/**
 * Weapons — the Aethon's hardpoint loadout.
 *
 * Before this the ship had exactly one gun: a pulse laser on a fixed cooldown,
 * drawing from the weapons capacitor, doing one damage number to whatever it
 * touched. Every fight was the same fight.
 *
 * A weapon here is a full specification — ballistics, guidance, ammunition,
 * damage model and its own hit signature — and `SpaceCombat` drives all of them
 * through one projectile loop. The differences that matter in play come out of
 * the data, not out of branches:
 *
 *   GUIDANCE   'straight' flies where it was pointed; 'homing' steers toward a
 *              locked target with a finite turn rate, so it can be outrun and
 *              out-turned; 'intercept' hunts hostile PROJECTILES instead of
 *              ships, which is what makes point defence a different weapon and
 *              not a short-range gun.
 *   FUSE       'impact' needs contact; 'proximity' detonates inside a radius,
 *              which is what lets a missile hurt something it never touched.
 *   SPLASH     a detonation radius and falloff, so a rocket punishes clustered
 *              targets and a nuke punishes everything including you if you are
 *              too close to the bloom.
 *   AMMO       finite for anything that expels mass. Only the laser runs purely
 *              off the capacitor, which is the trade: infinite shots, weakest
 *              hit, and it competes with the shields for power.
 *   DISABLE    seconds of systems failure inflicted. An EMP does almost no hull
 *              damage and is still the strongest thing in the bay against a
 *              swarm, because a drone that cannot manoeuvre or shoot is out of
 *              the fight without a single point of damage.
 *
 * Palette note: every tracer, bloom and spark colour below stays inside the
 * amber/steel/ice families the rest of the game uses. The EMP's violet is the
 * reserved Hollow accent, used here because an electromagnetic burst is the one
 * effect in the game that should not look like fire.
 */

/**
 * @typedef {object} WeaponSpec
 * @property {string} id            registry key
 * @property {string} name          HUD label, <= 9 chars so it fits the readout
 * @property {string} kind          short class label for the info line
 * @property {number} cooldown      seconds between shots
 * @property {number} cap           weapons-capacitor cost per shot (%)
 * @property {number|null} ammoMax  null = energy weapon, no magazine
 * @property {number} speed         muzzle velocity (units/s), added to ship velocity
 * @property {number} ttl           seconds before self-destruct
 * @property {number} damage        direct damage on contact
 * @property {number} splash        detonation radius (0 = no area effect)
 * @property {number} splashDamage  damage at the centre of the blast
 * @property {string} guidance      'straight' | 'homing' | 'intercept'
 * @property {number} turnRate      rad/s, guidance only
 * @property {string} fuse          'impact' | 'proximity'
 * @property {number} fuseR         proximity trigger radius
 * @property {number} hitR          contact radius against a ship
 * @property {number} disable       seconds of enemy systems failure
 * @property {number} shots         projectiles per trigger pull (spread weapons)
 * @property {number} spread        radians of cone for multi-shot
 * @property {number[]} tracer      projectile colour
 * @property {number} tracerSize    projectile sprite size
 * @property {object} fx            hit signature — see SpaceCombat._detonate
 */

/** @type {Record<string, WeaponSpec>} */
export const WEAPONS = {
  /**
   * The original gun, unchanged in feel. Pure energy, so it never runs dry —
   * but it draws on the same capacitor the shields want, and it is the weakest
   * thing aboard. The weapon you fall back to when everything else is empty.
   */
  laser: {
    id: 'laser', name: 'PULSE', kind: 'Energy lance',
    cooldown: 0.18, cap: 7, ammoMax: null,
    speed: 900, ttl: 2.4, damage: 34,
    splash: 0, splashDamage: 0,
    guidance: 'straight', turnRate: 0, fuse: 'impact', fuseR: 0, hitR: 30,
    disable: 0, shots: 1, spread: 0,
    tracer: [1.0, 0.78, 0.34], tracerSize: 3,
    fx: { flash: 1.0, sparks: 10, sparkCol: [1, 0.75, 0.3], smoke: 0, ring: 0, shake: 0.6 },
  },

  /**
   * Light railgun. A slug on a magnetic rail: nearly flat trajectory, arrives
   * before anything can react, and cheap enough to spam. Low damage per hit and
   * a big magazine — the accuracy weapon.
   */
  rail_light: {
    id: 'rail_light', name: 'RAIL-L', kind: 'Light railgun',
    cooldown: 0.28, cap: 4, ammoMax: 240,
    speed: 1900, ttl: 2.0, damage: 46,
    splash: 0, splashDamage: 0,
    guidance: 'straight', turnRate: 0, fuse: 'impact', fuseR: 0, hitR: 26,
    disable: 0, shots: 1, spread: 0,
    tracer: [0.86, 0.92, 1.0], tracerSize: 2,
    fx: { flash: 0.9, sparks: 14, sparkCol: [0.8, 0.88, 1], smoke: 0, ring: 0, shake: 0.7 },
  },

  /**
   * Heavy railgun. The same principle with a far larger slug and a capacitor
   * dump to match: slow to cycle, punishing to miss with, and the only kinetic
   * weapon that threatens a hull in one hit.
   */
  rail_heavy: {
    id: 'rail_heavy', name: 'RAIL-H', kind: 'Heavy railgun',
    cooldown: 1.35, cap: 22, ammoMax: 48,
    speed: 2400, ttl: 2.2, damage: 155,
    splash: 26, splashDamage: 40,
    guidance: 'straight', turnRate: 0, fuse: 'impact', fuseR: 0, hitR: 30,
    disable: 0, shots: 1, spread: 0,
    tracer: [0.95, 0.97, 1.0], tracerSize: 4,
    fx: { flash: 1.7, sparks: 26, sparkCol: [0.9, 0.94, 1], smoke: 2, ring: 1, shake: 1.6 },
  },

  /**
   * Scatter rail. Six sub-calibre slugs in a cone — hopeless at range, brutal
   * inside a few hundred units. The answer to something that has closed on you.
   */
  rail_scatter: {
    id: 'rail_scatter', name: 'SCATTER', kind: 'Scatter rail',
    cooldown: 0.85, cap: 12, ammoMax: 90,
    speed: 1400, ttl: 0.7, damage: 30,
    splash: 0, splashDamage: 0,
    guidance: 'straight', turnRate: 0, fuse: 'impact', fuseR: 0, hitR: 24,
    disable: 0, shots: 6, spread: 0.09,
    tracer: [1.0, 0.86, 0.52], tracerSize: 2,
    fx: { flash: 0.7, sparks: 8, sparkCol: [1, 0.8, 0.4], smoke: 0, ring: 0, shake: 0.5 },
  },

  /**
   * Guided rocket. Slower than anything that shoots straight, but it steers, and
   * its proximity fuse means a near miss still counts. Turn rate is deliberately
   * finite — a drone that commits to a hard break can beat it.
   */
  rocket: {
    id: 'rocket', name: 'ROCKET', kind: 'Guided munition',
    cooldown: 1.0, cap: 8, ammoMax: 60,
    speed: 620, ttl: 5.5, damage: 90,
    splash: 70, splashDamage: 70,
    guidance: 'homing', turnRate: 1.9, fuse: 'proximity', fuseR: 34, hitR: 26,
    disable: 0, shots: 1, spread: 0,
    tracer: [1.0, 0.66, 0.24], tracerSize: 3,
    fx: { flash: 2.0, sparks: 22, sparkCol: [1, 0.7, 0.28], smoke: 4, ring: 1, shake: 1.4 },
  },

  /**
   * Torpedo. A heavier rocket that trades agility for warhead: it will not catch
   * a fighter, but nothing survives being in the blast, and it is the only
   * conventional round that reliably kills a capital hull.
   */
  torpedo: {
    id: 'torpedo', name: 'TORPEDO', kind: 'Heavy munition',
    cooldown: 2.4, cap: 16, ammoMax: 24,
    speed: 420, ttl: 8, damage: 190,
    splash: 130, splashDamage: 150,
    guidance: 'homing', turnRate: 0.85, fuse: 'proximity', fuseR: 48, hitR: 32,
    disable: 0, shots: 1, spread: 0,
    tracer: [1.0, 0.58, 0.20], tracerSize: 4,
    fx: { flash: 3.0, sparks: 34, sparkCol: [1, 0.66, 0.24], smoke: 7, ring: 2, shake: 2.4 },
  },

  /**
   * Fission warhead. Enormous blast radius, four rounds in the locker, and it
   * does not care whose side you are on — the splash check runs against the
   * Aethon too. Firing one inside its own radius is a way to die.
   */
  nuke: {
    id: 'nuke', name: 'WARHEAD', kind: 'Fission warhead',
    cooldown: 4.5, cap: 34, ammoMax: 4,
    speed: 360, ttl: 10, damage: 260,
    splash: 340, splashDamage: 420,
    guidance: 'homing', turnRate: 0.5, fuse: 'proximity', fuseR: 70, hitR: 36,
    disable: 3.5, shots: 1, spread: 0,
    tracer: [1.0, 0.9, 0.7], tracerSize: 5,
    fx: { flash: 7.0, sparks: 64, sparkCol: [1, 0.88, 0.6], smoke: 16, ring: 4, shake: 6, selfHarm: true },
  },

  /**
   * Electromagnetic burst. Almost no damage — and still the strongest thing
   * aboard against a swarm, because a drone whose systems are down cannot
   * manoeuvre, cannot fire and cannot run. Detonates on a timer at range rather
   * than needing a hit.
   */
  emp: {
    id: 'emp', name: 'EMP', kind: 'EM burst',
    cooldown: 2.8, cap: 26, ammoMax: 18,
    speed: 700, ttl: 1.4, damage: 8,
    splash: 260, splashDamage: 14,
    guidance: 'straight', turnRate: 0, fuse: 'proximity', fuseR: 999, hitR: 24,
    disable: 6.0, shots: 1, spread: 0,
    // the reserved Hollow violet: the one effect in the game that must not read
    // as fire, because it is not combustion
    tracer: [0.62, 0.5, 0.82], tracerSize: 3,
    fx: { flash: 2.2, sparks: 40, sparkCol: [0.6, 0.52, 0.88], smoke: 0, ring: 3, shake: 0.9, emp: true },
  },

  /**
   * Point defence. Does not target ships at all — it hunts incoming hostile
   * PROJECTILES, which makes it the only weapon whose value is measured in shots
   * you did not take. Rapid, tiny magazine draw, useless offensively.
   */
  pdc: {
    id: 'pdc', name: 'PDC', kind: 'Point defence',
    cooldown: 0.09, cap: 2, ammoMax: 600,
    speed: 1500, ttl: 0.9, damage: 12,
    splash: 0, splashDamage: 0,
    guidance: 'intercept', turnRate: 5.5, fuse: 'impact', fuseR: 14, hitR: 14,
    disable: 0, shots: 2, spread: 0.05,
    tracer: [1.0, 0.94, 0.72], tracerSize: 1,
    fx: { flash: 0.5, sparks: 6, sparkCol: [1, 0.9, 0.6], smoke: 0, ring: 0, shake: 0.2 },
  },
};

/** Fixed cycle order — the order the CYCLE button and the X key step through. */
export const WEAPON_ORDER = [
  'laser', 'rail_light', 'rail_heavy', 'rail_scatter',
  'rocket', 'torpedo', 'nuke', 'emp', 'pdc',
];

/**
 * Live magazine state. Separate from the specs so the registry stays immutable
 * and a save only has to persist the counts.
 */
export class Loadout {
  constructor() {
    this.index = 0;
    /** @type {Record<string, number>} */
    this.ammo = {};
    for (const id of WEAPON_ORDER) {
      const w = WEAPONS[id];
      // start with about a third of capacity: enough to try everything, not
      // enough to lean on the heavy ordnance without resupplying
      if (w.ammoMax != null) this.ammo[id] = Math.max(1, Math.round(w.ammoMax * 0.34));
    }
  }

  get current() { return WEAPONS[WEAPON_ORDER[this.index]]; }
  get currentId() { return WEAPON_ORDER[this.index]; }

  /** Rounds left, or Infinity for an energy weapon. */
  rounds(id = this.currentId) {
    const w = WEAPONS[id];
    return w.ammoMax == null ? Infinity : (this.ammo[id] ?? 0);
  }

  /** Step to the next weapon. `dir` -1 cycles backwards. */
  cycle(dir = 1) {
    this.index = (this.index + dir + WEAPON_ORDER.length) % WEAPON_ORDER.length;
    return this.current;
  }

  /**
   * Step to the next weapon that actually has rounds. Used by auto-swap when a
   * magazine runs out mid-fight, so the trigger never goes dead silently — it
   * falls back to the laser at worst, which can always fire.
   */
  cycleToLoaded() {
    for (let k = 0; k < WEAPON_ORDER.length; k++) {
      this.cycle(1);
      if (this.rounds() > 0) return this.current;
    }
    this.index = WEAPON_ORDER.indexOf('laser');
    return this.current;
  }

  select(id) {
    const i = WEAPON_ORDER.indexOf(id);
    if (i >= 0) this.index = i;
    return this.current;
  }

  /** @returns {boolean} true if a round was available and consumed */
  consume(n = 1) {
    const w = this.current;
    if (w.ammoMax == null) return true;
    const have = this.ammo[w.id] ?? 0;
    if (have < n) return false;
    this.ammo[w.id] = have - n;
    return true;
  }

  /** Resupply, clamped to magazine capacity. */
  resupply(id, n) {
    const w = WEAPONS[id];
    if (!w || w.ammoMax == null) return 0;
    const before = this.ammo[id] ?? 0;
    this.ammo[id] = Math.min(w.ammoMax, before + n);
    return this.ammo[id] - before;
  }

  /** Top every magazine up — what docking at a station buys you. */
  resupplyAll(fraction = 1) {
    for (const id of WEAPON_ORDER) {
      const w = WEAPONS[id];
      if (w.ammoMax != null) this.resupply(id, Math.ceil(w.ammoMax * fraction));
    }
  }

  toJSON() { return { index: this.index, ammo: { ...this.ammo } }; }

  fromJSON(d) {
    if (!d) return;
    if (Number.isInteger(d.index)) this.index = Math.max(0, Math.min(WEAPON_ORDER.length - 1, d.index));
    if (d.ammo) for (const id of WEAPON_ORDER) if (typeof d.ammo[id] === 'number') this.ammo[id] = d.ammo[id];
  }
}
