/**
 * PersonalCombat — the three hand weapons, on foot.
 *
 * `context/07` Phase 6 has carried "personal combat (3 weapons)" as its only
 * unchecked line since the phase opened: the sidearm, carbine and arc cutter
 * have existed in `ItemRegistry` as inert loot the whole time. This is the
 * module that lets you hold one.
 *
 * DESIGN DECISIONS, and why each one is the way it is:
 *
 * HITSCAN, not projectiles. `SpaceCombat` simulates real bolts because ship
 * engagements happen across kilometres, where flight time is the whole tactical
 * problem. A corridor is nine metres wide. A slug crosses the longest sightline
 * on this ship in under two frames, so a projectile would only ever add latency
 * and a class of bugs; the ray is the honest model at this scale.
 *
 * RECOIL IS AN IMPULSE, NOT A SPRAY. Firing kicks the camera's pitch up and the
 * kick decays. It is not random cone growth. That means the second shot of a
 * burst goes high in a way you can predict, feel and compensate for — a skill
 * rather than a dice roll — and it is the difference between a gun that feels
 * mechanical and one that feels like a probability table.
 *
 * A GUNSHOT IS THE LOUDEST THING IN THE GAME. `NoiseSystem` treats a sprint as
 * 0.95; a shot pins the meter at 1.0 and holds it. That is the trade the whole
 * survival design turns on: the weapon works, and using it tells the ship
 * exactly where you are. Getting a gun should not make the Hollow easier.
 *
 * THE HOLLOW CANNOT BE SHOT. Not "has a lot of health" — it takes no damage by
 * construction, because `context/03` and `context/04` state that no combat-win
 * path exists and `TensionDirector` gives the entity no health, no hitbox and no
 * defeat state. There is nothing here for a ray to intersect: firing in its
 * compartment resolves against the bulkhead behind it and reports a refusal on
 * top. Handing the player a gun and then quietly making the monster killable
 * would undo the one thing that earns the *Isolation* comparison mechanically.
 *
 * YOU CAN SHOOT YOUR OWN SHIP. Rounds that land on a console, terminal or panel
 * damage the section they are in. The Aethon is the only thing keeping you
 * alive, discharging a slug thrower inside it is a genuinely stupid act, and the
 * game should say so rather than treating the interior as a shooting gallery.
 *
 * AMMUNITION LIVES IN THE HOLD. A magazine change consumes one `ammo_slug` or
 * `ammo_cell` item, so ammunition competes for the same 120 slots as everything
 * else and a full loadout is a real decision about volume.
 */
import { Vec3, rayAabb, clamp } from '../utils/MathUtils.js';
import { PALETTE } from '../core/Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';
import { FONT_FACES } from '../rendering/PixelFont.js';

/**
 * @typedef {object} HandWeaponSpec
 * @property {string} item      ItemRegistry id this spec is unlocked by
 * @property {string} name      viewmodel/HUD label
 * @property {string} ammo      ItemRegistry id of a magazine (null = none)
 * @property {number} mag       rounds per magazine
 * @property {number} cooldown  seconds between shots
 * @property {number} damage    per-hit damage
 * @property {number} range     metres of reach
 * @property {number} spread    radians of cone at rest
 * @property {number} recoil    radians of pitch impulse per shot
 * @property {number} noise     noise level a shot pins the meter to
 * @property {number} reload    seconds to change a magazine
 * @property {boolean} auto     held trigger keeps firing
 * @property {string} form      viewmodel silhouette: pistol | rifle | cutter
 */

/** @type {Record<string, HandWeaponSpec>} */
export const HAND_WEAPONS = {
  weapon_pistol: {
    item: 'weapon_pistol', name: 'SIDEARM', ammo: 'ammo_slug', mag: 6,
    // Slow, heavy, accurate, brutal recoil. Six rounds and a long reload is the
    // whole character: it is a weapon you aim, not one you spray.
    cooldown: 0.44, damage: 34, range: 26, spread: 0.004,
    recoil: 0.052, noise: 1.0, reload: 1.6, auto: false, form: 'pistol',
  },
  weapon_carbine: {
    item: 'weapon_carbine', name: 'CARBINE', ammo: 'ammo_slug', mag: 20,
    // "Rebuilt from three different rifles." Fast, loose, and it empties the
    // magazine in under three seconds if you let it.
    cooldown: 0.12, damage: 19, range: 44, spread: 0.017,
    recoil: 0.019, noise: 1.0, reload: 2.3, auto: true, form: 'rifle',
  },
  weapon_cutter: {
    item: 'weapon_cutter', name: 'CUTTER', ammo: 'ammo_cell', mag: 44,
    // "A mining tool, technically." Reach of an arm, but it is the only one of
    // the three that does not announce you to the entire deck.
    cooldown: 0.09, damage: 13, range: 3.1, spread: 0.05,
    recoil: 0.004, noise: 0.45, reload: 1.9, auto: true, form: 'cutter',
  },
};

/**
 * SPECIALTY LOADS. A magazine is not just a count — what is in it changes what
 * the shot does, and the hold is where that decision gets made.
 *
 * Preference order matters: the list for a weapon is tried in order and the
 * first box in the hold wins. Specialty rounds sit ABOVE the standard load
 * because you only bought them to use them, and the counter names whichever one
 * chambered so there is never a question of what is in the gun.
 *
 *   dmg   multiplier on the weapon's per-hit damage
 *   ship  multiplier on the damage a stray round does to your own systems — this
 *         is the whole argument for frangible rounds and against AP
 *   mag   multiplier on magazine capacity
 *   sprd  multiplier on the resting cone
 */
const LOADS = {
  ammo_slug: [
    { id: 'ammo_slug_ap', tag: 'AP', dmg: 1.42, ship: 2.1, mag: 1, sprd: 0.8 },
    { id: 'ammo_slug_frang', tag: 'FR', dmg: 0.86, ship: 0.22, mag: 1, sprd: 1.25 },
    { id: 'ammo_slug', tag: '', dmg: 1, ship: 1, mag: 1, sprd: 1 },
  ],
  ammo_cell: [
    { id: 'ammo_cell_heavy', tag: 'OC', dmg: 1.65, ship: 1.5, mag: 0.45, sprd: 1 },
    { id: 'ammo_cell', tag: '', dmg: 1, ship: 1, mag: 1, sprd: 1 },
  ],
};
/** The plain load for a weapon, used when nothing specialised is aboard. */
const PLAIN = { id: null, tag: '', dmg: 1, ship: 1, mag: 1, sprd: 1 };

/**
 * Ship systems you should not be putting a slug through, matched on the
 * interactable's own label.
 *
 * Interactable records carry `min`/`max`/`label`/`onInteract`/`prop` and no type
 * tag — there is nothing to switch on. main.js already classifies the same
 * records by label to decide what recharges the scanner cell, so this follows
 * that precedent rather than inventing a parallel taxonomy that would then have
 * to be threaded through every prop class.
 */
const FRAGILE = /CONSOLE|TERMINAL|MAINFRAME|PANEL|SCREEN|MONITOR|BUS|SYS|RECORD|BENCH|MED/i;

export class PersonalCombat {
  /**
   * @param {object} deps
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {import('../gameplay/Inventory.js').Inventory} deps.inventory
   * @param {import('../interior/CollisionMap.js').CollisionMap} deps.collision
   * @param {import('../interior/ShipMap.js').ShipMap} deps.shipMap
   * @param {(text:string)=>void} deps.notify
   */
  constructor({ events, inventory, collision, shipMap, notify }) {
    this.events = events;
    this.inv = inventory;
    // Read through the map rather than caching the CollisionMap object: a hull
    // reconfiguration (ShipMap.reconfigure) replaces it wholesale, and a cached
    // reference would leave every shot hitting the previous ship's geometry.
    this._collisionArg = collision;
    this.shipMap = shipMap;
    this.notify = notify ?? (() => {});

    /** @type {HandWeaponSpec|null} null = holstered, hands empty */
    this.spec = null;
    /** Which specialty load is in the chamber; null until something is loaded. */
    this.load = null;
    /** The load taken out of the hold for a change already in progress. */
    this._pending = null;
    this.rounds = 0;
    this.cd = 0;
    this.reloadT = 0;
    /** Decaying 0..~0.1 envelope: drives the viewmodel kick and the aim cone. */
    this.recoil = 0;
    /** Un-applied pitch impulse in radians. Consumed once by consumeKick(). */
    this.kick = 0;
    /** 0..1 muzzle-flash envelope, decays fast. */
    this.flash = 0;
    /** Viewmodel sway phase, advanced by how fast the player is actually moving. */
    this.sway = 0;
    this._swayAmt = 0;
    /** @type {Array<{p:number[], n:number[], t:number, kind:string}>} */
    this.impacts = [];
    /** Spent-case ejecta, purely cosmetic: {x,y,vx,vy,t} on the UI grid. */
    this.cases = [];
    this._rand = 0x1a2b3c;
    /**
     * `() => boolean` — is the entity in the compartment the player is standing
     * in? Injected rather than imported, so this module has no dependency on the
     * tension director.
     *
     * A PREDICATE, not a position, and that is the whole point. The Hollow has no
     * world transform and no collider anywhere in this codebase; handing out a
     * point to raycast against would be the first step toward it having a hitbox,
     * and a hitbox is one commit away from a health bar. Firing in its
     * compartment is enough to know a round went through it — and the answer is
     * still that nothing happens.
     */
    this.hollowHere = null;

    /**
     * The one thing in the game a round CAN kill, injected the same way and for
     * the opposite reason.
     *
     * `{raycast(origin, dir, range), hurt(actor, dmg)}` — a boarder is a real
     * body with a real box, so unlike `hollowHere` this hands out a position and
     * takes damage, which is precisely the distinction `context/04` draws
     * between an enemy and the entity. Left null on a hull with nothing aboard;
     * the shot then resolves against geometry exactly as it always did.
     *
     * @type {{raycast:Function, hurt:Function}|null}
     */
    this.hostiles = null;

    const f = hexToRgbf;
    this.C = {
      steel: f(PALETTE.HULL_METAL?.[1] ?? '#5a6154'),
      steelHi: f(PALETTE.HULL_METAL?.[2] ?? '#7d8574'),
      dark: f(PALETTE.SHADOW_BLACK[0]),
      amber: f(PALETTE.HUD_AMBER[1]),
      amberHi: f(PALETTE.HUD_AMBER[2]),
      rust: f(PALETTE.RUST?.[1] ?? '#a04e1a'),
      alert: f(PALETTE.HUD_ALERT[1]),
      arc: f('#8fb4c8'), // cold cutter plasma; NOT the violet reserved for the Hollow
      gore: f('#6a2018'), // a round into a body: dark, not a bright arterial red
      white: [1, 1, 1],
    };
  }

  /** Deterministic 0..1; the FX must not reseed Math.random every frame. */
  _r() {
    this._rand = (this._rand * 1664525 + 1013904223) & 0x7fffffff;
    return this._rand / 0x7fffffff;
  }

  /** Weapon specs the player is actually carrying, in registry order. */
  available() {
    return Object.values(HAND_WEAPONS).filter((w) => this.inv.count(w.item) > 0);
  }

  get drawn() { return !!this.spec; }
  get reloading() { return this.reloadT > 0; }

  /**
   * Step to the next carried weapon, then to holstered, then round again — so
   * one key both draws and puts away and there is never a mode you cannot leave.
   */
  cycle() {
    const list = this.available();
    if (!list.length) {
      this.notify('NO WEAPON IN THE HOLD');
      return;
    }
    const at = this.spec ? list.findIndex((w) => w.item === this.spec.item) : -1;
    const next = at + 1;
    if (next >= list.length) { this.holster(); return; }
    this.spec = list[next];
    this.rounds = 0;
    // The chambered load belongs to the weapon you just put down, not the one in
    // your hands — carrying it across would let a cutter fire penetrator slugs.
    this.load = null;
    this._pending = null;
    this.cd = 0.28;         // draw time: you cannot quick-draw out of a holster
    this.reloadT = 0;
    this.notify(`${this.spec.name} DRAWN`);
    this._autoLoad();
  }

  holster() {
    if (!this.spec) return;
    this.spec = null;
    this.reloadT = 0;
    this.flash = 0;
    this.notify('WEAPON STOWED');
  }

  /**
   * Chamber a magazine on draw, instantly and silently.
   *
   * NOT a call into `reload()`: routing it there started the full timed magazine
   * change, so a freshly drawn weapon spent 1.6-2.3 seconds unusable on top of
   * the draw cooldown and read as broken. You holstered it loaded; it comes out
   * loaded. The timed reload is for magazines you change under fire.
   */
  _autoLoad() {
    const s = this.spec;
    if (!s || this.rounds > 0) return;
    const load = this._takeMag(s);
    if (load) { this.load = load; this.rounds = Math.max(1, Math.round(s.mag * load.mag)); }
  }

  /**
   * Pull ONE magazine out of the hold, best load first, and return what it was.
   * Returns null if there is nothing at all for this weapon.
   */
  _takeMag(s) {
    for (const l of LOADS[s.ammo] ?? []) {
      if (this.inv.remove(l.id, 1) >= 1) return l;
    }
    return null;
  }

  /** The load currently chambered — never null, so callers can multiply freely. */
  get chambered() { return this.load ?? PLAIN; }

  /**
   * Change magazines. Consumes ONE ammunition item from the hold and fills to
   * capacity — a partial magazine is discarded, which is what actually happens
   * and what makes reloading early cost something.
   */
  reload(silent = false) {
    const s = this.spec;
    if (!s || this.reloadT > 0) return false;
    if (this.rounds >= Math.round(s.mag * this.chambered.mag)) {
      if (!silent) this.notify('MAGAZINE FULL'); return false;
    }
    const load = this._takeMag(s);
    if (!load) {
      if (!silent) this.notify('NO AMMUNITION');
      return false;
    }
    this._pending = load;
    this.reloadT = s.reload;
    if (!silent) this.notify(load.tag ? `RELOADING — ${load.tag}` : 'RELOADING');
    return true;
  }

  /** Take the pending pitch impulse, in radians, and clear it. */
  consumeKick() {
    const k = this.kick;
    this.kick = 0;
    return k;
  }

  update(dt, player) {
    this.cd = Math.max(0, this.cd - dt);
    // recoil bleeds off fast; the camera has already been kicked by it
    this.recoil *= Math.max(0, 1 - dt * 9);
    this.flash = Math.max(0, this.flash - dt * 7);
    if (this.reloadT > 0) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        // The load was taken out of the hold when the change STARTED, so it is
        // already paid for; this is where it reaches the chamber.
        if (this._pending) { this.load = this._pending; this._pending = null; }
        this.rounds = this.spec ? Math.max(1, Math.round(this.spec.mag * this.chambered.mag)) : 0;
        this.reloadT = 0;
      }
    }
    // Sway tracks REAL movement, so a stationary weapon is still. The controller
    // has no `speed` accessor — the horizontal components of `velocity` are the
    // ground truth (velocity[1] is the fall, which should not sway the barrel).
    const v = player?.controller?.velocity;
    const sp = v ? Math.hypot(v[0], v[2]) : 0;
    this._swayAmt += (Math.min(1, sp / 3) - this._swayAmt) * Math.min(1, dt * 5);
    this.sway += dt * (2.4 + this._swayAmt * 5.2);
    for (let i = this.impacts.length - 1; i >= 0; i--) {
      this.impacts[i].t -= dt * 2.6;
      if (this.impacts[i].t <= 0) this.impacts.splice(i, 1);
    }
    for (let i = this.cases.length - 1; i >= 0; i--) {
      const c = this.cases[i];
      c.t -= dt * 1.5;
      c.x += c.vx * dt; c.y += c.vy * dt; c.vy += dt * 210;
      if (c.t <= 0) this.cases.splice(i, 1);
    }
  }

  /**
   * Pull the trigger. `held` distinguishes a tap from a held trigger so a
   * semi-automatic weapon cannot be turned into an automatic one by holding.
   * @returns {boolean} whether a round left the barrel
   */
  tryFire(camera, held, systems) {
    const s = this.spec;
    if (!s || this.cd > 0 || this.reloadT > 0) return false;
    if (!s.auto && held) return false;
    if (this.rounds <= 0) {
      this.cd = 0.3;
      this.notify('EMPTY — RELOAD');
      // and dry-firing still makes a noise, just a small one
      this.events?.emit('weapon:dryFire', {});
      return false;
    }
    this.rounds -= 1;
    this.cd = s.cooldown;
    this.flash = 1;
    // Two separate things, and conflating them was a bug worth naming: `recoil`
    // is a DECAYING envelope that drives the viewmodel kick and the cone, while
    // `kick` is a one-shot pitch impulse the camera consumes exactly once. The
    // first version applied `recoil` to the camera every frame while it decayed,
    // which made the total climb depend on frame rate.
    this.recoil += s.recoil;
    this.kick += s.recoil;
    this.events?.emit('weapon:fire', { level: s.noise, name: s.name });
    this.cases.push({
      x: 0, y: 0, vx: 26 + this._r() * 22, vy: -34 - this._r() * 26, t: 1,
    });

    // Aim: the cone opens with the recoil still in the frame, so a fast burst
    // genuinely is less accurate than a measured pair — but as a consequence of
    // the kick rather than as a separate penalty bolted on.
    const dir = Vec3.create(camera.forward[0], camera.forward[1], camera.forward[2]);
    const cone = s.spread * this.chambered.sprd + this.recoil * 0.5;
    dir[0] += (this._r() - 0.5) * cone * 2;
    dir[1] += (this._r() - 0.5) * cone * 2;
    dir[2] += (this._r() - 0.5) * cone * 2;
    Vec3.normalize(dir, dir);

    // WHAT THE ROUND MEETS FIRST. A body and the bulkhead behind it are both
    // candidates, so both rays are cast and the NEARER one wins — testing the
    // hostiles first and returning early would let you shoot through a crate at
    // something standing behind it.
    const geom = this._hitscan(camera.eye, dir, s.range);
    const body = this.hostiles?.raycast(camera.eye, dir, geom ? geom.dist : s.range) ?? null;
    if (body) {
      const L = this.chambered;
      this.impacts.push({ p: body.p, n: body.n, t: 1, kind: 'gore' });
      const killed = this.hostiles.hurt(body.actor, s.damage * L.dmg);
      if (killed) this.notify(`${killed} DOWN`);
      this.events?.emit('weapon:hitBody', { kind: body.actor.kind, killed: !!killed });
    } else if (geom) {
      this._resolve(geom, s, systems);
    }
    // Discharging a weapon in the entity's compartment. Resolved SEPARATELY from
    // the ray, and after it, because there is nothing to aim at: the round does
    // whatever it was going to do to the bulkhead behind, and the refusal is
    // reported on top of that.
    if (this.hollowHere?.()) {
      this.notify('THE ROUND GOES THROUGH IT');
      this.events?.emit('weapon:hitHollow', {});
    }
    return true;
  }

  /**
   * Nearest interactable box or active collider. Returns the point, an
   * approximate surface normal, and what it was.
   */
  _hitscan(origin, dir, range) {
    let best = null, bd = range;
    for (const rec of this.shipMap?.interactables ?? []) {
      const d = rayAabb(origin[0], origin[1], origin[2], dir[0], dir[1], dir[2],
        rec.min, rec.max);
      if (d < bd && d > 0.02) {
        bd = d;
        const label = typeof rec.label === 'function' ? rec.label() : rec.label;
        best = { label: label ?? '', rec, box: rec };
      }
    }
    for (const b of (this.shipMap?.collision ?? this._collisionArg)?.boxes ?? []) {
      if (!b.active) continue;
      const d = rayAabb(origin[0], origin[1], origin[2], dir[0], dir[1], dir[2], b.min, b.max);
      if (d < bd && d > 0.02) { bd = d; best = { label: '', rec: b.ref, box: b }; }
    }
    if (!best) return null;
    const p = [origin[0] + dir[0] * bd, origin[1] + dir[1] * bd, origin[2] + dir[2] * bd];
    return { ...best, p, dist: bd, n: boxNormal(best.box, p) };
  }

  _resolve(hit, spec, systems) {
    this.impacts.push({
      p: hit.p, n: hit.n, t: 1,
      kind: spec.form === 'cutter' ? 'arc' : 'spark',
    });
    if (hit.label && FRAGILE.test(hit.label)) {
      // You just put a slug through your own ship. The section it is in loses
      // integrity, which the HUD's damage plan will show and REPAIR will have to
      // patch with a plate you could have kept.
      //
      // The LOAD decides how bad that is, and this is the reason frangible
      // ammunition exists: a round that breaks up on the console face does a
      // fifth of the harm a penetrator does going through the console, the
      // bulkhead and whatever runs behind it.
      const L = this.chambered;
      const sec = sectionAt(hit.p);
      if (systems?.sections && systems.sections[sec] != null) {
        systems.sections[sec] = clamp(systems.sections[sec] - spec.damage * L.dmg * L.ship * 0.16, 0, 100);
        systems.hull = systems.sectionMean();
      }
      this.notify(L.ship < 0.5
        ? `ROUND BREAKS UP ON ${sec.toUpperCase()} PANEL`
        : `DAMAGE TO SHIP SYSTEMS — ${sec.toUpperCase()}`);
      this.events?.emit('weapon:hitShip', { section: sec });
    }
  }

  // -- viewmodel -------------------------------------------------------------

  /**
   * Draw the held weapon, its muzzle flash, the impact sparks and the ammunition
   * counter, all on the fixed 480x270 UI grid.
   *
   * Everything here is `pix.rect` on the font atlas' white texel, the same way
   * `ProximityScanner` paints its handheld — no viewmodel mesh, no extra draw
   * call, and it stays honest to the pixel grid because it IS the pixel grid.
   * The impacts are the one part that is world-space: they are projected through
   * the camera each frame so a spark stays on the wall it hit while you turn.
   */
  draw(pix, font, fontTexture, W, H, camera) {
    pix.setTexture(fontTexture);
    this._drawImpacts(pix, W, H, camera);
    if (!this.spec) return;

    // Anchor: bottom-right, swaying with the walk cycle, dropped while
    // reloading and shoved back and up by recoil. The hand deliberately runs
    // OFF the bottom edge — a viewmodel that floats clear of the frame reads as
    // a sprite pasted on the screen rather than as something you are holding.
    const S = 2.3;
    const swayX = Math.sin(this.sway) * 5.5 * (0.35 + this._swayAmt);
    const swayY = Math.abs(Math.cos(this.sway)) * 5.0 * (0.3 + this._swayAmt);
    const kick = this.recoil * 320;
    const rel = this.reloadT > 0 && this.spec
      ? Math.sin(Math.min(1, 1 - this.reloadT / this.spec.reload) * Math.PI) * 46
      : 0;
    // 0.62, not 0.70: at 0.70 the weapon sat squarely on top of the HUD's SHIP
    // plate (which starts at x=361 on the 480-wide grid) and buried the FUEL and
    // HULL gauges whenever anything was drawn. A viewmodel is allowed to be the
    // nearest thing to the eye, but not at the cost of the readouts.
    const ax = Math.round(W * 0.62 + swayX + kick * 0.35);
    const ay = Math.round(H + 12 + swayY + kick + rel);

    const muzzle = this.spec.form === 'pistol' ? this._pistol(pix, ax, ay, S)
      : this.spec.form === 'rifle' ? this._rifle(pix, ax, ay, S)
        : this._cutter(pix, ax, ay, S);

    if (this.flash > 0.02) this._muzzleFlash(pix, W, H, muzzle[0], muzzle[1], S);
    this._ejectedCases(pix, ax, ay, S);
    this._ammoTag(pix, font, W, H);
    // FLUSH. `PixelRenderer` only auto-flushes when the bound texture changes or
    // the quad buffer fills, and the only explicit flush in the frame is the one
    // at the end of `HUD.render` — which runs BEFORE this. Without this call the
    // whole viewmodel was queued and silently discarded: draw() ran, every rect
    // was emitted, and nothing reached the screen.
    pix.flush();
  }

  /** A plate with the house lighting: lit top edge, shadowed bottom and right. */
  _plate(pix, x, y, w, h, c, k = 1) {
    if (w <= 0 || h <= 0) return;
    pix.rect(x, y, w, h, [c[0] * k, c[1] * k, c[2] * k, 1]);
    pix.rect(x, y, w, 1, [Math.min(1, c[0] * k * 1.5), Math.min(1, c[1] * k * 1.5),
      Math.min(1, c[2] * k * 1.5), 1]);
    pix.rect(x, y + h - 1, w, 1, [0, 0, 0, 0.55]);
    pix.rect(x + w - 1, y, 1, h, [0, 0, 0, 0.4]);
  }

  /** Speckle: the wear that stops a slab of one colour reading as plastic. */
  _wear(pix, x, y, w, h, n, c) {
    for (let i = 0; i < n; i++) {
      const sx = x + Math.floor(this._r() * w), sy = y + Math.floor(this._r() * h);
      pix.rect(sx, sy, 1, 1, [c[0], c[1], c[2], 0.35 + this._r() * 0.4]);
    }
  }

  /**
   * Local-space drawing helpers for the three silhouettes.
   *
   * The forms are authored on a small integer grid — roughly 45 wide by 52 tall,
   * the size a weapon reads at when you sketch it — and blown up by `S` at draw
   * time. Authoring at final size would mean 2.4x-larger numbers everywhere and
   * a rewrite of all three every time the scale is retuned, and the first pass
   * WAS at final size: a 35x51 pistol on a 480x270 grid is 7% of the frame, and
   * it read as a toy floating mid-screen rather than a weapon in your hands.
   *
   * @returns {{P:Function, R:Function, Wr:Function}}
   */
  _brush(pix, ax, ay, S) {
    const r = (v) => Math.round(v * S);
    return {
      /** plate at local (dx,dy) size (w,h) */
      P: (dx, dy, w, h, c, k = 1) =>
        this._plate(pix, ax + r(dx), ay + r(dy), r(w), r(h), c, k),
      /** raw rect, for cuts and slots that must not carry a bevel */
      R: (dx, dy, w, h, col) =>
        pix.rect(ax + r(dx), ay + r(dy), Math.max(1, r(w)), Math.max(1, r(h)), col),
      /** wear speckle over a local region */
      Wr: (dx, dy, w, h, n, c) =>
        this._wear(pix, ax + r(dx), ay + r(dy), r(w), r(h), n, c),
      r,
    };
  }

  /**
   * Kestrel Sidearm: heavy slug pistol, held right of centre and canted so the
   * barrel points up and inward at the crosshair. Returns the muzzle point.
   */
  _pistol(pix, ax, ay, S) {
    const { C } = this;
    const { P, R, Wr, r } = this._brush(pix, ax, ay, S);
    // gloved hand and forearm, rising off the bottom edge
    P(4, -26, 15, 28, C.dark, 2.2);
    P(6, -30, 12, 8, C.dark, 2.8);
    // Finger separations. Without them the glove is a featureless dark slab and
    // the weapon reads as floating above a rectangle rather than being gripped.
    for (const fy of [-22, -16, -10]) {
      R(4, fy, 15, 1, [0, 0, 0, 0.7]);
      R(4, fy + 1, 15, 1, [C.steelHi[0] * 0.5, C.steelHi[1] * 0.5, C.steelHi[2] * 0.5, 0.35]);
    }
    Wr(4, -26, 15, 26, 12, C.rust);
    // grip, raked back under the hand
    P(3, -34, 11, 12, C.steel, 0.68);
    // frame and trigger guard
    P(-1, -41, 19, 8, C.steel, 0.9);
    R(3, -33, 8, 3, [0, 0, 0, 0.7]);
    // slide: the long lit mass that makes it read as a firearm
    P(-12, -48, 31, 8, C.steel, 1.1);
    P(-12, -48, 31, 3, C.steelHi, 1);
    // ejection port, rear sight, serrations
    R(4, -45, 6, 3, [0, 0, 0, 0.75]);
    P(15, -51, 3, 3, C.dark, 2.6);
    for (let i = 0; i < 5; i++) R(12 - i * 2, -46, 1, 4, [0, 0, 0, 0.45]);
    // muzzle crown
    P(-16, -47, 5, 6, C.steel, 0.8);
    R(-16, -45, 3, 2, [0, 0, 0, 0.85]);
    Wr(-12, -48, 31, 8, 16, C.rust);
    return [ax + r(-16), ay + r(-44)];
  }

  /** Salvage Carbine: longer, uglier, three donors' worth of mismatched parts. */
  _rifle(pix, ax, ay, S) {
    const { C } = this;
    const { P, R, Wr, r } = this._brush(pix, ax, ay, S);
    P(6, -24, 14, 26, C.dark, 2.2);
    for (const fy of [-20, -14, -8]) {
      R(6, fy, 14, 1, [0, 0, 0, 0.7]);
      R(6, fy + 1, 14, 1, [C.steelHi[0] * 0.5, C.steelHi[1] * 0.5, C.steelHi[2] * 0.5, 0.35]);
    }
    Wr(6, -24, 14, 24, 11, C.rust);
    // stock and buffer tube, running off the bottom-right corner
    P(14, -34, 22, 11, C.steel, 0.6);
    // receiver
    P(-6, -42, 32, 11, C.steel, 0.95);
    P(-6, -42, 32, 3, C.steelHi, 0.95);
    R(2, -38, 7, 3, [0, 0, 0, 0.75]);   // port
    // magazine, canted forward under the receiver
    P(1, -32, 9, 14, C.steel, 0.5);
    Wr(1, -32, 9, 14, 8, C.rust);
    // handguard + barrel, reaching up-left toward the crosshair
    P(-26, -46, 22, 8, C.steel, 0.78);
    for (let i = 0; i < 6; i++) R(-24 + i * 3, -44, 2, 4, [0, 0, 0, 0.5]);
    P(-38, -45, 13, 5, C.steel, 0.9);
    // front sight post and a mismatched scavenged rail block
    P(-30, -51, 4, 6, C.dark, 2.4);
    P(-2, -47, 9, 5, C.dark, 2.6);
    Wr(-38, -46, 44, 10, 18, C.rust);
    return [ax + r(-40), ay + r(-42)];
  }

  /** Arc Cutter: an industrial tool with a live emitter head, not a gun. */
  _cutter(pix, ax, ay, S) {
    const { C } = this;
    const { P, R, Wr, r } = this._brush(pix, ax, ay, S);
    P(5, -25, 15, 27, C.dark, 2.2);
    for (const fy of [-21, -15, -9]) {
      R(5, fy, 15, 1, [0, 0, 0, 0.7]);
      R(5, fy + 1, 15, 1, [C.steelHi[0] * 0.5, C.steelHi[1] * 0.5, C.steelHi[2] * 0.5, 0.35]);
    }
    Wr(5, -25, 15, 25, 11, C.rust);
    // body: a fat rust-orange tool casing, not steel — it belongs in a workshop
    P(-4, -40, 26, 15, C.rust, 0.62);
    P(-4, -40, 26, 3, C.rust, 0.95);
    Wr(-4, -40, 26, 15, 19, C.dark);
    // cell in the heel, charge showing through a slot
    P(12, -30, 10, 12, C.steel, 0.55);
    const frac = this.spec ? this.rounds / this.spec.mag : 0;
    R(14, -27, Math.max(1, 6 * frac), 3, [C.arc[0], C.arc[1], C.arc[2], 0.9]);
    // neck and the emitter fork
    P(-20, -42, 18, 8, C.steel, 0.8);
    // Emitter fork: two bright tines with a hard dark gap between them. At the
    // first contrast the fork sank into the casing and the cutter read as a
    // plain brown box with a spark near it.
    R(-28, -44, 10, 8, [0, 0, 0, 0.85]);
    P(-27, -47, 9, 5, C.steelHi, 1.15);
    P(-27, -38, 9, 5, C.steelHi, 1.15);
    R(-19, -43, 2, 7, [C.arc[0] * 0.4, C.arc[1] * 0.4, C.arc[2] * 0.4, 0.8]);
    // the arc itself, crawling between the tines whenever there is charge
    if (frac > 0) {
      for (let i = 0; i < 9; i++) {
        const f = i / 8;
        const jx = -24 + f * 5 + (this._r() - 0.5) * 3;
        const jy = -43 + f * 9 + (this._r() - 0.5) * 3;
        R(jx, jy, 2, 1, [C.arc[0], C.arc[1], C.arc[2], 0.4 + this._r() * 0.6]);
      }
    }
    return [ax + r(-26), ay + r(-41)];
  }

  /**
   * Muzzle flash: a hard white core, a four-lobed star, a scatter of unburnt
   * powder, and a low-alpha wash over the whole frame so the corridor visibly
   * lights up for one frame. That last layer is what sells a shot indoors — the
   * flash is the brightest thing on this ship while it lasts.
   */
  _muzzleFlash(pix, W, H, mx, my, S = 1) {
    const { C } = this;
    const f = this.flash;
    const arc = this.spec?.form === 'cutter';
    const col = arc ? C.arc : [1, 0.86, 0.55];
    pix.rect(0, 0, W, H, [col[0], col[1], col[2], f * (arc ? 0.05 : 0.13)]);
    const r = (arc ? 4 : 11) * f * S;
    // lobes: long across the bore, short vertically — a real flash is not round
    pix.rect(Math.round(mx - r * 1.7), Math.round(my - r * 0.28), Math.round(r * 3.4),
      Math.max(1, Math.round(r * 0.56)), [col[0], col[1], col[2], 0.85 * f]);
    pix.rect(Math.round(mx - r * 0.28), Math.round(my - r * 1.25), Math.max(1, Math.round(r * 0.56)),
      Math.round(r * 2.5), [col[0], col[1], col[2], 0.7 * f]);
    pix.rect(Math.round(mx - r * 0.5), Math.round(my - r * 0.5), Math.max(1, Math.round(r)),
      Math.max(1, Math.round(r)), [1, 1, 1, 0.9 * f]);
    for (let i = 0; i < (arc ? 5 : 12); i++) {
      const a = this._r() * Math.PI * 2, d = this._r() * r * 2.4;
      pix.rect(Math.round(mx + Math.cos(a) * d), Math.round(my + Math.sin(a) * d), 1, 1,
        [col[0], col[1], col[2], f * (0.3 + this._r() * 0.6)]);
    }
  }

  /** Spent cases tumbling out of the port and off the bottom of the frame. */
  _ejectedCases(pix, ax, ay, S = 1) {
    const { C } = this;
    for (const c of this.cases) {
      pix.rect(Math.round(ax + (8 + c.x) * S), Math.round(ay + (-44 + c.y) * S),
        Math.max(1, Math.round(2 * S)), Math.max(1, Math.round(S)),
        [C.amberHi[0], C.amberHi[1], C.amberHi[2], Math.min(1, c.t)]);
    }
  }

  /**
   * World-space impact sparks, projected through the camera so they stay on the
   * surface they hit. Three layers: a hot core, a radial spark burst biased
   * along the surface normal, and a dark scorch that outlives both.
   */
  _drawImpacts(pix, W, H, camera) {
    if (!this.impacts.length || !camera?.viewProjection) return;
    const { C } = this;
    const m = camera.viewProjection;
    for (const im of this.impacts) {
      const p = im.p;
      const cw = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15];
      if (cw <= 0.01) continue; // behind the eye
      const cx = m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12];
      const cy = m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13];
      const sx = (cx / cw * 0.5 + 0.5) * W;
      const sy = (1 - (cy / cw * 0.5 + 0.5)) * H;
      if (sx < -20 || sx > W + 20 || sy < -20 || sy > H + 20) continue;
      // A round into a body does not spark. Dark, wet, and no hot core — the
      // white pixel is what makes an impact read as metal, so a hit that keeps
      // it would tell you that you had missed and hit the bulkhead.
      const gore = im.kind === 'gore';
      const t = im.t, col = gore ? C.gore : im.kind === 'arc' ? C.arc : [1, 0.82, 0.5];
      // scorch first, so the sparks sit on top of it
      pix.rect(Math.round(sx - 1), Math.round(sy - 1), 3, 3, [0, 0, 0, 0.5 * t]);
      if (!gore) pix.rect(Math.round(sx), Math.round(sy), 1, 1, [1, 1, 1, t]);
      for (let i = 0; i < 7; i++) {
        const a = this._r() * Math.PI * 2;
        const d = (1 - t) * 9 + this._r() * 3;
        // biased along the normal: debris comes back off a wall, not into it
        const px2 = sx + Math.cos(a) * d + im.n[0] * d * 0.6;
        const py2 = sy + Math.sin(a) * d - im.n[1] * d * 0.6;
        pix.rect(Math.round(px2), Math.round(py2), 1, 1,
          [col[0], col[1], col[2], t * (0.4 + this._r() * 0.5)]);
      }
    }
  }

  /**
   * Ammunition counter, on its own plate beside the viewmodel. Rounds in the
   * magazine, magazines left in the hold, and a row of pips — the pips are what
   * you read mid-fight, the numbers are what you read between them.
   */
  _ammoTag(pix, font, W, H) {
    const { C } = this;
    const s = this.spec;
    // Magazines LEFT counts every load that fits this weapon, not just the plain
    // one — with three slug types in the hold, a count of the standard boxes
    // alone would read as empty while you were still carrying forty rounds.
    // Capped at 99 so the row can never outgrow the plate.
    const mags = Math.min(99, (LOADS[s.ammo] ?? []).reduce((n2, l) => n2 + this.inv.count(l.id), 0));
    const L = this.chambered;
    const cap = Math.max(1, Math.round(s.mag * L.mag));
    const low = this.rounds <= Math.max(1, Math.round(cap * 0.25));
    const x = W - 78, y = H - 96;
    // plate
    pix.rect(x, y, 62, 22, [C.dark[0], C.dark[1], C.dark[2], 0.85]);
    pix.rect(x, y, 62, 1, [C.steelHi[0], C.steelHi[1], C.steelHi[2], 0.8]);
    pix.rect(x, y + 21, 62, 1, [0, 0, 0, 0.8]);
    const col = this.reloadT > 0 ? C.amberHi : low ? C.alert : C.amber;
    pix.text(font, FONT_FACES.AMBER9, x + 4, y + 3, s.name, [col[0], col[1], col[2], 1]);
    // Two-glyph load tag, inline. AMBER9 advances 7px per glyph and the plate has
    // 58px of usable width, so `AP 20/12` at 8 glyphs is the widest this can get.
    const line = this.reloadT > 0 ? '-- RELOAD'
      : L.tag ? `${L.tag} ${this.rounds}/${mags}` : `${this.rounds} / ${mags}`;
    pix.text(font, FONT_FACES.AMBER9, x + 4, y + 12, line, [col[0], col[1], col[2], 1]);
    // magazine pips, capped so a 44-cell cutter does not draw off the plate
    const n = Math.min(22, cap);
    const step = Math.floor(56 / n) || 1;
    for (let i = 0; i < n; i++) {
      const lit = i < Math.round((this.rounds / cap) * n);
      pix.rect(x + 4 + i * step, y + 19, Math.max(1, step - 1), 2,
        lit ? [col[0], col[1], col[2], 1] : [0, 0, 0, 0.7]);
    }
  }
}

/**
 * Surface normal at a point on a box, taken as the axis the point is closest to
 * a face on. `rayAabb` only returns a distance, and knowing which face was hit
 * is what lets debris come back OFF a wall instead of spraying through it.
 */
function boxNormal(box, p) {
  if (!box) return [0, 1, 0];
  const { min, max } = box;
  const cand = [
    [Math.abs(p[0] - min[0]), [-1, 0, 0]], [Math.abs(p[0] - max[0]), [1, 0, 0]],
    [Math.abs(p[1] - min[1]), [0, -1, 0]], [Math.abs(p[1] - max[1]), [0, 1, 0]],
    [Math.abs(p[2] - min[2]), [0, 0, -1]], [Math.abs(p[2] - max[2]), [0, 0, 1]],
  ];
  let bd = Infinity, n = [0, 1, 0];
  for (const [d, v] of cand) if (d < bd) { bd = d; n = v; }
  return n;
}

/**
 * Which hull section a point inside the ship belongs to. The interior runs fore
 * to aft along -z (`context/03` deck plan), so the split is: the forward and aft
 * thirds by z, otherwise the flank the point is on, and dorsal/ventral for
 * anything well off the deck plane.
 */
function sectionAt(p) {
  if (p[1] > 2.6) return 'dorsal';
  if (p[1] < 0.35) return 'ventral';
  if (p[2] < -18) return 'fore';
  if (p[2] > 14) return 'aft';
  return p[0] < 0 ? 'port' : 'stbd';
}
