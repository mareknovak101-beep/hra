/**
 * SpaceCombat — ship-to-ship combat (Phase 6, context/03 §5): the Aethon's
 * laser cannon, hostile patrols in faction space (Keth fighters in Vega Reach,
 * Drift drones in Twin Suns and the Pale), their bolts, and the explosions
 * they end in. Owns simulation only; SpaceRenderer draws from its state.
 *
 * AI is deliberately simple and readable at 480×270: patrol near an anchor →
 * aggro when the player closes → bore in, jink on a timer, fire in range →
 * die into salvage. No spawn-camping: kills stay dead until the system is
 * re-entered.
 */
import { Vec3 } from '../utils/MathUtils.js';
import { WEAPONS, WEAPON_ORDER, Loadout } from './Weapons.js';
import { RNG } from '../utils/RNG.js';
import { ShipSystems } from '../ship/ShipSystems.js';
import { factionOf } from '../gameplay/FactionSystem.js';

const AGGRO = 7000; // u — patrols notice the Aethon inside this
const FIRE_RANGE = 2200;
// -- target lock ------------------------------------------------------------
// Two cones, deliberately far apart: acquisition demands you point at the
// target, retention lets you manoeuvre hard without dropping it.
// LOCK envelope, widened and quickened (0.20). A 21-degree cone held for 1.1s was
// a stricter test than the ship could pass: the target jinks, the hull carries
// angular momentum, and the crosshair is drawn on a 480x270 grid, so the lock kept
// dropping a tenth of a second before it took. The cone is now ~31 degrees, it
// acquires in two thirds of the time, and it survives twice as long outside the
// cone — the lock should reward pointing at something, not perfect tracking.
const LOCK_RANGE = 5200;
const LOCK_ACQUIRE_COS = 0.86; // ~31 deg half-angle to START a lock
const LOCK_RETAIN_COS = 0.25;  // ~76 deg half-angle to KEEP one
const LOCK_TIME = 0.7;         // seconds of steady tracking to acquire
const LOCK_GRACE = 2.6;        // seconds outside the cone before it drops

/**
 * GUNNERY ASSIST — the cone in front of the hull inside which the guns solve
 * their own firing problem.
 *
 * The rule, stated once: a shot is corrected onto a target only if that target
 * is IN FRONT of the ship and within `AIM_CONE_DEG` of the boresight. Outside
 * the cone the guns fire exactly where they point and always have. That gate is
 * what keeps this an assist rather than an aimbot — you still have to fly the
 * nose onto the target, and the assist only removes the part that is arithmetic
 * (how far to lead a crossing target at this range and this muzzle velocity),
 * which a gunnery computer in this fiction would obviously do and a pilot
 * cannot do in their head.
 *
 * 9 degrees is deliberately tighter than the 31-degree lock cone: a lock is a
 * declaration of intent that survives manoeuvring, whereas a firing solution
 * has to be something you can lose by drifting off, or it is not aiming.
 */
const AIM_CONE_DEG = 9;
const AIM_CONE_COS = Math.cos((AIM_CONE_DEG * Math.PI) / 180);
const AIM_RANGE = 4200;        // beyond this the lead error exceeds the benefit

const BOLT_SPEED = 2600;
const BOLT_TTL = 2.4;
const PLAYER_FIRE_CD = 0.18; // laser default; per-weapon cooldowns live in Weapons.js
const PLAYER_BOLT_DMG = 34;
// 16 was the raw number, and with HULL_ARMOR now dividing it the effective figure
// is ~4% of a section per round — a fighter needs a sustained burst to open a
// flank instead of six lucky pokes. Kept at 12 rather than raised, because the
// deflector still eats it first and the interesting failure is the shield going
// down, not any single round.
const ENEMY_BOLT_DMG = 12;
const CAP_COST = 7; // weapons-capacitor % per shot

/**
 * What patrols where. Redfall stays neutral (reputation lands later), and so do
 * Odessa Chain and Amber Well — a system needs somewhere safe to trade from, and
 * the spurs would be pointless if every one of them shot at you on arrival.
 */
// Speeds cut ~35% across the board (0.20). At 320-360 u/s against a hull whose
// commanded turn rate is well under a radian a second, a fighter could sit on the
// Aethon's blind quarter indefinitely and there was no manoeuvre that shook it —
// the fight had no answer in it. Slower hostiles can be out-turned, which is what
// makes attitude control worth having.
/**
 * PER-TYPE BEHAVIOUR. The state machine in `_fly` is shared; this is what makes
 * a lancer feel unlike a picket inside it.
 *
 * Adding an enemy TYPE used to mean adding a branch. Now it is a row here plus
 * a row in HOSTILES, which is the difference between "we could add more
 * enemies" and actually doing it.
 *
 *   standoff  the range REGROUP and STANDOFF hold at
 *   runFor    how many seconds a firing pass lasts before breaking off
 *   slots     false = ignores squadron discipline and presses whenever it can.
 *             Reserved for things that are supposed to be frightening.
 *   agility   how fast the hull converges on its desired velocity
 *   evadeAt   hull fraction below which it starts breaking off to survive; 0
 *             means it never does, which is what a drone is
 *   burst     rounds per trigger pull, walked out over `burstGap` seconds
 *   reload    seconds between trigger pulls. It has to be a profile field rather
 *             than a constant because a type's FIRING WINDOW is set by `runFor`:
 *             an interceptor whose pass lasts 1.4s and whose reload is 3.5s only
 *             gets a shot away on some passes, which measured as four rounds in
 *             twenty-two seconds — a hostile that flies past without shooting.
 */
const PROFILES = {
  keth:           { standoff: 2600, runFor: [2.2, 3.4], slots: true,  agility: 1.35, evadeAt: 0.35, burst: 1, burstGap: 0,    reload: [2.0, 3.4] },
  drift:          { standoff: 2200, runFor: [3.0, 4.6], slots: true,  agility: 0.95, evadeAt: 0.0,  burst: 1, burstGap: 0,    reload: [2.0, 3.4] },
  keth_corvette:  { standoff: 2200, runFor: [0, 0],     slots: false, agility: 0.55, evadeAt: 0.35, burst: 4, burstGap: 0.11, reload: [5.0, 7.2] },
  // INTERCEPTOR: small, very fast, ignores the slot queue. It is the type that
  // punishes you for treating the squadron rhythm as a guarantee. Short passes,
  // so it reloads fast enough to actually use one.
  keth_lancer:    { standoff: 3200, runFor: [1.4, 2.1], slots: false, agility: 1.9,  evadeAt: 0.5,  burst: 2, burstGap: 0.16, reload: [1.5, 2.3] },
  // PICKET: never closes. Sits far out and shoots, so it cannot be ignored and
  // cannot be dogfought — you have to go and get it.
  drift_picket:   { standoff: 3400, runFor: [0, 0],     slots: false, agility: 0.6,  evadeAt: 0.0,  burst: 3, burstGap: 0.22, reload: [3.6, 5.0] },
  // LANCE: a heavy drone that commits and does not break off. Slow, tough, and
  // the only fighter-sized thing that will follow you through a hard turn.
  drift_lance:    { standoff: 1600, runFor: [5.0, 7.0], slots: true,  agility: 0.8,  evadeAt: 0.0,  burst: 1, burstGap: 0,    reload: [2.4, 3.6] },
};

/** Profile for a type, defaulting to the plain fighter. */
function profileFor(type) { return PROFILES[type] ?? PROFILES.keth; }

/**
 * What the comms say when a patrol drops out of loiter and comes for you. The
 * wording is the only warning you get about which behaviour is about to be
 * pointed at you, so each line names the thing it does, not just the hull.
 */
const ENGAGE = {
  keth: 'KETH FIGHTER LOCKING ON',
  keth_corvette: 'KETH CORVETTE — WEAPONS FREE',
  keth_lancer: 'KETH LANCER — CLOSING FAST',
  drift: 'DRIFT DRONE CONVERGING',
  drift_picket: 'DRIFT PICKET HOLDING RANGE — FIRING',
  drift_lance: 'DRIFT LANCE COMMITTED — IT WILL NOT BREAK',
};

/**
 * What a hull is called once it stops being a threat and starts being a place.
 * Named per type rather than "DERELICT" because the whole point of boarding one
 * is that you know exactly whose ship you are walking into.
 */
const CRIPPLED_NAME = {
  keth: 'KETH FIGHTER, CRIPPLED',
  keth_lancer: 'KETH LANCER, CRIPPLED',
  keth_corvette: 'KETH CORVETTE, CRIPPLED',
  drift: 'DRIFT DRONE, DEAD IN SPACE',
  drift_picket: 'DRIFT PICKET, DEAD IN SPACE',
  drift_lance: 'DRIFT LANCE, DEAD IN SPACE',
};

const HOSTILES = {
  vega_reach: { type: 'keth', count: 3, hp: 70, speed: 205, scale: 1.0 },
  twin_suns: { type: 'drift', count: 3, hp: 55, speed: 170, scale: 1.0 },
  the_pale: { type: 'drift', count: 5, hp: 70, speed: 195, scale: 1.15 },
  // the Keth forward yard: fewer hulls than the Pale but the hardest of them,
  // and the only place a corvette is stationed. `escort` spawns alongside the
  // main patrol, so Thresher is four fighters AND a line warship.
  thresher: { type: 'keth', count: 4, hp: 95, speed: 235, scale: 1.2,
    escort: { type: 'keth_corvette', count: 1, hp: 480, speed: 95, scale: 1.0, shield: 220 } },
  // a breaking yard, so: many drones, none of them fast — they were not built
  // to chase anything, they were built to take things apart at leisure
  cold_harbour: { type: 'drift', count: 6, hp: 60, speed: 140, scale: 1.0 },
  the_drum: { type: 'drift', count: 4, hp: 85, speed: 215, scale: 1.3 },
  // Redfall was neutral because reputation had not landed. It has now, and an
  // empty system on the commissioned route is a hole in the pacing — so it gets
  // the picket line: nothing that will chase you, everything that will shoot.
  redfall: { type: 'drift_picket', count: 3, hp: 90, speed: 120, scale: 1.1 },
  // Amber Well: a lancer flight. Fast, few, and they do not queue.
  amber_well: { type: 'keth_lancer', count: 3, hp: 52, speed: 300, scale: 0.8 },
  // Odessa Chain: heavy drones that commit. The counterpart to Redfall — these
  // will follow you anywhere, they just cannot catch you if you keep moving.
  odessa_chain: { type: 'drift_lance', count: 3, hp: 145, speed: 165, scale: 1.45 },
};

const SALVAGE_DROPS = {
  keth: ['fsalvage_keth_plate', 'fsalvage_keth_cell', 'salvage_plating_scrap'],
  // a warship's wreck yields its heavier fittings, not fighter offcuts
  keth_corvette: ['fsalvage_keth_cell', 'salvage_mag_coil', 'fsalvage_keth_plate'],
  // an interceptor is mostly engine, and the one part worth cutting out of it is
  // the thrust vane that let it turn like that
  keth_lancer: ['fsalvage_keth_vane', 'fsalvage_keth_cell', 'fsalvage_keth_plate'],
  drift: ['fsalvage_drift_lattice', 'fsalvage_drift_eye', 'salvage_mag_coil'],
  // a gun platform is built around its emitter; a lance around the mass it rams
  drift_picket: ['fsalvage_drift_emitter', 'fsalvage_drift_eye', 'salvage_mag_coil'],
  drift_lance: ['fsalvage_drift_emitter', 'fsalvage_drift_lattice', 'salvage_plating_scrap'],
};

export class SpaceCombat {
  /**
   * @param {object} hooks { notify(text), reward(itemId), shake(strength),
   *   playLaser(), playBoom(), playHit(), playShieldHit(), playShieldDown() }
   */
  constructor(hooks) {
    this.hooks = hooks;
    /** @type {Array<object>} live hostiles */
    this.enemies = [];
    /** @type {Array<{pos:number[],vel:number[],ttl:number,hostile:boolean}>} */
    this.bolts = [];
    /** @type {Array<{pos:number[],vel:number[],ttl:number}>} explosion sparks */
    this.sparks = [];
    /** light blooms at impact points: {pos, t (1..0), blue} */
    this.flashes = [];
    /** lingering battle smoke: {pos, vel, ttl} */
    this.smoke = [];
    /** Persistent hull wounds in ship-local space: {local, section, t, severity}. */
    this.breaches = [];
    /** Delayed pockets from a ship break-up: {pos, vel, delay, scale}. */
    this.secondaries = [];
    /**
     * Target lock. Homing weapons used to grab whatever `_nearestEnemy` returned
     * at the instant of firing, which means the pilot had no say in what a
     * torpedo chased and no way to tell what it was about to chase. A lock is the
     * missing feedback loop: you choose, you wait for it, you see it, and it can
     * be broken.
     */
    this.lock = {
      target: null,   // the enemy being tracked
      progress: 0,    // 0..1 acquisition, reaches 1 = locked
      locked: false,
      lostT: 0,       // seconds the target has been out of the retention cone
    };
    this._fireCd = 0;
    /** Magazines and the selected hardpoint — see combat/Weapons.js. */
    this.loadout = new Loadout();
    this._rng = new RNG(0xc0b7a7);
    /**
     * Optional `(factionId) => -100..100` standing probe, injected by main.js
     * from FactionSystem. Reputation decides whether a patrol even engages:
     * without it every hull is hostile on sight (the pre-0.8.9 behaviour).
     */
    this.standingOf = null;
  }

  /**
   * How a patrol of `type` currently regards the player.
   * @returns {{tolerant:boolean, aggro:number}} tolerant = won't fire first;
   *   aggro = detection radius, wider the more they hate you.
   */
  disposition(type) {
    // The standing is held per FACTION, not per hull, so a corvette or a picket
    // has to be resolved to its family first — asking for `keth_corvette`
    // returned 0, which reads as neutral, which made warships hold fire.
    const s = this.standingOf?.(factionOf(type) ?? type);
    if (s == null) return { tolerant: false, aggro: AGGRO };
    if (s >= 30) return { tolerant: true, aggro: AGGRO * 0.5 }; // friendly: they let you pass
    if (s >= 0) return { tolerant: true, aggro: AGGRO * 0.7 }; // neutral: wary, but no first shot
    if (s <= -60) return { tolerant: false, aggro: AGGRO * 1.4 }; // blood feud: hunted on sight
    return { tolerant: false, aggro: AGGRO };
  }

  /** Rebuild the patrol roster for a newly entered system. */
  setSystem(systemDef) {
    this.enemies.length = 0;
    this.bolts.length = 0;
    this.sparks.length = 0;
    const spec = HOSTILES[systemDef.id];
    if (!spec) return;
    // patrols anchor around the system's arrival lane so encounters happen
    const base = systemDef.shipStart.pos;
    for (let i = 0; i < spec.count; i++) {
      const ang = this._rng.range(0, Math.PI * 2);
      const d = this._rng.range(3200, 5600);
      this.enemies.push(this._makeHostile(spec, base, ang, d));
    }
    // capital escorts, if this system stations any
    const esc = spec.escort;
    if (esc) {
      for (let i = 0; i < esc.count; i++) {
        const ang = this._rng.range(0, Math.PI * 2);
        const d = this._rng.range(4200, 6200); // stands off further than the screen
        this.enemies.push(this._makeHostile(esc, base, ang, d));
      }
    }
  }

  /**
   * One hostile record. Split out of setSystem so escorts and patrols cannot
   * drift apart in what fields they carry — a partially-populated enemy throws
   * inside update() and aborts the whole tick, which is a silent and very
   * confusing failure (it cost a harness debug cycle in 16v).
   */
  _makeHostile(spec, base, ang, d) {
    const pos = [base[0] + Math.cos(ang) * d, base[1] + this._rng.range(-500, 500),
      base[2] + Math.sin(ang) * d];
    return {
      type: spec.type, hp: spec.hp, hpMax: spec.hp, speed: spec.speed, scale: spec.scale,
      pos, vel: [0, 0, 0],
      anchor: [base[0] + Math.cos(ang) * d, base[1], base[2] + Math.sin(ang) * d],
      yaw: this._rng.range(0, Math.PI * 2),
      state: 'patrol', fireCd: this._rng.range(0.5, 2), jinkT: 0, jink: [0, 0, 0],
      // A corvette carries its own deflector. Damage eats the shield first and it
      // regenerates between passes, so it cannot be chipped down by a PDC the way
      // a fighter can — you have to commit real ordnance to it.
      shield: spec.shield ?? 0, shieldMax: spec.shield ?? 0, shieldHold: 0,
      salvo: 0, salvoT: 0,
    };
  }

  /**
   * Player pulls the trigger (held). Everything about the shot — rate, cost,
   * ammunition, velocity, guidance, warhead — comes from the selected weapon's
   * spec, so adding a hardpoint is a table entry and not a branch in here.
   */
  /**
   * The firing solution, or null when there is nothing to solve for.
   *
   * TWO GATES, and both must pass:
   *   1. the target is IN FRONT of the hull, within `AIM_CONE_DEG` of the
   *      boresight — the rule the whole assist hangs on;
   *   2. it is inside `AIM_RANGE`, past which the lead error from the target's
   *      unknown future manoeuvring is larger than the correction is worth.
   *
   * With both satisfied the aim vector is the INTERCEPT point, not the target's
   * current position: a bolt takes real time to arrive and a crossing target is
   * somewhere else when it does. Solved by two iterations of "how long to reach
   * where I currently think it will be" — the fixed point converges fast because
   * muzzle velocity is an order of magnitude above closing speed, and two passes
   * are indistinguishable from twenty at these numbers.
   *
   * A LOCKED target wins ties, provided it is inside the cone. Otherwise the
   * candidate closest to the boresight does — the one you are most obviously
   * pointing at is the one you meant.
   *
   * Homing weapons are excluded: they steer themselves, and pre-leading a
   * missile only makes it turn the wrong way first.
   *
   * @returns {{dir:number[], target:object, lead:number[]}|null}
   */
  aimSolution(ship, muzzle, fwd, w) {
    if (!w || w.guidance === 'homing' || w.guidance === 'intercept') return null;
    let best = null, bestCos = AIM_CONE_COS;
    for (const e of this.enemies) {
      if (e.hp <= 0) continue;
      const dx = e.pos[0] - muzzle[0], dy = e.pos[1] - muzzle[1], dz = e.pos[2] - muzzle[2];
      const dist = Math.hypot(dx, dy, dz);
      if (dist > AIM_RANGE || dist < 1) continue;
      const cos = (fwd[0] * dx + fwd[1] * dy + fwd[2] * dz) / dist;
      if (cos < AIM_CONE_COS) continue;           // outside the cone: no solution
      // the lock wins if it qualifies at all, otherwise the tightest angle wins
      const locked = this.lock.locked && this.lock.target === e;
      if (locked) { best = e; bestCos = 2; break; }
      if (cos > bestCos) { bestCos = cos; best = e; }
    }
    if (!best) return null;
    // Intercept. Relative velocity, because a bolt inherits the ship's own
    // motion (see the spawn below) — what matters is closing, not ground speed.
    const rvx = (best.vel?.[0] ?? 0) - ship.vel[0];
    const rvy = (best.vel?.[1] ?? 0) - ship.vel[1];
    const rvz = (best.vel?.[2] ?? 0) - ship.vel[2];
    const lead = [best.pos[0], best.pos[1], best.pos[2]];
    for (let i = 0; i < 2; i++) {
      const t = Math.hypot(lead[0] - muzzle[0], lead[1] - muzzle[1], lead[2] - muzzle[2])
        / Math.max(1, w.speed);
      lead[0] = best.pos[0] + rvx * t;
      lead[1] = best.pos[1] + rvy * t;
      lead[2] = best.pos[2] + rvz * t;
    }
    const dir = [lead[0] - muzzle[0], lead[1] - muzzle[1], lead[2] - muzzle[2]];
    const dl = Math.hypot(dir[0], dir[1], dir[2]) || 1;
    dir[0] /= dl; dir[1] /= dl; dir[2] /= dl;
    return { dir, target: best, lead };
  }

  /**
   * Is there a solution RIGHT NOW, for the HUD to draw a converged reticle
   * from? Pure query, no side effects — the trigger path calls `aimSolution`
   * itself rather than trusting a cached answer, because a frame of staleness
   * on a firing solution is a frame of shots going somewhere else.
   */
  aimStatus(ship) {
    const w = this.loadout.current;
    const fwd = [0, 0, -1];
    ship.dirToWorld ? ship.dirToWorld(fwd, fwd) : quatRot(fwd, ship.quat, [0, 0, -1]);
    const muzzle = [ship.pos[0] + fwd[0] * 18, ship.pos[1] + fwd[1] * 18, ship.pos[2] + fwd[2] * 18];
    return this.aimSolution(ship, muzzle, fwd, w);
  }

  tryFire(ship, systems, dt) {
    this._fireCd -= dt;
    if (this._fireCd > 0) return;
    const w = this.loadout.current;

    // Out of rounds: swap rather than click uselessly. A dead trigger in a fight
    // reads as a bug, and the laser can always fire, so there is always a
    // fallback to land on.
    if (this.loadout.rounds() <= 0) {
      const next = this.loadout.cycleToLoaded();
      this.hooks.notify?.(`${w.name} DRY — ${next.name} SELECTED`);
      this._fireCd = 0.25;
      return;
    }
    if (systems.weapons < w.cap) {
      this._fireCd = 0.2;
      this.hooks.notify?.('CAPACITOR LOW');
      return;
    }
    /**
     * AMMUNITION ECONOMY. A practised gunner wastes fewer rounds — modelled as
     * a chance the shot simply does not draw one, which is the cheapest honest
     * version and never leaves the magazine reading wrong.
     */
    const free = Math.random() < (this.hooks.ammoSaved?.() ?? 0);
    if (!free && !this.loadout.consume(1)) return;

    this._fireCd = w.cooldown;
    systems.weapons -= w.cap;

    const fwd = [0, 0, -1];
    ship.dirToWorld ? ship.dirToWorld(fwd, fwd) : quatRot(fwd, ship.quat, [0, 0, -1]);
    // a basis to spread multi-shot weapons across
    const up = [0, 1, 0];
    const rt = [
      fwd[1] * up[2] - fwd[2] * up[1],
      fwd[2] * up[0] - fwd[0] * up[2],
      fwd[0] * up[1] - fwd[1] * up[0],
    ];
    const rl = Math.hypot(rt[0], rt[1], rt[2]) || 1;
    rt[0] /= rl; rt[1] /= rl; rt[2] /= rl;
    const uu = [
      rt[1] * fwd[2] - rt[2] * fwd[1],
      rt[2] * fwd[0] - rt[0] * fwd[2],
      rt[0] * fwd[1] - rt[1] * fwd[0],
    ];

    const muzzle = [ship.pos[0] + fwd[0] * 18, ship.pos[1] + fwd[1] * 18, ship.pos[2] + fwd[2] * 18];
    // GUNNERY ASSIST. Replaces the boresight with a lead-corrected aim vector
    // when — and only when — something is inside the cone. `fwd` is reused
    // below for the spread basis, so the correction has to land before the
    // per-shot loop, not inside it: every pellet of a shotgun spread must come
    // off the SAME solution or the pattern walks off the target.
    const aim = this.aimSolution(ship, muzzle, fwd, w);
    if (aim) { fwd[0] = aim.dir[0]; fwd[1] = aim.dir[1]; fwd[2] = aim.dir[2]; }
    // point defence locks a hostile round; everything else locks a ship
    // A locked target beats a guessed one. Falling back to `_nearestEnemy` keeps
    // unguided snap shots working when nothing is locked, but with a lock the
    // pilot decides what the torpedo chases — which is the point of having one.
    const target = w.guidance === 'intercept' ? this._nearestHostileBolt(muzzle)
      : w.guidance === 'homing'
        ? (this.lock.locked && this.lock.target?.hp > 0 ? this.lock.target : this._nearestEnemy(muzzle, fwd))
        : null;

    for (let k = 0; k < w.shots; k++) {
      const a = w.shots > 1 ? (this._rng.next() - 0.5) * w.spread * 2 : 0;
      const b2 = w.shots > 1 ? (this._rng.next() - 0.5) * w.spread * 2 : 0;
      const d = [
        fwd[0] + rt[0] * a + uu[0] * b2,
        fwd[1] + rt[1] * a + uu[1] * b2,
        fwd[2] + rt[2] * a + uu[2] * b2,
      ];
      const dl = Math.hypot(d[0], d[1], d[2]) || 1;
      d[0] /= dl; d[1] /= dl; d[2] /= dl;
      this.bolts.push({
        pos: [...muzzle],
        vel: [ship.vel[0] + d[0] * w.speed, ship.vel[1] + d[1] * w.speed, ship.vel[2] + d[2] * w.speed],
        dir: d, ttl: w.ttl, hostile: false, spec: w, target,
        // missiles trail smoke; slugs and beams do not
        trail: w.guidance === 'homing' ? 0 : -1,
        // Position history for the tracer streak. A round crossing 900-2600
        // units a second moves further between frames than its own length, so
        // drawn as a single point it is a dot that teleports; drawn as its last
        // few positions it is a streak, which is what a tracer actually looks
        // like and the single biggest readability win in a firefight.
        hist: [], histT: 0,
      });
    }

    this.hooks.playLaser?.();
    // muzzle flash, sized to the weapon — a PDC tick and a warhead launch should
    // not look the same at the emitter
    // Muzzle signature in three layers rather than one puff of fixed dots: a
    // white-hot flash cone thrown FORWARD along the bore, a slower ring of
    // burning propellant washing back around the emitter, and — for anything
    // that fires a physical slug — a tumbling case ejected to one side.
    const rngM = this._rng;
    const mf = Math.max(1, Math.round(w.fx.flash * 3));
    for (let k = 0; k < mf * 2; k++) {
      const sp = 150 + rngM.next() * 260 * w.fx.flash;
      this._ejecta(muzzle, [
        ship.vel[0] + fwd[0] * sp + rngM.range(-40, 40),
        ship.vel[1] + fwd[1] * sp + rngM.range(-40, 40),
        ship.vel[2] + fwd[2] * sp + rngM.range(-40, 40),
      ], 0.05 + rngM.next() * 0.05, [1, 0.97, 0.88], w.fx.sparkCol,
      Math.max(2, w.tracerSize), 1, 4.0);
    }
    for (let k = 0; k < mf; k++) {
      this._ejecta(muzzle, [
        ship.vel[0] + rngM.range(-45, 45),
        ship.vel[1] + rngM.range(-45, 45),
        ship.vel[2] + rngM.range(-45, 45),
      ], 0.12 + rngM.next() * 0.1, w.fx.sparkCol, [0.2, 0.07, 0.03],
      Math.max(1, w.tracerSize - 1), 1, 2.2);
    }
    if (w.ammoMax && w.guidance === 'straight') {
      this._ejecta(muzzle, [
        ship.vel[0] + rt[0] * 90 + rngM.range(-20, 20),
        ship.vel[1] + rt[1] * 90 - 30,
        ship.vel[2] + rt[2] * 90 + rngM.range(-20, 20),
      ], 1.4, [0.7, 0.6, 0.42], [0.2, 0.17, 0.13], 2, 1, 0.25);
    }
    if (w.fx.shake > 1) this.hooks.shake?.(w.fx.shake * 0.4);
  }

  /**
   * Warhead detonation: area damage with distance falloff, plus the weapon's own
   * hit signature. `skip` is the target already dealt direct damage, so a rocket
   * that connects does not also splash its victim at full strength.
   *
   * `selfHarm` is on the nuke alone, and it is not a formality — the splash
   * check runs against the Aethon, so launching one inside its own 340-unit
   * radius will take your own hull off. That is the cost of carrying it.
   */
  _detonate(b, ship, systems, skip = null) {
    const w = b.spec;
    if (!w || w.splash <= 0) return;
    for (const e of this.enemies) {
      if (e.hp <= 0 || e === skip) continue;
      const d = Vec3.distance(b.pos, e.pos);
      if (d > w.splash) continue;
      const fall = 1 - d / w.splash; // linear falloff from the centre
      this._hurtEnemy(e, w.splashDamage * fall);
      if (w.disable > 0) e.disabled = Math.max(e.disabled ?? 0, w.disable * fall);
      if (e.hp <= 0) this._downEnemy(e);
    }
    if (w.fx.selfHarm && systems) {
      const d = Vec3.distance(b.pos, ship.pos);
      if (d < w.splash) {
        const fall = 1 - d / w.splash;
        const dmg = w.splashDamage * fall * 0.75;
        // Same damage path as an enemy round: your own warhead is not a special
        // case, and it should be able to open a section too.
        const res = systems.applyHit(dmg, this._sectionOf(b.pos, ship));
        this.hooks.notify?.('OWN BLAST — TOO CLOSE');
        this.hooks.shake?.(6);
        this._impactFx(b.pos, ship, res, systems);
      }
    }
    this._hitFx(b.pos, w);
  }

  /**
   * Which hull section an impact landed on, from the impact point in SHIP-LOCAL
   * space. Dominant axis wins: -z fore, +z aft, ±x flanks, ±y spine/keel.
   *
   * The Aethon is long and thin, so a raw dominant-axis test would call almost
   * everything fore or aft. The z component is therefore scaled down before the
   * comparison, which widens the flanks to roughly the angular share they
   * actually occupy on the hull.
   */
  _sectionOf(worldPos, ship) {
    const l = [0, 0, 0];
    if (ship.toLocal) ship.toLocal(l, worldPos);
    else { l[0] = worldPos[0] - ship.pos[0]; l[1] = worldPos[1] - ship.pos[1]; l[2] = worldPos[2] - ship.pos[2]; }
    const ax = Math.abs(l[0]), ay = Math.abs(l[1]), az = Math.abs(l[2]) * 0.42;
    if (az >= ax && az >= ay) return l[2] < 0 ? 'fore' : 'aft';
    if (ax >= ay) return l[0] < 0 ? 'port' : 'stbd';
    return l[1] > 0 ? 'dorsal' : 'ventral';
  }

  /**
   * The player-facing consequence of a hit, branched on what the damage model
   * actually did. Four distinct events, because they mean four different things
   * and looking the same is how the old single explosion hid the mechanic:
   *
   *  - deflected      — blue shimmer ring, no lasting mark
   *  - shield collapse — a bigger discharge and a named warning
   *  - hull damage    — orange ejecta, debris, smoke, and a PERSISTENT breach
   *                     recorded on the section so the damage stays visible
   *  - destroyed      — hand off to the death path
   */
  _impactFx(pos, ship, res, systems) {
    const rng = this._rng;
    // Where the round struck, in SHIP-LOCAL space. The renderer needs this to put
    // the deflector ripple and the hull scorch on the right part of the ship — a
    // hit on the port flank has to light up the port flank.
    const loc = [0, 0, 0];
    if (ship?.toLocal) ship.toLocal(loc, pos);
    else if (ship?.pos) {
      loc[0] = pos[0] - ship.pos[0]; loc[1] = pos[1] - ship.pos[1]; loc[2] = pos[2] - ship.pos[2];
    }
    if (res.shieldAbsorbed > 0 && res.hullDamage <= 0) {
      this.hooks.shake?.(1);
      this.hooks.notify?.(`SHIELD IMPACT — ${Math.round(systems.shield)}%`);
      // ripple scale rides the size of the round: a PDC tick is not a torpedo
      this.hooks.shieldFx?.(loc, Math.min(2.2, 0.7 + res.shieldAbsorbed / 22));
      this.flashes.push({ pos: [...pos], t: 1, blue: true, scale: 0.8 });
      // two counter-rotating shimmer rings plus a scatter of fast motes: the
      // deflector should read as a surface being struck, not a puff at a point
      for (const [n, sp, life] of [[14, 130, 0.32], [10, 210, 0.2]]) {
        for (let k = 0; k < n; k++) {
          const th = (k / n) * Math.PI * 2;
          this._ejecta(pos, [Math.cos(th) * sp, rng.range(-40, 40), Math.sin(th) * sp],
            life, [0.72, 0.88, 1], [0.14, 0.24, 0.5], 2, 1, 1.8);
        }
      }
    }
    if (res.collapsed) {
      this.hooks.notify?.('DEFLECTOR COLLAPSE — HULL EXPOSED');
      this.hooks.shake?.(4);
      this.flashes.push({ pos: [...pos], t: 1, blue: true, scale: 2.2 });
      // The field tearing open is not one big ripple, it is the lattice failing
      // in several places at once: seed the strike plus a ring of sympathetic
      // discharges around it, so the collapse visibly runs across the bubble.
      this.hooks.shieldFx?.(loc, 2.6);
      for (let k = 0; k < 5; k++) {
        const th = rng.range(0, Math.PI * 2), sp = rng.range(0.5, 1.1);
        this.hooks.shieldFx?.([
          loc[0] + Math.cos(th) * sp * 40, loc[1] + Math.sin(th) * sp * 30,
          loc[2] + rng.range(-40, 40),
        ], rng.range(0.9, 1.7));
      }
      for (let k = 0; k < 34; k++) {
        const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
        const sp = 200 + rng.next() * 380;
        this._ejecta(pos, [Math.cos(th) * sp, ph * sp * 0.7, Math.sin(th) * sp],
          rng.range(0.3, 0.8), [0.9, 0.96, 1], [0.1, 0.16, 0.4], 3, 1, 1.4);
      }
    }
    if (res.hullDamage > 0) {
      const label = ShipSystems.SECTION_LABEL[res.section] ?? res.section.toUpperCase();
      this.hooks.shake?.(res.breached ? 6 : 2.5);
      this.hooks.hullFx?.();
      this.hooks.notify?.(res.breached
        ? `${label} BREACHED — ${Math.round(systems.sections[res.section])}%`
        : `HULL IMPACT ${label} — ${Math.round(systems.sections[res.section])}%`);
      this.flashes.push({ pos: [...pos], t: 1, blue: false, scale: 1.4 });
      for (let k = 0; k < 16; k++) {
        const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
        const sp = 140 + rng.next() * 260;
        this._ejecta(pos, [Math.cos(th) * sp, ph * sp * 0.6, Math.sin(th) * sp],
          rng.range(0.3, 0.9), [1, 0.82, 0.4], [0.3, 0.06, 0.02], 2, 1, 1.2);
      }
      this._debris(pos, ship.vel ?? [0, 0, 0], 8, 110, rng);
      for (let sm = 0; sm < 4; sm++) {
        this.smoke.push({ pos: [...pos], ttl: 1.6 + rng.next(),
          vel: [rng.range(-20, 20), rng.range(-14, 14), rng.range(-20, 20)] });
      }
      // Record the wound in SHIP-LOCAL space so it can keep venting from the
      // same spot on the hull as the ship manoeuvres. This is what makes damage
      // *visible* on the part that took it rather than a number going down.
      const local = [0, 0, 0];
      if (ship.toLocal) ship.toLocal(local, pos);
      this.breaches.push({ local, section: res.section, t: 0,
        severity: res.breached ? 1 : 0.5, emitT: 0 });
      if (this.breaches.length > 10) this.breaches.shift();
    }
  }

  /**
   * The visual signature of a hit, scaled off the weapon's own `fx` block. A
   * PDC tick, a railgun slug and a fission warhead all land here and come out
   * looking like three different events, which is the point of giving each
   * weapon its own numbers rather than one shared explosion.
   */
  _hitFx(pos, w) {
    const f = w.fx;
    const rng = this._rng;
    this.flashes.push({ pos: [...pos], t: 1, blue: !!f.emp, scale: f.flash });

    // LAYER 1 — the incandescent core. A handful of very short, very bright,
    // very fast particles right at the point of contact. They are gone in under
    // a tenth of a second, which is exactly what makes the hit read as an
    // instantaneous release rather than a puff that fades in.
    const core = f.emp ? [0.82, 0.92, 1] : [1, 0.98, 0.92];
    for (let k = 0; k < 4 + Math.round(f.flash * 4); k++) {
      const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
      const sp = (420 + rng.next() * 520) * f.flash;
      this._ejecta(pos, [Math.cos(th) * sp, ph * sp * 0.7, Math.sin(th) * sp],
        rng.range(0.05, 0.11), core, f.sparkCol,
        Math.max(2, Math.round(f.flash * 2)), 1, 3.5);
    }

    // LAYER 2 — the spark shower, cooling from the weapon's own colour down to a
    // dull ember as it slows.
    for (let k = 0; k < f.sparks; k++) {
      const sp = 120 + rng.next() * 240 * f.flash;
      const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
      this._ejecta(pos, [Math.cos(th) * sp, ph * sp * 0.6, Math.sin(th) * sp],
        rng.range(0.25, 0.35 + f.flash * 0.3), f.sparkCol,
        [f.sparkCol[0] * 0.35, f.sparkCol[1] * 0.14, f.sparkCol[2] * 0.08],
        Math.max(1, Math.round(f.flash)), 1, 1.1);
    }

    // LAYER 3 — solid fragments. Skipped for the EMP, which has no kinetic
    // component at all: it should look like a discharge, not an explosion.
    if (!f.emp) this._debris(pos, [0, 0, 0], Math.round(3 + f.flash * 5), 90 * f.flash, rng);

    // LAYER 4 — a few long-lived embers that keep glowing after everything else
    // is out, so the impact site stays alive for a second instead of snapping
    // back to empty space.
    for (let k = 0; k < Math.round(2 + f.flash * 3); k++) {
      const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
      const sp = 30 + rng.next() * 70;
      this._ejecta(pos, [Math.cos(th) * sp, ph * sp * 0.5, Math.sin(th) * sp],
        rng.range(0.8, 1.9), [1, 0.55, 0.18], [0.28, 0.05, 0.02], 1, 1, 0.6);
    }
    for (let k = 0; k < f.smoke; k++) {
      this.smoke.push({ pos: [...pos], ttl: 1.2 + this._rng.next() * f.flash * 0.6,
        vel: [this._rng.range(-30, 30), this._rng.range(-22, 22), this._rng.range(-30, 30)] });
    }
    // expanding shock rings: concentric shells of sparks thrown on the flat, so a
    // big warhead reads as a blast wave rather than a bigger puff
    for (let r = 0; r < f.ring; r++) {
      const n = 14 + r * 6, spd = 220 + r * 170;
      for (let k = 0; k < n; k++) {
        const th = (k / n) * Math.PI * 2;
        this.sparks.push({
          pos: [...pos], ttl: 0.35 + r * 0.12, col: f.sparkCol, size: 1,
          vel: [Math.cos(th) * spd, this._rng.range(-30, 30), Math.sin(th) * spd],
        });
      }
    }
    this.hooks.playBoom?.();
    if (f.shake) this.hooks.shake?.(f.shake);
  }

  /** Cycle hardpoints. Returns the newly selected spec for the notification. */
  cycleWeapon(dir = 1) {
    const w = this.loadout.cycle(dir);
    const n = this.loadout.rounds();
    this.hooks.notify?.(`${w.name} — ${w.kind.toUpperCase()}`
      + (n === Infinity ? ' — CAPACITOR' : ` — ${n} RDS`));
    return w;
  }

  /** Nearest enemy inside a forward cone, for missile lock. */
  _nearestEnemy(from, fwd) {
    let best = null, bestD = Infinity;
    for (const e of this.enemies) {
      if (e.hp <= 0) continue;
      const dx = e.pos[0] - from[0], dy = e.pos[1] - from[1], dz = e.pos[2] - from[2];
      const d = Math.hypot(dx, dy, dz);
      if (d < 1 || d > 4200) continue;
      // must be roughly ahead — a missile does not lock something behind you
      if ((dx * fwd[0] + dy * fwd[1] + dz * fwd[2]) / d < 0.25) continue;
      if (d < bestD) { bestD = d; best = e; }
    }
    return best;
  }

  /**
   * Acquisition and retention, once per fixed step.
   *
   * Two different cones on purpose: ACQUIRE is narrow (you must point at it) and
   * RETAIN is much wider (a lock survives a hard break). One cone for both would
   * either make locking trivial or make it impossible to manoeuvre while locked.
   *
   * A lost target keeps its lock for LOCK_GRACE seconds before dropping, so a
   * target crossing behind a manoeuvre does not need re-acquiring every time.
   */
  _updateLock(dt, ship, fwd) {
    const L = this.lock;
    if (L.target && L.target.hp <= 0) { this._clearLock('TARGET DESTROYED'); return; }
    // AUTO-ACQUIRE. The lock used to require an explicit LOCK/T press before it
    // would even begin, so the whole mechanism was invisible unless you already
    // knew it existed — and in a fight the one thing you do not have is a spare
    // hand. Pointing at a hostile now starts the acquisition by itself; LOCK
    // still cycles between candidates when several are in the cone.
    if (!L.target) {
      const cand = this._bestLockCandidate(ship, fwd);
      if (cand) { L.target = cand; L.progress = 0; L.lostT = 0; }
      else { L.progress = Math.max(0, L.progress - dt * 1.5); return; }
    }
    const t = L.target;

    const dx = t.pos[0] - ship.pos[0], dy = t.pos[1] - ship.pos[1], dz = t.pos[2] - ship.pos[2];
    const d = Math.hypot(dx, dy, dz) || 1;
    const cos = (dx * fwd[0] + dy * fwd[1] + dz * fwd[2]) / d;
    const inRange = d < LOCK_RANGE;
    const held = inRange && cos > LOCK_RETAIN_COS;

    if (held) {
      L.lostT = 0;
      // acquisition only advances inside the tighter cone; retention alone holds
      // an existing lock but will not build a new one
      if (cos > LOCK_ACQUIRE_COS || L.locked) {
        L.progress = Math.min(1, L.progress + dt / LOCK_TIME);
        if (L.progress >= 1 && !L.locked) {
          L.locked = true;
          this.hooks.notify?.(`LOCK — ${t.type === 'keth' ? 'KETH' : 'DRIFT'} AT ${Math.round(d)} u`);
          this.hooks.playLock?.();
        }
      } else {
        L.progress = Math.max(0, L.progress - dt * 0.5);
      }
    } else {
      L.lostT += dt;
      if (L.lostT > LOCK_GRACE) this._clearLock(inRange ? 'LOCK BROKEN' : 'TARGET OUT OF RANGE');
      else if (!L.locked) L.progress = Math.max(0, L.progress - dt * 1.2);
    }
  }

  _clearLock(reason) {
    if (this.lock.target && reason) this.hooks.notify?.(reason);
    this.lock.target = null;
    this.lock.progress = 0;
    this.lock.locked = false;
    this.lock.lostT = 0;
  }

  /**
   * Player asked to lock (T / the LOCK button). Cycles: if something is already
   * locked, tapping again steps to the next valid candidate rather than
   * re-locking the same hull — that is what makes it usable in a crowd.
   */
  /**
   * Every live hostile inside the acquisition cone, nearest first. Shared by
   * cycleLock and by the automatic acquisition in _updateLock, so the two can
   * never disagree about what counts as lockable.
   */
  _lockCandidates(ship, fwd) {
    const cands = [];
    for (const e of this.enemies) {
      if (e.hp <= 0) continue;
      const dx = e.pos[0] - ship.pos[0], dy = e.pos[1] - ship.pos[1], dz = e.pos[2] - ship.pos[2];
      const d = Math.hypot(dx, dy, dz) || 1;
      if (d > LOCK_RANGE) continue;
      const cos = (dx * fwd[0] + dy * fwd[1] + dz * fwd[2]) / d;
      if (cos < LOCK_ACQUIRE_COS) continue;
      cands.push({ e, d, cos });
    }
    cands.sort((a, b) => a.d - b.d);
    return cands;
  }

  /**
   * The one to lock on to if nothing is locked yet: whichever candidate sits
   * CLOSEST TO THE CROSSHAIR, not merely nearest. With several fighters in the
   * arc, nearest-first would keep snapping to whichever happened to be closest
   * while you were aiming at a different one.
   */
  _bestLockCandidate(ship, fwd) {
    const cands = this._lockCandidates(ship, fwd);
    if (!cands.length) return null;
    let best = cands[0];
    for (const c of cands) if (c.cos > best.cos) best = c;
    return best.e;
  }

  cycleLock(ship, fwd) {
    const cands = this._lockCandidates(ship, fwd);
    if (!cands.length) {
      this._clearLock(null);
      this.hooks.notify?.('NO TARGET IN ARC');
      return;
    }
    const at = cands.findIndex((c) => c.e === this.lock.target);
    const next = cands[(at + 1) % cands.length].e; // -1 wraps to 0, which is what we want
    this.lock.target = next;
    this.lock.progress = 0;
    this.lock.locked = false;
    this.lock.lostT = 0;
    this.hooks.notify?.('ACQUIRING…');
  }

  /**
   * One hostile round, led onto the target. `spreadA`/`spreadB` jitter the aim so
   * a salvo walks across the target instead of stacking four rounds on one point.
   */
  _hostileShot(e, ship, spreadA = 0, spreadB = 0) {
    const dist = Vec3.distance(ship.pos, e.pos) || 1;
    const t = dist / BOLT_SPEED;
    let tx = ship.pos[0] + ship.vel[0] * t - e.pos[0];
    let ty = ship.pos[1] + ship.vel[1] * t - e.pos[1];
    let tz = ship.pos[2] + ship.vel[2] * t - e.pos[2];
    const tl = Math.hypot(tx, ty, tz) || 1;
    tx /= tl; ty /= tl; tz /= tl;
    if (spreadA) {
      // jitter in a plane roughly perpendicular to the shot
      const k = spreadA / 100;
      tx += this._rng.range(-k, k); ty += this._rng.range(-k, k) * 0.6; tz += this._rng.range(-k, k);
      const nl = Math.hypot(tx, ty, tz) || 1;
      tx /= nl; ty /= nl; tz /= nl;
    }
    // barrels are offset from the hull centre on a capital ship, so the rounds
    // visibly come from different places rather than all from one point
    const off = spreadB
      ? [this._rng.range(-spreadB, spreadB), this._rng.range(-spreadB, spreadB) * 0.7,
        this._rng.range(-spreadB, spreadB)]
      : [0, 0, 0];
    const muz = [e.pos[0] + off[0], e.pos[1] + off[1], e.pos[2] + off[2]];
    this.bolts.push({
      pos: [...muz],
      vel: [tx * BOLT_SPEED, ty * BOLT_SPEED, tz * BOLT_SPEED],
      ttl: BOLT_TTL, hostile: true, kind: e.type, hist: [], histT: 0,
    });
    // Enemy guns get a muzzle signature too. Without one, incoming fire simply
    // materialised in space and the only way to tell which of five hulls was
    // shooting at you was to trace the tracer back — on a capital ship with four
    // separate barbettes that matters.
    const cold = e.type === 'drift';
    this.flashes.push({ pos: [...muz], t: 0.7, blue: cold, scale: 0.55 * (e.scale ?? 1) });
    const hot = cold ? [0.88, 0.94, 1] : [1, 0.72, 0.5];
    const cool = cold ? [0.16, 0.24, 0.5] : [0.34, 0.06, 0.04];
    for (let k = 0; k < 5; k++) {
      const sp = 120 + this._rng.next() * 200;
      this._ejecta(muz, [
        (e.vel?.[0] ?? 0) + tx * sp + this._rng.range(-35, 35),
        (e.vel?.[1] ?? 0) + ty * sp + this._rng.range(-35, 35),
        (e.vel?.[2] ?? 0) + tz * sp + this._rng.range(-35, 35),
      ], 0.05 + this._rng.next() * 0.05, hot, cool, 2, 1, 4.0);
    }
  }

  /**
   * Stop the venting from a section that has just been patched. Without this a
   * repaired flank kept streaming atmosphere for the rest of the flight, which
   * made the repair look like it had not worked.
   * @param {string} [section] section key; omitted clears every breach
   */
  clearBreaches(section) {
    if (!section) { this.breaches.length = 0; return; }
    for (let i = this.breaches.length - 1; i >= 0; i--) {
      if (this.breaches[i].section === section) this.breaches.splice(i, 1);
    }
  }

  /**
   * Damage a hostile through its own deflector, if it has one. Returns the hull
   * damage that actually landed, so the caller can decide whether to kill it.
   */
  _hurtEnemy(e, dmg) {
    e.shieldHold = 3.0;
    if (e.shield > 0) {
      const absorbed = Math.min(e.shield, dmg);
      e.shield -= absorbed;
      dmg -= absorbed;
      if (dmg <= 0) return 0;
    }
    /**
     * MARKSMANSHIP, applied at the one place damage actually lands.
     *
     * Multiplied here rather than at the muzzle so it covers every weapon, the
     * point-defence turret and the collision case alike, and so the shield
     * absorption above sees the un-boosted figure — a better shot puts more
     * through the hull, not more into the screen.
     */
    e.hp -= dmg * (this.hooks.damageMult?.() ?? 1);
    return dmg;
  }

  /** Nearest INCOMING round, for point defence. */
  _nearestHostileBolt(from) {
    let best = null, bestD = Infinity;
    for (const b of this.bolts) {
      if (!b.hostile) continue;
      const d = Vec3.distance(b.pos, from);
      if (d < bestD && d < 2600) { bestD = d; best = b; }
    }
    return best;
  }

/**
   * THE ATTACK CYCLE.
   *
   * The old behaviour was one state: bore in, jink, hold 1400 units, shoot. The
   * owner's description of it — "they just circle around and shoot" — was
   * exactly right, and the reason is that a single behaviour has no PHASES. A
   * hostile was never visibly setting up, committing, or breaking off, so
   * nothing it did could be read a second before it happened, and a fight with
   * nothing to read is a fight with nothing to do but hold the trigger.
   *
   * Five states, and the point of each is that it looks different from outside:
   *
   *   APPROACH  close from long range on an OFFSET vector, not straight down
   *             the throat — aiming past your shoulder so the run starts from a
   *             flank. Does not fire. This is the phase you get to react to.
   *   RUN       the firing pass. Nose on, shooting, closing hard through
   *             minimum range. Short and committed.
   *   EXTEND    after the pass: run OUT, presenting the tail, not turning to
   *             fight. This is the single biggest change — a ship that
   *             disengages and comes back is an attack run; a ship that never
   *             leaves is a carousel.
   *   REGROUP   out at distance, turning back, waiting for a slot.
   *   EVADE     hurt or shieldless: hard jinking away from the guns.
   *
   * SQUADRON DISCIPLINE. `_slots` caps how many may be in RUN at once (two).
   * Everyone else waits in REGROUP. That is what stops five hostiles converging
   * into one undifferentiated cloud, and it is why a fight now has a rhythm —
   * pressure, gap, pressure — instead of constant uniform noise.
   *
   * A CORVETTE DOES NOT DO THIS. It is a warship, not a fighter: it holds
   * STANDOFF, keeps its distance, and fires salvos. Giving a capital hull the
   * same dogfight cycle is what made it read as a fighter with more hit points.
   */
  _fly(dt, e, ship, dx, dy, dz, dist) {
    const rng = this._rng;
    e.stateT = (e.stateT ?? 0) - dt;
    const P = profileFor(e.type);
    // `runFor[1] === 0` is the signal for a hull that never makes a pass: a
    // corvette or a picket holds station and shoots, and running the dogfight
    // cycle on it is what made a warship read as a big fighter.
    const holds = P.runFor[1] <= 0;
    const hurt = P.evadeAt > 0 && e.hp / Math.max(1, e.hpMax) < P.evadeAt;

    // -- transitions ---------------------------------------------------------
    if (holds) {
      e.state = hurt && e.shield <= 0 ? 'evade' : 'standoff';
    } else if (e.state === 'attack' || !e.state) {
      // legacy entry point (and save restores): everything starts by closing
      e.state = 'approach'; e.stateT = rng.range(2.5, 4.5);
      e.offset = [rng.range(-1, 1), rng.range(-0.5, 0.5), rng.range(-1, 1)];
    } else if (hurt && e.shield <= 0 && e.state !== 'evade' && rng.chance(dt * 1.4)) {
      e.state = 'evade'; e.stateT = rng.range(3.0, 5.0);
      this._releaseSlot(e);
    } else if (e.stateT <= 0) {
      switch (e.state) {
        case 'approach':
          // Commit only if the squadron has a firing slot free. Without a slot
          // the ship keeps closing but never presses, which reads as a hostile
          // waiting its turn — which is exactly what it is doing.
          // A profile with `slots: false` presses whenever it wants. That is
          // the whole character of an interceptor: the squadron rhythm the
          // other types create is not a rule it obeys.
          if (!P.slots || this._takeSlot(e)) { e.state = 'run'; e.stateT = rng.range(P.runFor[0], P.runFor[1]); }
          else e.stateT = rng.range(0.8, 1.6);
          break;
        case 'run':
          e.state = 'extend'; e.stateT = rng.range(2.6, 4.2);
          this._releaseSlot(e);
          break;
        case 'extend':
          e.state = 'regroup'; e.stateT = rng.range(1.6, 3.2);
          break;
        case 'evade':
          e.state = 'regroup'; e.stateT = rng.range(2.0, 3.5);
          break;
        default:
          e.state = 'approach'; e.stateT = rng.range(2.0, 3.6);
          e.offset = [rng.range(-1, 1), rng.range(-0.5, 0.5), rng.range(-1, 1)];
          break;
      }
    }

    // -- steering ------------------------------------------------------------
    // Every state is a DESIRED VELOCITY the hull accelerates toward, rather
    // than a force added to whatever it was already doing. That is what makes a
    // break-off actually break off instead of curving lazily back.
    const ux = dx / dist, uy = dy / dist, uz = dz / dist;
    const off = e.offset ?? (e.offset = [rng.range(-1, 1), rng.range(-0.5, 0.5), rng.range(-1, 1)]);
    let wx = 0, wy = 0, wz = 0, cap = e.speed;
    switch (e.state) {
      case 'approach': {
        // aim PAST the player by an offset that shrinks as the range closes, so
        // the path curves in rather than pointing at them the whole way
        const lat = Math.min(1, dist / 2600) * 900;
        wx = ux * e.speed + off[0] * lat * 0.6;
        wy = uy * e.speed + off[1] * lat * 0.6;
        wz = uz * e.speed + off[2] * lat * 0.6;
        break;
      }
      case 'run':
        // nose on and closing hard; a shallow weave so it is not a rail
        e.jinkT -= dt;
        if (e.jinkT <= 0) {
          e.jinkT = rng.range(0.9, 1.6);
          e.jink = [rng.range(-1, 1), rng.range(-0.35, 0.35), rng.range(-1, 1)];
        }
        wx = ux * e.speed + e.jink[0] * 90;
        wy = uy * e.speed + e.jink[1] * 90;
        wz = uz * e.speed + e.jink[2] * 90;
        cap = e.speed * 1.25;                       // the pass is the fast part
        break;
      case 'extend':
        // straight out, tail toward you, full power. No steering back.
        wx = -ux * e.speed; wy = -uy * e.speed; wz = -uz * e.speed;
        cap = e.speed * 1.3;
        break;
      case 'regroup': {
        // hold at regroup distance: close if too far, drift out if too near
        const want = P.standoff;
        const err = (dist - want) / want;
        wx = ux * e.speed * Math.max(-1, Math.min(1, err));
        wy = uy * e.speed * Math.max(-1, Math.min(1, err)) + off[1] * 40;
        wz = uz * e.speed * Math.max(-1, Math.min(1, err));
        cap = e.speed * 0.7;
        break;
      }
      case 'standoff': {
        // station-keeping: hold the range its guns like
        const want = P.standoff;
        const err = (dist - want) / want;
        wx = ux * e.speed * Math.max(-0.6, Math.min(0.6, err)) + off[2] * 30;
        wy = uy * e.speed * 0.2;
        wz = uz * e.speed * Math.max(-0.6, Math.min(0.6, err)) - off[0] * 30;
        cap = e.speed * 0.8;
        break;
      }
      case 'evade':
      default:
        e.jinkT -= dt;
        if (e.jinkT <= 0) {
          e.jinkT = rng.range(0.5, 1.0);
          e.jink = [rng.range(-1, 1), rng.range(-1, 1), rng.range(-1, 1)];
        }
        wx = -ux * e.speed * 0.9 + e.jink[0] * 150;
        wy = -uy * e.speed * 0.9 + e.jink[1] * 150;
        wz = -uz * e.speed * 0.9 + e.jink[2] * 150;
        cap = e.speed * 1.15;
        break;
    }
    // accelerate toward the desired velocity; the rate is the hull's agility
    const k = Math.min(1, dt * P.agility);
    e.vel[0] += (wx - e.vel[0]) * k;
    e.vel[1] += (wy - e.vel[1]) * k;
    e.vel[2] += (wz - e.vel[2]) * k;
    const sp = Math.hypot(e.vel[0], e.vel[1], e.vel[2]);
    if (sp > cap) { const f = cap / sp; e.vel[0] *= f; e.vel[1] *= f; e.vel[2] *= f; }
  }

  /**
   * Firing slots. Two hostiles may press an attack at once; the rest wait.
   * Held by object identity rather than by a counter so a ship that dies
   * mid-run cannot leak its slot and starve the squadron.
   */
  _takeSlot(e) {
    this._slots = (this._slots ?? []).filter((x) => x.hp > 0 && this.enemies.includes(x));
    if (this._slots.includes(e)) return true;
    if (this._slots.length >= 2) return false;
    this._slots.push(e);
    return true;
  }

  _releaseSlot(e) {
    if (this._slots) this._slots = this._slots.filter((x) => x !== e);
  }

  update(dt, ship, systems) {
    // -- target lock -----------------------------------------------------------
    // Runs first so the HUD and any shot fired this step see the same lock state.
    {
      const fwd = [0, 0, -1];
      if (ship.dirToWorld) ship.dirToWorld(fwd, [0, 0, -1]);
      else quatRot(fwd, ship.quat, [0, 0, -1]);
      this._updateLock(dt, ship, fwd);
      this._lockFwd = fwd; // reused by cycleLock() so main.js need not recompute it
    }

    // -- enemies ---------------------------------------------------------------
    for (const e of this.enemies) {
      /**
       * A HULL THAT IS STILL THERE AND NO LONGER A THREAT.
       *
       * A crippled ship has no drive, no guns and no opinion: it coasts on the
       * velocity it had when the lights went out, bleeding it off against
       * nothing in particular, and everything below this line — acquisition,
       * jinking, firing — is skipped. It stays in `enemies` because it still
       * has to be drawn, still has to be flown around, and can still be
       * finished off if you decide the boarding is not worth it.
       */
      if (e.crippled) {
        Vec3.scaleAndAdd(e.pos, e.pos, e.vel, dt);
        // Cold gas venting from a dozen holes, slowly. Not a brake — a leak.
        const k = Math.max(0, 1 - 0.12 * dt);
        e.vel[0] *= k; e.vel[1] *= k; e.vel[2] *= k;
        e.yaw += (e.tumbleRate ?? 0.04) * dt;
        continue;
      }
      const dx = ship.pos[0] - e.pos[0], dy = ship.pos[1] - e.pos[1], dz = ship.pos[2] - e.pos[2];
      const dist = Math.hypot(dx, dy, dz) || 1;
      if (e.state === 'patrol') {
        // reputation decides the engagement: a faction you stand well with lets
        // you pass (they still shadow you), one with a blood feud hunts you from
        // further out. Provoked ships always come, whatever the standing.
        const disp = this.disposition(e.type);
        if (dist < disp.aggro && (!disp.tolerant || e.provoked)) {
          e.state = 'attack';
          this.hooks.notify?.(ENGAGE[e.type] ?? ENGAGE.keth);
        } else if (dist < disp.aggro && disp.tolerant && !e.hailed) {
          // one-time flyby hail so tolerated space still feels inhabited
          e.hailed = true;
          this.hooks.notify?.(factionOf(e.type) === 'keth'
            ? 'KETH PATROL HOLDS FORMATION — NO LOCK'
            : 'DRIFT HULL SWEEPS PAST — NO LOCK');
        }
        // lazy loiter around the anchor
        const ax = e.anchor[0] - e.pos[0], az = e.anchor[2] - e.pos[2];
        e.vel[0] += ax * 0.02 * dt; e.vel[2] += az * 0.02 * dt;
      } else {
        // an EMP'd hull cannot shoot and cannot steer — it coasts
        if ((e.disabled ?? 0) > 0) { e.disabled -= dt; e.pos[0] += e.vel[0] * dt; e.pos[1] += e.vel[1] * dt; e.pos[2] += e.vel[2] * dt; continue; }
        this._fly(dt, e, ship, dx, dy, dz, dist);
        // The firing pattern comes from the same profile the flying does, so a
        // hull's behaviour is described in ONE place. `holds` means a gun
        // platform — a hull with no run window, which stands off and shoots
        // rather than making passes; it fires further and its rounds hit harder.
        const P = profileFor(e.type);
        const holds = P.runFor[1] <= 0;
        e.fireCd -= dt;
        // A burst is a SALVO, not a shot: several rounds walking out of separate
        // barbettes over a fraction of a second. One bolt from a heavy hull
        // would read as a fighter with more hit points; a rippling salvo is what
        // makes it feel like being shot at by a warship, and the spacing is what
        // gives you time to break away between rounds.
        if (e.salvo > 0) {
          e.salvoT -= dt;
          if (e.salvoT <= 0) {
            e.salvo--;
            e.salvoT = P.burstGap;
            this._hostileShot(e, ship, holds ? 3.2 : 1.4, holds ? 1.9 : 1.0);
          }
        } else if (dist < FIRE_RANGE * (holds ? 1.6 : 1) && e.fireCd <= 0
          && (e.state === 'run' || e.state === 'standoff')) {
          // ONLY on a firing pass. Shooting from every state is what made the
          // old AI read as "circle and shoot": there was no moment where a
          // hostile was visibly setting up rather than already attacking, so
          // nothing it did could be anticipated.
          // Slower cadence than the pre-0.20 timer, which put a round in the air
          // every ~0.3s across five hostiles — not a duel, weather. The gap is
          // what gives you room to break off and re-attack.
          e.fireCd = this._rng.range(P.reload[0], P.reload[1]);
          if (P.burst > 1) {
            e.salvo = P.burst;
            e.salvoT = 0;
            if (e.type === 'keth_corvette') this.hooks.notify?.('CORVETTE FIRING SOLUTION — BREAK');
          } else {
            this._hostileShot(e, ship, 0, 0);
          }
        }
      }
      e.pos[0] += e.vel[0] * dt; e.pos[1] += e.vel[1] * dt; e.pos[2] += e.vel[2] * dt;
      e.yaw = Math.atan2(dx, -dz); // face the player (approximately)
      // engine plume: exhaust pixels shed behind the drive while it moves
      e.plumeT = (e.plumeT ?? 0) - dt;
      const spd2 = Math.hypot(e.vel[0], e.vel[1], e.vel[2]);
      if (e.plumeT <= 0 && spd2 > 40) {
        e.plumeT = 0.07;
        const inv = 1 / spd2;
        // Keth burn dirty chemical orange, Drift run cold electric blue. Match on
        // the family prefix so every variant hull inherits its faction's exhaust
        // instead of silently falling through to the Drift colour.
        const hot = e.type.startsWith('keth') ? [0.95, 0.35, 0.2] : [0.8, 0.88, 1];
        this.sparks.push({
          pos: [e.pos[0] - e.vel[0] * inv * 9, e.pos[1] - e.vel[1] * inv * 9, e.pos[2] - e.vel[2] * inv * 9],
          vel: [-e.vel[0] * 0.25, -e.vel[1] * 0.25, -e.vel[2] * 0.25],
          ttl: 0.4, col: hot, size: 1,
        });
      }
    }

    // -- bolts -----------------------------------------------------------------
    for (let i = this.bolts.length - 1; i >= 0; i--) {
      const b = this.bolts[i];
      b.ttl -= dt;
      const spec = b.spec;

      // -- guidance ------------------------------------------------------------
      // Steer the VELOCITY vector toward the target at a finite rate rather than
      // snapping to it. A missile that turns instantly is unavoidable and no fun;
      // a finite turn rate means a hard break can beat it, which is the whole
      // interaction.
      if (spec && spec.guidance !== 'straight' && b.target) {
        const t = b.target;
        const alive = t.hp === undefined ? this.bolts.includes(t) : t.hp > 0;
        if (!alive) b.target = null;
        else {
          const sp = Math.hypot(b.vel[0], b.vel[1], b.vel[2]) || 1;
          const to = [t.pos[0] - b.pos[0], t.pos[1] - b.pos[1], t.pos[2] - b.pos[2]];
          const tl = Math.hypot(to[0], to[1], to[2]) || 1;
          to[0] /= tl; to[1] /= tl; to[2] /= tl;
          const cur = [b.vel[0] / sp, b.vel[1] / sp, b.vel[2] / sp];
          const max = spec.turnRate * dt;
          // rotate `cur` toward `to` by at most `max` radians
          const dot = Math.max(-1, Math.min(1, cur[0] * to[0] + cur[1] * to[1] + cur[2] * to[2]));
          const ang = Math.acos(dot);
          const k = ang > 1e-4 ? Math.min(1, max / ang) : 1;
          const nx = cur[0] + (to[0] - cur[0]) * k;
          const ny = cur[1] + (to[1] - cur[1]) * k;
          const nz = cur[2] + (to[2] - cur[2]) * k;
          const nl = Math.hypot(nx, ny, nz) || 1;
          b.vel[0] = (nx / nl) * sp; b.vel[1] = (ny / nl) * sp; b.vel[2] = (nz / nl) * sp;
        }
      }

      b.pos[0] += b.vel[0] * dt; b.pos[1] += b.vel[1] * dt; b.pos[2] += b.vel[2] * dt;
      // Sample the flight path at a fixed rate rather than per frame, so a
      // tracer is the same physical length whatever the frame rate is doing.
      b.histT -= dt;
      if (b.histT <= 0) {
        b.histT = 0.012;
        b.hist.push(b.pos[0], b.pos[1], b.pos[2]);
        if (b.hist.length > 18) b.hist.splice(0, 3); // six samples ≈ 70ms of travel
      }

      // exhaust trail on anything that burns its way there
      if (b.trail >= 0) {
        b.trail -= dt;
        if (b.trail <= 0) {
          b.trail = 0.045;
          this.smoke.push({ pos: [...b.pos], ttl: 0.65,
            vel: [this._rng.range(-6, 6), this._rng.range(-6, 6), this._rng.range(-6, 6)] });
        }
      }

      let dead = b.ttl <= 0;
      // A timed round detonates when its clock runs out rather than fizzling —
      // that is what makes the EMP a burst weapon: it never has to hit anything.
      if (dead && spec && spec.splash > 0) this._detonate(b, ship, systems);
      if (!dead && b.hostile) {
        // hit the Aethon? (hull sphere ~14u)
        if (Vec3.distance(b.pos, ship.pos) < 16) {
          dead = true;
          // WHICH LAYER TOOK IT. A round stopped by the deflector and a round
          // into the plating were the same metallic knock until now, so the one
          // transition in a fight that has to be unmistakable — the moment the
          // shield stops being there — was audibly identical to the moment
          // before it.
          if (!systems.shieldDown && systems.shield > 0) this.hooks.playShieldHit?.();
          else this.hooks.playHit?.();
          // Route the hit through the damage model, which handles shield
          // overflow and picks a hull SECTION from where the round actually
          // struck. The old code branched on `shield > 0` and absorbed the whole
          // round if it was, which is why the hull never took anything.
          const sec = this._sectionOf(b.pos, ship);
          const res = systems.applyHit(ENEMY_BOLT_DMG, sec);
          if (res.collapsed) this.hooks.playShieldDown?.();
          this._impactFx(b.pos, ship, res, systems);
        }
      } else if (!dead && !b.hostile) {
        // Point defence hunts ROUNDS, not ships — check that first, because a
        // PDC slug passing near an enemy hull should not waste itself on it.
        if (spec && spec.guidance === 'intercept') {
          for (let j = this.bolts.length - 1; j >= 0; j--) {
            const o = this.bolts[j];
            if (!o.hostile || o === b) continue;
            if (Vec3.distance(b.pos, o.pos) < spec.hitR) {
              dead = true;
              this.bolts.splice(j, 1);
              if (j < i) i--;
              for (let k = 0; k < 5; k++) {
                this.sparks.push({ pos: [...b.pos], ttl: 0.22, col: [1, 0.9, 0.6], size: 1,
                  vel: [this._rng.range(-90, 90), this._rng.range(-90, 90), this._rng.range(-90, 90)] });
              }
              break;
            }
          }
        }
        for (const e of this.enemies) {
          if (dead) break;
          if (e.hp <= 0) continue;
          // generous hit sphere: aiming happens on a 480×270 pixel grid against
          // jinking targets — the lance is a lance, not a needle
          const reach = spec
            ? (spec.fuse === 'proximity' ? Math.max(spec.hitR, spec.fuseR) : spec.hitR) * e.scale
            : 30 * e.scale;
          if (Vec3.distance(b.pos, e.pos) < reach) {
            dead = true;
            this._hurtEnemy(e, spec ? spec.damage : PLAYER_BOLT_DMG);
            if (spec && spec.disable > 0) e.disabled = Math.max(e.disabled ?? 0, spec.disable);
            if (spec && spec.splash > 0) this._detonate(b, ship, systems, e);
            // firing first on a faction that was letting you pass is an act of
            // war: the whole patrol turns, and the diplomatic bill comes due
            if (!e.provoked) {
              e.provoked = true;
              if (this.disposition(e.type).tolerant) {
                this.hooks.notify?.('UNPROVOKED FIRE LOGGED — THEY WILL REMEMBER THIS');
                this.hooks.provoked?.(e.type);
                for (const o of this.enemies) if (o.type === e.type) o.provoked = true;
              }
            }
            if (e.hp <= 0) this._downEnemy(e);
            break;
          }
        }
      }
      if (dead) this.bolts.splice(i, 1);
    }
    this.enemies = this.enemies.filter((e) => e.hp > 0);

    // -- impact flashes + battle smoke -------------------------------------------
    for (let i = this.flashes.length - 1; i >= 0; i--) {
      this.flashes[i].t -= dt * 6; // ~0.17s bloom
      if (this.flashes[i].t <= 0) this.flashes.splice(i, 1);
    }
    for (let i = this.smoke.length - 1; i >= 0; i--) {
      const s = this.smoke[i];
      s.ttl -= dt;
      s.pos[0] += s.vel[0] * dt; s.pos[1] += s.vel[1] * dt; s.pos[2] += s.vel[2] * dt;
      if (s.ttl <= 0) this.smoke.splice(i, 1);
    }

    // -- hostile deflector regen ----------------------------------------------
    // Same hold-then-recharge shape as the Aethon's, for the same reason: a
    // shield that trickles up the instant it is hit can never actually be broken.
    for (const e of this.enemies) {
      if (!e.shieldMax) continue;
      e.shieldHold = Math.max(0, (e.shieldHold ?? 0) - dt);
      if (e.shieldHold <= 0 && e.shield < e.shieldMax) {
        e.shield = Math.min(e.shieldMax, e.shield + e.shieldMax * 0.06 * dt);
      }
    }

    // -- hull breaches: keep venting from where the ship was actually holed ----
    // Each wound is stored in SHIP-LOCAL space and converted back to world every
    // frame, so the plume stays welded to that spot on the hull however the ship
    // manoeuvres. Severity drives the rate, so a breached section smokes hard
    // and a scorch mark just wisps.
    if (ship && this.breaches.length) {
      for (const br of this.breaches) {
        br.t += dt;
        br.emitT -= dt;
        if (br.emitT > 0) continue;
        br.emitT = 0.05 + 0.09 * (1 - br.severity);
        const w = [0, 0, 0];
        if (ship.dirToWorld) ship.dirToWorld(w, br.local);
        else { w[0] = br.local[0]; w[1] = br.local[1]; w[2] = br.local[2]; }
        const p2 = [ship.pos[0] + w[0], ship.pos[1] + w[1], ship.pos[2] + w[2]];
        // venting atmosphere: a fast pale jet along the local surface normal
        const nl = Math.hypot(w[0], w[1], w[2]) || 1;
        const jet = 60 + 90 * br.severity;
        this._ejecta(p2, [
          ship.vel[0] + (w[0] / nl) * jet + this._rng.range(-18, 18),
          ship.vel[1] + (w[1] / nl) * jet + this._rng.range(-18, 18),
          ship.vel[2] + (w[2] / nl) * jet + this._rng.range(-18, 18),
        ], 0.5 + this._rng.next() * 0.5, [0.86, 0.9, 0.95], [0.2, 0.22, 0.26],
        2, 1, 1.1);
        if (br.severity > 0.75 && this._rng.chance(0.5)) {
          // fire in a properly breached section
          this._ejecta(p2, [
            ship.vel[0] + this._rng.range(-30, 30),
            ship.vel[1] + this._rng.range(-30, 30),
            ship.vel[2] + this._rng.range(-30, 30),
          ], 0.35 + this._rng.next() * 0.4, [1, 0.66, 0.22], [0.3, 0.05, 0.02], 2, 1, 1.6);
          this.smoke.push({ pos: [...p2], ttl: 1.2,
            vel: [ship.vel[0] * 0.4, ship.vel[1] * 0.4, ship.vel[2] * 0.4] });
        }
      }
    }

    // -- delayed secondary detonations from a break-up -------------------------
    for (let i = this.secondaries.length - 1; i >= 0; i--) {
      const sc = this.secondaries[i];
      sc.delay -= dt;
      sc.pos[0] += sc.vel[0] * dt; sc.pos[1] += sc.vel[1] * dt; sc.pos[2] += sc.vel[2] * dt;
      if (sc.delay > 0) continue;
      this.secondaries.splice(i, 1);
      this.flashes.push({ pos: [...sc.pos], t: 1, blue: false, scale: 1.4 });
      for (let k = 0; k < 12; k++) {
        const th = this._rng.range(0, Math.PI * 2), ph = this._rng.range(-1, 1);
        const sp = 150 + this._rng.next() * 260;
        this._ejecta(sc.pos, [
          sc.vel[0] + Math.cos(th) * sp, sc.vel[1] + ph * sp * 0.7, sc.vel[2] + Math.sin(th) * sp,
        ], this._rng.range(0.2, 0.6), [1, 0.9, 0.6], [0.3, 0.05, 0.02], 2, 1, 2.0);
      }
      this._debris(sc.pos, sc.vel, 4, 90, this._rng);
    }

    // -- explosion sparks -------------------------------------------------------
    for (let i = this.sparks.length - 1; i >= 0; i--) {
      const s = this.sparks[i];
      s.ttl -= dt;
      s.pos[0] += s.vel[0] * dt; s.pos[1] += s.vel[1] * dt; s.pos[2] += s.vel[2] * dt;
      // Ejecta slows as it spreads. Without drag every spark flies off in a
      // perfectly straight line at constant speed, which is what made the old
      // bursts read as a starburst decal rather than as thrown material.
      if (s.drag) {
        const k = Math.max(0, 1 - s.drag * dt);
        s.vel[0] *= k; s.vel[1] *= k; s.vel[2] *= k;
      }
      if (s.ttl <= 0) this.sparks.splice(i, 1);
    }
  }

  /**
   * Push one ejecta particle that COOLS AND SHRINKS over its life.
   *
   * This is the core of the multi-layer rework. A spark used to be a fixed
   * colour and a fixed size for its whole life and then vanish, which reads as a
   * sprite being switched off. Real ejecta starts white-hot, cools through
   * yellow and orange to a dull red, shrinks as it does, and slows as it goes —
   * so the same particle count now carries several times the information.
   *
   * `hot`/`cool` are the endpoint colours; the renderer interpolates on the
   * particle's remaining life fraction, so nothing here has to run per frame.
   */
  _ejecta(pos, vel, life, hot, cool, size0, size1, drag = 0) {
    this.sparks.push({
      pos: [...pos], vel, ttl: life, life,
      col: hot, colCool: cool, size: size0, size1, drag,
    });
  }

  /**
   * Solid fragments blown off a hull: slower than sparks, much longer-lived,
   * barely luminous, and they keep going after the fire has died.
   *
   * Sparks alone make every impact look like a firework. Debris is what tells
   * the eye that something SOLID broke — it is the layer that separates a hit on
   * metal from a hit on a shield.
   */
  _debris(pos, baseVel, count, spread, rng) {
    for (let k = 0; k < count; k++) {
      const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
      const sp = spread * (0.35 + rng.next() * 0.65);
      this._ejecta(pos, [
        baseVel[0] + Math.cos(th) * sp,
        baseVel[1] + ph * sp * 0.7,
        baseVel[2] + Math.sin(th) * sp,
      ], rng.range(0.9, 2.1), [0.62, 0.58, 0.55], [0.16, 0.15, 0.15],
      rng.chance(0.3) ? 2 : 1, 1, 0.35);
    }
  }

  /**
   * THE MEASURED KILL — the reason to stop shooting.
   *
   * A hull taken to zero does not always come apart. If the blow that finished
   * it did not massively overshoot, the ship goes dark and adrift instead: no
   * drive, no guns, atmosphere venting, and a crew still inside it. That hull
   * can be crossed to in a suit and gone through compartment by compartment,
   * which is worth several times what the debris field is worth.
   *
   * OVERKILL IS THE WHOLE MECHANIC, and it is a skill rather than a dice roll.
   * Finish a fighter with a measured burst and there is something left to board;
   * put a torpedo into it and there is not. That makes the weapon you choose
   * for the last shot a real decision, and it gives the PDC a use it never had.
   *
   * Capital hulls are excluded: a corvette breaking up is a set piece, and one
   * drifting intact next to you would be a boarding action against forty
   * people, which is a different game.
   */
  _shouldCripple(e, overkill) {
    if (e.crippled) return false;
    if (e.type === 'keth_corvette') return false;
    // Nothing survives being hit for more than a third of its own hull again
    // after it was already dead.
    return overkill < e.hpMax * 0.34;
  }

  /** Take the fight out of a hull without taking the hull out of the sky. */
  _cripple(e) {
    e.crippled = true;
    e.hp = 1;              // > 0, so the sweep at the end of update keeps it
    e.state = 'derelict';
    e.shield = 0;
    e.dark = true;         // the renderer drops its running lights and glow
    e.tumbleRate = this._rng.range(-0.09, 0.09);
    // A boardable record needs a stable identity — the boarding roll, the loot
    // seed and the "already stripped" set are all keyed off it.
    e.id = e.id ?? `crippled:${e.type}:${Math.round(e.anchor[0])}:${Math.round(e.anchor[2])}`;
    e.name = CRIPPLED_NAME[e.type] ?? 'CRIPPLED HULL';
    e.boardable = true;
    e.bodyR = 46 * (e.scale ?? 1);
    // Station-keeping range. A crippled fighter keeps the velocity it had when
    // the lights went out — a couple of hundred units a second — so without a
    // hold on it the hull is three kilometres away by the time you have your
    // suit on. Measured: 453 m at the airlock, 3.3 km by the time the crossing
    // was over. See main.js holdCandidate.
    e.reach = 1400;
    e.faction = factionOf(e.type);
    this.hooks.shake?.(0.25);
    this.hooks.notify?.(`${e.name} — DRIVE DEAD, HULL ADRIFT. SOMETHING IS STILL MOVING INSIDE IT.`);
    this.hooks.crippled?.(e);
  }

  /**
   * A hull has reached zero. ONE place decides what that means, called from
   * both the direct-hit path and the splash path — the first cut had the test
   * inline at each and they drifted within the hour.
   */
  _downEnemy(e) {
    const overkill = Math.max(0, -e.hp);
    if (this._shouldCripple(e, overkill)) this._cripple(e);
    else this._kill(e);
  }

  _kill(e) {
    this.hooks.killed?.(e.type); // quest ledger counts the wreck
    // scale the break-up to the hull: a corvette coming apart should not look
    // like a fighter coming apart
    const BREAKUP = { keth_corvette: 2.6, drift_lance: 1.5, drift_picket: 1.3, keth_lancer: 0.8 };
    this.destroyShip(e.pos, e.vel ?? [0, 0, 0], BREAKUP[e.type] ?? 1);
    this.hooks.playBoom?.();
    this.hooks.shake?.(0.5);
    const drops = SALVAGE_DROPS[e.type] ?? SALVAGE_DROPS.keth;
    const drop = drops[this._rng.int(0, drops.length - 1)];
    const NAME = {
      keth: 'KETH FIGHTER DESTROYED',
      keth_corvette: 'KETH CORVETTE BREAKING UP',
      keth_lancer: 'KETH LANCER DESTROYED',
      drift: 'DRIFT DRONE SHATTERED',
      drift_picket: 'DRIFT PICKET SILENCED',
      drift_lance: 'DRIFT LANCE SHATTERED',
    };
    this.hooks.reward?.(drop, NAME[e.type] ?? 'HOSTILE DESTROYED');
  }

  /**
   * A ship coming apart. Used for enemy kills AND for the Aethon's own
   * destruction, because the same event should look the same whoever it happens
   * to — a player who watches an enemy break up learns what their own death
   * will look like.
   *
   * Six overlapping stages rather than one burst, on the principle that a
   * catastrophic failure is a SEQUENCE: containment lets go, the hull opens, the
   * fuel goes, then the wreck coasts away burning.
   *
   * @param {number[]} pos  @param {number[]} vel  @param {number} scale
   */
  destroyShip(pos, vel = [0, 0, 0], scale = 1) {
    const rng = this._rng;
    const V = vel;

    // 1. containment flash — a single hard white core, gone almost instantly
    this.flashes.push({ pos: [...pos], t: 1, blue: false, scale: 3.2 * scale });
    for (let i = 0; i < Math.round(10 * scale); i++) {
      const th = rng.range(0, Math.PI * 2), ph = rng.range(-1, 1);
      const sp = (500 + rng.next() * 700) * scale;
      this._ejecta(pos, [V[0] + Math.cos(th) * sp, V[1] + ph * sp, V[2] + Math.sin(th) * sp],
        rng.range(0.06, 0.13), [1, 1, 0.98], [1, 0.8, 0.4], 4, 2, 4.5);
    }

    // 2. three expanding shock shells at different speeds — one ring reads as a
    //    decal, three reads as a blast front moving through debris
    for (let r = 0; r < 3; r++) {
      const n = 20 + r * 10, sp = (240 + r * 200) * scale;
      for (let k = 0; k < n; k++) {
        const th = (k / n) * Math.PI * 2 + r * 0.4;
        const tilt = (r - 1) * 0.5;
        this._ejecta(pos, [
          V[0] + Math.cos(th) * sp, V[1] + tilt * sp * 0.5 + rng.range(-40, 40),
          V[2] + Math.sin(th) * sp,
        ], rng.range(0.35, 0.75) + r * 0.15, [1, 0.88, 0.55], [0.32, 0.05, 0.02],
        3, 1, 1.5);
      }
    }

    // 3. fuel deflagration — slow, fat, long-lived fire that lingers where the
    //    tanks were, after the fast stuff has already gone
    for (let i = 0; i < Math.round(26 * scale); i++) {
      const th = rng.range(0, Math.PI * 2), ph = Math.acos(rng.range(-1, 1));
      const sp = rng.range(30, 150) * scale;
      this._ejecta(pos, [
        V[0] + Math.sin(ph) * Math.cos(th) * sp,
        V[1] + Math.cos(ph) * sp,
        V[2] + Math.sin(ph) * Math.sin(th) * sp,
      ], rng.range(0.9, 2.2), [1, 0.6, 0.16], [0.26, 0.04, 0.02],
      rng.chance(0.35) ? 3 : 2, 1, 0.5);
    }

    // 4. structural debris — big, slow, cool, still tumbling long after
    this._debris(pos, V, Math.round(26 * scale), 170 * scale, rng);

    // 5. smoke cloud, expanding outward with the debris
    for (let sm = 0; sm < Math.round(9 * scale); sm++) {
      this.smoke.push({ pos: [...pos], ttl: 2.2 + rng.next() * 1.6,
        vel: [V[0] + rng.range(-46, 46), V[1] + rng.range(-32, 32), V[2] + rng.range(-46, 46)] });
    }

    // 6. secondary detonations — a few delayed pockets so the wreck keeps
    //    letting go for a second or two rather than being over in one frame
    for (let i = 0; i < Math.round(5 * scale); i++) {
      const off = [rng.range(-14, 14) * scale, rng.range(-10, 10) * scale, rng.range(-14, 14) * scale];
      this.secondaries.push({
        pos: [pos[0] + off[0], pos[1] + off[1], pos[2] + off[2]],
        vel: [...V], delay: rng.range(0.15, 1.5), scale: 0.3 * scale,
      });
    }
  }

  /** Anything hostile still alive and aggroed? (drives HUD contact colour) */
  get inCombat() {
    return this.enemies.some((e) => e.state === 'attack');
  }
}

/** Rotate v by quaternion q (fallback if ship lacks dirToWorld). */
function quatRot(out, q, v) {
  const [x, y, z, w] = q;
  const ux = 2 * (y * v[2] - z * v[1]);
  const uy = 2 * (z * v[0] - x * v[2]);
  const uz = 2 * (x * v[1] - y * v[0]);
  out[0] = v[0] + w * ux + (y * uz - z * uy);
  out[1] = v[1] + w * uy + (z * ux - x * uz);
  out[2] = v[2] + w * uz + (x * uy - y * ux);
  return out;
}
