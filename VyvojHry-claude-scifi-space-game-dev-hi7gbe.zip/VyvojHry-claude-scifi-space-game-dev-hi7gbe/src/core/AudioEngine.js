/**
 * AudioEngine — every sound synthesized at runtime through the Web Audio API
 * (context/06; pillar 4: no audio files). Philosophy: silence is an
 * instrument — the ambience is sparse layers over near-quiet, so a single
 * distant clank still means something.
 *
 * The context can only start after a user gesture; call resume() from the
 * boarding click.
 */
import { AUDIO } from './Constants.js';
import { Settings } from './Settings.js';

export class AudioEngine {
  /** @param {import('./EventBus.js').EventBus} events */
  constructor(events) {
    this.events = events;
    this.ctx = null;
    this.master = null;
    this.started = false;
    this._clankTimer = null;

    events.on('player:step', ({ surface, sprint, crouch }) => {
      this.playFootstep(surface, sprint, crouch);
    });
    events.on('door:toggle', () => this.playDoorHiss());
    events.on('player:flashlight', () => this.playSwitchClick());
    // Everything aboard a boarded hull is heard before it is seen — the deck is
    // unlit and the helmet lamp reaches nine metres. These are the warning.
    events.on('boarder:rouse', ({ kind }) => this.playBoarderRouse(kind));
    events.on('boarder:strike', ({ hit }) => { if (hit) this.playBoarderStrike(); });
    events.on('boarder:shot', () => this.playBoarderShot());
    events.on('weapon:hitBody', ({ killed }) => {
      if (killed) this.playBoarderDown(); else this.playBoarderHurt();
    });

    /**
     * EVERYTHING ELSE IS WIRED HERE RATHER THAN CALLED FROM THE SYSTEM THAT
     * CAUSED IT.
     *
     * Same argument as `Progression._listen`: every one of these events already
     * existed and was already being emitted for something else, so reading them
     * here means no other module had to learn that audio exists, and a sound
     * cannot be played twice because there is exactly one place that decides
     * what an event sounds like.
     */
    events.on('ship:docked', () => this.playDock());
    events.on('system:arrived', () => this.playWarpJump());
    events.on('landing:down', (d) => this.playTouchdown(!!d?.hard));
    events.on('fab:crafted', () => this.playCraft());
    events.on('fab:recycled', () => this.playCraft());
    events.on('fab:spoiled', () => this.playCraftSpoil());
    events.on('loot:searched', (d) => this.playPickup(!!d?.rare));
    events.on('station:galley', () => this.playPickup());
    events.on('station:water', () => this.playPickup());
    events.on('station:assayed', () => this.playCraft());
    events.on('station:treated', () => this.playConsume('med'));
    events.on('trade:sold', () => this.playCredits());
    events.on('trade:bought', () => this.playCredits());
    events.on('hack:solved', () => this.playCredits());
    events.on('quest:complete', () => this.playCredits());
    events.on('skill:level', () => this.playLevelUp());
    events.on('weapon:dryFire', () => this.playDryFire());
    // A hazard on a wreck or in an entry is the one place a klaxon belongs.
    events.on('boarding:hazard', () => this.playAlarm(true));
    events.on('landing:hazard', () => this.playAlarm(true));
    events.on('mine:hit', () => this.playAlarm(true));
    // Out of the lock, into nothing. The jet only exists while the suit does.
    events.on('eva:end', () => this.setSuitJet(0));
  }

  /** Create/resume the context. Safe to call repeatedly. */
  resume() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.master = this.ctx.createGain();
      this.master.gain.value = Settings.get('volume') ?? AUDIO.MASTER_GAIN;
      this.master.connect(this.ctx.destination);
      /**
       * TWO BUSES UNDER THE MASTER, and they are not a cosmetic split.
       *
       * The bed (reactor hum, HVAC, hull groans, the drive, the suit jet) is
       * continuous and is most of what makes the ship feel inhabited; the
       * one-shots are information. A player who wants the atmosphere loud and
       * the clatter quiet, or who is listening to something else and wants only
       * the cues, cannot express either with one slider — and turning the
       * master down far enough to live with the hum also hides the alarm.
       */
      this.amb = this.ctx.createGain();
      this.sfx = this.ctx.createGain();
      this.amb.connect(this.master);
      this.sfx.connect(this.master);
      const applyMix = () => {
        this.master.gain.value = Settings.get('volume');
        this.amb.gain.value = Settings.get('ambienceVolume') ?? 1;
        this.sfx.gain.value = Settings.get('sfxVolume') ?? 1;
      };
      applyMix();
      Settings.onChange((key) => {
        if (key === null || key === 'volume' || key === 'ambienceVolume' || key === 'sfxVolume') {
          if (this.master) applyMix();
        }
      });
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    if (!this.started) {
      this.started = true;
      this.playAmbientInterior();
    }
  }

  _noiseBuffer(seconds) {
    const rate = this.ctx.sampleRate;
    const buf = this.ctx.createBuffer(1, Math.max(1, Math.floor(rate * seconds)), rate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    return buf;
  }

  /**
   * One-shot filtered noise burst. `bed: true` routes it to the ambience bus
   * instead of the effects bus — used by anything continuous or atmospheric,
   * so the two sliders each control what a player would expect them to.
   */
  _burst({ dur, filterType = 'bandpass', freq, q = 1, gain = 0.5, attack = 0.002, when = 0, bed = false }) {
    const t0 = this.ctx.currentTime + when;
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(dur);
    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.value = freq;
    filter.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(gain, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    src.connect(filter).connect(g).connect(bed ? this.amb : this.sfx);
    src.start(t0);
    src.stop(t0 + dur + 0.05);
  }

  /** One-shot oscillator sweep. `bed` as above. */
  _tone({ type = 'sine', from, to, dur, gain = 0.3, attack = 0.005, when = 0, bed = false }) {
    const t0 = this.ctx.currentTime + when;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(from, t0);
    if (to && to !== from) osc.frequency.exponentialRampToValueAtTime(Math.max(1, to), t0 + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(gain, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    osc.connect(g).connect(bed ? this.amb : this.sfx);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  // -- ambience (context/06 §2) -------------------------------------------------

  playAmbientInterior() {
    if (!this.ctx) return;
    // layer 1: reactor hum — 48Hz sine, gain wobbled at 0.3Hz
    const hum = this.ctx.createOscillator();
    hum.type = 'sine';
    hum.frequency.value = AUDIO.REACTOR_HZ;
    const humGain = this.ctx.createGain();
    humGain.gain.value = 0.055;
    const humLfo = this.ctx.createOscillator();
    humLfo.frequency.value = AUDIO.REACTOR_MOD_HZ;
    const humLfoGain = this.ctx.createGain();
    humLfoGain.gain.value = 0.02;
    humLfo.connect(humLfoGain).connect(humGain.gain);
    hum.connect(humGain).connect(this.amb);
    hum.start(); humLfo.start();

    // layer 2: HVAC — looped low-passed noise, volume LFO at 0.5Hz
    const hvac = this.ctx.createBufferSource();
    hvac.buffer = this._noiseBuffer(2);
    hvac.loop = true;
    const hvacFilter = this.ctx.createBiquadFilter();
    hvacFilter.type = 'lowpass';
    hvacFilter.frequency.value = 320;
    const hvacGain = this.ctx.createGain();
    hvacGain.gain.value = 0.016;
    const hvacLfo = this.ctx.createOscillator();
    hvacLfo.frequency.value = AUDIO.HVAC_LFO_HZ;
    const hvacLfoGain = this.ctx.createGain();
    hvacLfoGain.gain.value = 0.006;
    hvacLfo.connect(hvacLfoGain).connect(hvacGain.gain);
    hvac.connect(hvacFilter).connect(hvacGain).connect(this.amb);
    hvac.start(); hvacLfo.start();

    // layer 3: random distant clank, 8–30s apart
    const scheduleClank = () => {
      const wait = AUDIO.CLANK_INTERVAL_MIN +
        Math.random() * (AUDIO.CLANK_INTERVAL_MAX - AUDIO.CLANK_INTERVAL_MIN);
      this._clankTimer = setTimeout(() => {
        this.playDistantClank();
        scheduleClank();
      }, wait * 1000);
    };
    scheduleClank();
  }

  playDistantClank() {
    if (!this.ctx) return;
    this._burst({ dur: 0.22, freq: 260 + Math.random() * 200, q: 6, gain: 0.05, bed: true });
    this._tone({ type: 'sine', from: 140 + Math.random() * 60, to: 90, dur: 0.3, gain: 0.02, bed: true });
  }

  // -- one-shots -----------------------------------------------------------------

  /** Noise burst ~50ms, band chosen by surface, pitch jitter ±15%. */
  playFootstep(surface, sprint = false, crouch = false) {
    if (!this.ctx) return;
    const jitter = 1 + (Math.random() * 2 - 1) * AUDIO.FOOTSTEP_PITCH_JITTER;
    const base = surface === 'grating'
      ? { freq: 700 * jitter, q: 1.6, gain: 0.09 }
      : { freq: 1300 * jitter, q: 2.2, gain: 0.07 };
    const gain = base.gain * (sprint ? 1.5 : 1) * (crouch ? 0.35 : 1);
    this._burst({ dur: AUDIO.FOOTSTEP_MS / 1000, filterType: 'bandpass', freq: base.freq, q: base.q, gain });
    if (surface === 'grating') {
      // faint metallic ring under grating steps
      this._tone({ type: 'triangle', from: 480 * jitter, to: 320, dur: 0.09, gain: gain * 0.25 });
    }
  }

  playDoorHiss() {
    if (!this.ctx) return;
    this._burst({ dur: 0.5, filterType: 'bandpass', freq: 2400, q: 0.9, gain: 0.06 });
    this._burst({ dur: 0.35, filterType: 'lowpass', freq: 300, gain: 0.05, when: 0.02 });
    this._tone({ type: 'sine', from: 90, to: 60, dur: 0.4, gain: 0.03, when: 0.35 }); // seat thunk
  }

  /** The save-terminal ritual sound — percussive burst + low relay thunk. */
  playSaveChunk() {
    if (!this.ctx) return;
    this._burst({ dur: 0.08, filterType: 'bandpass', freq: 900, q: 3, gain: 0.15 });
    this._tone({ type: 'sine', from: 70, to: 45, dur: 0.22, gain: 0.18, when: 0.06 });
    this._burst({ dur: 0.05, filterType: 'bandpass', freq: 1400, q: 4, gain: 0.07, when: 0.16 });
  }

  /** Refusal buzz for locked systems. */
  playDenyBuzz() {
    if (!this.ctx) return;
    this._tone({ type: 'square', from: 110, to: 100, dur: 0.16, gain: 0.05 });
  }

  /** The Aethon's laser: a short falling zap. */
  playLaser() {
    if (!this.ctx) return;
    this._tone({ type: 'sawtooth', from: 900, to: 220, dur: 0.09, gain: 0.035 });
  }

  /** Something died out there: a low thump with a falling tail. */
  playBoom() {
    if (!this.ctx) return;
    this._tone({ type: 'triangle', from: 140, to: 30, dur: 0.5, gain: 0.09 });
    this._tone({ type: 'square', from: 70, to: 24, dur: 0.65, gain: 0.05 });
  }

  /** A bolt against our hull/shield: sharp metallic knock. */
  playHitTaken() {
    if (!this.ctx) return;
    this._tone({ type: 'square', from: 320, to: 90, dur: 0.14, gain: 0.06 });
  }

  /**
   * Something aboard has noticed you. Three voices, and they are deliberately
   * in three different registers so you know WHAT has woken up before you can
   * see it — which on a dark deck is the only warning that is worth anything.
   *
   *   carrion  a rising shriek, band-passed and short
   *   keth     a clipped two-tone vox challenge through a helmet speaker
   *   drift    no voice at all: a servo spinning up, and that is worse
   */
  playBoarderRouse(kind) {
    if (!this.ctx) return;
    if (kind === 'carrion') {
      this._tone({ type: 'sawtooth', from: 420, to: 1350, dur: 0.34, gain: 0.075 });
      this._burst({ dur: 0.22, filterType: 'bandpass', freq: 2200, q: 3, gain: 0.05 });
    } else if (kind === 'keth') {
      this._burst({ dur: 0.09, filterType: 'bandpass', freq: 900, q: 6, gain: 0.09 });
      this._burst({ dur: 0.12, filterType: 'bandpass', freq: 640, q: 6, gain: 0.08, when: 0.14 });
    } else {
      this._tone({ type: 'square', from: 48, to: 190, dur: 0.9, gain: 0.06 });
      this._burst({ dur: 0.5, filterType: 'lowpass', freq: 380, gain: 0.045, when: 0.2 });
    }
  }

  /** A strike landing on your suit: a heavy, dull, close impact. */
  playBoarderStrike() {
    if (!this.ctx) return;
    this._burst({ dur: 0.08, filterType: 'lowpass', freq: 420, gain: 0.14 });
    this._tone({ type: 'triangle', from: 190, to: 60, dur: 0.22, gain: 0.1 });
  }

  /** A round going into a body — wet and short, nothing like a hit on plate. */
  playBoarderHurt() {
    if (!this.ctx) return;
    this._burst({ dur: 0.06, filterType: 'bandpass', freq: 620, q: 1.4, gain: 0.09 });
  }

  /** It goes down. A collapse, then the deck taking the weight. */
  playBoarderDown() {
    if (!this.ctx) return;
    this._tone({ type: 'sawtooth', from: 300, to: 40, dur: 0.4, gain: 0.07 });
    this._burst({ dur: 0.14, filterType: 'lowpass', freq: 240, gain: 0.11, when: 0.22 });
  }

  /** A Keth bolt going past, or into, you. */
  playBoarderShot() {
    if (!this.ctx) return;
    this._tone({ type: 'square', from: 1400, to: 380, dur: 0.07, gain: 0.05 });
  }

  playSwitchClick() {
    if (!this.ctx) return;
    this._burst({ dur: 0.03, filterType: 'highpass', freq: 2000, gain: 0.08 });
  }

  /** Very short filtered click per keypress (terminals, Phase 7 hacking UI). */
  playTerminalKeystroke() {
    if (!this.ctx) return;
    const jitter = 1 + (Math.random() * 2 - 1) * 0.1;
    this._burst({ dur: AUDIO.KEYSTROKE_MS / 1000, filterType: 'bandpass', freq: 1800 * jitter, q: 2, gain: 0.05 });
  }

  // -- flight (Phase 3) -----------------------------------------------------------

  /** Heavy harness clunk when taking / leaving the pilot seat. */
  playSeatLatch() {
    if (!this.ctx) return;
    this._burst({ dur: 0.06, filterType: 'bandpass', freq: 500, q: 2.5, gain: 0.12 });
    this._tone({ type: 'sine', from: 90, to: 55, dur: 0.18, gain: 0.12, when: 0.05 });
  }

  // -- context/06 §3: the four named sounds this file never had ------------------

  /**
   * The proximity scanner's own blip. 1200 Hz, short, soft either end.
   *
   * `hollow` is the whole point of the function. `context/04` gives the scanner
   * one job near the Hollow — to stop being trustworthy — and until now that
   * was a visual-only lie (static on the sweep). A ping that drops an octave
   * and comes back wrapped in noise is the same lie told in the channel the
   * player is actually listening to, and it lands before the screen does.
   */
  playScannerPing(hollow = 0) {
    if (!this.ctx) return;
    const h = Math.max(0, Math.min(1, hollow));
    const f = AUDIO.SCANNER_PING_HZ * (1 - h * 0.5);
    this._tone({ type: 'sine', from: f, to: f * 0.94, dur: 0.04 + h * 0.05,
      gain: 0.05, attack: 0.006 });
    if (h > 0.02) {
      // The static is not decoration: it rises with proximity and it is the
      // only cue that arrives before the thing does.
      this._burst({ dur: 0.1 + h * 0.16, filterType: 'bandpass',
        freq: 1400 - h * 700, q: 0.8, gain: 0.02 + h * 0.05, when: 0.02 });
    }
  }

  /**
   * A recovered log playing back. There is no audio file — this is the BED the
   * text scrolls over: telephone-band noise plus a slow wow on a carrier, which
   * is what a degraded magnetic recording sounds like when there is nothing
   * left on it worth resolving.
   *
   * Returns a stop function, because a log has a length and the player can
   * close the journal in the middle of one.
   */
  playTapeLogCrackle(seconds = 6) {
    if (!this.ctx) return () => {};
    const t0 = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(2);
    src.loop = true;
    // 300–3400 Hz is the telephone band, and the reason a bad recording is
    // instantly legible as a bad recording.
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass'; hp.frequency.value = 300;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 3400;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t0);
    g.gain.linearRampToValueAtTime(0.03, t0 + 0.25);
    // Wow: the transport is not holding speed. 0.7 Hz is slow enough to hear as
    // a drift rather than as vibrato.
    const wow = this.ctx.createOscillator();
    wow.frequency.value = 0.7;
    const wowGain = this.ctx.createGain();
    wowGain.gain.value = 260;
    wow.connect(wowGain).connect(lp.frequency);
    src.connect(hp).connect(lp).connect(g).connect(this.amb);
    src.start(t0); wow.start(t0);
    const stop = (at = this.ctx.currentTime) => {
      g.gain.cancelScheduledValues(at);
      g.gain.setValueAtTime(g.gain.value, at);
      g.gain.linearRampToValueAtTime(0, at + 0.3);
      src.stop(at + 0.4); wow.stop(at + 0.4);
    };
    if (seconds > 0) stop(t0 + seconds);
    return stop;
  }

  /**
   * A cold hull flexing. Sparingly — this is the sound the ship makes when
   * nothing is happening, and it only works because nothing is happening.
   *
   * Doubled an octave up at a fifth of the gain, because 30–60 Hz on a laptop
   * speaker is silence: the harmonic is what survives the playback chain and
   * carries the fundamental with it on anything that can reproduce it.
   */
  playHullGroan(strain = 0) {
    if (!this.ctx) return;
    const [lo, hi] = AUDIO.GROAN_HZ;
    const f = lo + Math.random() * (hi - lo);
    const dur = 1.6 + Math.random() * 2.2;
    const g = 0.035 + strain * 0.05;
    this._tone({ type: 'sawtooth', from: f, to: f * (0.82 + Math.random() * 0.3),
      dur, gain: g, attack: dur * 0.35, bed: true });
    this._tone({ type: 'sine', from: f * 2, to: f * 1.8, dur: dur * 0.8,
      gain: g * 0.2, attack: dur * 0.3, bed: true });
    // The tick of something settling at the end of it.
    if (Math.random() < 0.5) {
      this._burst({ dur: 0.05, filterType: 'bandpass', freq: 700 + Math.random() * 900,
        q: 5, gain: 0.03, when: dur * 0.7, bed: true });
    }
  }

  /**
   * Two low pulses. THE HOLLOW ONLY — `context/06` §3 is explicit that this has
   * to stay rare enough to be a signal rather than wallpaper, so nothing in the
   * codebase may call it except the tension director.
   */
  playHeartbeatSting() {
    if (!this.ctx) return;
    const f = AUDIO.HEARTBEAT_HZ;
    this._tone({ type: 'sine', from: f, to: f * 0.8, dur: 0.26, gain: 0.13, attack: 0.02 });
    this._tone({ type: 'sine', from: f * 0.94, to: f * 0.74, dur: 0.34, gain: 0.1,
      attack: 0.02, when: 0.34 });
  }

  // -- the airlock, and everything else that had no voice ------------------------

  /**
   * The outer door cycling. This was CALLED and did not exist — `startEva` has
   * been firing `audio.playAirlock?.()` since 0.51.0 and the optional chaining
   * swallowed it, so the single most dramatic thing you can do on foot happened
   * in silence.
   *
   * Pump-down, then the hiss thinning to nothing as the compartment empties,
   * then the bolts. The thinning is the sound: it is the only moment in the
   * game where the air is taken away from you.
   */
  playAirlock() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this._burst({ dur: 0.35, filterType: 'bandpass', freq: 420, q: 1.2, gain: 0.09 });
    // The evacuating hiss: a bandpass climbing as the air thins out of it.
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(2.2);
    const f = this.ctx.createBiquadFilter();
    f.type = 'bandpass'; f.Q.value = 1.1;
    f.frequency.setValueAtTime(900, t + 0.2);
    f.frequency.exponentialRampToValueAtTime(5200, t + 2.0);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0, t + 0.2);
    g.gain.linearRampToValueAtTime(0.075, t + 0.5);
    g.gain.exponentialRampToValueAtTime(0.001, t + 2.1);
    src.connect(f).connect(g).connect(this.master);
    src.start(t + 0.2); src.stop(t + 2.3);
    // Bolts, after the air is gone, so they arrive into near-silence.
    for (let i = 0; i < 3; i++) {
      this._burst({ dur: 0.07, filterType: 'bandpass', freq: 340 + i * 120, q: 4,
        gain: 0.1, when: 2.05 + i * 0.11 });
    }
    this._tone({ type: 'sine', from: 64, to: 40, dur: 0.5, gain: 0.09, when: 2.3 });
  }

  /** Clamps taking your hull. Heavy, and it arrives in two stages. */
  playDock() {
    if (!this.ctx) return;
    this._tone({ type: 'sine', from: 55, to: 34, dur: 0.7, gain: 0.11 });
    this._burst({ dur: 0.12, filterType: 'lowpass', freq: 300, gain: 0.13, when: 0.05 });
    this._burst({ dur: 0.09, filterType: 'bandpass', freq: 520, q: 3, gain: 0.09, when: 0.42 });
  }

  /**
   * Gear on the ground. `hard` is the whole distinction: a soft touchdown is a
   * compression and a settle, a hard one is a bang and a scrape you feel in the
   * frame — and the progression system pays four times as much for the first,
   * so the sound has to tell you which one you just did.
   */
  playTouchdown(hard = false) {
    if (!this.ctx) return;
    if (hard) {
      this._burst({ dur: 0.16, filterType: 'lowpass', freq: 240, gain: 0.2 });
      this._tone({ type: 'square', from: 120, to: 28, dur: 0.5, gain: 0.11 });
      this._burst({ dur: 0.4, filterType: 'bandpass', freq: 1700, q: 0.8, gain: 0.05, when: 0.1 });
    } else {
      this._burst({ dur: 0.1, filterType: 'lowpass', freq: 320, gain: 0.09 });
      this._tone({ type: 'sine', from: 90, to: 46, dur: 0.4, gain: 0.07, when: 0.03 });
    }
  }

  /** Spooling into a jump: a rising carrier that stops rather than resolves. */
  playWarpCharge(seconds = 2.2) {
    if (!this.ctx) return;
    this._tone({ type: 'sawtooth', from: 70, to: 640, dur: seconds, gain: 0.05,
      attack: seconds * 0.5 });
    this._tone({ type: 'sine', from: 140, to: 1280, dur: seconds, gain: 0.03,
      attack: seconds * 0.6 });
  }

  /** And the jump itself: everything at once, then nothing. */
  playWarpJump() {
    if (!this.ctx) return;
    this._burst({ dur: 0.5, filterType: 'lowpass', freq: 900, gain: 0.16 });
    this._tone({ type: 'sawtooth', from: 900, to: 40, dur: 0.7, gain: 0.09 });
    this._tone({ type: 'sine', from: 2200, to: 60, dur: 0.55, gain: 0.05 });
  }

  /** The bench finishing a job: a press, a hiss, and a part in the tray. */
  playCraft() {
    if (!this.ctx) return;
    this._burst({ dur: 0.09, filterType: 'lowpass', freq: 400, gain: 0.11 });
    this._burst({ dur: 0.3, filterType: 'bandpass', freq: 2600, q: 1.1, gain: 0.045, when: 0.1 });
    this._tone({ type: 'triangle', from: 320, to: 420, dur: 0.14, gain: 0.06, when: 0.34 });
  }

  /** And spoiling one: the same press, then it lets go. */
  playCraftSpoil() {
    if (!this.ctx) return;
    this._burst({ dur: 0.09, filterType: 'lowpass', freq: 400, gain: 0.11 });
    this._tone({ type: 'sawtooth', from: 300, to: 70, dur: 0.45, gain: 0.07, when: 0.08 });
    this._burst({ dur: 0.2, filterType: 'bandpass', freq: 600, q: 2, gain: 0.05, when: 0.12 });
  }

  /**
   * Something going into the hold. `rare` gets a second note a fifth up — the
   * only difference between a good find and an ordinary one, and it is enough,
   * because by then you have heard the ordinary one two hundred times.
   */
  playPickup(rare = false) {
    if (!this.ctx) return;
    this._burst({ dur: 0.05, filterType: 'bandpass', freq: 1500, q: 2.5, gain: 0.05 });
    this._tone({ type: 'triangle', from: 520, to: 560, dur: 0.09, gain: 0.05, when: 0.02 });
    if (rare) this._tone({ type: 'triangle', from: 780, to: 840, dur: 0.13, gain: 0.05, when: 0.11 });
  }

  /** A till. Mechanical, because everything on this ship is. */
  playCredits() {
    if (!this.ctx) return;
    this._burst({ dur: 0.04, filterType: 'bandpass', freq: 2400, q: 5, gain: 0.06 });
    this._tone({ type: 'square', from: 880, to: 880, dur: 0.05, gain: 0.035, when: 0.05 });
    this._tone({ type: 'square', from: 1320, to: 1320, dur: 0.07, gain: 0.03, when: 0.11 });
  }

  /** A proficiency going up. Two notes, and it does not overstay. */
  playLevelUp() {
    if (!this.ctx) return;
    this._tone({ type: 'triangle', from: 440, to: 460, dur: 0.16, gain: 0.06 });
    this._tone({ type: 'triangle', from: 660, to: 690, dur: 0.3, gain: 0.055, when: 0.15 });
  }

  /**
   * A klaxon. Two-tone, slow, and DELIBERATELY not urgent-sounding: an alarm
   * that panics does the panicking for you. This one just tells you, over and
   * over, in a compartment where nobody is coming.
   */
  playAlarm(severe = false) {
    if (!this.ctx) return;
    const a = severe ? 520 : 380;
    this._tone({ type: 'square', from: a, to: a, dur: 0.3, gain: 0.045 });
    this._tone({ type: 'square', from: a * 0.75, to: a * 0.75, dur: 0.34, gain: 0.045, when: 0.32 });
  }

  /** A round stopped by the deflector rather than the plating. */
  playShieldHit() {
    if (!this.ctx) return;
    this._tone({ type: 'sine', from: 1500, to: 700, dur: 0.16, gain: 0.05 });
    this._burst({ dur: 0.12, filterType: 'highpass', freq: 3000, gain: 0.03 });
  }

  /** The emitter collapsing. The last thing between you and the plating. */
  playShieldDown() {
    if (!this.ctx) return;
    this._tone({ type: 'sawtooth', from: 700, to: 90, dur: 0.6, gain: 0.08 });
    this._burst({ dur: 0.3, filterType: 'bandpass', freq: 500, q: 1.2, gain: 0.06, when: 0.05 });
  }

  /** Nothing in the magazine. A mechanism completing its cycle on empty. */
  playDryFire() {
    if (!this.ctx) return;
    this._burst({ dur: 0.035, filterType: 'bandpass', freq: 1900, q: 6, gain: 0.07 });
    this._burst({ dur: 0.05, filterType: 'bandpass', freq: 700, q: 5, gain: 0.04, when: 0.04 });
  }

  /** Eating, drinking, or putting something into your arm. */
  playConsume(kind = 'eat') {
    if (!this.ctx) return;
    if (kind === 'drink') {
      this._burst({ dur: 0.28, filterType: 'bandpass', freq: 560, q: 1.6, gain: 0.05 });
      this._tone({ type: 'sine', from: 300, to: 190, dur: 0.24, gain: 0.03, when: 0.05 });
    } else if (kind === 'med') {
      this._burst({ dur: 0.06, filterType: 'bandpass', freq: 1500, q: 4, gain: 0.05 });
      this._burst({ dur: 0.3, filterType: 'highpass', freq: 2600, gain: 0.035, when: 0.06 });
    } else {
      this._burst({ dur: 0.16, filterType: 'bandpass', freq: 900, q: 1.1, gain: 0.05 });
      this._burst({ dur: 0.14, filterType: 'bandpass', freq: 640, q: 1.3, gain: 0.04, when: 0.19 });
    }
  }

  /**
   * The suit's cold-gas jet, held while a translation key is down. A hiss, not
   * a rumble: outside there is no hull to carry a low frequency into your feet,
   * and the gas is arriving through the pack against your own back.
   */
  setSuitJet(level) {
    if (!this.ctx) return;
    if (!this._jet) {
      const src = this.ctx.createBufferSource();
      src.buffer = this._noiseBuffer(2);
      src.loop = true;
      const f = this.ctx.createBiquadFilter();
      f.type = 'bandpass';
      f.frequency.value = AUDIO.SUIT_JET_HZ;
      f.Q.value = 0.7;
      const gain = this.ctx.createGain();
      gain.gain.value = 0;
      src.connect(f).connect(gain).connect(this.amb);
      src.start();
      this._jet = { gain, filter: f };
    }
    const t = this.ctx.currentTime;
    const lv = Math.max(0, Math.min(1, level));
    this._jet.gain.gain.setTargetAtTime(lv * 0.05, t, 0.05);
    this._jet.filter.frequency.setTargetAtTime(
      AUDIO.SUIT_JET_HZ * (0.8 + lv * 0.4), t, 0.08);
  }

  /**
   * THE HULL TALKING TO ITSELF, on a slow timer.
   *
   * `strain` 0..1 scales both the gain and how often it happens, so a hull at
   * 30% plating groans three times as often as a sound one — which turns the
   * damage number on the HUD into something you can hear without looking at it.
   * Passing 0 stops the timer, which is what leaving a deck does.
   */
  setHullStrain(strain) {
    if (!this.ctx) return;
    this._strain = Math.max(0, Math.min(1, strain));
    if (this._groanTimer) return;
    const schedule = () => {
      const s = this._strain ?? 0;
      if (s <= 0) { this._groanTimer = null; return; }
      const lo = AUDIO.GROAN_INTERVAL_MIN * (1 - s * 0.6);
      const hi = AUDIO.GROAN_INTERVAL_MAX * (1 - s * 0.6);
      this._groanTimer = setTimeout(() => {
        this.playHullGroan(this._strain ?? 0);
        schedule();
      }, (lo + Math.random() * (hi - lo)) * 1000);
    };
    schedule();
  }

  /**
   * Continuous drive rumble. level 0..3 (thrust × boost); felt through the
   * hull, so it lives low — sawtooth through a tight lowpass.
   */
  setEngineThrust(level) {
    if (!this.ctx) return;
    if (!this._engine) {
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.value = AUDIO.ENGINE_RUMBLE_HZ;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 130;
      const gain = this.ctx.createGain();
      gain.gain.value = 0;
      osc.connect(filter).connect(gain).connect(this.amb);
      osc.start();
      this._engine = { osc, gain };
    }
    const t = this.ctx.currentTime;
    const target = Math.min(0.11, level * 0.04);
    this._engine.gain.gain.setTargetAtTime(target, t, 0.12);
    this._engine.osc.frequency.setTargetAtTime(
      AUDIO.ENGINE_RUMBLE_HZ * (1 + level * 0.18), t, 0.2);
  }
}
