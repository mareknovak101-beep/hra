/**
 * SaveSystem — localStorage persistence (context/04 §10, context/02 §9).
 * Two writers, one format: the diegetic SaveTerminal ritual ("PROGRESS
 * RECORDED") and a quiet interval autosave so a browser crash costs minutes,
 * not hours. The snapshot is versioned; unknown versions are ignored rather
 * than half-applied.
 */

const KEY = 'starrift_save_v1';
export const SAVE_VERSION = 1;

export class SaveSystem {
  /**
   * @param {() => object} gather returns the current state snapshot body
   * @param {(data: object) => void} apply restores a snapshot body
   */
  constructor(gather, apply) {
    this.gather = gather;
    this.apply = apply;
    this.lastSaveAt = 0;
    this._autosaveT = 0;
  }

  /** Write a snapshot now. Returns true on success. */
  save(reason = 'manual') {
    try {
      const body = this.gather();
      const record = { version: SAVE_VERSION, at: Date.now(), reason, body };
      localStorage.setItem(KEY, JSON.stringify(record));
      this.lastSaveAt = record.at;
      return true;
    } catch (err) {
      console.warn('save failed', err); // quota/private mode — play continues
      return false;
    }
  }

  /** True if a compatible save exists. */
  hasSave() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return false;
      return JSON.parse(raw).version === SAVE_VERSION;
    } catch { return false; }
  }

  /** Load and apply the snapshot. Returns true if restored. */
  load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return false;
      const record = JSON.parse(raw);
      if (record.version !== SAVE_VERSION || !record.body) return false;
      this.apply(record.body);
      this.lastSaveAt = record.at;
      return true;
    } catch (err) {
      console.warn('save restore failed', err);
      return false;
    }
  }

  clear() { try { localStorage.removeItem(KEY); } catch { /* fine */ } }

  /** Call every frame; writes a quiet autosave on the interval. */
  tick(dt, intervalS = 60) {
    this._autosaveT += dt;
    if (this._autosaveT >= intervalS) {
      this._autosaveT = 0;
      this.save('autosave');
    }
  }
}
