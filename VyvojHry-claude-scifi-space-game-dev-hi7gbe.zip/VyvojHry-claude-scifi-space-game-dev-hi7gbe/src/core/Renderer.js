/**
 * Renderer — WebGL2 context owner and low-level GPU primitives.
 *
 * The canvas backbuffer is the true 480×270 target (context/02 §1); upscaling
 * to the display happens purely via CSS `image-rendering: pixelated`, so every
 * gl_FragCoord is a real logical pixel and no antialiasing can sneak in.
 */
import { RENDER, PALETTE } from './Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';

// Interleaved interior vertex: pos(3) normal(3) uv(2) layer(1) ao(1) emissive(1) tangent(3)
export const INTERIOR_FLOATS_PER_VERTEX = 14;
// Interleaved HUD vertex: pos(2) uv(2) color(4)
export const HUD_FLOATS_PER_VERTEX = 8;

export class Renderer {
  /** @param {HTMLCanvasElement} canvas */
  constructor(canvas) {
    this.canvas = canvas;
    canvas.width = RENDER.WIDTH;
    canvas.height = RENDER.HEIGHT;

    const gl = canvas.getContext('webgl2', {
      antialias: false,
      alpha: false,
      depth: true,
      stencil: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: false,
    });
    if (!gl) throw new Error('WebGL2 not supported');
    this.gl = gl;

    gl.viewport(0, 0, RENDER.WIDTH, RENDER.HEIGHT);
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);

    const clear = hexToRgbf(PALETTE.SHADOW_BLACK[2]);
    gl.clearColor(clear[0], clear[1], clear[2], 1);

    /** @type {Map<string, WebGLProgram & {uniforms: Object}>} */
    this.programs = new Map();
    this.drawCalls = 0;
    // Leak tracking (context/07: no leaked WebGL buffers)
    this.liveBuffers = 0;
    this.liveTextures = 0;
    this.liveVaos = 0;
  }

  compileShader(type, source, name) {
    const gl = this.gl;
    const sh = gl.createShader(type);
    gl.shaderSource(sh, source);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      const log = gl.getShaderInfoLog(sh);
      gl.deleteShader(sh);
      throw new Error(`Shader compile failed (${name}): ${log}`);
    }
    return sh;
  }

  /** Compile + link and cache a program; uniform locations are enumerated. */
  createProgram(name, vertSrc, fragSrc) {
    const gl = this.gl;
    const vs = this.compileShader(gl.VERTEX_SHADER, vertSrc, `${name}.vert`);
    const fs = this.compileShader(gl.FRAGMENT_SHADER, fragSrc, `${name}.frag`);
    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    gl.deleteShader(vs);
    gl.deleteShader(fs);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      throw new Error(`Program link failed (${name}): ${gl.getProgramInfoLog(prog)}`);
    }
    prog.uniforms = {};
    const count = gl.getProgramParameter(prog, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < count; i++) {
      const info = gl.getActiveUniform(prog, i);
      // Array uniforms report as "name[0]"; register both spellings.
      const loc = gl.getUniformLocation(prog, info.name);
      prog.uniforms[info.name] = loc;
      if (info.name.endsWith('[0]')) prog.uniforms[info.name.slice(0, -3)] = loc;
    }
    this.programs.set(name, prog);
    return prog;
  }

  use(name) {
    const prog = this.programs.get(name);
    this.gl.useProgram(prog);
    return prog;
  }

  /**
   * Static indexed mesh with the interior vertex layout.
   * @param {Float32Array} vertexData interleaved, 11 floats/vertex
   * @param {Uint32Array} indexData
   */
  createInteriorMesh(vertexData, indexData) {
    const gl = this.gl;
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);

    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.STATIC_DRAW);
    const stride = INTERIOR_FLOATS_PER_VERTEX * 4;
    const attribs = [
      [0, 3, 0], // position
      [1, 3, 12], // normal
      [2, 2, 24], // uv
      [3, 1, 32], // layer
      [4, 1, 36], // ao
      [5, 1, 40], // emissive
      [6, 3, 44], // tangent
    ];
    for (const [loc, size, offset] of attribs) {
      gl.enableVertexAttribArray(loc);
      gl.vertexAttribPointer(loc, size, gl.FLOAT, false, stride, offset);
    }

    const ibo = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexData, gl.STATIC_DRAW);

    gl.bindVertexArray(null);
    this.liveBuffers += 2;
    this.liveVaos += 1;
    return { vao, vbo, ibo, count: indexData.length };
  }

  deleteMesh(mesh) {
    const gl = this.gl;
    gl.deleteBuffer(mesh.vbo);
    gl.deleteBuffer(mesh.ibo);
    gl.deleteVertexArray(mesh.vao);
    this.liveBuffers -= 2;
    this.liveVaos -= 1;
  }

  drawMesh(mesh) {
    const gl = this.gl;
    gl.bindVertexArray(mesh.vao);
    gl.drawElements(gl.TRIANGLES, mesh.count, gl.UNSIGNED_INT, 0);
    gl.bindVertexArray(null);
    this.drawCalls++;
  }

  /**
   * 2D texture array for the interior material atlas — NEAREST + REPEAT, no
   * mips (pixel truth: no filtering anywhere).
   * @param {number} size square texture edge
   * @param {Uint8Array[]} layers RGBA data per layer
   */
  createTextureArray(size, layers) {
    const gl = this.gl;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, tex);
    // A MIP CHAIN, sampled NEAREST_MIPMAP_NEAREST. This is not a softening of
    // pillar 3 — that filter picks exactly one texel from exactly one level, so
    // nothing is ever blended, magnification stays hard-edged nearest, and the
    // look up close is unchanged. What it fixes is minification: interior texels
    // are finer than a screen pixel on any wall more than a few metres off, and
    // with a single level that undersampling reads as crawling static as the
    // player walks. Picking a whole texel from a smaller level is the standard
    // retro-3D answer and keeps every surface hard.
    const levels = Math.floor(Math.log2(size)) + 1;
    gl.texStorage3D(gl.TEXTURE_2D_ARRAY, levels, gl.RGBA8, size, size, layers.length);
    for (let i = 0; i < layers.length; i++) {
      gl.texSubImage3D(
        gl.TEXTURE_2D_ARRAY, 0, 0, 0, i, size, size, 1,
        gl.RGBA, gl.UNSIGNED_BYTE, layers[i],
      );
    }
    if (levels > 1) gl.generateMipmap(gl.TEXTURE_2D_ARRAY);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MIN_FILTER,
      levels > 1 ? gl.NEAREST_MIPMAP_NEAREST : gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D_ARRAY, gl.TEXTURE_WRAP_T, gl.REPEAT);
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, null);
    this.liveTextures += 1;
    return tex;
  }

  /**
   * Plain 2D texture (HUD atlas, overlays, space objects) — NEAREST, CLAMP by
   * default.
   *
   * `opts.repeat` is REQUIRED for anything whose UVs tile. Exterior hull meshes
   * derive planar UVs from model coordinates, so a 90-unit ship at uvScale 0.16
   * addresses u ∈ [-7, 7] — under CLAMP_TO_EDGE every one of those faces
   * sampled the same edge column, which is why the plating on the Aethon and
   * the freighter read as a single flat colour no matter what got painted into
   * the texture. Spheres and billboards stay clamped: their UVs are already in
   * 0..1 and clamping is what keeps their seams tight.
   * @param {{width:number, height:number, data:Uint8Array|Uint8ClampedArray}} img
   * @param {{repeat?:boolean}} [opts]
   */
  createTexture2D(img, opts = {}) {
    const gl = this.gl;
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(
      gl.TEXTURE_2D, 0, gl.RGBA, img.width, img.height, 0,
      gl.RGBA, gl.UNSIGNED_BYTE,
      img.data instanceof Uint8Array ? img.data : new Uint8Array(img.data.buffer),
    );
    const wrap = opts.repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE;
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
    gl.bindTexture(gl.TEXTURE_2D, null);
    this.liveTextures += 1;
    return tex;
  }

  beginFrame() {
    const gl = this.gl;
    this.drawCalls = 0;
    gl.viewport(0, 0, RENDER.WIDTH, RENDER.HEIGHT);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  }

  /** Switch GL state for the 2D HUD overlay pass (after 3D). */
  begin2D() {
    const gl = this.gl;
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  }

  end2D() {
    const gl = this.gl;
    gl.disable(gl.BLEND);
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
  }
}
