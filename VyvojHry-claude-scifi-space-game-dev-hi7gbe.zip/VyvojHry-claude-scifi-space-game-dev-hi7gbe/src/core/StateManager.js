/**
 * StateManager — global game FSM.
 * States this session: LOADING → GATE (click to board) → PLAYING ↔ PAUSED.
 * Later phases add MENU, INVENTORY, MAP, FLIGHT etc. on the same machine.
 */
export const STATES = {
  LOADING: 'LOADING',
  GATE: 'GATE',
  PLAYING: 'PLAYING', // on foot
  FLIGHT: 'FLIGHT', // in the pilot seat — still first person
  EVA: 'EVA', // outside the hull in a suit — first person, no floor
  SURFACE: 'SURFACE', // down on a world, walking its generated ground
  PAUSED: 'PAUSED',
};

export class StateManager {
  /** @param {import('./EventBus.js').EventBus} events */
  constructor(events) {
    this.events = events;
    this.current = STATES.LOADING;
    /** @type {Map<string, {enter?: Function, exit?: Function}>} */
    this.handlers = new Map();
  }

  register(state, handlers) {
    this.handlers.set(state, handlers);
  }

  is(state) { return this.current === state; }

  transition(next) {
    if (next === this.current) return;
    const prev = this.current;
    this.handlers.get(prev)?.exit?.(next);
    this.current = next;
    this.handlers.get(next)?.enter?.(prev);
    this.events.emit('state:change', { from: prev, to: next });
  }
}
