/**
 * Engine — main loop. requestAnimationFrame drives rendering; simulation runs
 * on a fixed 60Hz accumulator so physics/collision are framerate-independent.
 *
 * The loop has three phases per rendered frame, and which one a piece of work
 * belongs in decides whether it looks smooth:
 *
 * - `update(fixedDt)` — 0..MAX_STEPS times. Physics, collision, anything whose
 *   result must not depend on the display's refresh rate. Because it can run
 *   zero times in a frame, nothing the player *watches* should live here alone.
 * - `frame(frameDt)` — exactly once, before render. Raw input that wants zero
 *   latency (mouse look) and anything animated off real elapsed time.
 * - `render(alpha, frameDt)` — exactly once. `alpha` is how far the clock sits
 *   between the last fixed step and the next, so a renderer can interpolate a
 *   body's drawn position between its two most recent simulated ones.
 *
 * Without that interpolation a 60Hz sim on any display that isn't exactly 60Hz
 * judders: some frames advance the simulation twice and some not at all, so a
 * first-person camera visibly stutters even at a locked 60fps. The camera and
 * the ship both snapshot their previous step and resolve against `alpha`.
 */
export class Engine {
  /**
   * @param {{update:(dt:number)=>void, frame?:(dt:number)=>void,
   *          render:(alpha:number, dt:number)=>void}} game
   * @param {import('../utils/Debug.js').Debug} debug
   */
  constructor(game, debug) {
    this.game = game;
    this.debug = debug;
    this.fixedDt = 1 / 60;
    this.maxAccum = 0.25; // clamp huge tab-switch deltas
    /**
     * Hard ceiling on catch-up steps per frame. The accumulator alone is a
     * death spiral: a frame that runs long queues extra steps, the extra steps
     * make the next frame run longer, and the game slides into slow motion it
     * cannot climb out of. Past this many steps the backlog is DISCARDED — the
     * simulation clock falls behind real time, which is invisible, where a
     * spiral is not.
     */
    this.maxSteps = 5;
    this.accum = 0;
    this.lastTime = 0;
    this.time = 0; // total simulated seconds
    /** Real seconds the last rendered frame took — for time-based animation. */
    this.frameDt = this.fixedDt;
    this.running = false;
    this._tick = this._tick.bind(this);
  }

  start() {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    requestAnimationFrame(this._tick);
  }

  stop() {
    this.running = false;
  }

  _tick(now) {
    if (!this.running) return;
    let dt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    if (dt > this.maxAccum) dt = this.maxAccum;
    // Guard against a zero or negative delta (two rAF callbacks in the same
    // millisecond, or a clock that steps backwards): frame-rate-scaled
    // animation would freeze, and dividing by it would produce Infinity.
    this.frameDt = Math.max(1e-4, dt);
    this.accum += dt;

    let steps = 0;
    while (this.accum >= this.fixedDt && steps < this.maxSteps) {
      this.time += this.fixedDt;
      this.game.update(this.fixedDt);
      this.accum -= this.fixedDt;
      steps++;
    }
    if (steps >= this.maxSteps) this.accum = 0; // drop the backlog, don't spiral

    this.game.frame?.(this.frameDt);
    this.game.render(this.accum / this.fixedDt, this.frameDt);
    this.debug?.frame();
    requestAnimationFrame(this._tick);
  }
}
