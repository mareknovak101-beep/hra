/**
 * InputManager — keyboard + pointer lock mouse look. Touch joysticks land in
 * Phase 8 (TouchControls.js); the action map here is built to absorb them.
 *
 * Actions are queried by name so key bindings stay in one table.
 */
export const KEY_BINDINGS = {
  forward: ['KeyW', 'ArrowUp'],
  back: ['KeyS', 'ArrowDown'],
  left: ['KeyA', 'ArrowLeft'],
  right: ['KeyD', 'ArrowRight'],
  sprint: ['ShiftLeft', 'ShiftRight'],
  crouch: ['KeyC', 'ControlLeft'],
  jump: ['Space'],
  interact: ['KeyE'],
  flashlight: ['KeyG'], // moved off F so flight can strafe-down there
  view: ['KeyV'], // toggle first/third-person while piloting
  // 6DOF translational thrusters (flight only): sidestep + climb/dive
  strafeLeft: ['KeyQ'],
  strafeRight: ['KeyE'],
  strafeUp: ['KeyR'],
  strafeDown: ['KeyF'],
  flightAssist: ['KeyZ'], // toggle fly-by-wire drift damping
  warp: ['KeyJ'], // open the warp target panel while piloting
  inventory: ['KeyI'], // toggle the hold manifest
  journal: ['KeyL'], // toggle the survey journal (work orders + logs)
  // KeyN aliases Tab so the command bar has a keybind it can actually PRINT:
  // AMBER9 has no tab glyph and the legend rendered as '?'. Tab still works.
  scanner: ['Tab', 'KeyN'], // raise/lower the proximity scanner
  fire: ['KeyX', 'Mouse0'], // ship weapon while piloting (left click / X / FIRE)
  cycleWeapon: ['KeyC'], // step through the hardpoints (C / the WPN button)
  lockTarget: ['KeyT'], // acquire / step the target lock (T / the LOCK button)
  repair: ['KeyH'], // weld a hull plate onto the worst section (H / REPAIR)
  // STATION-KEEPING. Locks the hull to whatever it is closest to — a world's
  // orbit or a station's stand-off — so it rides along instead of being left
  // behind by a moving target. O for orbit; nothing else claims it.
  hold: ['KeyO'],
  // ON FOOT ONLY, and deliberately sharing keys the seat already claims for
  // something else — the same trick strafeUp/strafeDown play with R and F. B
  // draws and steps through whatever hand weapons are in the hold, then
  // holsters; R changes magazines; `fire` above is reused for the trigger.
  drawWeapon: ['KeyB'],
  reload: ['KeyR'],
  // HELD, not tapped: orbits the hull cam instead of steering, and only while the
  // chase camera is out (see main.js). Before this, the hull cam claimed the look
  // delta unconditionally and the ship could not be turned in third person at
  // all. Right mouse, because the gesture reads as "inspect, don't fly".
  orbit: ['Mouse2', 'AltLeft'],
  // HELD, and only while the hull cam is out: dollies the chase camera in and
  // out. Bound to the two keys that sit either side of Backspace so they are
  // reachable without moving the left hand off WASD, and duplicated onto the
  // numeric-pad pair for keyboards that have one. The wheel does the same job
  // continuously; the HUD's zoom pad is the touch and mouse-cursor route.
  zoomIn: ['Equal', 'NumpadAdd'],
  zoomOut: ['Minus', 'NumpadSubtract'],
  debug: ['Backquote'],
};

export class InputManager {
  /** @param {import('./EventBus.js').EventBus} events */
  constructor(events) {
    this.events = events;
    /** @type {Set<string>} currently held key codes */
    this.down = new Set();
    /** @type {Set<string>} codes pressed since last consume */
    this.pressed = new Set();
    this.mouseDX = 0;
    this.mouseDY = 0;
    this.pointerLocked = false;
    this.enabled = true;
    /** analog move from touch joysticks: [strafe -1..1, forward -1..1] */
    this.moveAxis = [0, 0];
    /**
     * Analog ATTITUDE command: [yaw -1..1, pitch -1..1]. Separate from moveAxis
     * and from mouse look on purpose — look could not serve piloting in both
     * views (in the hull cam it orbits the camera), so turning needs a channel
     * of its own that means the same thing wherever the camera is.
     */
    this.turnAxis = [0, 0];

    // code -> action reverse lookup
    this.codeToAction = new Map();
    for (const [action, codes] of Object.entries(KEY_BINDINGS)) {
      for (const code of codes) this.codeToAction.set(code, action);
    }

    document.addEventListener('keydown', (e) => {
      if (e.repeat) return;
      this.down.add(e.code);
      this.pressed.add(e.code);
      const action = this.codeToAction.get(e.code);
      if (action) {
        this.events.emit(`input:${action}`, true);
        // Space scrolls, Tab steals focus — both are game keys here
        if (e.code === 'Space' || e.code === 'Tab') e.preventDefault();
      }
    });
    document.addEventListener('keyup', (e) => {
      this.down.delete(e.code);
    });
    window.addEventListener('blur', () => this.down.clear());

    // left mouse fires the ship laser while pointer-locked (piloting);
    // outside pointer lock clicks belong to menus and boarding
    document.addEventListener('mousedown', (e) => {
      if (e.button === 0 && this.pointerLocked) this.setVirtualDown('fire', true);
      if (e.button === 2 && this.pointerLocked) this.setVirtualDown('orbit', true);
    });
    document.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.setVirtualDown('fire', false);
      if (e.button === 2) this.setVirtualDown('orbit', false);
    });
    // right button holds the hull-cam orbit; the browser menu would otherwise
    // eat the gesture and leave the hold latched down
    document.addEventListener('contextmenu', (e) => {
      if (this.pointerLocked) e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!this.pointerLocked || !this.enabled) return;
      this.mouseDX += e.movementX;
      this.mouseDY += e.movementY;
    });
    document.addEventListener('pointerlockchange', () => {
      this.pointerLocked = document.pointerLockElement != null;
      this.events.emit('input:pointerlock', this.pointerLocked);
    });
  }

  /**
   * @param {HTMLElement} el element to lock the pointer to
   * @returns {Promise|undefined} modern browsers return a promise; callers
   * can catch rejection to fall back to lock-free input
   */
  requestPointerLock(el) {
    return el.requestPointerLock?.();
  }

  exitPointerLock() {
    document.exitPointerLock?.();
  }

  /** true while any key bound to the action is held */
  isDown(action) {
    const codes = KEY_BINDINGS[action];
    if (!codes) return false;
    for (const code of codes) if (this.down.has(code)) return true;
    return false;
  }

  /** true exactly once per key press (edge trigger, cleared each frame) */
  wasPressed(action) {
    const codes = KEY_BINDINGS[action];
    if (!codes) return false;
    for (const code of codes) if (this.pressed.has(code)) return true;
    return false;
  }

  /** Returns accumulated mouse delta since last call and resets it. */
  consumeMouseDelta() {
    const d = [this.mouseDX, this.mouseDY];
    this.mouseDX = 0;
    this.mouseDY = 0;
    return d;
  }

  // -- virtual input (TouchControls) ----------------------------------------

  /** Analog movement from the touch move-stick. */
  setVirtualAxis(strafe, forward) {
    this.moveAxis[0] = strafe;
    this.moveAxis[1] = forward;
  }

  /**
   * Attitude command from the turn stick (or the keyboard turn keys).
   * @param {number} yaw   -1 = nose left, +1 = nose right
   * @param {number} pitch -1 = nose down, +1 = nose up
   */
  setVirtualTurn(yaw, pitch) {
    this.turnAxis[0] = yaw;
    this.turnAxis[1] = pitch;
  }

  /** Look delta from the touch look-stick (bypasses pointer lock). */
  injectLook(dx, dy) {
    this.mouseDX += dx;
    this.mouseDY += dy;
  }

  /** Hold/release a bound action from a touch button. */
  setVirtualDown(action, down) {
    const code = KEY_BINDINGS[action]?.[0];
    if (!code) return;
    if (down) {
      if (!this.down.has(code)) this.pressed.add(code);
      this.down.add(code);
    } else {
      this.down.delete(code);
    }
  }

  /** One-shot action from a touch button (tap). */
  virtualPress(action) {
    const code = KEY_BINDINGS[action]?.[0];
    if (!code) return;
    this.pressed.add(code);
    this.events.emit(`input:${action}`, true);
  }

  /** Call at end of each update tick. */
  endFrame() {
    this.pressed.clear();
  }
}
