/**
 * AssetManager — loads shader sources, drives procedural asset generation and
 * tracks what exists on the GPU. Nothing here reads an art file: every texture
 * is generated at startup by TextureFactory (pillar 4).
 */
export class AssetManager {
  /** @param {import('./Renderer.js').Renderer} renderer */
  constructor(renderer) {
    this.renderer = renderer;
    /** @type {Map<string, string>} shader name -> source */
    this.shaderSources = new Map();
  }

  async fetchText(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Failed to fetch ${url}: ${res.status}`);
    return res.text();
  }

  /**
   * Fetch .vert/.frag pairs and compile them.
   * @param {Array<[string, string]>} entries [programName, basePathWithoutExt]
   * @param {(msg: string) => void} onProgress
   */
  async loadPrograms(entries, onProgress = () => {}) {
    for (const [name, base] of entries) {
      onProgress(`COMPILING ${name.toUpperCase()} SHADER`);
      const [vert, frag] = await Promise.all([
        this.fetchText(`${base}.vert`),
        this.fetchText(`${base}.frag`),
      ]);
      this.shaderSources.set(`${name}.vert`, vert);
      this.shaderSources.set(`${name}.frag`, frag);
      this.renderer.createProgram(name, vert, frag);
    }
  }
}
