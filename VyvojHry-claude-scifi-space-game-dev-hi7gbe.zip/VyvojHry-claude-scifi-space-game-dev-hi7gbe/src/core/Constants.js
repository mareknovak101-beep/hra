/**
 * Constants — the single home for ALL magic numbers, config values and palette
 * colors (quality checklist: no magic numbers outside this file).
 *
 * Palette families are transcribed verbatim from context/01-ART-DIRECTION.md §2.
 * The palette is a CLOSED SYSTEM: if a new color is genuinely needed it gets
 * added to that doc first, then here — never inline in a shader or texture fn.
 */

export const GAME_TITLE = 'STARRIFT';
export const GAME_VERSION = '0.60.0'; // session 18m — settings that reach the whole engine
export const COMPANY_NAME = 'KESTREL EXTRACTION & SALVAGE CO.';
export const SHIP_NAME = 'HSV AETHON';

// ---------------------------------------------------------------------------
// Palette — context/01 §2, closed system
// ---------------------------------------------------------------------------
export const PALETTE = {
  // Interior surfaces — retro-future: cool white/grey/blue-grey, not industrial green
  METAL_DARK: ['#3a414b', '#525c68', '#727d8b'], // structural panels — cool blue-grey steel
  RUST: ['#5c4638', '#725645', '#8a6a52'], // muted aged staining, not orange industrial rust
  AMBER_MACHINE: ['#8a5a10', '#b07020', '#d09030'],
  PANEL_STEEL: ['#3d465a', '#525d74', '#6f7c92'], // brighter blue-grey brushed steel
  FLOOR_GRIME: ['#181b20', '#252b33', '#353d47'], // neutral charcoal, faint cool tint
  WARNING_RED: ['#8a1515', '#aa2020', '#cc3030'],
  SHADOW_BLACK: ['#0a0a0f', '#050508', '#000003'],
  // Bright panel accents for the retro-future look — clean off-white ceramics
  PANEL_WHITE: ['#8f97a2', '#aab2bd', '#c8ced6'],

  // Terminal phosphor green — diegetic screens ONLY, never the player HUD
  PHOSPHOR_BG: ['#0d1a12', '#16241a'],
  PHOSPHOR_MID: ['#2d4a35', '#3a5c42'],
  PHOSPHOR_TEXT: ['#4a7a52', '#5a9060'], // brightness ceiling — never brighter

  // HUD — vintage amber only, zero exceptions
  HUD_AMBER: ['#b08040', '#c09050', '#d0a060'],
  HUD_SECONDARY: ['#8a6030', '#704a20'],
  HUD_ALERT: ['#993020', '#bb4030'],
  HUD_PANEL_BG: ['#0f0f14', '#14141a'],
  HUD_BORDER: ['#403020', '#503828'],
  HUD_O2: ['#205080', '#4080c0'], // desaturated blue, right-to-left fill
  HUD_HEALTH: ['#7a1515', '#aa2525'], // dark red, left-to-right fill

  // Bio-unknown accent — the Hollow only (unused this session, reserved)
  HOLLOW_BLACK: ['#0a0508'],
  HOLLOW_VIOLET: ['#3a2f3a', '#4f3f4a'],

  // Space / exterior
  DEEP_SPACE: ['#000008', '#010110'],
  STARLIGHT: ['#e8e8f0', '#9696a5', '#d0b48c'], // white / cool / warm star points
  NEBULA: ['#200a30', '#0a1530', '#30200a', '#0a2a26'], // 4th so all four sky variants differ in hue, not just shape
  PLANET_ROCKY: ['#5a4530', '#6a5540', '#4a3a28'],
  PLANET_ICE: ['#3a4a5a', '#4a5a6a', '#5a6a7a'],
  PLANET_LAVA: ['#5a1a08', '#7a2a10', '#9a3a18'],
  PLANET_JUNGLE: ['#1a3a1a', '#2a4a2a', '#1a2a18'],
};

// ---------------------------------------------------------------------------
// Rendering — context/02 §1
// Render scale is the one lever that controls apparent pixel size.
// ---------------------------------------------------------------------------
/**
 * The base 480×270 buffer is pillar 3, and for fifteen sessions it was fixed.
 * The owner asked four times for finer pixels, so it is now a preset: the SCENE
 * buffer is `480×270 × scale`, and the UI grid below stays at 480×270 so the
 * HUD keeps the size it was tuned to. Everything that reads RENDER.WIDTH/HEIGHT
 * is the 3D scene, the CRT post-process and the helmet glass — those all get
 * `scale²` times the pixels. Everything that reads UI_WIDTH/UI_HEIGHT is 2D
 * chrome and is unaffected.
 *
 * Why the scene and the chrome must diverge: the HUD is authored as literal
 * pixel rects and 6px bitmap glyphs on a 480-wide grid. Scaling that grid does
 * not add detail to it, it just makes it smaller — a 6px glyph at 960 wide is
 * an unreadable 6px glyph. The 3D scene has no such ceiling: its detail comes
 * from geometry and textures, both of which resolve finer the moment there are
 * more pixels to put them in.
 *
 * Only integer multiples, and only ones that also land on a whole ratio against
 * a 1080p display — 4×, 2× and 1× respectively. The tempting middle preset,
 * 1440×810, is deliberately absent: it upscales to 1080p at 1.33×, and a
 * fractional nearest-neighbour upscale drops pixels unevenly, so straight lines
 * grow a visible stagger. A resolution option whose whole purpose is cleaner
 * pixels must not introduce shimmer.
 */
export const RENDER_SCALES = [
  { id: 1, label: '480 × 270 CLASSIC', w: 480, h: 270, tex: 128 },
  { id: 2, label: '960 × 540 FINE', w: 960, h: 540, tex: 256 },
  { id: 4, label: '1920 × 1080 SHARP', w: 1920, h: 1080, tex: 256 },
];
export const RENDER_SCALE_DEFAULT = 2;

/** localStorage key for the settings blob; re-exported to Settings.js so the
 * scale can be read here at module load without importing Settings (which
 * would make a cycle — Settings needs the preset table from this file). */
export const SETTINGS_KEY = 'starrift.settings';

/**
 * Resolve the chosen preset before anything else imports RENDER. This has to
 * happen at module-evaluation time: Renderer sizes the canvas, PostProcess
 * allocates its framebuffer and TextureFactory sizes the glass overlay all from
 * these numbers, and none of them are rebuilt later. Changing the setting
 * therefore needs a reload, which the Settings menu says out loud.
 */
function bootScale() {
  let id = RENDER_SCALE_DEFAULT;
  try {
    const raw = globalThis.localStorage?.getItem(SETTINGS_KEY);
    if (raw) {
      const v = JSON.parse(raw).renderScale;
      if (typeof v === 'number' && RENDER_SCALES.some((p) => p.id === v)) id = v;
    }
  } catch { /* corrupt, unavailable or SSR — take the default */ }
  return RENDER_SCALES.find((p) => p.id === id) ?? RENDER_SCALES[1];
}
const SCALE = bootScale();

export const RENDER = {
  // SCENE buffer — the 3D pass, the CRT post-process and the helmet glass.
  WIDTH: SCALE.w,
  HEIGHT: SCALE.h,
  SCALE: SCALE.id,
  // UI grid — the HUD, crosshair, notifications and scanner are authored here
  // and stretched to the scene buffer by the hud shader's u_resolution. Fixed
  // at the classic size forever: these are hand-placed pixel coordinates.
  UI_WIDTH: 480,
  UI_HEIGHT: 270,
  // Widened 70 -> 84 (owner, session 17c). At 70 the cockpit glass framed a
  // keyhole: the windshield pillars ate most of the useful arc and a fighter
  // crossing your nose left frame before you could follow it. 84 is about as far
  // as this projection goes before the edge stretch becomes obvious.
  FOV_DEG: 84,
  NEAR: 0.05,
  FAR: 120,
  /**
   * The ground needs its OWN far plane, and this is the single most consequential
   * number in the whole surface renderer.
   *
   * FAR is 120 because that is the length of the ship and a corridor never needs
   * more. The terrain patch is 3200 units across — so drawing it through the
   * interior projection clipped away everything past a 120-unit disc around the
   * player's boots. There was never a horizon, the skyline was the far plane,
   * and the ~9 units of relief the first surface pass generated across that disc
   * came to a 7% slope: a painted floor. Both halves of "the surface is flat"
   * were this number.
   *
   * NEAR rises with it. 0.05 against a 7000 far plane is a depth ratio of
   * 140 000 and the z-buffer cannot carry it; 0.25 is still closer than a
   * standing player's own feet and buys two and a half bits back.
   */
  /**
   * THE SUIT'S OWN FRUSTUM (0.49.0).
   *
   * An EVA borrowed the interior camera, whose far plane is 120 units — and the
   * Aethon is 97 units long. Fly a hundred metres off your own ship to look at
   * it and the hull crosses the far plane and disappears; the reported symptom
   * was an empty starfield with nothing in it. Outside the hull you are looking
   * at objects hundreds of units away and the frustum has to say so.
   */
  EVA_FAR: 4200,
  EVA_NEAR: 0.12,
  SURFACE_FAR: 7000,
  SURFACE_NEAR: 0.25,
  TARGET_FPS_DESKTOP: 60,
  TARGET_FPS_MOBILE: 30,
  MAX_DRAW_CALLS_INTERIOR: 200,
  MAX_DRAW_CALLS_SPACE: 100,
  MAX_LIGHTS_PER_DRAW: 8,
  DITHER_LIGHT_LEVELS: 22, // lighting quantization steps (smooth banding, no Bayer)
  // surface relief: per-texture normal maps derived from painted height +
  // a luminance assist, lit with a quantized specular term ("plastic" pop)
  // Detailed + plastic, but no dither dots and no HARSH white/black borders:
  // strong DIFFUSE normal relief gives 3D depth as a soft shade gradient, and a
  // broad, weak specular reads as a gentle "plastic" sheen, not a sharp outline.
  NORMAL_STRENGTH: 2.05, // sobel slope -> normal xy gain (deep relief; raised session 11)
  NORMAL_LUM_WEIGHT: 0.22, // how much texture brightness implies height
  SPEC_POWER: 16, // broad, soft highlight (low = spread out, not a point)
  SPEC_STRENGTH: 0.06, // gentle plastic sheen, never a hard white border
  DISTANCE_DARKEN_RANGE: 70, // meters — light falls toward this floor with distance...
  DISTANCE_DARKEN_FLOOR: 0.6, // ...but never below this factor (raised: less murk)
  // Interior materials are authored on a 64×64 DESIGN grid — every seam pitch,
  // bolt position and inset-panel rect in TextureFactory is a coordinate on that
  // grid, and moving it would mean retuning forty generators. TEXTURE_SIZE is
  // what actually reaches the GPU: the Painter writes TEXTURE_SIZE/TEXTURE_DESIGN
  // output texels per design texel, and samples every noise, wear and grain layer
  // at the OUTPUT rate. So structure keeps its physical size on the wall while the
  // material detail inside it resolves finer — the same trade the celestial
  // surfaces took when they went to 512×256 with one sample per texel.
  //
  // Tied to the render scale, because texel density only pays for itself when
  // there are pixels to resolve it. At 480×270 a 2m wall three metres out spans
  // ~150 buffer px, so 128 texels across it is already 1:1 and 256 would just be
  // averaged back down by the mip chain (measured session 16r: 2× the boot cost,
  // zero visible gain). At 960×540 that same wall spans ~300 px, so 128 texels
  // becomes a visible 2px block and 256 is what restores 1:1.
  TEXTURE_SIZE: SCALE.tex, // texels per procedural texture as uploaded
  TEXTURE_DESIGN: 64, // the grid the generators are written against
};

// 4×4 Bayer matrix — context/01 §3, the exact standard pattern, reused everywhere.
export const BAYER_4X4 = [
  0, 8, 2, 10,
  12, 4, 14, 6,
  3, 11, 1, 9,
  15, 7, 13, 5,
];

// ---------------------------------------------------------------------------
// Lighting — context/02 §6
// ---------------------------------------------------------------------------
export const LIGHTING = {
  // The player's ship is powered and lived-in — it should read as *lit*, with
  // shadow for mood, not near-black. The old oppressive 0.08 is kept as the
  // DERELICT profile for later wrecks and enemy hulls (context/03 §6).
  AMBIENT: 0.26, // lit ship (HSV Aethon) — good general visibility
  AMBIENT_DERELICT: 0.06, // wrecks / powered-down hulls — the old dread level
  TYPES: {
    // brighter + larger so rooms are evenly lit end-to-end on the live ship
    CEILING_TUBE: { color: [0.95, 0.82, 0.55], intensity: 1.15, radius: 6.5 },
    EMERGENCY: { color: [0.7, 0.14, 0.12], intensity: 0.5, radius: 3.0 },
    SCREEN_GLOW: { color: [0.4, 0.5, 0.7], intensity: 0.22, radius: 1.8 },
    TERMINAL_PHOSPHOR: { color: [0.29, 0.48, 0.34], intensity: 0.18, radius: 1.6 },
    SCANNER_PULSE: { color: [0.29, 0.48, 0.34], intensity: 0.4, radius: 3.0, decay: 0.3 },
    // rust-orange floor-seam glow, Cargo Bay concept art (context/01 §6)
    CARGO_SEAM: { color: [0.78, 0.38, 0.12], intensity: 0.4, radius: 3.5 },
    // reactor core viewport glow
    REACTOR_GLOW: { color: [0.85, 0.5, 0.15], intensity: 1.0, radius: 7.0 },
  },
  HELMET_LIGHT: {
    color: [0.95, 0.9, 0.8],
    intensity: 1.2,
    innerAngleDeg: 18,
    outerAngleDeg: 32,
    range: 12.0,
  },
  FLICKER: {
    SLOW_PULSE_RATE: 1.2,
    SLOW_PULSE_BASE: 0.85,
    SLOW_PULSE_AMP: 0.15,
    RAPID_DROP_CHANCE: 0.1,
    RAPID_DROP_LEVEL: 0.3,
    CUT_DURATION: 0.2,
    CUT_INTERVAL_MIN: 4,
    CUT_INTERVAL_RAND: 4,
  },
};

// ---------------------------------------------------------------------------
// Player — context/02 §3
// ---------------------------------------------------------------------------
export const PLAYER = {
  EYE_HEIGHT: 1.6,
  EYE_HEIGHT_CROUCH: 1.1,
  HEIGHT: 1.7,
  HEIGHT_CROUCH: 1.2,
  RADIUS: 0.28, // AABB half-extent on x/z
  WALK_SPEED: 2.6, // m/s
  SPRINT_SPEED: 4.4,
  CROUCH_SPEED: 1.3,
  ACCEL: 22, // ground acceleration m/s^2
  DECEL: 16,
  GRAVITY: 12,
  JUMP_SPEED: 3.6,
  HEAD_BOB_AMPLITUDE: 0.04,
  HEAD_BOB_FREQ_HZ: 1.8,
  PITCH_LIMIT_DEG: 89,
  MOUSE_SENSITIVITY: 0.0034, // rad per px (base; scaled by Settings.lookSens)
  INTERACT_DISTANCE: 2.6,
  FOOTSTEP_STRIDE: 0.78, // meters between footstep sounds
  CROUCH_LERP_SPEED: 8, // eye-height transition
};

// ---------------------------------------------------------------------------
// Corridor types — context/02 §5 (E is the octagonal junction hub)
// ---------------------------------------------------------------------------
export const CORRIDOR_TYPES = {
  A: { name: 'Barrel Arch', width: 2.0, height: 2.8, shape: 'arch' },
  B: { name: 'Low Industrial', width: 2.5, height: 2.0, shape: 'flat' },
  C: { name: 'Wide Bay', width: 4.0, height: 3.5, shape: 'buttress' },
  D: { name: 'Maintenance', width: 1.2, height: 1.8, shape: 'hex' },
  E: { name: 'Junction', width: 5.0, height: 3.5, shape: 'octagon' },
};

// ---------------------------------------------------------------------------
// Flight — context/02 §3 (first-person seated; the universe moves, not the camera)
// ---------------------------------------------------------------------------
export const FLIGHT = {
  SEAT_EYE: [0, 1.34, 2.82], // interior coords: seated eye, sightline over the console bank
  SEAT_TRANSITION_S: 0.5, // camera lerp into/out of the seat — never a pull-back
  EXIT_POS: [0.9, 0, 2.7], // where you stand when you get up
  // Speeds are tuned for the real-AU system scale (CelestialGen): orbits run to
  // hundreds of thousands of units, so cruise is fast and BOOST is a real burn.
  // Retuned with the 0.37.0 rescale. Orbital distances are 3.33x what they
  // were, so a transit budget that was tuned against the old chart would have
  // made every crossing three times as long. BOOST takes the same factor —
  // cruise deliberately does NOT, because cruise speed against BODY radius is
  // what decides how big a world feels when you fly past one, and that ratio
  // improving by six is the entire point of the rescale.
  THRUST_ACCEL: 90, // u/s^2 main drive
  RETRO_ACCEL: 56, // u/s^2 reverse thrust
  STRAFE_ACCEL: 46, // u/s^2 lateral/vertical RCS translation (Q/E/R/F)
  /**
   * The ventral descent engine, used only in ground mode (see
   * FlightController). Gravity is GRAV_UNITS=34 u/s² at one g, so 118 leaves
   * net climb authority of 84 over an Earth-like world and 49 over a heavy one
   * — a hull that can hold itself off a planet and still be flown, rather than
   * one that falls at twelve units a second squared no matter what you press.
   */
  DESCENT_ACCEL: 118,
  BOOST_MULT: 12.0, // full-burn interplanetary transit (~17000 u/s top)
  BRAKE_DAMP: 1.4, // flight-assist deceleration (exponential, Space held)
  ASSIST_DAMP: 0.9, // fly-by-wire drift-bleed when flight assist is on + no input
  SOFT_MAX_SPEED: 1400, // u/s — velocity softly clamped here
  TURN_RATE: 0.0011, // rad per mouse px (pitch/yaw; scaled by Settings.flightSens)
  ROLL_RATE: 1.7, // rad/s (A/D) — legacy direct rate, kept for touch tuning
  // Angular inertia (0.9.1): control input is TORQUE, not direct rotation, so
  // the hull carries momentum and has to be flown rather than pointed.
  //
  // Retuned (0.20): a mouse flick used to bank the hull most of the way through a
  // barrel roll before the RCS caught it, which made aiming at a jinking fighter
  // guesswork. Gain and the velocity ceiling are both down, and the damping while
  // actively steering is up — the ship still carries momentum, it just no longer
  // overshoots the thing you were trying to point at.
  TORQUE_GAIN: 15, // mouse impulse → rad/s of spin-up
  ROLL_TORQUE: 4.2, // rad/s² from the roll thrusters
  ANG_DAMP_ASSIST: 6.5, // fly-by-wire arrests the tumble when you let go
  ANG_DAMP_ASSIST_ACTIVE: 3.4, // lighter while actively steering, so it still glides
  ANG_DAMP_MANUAL: 0.25, // assist off: it keeps turning until you counter-steer
  MAX_ANG_VEL: 1.35, // rad/s cap — a flung mouse can't start an unrecoverable spin
  // -- TURN STICK ------------------------------------------------------------
  // A dedicated attitude control, separate from mouse look, because look could
  // not serve both views: in the hull cam the look delta orbits the CAMERA, so
  // the ship simply would not turn in third person at all. The stick is a RATE
  // command rather than an impulse — deflection maps to a target angular
  // velocity the RCS chases — which is what makes it hold a steady turn instead
  // of accelerating for as long as you keep pushing.
  TURN_STICK_RATE: 0.62, // rad/s at full deflection (pitch + yaw)
  TURN_STICK_GAIN: 7.0, // how hard the RCS chases the commanded rate
  TURN_STICK_ROLL: 0.85, // rad/s at full deflection when the stick is in roll mode
  DUST_COUNT: 130,
  DUST_RADIUS: 55, // motes live inside this ship-local sphere
  SKY_RADIUS: 90, // distant bodies projected onto this sphere (inside FAR plane)
  STAR_COUNT: 1400,
  // third-person pilot view (chase camera). Offsets are in ship-local space
  // (forward = -z), lerped near→far so the toggle reads as a zoom-out reveal.
  // NEAR must clear the hull's rear (nozzles reach z≈16.5) or the camera starts
  // INSIDE the ship and the view blacks out during the transition.
  CHASE_NEAR: [0, 9, 26], // just behind/above the hull — outside it
  CHASE_FAR: [0, 20, 54], // full chase: whole ship with space around it
  VIEW_TOGGLE_S: 0.7, // seconds for the first↔third transition
  // interstellar warp (Phase 4) — the owner-specced 4-stage jump:
  //   infall (space bends, particles stream into the spine) → hole (a black
  //   sphere grows amid a spinning accretion disk) → consume (it swallows the
  //   ship, white-out) → streak (hyperspace lines; the system swaps behind the
  //   flash). The first three stages play on the external cinematic camera.
  WARP_INFALL_S: 1.4,
  WARP_HOLE_S: 2.3,
  WARP_CONSUME_S: 1.3,
  WARP_STREAK_S: 2.6,
  WARP_HOLE_R: 7.5, // black sphere radius at the end of the hole stage
  WARP_CONSUME_R: 17, // radius that fully swallows the drawn hull
  WARP_COST: 22, // % of warp fuel per jump — ~4 jumps per tank, refuel at stations
  // -- SURVIVABILITY ---------------------------------------------------------
  // The Aethon is a SURVEY vessel rated for six, not a gunship, but at 16 damage
  // a round into a 100% section it lost a section to six hits — and five hostiles
  // put six rounds in the air in under two seconds. HULL_ARMOR divides incoming
  // hull damage, which is the honest way to say "there is structure behind the
  // plating": the section percentages still mean what they say, they just take
  // roughly a third of the raw damage.
  HULL_ARMOR: 2.7,
  // A field repair patches ONE section — the worst one — because that is what a
  // pilot with a plate and a welder can reach. Costs a hull-plate item.
  REPAIR_SECTION_PCT: 34,
  REPAIR_ITEM: 'hull_plate',
  REPAIR_COOLDOWN: 2.2, // seconds between patches, so it is not a heal button
  // -- RADAR -----------------------------------------------------------------
  // The tactical display's outer ring, in world units. Enemies further out than
  // this are pinned to the rim with a range readout rather than being dropped —
  // knowing something is out there at 9km is the whole point of having a radar.
  RADAR_RANGE: 6000,
};

// ---------------------------------------------------------------------------
// Doors
// ---------------------------------------------------------------------------
export const DOOR = {
  WIDTH: 1.2,
  HEIGHT: 2.1,
  THICKNESS: 0.1,
  WALL_GAP: 0.3, // structural wall thickness the frame tunnels through
  SLIDE_TIME: 0.55, // seconds to fully open/close
};

// ---------------------------------------------------------------------------
// Audio — context/06 (synthesis parameters)
// ---------------------------------------------------------------------------
export const AUDIO = {
  MASTER_GAIN: 0.55,
  REACTOR_HZ: 48,
  REACTOR_MOD_HZ: 0.3,
  HVAC_LFO_HZ: 0.5,
  CLANK_INTERVAL_MIN: 8,
  CLANK_INTERVAL_MAX: 30,
  FOOTSTEP_MS: 50,
  FOOTSTEP_PITCH_JITTER: 0.15,
  KEYSTROKE_MS: 30,
  ENGINE_RUMBLE_HZ: 36,
  /** Proximity-scanner blip, context/06 §3. Drops an octave near the Hollow. */
  SCANNER_PING_HZ: 1200,
  /**
   * Hull groan, context/06 §3: a cold hull flexing. Deliberately in the band
   * where a subwoofer and a laptop speaker disagree, which is why the tone is
   * doubled an octave up at a fifth of the gain — the groan has to survive
   * being played on a phone.
   */
  GROAN_HZ: [30, 60],
  GROAN_INTERVAL_MIN: 24,
  GROAN_INTERVAL_MAX: 70,
  /** The Hollow's two-pulse sting. Rare by contract — see TensionDirector. */
  HEARTBEAT_HZ: 60,
  /** Suit cold-gas jet, EVA. A hiss, not a rumble: there is no hull to carry it. */
  SUIT_JET_HZ: 2600,
};

// ---------------------------------------------------------------------------
// Mobile — context/02 §10
// ---------------------------------------------------------------------------
export const MOBILE = {
  MAX_PARTICLES: 500, // vs 2000 desktop (particles land in a later phase)
  SHADOW_RES: 256, // vs 512 desktop
  MIN_TOUCH_TARGET: 44, // px
};

export const isMobile = () =>
  /Android|iPhone|iPad/i.test(navigator.userAgent) || navigator.maxTouchPoints > 2;
