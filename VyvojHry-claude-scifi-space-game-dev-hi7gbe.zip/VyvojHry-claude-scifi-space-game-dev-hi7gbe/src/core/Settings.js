/**
 * Settings — player-tunable options, persisted to localStorage. A single
 * source of truth read live by the camera, flight controller, renderer and
 * audio; the Settings menu writes here and everything picks it up next frame.
 */
import { SETTINGS_KEY, RENDER_SCALES, RENDER_SCALE_DEFAULT, RENDER } from './Constants.js';

const KEY = SETTINGS_KEY;

const DEFAULTS = {
  lookSens: 1.0, // walking mouse-look multiplier (0.3 .. 2.5)
  flightSens: 1.0, // piloting steer multiplier (0.3 .. 2.5)
  invertY: false, // invert vertical look
  brightness: 1.0, // interior brightness (0.6 .. 1.8)
  volume: 0.55, // master audio gain (0 .. 1)
  // Two buses under the master. The bed is what makes the ship feel inhabited;
  // the one-shots are information. One slider could not express "atmosphere
  // loud, clatter quiet" or the reverse. See AudioEngine.resume.
  ambienceVolume: 1.0,
  sfxVolume: 1.0,
  fov: 70, // vertical field of view in degrees (60 .. 100)
  crt: true, // full-frame CRT post-process (scanlines/vignette/grain/phosphor)
  crtStrength: 1.0, // how much of the tube to apply (0 .. 1) — see PostProcess
  // Head bob off is an accessibility option, not a nicety: a 1.8 Hz vertical
  // oscillation is one of the two reliable causes of motion sickness in a
  // first-person game, and pillar 1 means there is no other view to escape to.
  headBob: true,
  // Seconds between quiet autosaves; 0 turns the background writer off and
  // leaves only the diegetic terminal ritual.
  autosave: 60,
  // How often the Hollow arms: 'off' | 'rare' | 'normal' | 'often'. This is the
  // open question CLAUDE.md has carried since session 0, answered as a choice.
  hollow: 'normal',
  // Scene buffer size, as a multiple of the classic 480×270. Read by
  // Constants at module load, so a change only lands on the next reload —
  // the canvas, the post-process framebuffer and the whole texture set are
  // all sized from it once at boot.
  renderScale: RENDER_SCALE_DEFAULT,
};

/** Field metadata drives the Settings menu UI generically. `section` groups
 * fields under VIDEO / CONTROLS / AUDIO headers in the menu. */
export const SETTING_FIELDS = [
  // -- VIDEO -----------------------------------------------------------------
  // First on purpose: it is the one setting that changes what the game looks
  // like more than all the others together, and the one that needs a reload,
  // so it should be the first thing a player finds.
  {
    section: 'VIDEO', key: 'renderScale', label: 'RENDER RESOLUTION', type: 'select',
    options: RENDER_SCALES.map((p) => ({ value: p.id, label: p.label })),
    note: () => (Settings.get('renderScale') === RENDER.SCALE
      ? 'HIGHER = FINER PIXELS, MORE GPU LOAD'
      : 'RELOAD REQUIRED — RESTART TO APPLY'),
  },
  { section: 'VIDEO', key: 'brightness', label: 'BRIGHTNESS', type: 'range', min: 0.6, max: 1.8, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%` },
  { section: 'VIDEO', key: 'fov', label: 'FIELD OF VIEW', type: 'range', min: 60, max: 100, step: 1, fmt: (v) => `${Math.round(v)}°` },
  { section: 'VIDEO', key: 'crt', label: 'CRT SCREEN', type: 'toggle' },
  {
    section: 'VIDEO', key: 'crtStrength', label: 'CRT STRENGTH', type: 'range',
    min: 0, max: 1, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%`,
    note: () => 'SCANLINES, PHOSPHOR, GRAIN, VIGNETTE',
  },

  // -- CONTROLS --------------------------------------------------------------
  { section: 'CONTROLS', key: 'lookSens', label: 'LOOK SENSITIVITY', type: 'range', min: 0.3, max: 2.5, step: 0.05, fmt: (v) => `${v.toFixed(2)}x` },
  { section: 'CONTROLS', key: 'flightSens', label: 'FLIGHT SENSITIVITY', type: 'range', min: 0.3, max: 2.5, step: 0.05, fmt: (v) => `${v.toFixed(2)}x` },
  { section: 'CONTROLS', key: 'invertY', label: 'INVERT VERTICAL', type: 'toggle' },
  {
    section: 'CONTROLS', key: 'headBob', label: 'HEAD BOB', type: 'toggle',
    note: () => 'OFF IF WALKING MAKES YOU QUEASY',
  },

  // -- AUDIO -----------------------------------------------------------------
  { section: 'AUDIO', key: 'volume', label: 'MASTER VOLUME', type: 'range', min: 0, max: 1, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%` },
  { section: 'AUDIO', key: 'ambienceVolume', label: 'SHIP AMBIENCE', type: 'range', min: 0, max: 1, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%`, note: () => 'HUM, HVAC, HULL, DRIVE' },
  { section: 'AUDIO', key: 'sfxVolume', label: 'EFFECTS', type: 'range', min: 0, max: 1, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%`, note: () => 'DOORS, WEAPONS, ALARMS, CUES' },

  // -- GAMEPLAY --------------------------------------------------------------
  {
    section: 'GAMEPLAY', key: 'autosave', label: 'AUTOSAVE', type: 'select',
    options: [
      { value: 30, label: 'EVERY 30s' },
      { value: 60, label: 'EVERY 60s' },
      { value: 180, label: 'EVERY 3 MIN' },
      { value: 0, label: 'OFF — TERMINAL ONLY' },
    ],
    note: () => (Settings.get('autosave') === 0
      ? 'SAVE AT A TERMINAL OR LOSE THE RUN'
      : 'THE TERMINAL RITUAL STILL WORKS'),
  },
  {
    section: 'GAMEPLAY', key: 'hollow', label: 'THE HOLLOW', type: 'select',
    options: [
      { value: 'off', label: 'NEVER' },
      { value: 'rare', label: 'RARE — TWO SYSTEMS' },
      { value: 'normal', label: 'NORMAL — FOUR SYSTEMS' },
      { value: 'often', label: 'EVERY SYSTEM' },
    ],
    note: () => (Settings.get('hollow') === 'off'
      ? 'A SURVEY GAME WITH NOTHING IN THE DARK'
      : 'IT STILL CANNOT BE FOUGHT. ONLY AVOIDED'),
  },
];

class SettingsStore {
  constructor() {
    this.values = { ...DEFAULTS };
    this._listeners = new Set();
    this.load();
  }

  load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const saved = JSON.parse(raw);
        for (const k of Object.keys(DEFAULTS)) {
          if (typeof saved[k] === typeof DEFAULTS[k]) this.values[k] = saved[k];
        }
      }
    } catch { /* corrupt or unavailable — keep defaults */ }
  }

  save() {
    try { localStorage.setItem(KEY, JSON.stringify(this.values)); } catch { /* ignore */ }
  }

  get(key) { return this.values[key]; }

  set(key, value) {
    if (!(key in DEFAULTS)) return;
    this.values[key] = value;
    this.save();
    for (const fn of this._listeners) fn(key, value);
  }

  reset() {
    this.values = { ...DEFAULTS };
    this.save();
    for (const fn of this._listeners) fn(null, null);
  }

  /** Subscribe to any change; returns an unsubscribe fn. */
  onChange(fn) { this._listeners.add(fn); return () => this._listeners.delete(fn); }
}

export const Settings = new SettingsStore();
