/**
 * Spaceship — the HSV Aethon's state in system space. The interior is welded
 * to the ship frame: interior coordinates never move; the universe is
 * transformed by the inverse of this state when rendered through the glass.
 */
import { Vec3, Quat } from '../utils/MathUtils.js';

export class Spaceship {
  /** @param {number[]} startPos system-space position */
  constructor(startPos) {
    this.pos = Vec3.create(startPos[0], startPos[1], startPos[2]);
    this.quat = Quat.create(); // identity: ship forward = interior -z
    this.vel = Vec3.create();
    this.qConj = Quat.create(); // cached inverse orientation, updated per frame
    this.thrust = 0; // -1..1 current main-drive input (for HUD + audio)
    this.boosting = false;
    this.braking = false;
    this.flightAssist = true; // fly-by-wire drift damping (Z toggles)
    /** live translational RCS input this frame, ship-local [x,y] (-1..1) for FX+HUD */
    this.strafe = [0, 0];
    /**
     * Render interpolation, same idea as PlayerCamera's. Attitude is what the
     * pilot actually watches — the interior is welded to the hull, so the whole
     * starfield outside the glass swings with `quat`, and a frame that advanced
     * no fixed step would draw the identical view as the frame before. `stepQuat`
     * is the last simulated attitude, `prevQuat` the one before it, and `quat`
     * is what gets drawn.
     *
     * Position is NOT interpolated and does not need to be: space renders
     * camera-centred (the ship sits at the frame origin), so `pos` only selects
     * which part of the system is around you, never a screen-space offset.
     */
    this.prevQuat = Quat.create();
    this.stepQuat = Quat.create();
    this._interp = false;
  }

  get speed() {
    return Vec3.length(this.vel);
  }

  updateConjugate() {
    Quat.conjugate(this.qConj, this.quat);
  }

  /**
   * Open a fixed step: this step's starting attitude becomes the previous one,
   * and `quat` is rewound to the last SIMULATED attitude.
   *
   * The rewind is not optional. resolve() leaves an interpolated attitude in
   * `quat` for the renderer, and FlightController integrates the next step from
   * whatever it finds there — so without this the sim would compound its own
   * display smoothing into the flight model and the hull would drift.
   */
  beginStep() {
    Quat.copy(this.prevQuat, this.stepQuat);
    Quat.copy(this.quat, this.stepQuat);
    this.updateConjugate();
    this._interp = true;
  }

  /** Close a fixed step: commit the attitude the controller just produced. */
  endStep() {
    Quat.copy(this.stepQuat, this.quat);
  }

  /**
   * Resolve the drawn attitude between the last two simulated ones.
   *
   * Normalized lerp, not a true slerp: at 60Hz a step's rotation is a couple of
   * degrees at most, where nlerp's angular-velocity error is far below a pixel,
   * and it costs no trig. It also short-circuits the sign flip that would make a
   * quaternion pair take the long way round.
   */
  resolve(alpha) {
    if (!this._interp) return;
    const t = alpha < 0 ? 0 : alpha > 1 ? 1 : alpha;
    const a = this.prevQuat, b = this.stepQuat;
    const dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3];
    const s = dot < 0 ? -1 : 1; // take the short arc
    const q = this.quat;
    for (let i = 0; i < 4; i++) q[i] = a[i] + (b[i] * s - a[i]) * t;
    Quat.normalize(q, q);
    this.updateConjugate();
  }

  /** Drop the history after a warp or any other hard attitude cut. */
  snapHistory() {
    Quat.copy(this.stepQuat, this.quat);
    Quat.copy(this.prevQuat, this.quat);
    this.updateConjugate();
  }

  /** World point -> ship-local (interior-frame) point. */
  toLocal(out, worldPos) {
    const rel = [worldPos[0] - this.pos[0], worldPos[1] - this.pos[1], worldPos[2] - this.pos[2]];
    return Quat.rotateVec3(out, this.qConj, rel);
  }

  /** World direction -> ship-local direction. */
  dirToLocal(out, worldDir) {
    return Quat.rotateVec3(out, this.qConj, worldDir);
  }

  /**
   * Ship-local direction -> world direction. The inverse of dirToLocal, and the
   * transform that lets anything recorded in the hull's own frame — a hull
   * breach, a hardpoint, a running light — be drawn at the right place in space
   * as the ship manoeuvres.
   */
  dirToWorld(out, localDir) {
    return Quat.rotateVec3(out, this.quat, localDir);
  }
}
