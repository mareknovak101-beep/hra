/**
 * ThrusterFX — flight feedback the pilot can actually see and hear from
 * inside the hull (camera rule: we never watch our own engines burn).
 * - space-dust motes streaming past the glass: THE first-person velocity cue
 * - engine audio coupling: rumble gain follows thrust
 */
import { FLIGHT, PALETTE } from '../core/Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';
import { Vec3 } from '../utils/MathUtils.js';
import { RNG } from '../utils/RNG.js';

export class ThrusterFX {
  constructor() {
    const n = FLIGHT.DUST_COUNT;
    this.count = n;
    // interleaved for the stars program: pos(3) color(3) size(1)
    this.buffer = new Float32Array(n * 7);
    this.rng = new RNG(0xd057);
    const dim = hexToRgbf(PALETTE.STARLIGHT[1]);
    for (let i = 0; i < n; i++) {
      const o = i * 7;
      this._respawn(o);
      this.buffer[o + 3] = dim[0];
      this.buffer[o + 4] = dim[1];
      this.buffer[o + 5] = dim[2];
      this.buffer[o + 6] = 1;
    }
    this._velLocal = Vec3.create();
  }

  _respawn(o) {
    const R = FLIGHT.DUST_RADIUS;
    this.buffer[o] = this.rng.range(-R, R);
    this.buffer[o + 1] = this.rng.range(-R, R);
    this.buffer[o + 2] = this.rng.range(-R, R);
  }

  /** @param {import('./Spaceship.js').Spaceship} ship */
  update(dt, ship) {
    // dust is static in space; in the ship frame it streams at -shipVel
    ship.dirToLocal(this._velLocal, ship.vel);
    const vx = -this._velLocal[0] * dt;
    const vy = -this._velLocal[1] * dt;
    const vz = -this._velLocal[2] * dt;
    const R = FLIGHT.DUST_RADIUS;
    const wrap = R * 2;
    for (let i = 0; i < this.count; i++) {
      const o = i * 7;
      let x = this.buffer[o] + vx;
      let y = this.buffer[o + 1] + vy;
      let z = this.buffer[o + 2] + vz;
      if (x > R) x -= wrap; else if (x < -R) x += wrap;
      if (y > R) y -= wrap; else if (y < -R) y += wrap;
      if (z > R) z -= wrap; else if (z < -R) z += wrap;
      this.buffer[o] = x;
      this.buffer[o + 1] = y;
      this.buffer[o + 2] = z;
    }
  }

  /** Dust visibility scales with speed — parked ships have quiet glass. */
  alphaFor(ship) {
    return Math.min(0.85, 0.1 + ship.speed / 70);
  }
}
