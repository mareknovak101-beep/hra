/**
 * HULL DETAIL — a shared library of bolt-on external parts.
 *
 * The Aethon carries roughly four hundred hand-placed greebles because it was
 * authored over three sessions. The three hulls added in 0.26.0 were authored
 * in one, and it shows at chase distance: their silhouettes are distinct and
 * their SURFACES are bare, so they read as blockouts of good ships rather than
 * as ships. This module is the fix, and deliberately not another four hundred
 * hand-placed boxes — it is the parts bin every hull can bolt from.
 *
 * WHY A KIT AND NOT MORE INLINE BOXES. A greeble written inline is a greeble
 * that exists on exactly one hull. Written here, "docking ring" is one idea
 * with one set of proportions, and the Petrel's nose collar and the Drayman's
 * belly hardpoint are visibly the same fitting from the same yard — which is
 * the whole argument of a used future. Parts commonality is what makes a
 * fleet look like a fleet.
 *
 * Every part is built from the primitives in ShipExterior (`box`, `octaTube`)
 * in the SAME model convention: forward is -z, +y is up, one plating tile per
 * ~10.5 units. Nothing here knows which hull it is on.
 *
 * USAGE. `const k = kit(hv, hi, gv, gi, rnd)` binds the writers once, then
 * every part is `k.something(...)`. The kit exposes `H`/`G`/`T`/`TG` too, so a
 * builder can keep writing raw boxes beside the fitted parts.
 */
import { box, octaTube } from './ShipExterior.js';

const UV = 0.095; // one plating tile per ~10.5 model units, as everywhere else

/**
 * Bind the parts bin to one hull's vertex buffers.
 *
 * @param {number[]} hv hull verts   @param {number[]} hi hull indices
 * @param {number[]} gv glow verts   @param {number[]} gi glow indices
 * @param {Function} [rnd] the builder's own LCG, so a part that wants variation
 *   draws from the same deterministic stream the hull already uses
 */
export function kit(hv, hi, gv, gi, rnd = () => 0.5) {
  const H = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, UV);
  const T = (axis, a, b, s0, s1, r0, r1, caps = 0, flip = false, sides = 8) =>
    octaTube(hv, hi, axis, a, b, s0, s1, r0, r1, UV, caps, flip, sides);
  const TG = (axis, a, b, s0, s1, r0, r1, caps = 1, flip = false, sides = 8) =>
    octaTube(gv, gi, axis, a, b, s0, s1, r0, r1, UV, caps, flip, sides);
  /** Mirrored box: written for STARBOARD, `s` = ±1 flips AND re-sorts. */
  const HX = (s, x0, x1, y0, y1, z0, z1) =>
    H([Math.min(s * x0, s * x1), y0, z0], [Math.max(s * x0, s * x1), y1, z1]);
  const GX = (s, x0, x1, y0, y1, z0, z1) =>
    G([Math.min(s * x0, s * x1), y0, z0], [Math.max(s * x0, s * x1), y1, z1]);

  const k = { H, G, T, TG, HX, GX, rnd };

  /**
   * LANDING GEAR — a leg, a knee, a shock strut and a splayed foot.
   *
   * 0.33.0 let the ship put down on a planet and not one hull had anything to
   * put down ON. A ship that lands needs feet or it is hovering, and a game
   * that shows you the hull from outside on the surface will show you exactly
   * that. Deployed, always: retracting them would need a per-frame transform
   * the exterior pass does not have, and a survey hull that lives on the ground
   * plausibly leaves them out.
   *
   * @param {number} x  leg centre       @param {number} yTop  where it meets the hull
   * @param {number} z  leg centre       @param {number} drop  how far below yTop the foot sits
   * @param {number} [splay] how far outboard the foot walks from the leg
   */
  k.gear = (x, yTop, z, drop, splay = 0.5) => {
    const s = Math.sign(x) || 1;
    const yFoot = yTop - drop;
    const xFoot = x + s * splay;
    // bay: the leg comes out of somewhere, and a hole with a lip reads as a bay
    H([x - 0.44, yTop - 0.06, z - 0.52], [x + 0.44, yTop + 0.16, z + 0.52]);
    H([x - 0.5, yTop - 0.14, z - 0.58], [x + 0.5, yTop - 0.02, z + 0.58]);
    // main leg, raked outboard: two segments so there is a visible knee
    const xKnee = x + s * splay * 0.55, yKnee = yTop - drop * 0.55;
    H([Math.min(x, xKnee) - 0.13, yKnee, z - 0.13], [Math.max(x, xKnee) + 0.13, yTop, z + 0.13]);
    H([Math.min(xKnee, xFoot) - 0.11, yFoot + 0.16, z - 0.11],
      [Math.max(xKnee, xFoot) + 0.11, yKnee + 0.06, z + 0.11]);
    // oleo strut: a bright collar on the sliding section, the one detail that
    // makes a leg read as sprung rather than as a stick
    H([Math.min(x, xKnee) - 0.17, yTop - drop * 0.30, z - 0.17],
      [Math.max(x, xKnee) + 0.17, yTop - drop * 0.16, z + 0.17]);
    // drag brace back to the hull
    H([Math.min(x, xKnee) - 0.07, yKnee, z + 0.28], [Math.max(x, xKnee) + 0.07, yTop - 0.05, z + 0.44]);
    // foot: a pad on a swivel, splayed wider than the leg
    H([xFoot - 0.42, yFoot + 0.10, z - 0.42], [xFoot + 0.42, yFoot + 0.22, z + 0.42]);
    H([xFoot - 0.55, yFoot, z - 0.55], [xFoot + 0.55, yFoot + 0.12, z + 0.55]);
    for (const [gx, gz] of [[-0.46, -0.46], [0.46, -0.46], [-0.46, 0.46], [0.46, 0.46]]) {
      H([xFoot + gx - 0.09, yFoot - 0.05, z + gz - 0.09], [xFoot + gx + 0.09, yFoot + 0.04, z + gz + 0.09]);
    }
    G([xFoot - 0.12, yFoot + 0.22, z - 0.12], [xFoot + 0.12, yFoot + 0.30, z + 0.12]); // touch lamp
  };

  /**
   * DOCKING RING — the collar every station clamp in the register mates to.
   *
   * Four latch lugs at the quarters, a guide lamp at twelve o'clock and a
   * recessed throat you can see into.
   *
   * Axis-aware because hulls dock differently and it matters which: a tug mates
   * nose-first (axis 2) and a slim hull with its nose full of canopy takes the
   * collar on its spine (axis 1). One part, both fittings.
   *
   * @param {number[]} c    ring centre, on the hull surface
   * @param {number} r      throat radius
   * @param {number} axis   0=x, 1=y, 2=z — the direction the collar points along
   * @param {number} sign   +1 or -1 along that axis
   */
  k.dockRing = (c, r, axis = 2, sign = -1) => {
    const [ia, ib] = [[1, 2], [2, 0], [0, 1]][axis];
    const a = c[ia], b = c[ib];
    const s0 = c[axis], s1 = c[axis] + sign * 0.62;
    const [lo, hi] = s0 < s1 ? [s0, s1] : [s1, s0];
    T(axis, a, b, lo, hi, r * 1.14, r * 1.14, 0);           // collar
    T(axis, a, b, lo + 0.06, hi - 0.06, r, r, 0, true);      // throat, inside-out
    T(axis, a, b, lo, lo + 0.1, r * 1.3, r * 1.14, 0);       // flared lip
    for (let i = 0; i < 4; i++) {                            // latch lugs at the quarters
      const ang = Math.PI / 4 + (i / 4) * Math.PI * 2;
      const p0 = [0, 0, 0], p1 = [0, 0, 0];
      p0[ia] = a + Math.cos(ang) * r * 1.2 - 0.11; p1[ia] = a + Math.cos(ang) * r * 1.2 + 0.11;
      p0[ib] = b + Math.sin(ang) * r * 1.2 - 0.11; p1[ib] = b + Math.sin(ang) * r * 1.2 + 0.11;
      p0[axis] = lo; p1[axis] = hi + 0.14;
      H(p0, p1);
    }
    const g0 = [0, 0, 0], g1 = [0, 0, 0];
    g0[ia] = a - 0.1; g1[ia] = a + 0.1;
    g0[ib] = b + r * 1.16; g1[ib] = b + r * 1.30;
    g0[axis] = lo + 0.1; g1[axis] = lo + 0.34;
    G(g0, g1);
  };

  /**
   * COMMS MAST — a tower with cross-arms, a dish and a strobe at the top.
   *
   * Thin verticals are the cheapest way to break a silhouette, and the reason
   * every real working hull bristles: an antenna is the one fitting that has to
   * stick out past everything else to work.
   */
  k.mast = (x, yBase, z, h, dish = true) => {
    H([x - 0.09, yBase, z - 0.09], [x + 0.09, yBase + h, z + 0.09]);
    H([x - 0.22, yBase, z - 0.22], [x + 0.22, yBase + 0.22, z + 0.22]);       // base insulator
    for (let i = 1; i <= 3; i++) {                                             // cross-arms
      const y = yBase + h * (i / 4);
      const w = 0.34 + (3 - i) * 0.16;
      H([x - w, y, z - 0.05], [x + w, y + 0.07, z + 0.05]);
      H([x - 0.05, y, z - w * 0.5], [x + 0.05, y + 0.07, z + w * 0.5]);
    }
    if (dish) {                                                                // parabolic-ish bowl
      T(2, x, yBase + h * 0.78, z + 0.1, z + 0.36, 0.16, 0.52, 0, true);
      H([x - 0.05, yBase + h * 0.78 - 0.05, z + 0.32], [x + 0.05, yBase + h * 0.78 + 0.05, z + 0.52]); // feed horn
    }
    H([x - 0.06, yBase + h, z - 0.06], [x + 0.06, yBase + h + 0.18, z + 0.06]);
    G([x - 0.08, yBase + h + 0.18, z - 0.08], [x + 0.08, yBase + h + 0.30, z + 0.08]); // strobe
  };

  /**
   * FLOODLIGHT — housing, lens and a four-bar guard cage.
   *
   * The cage is the whole point: an unguarded glowing box is a decal, a guarded
   * one is hardware. Lifted wholesale from the Aethon's caged lamps because
   * that is exactly the commonality this module exists to create.
   *
   * @param {number[]} n outward face normal, one of ±x / ±y (not diagonal)
   */
  k.flood = (x, y, z, n = [0, 1, 0]) => {
    const [nx, ny] = n;
    if (ny) { // dorsal / ventral
      const s = Math.sign(ny);
      H([x - 0.24, y, z - 0.22], [x + 0.24, y + s * 0.26, z + 0.22]);
      G([x - 0.17, y + s * 0.26, z - 0.15], [x + 0.17, y + s * 0.32, z + 0.15]);
      for (const gz of [-0.19, 0.19]) H([x - 0.26, y + s * 0.2, z + gz - 0.03], [x + 0.26, y + s * 0.42, z + gz + 0.03]);
      for (const gx of [-0.22, 0.22]) H([x + gx - 0.03, y + s * 0.2, z - 0.22], [x + gx + 0.03, y + s * 0.42, z + 0.22]);
    } else {  // flank
      const s = Math.sign(nx);
      H([Math.min(x, x + s * 0.26), y - 0.24, z - 0.22], [Math.max(x, x + s * 0.26), y + 0.24, z + 0.22]);
      G([Math.min(x + s * 0.26, x + s * 0.32), y - 0.17, z - 0.15],
        [Math.max(x + s * 0.26, x + s * 0.32), y + 0.17, z + 0.15]);
      for (const gy of [-0.21, 0.21]) {
        H([Math.min(x + s * 0.2, x + s * 0.42), y + gy - 0.03, z - 0.22],
          [Math.max(x + s * 0.2, x + s * 0.42), y + gy + 0.03, z + 0.22]);
      }
    }
  };

  /**
   * SENSOR POD — a faired cylinder with a glowing aperture band.
   *
   * The generic "this ship looks at things" fitting: wingtip on a fighter,
   * belly on a survey hull, boom-mounted on anything else.
   */
  k.pod = (x, y, z, r, len, axis = 2) => {
    const [a, b] = axis === 2 ? [x, y] : axis === 0 ? [y, z] : [z, x];
    const s0 = axis === 2 ? z : axis === 0 ? x : y;
    T(axis, a, b, s0, s0 + len, r * 0.5, r, 1);                      // nose fairing
    T(axis, a, b, s0 + len, s0 + len * 2.6, r, r, 0);                // barrel
    T(axis, a, b, s0 + len * 2.6, s0 + len * 3.1, r, r * 0.7, 1);    // tail
    TG(axis, a, b, s0 + len * 1.2, s0 + len * 1.5, r * 1.03, r * 1.03, 0); // aperture band
    // mounting shoe
    if (axis === 2) H([x - r * 0.5, y + r * 0.6, z + len], [x + r * 0.5, y + r * 1.5, z + len * 2.2]);
  };

  /**
   * HANDRAIL — a rail on stand-off stanchions, broken into fitted lengths.
   *
   * Runs along +z at a fixed (x, y). Handrails do more per triangle than any
   * other part here: they are the reason a hull reads as something people work
   * on in vacuum rather than a solid object.
   */
  k.rail = (x, y, z0, z1, seg = 3.2) => {
    for (let z = z0; z < z1 - 0.4; z += seg + 0.5) {
      const ze = Math.min(z + seg, z1);
      H([x - 0.05, y + 0.26, z], [x + 0.05, y + 0.34, ze]);
      for (const sz of [z + 0.08, (z + ze) / 2, ze - 0.14]) {
        H([x - 0.035, y, sz], [x + 0.035, y + 0.30, sz + 0.07]);
      }
    }
  };

  /** LADDER — rungs between two stiles, climbing +y at a fixed (x, z). */
  k.ladder = (x, y0, y1, z, w = 0.28) => {
    H([x - w, y0, z - 0.05], [x - w + 0.07, y1, z + 0.05]);
    H([x + w - 0.07, y0, z - 0.05], [x + w, y1, z + 0.05]);
    for (let y = y0 + 0.24; y < y1 - 0.1; y += 0.34) {
      H([x - w, y, z - 0.04], [x + w, y + 0.05, z + 0.04]);
    }
  };

  /**
   * ACCESS HATCH — a recessed round plate with hinge, dogs and a stencil bar.
   *
   * Faces ±y. Panels that open are the single most legible sign that a surface
   * is maintained, and they cost eight boxes.
   */
  k.hatch = (x, y, z, r, sign = 1) => {
    T(1, z, x, y, y + sign * 0.07, r, r, 2);                    // plate (axis 1: a=z, b=x)
    T(1, z, x, y + sign * 0.04, y + sign * 0.10, r * 0.62, r * 0.62, 2); // raised centre
    for (let i = 0; i < 4; i++) {                               // dogs
      const ang = Math.PI / 4 + (i / 4) * Math.PI * 2;
      const dx = x + Math.cos(ang) * r * 0.82, dz = z + Math.sin(ang) * r * 0.82;
      H([dx - 0.07, y, dz - 0.07], [dx + 0.07, y + sign * 0.12, dz + 0.07]);
    }
    H([x - r * 0.9, y, z + r * 0.98], [x + r * 0.9, y + sign * 0.05, z + r * 1.16]); // hinge bar
  };

  /**
   * NUMBER PLATE — a raised rectangle with a border, on a flank.
   *
   * There is no decal system on the hull shader: painted markings come from the
   * plating texture and cannot be placed. A RAISED plate can be, and a bolted
   * registration panel is more used-future than a decal anyway.
   */
  k.plate = (s, xOuter, y, z, w, h) => {
    HX(s, xOuter, xOuter + 0.06, y, y + h, z, z + w);
    HX(s, xOuter + 0.06, xOuter + 0.10, y + 0.05, y + h - 0.05, z + 0.05, z + w - 0.05);
    for (const cz of [z + 0.06, z + w - 0.12]) {                // corner bolts
      for (const cy of [y + 0.04, y + h - 0.09]) HX(s, xOuter + 0.06, xOuter + 0.12, cy, cy + 0.05, cz, cz + 0.06);
    }
  };

  /**
   * CHAFF / FLARE DISPENSER — a block of tube mouths under a lip.
   *
   * Escort hardware. The mouths go in the GLOW buffer: unfired countermeasures
   * read as loaded ports, which is more interesting than empty holes.
   */
  k.dispenser = (s, x, y, z, n = 4) => {
    HX(s, x, x + 0.9, y, y + 0.34, z, z + 0.28 * n + 0.2);
    HX(s, x, x + 1.0, y + 0.30, y + 0.40, z - 0.05, z + 0.28 * n + 0.25);  // lip
    for (let i = 0; i < n; i++) {
      GX(s, x + 0.12, x + 0.3, y + 0.08, y + 0.24, z + 0.14 + i * 0.28, z + 0.30 + i * 0.28);
    }
  };

  /**
   * PIPE RUN — an external conduit with support saddles, along +z.
   *
   * Anything routed on the OUTSIDE of a hull says the inside ran out of room,
   * which is the most compact statement of "refitted badly" available.
   */
  k.pipes = (x, y, z0, z1, r = 0.13, n = 2) => {
    for (let i = 0; i < n; i++) {
      T(2, x + i * r * 2.6, y, z0, z1, r, r, 2);
    }
    for (let z = z0 + 0.8; z < z1; z += 2.4) {                   // saddles
      H([x - r * 1.8, y - r * 2.0, z], [x + (n - 1) * r * 2.6 + r * 1.8, y - r * 0.4, z + 0.22]);
    }
  };

  /**
   * CARGO POD — a ribbed container clamped to a flank or a belly.
   *
   * Extra volume bolted where the designer did not intend it. Corrugation is
   * the whole texture of a container and is what stops it reading as a brick.
   */
  k.pod3 = (x0, y0, z0, x1, y1, z1) => {
    H([x0, y0, z0], [x1, y1, z1]);
    const n = Math.max(3, Math.round((z1 - z0) / 1.1));
    for (let i = 0; i < n; i++) {
      const z = z0 + 0.35 + i * ((z1 - z0 - 0.7) / (n - 1 || 1));
      H([x0 - 0.09, y0 + 0.14, z], [x0, y1 - 0.14, z + 0.2]);
      H([x1, y0 + 0.14, z], [x1 + 0.09, y1 - 0.14, z + 0.2]);
    }
    for (const cz of [z0 + 0.1, z1 - 0.5]) {                     // corner castings
      for (const cx of [x0, x1 - 0.38]) {
        H([cx, y0, cz], [cx + 0.38, y0 + 0.38, cz + 0.4]);
        H([cx, y1 - 0.38, cz], [cx + 0.38, y1, cz + 0.4]);
      }
    }
    H([x0 + 0.25, y1, z0 + 0.6], [x1 - 0.25, y1 + 0.16, z1 - 0.6]); // top rail
  };

  /**
   * WEAR — a scatter of small plates, patches and repair straps on a flank.
   *
   * The cheapest density there is, and the one that most changes how OLD a hull
   * looks. Draws from the builder's own RNG so it is reproducible per hull.
   */
  k.wear = (s, xOuter, y0, y1, z0, z1, n) => {
    for (let i = 0; i < n; i++) {
      const y = y0 + rnd() * (y1 - y0);
      const z = z0 + rnd() * (z1 - z0);
      const w = 0.4 + rnd() * 1.5, h = 0.22 + rnd() * 0.5;
      HX(s, xOuter, xOuter + 0.05 + rnd() * 0.06, y, y + h, z, z + w);
      if (rnd() < 0.35) {                                        // strap over the patch
        HX(s, xOuter + 0.05, xOuter + 0.12, y - 0.05, y + h + 0.05, z + w * 0.4, z + w * 0.4 + 0.13);
      }
    }
  };

  return k;
}
