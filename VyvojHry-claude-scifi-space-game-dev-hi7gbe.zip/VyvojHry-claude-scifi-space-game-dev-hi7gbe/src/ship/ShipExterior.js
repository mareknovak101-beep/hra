/**
 * ShipExterior — procedural hull meshes for other ships, station approaches,
 * cinematics, AND (as of the pilot-view toggle) the player's own HSV Aethon
 * when they switch to the external chase camera while piloting.
 *
 * Emits the space-pass vertex format: pos(3) normal(3) uv(2).
 *
 * The `HullDetail` import is CIRCULAR — that module builds its parts out of
 * `box` and `octaTube` from here, and `buildAethon` bolts those parts on. It is
 * safe because both directions cross the cycle only at CALL time and every name
 * involved is a hoisted function declaration; nothing here runs at module
 * evaluation. Worth stating out loud, because adding a top-level call that
 * reaches across the cycle would break it silently.
 */
import { kit as kitFor } from './HullDetail.js';

const F = 8; // floats per vertex

export function box(verts, indices, min, max, uvScale) {
  const [x0, y0, z0] = min;
  const [x1, y1, z1] = max;
  const faces = [
    // [normal, four corners CCW from outside]
    [[0, 1, 0], [[x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0]]],
    [[0, -1, 0], [[x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]]],
    [[0, 0, 1], [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]]],
    [[0, 0, -1], [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]]],
    [[1, 0, 0], [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]]],
    [[-1, 0, 0], [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]]],
  ];
  for (const [n, pts] of faces) {
    const base = verts.length / F;
    for (const p of pts) {
      // planar uv on the two axes least aligned with the normal
      let u, v;
      if (Math.abs(n[0]) === 1) { u = p[2]; v = p[1]; }
      else if (Math.abs(n[1]) === 1) { u = p[0]; v = p[2]; }
      else { u = p[0]; v = p[1]; }
      verts.push(p[0], p[1], p[2], n[0], n[1], n[2], u * uvScale, v * uvScale);
    }
    indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
}

/**
 * A Kestrel intra-system freighter: spine, four cargo pods, engine block,
 * low bridge tower. ~30 units long, forward = -z.
 * @returns {{vertexData: Float32Array, indexData: Uint32Array}}
 */
export function buildFreighter() {
  const verts = [];
  const indices = [];
  const uv = 0.14;

  const rnd = lcg(0xf4e1);
  const B = (min, max) => box(verts, indices, min, max, uv);
  const M = (x0, x1, y0, y1, z0, z1) => {
    B([x0, y0, z0], [x1, y1, z1]);
    B([-x1, y0, z0], [-x0, y1, z1]);
  };

  // -- spine as an open TRUSS, not a bar ------------------------------------
  // The whole point of a pod hauler is that the spine is exposed structure with
  // the load hung off it. Four chords with diagonal bracing between them gives
  // the silhouette holes to see through, which is worth more than any amount of
  // surface detail on a solid box.
  for (const [cx, cy] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]]) {
    B([cx - 0.22, cy - 0.22, -15], [cx + 0.22, cy + 0.22, 12]);
  }
  for (let z = -14.4; z < 11.4; z += 2.1) {
    M(1.05, 1.55, -1.55, -1.05, z, z + 0.34);   // lower ring members
    M(1.05, 1.55, 1.05, 1.55, z, z + 0.34);     // upper
    B([-1.55, -1.55, z], [1.55, -1.05, z + 0.28]); // ventral tie
    B([-1.55, 1.05, z], [1.55, 1.55, z + 0.28]);   // dorsal tie
    if (rnd() < 0.55) B([-1.5, -1.2, z + 0.4], [1.5, 1.2, z + 0.62]); // diagonal web
  }

  // -- nose block: bumper, tug fittings, sensor mast -------------------------
  B([-1.05, -1.05, -17.6], [1.05, 1.05, -15]);
  B([-1.3, -1.3, -18.1], [1.3, 1.3, -17.5]);   // bumper ring
  B([-0.5, -0.5, -18.9], [0.5, 0.5, -18.0]);   // tow probe
  M(1.1, 1.5, -0.3, 0.3, -17.4, -16.2);        // tug fittings
  B([-0.16, 1.05, -16.9], [0.16, 2.5, -16.6]); // sensor mast
  B([-0.5, 2.4, -17.1], [0.5, 2.72, -16.4]);   // mast head

  // -- cargo pods: ribbed drums in clamp cradles ----------------------------
  // Each pod is a body, four ribs standing proud of it, a clamp cradle under it
  // and an end cap — four depth tiers, where before it was one box.
  const pod = (x0, x1, z0, z1) => {
    B([x0, -1.8, z0], [x1, 1.8, z1]);
    for (let z = z0 + 1.0; z < z1 - 0.6; z += 1.9) {           // hoop ribs
      B([x0 - 0.14, -1.95, z], [x1 + 0.14, 1.95, z + 0.3]);
    }
    B([x0 - 0.1, -1.9, z0 - 0.28], [x1 + 0.1, 1.9, z0]);        // fore cap
    B([x0 - 0.1, -1.9, z1], [x1 + 0.1, 1.9, z1 + 0.28]);        // aft cap
    B([x0 + 0.3, -2.15, z0 + 0.8], [x1 - 0.3, -1.7, z1 - 0.8]); // cradle keel
    for (const cz of [z0 + 1.4, z1 - 1.4]) {                     // clamp arms
      B([Math.min(x0, x1 > 0 ? 1.3 : -1.3), -0.55, cz - 0.22],
        [Math.max(x0, x1 > 0 ? 1.3 : -1.3), 0.55, cz + 0.22]);
    }
    B([x0 + 0.5, 1.75, z0 + 1.2], [x0 + 1.1, 2.05, z1 - 1.2]);   // dorsal walkway
  };
  pod(-4.6, -1.6, -9, -1);
  pod(1.6, 4.6, -8, 0);
  pod(-4.6, -1.6, 1, 9);
  pod(1.6, 4.6, 2, 10);

  // -- engine block: stepped, with gimbal rings and radiator fins -----------
  B([-2.3, -2.3, 11.6], [2.3, 2.3, 14.2]);
  B([-2.0, -2.0, 14.2], [2.0, 2.0, 15.2]);
  M(0.25, 1.6, -0.85, 0.85, 15.1, 16.0);       // gimbal rings
  M(0.4, 1.45, -0.7, 0.7, 15.9, 17.0);         // bells
  M(0.55, 1.3, -0.5, 0.5, 16.9, 17.4);         // throats
  for (const s of [-1, 1]) {                     // radiator fins
    B([s * 2.25, -0.2, 12.0], [s * 4.2, 0.2, 14.0]);
    B([s * 2.25, -0.2, 12.3], [s * 4.0, 0.9, 12.5]);
    B([s * 2.25, -0.9, 13.4], [s * 4.0, 0.2, 13.6]);
  }

  // -- bridge tower: stepped, with a canopy band and antenna ---------------
  B([-1.0, 1.4, -13.8], [1.0, 2.5, -10.2]);
  B([-0.8, 2.5, -13.4], [0.8, 3.2, -10.8]);
  B([-0.85, 2.7, -13.55], [0.85, 3.05, -13.3]); // canopy band, proud of the box
  B([-0.5, 3.2, -12.6], [0.5, 3.5, -11.4]);     // roof housing
  B([-0.07, 3.5, -12.1], [0.07, 4.7, -11.9]);   // whip antenna
  M(0.85, 1.15, 1.5, 2.3, -13.2, -12.8);        // side blisters

  // -- scattered greeble plate along the spine and pods --------------------
  for (let z = -13; z < 10; z += 1.3) {
    if (rnd() < 0.5) continue;
    const t = 0.12 + rnd() * 0.2;
    const y = -1.2 + rnd() * 2.2;
    M(1.5, 1.5 + t, y, y + 0.2 + rnd() * 0.4, z, z + 0.3 + rnd() * 0.5);
  }

  return {
    vertexData: new Float32Array(verts),
    indexData: new Uint32Array(indices),
  };
}

// ---------------------------------------------------------------------------
// Geometry primitives shared by the detailed hulls
// ---------------------------------------------------------------------------

/**
 * Deterministic LCG. The Aethon's greeble field is randomly placed but must be
 * the SAME ship every launch — the player learns its silhouette.
 */
export function lcg(seed) {
  let s = seed >>> 0;
  return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296);
}

/**
 * Chamfered-rectangle cross-section, CCW in the XY plane: the rect
 * x ∈ [cx±hw], y ∈ [y0,y1] with its four corners cut back by `ch`. Eight
 * points, so a hull section reads as a bevelled slab instead of a box — the
 * chamfer catches its own light band, which is where the sense of depth in
 * the silhouette actually comes from.
 */
export function chamRect(hw, y0, y1, ch, cx = 0) {
  const c = Math.max(0, Math.min(ch, hw * 0.85, (y1 - y0) * 0.42));
  return [
    [cx + hw, y1 - c], [cx + hw - c, y1], [cx - hw + c, y1], [cx - hw, y1 - c],
    [cx - hw, y0 + c], [cx - hw + c, y0], [cx + hw - c, y0], [cx + hw, y0 + c],
  ];
}

/** Triangle fan closing a ring at plane z; sign = which way the normal faces. */
function ringCap(verts, indices, pts, z, sign, uvScale) {
  const n = pts.length;
  let cx = 0, cy = 0;
  for (const [x, y] of pts) { cx += x; cy += y; }
  cx /= n; cy /= n;
  const c = verts.length / F;
  verts.push(cx, cy, z, 0, 0, sign, cx * uvScale, cy * uvScale);
  for (const [x, y] of pts) verts.push(x, y, z, 0, 0, sign, x * uvScale, y * uvScale);
  for (let i = 0; i < n; i++) {
    const a = c + 1 + i, b = c + 1 + ((i + 1) % n);
    if (sign > 0) indices.push(c, a, b); else indices.push(c, b, a);
  }
}

/**
 * Loft a run of cross-sections into a tube. `sections` = [{z, pts}] ordered
 * fore-to-aft; every ring needs the same point count. Face normals come from
 * the real quad cross product, so a tapering section is lit as the sloped
 * plane it is (flat-shaded, one normal per facet — hard edges, no smoothing).
 * `u` runs along the section perimeter so plating wraps continuously.
 */
export function loft(verts, indices, sections, uvScale, opts = {}) {
  for (let s = 0; s + 1 < sections.length; s++) {
    const A = sections[s], B = sections[s + 1];
    const n = A.pts.length;
    let peri = 0;
    for (let i = 0; i < n; i++) {
      const j = (i + 1) % n;
      const p0 = [A.pts[i][0], A.pts[i][1], A.z];
      const p1 = [A.pts[j][0], A.pts[j][1], A.z];
      const p2 = [B.pts[j][0], B.pts[j][1], B.z];
      const p3 = [B.pts[i][0], B.pts[i][1], B.z];
      const e1 = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]];
      const e2 = [p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]];
      let nx = e1[1] * e2[2] - e1[2] * e2[1];
      let ny = e1[2] * e2[0] - e1[0] * e2[2];
      let nz = e1[0] * e2[1] - e1[1] * e2[0];
      const nl = Math.hypot(nx, ny, nz) || 1; nx /= nl; ny /= nl; nz /= nl;
      const seg = Math.hypot(e1[0], e1[1]);
      const u0 = peri * uvScale, u1 = (peri + seg) * uvScale;
      peri += seg;
      const base = verts.length / F;
      verts.push(p0[0], p0[1], p0[2], nx, ny, nz, u0, A.z * uvScale);
      verts.push(p1[0], p1[1], p1[2], nx, ny, nz, u1, A.z * uvScale);
      verts.push(p2[0], p2[1], p2[2], nx, ny, nz, u1, B.z * uvScale);
      verts.push(p3[0], p3[1], p3[2], nx, ny, nz, u0, B.z * uvScale);
      indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }
  if (opts.capFore) ringCap(verts, indices, sections[0].pts, sections[0].z, -1, uvScale);
  if (opts.capAft) {
    const L = sections[sections.length - 1];
    ringCap(verts, indices, L.pts, L.z, +1, uvScale);
  }
}

/** axis → the two perpendicular axes, cyclically (keeps the basis right-handed). */
const CYC = [[1, 2], [2, 0], [0, 1]];

/**
 * Octagonal frustum along `axis` (0=x, 1=y, 2=z): centred at (a,b) in the
 * other two axes, running s0→s1 with radius r0→r1. `caps`: 0 open (see the
 * inside), 1 far end only, 2 closed. `flip` reverses winding + normals, which
 * turns the tube inside-out — that's how nozzle bells and dish bowls get a
 * visible concave interior instead of a culled hole.
 */
export function octaTube(verts, indices, axis, a, b, s0, s1, r0, r1, uvScale, caps = 2, flip = false, sides = 8) {
  const [ia, ib] = CYC[axis];
  const sg = flip ? -1 : 1;
  const ring = [];
  for (let i = 0; i < sides; i++) {
    const ang = (i / sides) * Math.PI * 2;
    ring.push([Math.cos(ang), Math.sin(ang)]);
  }
  const vp = (rx, ry, s, nx, ny, ns, u, v) => {
    const p = [0, 0, 0], n = [0, 0, 0];
    p[ia] = a + rx; p[ib] = b + ry; p[axis] = s;
    n[ia] = nx * sg; n[ib] = ny * sg; n[axis] = ns * sg;
    verts.push(p[0], p[1], p[2], n[0], n[1], n[2], u, v);
  };
  const circ = (2 * Math.PI * Math.max(r0, r1)) / sides;
  const quad = (base) => (flip
    ? indices.push(base, base + 2, base + 1, base, base + 3, base + 2)
    : indices.push(base, base + 1, base + 2, base, base + 2, base + 3));
  for (let i = 0; i < sides; i++) {
    const [c0, d0] = ring[i], [c1, d1] = ring[(i + 1) % sides];
    const mx = (c0 + c1) / 2, my = (d0 + d1) / 2;
    const ml = Math.hypot(mx, my) || 1;
    let nx = mx / ml, ny = my / ml, ns = (r0 - r1) / ((s1 - s0) || 1);
    const nl = Math.hypot(nx, ny, ns) || 1; nx /= nl; ny /= nl; ns /= nl;
    const base = verts.length / F;
    vp(c0 * r0, d0 * r0, s0, nx, ny, ns, i * circ * uvScale, s0 * uvScale);
    vp(c1 * r0, d1 * r0, s0, nx, ny, ns, (i + 1) * circ * uvScale, s0 * uvScale);
    vp(c1 * r1, d1 * r1, s1, nx, ny, ns, (i + 1) * circ * uvScale, s1 * uvScale);
    vp(c0 * r1, d0 * r1, s1, nx, ny, ns, i * circ * uvScale, s1 * uvScale);
    quad(base);
  }
  const cap = (s, r, sign) => {
    const c = verts.length / F;
    vp(0, 0, s, 0, 0, sign, 0.5, 0.5);
    for (const [cx, cy] of ring) vp(cx * r, cy * r, s, 0, 0, sign, 0.5 + cx * 0.5, 0.5 + cy * 0.5);
    for (let i = 0; i < sides; i++) {
      const p = c + 1 + i, q = c + 1 + ((i + 1) % sides);
      const fwd = sign > 0 !== flip;
      if (fwd) indices.push(c, p, q); else indices.push(c, q, p);
    }
  };
  if (caps >= 1) cap(s1, r1, +1);
  if (caps >= 2) cap(s0, r0, -1);
}

/** Quarter-turn about +z applied to an (x,y) pair. Rotations, never mirrors —
 * a mirror would invert every triangle's winding and cull the whole part. */
function rz(k, x, y) {
  const t = ((k % 4) + 4) % 4;
  if (t === 1) return [-y, x];
  if (t === 2) return [-x, -y];
  if (t === 3) return [y, -x];
  return [x, y];
}

/** Axis-aligned box stamped through a quarter-turn about z (still axis-aligned). */
export function boxR(verts, indices, k, min, max, uvScale) {
  const [ax, ay] = rz(k, min[0], min[1]);
  const [bx, by] = rz(k, max[0], max[1]);
  box(verts, indices,
    [Math.min(ax, bx), Math.min(ay, by), min[2]],
    [Math.max(ax, bx), Math.max(ay, by), max[2]], uvScale);
}

/**
 * Octagonal tube whose axis is the canonical +x direction stamped through a
 * quarter-turn `k` about z — wing-tip pods on all four cruciform arms from one
 * description. Always closed (caps=2) so the two mirrored arms, whose run
 * direction reverses, can't show an open end.
 */
export function octaTubeR(verts, indices, k, s0, s1, r0, r1, a, b, uvScale) {
  const t = ((k % 4) + 4) % 4;
  if (t === 0) octaTube(verts, indices, 0, a, b, s0, s1, r0, r1, uvScale, 2);
  else if (t === 1) octaTube(verts, indices, 1, b, -a, s0, s1, r0, r1, uvScale, 2);
  else if (t === 2) octaTube(verts, indices, 0, -a, b, -s1, -s0, r1, r0, uvScale, 2);
  else octaTube(verts, indices, 1, b, a, -s1, -s0, r1, r0, uvScale, 2);
}

/**
 * Flat quad from four explicit corners, DOUBLE-SIDED — for parts that don't
 * fit an axis-aligned box: window panes following a rake, slanted mullions.
 * Double-sided because the glow mesh is drawn with back-face culling on, and a
 * canopy pane seen edge-on during a roll must not vanish.
 */
function flatQuad(verts, indices, p0, p1, p2, p3, uvs) {
  const e1 = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]];
  const e2 = [p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]];
  let nx = e1[1] * e2[2] - e1[2] * e2[1];
  let ny = e1[2] * e2[0] - e1[0] * e2[2];
  let nz = e1[0] * e2[1] - e1[1] * e2[0];
  const nl = Math.hypot(nx, ny, nz) || 1; nx /= nl; ny /= nl; nz /= nl;
  const uv = uvs ?? [[0, 1], [1, 1], [1, 0], [0, 0]];
  const base = verts.length / F;
  for (let i = 0; i < 4; i++) {
    const p = [p0, p1, p2, p3][i];
    verts.push(p[0], p[1], p[2], nx, ny, nz, uv[i][0], uv[i][1]);
  }
  // double-sided: a canopy pane seen from behind (docking, roll) must still lit
  indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  indices.push(base, base + 2, base + 1, base, base + 3, base + 2);
}

// ---------------------------------------------------------------------------
// HSV Aethon — the player's own hull. Forward = -z.
// ---------------------------------------------------------------------------

/**
 * Fuselage cross-sections fore→aft: [z, halfWidth, yBottom, yTop, chamfer].
 * Deliberately three masses, not one long box: a swollen sensor head, a
 * pinched waist, and a heavy engineering block aft. That silhouette is what
 * makes it read as a working survey vessel rather than a brick.
 */
const AE_SECTIONS = [
  [-44.0, 0.85, -0.70, 0.75, 0.28],
  [-42.6, 1.45, -1.15, 1.25, 0.44],
  [-40.0, 2.20, -1.65, 1.85, 0.60],
  [-36.5, 2.90, -2.05, 2.25, 0.78], // sensor head, widest forward point
  [-33.2, 2.65, -2.00, 2.15, 0.70],
  [-28.0, 2.30, -1.90, 2.00, 0.60], // waist
  [-22.0, 2.50, -2.10, 2.20, 0.66],
  [-14.0, 3.00, -2.60, 2.70, 0.84],
  [-2.00, 3.30, -2.90, 3.00, 0.95], // wing root
  [10.00, 3.10, -2.70, 2.80, 0.90],
  [20.00, 2.90, -2.50, 2.60, 0.80],
  [25.50, 3.55, -3.10, 3.20, 0.82], // engineering block flare
  [38.50, 3.70, -3.30, 3.40, 0.76],
  [41.20, 3.25, -2.90, 3.00, 0.70], // aft bevel
];

/** Linear read of an AE_SECTIONS column at arbitrary z. */
function aeLerp(z, col) {
  let i = 0;
  while (i + 2 < AE_SECTIONS.length && AE_SECTIONS[i + 1][0] < z) i++;
  const A = AE_SECTIONS[i], B = AE_SECTIONS[i + 1];
  const t = Math.max(0, Math.min(1, (z - A[0]) / (B[0] - A[0])));
  return A[col] + (B[col] - A[col]) * t;
}
const aeHalf = (z) => aeLerp(z, 1);
const aeBot = (z) => aeLerp(z, 2);
const aeTop = (z) => aeLerp(z, 3);
const aeCham = (z) => aeLerp(z, 4);
const aeProfile = (z, scale = 1) =>
  chamRect(aeHalf(z) * scale, aeBot(z) * scale, aeTop(z) * scale, aeCham(z));

/**
 * Main drive cluster + verniers, in hull model space. The bells START inside
 * the aft cap (z=41.2) and reach well past it — a bell that stops short of the
 * cap is invisible, which is how the old three "nozzles" ended up buried.
 */
const AE_NOZZLE = { z0: 40.6, z1: 45.8, r0: 1.18, r1: 1.78, y: -0.30, xs: [-2.02, 0, 2.02] };
const AE_VERNIER = { z0: 41.6, z1: 44.6, r0: 0.42, r1: 0.64, y: 1.98, xs: [-1.18, 1.18] };

/**
 * RCS ports: `p` is the throat on the hull skin, `ax` the exhaust direction.
 * Geometry stamps a visible blister at every one of these, and SpaceRenderer
 * fires its cold-gas puffs from the same table — so a jet can never again
 * appear to squirt out of blank plating. Groups are named by what they DO:
 * roll pairs are opposed, the rest push along `ax`.
 */
const AE_RCS = (() => {
  const sideX = (z) => aeHalf(z) + 0.06;
  const port = (x, y, z, ax) => ({ p: [x, y, z], ax });
  return {
    // roll: opposed vertical pairs at the wing roots. Named by the SIGN of the
    // ship-local roll rate they produce, so the renderer needs no sign algebra.
    rollPos: [port(sideX(-1) + 0.05, -0.30, -1, [0, -1, 0]), port(-sideX(-1) - 0.05, 0.30, -1, [0, 1, 0])],
    rollNeg: [port(sideX(-1) + 0.05, 0.30, -1, [0, 1, 0]), port(-sideX(-1) - 0.05, -0.30, -1, [0, -1, 0])],
    // yaw: nose lateral jets. [0] exhausts +x (nose swings to port), [1] the reverse.
    yaw: [port(sideX(-35.4), -0.20, -35.4, [1, 0, 0]), port(-sideX(-35.4), -0.20, -35.4, [-1, 0, 0])],
    // pitch: named by where the NOSE goes. Nose-up needs downward exhaust from
    // a point forward of the centre of mass, i.e. the belly jets.
    noseUp: [port(1.1, aeBot(-30) - 0.06, -30, [0, -1, 0]), port(-1.1, aeBot(-30) - 0.06, -30, [0, -1, 0])],
    noseDown: [port(1.1, aeTop(-30) + 0.06, -30, [0, 1, 0]), port(-1.1, aeTop(-30) + 0.06, -30, [0, 1, 0])],
    // translation: a jet pushes AWAY from its own side, so strafing starboard
    // fires the port-side cluster.
    latStar: [port(sideX(-19), 0.10, -19, [1, 0, 0]), port(sideX(14), 0.10, 14, [1, 0, 0])],
    latPort: [port(-sideX(-19), 0.10, -19, [-1, 0, 0]), port(-sideX(14), 0.10, 14, [-1, 0, 0])],
    vertUp: [port(1.5, aeTop(-7) + 0.06, -7, [0, 1, 0]), port(-1.5, aeTop(22) + 0.06, 22, [0, 1, 0])],
    vertDown: [port(1.5, aeBot(-7) - 0.06, -7, [0, -1, 0]), port(-1.5, aeBot(22) - 0.06, 22, [0, -1, 0])],
    // retro: forward-firing clusters on the fore face of the four wing pylons —
    // the only genuinely forward-facing structure on the ship, so reverse thrust
    // reads as braking instead of the main bells somehow burning backwards.
    retro: [0, 1, 2, 3].map((k) => {
      const [x, y] = rz(k, 3.65, 0);
      return port(x, y, -3.62, [0, 0, -1]);
    }),
  };
})();

/**
 * Anchors the exterior effect layers read so they can never drift from the
 * mesh again. Before this existed the drive plumes were emitting from model
 * z=16.8 — the middle of the hull, 14 world units ahead of the actual bells —
 * which buried every throat core and bloom inside the ship and is why the
 * engines looked like a few loose dots instead of a burn.
 */
export const AETHON_FX = {
  nose: AE_SECTIONS[0][0],
  tail: AE_NOZZLE.z1,
  center: [0, 0, -1.4], // hull midpoint: shield-bubble origin
  shieldHalf: [7.4, 5.8, 27.5],
  nozzles: AE_NOZZLE.xs.map((x) => [x, AE_NOZZLE.y, AE_NOZZLE.z1 - 0.3]),
  nozzleR: AE_NOZZLE.r1,
  verniers: AE_VERNIER.xs.map((x) => [x, AE_VERNIER.y, AE_VERNIER.z1 - 0.2]),
  vernierR: AE_VERNIER.r1,
  rcs: AE_RCS,
  /** Battle-damage vents — on the SKIN, so smoke isn't born inside the hull. */
  wounds: [[aeHalf(6.4) + 0.14, 0.80, 6.4], [-1.80, aeBot(-12) - 0.14, -12.0]],
  /**
   * BREACH VENTS, one per hull section that ShipSystems tracks, each as a point
   * on the skin plus the outward normal the escaping atmosphere follows.
   *
   * `wounds` above is a pair of fixed points that only ever knew the ship's
   * OVERALL integrity, so a shattered bow and a shattered tail smoked from the
   * same two holes amidships. These are keyed to the sections by name, so what
   * you see venting is the section the HUD's damage plan is calling out and the
   * one REPAIR is about to patch. Forward is -z, so the fore vent faces -z.
   */
  sectionVents: {
    fore: [[1.3, aeTop(-31) + 0.12, -31.0], [0.16, 0.42, -0.89]],
    aft: [[-1.5, aeTop(35) + 0.12, 35.0], [-0.14, 0.38, 0.91]],
    port: [[-aeHalf(-4) - 0.14, 0.5, -4.0], [-0.97, 0.12, -0.2]],
    stbd: [[aeHalf(12) + 0.14, -0.4, 12.0], [0.96, -0.14, 0.24]],
    dorsal: [[0.9, aeTop(4) + 0.14, 4.0], [0.1, 0.98, 0.14]],
    ventral: [[-0.7, aeBot(-18) - 0.14, -18.0], [-0.12, -0.97, -0.2]],
  },
  /** Strobe beacons: wing tips + fin tips + mast head. Blink, don't burn. */
  beacons: [[13.9, 0.55, 1.2], [-13.9, -0.55, 1.2], [-0.55, 13.9, 1.2], [0.55, -13.9, 1.2],
    [0, 6.7, -30.5]],
};

/**
 * The HSV Aethon — heavy survey vessel, cruciform, forward = -z, ~87 units
 * nose to bell. Lofted chamfered fuselage rather than stacked boxes: frame
 * bands at every section joint, a raked three-pane canopy with quarter-lights
 * and chin ports, four finned radiator wings on stepped pylons, a gimballed
 * three-bell drive with concave throats and vernier pair, deployable comms
 * dish, dorsal docking collar, magnetometer boom, and a deterministic greeble
 * field of hatches, blisters, conduits and hull plate across every surface.
 *
 * @returns {{hull:{vertexData,indexData}, glow:{vertexData,indexData}}}
 *   hull = sun-lit; glow = emissive (windows / lights / nozzle throats).
 */
/**
 * @typedef {object} HullProfile
 * @property {number} arms      cruciform radiator arms stamped, 0-4
 * @property {number} span      multiplier on how far those arms reach
 * @property {number} nozzles   drive bells lit, 1-3
 */

/**
 * @param {HullProfile} [profile] hull-class silhouette (see data/ShipClasses.js)
 *
 * WHAT VARIES AND WHY ONLY THIS. Every greeble, frame band, canopy pane and RCS
 * blister below is placed at an absolute model coordinate, hand-authored over
 * several sessions. Stretching the section table would slide all of it off the
 * surfaces it belongs to — the frame bands would stop landing on section joints,
 * the RCS blisters would stop matching where the puffs fire from, the canopy
 * would leave the nose. So the profile varies the three things that CAN vary
 * without touching that authored detail and still change a silhouette from a
 * kilometre out: how many arms are stamped, how far they reach, and how many
 * bells are burning. A wingless three-bell hauler and a two-winged single-bell
 * courier do not read as the same ship.
 */
export function buildAethon(profile = {}) {
  const HP = { arms: 4, span: 1, nozzles: 3, ...profile };
  const hv = [], hi = []; // hull (lit)
  const gv = [], gi = []; // glow (emissive)
  // 0.095 -> one plating tile per ~10.5 model units. At 0.16 the 64px tile
  // repeated ~15 times down the hull and the grid was obvious; bigger plates
  // also let more of the painted detail actually read at chase distance.
  // space.frag mirrors and value-steps each tile on top of this.
  const uv = 0.095;
  const H = (min, max, s = uv) => box(hv, hi, min, max, s);
  const G = (min, max, s = uv) => box(gv, gi, min, max, s);
  const rnd = lcg(0x4e73a1); // fixed seed — same ship, every launch
  /**
   * Mirrored box: x extents are written for the STARBOARD side and `s` = ±1
   * flips them. Doing this by hand (`[s*x0 … s*x1]`) silently inverts min/max
   * on the port side, which flips every face's winding and culls the part away
   * — the bug that ate half the greebles in the first pass.
   */
  const HX = (s, x0, x1, y0, y1, z0, z1) =>
    H([Math.min(s * x0, s * x1), y0, z0], [Math.max(s * x0, s * x1), y1, z1]);
  const GX = (s, x0, x1, y0, y1, z0, z1) =>
    G([Math.min(s * x0, s * x1), y0, z0], [Math.max(s * x0, s * x1), y1, z1]);

  // -- 1. fuselage -------------------------------------------------------------
  loft(hv, hi, AE_SECTIONS.map(([z, hw, y0, y1, ch]) =>
    ({ z, pts: chamRect(hw, y0, y1, ch) })), uv, { capFore: true, capAft: true });

  // frame bands standing proud at every section joint: the ribs a real pressure
  // hull is built around, and the only thing that breaks up a 60-unit flank
  for (const z of [-33.2, -28.0, -22.0, -14.0, -2.0, 10.0, 20.0, 25.5]) {
    loft(hv, hi, [
      { z: z - 0.42, pts: aeProfile(z - 0.42, 1.05) },
      { z: z + 0.42, pts: aeProfile(z + 0.42, 1.05) },
    ], uv, { capFore: true, capAft: true });
  }

  // -- 2. dorsal spine + ventral keel -----------------------------------------
  loft(hv, hi, [-30, -22, -12, 0, 10, 20, 25].map((z) =>
    ({ z, pts: chamRect(0.80, aeTop(z) - 0.40, aeTop(z) + 0.66, 0.22) })), uv,
  { capFore: true, capAft: true });
  loft(hv, hi, [-27, -18, -8, 4, 14, 22].map((z) =>
    ({ z, pts: chamRect(0.94, aeBot(z) - 0.58, aeBot(z) + 0.30, 0.24) })), uv,
  { capFore: true, capAft: true });
  // spine equipment blocks + a handrail run along the dorsal walkway. Rail
  // segments are built per-step so they FOLLOW the swelling hull instead of
  // sinking into it amidships (a single long rail box does exactly that).
  for (let z = -26; z < 24; z += 4.2) {
    const yt = aeTop(z) + 0.66;
    H([-0.62, yt, z + 0.3], [0.62, yt + 0.24 + rnd() * 0.3, z + 2.4]);
    for (const s of [-1, 1]) {
      HX(s, 0.86, 1.02, yt - 0.05, yt + 0.52, z + 0.6, z + 0.76);      // stanchion
      HX(s, 0.86, 1.02, yt + 0.44, yt + 0.54, z, z + 4.25);            // rail run
    }
  }

  // -- 3. sensor head: survey pallet under the nose ---------------------------
  // Lofted so it hugs the belly all the way forward; a straight box floats free
  // of the taper at the nose end.
  loft(hv, hi, [-41.0, -38.5, -36.0, -34.0].map((z) => ({
    z, pts: chamRect(Math.min(2.3, aeHalf(z) - 0.3), aeBot(z) - 0.88, aeBot(z) + 0.15, 0.24),
  })), uv, { capFore: true, capAft: true });
  for (const s of [-1, 1]) {
    const pb = aeBot(-38.4) - 0.88; // pallet underside
    octaTube(hv, hi, 1, -38.4, s * 1.25, pb - 0.95, pb + 0.1, 0.92, 0.38, uv, 0);      // dish rim → vertex
    octaTube(hv, hi, 1, -38.4, s * 1.25, pb - 0.90, pb + 0.05, 0.84, 0.32, uv, 0, true); // concave face
    HX(s, 1.18, 1.32, pb - 1.25, pb - 0.85, -38.55, -38.25);                            // feed horn
  }
  H([-1.9, aeBot(-40) - 1.02, -40.6], [1.9, aeBot(-40) - 0.84, -39.2]);  // radar plate
  H([-0.9, aeBot(-37) - 1.05, -37.6], [0.9, aeBot(-37) - 0.8, -36.2]);   // lidar drum shroud
  // magnetometer boom off the nose — the survey cue that reads at any distance
  H([-0.11, -0.11, -50.5], [0.11, 0.11, -43.6]);
  for (const bz of [-49.4, -47.4, -45.4]) H([-0.26, -0.26, bz], [0.26, 0.26, bz + 0.28]);
  H([-0.42, -0.05, -50.9], [0.42, 0.05, -50.4]);           // boom cruciform tip
  H([-0.05, -0.42, -50.9], [0.05, 0.42, -50.4]);

  // -- 4. cockpit canopy: raked, faceted, three panes -------------------------
  // Sections are the OUTER shell; the glass sits a hair proud of the top facets
  // so the panes read as inset glazing in a frame, not decals.
  const CANOPY = [
    [-40.85, 1.50, 1.30, 1.76, 0.20],
    [-39.25, 1.94, 1.25, 2.46, 0.30],
    [-36.85, 2.28, 1.20, 3.06, 0.34],
    [-34.00, 2.42, 1.15, 3.10, 0.34],
    [-31.60, 2.10, 1.10, 2.62, 0.28],
  ];
  loft(hv, hi, CANOPY.map(([z, hw, y0, y1, ch]) =>
    ({ z, pts: chamRect(hw, y0, y1, ch) })), uv, { capFore: true, capAft: true });
  // the rake line the windscreen follows, and the flat width available at each
  const rake = CANOPY.slice(0, 4).map(([z, hw, , y1, ch]) => [z, y1 + 0.05, hw - ch - 0.06]);
  for (let i = 0; i + 1 < rake.length; i++) {
    const [z0, y0, w0] = rake[i], [z1, y1, w1] = rake[i + 1];
    const c0 = Math.min(0.95, w0 - 0.28), c1 = Math.min(0.95, w1 - 0.28);
    // centre pane — wide, trapezoidal, tracking the bend of the rake
    flatQuad(gv, gi, [-c0, y0, z0], [c0, y0, z0], [c1, y1, z1], [-c1, y1, z1]);
    // outboard panes: the corner glazing that makes the forward arc wrap
    for (const s of [-1, 1]) {
      flatQuad(gv, gi, [s * c0, y0, z0], [s * w0, y0 - 0.16, z0],
        [s * w1, y1 - 0.16, z1], [s * c1, y1, z1]);
      // mullion: a real bar between the panes, running the whole rake segment
      flatQuad(hv, hi, [s * c0 - 0.07, y0 + 0.05, z0], [s * c0 + 0.07, y0 + 0.05, z0],
        [s * c1 + 0.07, y1 + 0.05, z1], [s * c1 - 0.07, y1 + 0.05, z1]);
    }
  }
  // transverse frame ribs across the canopy roof, between the panes
  for (const [z, hw, , y1, ch] of CANOPY.slice(0, 4)) {
    H([-(hw - ch), y1 - 0.03, z - 0.11], [hw - ch, y1 + 0.10, z + 0.11]);
  }
  // side quarter-lights: tall slanted flank glazing that follows the canopy
  // flank outward as it widens — this is what turns a boxy windscreen into a
  // wrap-around canopy from outside
  for (const s of [-1, 1]) {
    for (let i = 1; i + 1 < CANOPY.length; i++) {
      const [z0, hw0, , t0, ch0] = CANOPY[i];
      const [z1, hw1, , t1, ch1] = CANOPY[i + 1];
      const x0 = s * (hw0 + 0.03), x1 = s * (hw1 + 0.03);
      flatQuad(gv, gi, [x0, 1.44, z0], [x0, t0 - ch0 - 0.04, z0],
        [x1, t1 - ch1 - 0.04, z1], [x1, 1.44, z1]);
    }
  }
  // overhead observation strip aft of the windscreen (star sights on watch)
  flatQuad(gv, gi, [-1.5, 3.14, -33.9], [1.5, 3.14, -33.9], [1.3, 2.72, -31.8], [-1.3, 2.72, -31.8]);
  // chin ports: downward survey glazing under the nose, in the pallet underside
  for (const s of [-1, 1]) {
    const pb = aeBot(-38) - 0.9;
    flatQuad(gv, gi, [s * 0.3, pb, -40.4], [s * 1.5, pb, -40.0],
      [s * 1.5, pb, -36.4], [s * 0.3, pb, -36.8]);
  }
  // canopy shoulder floodlights, aimed forward over the nose
  for (const s of [-1, 1]) {
    HX(s, 2.0, 2.52, 2.38, 2.86, -35.5, -34.5);
    GX(s, 2.46, 2.6, 2.48, 2.76, -35.42, -35.18);
  }

  // -- 5. porthole rows: framed, inset, staggered ------------------------------
  for (let z = -30; z < 22; z += 4.4) {
    const hw = aeHalf(z + 0.8);
    const y = z < -8 ? 0.25 : -0.15;
    for (const s of [-1, 1]) {
      if (s > 0 && z > -19.5 && z < -13) continue; // starboard airlock lives here
      HX(s, hw - 0.04, hw + 0.13, y - 0.14, y + 1.06, z, z + 1.72);     // frame plate
      GX(s, hw + 0.05, hw + 0.19, y, y + 0.78, z + 0.2, z + 1.5);       // lit pane
      HX(s, hw + 0.03, hw + 0.24, y + 0.4, y + 0.5, z + 0.78, z + 0.94); // mullion, crossing the pane
    }
  }
  // a wider lit compartment window (the mess, per the deck plan), sat between
  // two rows of portholes so nothing overlaps
  for (const s of [-1, 1]) {
    const hw = aeHalf(-8.7);
    HX(s, hw - 0.05, hw + 0.15, -1.5, 0.2, -10.4, -7.0);
    GX(s, hw + 0.06, hw + 0.21, -1.32, 0.02, -10.1, -7.3);
    HX(s, hw + 0.04, hw + 0.26, -0.75, -0.63, -10.4, -7.0);            // mullion
  }

  // -- 6. cruciform radiator wings --------------------------------------------
  // One canonical starboard arm, stamped through four quarter-turns.
  // `arms` picks WHICH quarter-turns are stamped, not just how many: two arms
  // must be the opposed horizontal pair (k = 0 and 2) or the ship grows one wing
  // and a keel. Zero arms leaves a clean wingless hull.
  const ARM_K = HP.arms >= 4 ? [0, 1, 2, 3] : HP.arms === 2 ? [0, 2] : HP.arms === 1 ? [0] : [];
  for (const k of ARM_K) {
    // `span` scales the OUTBOARD x of every wing box. The root pylon keeps its
    // own width so the wing still meets the fuselage where the fuselage is.
    const sp = (v) => (v <= 4.45 ? v : 4.45 + (v - 4.45) * HP.span);
    const B = (min, max, s = uv) =>
      boxR(hv, hi, k, [sp(min[0]), min[1], min[2]], [sp(max[0]), max[1], max[2]], s);
    const GB = (min, max, s = uv) =>
      boxR(gv, gi, k, [sp(min[0]), min[1], min[2]], [sp(max[0]), max[1], max[2]], s);
    // stepped root pylon — thick where it takes the load, tapering outboard
    B([2.85, -1.30, -3.6], [4.45, 1.35, 6.4]);
    B([4.45, -0.95, -2.8], [5.70, 1.00, 5.5]);
    B([3.05, -1.55, -1.6], [4.30, -1.25, 4.2]);      // pylon underslung fairing
    B([3.15, 1.35, -1.2], [4.20, 1.62, 3.8]);        // pylon dorsal cap
    // main spar out to the tip
    B([5.70, -0.44, -2.4], [12.45, 0.44, 4.8]);
    B([5.60, -0.24, -3.6], [12.10, 0.24, -2.4]);     // leading-edge strake
    B([5.60, -0.20, 4.8], [11.60, 0.20, 6.1]);       // trailing blade
    // radiator fins, standing off the spar with real gaps between them
    for (let i = 0; i < 7; i++) {
      const z = -2.1 + i * 0.98;
      B([5.95, 0.44, z], [12.05, 1.14, z + 0.46]);
      B([5.95, -1.14, z], [12.05, -0.44, z + 0.46]);
    }
    B([11.95, -1.22, -2.4], [12.40, 1.22, 5.0]);     // fin end plate
    // coolant lines feeding the panel, with collars
    B([5.75, 0.52, -2.05], [12.30, 0.76, -1.78]);
    B([5.75, -0.76, 4.3], [12.30, -0.52, 4.57]);
    for (let i = 0; i < 4; i++) {
      const x = 6.6 + i * 1.7;
      B([x, 0.46, -2.14], [x + 0.3, 0.84, -1.7]);
      B([x, -0.84, 4.22], [x + 0.3, -0.46, 4.66]);
    }
    // wing-tip nav pod + strobe housing
    octaTubeR(hv, hi, k, sp(12.4), sp(13.75), 0.58, 0.78, 0.0, 1.2, uv);
    octaTubeR(gv, gi, k, sp(13.7), sp(13.98), 0.62, 0.52, 0.0, 1.2, uv);
    GB([13.05, 0.74, 0.9], [13.5, 0.94, 1.5]);       // upper strobe lens
    B([12.9, -1.02, 0.7], [13.6, -0.72, 1.7]);       // lower antenna fairing
    // pylon greebles: junction boxes and a hatch
    B([3.3, -0.6, -3.3], [4.1, 0.1, -2.5]);
    B([4.6, 0.35, 2.2], [5.4, 0.85, 3.6]);
    GB([3.42, -0.42, -3.38], [3.98, -0.16, -3.3]);   // service lamp
  }

  // -- 7. main drive: gimballed bells with concave throats --------------------
  const N = AE_NOZZLE;
  // Bells are lit from the CENTRE out: one bell is the middle one, two are the
  // outboard pair (a single off-axis bell would thrust the ship in a circle,
  // which is funny once).
  const LIT = HP.nozzles >= 3 ? N.xs : HP.nozzles === 2 ? [N.xs[0], N.xs[2]] : [N.xs[1]];
  // Keep the EFFECT anchors in step with the geometry. SpaceRenderer fires the
  // drive plume from AETHON_FX.nozzles, and leaving all three in the table on a
  // one-bell courier would burn two plumes out of solid plating — the exact
  // class of drift the FX-anchor table was introduced to end.
  AETHON_FX.nozzles = LIT.map((x) => [x, N.y, N.z1 - 0.3]);
  for (const nx of LIT) {
    const rAt = (z) => N.r0 + (N.r1 - N.r0) * ((z - N.z0) / (N.z1 - N.z0));
    octaTube(hv, hi, 2, nx, N.y, N.z0, N.z1, N.r0, N.r1, uv, 0);          // bell, outer
    octaTube(hv, hi, 2, nx, N.y, N.z0 + 0.4, N.z1, N.r0 - 0.14, N.r1 - 0.12, uv, 0, true); // liner
    octaTube(gv, gi, 2, nx, N.y, N.z0 + 0.5, N.z1 - 1.1, 0.5, N.r0 - 0.18, uv, 1); // throat glow
    octaTube(hv, hi, 2, nx, N.y, 40.8, 42.0, 1.62, 1.6, uv, 2);           // gimbal collar
    for (const hz of [42.6, 43.8, 45.0]) {                                 // cooling hoops
      octaTube(hv, hi, 2, nx, N.y, hz, hz + 0.22, rAt(hz) + 0.07, rAt(hz) + 0.09, uv, 2);
    }
    for (let i = 0; i < 4; i++) {                                          // feed pipes down the bell
      const a = (i / 4) * Math.PI * 2 + 0.4;
      const px = nx + Math.cos(a) * 1.86, py = N.y + Math.sin(a) * 1.86;
      H([px - 0.12, py - 0.12, 41.0], [px + 0.12, py + 0.12, 44.6]);
    }
    H([nx - 0.55, N.y + 1.62, 41.0], [nx + 0.55, N.y + 2.4, 43.4]);        // turbopump
    H([nx - 0.34, N.y + 2.4, 41.4], [nx + 0.34, N.y + 2.7, 42.9]);
  }
  const V = AE_VERNIER;
  for (const vx of V.xs) {
    octaTube(hv, hi, 2, vx, V.y, V.z0, V.z1, V.r0, V.r1, uv, 0);
    octaTube(hv, hi, 2, vx, V.y, V.z0 + 0.2, V.z1, V.r0 - 0.08, V.r1 - 0.07, uv, 0, true);
    octaTube(gv, gi, 2, vx, V.y, V.z0 + 0.3, V.z1 - 0.6, 0.2, V.r0 - 0.1, uv, 1);
    H([vx - 0.28, V.y + 0.66, 41.3], [vx + 0.28, V.y + 1.3, 43.2]);        // vernier feed block
  }
  // aft bulkhead dressing: heat-exchanger grille, hatches, APU stack
  for (let i = 0; i < 5; i++) H([-2.9 + i * 1.2, 1.6, 41.25], [-2.1 + i * 1.2, 2.7, 41.5]);
  for (const s of [-1, 1]) HX(s, 2.1, 3.05, -2.6, -1.55, 41.25, 41.55);
  H([-0.7, -2.85, 41.0], [0.7, -2.0, 43.2]);                               // APU exhaust stack
  G([-0.52, -2.72, 43.1], [0.52, -2.12, 43.26]);

  // -- 8. comms dish on a stepped mast ---------------------------------------
  H([-0.30, aeTop(-24) + 0.6, -24.35], [0.30, 5.55, -23.75]);              // mast
  H([-0.46, 4.35, -24.5], [0.46, 4.75, -23.6]);                            // mast collar
  H([-0.26, 5.45, -24.4], [0.26, 6.35, -23.9]);                            // yoke
  // bowl opening FORWARD: rim wide at the fore edge, vertex on the yoke
  octaTube(hv, hi, 2, 0, 6.35, -25.0, -23.9, 2.15, 0.55, uv, 0);           // bowl, back face
  octaTube(hv, hi, 2, 0, 6.35, -24.95, -23.95, 2.05, 0.48, uv, 0, true);   // bowl, concave dish
  H([-0.10, 6.25, -26.1], [0.10, 6.45, -24.2]);                            // feed boom, out to focus
  H([-0.26, 6.14, -26.4], [0.26, 6.56, -26.0]);                            // feed horn at the focus
  G([-0.17, 6.24, -26.44], [0.17, 6.46, -26.34]);
  // ventral survey dish, aimed at whatever they're flying over — forward of the
  // ventral fin root so the two don't intersect
  {
    const yb = aeBot(-24);
    octaTube(hv, hi, 1, -24.0, 0, yb - 1.7, yb - 0.5, 1.75, 0.5, uv, 0);
    octaTube(hv, hi, 1, -24.0, 0, yb - 1.65, yb - 0.55, 1.66, 0.44, uv, 0, true);
    H([-0.14, yb - 2.1, -24.14], [0.14, yb - 1.6, -23.86]);                // feed
  }

  // -- 9. antennae, masts, docking collar ------------------------------------
  // whip is aft of the canopy: mounted at the nose it speared the windscreen
  H([-0.09, aeTop(-30.5) + 0.3, -30.6], [0.09, 6.6, -30.4]);               // dorsal whip
  for (const s of [-1, 1]) {
    HX(s, 2.55, 2.72, 0.9, 3.6, 7.0, 7.2);                                 // blade antenna
    HX(s, 2.42, 2.85, 3.4, 3.62, 6.6, 7.6);                                // blade cap
  }
  // dorsal docking collar — the top hatch, with a concave tunnel you can see into
  const dcY = aeTop(-8) + 0.55;
  octaTube(hv, hi, 1, -8.0, 0, dcY, dcY + 1.25, 1.62, 1.42, uv, 0);
  octaTube(hv, hi, 1, -8.0, 0, dcY + 0.05, dcY + 1.3, 1.48, 1.3, uv, 0, true);
  octaTube(hv, hi, 1, -8.0, 0, dcY + 1.2, dcY + 1.42, 1.66, 1.66, uv, 2);  // clamp ring
  for (let i = 0; i < 4; i++) {                                            // capture latches
    const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
    const px = Math.cos(a) * 1.62, pz = -8.0 + Math.sin(a) * 1.62;
    H([px - 0.18, dcY + 0.9, pz - 0.18], [px + 0.18, dcY + 1.6, pz + 0.18]);
  }
  G([-0.22, dcY + 1.44, -8.22], [0.22, dcY + 1.52, -7.78]);                // collar guide light
  // starboard personnel airlock hatch, recessed in a raised surround
  {
    const hw = aeHalf(-16);
    H([hw - 0.05, -1.25, -18.4], [hw + 0.22, 1.35, -14.2]);
    octaTube(hv, hi, 0, -0.05, -16.3, hw + 0.12, hw + 0.42, 1.05, 0.95, uv, 0);
    octaTube(hv, hi, 0, -0.05, -16.3, hw + 0.16, hw + 0.44, 0.92, 0.84, uv, 0, true);
    G([hw + 0.24, 1.05, -18.1], [hw + 0.38, 1.25, -17.5]);                 // hatch status lamp
  }

  // -- 10. conduit runs with segment collars ---------------------------------
  // Segmented per 3.2 units so the pipe follows the hull's swell; one long box
  // sinks into the waist and floats off the wing root.
  for (const s of [-1, 1]) {
    for (const [y, z0, z1, r] of [[-1.15, -30, 24, 0.22], [1.45, -28, 20, 0.17]]) {
      let seg = 0;
      for (let z = z0; z < z1; z += 3.2, seg++) {
        const hw = aeHalf(z + 1.6);
        HX(s, hw - 0.02, hw + r * 1.7, y - r, y + r, z, Math.min(z1, z + 3.3));
        if (seg % 2 === 0) HX(s, hw - 0.04, hw + r * 2.2, y - r * 1.6, y + r * 1.6, z + 1.1, z + 1.7);
      }
    }
  }

  // -- 11. cargo bay doors, belly (recessed seam + hazard strobes) -----------
  // Two panels either side of the ventral keel, aft of the fin root so nothing
  // grows through them.
  {
    const yb = aeBot(14.5);
    for (const s of [-1, 1]) {
      for (const [x0, x1, z0, z1] of [[1.05, 2.24, 8.6, 8.95], [1.05, 2.24, 20.05, 20.4],
        [1.05, 1.32, 8.6, 20.4], [1.97, 2.24, 8.6, 20.4]]) {
        HX(s, x0, x1, yb - 0.17, yb + 0.05, z0, z1);
      }
      for (const z of [9.6, 18.9]) GX(s, 1.44, 1.86, yb - 0.26, yb - 0.14, z, z + 0.5);
      HX(s, 1.2, 1.7, yb - 0.44, yb - 0.12, 13.6, 15.4);                   // door ram housing
    }
  }

  // -- 12. RCS blisters at every port the effects fire from ------------------
  for (const group of Object.values(AE_RCS)) {
    for (const { p, ax } of group) {
      const axis = ax[0] !== 0 ? 0 : ax[1] !== 0 ? 1 : 2;
      const sgn = ax[axis] > 0 ? 1 : -1;
      const [ia, ib] = CYC[axis];
      const base = p[axis] - sgn * 0.36, lip = p[axis] + sgn * 0.05;
      // sorted span + radii keyed to which end is the OUTER lip, so the port
      // side (running "backwards" along its axis) still tapers outward
      const s0 = Math.min(base, lip), s1 = Math.max(base, lip);
      const r0 = sgn > 0 ? 0.44 : 0.3, r1 = sgn > 0 ? 0.3 : 0.44;
      octaTube(hv, hi, axis, p[ia], p[ib], s0, s1, r0, r1, uv, 2);
      octaTube(gv, gi, axis, p[ia], p[ib], s0 + 0.1, s1 - 0.1, r0 * 0.42, r1 * 0.42, uv, 2);
    }
  }

  // -- 13. greeble field: hatches, blisters, plate, cable runs ---------------
  // Deterministic but irregular — regular spacing is what made v1 read as
  // wallpaper. Every stamp sits ON the local skin, inside the flat between the
  // chamfers, so nothing floats and nothing sinks.
  for (let z = -31; z < 24; z += 1.55) {
    const hw = aeHalf(z), ch = aeCham(z);
    const yLo = aeBot(z) + ch + 0.1, yHi = aeTop(z) - ch - 0.5;
    for (const s of [-1, 1]) {
      if (rnd() < 0.34) continue;
      const y = yLo + rnd() * Math.max(0.2, yHi - yLo);
      const dz = 0.3 + rnd() * 1.05, dy = 0.18 + rnd() * 0.62;
      const t = 0.07 + rnd() * 0.2;
      HX(s, hw - 0.03, hw + t, y, y + dy, z, z + dz);
      if (rnd() < 0.22) { // a smaller box stacked on top: two-tier relief
        HX(s, hw + t - 0.01, hw + t + 0.1, y + dy * 0.2, y + dy * 0.75, z + dz * 0.2, z + dz * 0.8);
      }
    }
    // dorsal + ventral plate
    if (rnd() < 0.55) {
      const w = 0.3 + rnd() * 1.5, x = (rnd() - 0.5) * Math.max(0.2, hw - ch - w);
      const yt = aeTop(z);
      H([x - w / 2, yt - 0.03, z], [x + w / 2, yt + 0.08 + rnd() * 0.2, z + 0.4 + rnd() * 1.0]);
    }
    if (rnd() < 0.45) {
      const w = 0.3 + rnd() * 1.4, x = (rnd() - 0.5) * Math.max(0.2, hw - ch - w);
      const yb = aeBot(z);
      H([x - w / 2, yb - 0.08 - rnd() * 0.22, z], [x + w / 2, yb + 0.03, z + 0.4 + rnd() * 0.9]);
    }
  }
  // sensor blisters: octagonal domes scattered on the flanks. Closed drums —
  // the two sides run opposite along +x, so an open end would face inward.
  for (const [z, s, r] of [[-26, 1, 0.5], [-20.5, -1, 0.42], [-11, 1, 0.62],
    [3.5, -1, 0.55], [17, 1, 0.46], [-31.5, -1, 0.38]]) {
    const hw = aeHalf(z);
    const a0 = s * (hw - 0.1), a1 = s * (hw + 0.34);
    octaTube(hv, hi, 0, 0.35, z, Math.min(a0, a1), Math.max(a0, a1),
      s > 0 ? r : r * 0.72, s > 0 ? r * 0.72 : r, uv, 2);
  }
  // hull-number plate + a lit registry panel, port side forward
  {
    const hw = aeHalf(-25);
    HX(-1, hw - 0.04, hw + 0.14, 0.9, 1.9, -26.6, -22.2);
    GX(-1, hw + 0.1, hw + 0.2, 1.06, 1.72, -26.2, -22.7);
  }

  // -- 14. running lights + strobes ------------------------------------------
  // outboard of the spine equipment blocks (x±0.62) and inboard of the
  // stanchions (x±0.86), or the lamps end up buried in the walkway kit
  for (let z = -26; z < 22; z += 4.6) {
    const yt = aeTop(z) + 0.68, yb = aeBot(z) - 0.60;
    for (const s of [-1, 1]) {
      GX(s, 0.68, 0.82, yt, yt + 0.11, z, z + 0.45);
      GX(s, 0.68, 0.82, yb - 0.11, yb, z, z + 0.45);
    }
  }
  // beacon lenses at the tips, matching AETHON_FX.beacons for the strobe FX
  for (const [bx, by, bz] of AETHON_FX.beacons) {
    G([bx - 0.19, by - 0.19, bz - 0.19], [bx + 0.19, by + 0.19, bz + 0.19]);
  }

  // -- 15. themed fittings: stringers, cage lamps, grab rails, whip antennae --
  //
  // The hull had structure and greebles but almost no *ship furniture* — the
  // fittings a crew actually touches. These are the parts that say a person
  // works out here: something to hold onto, something that lights the way, a
  // guard so a boot does not smash a lamp. They also add a third depth tier on
  // the flanks, between the skin and the big equipment blocks.

  // Ribbed transverse stringers: paired bands wrapping the flanks at intervals.
  // The pairing matters — two close ribs with a gutter between them catch two
  // light bands and a shadow, where one rib catches one edge and reads flat.
  for (let z = -28; z < 20; z += 5.7) {
    const hw = aeHalf(z), ch = aeCham(z);
    const yLo = aeBot(z) + ch + 0.06, yHi = aeTop(z) - ch - 0.06;
    if (yHi - yLo < 0.4) continue;
    for (const s of [-1, 1]) {
      HX(s, hw - 0.02, hw + 0.14, yLo, yHi, z, z + 0.22);
      HX(s, hw - 0.02, hw + 0.19, yLo + 0.08, yHi - 0.08, z + 0.3, z + 0.44);
      // gusset feet where the rib lands on the chamfer
      HX(s, hw - 0.02, hw + 0.24, yLo, yLo + 0.14, z - 0.05, z + 0.5);
      HX(s, hw - 0.02, hw + 0.24, yHi - 0.14, yHi, z - 0.05, z + 0.5);
    }
  }

  // Caged floodlamps: a lens with four guard bars standing proud of it, on the
  // dorsal spine and either flank. The cage is the whole point — an unguarded
  // glowing box is a decal, a guarded one is hardware.
  for (const [lz, side] of [[-24, 1], [-13, -1], [-2, 1], [9, -1], [18, 1]]) {
    const hw = aeHalf(lz);
    const y = aeTop(lz) - 0.35;
    HX(side, hw + 0.04, hw + 0.3, y - 0.02, y + 0.3, lz, lz + 0.5);      // housing
    GX(side, hw + 0.28, hw + 0.34, y + 0.03, y + 0.25, lz + 0.06, lz + 0.44); // lens
    for (const gy of [y + 0.02, y + 0.26]) {                              // guard bars
      HX(side, hw + 0.3, hw + 0.42, gy, gy + 0.04, lz + 0.02, lz + 0.48);
    }
    for (const gz of [lz + 0.04, lz + 0.44]) {
      HX(side, hw + 0.3, hw + 0.42, y + 0.02, y + 0.3, gz, gz + 0.04);
    }
  }

  // Grab-rail runs along the dorsal walkway: a rail on stand-off stanchions,
  // broken into segments so it reads as fitted lengths rather than one extrusion.
  for (let z = -22; z < 16; z += 4.2) {
    const yt = aeTop(z) + 0.1;
    for (const s of [-1, 1]) {
      HX(s, 0.92, 1.02, yt + 0.26, yt + 0.34, z, z + 3.4);       // rail
      for (const sz of [z + 0.15, z + 1.7, z + 3.2]) {            // stanchions
        HX(s, 0.94, 1.0, yt, yt + 0.3, sz, sz + 0.08);
      }
    }
  }

  // Whip antennae in staggered clusters — thin, tall, and deliberately not
  // symmetric with each other, so the silhouette gets some noise in it.
  for (const [az, ax, ah] of [[-29.5, 0.55, 1.9], [-29.1, -0.42, 1.35],
    [-19, 0.48, 1.55], [6.5, -0.5, 1.7], [7.1, 0.36, 1.15], [15, 0.44, 1.4]]) {
    const yt = aeTop(az) + 0.1;
    H([ax - 0.035, yt, az], [ax + 0.035, yt + ah, az + 0.07]);
    H([ax - 0.09, yt, az - 0.04], [ax + 0.09, yt + 0.16, az + 0.11]); // base insulator
  }

  // Landing gear (0.34.0). The commission hull had none either, and the survey
  // vessel is the one that most obviously should: it is rated for six and its
  // whole job is to put people on the ground. Four legs, from the shared parts
  // bin so they are the same fitting the other three hulls stand on.
  {
    const k = kitFor(hv, hi, gv, gi, rnd);
    for (const [gx, gz] of [[-2.35, -12.0], [2.35, -12.0], [-2.85, 22.0], [2.85, 22.0]]) {
      k.gear(gx, aeBot(gz) + 0.05, gz, 3.1, 0.85);
    }
    // A nose collar under the chin, and belly hatches over the survey bay.
    k.dockRing([0, aeBot(-26.5) + 0.12, -30.4], 0.86, 2, -1);
    k.hatch(-1.15, aeBot(4) + 0.04, 4.0, 0.5, -1);
    k.hatch(1.15, aeBot(10) + 0.04, 10.0, 0.44, -1);
  }

  return {
    hull: { vertexData: new Float32Array(hv), indexData: new Uint32Array(hi) },
    glow: { vertexData: new Float32Array(gv), indexData: new Uint32Array(gi) },
  };
}

/**
 * Keth fighter — angular, no curves, all blade (context/03 §5): a dart of
 * stacked wedge boxes with forward-swept strake fins. ~9 u long.
 */
export function buildKethFighter() {
  const verts = [];
  const indices = [];
  const uv = 0.2;
  const rnd = lcg(0x4e7401);
  const B = (min, max) => box(verts, indices, min, max, uv);
  /** Mirror a box across the centreline — the Keth are ruthlessly symmetric. */
  const M = (x0, x1, y0, y1, z0, z1) => {
    B([x0, y0, z0], [x1, y1, z1]);
    B([-x1, y0, z0], [-x0, y1, z1]);
  };

  // -- 1. fuselage in three stacked plate layers ------------------------------
  // A single box has one silhouette and one light band. Three concentric slabs
  // of decreasing width give two step lines down the whole length, and every
  // step catches its own shading — this is where the sense of a built machine
  // comes from rather than a shape.
  B([-0.52, -0.44, -4.6], [0.52, 0.44, 2.6]);   // core
  B([-0.66, -0.3, -3.6], [0.66, 0.3, 1.9]);     // mid plating, wider, shallower
  B([-0.4, -0.56, -3.1], [0.4, 0.56, 1.4]);     // keel/dorsal spine, taller
  B([-0.3, 0.5, -2.4], [0.3, 0.72, 0.6]);       // dorsal fairing
  B([-0.22, -0.68, -1.9], [0.22, -0.5, 0.9]);   // ventral fairing

  // -- 2. nose: spike, chin sensor, cheek blades -----------------------------
  B([-0.34, -0.34, -5.7], [0.34, 0.34, -4.5]);  // spike
  B([-0.17, -0.17, -6.5], [0.17, 0.17, -5.6]);  // tip
  B([-0.09, -0.09, -7.1], [0.09, 0.09, -6.4]);  // probe needle
  B([-0.26, -0.46, -5.4], [0.26, -0.24, -4.2]); // chin sensor housing
  M(0.3, 0.62, -0.16, 0.16, -5.2, -3.9);        // cheek blades

  // -- 3. forward-swept wings with root fairings, fences and tip pods --------
  B([-3.3, -0.13, -0.6], [3.3, 0.13, 2.3]);     // main blade
  M(0.55, 1.5, -0.26, 0.26, -0.3, 2.0);         // root fairing, thicker inboard
  M(1.9, 2.1, -0.4, 0.4, 0.3, 1.9);             // wing fence, stands proud
  M(2.95, 3.35, -0.3, 0.3, 0.1, 1.6);           // tip pod
  M(3.05, 3.25, -0.14, 0.14, -0.7, 0.2);        // pod nose spike
  M(1.1, 2.6, -0.3, -0.16, 0.5, 1.7);           // underwing weapon rail
  M(1.5, 1.8, -0.46, -0.28, 0.2, 1.9);          // rail pylon + store

  // -- 4. canards and vertical strakes ---------------------------------------
  B([-2.3, -0.11, -2.3], [2.3, 0.11, -1.2]);
  M(0.5, 1.0, -0.2, 0.2, -2.2, -1.3);           // canard root
  B([-0.13, -1.75, 0.7], [0.13, 1.75, 2.5]);    // vertical strake
  B([-0.2, 1.2, 1.1], [0.2, 1.62, 2.2]);        // upper strake cap
  B([-0.2, -1.62, 1.1], [0.2, -1.2, 2.2]);      // lower strake cap

  // -- 5. twin engine nacelles with intake lips and exhaust rings ------------
  M(0.42, 1.12, -0.34, 0.34, 1.6, 3.5);         // nacelle body
  M(0.5, 1.04, -0.42, 0.42, 1.3, 1.7);          // intake lip, proud of the body
  M(0.34, 1.2, -0.26, 0.26, 3.4, 3.7);          // exhaust ring
  M(0.56, 0.98, -0.16, 0.16, 3.65, 3.9);        // inner bell
  B([-0.62, -0.46, 2.5], [0.62, 0.46, 3.35]);   // centre engine block
  B([-0.5, -0.36, 3.3], [0.5, 0.36, 3.6]);

  // -- 6. greeble field: scattered plate, panels and vents -------------------
  // Deterministic scatter so a Keth wing always looks the same, but irregular
  // enough that the plating never reads as a repeating band.
  for (let z = -4.2; z < 2.4; z += 0.52) {
    if (rnd() < 0.42) continue;
    const t = 0.05 + rnd() * 0.11;
    const h = 0.1 + rnd() * 0.24;
    const y = -0.3 + rnd() * 0.5;
    const dz = 0.16 + rnd() * 0.38;
    M(0.5, 0.5 + t, y, y + h, z, z + dz);       // flank plate
    if (rnd() < 0.4) B([-0.24, 0.42, z], [0.24, 0.42 + t + 0.06, z + dz]); // dorsal
    if (rnd() < 0.32) B([-0.2, -0.46 - t, z], [0.2, -0.42, z + dz * 0.8]); // ventral
  }
  return { vertexData: new Float32Array(verts), indexData: new Uint32Array(indices) };
}

/**
 * Keth corvette — the faction's line warship, and the first hostile big enough
 * that you cannot simply out-turn it. ~34 u long against the fighter's 14.
 *
 * Design brief from `context/03` §5: the Keth build blades, not boxes. A capital
 * hull cannot be a blade, so it is a STACK of them — a deep central keel with
 * swept dorsal and ventral blades running its length, and everything hung off
 * that spine. What makes it read as a warship rather than a big fighter is the
 * visible ordnance: four turret barbettes with real barrels, two missile cell
 * blocks, and a battery of point-defence stubs along both flanks.
 */
export function buildKethCorvette() {
  const verts = [];
  const indices = [];
  const uv = 0.13;
  const rnd = lcg(0x4e7c02);
  const B = (min, max) => box(verts, indices, min, max, uv);
  const M = (x0, x1, y0, y1, z0, z1) => {
    B([x0, y0, z0], [x1, y1, z1]);
    B([-x1, y0, z0], [-x0, y1, z1]);
  };

  // -- 1. keel: five stacked slabs of decreasing width ----------------------
  // Five step lines run the full 34 units, and every one catches its own shading.
  B([-2.1, -1.5, -17], [2.1, 1.5, 13]);      // core
  B([-2.7, -0.9, -14], [2.7, 0.9, 10]);      // mid belt, wider
  B([-1.5, -2.3, -12], [1.5, 2.3, 9]);       // spine, taller
  B([-1.0, 2.2, -9], [1.0, 3.1, 6]);         // dorsal blade root
  B([-0.8, -3.0, -8], [0.8, -2.2, 5]);       // ventral blade root

  // -- 2. swept dorsal and ventral blades -----------------------------------
  B([-0.5, 3.0, -7], [0.5, 5.4, 2]);         // dorsal fin
  B([-0.35, 5.3, -4], [0.35, 6.4, 0.5]);     // fin tip
  B([-0.45, -5.0, -6], [0.45, -2.9, 1]);     // ventral fin
  M(0.5, 3.4, -0.4, 0.4, -6, 4);             // lateral blades
  M(3.2, 4.0, -0.9, 0.9, -3, 2.5);           // blade tip pods
  M(1.4, 1.9, -1.1, 1.1, -8, 5);             // blade root fairings

  // -- 3. prow: ram, sensor cluster, chin battery ---------------------------
  B([-1.5, -1.1, -20], [1.5, 1.1, -16.6]);
  B([-0.9, -0.7, -22.4], [0.9, 0.7, -19.8]);
  B([-0.45, -0.35, -23.8], [0.45, 0.35, -22.2]);  // ram spike
  M(1.0, 1.9, -0.45, 0.45, -19.5, -16.0);         // cheek blades
  B([-1.0, -1.8, -19.2], [1.0, -1.0, -16.4]);     // chin sensor block
  B([-0.6, -2.1, -18.6], [0.6, -1.7, -17.2]);     // and its lens housing

  // -- 4. TURRET BARBETTES: the thing that says warship ---------------------
  // Each is a base ring, a rotating drum standing proud of it, and twin barrels
  // extending past the drum — four depth tiers on every one.
  const turret = (x, y, z, up) => {
    const s = up ? 1 : -1;
    B([x - 1.15, y, z - 1.15], [x + 1.15, y + s * 0.45, z + 1.15]);           // barbette ring
    B([x - 0.85, y + s * 0.4, z - 0.85], [x + 0.85, y + s * 1.35, z + 0.85]); // drum
    for (const dx of [-0.34, 0.34]) {                                          // twin barrels
      B([x + dx - 0.12, y + s * 0.65, z - 2.6], [x + dx + 0.12, y + s * 1.05, z - 0.6]);
    }
    B([x - 0.5, y + s * 1.3, z - 0.5], [x + 0.5, y + s * 1.65, z + 0.5]);     // cupola
  };
  turret(0, 3.05, -5.5, true);
  turret(0, 3.05, 3.0, true);
  turret(0, -2.95, -3.5, false);
  turret(0, -2.95, 4.5, false);

  // -- 5. missile cell blocks, port and starboard ---------------------------
  for (const s of [-1, 1]) {
    B([s * 1.5, 0.4, -2.5], [s * 2.9, 1.9, 4.5]);        // block
    for (let i = 0; i < 4; i++) {                          // individual cell hatches
      const cz = -2.0 + i * 1.7;
      B([s * 1.55, 1.85, cz], [s * 2.85, 2.05, cz + 1.2]);
      B([s * 1.75, 2.02, cz + 0.25], [s * 2.65, 2.16, cz + 0.95]); // hatch lip, proud
    }
  }

  // -- 6. point-defence stub battery down both flanks ----------------------
  for (let z = -13; z < 8; z += 2.4) {
    for (const s of [-1, 1]) {
      const y = ((z | 0) % 2) ? 0.55 : -0.55;
      B([s * 2.6, y - 0.2, z], [s * 3.05, y + 0.2, z + 0.5]);       // mount
      B([s * 2.9, y - 0.09, z + 0.1], [s * 3.5, y + 0.09, z + 0.32]); // barrel
    }
  }

  // -- 7. drive block: four bells in a stepped housing ---------------------
  B([-2.4, -1.9, 12], [2.4, 1.9, 16]);
  B([-2.0, -1.6, 16], [2.0, 1.6, 17.2]);
  for (const [bx, by] of [[-1.15, 0.8], [1.15, 0.8], [-1.15, -0.8], [1.15, -0.8]]) {
    B([bx - 0.62, by - 0.62, 17.0], [bx + 0.62, by + 0.62, 18.4]);   // bell
    B([bx - 0.42, by - 0.42, 18.3], [bx + 0.42, by + 0.42, 18.9]);   // throat
  }
  M(2.35, 3.3, -0.25, 0.25, 12.5, 15.5);   // radiator fins
  M(2.35, 3.0, -0.9, 0.9, 13.0, 13.3);

  // -- 8. bridge tower and mast --------------------------------------------
  B([-1.2, 1.4, -11.5], [1.2, 2.4, -8.0]);
  B([-0.95, 2.35, -11.0], [0.95, 3.0, -8.6]);
  B([-1.0, 2.6, -11.2], [1.0, 2.9, -10.9]);   // canopy band, proud of the box
  B([-0.09, 3.0, -10.2], [0.09, 4.9, -10.0]); // mast
  M(0.6, 0.85, 3.0, 3.9, -10.6, -10.2);       // yardarm sensors

  // -- 9. greeble plate along the flanks -----------------------------------
  for (let z = -15; z < 11; z += 1.15) {
    if (rnd() < 0.45) continue;
    const t = 0.1 + rnd() * 0.2;
    const h = 0.25 + rnd() * 0.6;
    const y = -1.2 + rnd() * 1.8;
    M(2.7, 2.7 + t, y, y + h, z, z + 0.35 + rnd() * 0.6);
    if (rnd() < 0.3) B([-1.4, 2.28, z], [1.4, 2.28 + t + 0.1, z + 0.5]); // dorsal
  }
  return { vertexData: new Float32Array(verts), indexData: new Uint32Array(indices) };
}

/**
 * Drift drone — crystalline machine-race scout: an offset cluster of shards
 * around a core, nothing symmetric, nothing aerodynamic. ~6 u across.
 */
export function buildDriftDrone() {
  const verts = [];
  const indices = [];
  const uv = 0.25;
  const rnd = lcg(0xd21f7);
  const B = (min, max) => box(verts, indices, min, max, uv);

  // -- 1. faceted core: three nested masses on offset axes -------------------
  // The Drift are a machine race that grew rather than being built, so the core
  // is a crystal habit — concentric, but never concentric on the same centre.
  B([-1.15, -1.15, -1.15], [1.15, 1.15, 1.15]);
  B([-0.86, -1.42, -0.9], [0.94, 1.38, 1.0]);
  B([-1.38, -0.82, -0.78], [1.44, 0.9, 0.86]);
  B([-0.55, -0.55, -1.5], [0.6, 0.6, 1.55]);

  /**
   * A shard with its own SUB-SHARD stacked on it and a filament strut back to
   * the core. Two-tier relief on every limb is what makes the cluster read as
   * grown crystal rather than a handful of loose boxes: each shard has a step
   * line and a shadow of its own before the silhouette even starts.
   */
  const shard = (min, max, sub) => {
    B(min, max);
    // sub-shard on a random face, inset from the parent's edges
    const ax = sub % 3;
    const lo = [...min], hi = [...max];
    const span = [max[0] - min[0], max[1] - min[1], max[2] - min[2]];
    for (let i = 0; i < 3; i++) {
      if (i === ax) continue;
      lo[i] += span[i] * (0.18 + rnd() * 0.2);
      hi[i] -= span[i] * (0.18 + rnd() * 0.2);
    }
    if (sub & 1) { lo[ax] = max[ax] - span[ax] * 0.08; hi[ax] = max[ax] + span[ax] * (0.3 + rnd() * 0.4); }
    else { hi[ax] = min[ax] + span[ax] * 0.08; lo[ax] = min[ax] - span[ax] * (0.3 + rnd() * 0.4); }
    B([Math.min(lo[0], hi[0]), Math.min(lo[1], hi[1]), Math.min(lo[2], hi[2])],
      [Math.max(lo[0], hi[0]), Math.max(lo[1], hi[1]), Math.max(lo[2], hi[2])]);
    // filament strut from the shard's inboard face toward the core
    const cx = (min[0] + max[0]) / 2, cy = (min[1] + max[1]) / 2, cz = (min[2] + max[2]) / 2;
    const k = 0.09;
    B([Math.min(cx * 0.2, cx) - k, Math.min(cy * 0.2, cy) - k, Math.min(cz * 0.2, cz) - k],
      [Math.max(cx * 0.2, cx) + k, Math.max(cy * 0.2, cy) + k, Math.max(cz * 0.2, cz) + k]);
  };

  // -- 2. the shard cluster — nothing symmetric, nothing aerodynamic --------
  shard([0.6, 0.6, -3.1], [1.5, 1.5, 0.2], 0);
  shard([-2.1, -0.45, 0.4], [-0.7, 0.55, 2.8], 1);
  shard([-0.55, 1.0, 0.8], [0.35, 2.8, 1.7], 2);
  shard([-0.35, -2.7, -1.0], [0.45, -0.9, -0.15], 3);
  shard([1.25, -1.45, 0.9], [2.7, -0.5, 1.8], 4);
  shard([-1.9, 0.7, -2.2], [-0.8, 1.7, -0.6], 5);
  shard([0.9, -0.3, 1.9], [1.7, 0.7, 3.2], 0);
  shard([-0.9, -1.9, 1.2], [-0.1, -0.8, 2.4], 2);

  // -- 3. micro-facets: small chips clinging to the core ---------------------
  for (let i = 0; i < 22; i++) {
    const a = rnd() * Math.PI * 2, b = (rnd() - 0.5) * 2.2;
    const r = 1.05 + rnd() * 0.35;
    const x = Math.cos(a) * r, y = b * 0.8, z = Math.sin(a) * r;
    const s = 0.08 + rnd() * 0.19;
    B([x - s, y - s, z - s], [x + s, y + s * 1.6, z + s]);
  }
  return { vertexData: new Float32Array(verts), indexData: new Uint32Array(indices) };
}

/**
 * Build the player hull for a class id, and point the shared FX anchor table at
 * it.
 *
 * `AETHON_FX` is a module singleton because there is exactly one player ship at
 * a time and `SpaceRenderer` imports it directly. Rewriting its fields in place
 * — rather than threading a per-hull table through the twenty-odd places the
 * renderer reads it — keeps the whole exterior FX layer hull-agnostic. The
 * critical part is that the anchors are swapped IN THE SAME CALL as the mesh:
 * an anchor table that can be out of step with the geometry it belongs to is
 * how the drive plumes ended up burning out of the middle of the hull once
 * already.
 */
export async function buildPlayerHull(classId) {
  if (!classId || classId === 'aethon') {
    Object.assign(AETHON_FX, AETHON_FX_BASE);
    return buildAethon();
  }
  const M = await import('./HullModels.js');
  const built = classId === 'petrel' ? M.buildPetrel()
    : classId === 'drayman' ? M.buildDrayman()
      : classId === 'harrier' ? M.buildHarrier() : null;
  if (!built) { Object.assign(AETHON_FX, AETHON_FX_BASE); return buildAethon(); }
  Object.assign(AETHON_FX, built.fx, { sectionVents: M.ventsFor(built.fx) });
  return { hull: built.hull, glow: built.glow };
}

/** Pristine copy of the Aethon anchors, so switching back restores them. */
const AETHON_FX_BASE = { ...AETHON_FX };
