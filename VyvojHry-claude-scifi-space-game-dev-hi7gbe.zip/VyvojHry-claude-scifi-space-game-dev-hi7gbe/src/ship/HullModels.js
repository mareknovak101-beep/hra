/**
 * HULL MODELS — the three non-Aethon player ships, as their own meshes.
 *
 * 0.25.0 gave the classes different silhouettes by varying the Aethon's arm
 * count, wing span and bell count. That was the safe move at the time and the
 * owner's answer was the right one: they are supposed to be different SHIPS,
 * not the same ship with fewer wings. So each hull here is authored from
 * scratch, with its own construction logic rather than its own parameters.
 *
 * The three read differently because they are built from different ideas:
 *
 *   PETREL   a NEEDLE. One continuous lofted taper from a bubble canopy at the
 *            tip to a single bell, with swept canards well forward and a lone
 *            dorsal fin. No cruciform, no radiator panels, nothing bolted on
 *            that could be left off. It is an airframe.
 *   DRAYMAN  a SPINE. There is no fuselage at all: an open lattice keel with
 *            six cargo containers clamped along it, a boxy tug head at the
 *            front and four bells in a square cluster at the back. The shape is
 *            the cargo, and you can see space between the parts.
 *   HARRIER  a WEDGE. A flattened delta blended wing-body with twin tail booms,
 *            the bells slung between them, a chin sensor blister and hardpoints
 *            under the wing. Wide and low where the others are tall and narrow.
 *
 * Model convention, shared with `buildAethon`: forward is -z, +y is up, and the
 * mesh is authored in the same units, so `SHIP_CHASE_SCALE` and the collision
 * radius need no per-hull adjustment.
 *
 * Each builder returns its FX anchor table alongside the geometry rather than
 * writing a module global. The anchors are what the renderer fires drive
 * plumes, RCS puffs, breach vents, damage smoke and beacons from, and the
 * lesson from the session that introduced `AETHON_FX` is that anchors kept
 * anywhere other than beside the geometry they belong to will drift from it.
 */
import { box, chamRect, loft, octaTube, lcg } from './ShipExterior.js';
import { kit } from './HullDetail.js';

const UV = 0.095; // one plating tile per ~10.5 model units, same as the Aethon

/** Mirrored box: x written for STARBOARD, `s` = ±1 flips and re-sorts. */
function mirror(v, i, s, x0, x1, y0, y1, z0, z1) {
  box(v, i, [Math.min(s * x0, s * x1), y0, z0], [Math.max(s * x0, s * x1), y1, z1], UV);
}

/**
 * KSV PETREL — light dispatch hull.
 *
 * A needle: 62 units of continuous taper with nothing bolted to it. The whole
 * design argument is that every gram is airframe, so there is no cruciform
 * radiator, no engineering block and no cargo flare — the things that make the
 * Aethon read as a working vessel are exactly what a courier does not carry.
 */
export function buildPetrel() {
  const hv = [], hi = [], gv = [], gi = [];
  const H = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, UV);
  const rnd = lcg(0x9e3f11);

  // -- 1. the needle ---------------------------------------------------------
  // A single loft from a sharp nose to the drive throat. The section list is
  // deliberately short and monotonic: any waist or flare would start to read as
  // "fuselage with modules", which is the Aethon's language, not this one.
  const SEC = [
    [-31.0, 0.34, -0.30, 0.34, 0.14],
    [-28.5, 0.72, -0.62, 0.70, 0.26],
    [-24.0, 1.15, -0.98, 1.12, 0.40],
    [-17.0, 1.52, -1.28, 1.55, 0.52],  // canopy shoulder
    [-8.0, 1.74, -1.46, 1.70, 0.58],
    [4.0, 1.80, -1.52, 1.74, 0.60],   // widest point, well aft of centre
    [14.0, 1.62, -1.38, 1.56, 0.54],
    [22.5, 1.30, -1.12, 1.26, 0.44],
    [27.0, 1.08, -0.94, 1.04, 0.36],   // drive throat
  ];
  loft(hv, hi, SEC.map(([z, hw, y0, y1, ch]) => ({ z, pts: chamRect(hw, y0, y1, ch) })),
    UV, { capFore: true, capAft: true });

  // -- 2. bubble canopy ------------------------------------------------------
  // Set INTO the spine right at the tip, not raised on a tower. On a hull this
  // slim the pilot sits in the nose and the glass wraps them.
  G([-0.86, 0.62, -25.6], [0.86, 1.48, -19.4]);          // glass
  H([-0.98, 0.50, -26.0], [-0.80, 1.58, -19.0]);          // port mullion
  H([0.80, 0.50, -26.0], [0.98, 1.58, -19.0]);            // starboard mullion
  H([-0.98, 1.44, -26.0], [0.98, 1.62, -19.0]);           // brow
  for (let i = 0; i < 3; i++) {                            // pane dividers
    const z = -24.4 + i * 1.7;
    H([-0.9, 0.56, z], [0.9, 1.54, z + 0.16]);
  }

  // -- 3. canards, well forward ----------------------------------------------
  // Swept sharply back and set high. Two of them, horizontal only — a courier
  // has no reason to carry a ventral surface it would land on.
  for (const s of [-1, 1]) {
    mirror(hv, hi, s, 1.5, 5.6, 0.30, 0.62, -21.5, -17.0);
    mirror(hv, hi, s, 5.6, 7.9, 0.34, 0.58, -19.8, -16.6);
    mirror(hv, hi, s, 7.9, 8.9, 0.38, 0.54, -18.6, -16.4);  // clipped tip
    mirror(hv, hi, s, 1.7, 3.4, 0.62, 0.86, -20.6, -18.4);  // root fairing
    // tip strobe
    box(gv, gi, [Math.min(s * 8.5, s * 8.9), 0.40, -17.6],
      [Math.max(s * 8.5, s * 8.9), 0.52, -17.0], UV);
  }

  // -- 4. one dorsal fin -----------------------------------------------------
  // Tall, thin, raked. It is the only thing that breaks the silhouette above
  // the spine, which is what makes the ship read as an arrow rather than a rod.
  H([-0.22, 1.60, 8.0], [0.22, 6.20, 20.5]);
  H([-0.30, 1.55, 10.5], [0.30, 3.20, 21.5]);              // thicker root
  H([-0.16, 5.60, 14.0], [0.16, 6.55, 20.0]);              // tip cap
  G([-0.20, 6.20, 17.8], [0.20, 6.42, 18.8]);              // fin strobe
  // ventral strake, short, purely to keep the tail from looking top-heavy
  H([-0.20, -1.60, 12.0], [0.20, -2.90, 21.0]);

  // -- 5. single drive -------------------------------------------------------
  // One bell, on the axis, big relative to the hull. The courier's whole claim
  // is thrust-to-mass and the engine should look like it.
  octaTube(hv, hi, 2, 0, 0.0, 26.4, 32.6, 1.06, 1.62, UV, 0);   // bell
  octaTube(hv, hi, 2, 0, 0.0, 27.4, 32.2, 0.86, 1.34, UV, 0, true); // throat
  octaTube(gv, gi, 2, 0, 0.0, 31.4, 32.4, 0.78, 1.18, UV, 1);  // glow disc
  for (let i = 0; i < 4; i++) {                                 // gimbal ribs
    const a = (i / 4) * Math.PI * 2;
    const x = Math.cos(a) * 1.3, y = Math.sin(a) * 1.3;
    H([x - 0.14, y - 0.14, 26.6], [x + 0.14, y + 0.14, 29.2]);
  }

  // -- 6. greebles: a courier is maintained, not refitted ---------------------
  for (let i = 0; i < 16; i++) {
    const z = -14 + rnd() * 36;
    const s = rnd() < 0.5 ? -1 : 1;
    const w = 0.24 + rnd() * 0.5;
    mirror(hv, hi, s, 1.5, 1.5 + 0.22, -0.3 + rnd() * 0.9, -0.3 + rnd() * 0.9 + w, z, z + 0.6 + rnd());
  }
  H([-0.6, 1.72, -4.0], [0.6, 2.05, 1.5]);                 // dorsal comms blister
  H([-1.2, -1.55, -6.0], [1.2, -1.86, 2.0]);               // belly radiator strip
  for (let i = 0; i < 5; i++) H([-1.1 + i * 0.5, -1.90, -5.4], [-0.9 + i * 0.5, -1.72, 1.4]);
  G([-0.24, 1.88, -3.2], [0.24, 2.02, -2.6]);              // beacon

  // -- 7. refit: the fittings a courier actually carries ----------------------
  // 0.34.0. The needle was the right silhouette and a bare one — at chase
  // distance it read as a shape rather than a machine. Everything below is from
  // the shared parts bin (HullDetail), so the Petrel's collar, lamps and rails
  // are visibly the same yard hardware bolted to the other three hulls.
  const k = kit(hv, hi, gv, gi, rnd);

  // Landing gear. Nothing on the register had feet until now, which was
  // conspicuous the moment 0.33.0 let you put a hull down on a planet. A
  // courier's are minimal: a nose leg and two short mains close to the axis.
  k.gear(0, -1.14, -19.5, 1.5, 0);
  k.gear(-1.15, -1.42, 7.5, 1.75, 0.55);
  k.gear(1.15, -1.42, 7.5, 1.75, 0.55);

  // Dorsal docking collar, aft of the canopy. The nose is full of glass, so
  // this hull mates spine-up — which also means you see the collar from the
  // chase camera, where a nose ring would be hidden by the ship itself.
  k.dockRing([0, 1.76, -12.4], 0.62, 1, 1);

  // Comms mast: a courier is paid to be reachable.
  k.mast(0, 1.78, 3.4, 2.5, true);
  k.pod(8.3, 0.46, -21.4, 0.22, 0.62);      // canard-tip sensor pods
  k.pod(-8.3, 0.46, -21.4, 0.22, 0.62);

  // Belly pannier: the only cargo this hull carries, hung where it does not
  // spoil the line. A courier with nowhere to put anything still has to.
  k.pod3(-0.92, -2.55, 2.0, 0.92, -1.52, 11.5);

  // Worked-on surfaces: spine rails, hatches, flank plates, patched plating.
  k.rail(0.86, 1.70, -8.0, 6.0);
  k.rail(-0.86, 1.70, -8.0, 6.0);
  k.hatch(0.52, 1.76, 9.6, 0.34, 1);
  k.hatch(-0.52, 1.76, 13.2, 0.30, 1);
  k.hatch(0, -1.52, -8.6, 0.32, -1);
  for (const s of [-1, 1]) {
    k.plate(s, 1.66, 0.10, -13.6, 2.4, 0.72);
    k.flood(s * 1.62, -0.55, -15.5, [s, 0, 0]);
    k.wear(s, 1.62, -0.9, 1.2, -16.0, 22.0, 7);
  }
  k.pipes(1.28, -1.05, 12.0, 25.6, 0.10, 2);   // fuel gallery, run outboard

  return {
    hull: { vertexData: new Float32Array(hv), indexData: new Uint32Array(hi) },
    glow: { vertexData: new Float32Array(gv), indexData: new Uint32Array(gi) },
    fx: {
      nose: -31.0, tail: 32.6, center: [0, 0, 0],
      shieldHalf: [9.4, 6.8, 33.0],
      nozzles: [[0, 0, 32.3]], nozzleR: 1.62,
      verniers: [[-0.9, 1.5, 31.0], [0.9, 1.5, 31.0]], vernierR: 0.34,
      rcs: rcsFor(1.8, -26, 24, 1.6),
      wounds: [[1.6, 0.5, 2.0], [-1.0, -1.5, -9.0]],
      beacons: [[8.7, 0.46, -17.3], [-8.7, 0.46, -17.3], [0, 6.3, 18.3], [0, 2.0, -2.9]],
    },
  };
}

/**
 * KSV DRAYMAN — heavy lift hull.
 *
 * A spine, not a fuselage. Everything hangs off an open lattice keel with gaps
 * you can see through, which is the one silhouette on the register that cannot
 * be mistaken for any of the others: the Aethon and the Petrel are solid
 * volumes, and this is a frame with boxes clamped to it.
 */
export function buildDrayman() {
  const hv = [], hi = [], gv = [], gi = [];
  const H = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, UV);
  const rnd = lcg(0x3ad10c);

  // -- 1. the keel -----------------------------------------------------------
  // Four longerons in a square, cross-braced. The gaps between them are the
  // point: this is the only player hull you can see stars through.
  const K = 1.55; // longeron offset from the axis
  for (const [sx, sy] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
    H([sx * K - 0.30, sy * K - 0.30, -22.0], [sx * K + 0.30, sy * K + 0.30, 34.0]);
  }
  for (let i = 0; i < 13; i++) {           // ring frames
    const z = -21.0 + i * 4.3;
    for (const [ax, ay] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const x0 = ax ? ax * K - 0.22 : -K - 0.22, x1 = ax ? ax * K + 0.22 : K + 0.22;
      const y0 = ay ? ay * K - 0.22 : -K - 0.22, y1 = ay ? ay * K + 0.22 : K + 0.22;
      H([Math.min(x0, x1), Math.min(y0, y1), z], [Math.max(x0, x1), Math.max(y0, y1), z + 0.44]);
    }
    // diagonal brace, alternating hand so the lattice reads as trussed
    const d = i % 2 ? 1 : -1;
    H([-K, d * K - 0.18, z + 0.4], [K, d * K + 0.18, z + 2.1]);
  }

  // -- 2. tug head -----------------------------------------------------------
  // A blunt box with a slab canopy. No taper at all — nothing about this ship
  // pretends to be aerodynamic and the nose is where you notice that first.
  H([-3.30, -2.90, -30.5], [3.30, 3.10, -21.0]);
  H([-3.55, -2.40, -29.0], [3.55, 2.30, -23.0]);           // side sponsons
  H([-2.60, 3.10, -29.0], [2.60, 3.90, -23.5]);            // brow block
  G([-2.20, 0.60, -30.62], [2.20, 2.35, -30.5]);           // slab windscreen
  H([-2.40, 0.40, -30.7], [-1.95, 2.55, -30.46]);          // mullions
  H([1.95, 0.40, -30.7], [2.40, 2.55, -30.46]);
  H([-0.24, 0.45, -30.7], [0.24, 2.50, -30.46]);
  H([-2.40, 2.35, -30.72], [2.40, 2.62, -30.42]);          // sun visor
  for (let i = 0; i < 4; i++) {                             // bumper ribs
    H([-3.4, -2.95 + i * 0.1, -30.9], [3.4, -2.72 + i * 0.1, -30.2]);
  }
  G([-0.5, -2.05, -30.9], [0.5, -1.75, -30.6]);            // docking lamp

  // -- 3. six cargo containers, clamped along the spine ----------------------
  // Not identical: sizes and vertical offsets vary, and one bay is EMPTY, which
  // does more for "this is a working hauler" than any amount of surface detail.
  const BAYS = [
    [-18.0, -9.5, 4.6, 3.9, 0.2],
    [-9.0, -0.5, 4.9, 4.2, -0.1],
    [0.0, 8.5, 4.6, 3.9, 0.3],
    [9.0, 16.0, 0, 0, 0],            // empty: clamps only
    [16.5, 24.0, 4.3, 3.6, -0.2],
    [24.5, 31.5, 4.9, 4.0, 0.1],
  ];
  for (const [z0, z1, w, h, dy] of BAYS) {
    // clamps are always there, cargo or not
    for (const z of [z0 + 0.5, z1 - 0.9]) {
      H([-2.15, -2.15, z], [2.15, -1.75, z + 0.4]);
      H([-2.15, 1.75, z], [2.15, 2.15, z + 0.4]);
      H([-2.15, -2.15, z], [-1.75, 2.15, z + 0.4]);
      H([1.75, -2.15, z], [2.15, 2.15, z + 0.4]);
    }
    if (w <= 0) continue;
    const hw = w / 2, hh = h / 2;
    H([-hw, dy - hh, z0 + 0.3], [hw, dy + hh, z1 - 0.3]);
    // corrugation: vertical ribs down both flanks, the container's whole texture
    for (let i = 0; i < 9; i++) {
      const z = z0 + 0.7 + i * ((z1 - z0 - 1.4) / 8);
      H([-hw - 0.12, dy - hh + 0.3, z], [-hw, dy + hh - 0.3, z + 0.28]);
      H([hw, dy - hh + 0.3, z], [hw + 0.12, dy + hh - 0.3, z + 0.28]);
    }
    // corner castings, top rail and a stencil plate
    for (const [cx, cy] of [[-hw, dy - hh], [hw - 0.5, dy - hh], [-hw, dy + hh - 0.5], [hw - 0.5, dy + hh - 0.5]]) {
      H([cx, cy, z0 + 0.2], [cx + 0.5, cy + 0.5, z0 + 0.7]);
      H([cx, cy, z1 - 0.7], [cx + 0.5, cy + 0.5, z1 - 0.2]);
    }
    H([-hw + 0.4, dy + hh, z0 + 1.0], [hw - 0.4, dy + hh + 0.22, z1 - 1.0]);
    G([-0.8, dy + hh + 0.05, z0 + 1.4], [0.8, dy + hh + 0.2, z0 + 2.2]);
  }

  // -- 4. four bells in a square cluster -------------------------------------
  const BELLS = [[-1.55, 1.55], [1.55, 1.55], [-1.55, -1.55], [1.55, -1.55]];
  H([-2.6, -2.6, 33.0], [2.6, 2.6, 36.5]);                 // thrust frame
  for (const [bx, by] of BELLS) {
    octaTube(hv, hi, 2, bx, by, 35.0, 40.2, 0.94, 1.36, UV, 0);
    octaTube(hv, hi, 2, bx, by, 35.6, 39.9, 0.74, 1.10, UV, 0, true);
    octaTube(gv, gi, 2, bx, by, 39.2, 40.0, 0.68, 0.98, UV, 1);
    H([bx - 0.5, by - 0.5, 33.4], [bx + 0.5, by + 0.5, 35.4]); // mount
  }

  // -- 5. reactor and radiators, external because there is no hull to hide in -
  H([-2.2, 2.15, 26.0], [2.2, 4.10, 32.0]);                // reactor drum
  octaTube(hv, hi, 2, 0, 3.1, 25.4, 32.6, 1.55, 1.55, UV, 2);
  G([-1.5, 4.10, 27.2], [1.5, 4.30, 30.8]);                // cooling glow
  for (const s of [-1, 1]) {                                // radiator panels
    mirror(hv, hi, s, 2.2, 6.9, -0.18, 0.18, 20.0, 31.0);
    for (let i = 0; i < 6; i++) {
      const z = 20.6 + i * 1.7;
      mirror(hv, hi, s, 2.4, 6.7, 0.18, 0.62, z, z + 1.1);
      mirror(hv, hi, s, 2.4, 6.7, -0.62, -0.18, z, z + 1.1);
    }
    mirror(hv, hi, s, 6.7, 7.1, -0.7, 0.7, 20.2, 30.8);     // end plate
    box(gv, gi, [Math.min(s * 7.0, s * 7.2), -0.14, 25.0],
      [Math.max(s * 7.0, s * 7.2), 0.14, 26.0], UV);
  }

  // -- 6. plumbing along the keel --------------------------------------------
  for (let i = 0; i < 22; i++) {
    const z = -20 + rnd() * 52;
    const s = rnd() < 0.5 ? -1 : 1;
    mirror(hv, hi, s, K + 0.30, K + 0.30 + 0.2 + rnd() * 0.3,
      -0.4 + rnd() * 0.8, -0.1 + rnd() * 0.8, z, z + 0.8 + rnd() * 1.6);
  }
  octaTube(hv, hi, 2, 0, -K - 0.5, -20.0, 32.0, 0.24, 0.24, UV, 2); // main run

  // -- 7. refit: a hull that gets worked on, in vacuum, by hand ---------------
  // 0.34.0. The lattice was the strongest silhouette on the register and the
  // emptiest surface: an open frame has twice the visible area of a fuselage
  // and half the reason for a greeble to exist. What fills it honestly is the
  // gear a working hauler needs OUTSIDE — rails to clip a tether to, ladders,
  // floodlights and a crane, all from the shared parts bin.
  const k = kit(hv, hi, gv, gi, rnd);

  // Four legs off the lower longerons, splayed wide. A loaded hauler is the
  // heaviest thing that lands anywhere and the feet say so.
  k.gear(-1.85, -1.85, -13.0, 3.0, 0.95);
  k.gear(1.85, -1.85, -13.0, 3.0, 0.95);
  k.gear(-1.85, -1.85, 21.0, 3.0, 0.95);
  k.gear(1.85, -1.85, 21.0, 3.0, 0.95);

  // The tug's mating collar, dead on the nose. This is the one hull that docks
  // by pushing, and the yoke around the ring is what it pushes with.
  k.dockRing([0, 0.1, -30.6], 1.05, 2, -1);
  for (const s of [-1, 1]) {                        // towing yoke arms
    mirror(hv, hi, s, 1.55, 2.30, -0.55, 0.55, -32.4, -30.2);
    mirror(hv, hi, s, 2.05, 2.35, -1.10, 1.10, -32.6, -31.6);
    k.flood(s * 3.45, 1.3, -27.0, [s, 0, 0]);
  }
  k.flood(0.9, 3.92, -26.0, [0, 1, 0]);             // brow work lamps
  k.flood(-0.9, 3.92, -26.0, [0, 1, 0]);

  // Crane gantry down the keel: a rail with a trolley and a hook block. The
  // containers had to get on somehow, and nothing else on the ship explains it.
  H([-0.16, 4.55, -8.0], [0.16, 4.85, 30.0]);       // rail
  for (let z = -7.0; z < 30; z += 5.6) {            // stanchions off the top longerons
    H([-1.75, 4.10, z], [-1.45, 4.62, z + 0.26]);
    H([1.45, 4.10, z], [1.75, 4.62, z + 0.26]);
    H([-1.75, 4.30, z], [1.75, 4.46, z + 0.16]);
  }
  H([-0.62, 4.20, 6.4], [0.62, 4.62, 7.9]);         // trolley
  H([-0.16, 3.10, 6.9], [0.16, 4.24, 7.4]);         // hoist cable
  H([-0.42, 2.62, 6.72], [0.42, 3.14, 7.58]);       // hook block
  G([-0.22, 4.62, 6.8], [0.22, 4.74, 7.5]);         // trolley lamp

  // Rails and ladders along the working faces. A hauler is crewed by people in
  // suits who need something to hold on to, and that is the whole read.
  k.rail(1.85, 1.55, -18.0, 30.0, 4.2);
  k.rail(-1.85, 1.55, -18.0, 30.0, 4.2);
  k.ladder(0, -1.5, 3.0, -20.6, 0.34);
  k.ladder(0, -1.5, 3.0, 32.4, 0.34);
  k.hatch(1.1, 3.94, -25.0, 0.42, 1);               // tug-head roof hatches
  k.hatch(-1.1, 3.94, -27.4, 0.36, 1);

  // Registration plates and a lot of patched plating: this hull was refitted
  // badly and the paperwork was screwed on over the damage.
  for (const s of [-1, 1]) {
    k.plate(s, 3.32, -1.10, -28.4, 2.9, 1.05);
    k.wear(s, 3.32, -2.4, 2.6, -30.0, -21.5, 6);
  }
  k.pipes(-2.05, -1.9, -12.0, 26.0, 0.15, 3);       // outboard gallery, port

  return {
    hull: { vertexData: new Float32Array(hv), indexData: new Uint32Array(hi) },
    glow: { vertexData: new Float32Array(gv), indexData: new Uint32Array(gi) },
    fx: {
      nose: -30.9, tail: 40.2, center: [0, 0, 4],
      shieldHalf: [8.6, 6.4, 38.0],
      nozzles: BELLS.map(([x, y]) => [x, y, 39.9]), nozzleR: 1.36,
      verniers: [[-2.6, 2.6, 34.0], [2.6, 2.6, 34.0]], vernierR: 0.42,
      rcs: rcsFor(2.2, -27, 30, 2.4),
      wounds: [[2.4, 0.4, -4.0], [-1.6, -2.3, 14.0]],
      beacons: [[7.1, 0, 25.5], [-7.1, 0, 25.5], [0, 4.2, 29.0], [0, -1.9, -30.7]],
    },
  };
}

/**
 * KSV HARRIER — escort conversion.
 *
 * A wedge. Where the Aethon and the Petrel are tall and narrow and the Drayman
 * is an open frame, this is wide, flat and low: a blended delta with twin tail
 * booms and the bells slung between them. Nothing on it is round.
 */
export function buildHarrier() {
  const hv = [], hi = [], gv = [], gi = [];
  const H = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, UV);
  const rnd = lcg(0x77b204);

  // -- 1. blended wing-body --------------------------------------------------
  // Lofted like the others, but the sections are WIDE and SHALLOW, so the same
  // machinery produces a completely different volume: at its widest the hull is
  // eleven units across and two and a half tall.
  const SEC = [
    [-24.0, 0.60, -0.34, 0.44, 0.20],
    [-20.5, 2.10, -0.62, 0.86, 0.36],
    [-15.0, 4.30, -0.90, 1.32, 0.52],
    [-8.0, 7.40, -1.12, 1.58, 0.66],
    [-1.0, 10.20, -1.28, 1.66, 0.74],   // widest
    [6.0, 11.05, -1.30, 1.60, 0.74],
    [12.0, 9.60, -1.20, 1.42, 0.66],
    [17.5, 6.20, -1.02, 1.18, 0.52],
    [21.0, 4.10, -0.88, 0.96, 0.40],
  ];
  loft(hv, hi, SEC.map(([z, hw, y0, y1, ch]) => ({ z, pts: chamRect(hw, y0, y1, ch) })),
    UV, { capFore: true, capAft: true });

  // -- 2. raked canopy, set low and far forward ------------------------------
  G([-1.30, 0.72, -19.6], [1.30, 1.52, -13.8]);
  H([-1.46, 0.60, -20.0], [-1.22, 1.66, -13.4]);
  H([1.22, 0.60, -20.0], [1.46, 1.66, -13.4]);
  H([-1.46, 1.50, -20.2], [1.46, 1.78, -13.2]);            // spine over the glass
  H([-1.2, 0.66, -17.2], [1.2, 1.56, -16.9]);              // divider
  H([-2.1, -0.95, -21.2], [2.1, -0.10, -17.4]);            // chin sensor blister
  G([-1.5, -1.02, -21.3], [1.5, -0.62, -20.4]);            // sensor face

  // -- 3. twin tail booms ----------------------------------------------------
  // The signature. They run aft off the wing trailing edge and carry the whole
  // tail between them, which is the shape you recognise at a distance.
  for (const s of [-1, 1]) {
    mirror(hv, hi, s, 4.60, 6.40, -1.05, 1.20, 8.0, 30.5);   // boom body
    mirror(hv, hi, s, 4.85, 6.15, 1.20, 1.55, 11.0, 29.0);   // dorsal cap
    mirror(hv, hi, s, 4.85, 6.15, -1.35, -1.05, 11.0, 29.0); // ventral cap
    mirror(hv, hi, s, 4.75, 6.25, -0.8, 0.9, 30.5, 31.6);    // tail cap
    // vertical stabiliser standing on each boom
    mirror(hv, hi, s, 5.10, 5.90, 1.55, 5.90, 20.0, 30.0);
    mirror(hv, hi, s, 5.25, 5.75, 5.20, 6.25, 24.0, 29.4);   // tip
    box(gv, gi, [Math.min(s * 5.3, s * 5.7), 5.92, 26.4],
      [Math.max(s * 5.3, s * 5.7), 6.12, 27.4], UV);          // strobe
    // boom root fairing, blending into the wing
    mirror(hv, hi, s, 4.20, 5.10, -0.9, 1.0, 4.0, 10.0);
  }

  // -- 4. two bells, slung between the booms ---------------------------------
  const BELLS = [[-2.30, 0.10], [2.30, 0.10]];
  H([-3.4, -1.0, 20.0], [3.4, 1.0, 23.0]);                 // thrust box
  for (const [bx, by] of BELLS) {
    octaTube(hv, hi, 2, bx, by, 21.5, 27.4, 1.02, 1.48, UV, 0);
    octaTube(hv, hi, 2, bx, by, 22.1, 27.1, 0.82, 1.20, UV, 0, true);
    octaTube(gv, gi, 2, bx, by, 26.4, 27.2, 0.74, 1.06, UV, 1);
  }

  // -- 5. hardpoints under the wing ------------------------------------------
  // The conversion, made visible: pylons the survey office did not order.
  for (const s of [-1, 1]) {
    for (const z of [-6.0, 1.0]) {
      mirror(hv, hi, s, 3.0, 4.2, -1.55, -1.10, z, z + 3.2);      // pylon
      mirror(hv, hi, s, 2.7, 4.5, -2.35, -1.55, z - 0.6, z + 4.0); // launcher body
      for (let i = 0; i < 3; i++) {                                // tube mouths
        box(gv, gi, [Math.min(s * (2.9 + i * 0.55), s * (3.3 + i * 0.55)), -2.20, z - 0.72],
          [Math.max(s * (2.9 + i * 0.55), s * (3.3 + i * 0.55)), -1.80, z - 0.58], UV);
      }
    }
    // leading-edge strake and a wingtip rail
    mirror(hv, hi, s, 7.0, 10.4, -0.30, 0.30, -6.0, -3.0);
    mirror(hv, hi, s, 10.2, 11.2, -0.7, 0.8, -1.5, 7.5);
    mirror(hv, hi, s, 10.4, 11.0, 0.80, 1.60, 1.0, 6.0);            // fence
  }

  // -- 6. armour plating and greebles ----------------------------------------
  // Slabs laid ON the wing rather than modelled into it: bolt-on armour is what
  // an auction hull that was never repainted actually looks like.
  for (let i = 0; i < 9; i++) {
    const s = i % 2 ? 1 : -1;
    const x0 = 1.6 + rnd() * 5.5;
    const z = -12 + rnd() * 24;
    mirror(hv, hi, s, x0, x0 + 1.4 + rnd() * 1.8, 1.55, 1.82, z, z + 2.0 + rnd() * 2.4);
  }
  for (let i = 0; i < 14; i++) {
    const s = rnd() < 0.5 ? -1 : 1;
    const x0 = 1.2 + rnd() * 7.0;
    const z = -14 + rnd() * 28;
    mirror(hv, hi, s, x0, x0 + 0.3 + rnd() * 0.5, -1.55, -1.28, z, z + 0.5 + rnd() * 1.2);
  }
  H([-1.0, 1.78, 2.0], [1.0, 2.30, 9.0]);                  // dorsal spine box
  G([-0.4, 2.30, 4.0], [0.4, 2.44, 5.0]);                  // beacon

  // -- 7. refit: the conversion, made obvious --------------------------------
  // 0.34.0. The blurb says a patrol hull bought at auction and never repainted,
  // and until now the only evidence was four hardpoints. A wedge this wide has
  // an enormous upper surface with nothing on it, and what belongs there is
  // gun-ship hardware nobody has bothered to remove.
  const k = kit(hv, hi, gv, gi, rnd);

  // Wide-track gear: a low, flat hull sits on its wing, not under it.
  k.gear(0, -1.06, -15.5, 1.5, 0);
  k.gear(-3.9, -1.32, 7.0, 1.9, 1.0);
  k.gear(3.9, -1.32, 7.0, 1.9, 1.0);

  // Chin barbette. An escort conversion with a magazine and no gun was the
  // detail that gave the whole class away as a blockout.
  octaTube(hv, hi, 1, -22.6, 0, -1.85, -0.95, 0.72, 0.86, UV, 2);   // turret drum
  H([-0.62, -1.72, -24.6], [0.62, -1.18, -22.2]);                    // gun cradle
  for (const bx of [-0.30, 0.30]) {
    octaTube(hv, hi, 2, bx, -1.45, -26.9, -23.4, 0.13, 0.16, UV, 1); // barrels
    octaTube(hv, hi, 2, bx, -1.45, -26.6, -26.0, 0.21, 0.21, UV, 2); // muzzle brakes
  }
  G([-0.5, -1.90, -23.9], [0.5, -1.80, -23.0]);                      // laying lamp

  // Countermeasures at the wing roots, sensor pods on the tips, blast shutters
  // stowed above the glass. All three read at silhouette distance.
  for (const s of [-1, 1]) {
    k.dispenser(s, 2.4, -1.62, 9.4, 4);
    k.pod(s * 10.7, 0.05, -2.4, 0.30, 0.86);
    mirror(hv, hi, s, 0.55, 1.44, 1.72, 1.96, -19.4, -14.2);         // shutter, stowed
    mirror(hv, hi, s, 0.60, 1.40, 1.96, 2.06, -18.8, -14.6);         // shutter rail
    k.flood(s * 4.9, 1.30, 12.0, [0, 1, 0]);                          // boom work lamps
    k.plate(s, 6.32, -0.55, 14.0, 3.0, 0.9);                          // squadron plate
    k.wear(s, 6.34, -0.9, 1.1, 9.0, 29.0, 5);
    k.rail(s * 3.2, 1.62, -8.0, 6.0);                                 // wing walkway
    k.hatch(s * 2.2, 1.66, 3.4, 0.36, 1);
  }
  k.dockRing([0, 1.80, 11.4], 0.68, 1, 1);       // dorsal collar, aft of the spine box
  k.mast(0.0, 2.30, 8.2, 1.8, false);            // stub whip: no dish, this hull listens
  k.pipes(-1.15, -1.42, 12.0, 20.5, 0.12, 2);    // hydraulics to the booms
  // Arrestor hook under the tail: patrol furniture, useless on a survey run.
  H([-0.18, -1.42, 17.0], [0.18, -1.16, 23.4]);
  H([-0.30, -1.92, 22.6], [0.30, -1.30, 23.9]);

  return {
    hull: { vertexData: new Float32Array(hv), indexData: new Uint32Array(hi) },
    glow: { vertexData: new Float32Array(gv), indexData: new Uint32Array(gi) },
    fx: {
      nose: -24.0, tail: 27.4, center: [0, 0, 0],
      shieldHalf: [12.4, 6.6, 29.0],
      nozzles: BELLS.map(([x, y]) => [x, y, 27.1]), nozzleR: 1.48,
      verniers: [[-3.6, 0.1, 22.4], [3.6, 0.1, 22.4]], vernierR: 0.38,
      rcs: rcsFor(6.0, -20, 18, 1.4),
      wounds: [[5.2, 0.6, -2.0], [-3.0, -1.4, 6.0]],
      beacons: [[5.5, 6.0, 26.9], [-5.5, 6.0, 26.9], [10.8, 0, 3.0], [-10.8, 0, 3.0]],
    },
  };
}

/**
 * A generic RCS port table for a hull of half-width `hw`, running from `zF` to
 * `zA`, with vertical jets offset `vy` off the axis.
 *
 * The Aethon's table is hand-placed against its blisters because it HAS
 * blisters at specific model coordinates. These three do not, so the ports are
 * derived from the hull's own extents — same group names, same meanings, so
 * `SpaceRenderer` needs no per-hull branch. Group names describe what the jet
 * DOES, not where it is, which is what lets the renderer stay ignorant.
 */
function rcsFor(hw, zF, zA, vy) {
  const p = (x, y, z, ax) => ({ p: [x, y, z], ax });
  const mid = (zF + zA) / 2;
  return {
    rollPos: [p(hw, -0.3, mid, [0, -1, 0]), p(-hw, 0.3, mid, [0, 1, 0])],
    rollNeg: [p(hw, 0.3, mid, [0, 1, 0]), p(-hw, -0.3, mid, [0, -1, 0])],
    yaw: [p(hw * 0.4, 0, zF + 1, [1, 0, 0]), p(-hw * 0.4, 0, zF + 1, [-1, 0, 0])],
    noseUp: [p(0.9, -vy, zF + 2, [0, -1, 0]), p(-0.9, -vy, zF + 2, [0, -1, 0])],
    noseDown: [p(0.9, vy, zF + 2, [0, 1, 0]), p(-0.9, vy, zF + 2, [0, 1, 0])],
    latStar: [p(hw, 0.1, zF + 4, [1, 0, 0]), p(hw, 0.1, zA - 4, [1, 0, 0])],
    latPort: [p(-hw, 0.1, zF + 4, [-1, 0, 0]), p(-hw, 0.1, zA - 4, [-1, 0, 0])],
    vertUp: [p(1.2, vy, zF + 5, [0, 1, 0]), p(-1.2, vy, zA - 5, [0, 1, 0])],
    vertDown: [p(1.2, -vy, zF + 5, [0, -1, 0]), p(-1.2, -vy, zA - 5, [0, -1, 0])],
    retro: [p(hw * 0.5, 0.4, zF + 1.5, [0, 0, -1]), p(-hw * 0.5, 0.4, zF + 1.5, [0, 0, -1]),
      p(hw * 0.5, -0.4, zF + 1.5, [0, 0, -1]), p(-hw * 0.5, -0.4, zF + 1.5, [0, 0, -1])],
  };
}

/**
 * Section vents for a hull, derived from its own extents. Same six keys as the
 * Aethon's, so `SpaceRenderer`'s breach-venting pass is hull-agnostic.
 */
export function ventsFor(fx) {
  const { nose, tail } = fx;
  const [hx, hy] = fx.shieldHalf;
  const fz = nose * 0.75, az = tail * 0.75;
  return {
    fore: [[1.0, hy * 0.25, fz], [0.16, 0.42, -0.89]],
    aft: [[-1.0, hy * 0.25, az], [-0.14, 0.38, 0.91]],
    port: [[-hx * 0.35, 0.4, nose * 0.2], [-0.97, 0.12, -0.2]],
    stbd: [[hx * 0.35, -0.4, tail * 0.3], [0.96, -0.14, 0.24]],
    dorsal: [[0.8, hy * 0.3, tail * 0.1], [0.1, 0.98, 0.14]],
    ventral: [[-0.7, -hy * 0.3, nose * 0.5], [-0.12, -0.97, -0.2]],
  };
}
