/**
 * ShipSystems — live ship + survival state that actually changes over time, so
 * the HUD bars mean something. This is the seed of the full Survival.js /
 * ShipSystems.js split (context/04 §1–2); for now one model holds both the
 * ship resources and the pilot's vitals and updates them each tick.
 *
 * Everything is 0–100 except heat (°C) and radiation (0–100 accumulation).
 */
import { clamp } from '../utils/MathUtils.js';
import { FLIGHT } from '../core/Constants.js';

export class ShipSystems {
  constructor() {
    // -- ship resources --
    this.fuel = 87;      // sublight fuel %
    this.power = 92;     // reactor power / energy %
    this.shield = 78;    // shield %
    this.hull = 91;      // hull integrity % — kept as the MEAN of `sections`
    /**
     * Seconds until shield regeneration resumes. THIS IS THE FIX for the bug
     * where the hull could never be damaged.
     *
     * The shield used to regenerate unconditionally at 1.5%/s, every frame, with
     * no delay after a hit. So the frame after a hit emptied it, the shield was
     * back to 0.025% — above zero — and the damage branch `if (shield > 0)`
     * absorbed the next round too. The shield could never *stay* down, so every
     * hit for the whole game went to the shield and the hull bar never moved.
     * That is exactly the "always hit shield because they got minimal 1%" the
     * owner reported.
     */
    this.shieldHold = 0;
    /** True once the shield has been emptied: needs a full reboot, not a top-up. */
    this.shieldDown = false;

    /**
     * Per-section hull integrity. Damage that gets through the shield lands on
     * the section it physically struck, so a fight leaves a readable record of
     * where you were hit rather than one abstract number going down.
     * `hull` is the mean of these six, so the HUD bar still means "the ship".
     */
    this.sections = { fore: 100, aft: 100, port: 100, stbd: 100, dorsal: 100, ventral: 100 };
    this.warpFuel = 64;  // warp fuel %
    this.weapons = 100;  // weapon capacitor %

    // -- pilot vitals --
    this.health = 100;   // %
    this.oxygen = 96;    // %
    this.hunger = 82;    // %
    this.thirst = 74;    // %
    this.fatigue = 92;   // % rest (context/04 §1) — low = impaired
    this.heat = 21.0;    // body/cabin temperature °C (nominal 21)
    this.radiation = 4;  // accumulated radiation 0..100

    // -- surroundings (read-outs, not resources) --
    this.contacts = 0;   // nearby ship/blip count
    this.gravity = 1.0;  // local g
    /**
     * Cabin pressure in atmospheres, driven by the WORST hull section rather
     * than the mean: one hole vents the deck, and averaging six sections would
     * let a breached bow hide behind five intact ones. Surfaced on the HUD's
     * SENSORS plate.
     */
    this.pressure = 1.0;

    // -- hull class (see data/ShipClasses.js) --
    /**
     * Everything below stays on a 0..100 scale so the HUD keeps reading
     * percentages of what THIS hull can hold — which is what a pilot actually
     * wants — and the class instead changes how fast those percentages move.
     * A 165-hull hauler divides incoming damage by 1.65; a 78-fuel pinnace
     * burns its tank 1.28x faster. Rescaling the bars themselves would have
     * meant touching every gauge in the HUD to no benefit.
     */
    this.classId = 'aethon';
    this.hullMax = 100;
    this.shieldMax = 100;
    this.fuelMax = 100;
    this.powerMax = 100;
    this.scanGain = 1.0;

    this._t = 0;
  }

  /** Section names in the order the impact classifier tests them. */
  static SECTION_LABEL = {
    fore: 'FORWARD SECTION', aft: 'AFT SECTION', port: 'PORT FLANK',
    stbd: 'STARBOARD FLANK', dorsal: 'DORSAL SPINE', ventral: 'VENTRAL KEEL',
  };

  /**
   * Apply an incoming hit through the shield, then into a hull section.
   *
   * Returns what actually happened so the caller can pick the right effects —
   * a round stopped by the deflector and a round that opens a hull section are
   * different events and should not look the same.
   *
   * OVERFLOW MATTERS: a 40-point hit against an 8% shield takes the shield out
   * AND puts 32 into the hull. Absorbing the whole thing because the shield
   * happened to be non-zero is what made the deflector infinitely strong at 1%.
   *
   * @param {number} dmg
   * @param {string} section one of `sections`' keys
   * @returns {{shieldAbsorbed:number, hullDamage:number, collapsed:boolean,
   *   section:string, breached:boolean, destroyed:boolean}}
   */
  applyHit(dmg, section = 'fore') {
    this.shieldHold = 4.0; // any hit stalls regeneration
    let hullDamage = dmg;
    let shieldAbsorbed = 0;
    let collapsed = false;
    if (!this.shieldDown && this.shield > 0) {
      shieldAbsorbed = Math.min(this.shield, dmg);
      this.shield -= shieldAbsorbed;
      hullDamage = dmg - shieldAbsorbed;
      if (this.shield <= 0.001) {
        this.shield = 0;
        this.shieldDown = true;
        this.shieldHold = 7.0; // a collapsed emitter takes longer to come back
        collapsed = true;
      }
    }
    let breached = false;
    if (hullDamage > 0) {
      // ARMOUR. Raw damage is what the round carries; what the section loses is
      // that divided by the structure behind the plating. Without this a section
      // fell to six rounds, and five hostiles put six rounds in the air in under
      // two seconds — the ship was not weak because the numbers were dramatic,
      // it was weak because a survey hull had no armour term at all.
      hullDamage /= FLIGHT.HULL_ARMOR * (this.hullMax / 100);
      const before = this.sections[section] ?? 100;
      // A section takes the hit at full strength; the ship-wide hull figure is
      // the mean, so one section failing costs ~17% of total integrity. That is
      // deliberate: losing a flank should be survivable, losing three should not.
      const after = clamp(before - hullDamage, 0, 100);
      this.sections[section] = after;
      breached = before > 25 && after <= 25;
      this.hull = this.sectionMean();
    }
    return { shieldAbsorbed, hullDamage, collapsed, section, breached,
      destroyed: this.hull <= 0 };
  }

  /**
   * FIELD REPAIR — patch the worst section by `pct`. This is the honest unit of
   * repair: a pilot with a plate and a welder reaches one compartment, not the
   * whole ship, so the interesting decision is which damage you live with.
   *
   * Returns null when there is nothing to fix, so the caller can say so instead
   * of silently eating the plate.
   * @returns {{name:string, label:string, from:number, to:number}|null}
   */
  repairSection(pct = FLIGHT.REPAIR_SECTION_PCT) {
    const worst = this.worstSection();
    if (worst.value >= 99.9) return null;
    const from = this.sections[worst.name];
    this.sections[worst.name] = clamp(from + pct, 0, 100);
    this.hull = this.sectionMean();
    return {
      name: worst.name,
      label: ShipSystems.SECTION_LABEL[worst.name] ?? worst.name.toUpperCase(),
      from: Math.round(from), to: Math.round(this.sections[worst.name]),
    };
  }

  /** Mean integrity across the six sections. */
  sectionMean() {
    const v = Object.values(this.sections);
    return v.reduce((a, b) => a + b, 0) / v.length;
  }

  /** Set every section to `v` and resync `hull` — used by repair and respawn. */
  setSections(v) {
    for (const k of Object.keys(this.sections)) this.sections[k] = v;
    this.hull = this.sectionMean();
  }

  /** The worst-off section, for HUD callouts. */
  worstSection() {
    let worst = 'fore', lo = Infinity;
    for (const [k, v] of Object.entries(this.sections)) if (v < lo) { lo = v; worst = k; }
    return { name: worst, value: lo };
  }

  /**
   * @param {number} dt seconds
   * @param {object} ctx { thrust, boosting, inFlight, zoneId, speed }
   */
  update(dt, ctx = {}) {
    this._t += dt;
    const thrust = Math.abs(ctx.thrust ?? 0);
    const inReactor = ctx.zoneId === 'reactor_room' || ctx.zoneId === 'engine_room';

    // fuel drains with main-drive use (boost costs more); idles otherwise
    if (ctx.inFlight && thrust > 0) {
      this.fuel = clamp(this.fuel - thrust * (ctx.boosting ? 0.9 : 0.35)
        * (100 / this.fuelMax) * dt, 0, 100);
    }

    // power: thrust/boost draws it down, reactor trickle-charges it back
    const draw = ctx.inFlight ? thrust * (ctx.boosting ? 6 : 2.5) : 0;
    const regen = 3.2;
    this.power = clamp(this.power + (regen - draw * (100 / this.powerMax)) * dt, 0, 100);

    // Shield: regenerates only after a hold-off, and a COLLAPSED shield has to
    // reboot from nothing rather than trickling up out of zero. Regen also draws
    // reactor power, so running the shield hard costs you thrust.
    this.shieldHold = Math.max(0, this.shieldHold - dt);
    if (this.shieldHold <= 0 && this.power > 4) {
      const rate = this.shieldDown ? 4.5 : 1.8; // emitters run hot on reboot
      this.shield = clamp(this.shield + rate * dt, 0, 100);
      this.power = clamp(this.power - rate * 0.22 * dt, 0, 100);
      if (this.shieldDown && this.shield >= 25) this.shieldDown = false; // back online
    }
    this.weapons = clamp(this.weapons + 6 * dt, 0, 100);

    // oxygen: life support holds it near full; drifts a touch for life
    const o2Target = 96 + 2 * Math.sin(this._t * 0.08);
    this.oxygen += (o2Target - this.oxygen) * clamp(dt * 0.4, 0, 1);

    // survival needs tick down slowly (game-time compressed)
    this.hunger = clamp(this.hunger - 0.06 * dt, 0, 100);
    this.thirst = clamp(this.thirst - 0.09 * dt, 0, 100);
    this.fatigue = clamp(this.fatigue - (ctx.inFlight ? 0.02 : 0.035) * dt, 0, 100);

    // critical thresholds bite (context/04 §1) — and with Phase 6, all the way:
    // health can reach 0 now; main.js owns the death/respawn flow.
    if (this.thirst < 20) this.health = clamp(this.health - 0.15 * dt, 0, 100);
    if (this.radiation > 60) this.health = clamp(this.health - 0.2 * dt, 0, 100);
    if (this.oxygen <= 2) this.health = clamp(this.health - 1.0 * dt, 0, 100);

    // heat rises near the reactor/engines, else eases to cabin nominal
    const heatTarget = inReactor ? 34 : 21;
    this.heat += (heatTarget - this.heat) * clamp(dt * 0.25, 0, 1);

    // radiation accumulates near the reactor, decays slowly elsewhere
    if (inReactor) this.radiation = clamp(this.radiation + 2.0 * dt, 0, 100);
    else this.radiation = clamp(this.radiation - 0.5 * dt, 0, 100);

    this.gravity = ctx.inFlight ? 0.0 : 1.0;
    // Pressure sags with the worst section, so a breach reads on the gauge
    // immediately instead of being averaged away.
    this.pressure = clamp(0.42 + (this.worstSection().value / 100) * 0.58, 0.05, 1.0);
  }

  /** Compact label for a 0–100 level (used by the RAD read-out). */
  radBand() {
    return this.radiation > 60 ? 'HIGH' : this.radiation > 25 ? 'MED' : 'LOW';
  }

  /**
   * Apply an item's effect map (context/04 §3) to the vitals/tanks. Radiation
   * effects are negative deltas (chelation removes it); everything else adds.
   * @returns {string} a short HUD line describing what changed
   */
  applyItem(effect = {}) {
    const notes = [];
    const bump = (field, delta, label, max = 100) => {
      if (delta == null) return;
      const before = this[field];
      this[field] = clamp(before + delta, 0, max);
      const got = Math.round(this[field] - before);
      if (got !== 0) notes.push(`${label} ${got > 0 ? '+' : ''}${got}`);
    };
    bump('health', effect.health, 'HP');
    bump('oxygen', effect.oxygen, 'O2');
    bump('hunger', effect.hunger, 'FOOD');
    bump('thirst', effect.thirst, 'H2O');
    bump('fatigue', effect.fatigue, 'REST');
    bump('radiation', effect.radiation, 'RAD');
    bump('fuel', effect.fuel, 'FUEL');
    bump('warpFuel', effect.warpFuel, 'WARP');
    bump('shield', effect.shield, 'SHLD');
    bump('power', effect.power, 'PWR');
    // HULL is NOT a plain field — it is the mean of `sections`, so raising it
    // directly was silently undone by the next applyHit's `hull = sectionMean()`.
    // A hull item now patches the worst section, which is what "weld a plate on"
    // actually means, and the mean follows from that.
    if (effect.hull != null) {
      const rep = this.repairSection(effect.hull);
      if (rep) notes.push(`${rep.label} ${rep.from}→${rep.to}%`);
      else notes.push('HULL ALREADY SOUND');
    }
    return notes.join('  ');
  }

  /** Snapshot for the save file. */
  toJSON() {
    const out = {};
    for (const k of ['fuel', 'power', 'shield', 'hull', 'warpFuel', 'weapons',
      'health', 'oxygen', 'hunger', 'thirst', 'fatigue', 'heat', 'radiation']) out[k] = this[k];
    out.sections = { ...this.sections };
    return out;
  }

  /** Restore from a save file. */
  fromJSON(data) {
    for (const [k, v] of Object.entries(data ?? {})) {
      if (typeof v === 'number' && k in this) this[k] = v;
    }
    // Section damage is a nested object, so the numeric loop above skips it.
    // Older saves have no `sections` at all: seed them from the saved hull so a
    // ship loaded at 40% integrity does not come back with six pristine sections.
    if (data?.sections) {
      for (const k of Object.keys(this.sections)) {
        if (typeof data.sections[k] === 'number') this.sections[k] = data.sections[k];
      }
    } else if (typeof data?.hull === 'number') {
      this.setSections(data.hull);
    }
    this.hull = this.sectionMean();
  }
}
