/**
 * FlightController — Newtonian, first-person-seated flight (context/02 §3).
 * Mouse steers pitch/yaw, A/D rolls, W/S thrusts along the drive axis; Q/E and
 * R/F fire the translational RCS (sidestep + climb/dive) for real 6-DOF
 * maneuvering; Shift boosts, Space is a hard brake, Z toggles fly-by-wire
 * flight assist (bleeds drift so the ship can actually hover and stop). Velocity
 * persists between burns. The camera stays bolted to the pilot's skull.
 */
import { FLIGHT } from '../core/Constants.js';
import { Settings } from '../core/Settings.js';
import { Vec3, Quat, clamp } from '../utils/MathUtils.js';

const AXIS_X = [1, 0, 0];
const AXIS_Y = [0, 1, 0];
const AXIS_Z = [0, 0, 1];
const FORWARD = [0, 0, -1]; // ship forward = interior fore (-z)
const RIGHT = [1, 0, 0];
const UP = [0, 1, 0];

export class FlightController {
  /**
   * @param {import('./Spaceship.js').Spaceship} ship
   * @param {import('../core/InputManager.js').InputManager} input
   * @param {import('../core/EventBus.js').EventBus} events
   */
  constructor(ship, input, events) {
    this.ship = ship;
    this.input = input;
    this.events = events;
    this._dq = Quat.create();
    this._tmpQ = Quat.create();
    this._fwd = Vec3.create();
    this._axis = Vec3.create();
    /**
     * Angular velocity in ship-local axes [pitch, yaw, roll], rad/s. The ship
     * is a 6-DOF body with mass, not a camera: control input applies TORQUE to
     * this, and it bleeds off through the RCS rather than stopping dead. That's
     * what gives the Aethon its heavy, drifting feel instead of a mouse-look
     * that snaps to the cursor.
     */
    this.angVel = [0, 0, 0];
    /**
     * Hull-class multipliers on the FLIGHT constants (see data/ShipClasses.js).
     * Set once at commission. They are multipliers rather than replacements so
     * every tuning pass on the base constants still lands on every hull — a
     * courier that turns 1.6x as fast stays 1.6x as fast when TURN_RATE moves.
     */
    this.cls = { thrust: 1, turn: 1, damp: 1, mass: 1 };
  }

  update(dt) {
    const { ship, input } = this;

    // -- attitude: torque in, momentum out -----------------------------------
    // Input no longer rotates the hull directly; it spins up angular velocity
    // that keeps going until the RCS bleeds it. Flight assist damps hard (the
    // computer fights the drift for you); with assist off you keep tumbling
    // until you counter-steer, which is the honest Newtonian behaviour.
    const [mdx, mdy] = input.consumeMouseDelta();
    const rate = FLIGHT.TURN_RATE * (Settings.get('flightSens') ?? 1) * this.cls.turn;
    const inv = Settings.get('invertY') ? -1 : 1;
    const av = this.angVel;
    // mouse delta is an impulse (already frame-scaled by the delta itself)
    av[0] += -mdy * rate * inv * FLIGHT.TORQUE_GAIN;
    av[1] += -mdx * rate * FLIGHT.TORQUE_GAIN;

    const [tYaw, tPitch] = input.turnAxis;
    const stickOn = tYaw !== 0 || tPitch !== 0;

    let rollIn = 0;
    if (input.isDown('left')) rollIn += 1;
    if (input.isDown('right')) rollIn -= 1;
    rollIn -= input.moveAxis[0]; // touch stick x
    av[2] += rollIn * FLIGHT.ROLL_TORQUE * dt;

    // RCS damping: strong with flight assist, a slow bleed without it. The turn
    // stick counts as steering — otherwise the assist would fight the rate it was
    // just asked to hold and the ship would creep back to level under you.
    const steering = mdx !== 0 || mdy !== 0 || rollIn !== 0 || stickOn;
    const damp = (ship.flightAssist
      ? (steering ? FLIGHT.ANG_DAMP_ASSIST_ACTIVE : FLIGHT.ANG_DAMP_ASSIST)
      : FLIGHT.ANG_DAMP_MANUAL) * this.cls.damp;
    const k = Math.exp(-damp * dt);
    av[0] *= k; av[1] *= k; av[2] *= k;

    // -- TURN STICK: a rate command, not an impulse ---------------------------
    // Deflection names a TARGET angular velocity and the RCS chases it, so
    // holding the stick over holds a STEADY turn instead of winding the hull up
    // faster the longer you hold. That is the difference between "turn left" and
    // "keep applying left torque", and it is what makes the stick flyable
    // one-handed on a phone. It works identically in the seat and in the hull
    // cam, because unlike mouse look it is never claimed by the camera.
    //
    // Deliberately applied AFTER the damping, not before: damped afterwards, the
    // achieved rate would settle at gain/(gain+damp) of what was asked for, and
    // the assist would quietly fight the turn it was just told to hold.
    if (stickOn) {
      const g = Math.min(1, FLIGHT.TURN_STICK_GAIN * dt);
      av[0] += (tPitch * inv * FLIGHT.TURN_STICK_RATE - av[0]) * g;
      av[1] += (-tYaw * FLIGHT.TURN_STICK_RATE - av[1]) * g;
    }

    // clamp so a flung mouse can't put the hull into an unrecoverable spin
    const maxA = FLIGHT.MAX_ANG_VEL;
    for (let i = 0; i < 3; i++) av[i] = clamp(av[i], -maxA, maxA);
    if (Math.abs(av[0]) < 1e-4) av[0] = 0;
    if (Math.abs(av[1]) < 1e-4) av[1] = 0;
    if (Math.abs(av[2]) < 1e-4) av[2] = 0;

    if (av[0] !== 0) this._applyLocalRotation(AXIS_X, av[0] * dt);
    if (av[1] !== 0) this._applyLocalRotation(AXIS_Y, av[1] * dt);
    if (av[2] !== 0) this._applyLocalRotation(AXIS_Z, av[2] * dt);
    Quat.normalize(ship.quat, ship.quat);
    // expose for the HUD turn-rate readout + RCS puff visuals
    ship.angVel = av;

    // -- flight assist toggle (fly-by-wire drift damping) ----------------------
    if (input.wasPressed('flightAssist')) {
      ship.flightAssist = !ship.flightAssist;
      this.events?.emit('flight:assist', ship.flightAssist);
    }

    // -- main drive: W/S along the nose ---------------------------------------
    let thrust = 0;
    if (input.isDown('forward')) thrust += 1;
    if (input.isDown('back')) thrust -= 1;
    thrust = clamp(thrust + input.moveAxis[1], -1, 1); // touch stick y
    ship.boosting = input.isDown('sprint') && thrust > 0;
    ship.thrust = thrust * (ship.boosting ? FLIGHT.BOOST_MULT : 1);
    if (thrust !== 0) {
      Quat.rotateVec3(this._fwd, ship.quat, FORWARD);
      // Thrust over MASS: a hauler with 1.9x the mass and 0.72x the drive
      // accelerates at 0.38 of the cutter, which is the whole character of
      // flying one. Newton, not a difficulty slider.
      const accel = (thrust > 0 ? FLIGHT.THRUST_ACCEL : FLIGHT.RETRO_ACCEL)
        * Math.abs(ship.thrust) * (this.cls.thrust / this.cls.mass);
      Vec3.scaleAndAdd(ship.vel, ship.vel, this._fwd, Math.sign(thrust) * accel * dt);
    }

    // -- translational RCS: Q/E sidestep, R/F climb/dive (6-DOF) ---------------
    let sx = 0, sy = 0;
    if (input.isDown('strafeRight')) sx += 1;
    if (input.isDown('strafeLeft')) sx -= 1;
    if (input.isDown('strafeUp')) sy += 1;
    if (input.isDown('strafeDown')) sy -= 1;
    ship.strafe[0] = sx; ship.strafe[1] = sy;
    if (sx !== 0) {
      Quat.rotateVec3(this._axis, ship.quat, RIGHT);
      Vec3.scaleAndAdd(ship.vel, ship.vel, this._axis, sx * FLIGHT.STRAFE_ACCEL * dt);
    }
    if (sy !== 0) {
      // GROUND MODE: the vertical jets push along WORLD up, not hull up.
      //
      // In space "up" is whatever the hull says it is and that is correct. Over
      // a planet it is catastrophic: you break cloud pitched thirty-five degrees
      // nose-down so you can see the ground, and the thruster you reach for to
      // arrest the descent is pointing thirty-five degrees off vertical — most
      // of your lift goes sideways and you hit anyway. That is why landing
      // always ended in a crash.
      //
      // A landing thruster is a gimballed ventral jet whose whole job is to hold
      // the hull off the ground, so it fires DOWN whatever the ship is doing.
      //
      // AND IT PUSHES HARDER THAN THE RCS DOES, which is the other half of the
      // same fix and was missing.
      //
      // The manoeuvring jets are 46 u/s². Gravity at one g is 34, so the net
      // climb authority over an Earth-like world was twelve — arresting the
      // seventy units a second you break cloud with took six seconds and two
      // hundred metres, out of the three hundred and thirty you are given. Over
      // 1.3 g the net was two, which is thirty-five seconds and twelve hundred
      // metres: not a hard landing, an arithmetically impossible one. That is
      // the whole of "ship control when landing is not good".
      //
      // A descent engine is not an RCS quad. It is the largest thruster on the
      // ship after the main drive, because holding a hull off a planet is the
      // hardest thing it ever does, so in ground mode the vertical axis gets
      // its own figure — enough to out-lift two g with margin left to fly on.
      if (ship.groundMode) Vec3.set(this._axis, 0, 1, 0);
      else Quat.rotateVec3(this._axis, ship.quat, UP);
      const vAcc = ship.groundMode ? FLIGHT.DESCENT_ACCEL : FLIGHT.STRAFE_ACCEL;
      Vec3.scaleAndAdd(ship.vel, ship.vel, this._axis, sy * vAcc * dt);
    }

    // -- flight-assist brake (Space) + auto drift-bleed ------------------------
    ship.braking = input.isDown('jump');
    const anyTranslate = thrust !== 0 || sx !== 0 || sy !== 0;
    if (ship.braking) {
      const damp = Math.exp(-FLIGHT.BRAKE_DAMP * dt);
      Vec3.scale(ship.vel, ship.vel, damp);
      if (ship.speed < 0.4) Vec3.set(ship.vel, 0, 0, 0);
    } else if (ship.flightAssist && !anyTranslate) {
      // fly-by-wire: with no thruster input, gently bleed residual drift so the
      // ship settles to a hover instead of coasting forever — precise docking
      const damp = Math.exp(-FLIGHT.ASSIST_DAMP * dt);
      Vec3.scale(ship.vel, ship.vel, damp);
      if (ship.speed < 0.25) Vec3.set(ship.vel, 0, 0, 0);
    }

    // -- soft speed cap -------------------------------------------------------------
    const speed = ship.speed;
    if (speed > FLIGHT.SOFT_MAX_SPEED) {
      Vec3.scale(ship.vel, ship.vel, FLIGHT.SOFT_MAX_SPEED / speed);
    }

    // -- integrate ---------------------------------------------------------------------
    Vec3.scaleAndAdd(ship.pos, ship.pos, ship.vel, dt);
    ship.updateConjugate();
  }

  _applyLocalRotation(axis, rad) {
    Quat.setAxisAngle(this._dq, axis, clamp(rad, -0.12, 0.12));
    Quat.multiply(this._tmpQ, this.ship.quat, this._dq);
    Quat.copy(this.ship.quat, this._tmpQ);
  }
}
