/**
 * CREW — the people on a station, and the first thing in this game that is
 * alive and not trying to kill you.
 *
 * Everything that has ever moved on a deck so far has been a boarder, a drone
 * or the Hollow. A station with eleven compartments, four counters and a
 * taproom, and nobody standing in any of it, reads as a set — and it undercuts
 * the one thing a station is for, which is being somewhere that people are.
 *
 * BUILT ON THE BOARDER MACHINERY ON PURPOSE. Same part-mesh layout, same
 * `actors` hook on the interior renderer, so a factor behind a counter is lit
 * by the compartment they are standing in and by your lamp exactly like the
 * wall behind them. There is no NPC shader and no billboard sprite. What is different
 * is everything above the neck of the code: these do not path, do not attack
 * and cannot be hurt — they stand at a post, shift their weight, and turn to
 * look at you when you get close.
 *
 * WHY THEY DO NOT WALK. A station concourse is a room, not a corridor, and
 * pedestrians crossing an open room need avoidance, queueing and a reason to be
 * going somewhere — three systems' worth of work to produce motion the player
 * reads as "background people milling". A figure standing at a post, breathing,
 * that turns its head when you approach, reads as a person at a fraction of the
 * cost and never walks through a crate.
 *
 * SIX ARCHETYPES, each keyed to the compartment it belongs in. The textures are
 * existing atlas layers — `suit_rack` is literally worn suit fabric and
 * `seat_leather` is worn leather, which is what dock crews and factors are
 * actually dressed in. No new texture was needed and none was added.
 */
import { Mat4 } from '../utils/MathUtils.js';
import { MeshBuilder } from '../rendering/MeshBuilder.js';

/**
 * @typedef {object} CrewKind
 * @property {string} role   what the interact prompt calls them
 * @property {string} mat    atlas layer for the body
 * @property {string} accent atlas layer for jacket, boots, kit
 * @property {number} height metres, eye-line included
 * @property {string} build  'lean' | 'heavy' — changes shoulder and hip width
 * @property {boolean} [helm] wears a respirator/visor instead of a bare head
 */
/** @type {Record<string, CrewKind>} */
export const CREW_KINDS = {
  // Kestrel's own, in a company coverall, behind a counter.
  chandler: { role: 'CHANDLER', mat: 'suit_rack', accent: 'seat_leather', height: 1.74, build: 'lean' },
  // The parts window. Heavier, in a work jacket, hands never still.
  armourer: { role: 'ARMOURER', mat: 'seat_leather', accent: 'machinery', height: 1.71, build: 'heavy' },
  // Hull broker. Long coat, no tools, the only one who is not dirty.
  broker: { role: 'HULL BROKER', mat: 'seat_leather', accent: 'suit_rack', height: 1.78, build: 'lean' },
  // Dock crew, still in half a suit because the shift is not over.
  dockhand: { role: 'DOCKHAND', mat: 'suit_rack', accent: 'machinery', height: 1.69, build: 'heavy', helm: true },
  // Station clinic. White fixture cloth, and a hard case at her feet.
  medic: { role: 'STATION MEDIC', mat: 'fixture_white', accent: 'suit_rack', height: 1.66, build: 'lean' },
  // Harbour office / customs. Uniform, clipboard, unmoved by anything.
  officer: { role: 'HARBOUR OFFICER', mat: 'seat_leather', accent: 'locker', height: 1.75, build: 'lean' },
};

/** Build the five parts of a body. Same shape contract as Boarders'. */
function buildParts(kind, layer, accent) {
  const K = CREW_KINDS[kind];
  const H = K.height;
  const heavy = K.build === 'heavy';
  const parts = [];
  const push = (name, pivot, fn, swing = 0, side = 0, anti = 1) => {
    const b = new MeshBuilder();
    fn(b);
    parts.push({ name, pivot, swing, side, anti, data: b.finish() });
  };
  const L = { all: layer };
  const A = { all: accent };
  // One dim self-lit feature each, same rule as the boarders: a wholly unlit
  // figure at the edge of a lamp cone is a silhouette you cannot separate from
  // a locker. Here it is a collar tab or a visor, and it is small.
  const GLOW = { emissive: 0.42 };

  const sh = heavy ? 0.27 : 0.23;  // half shoulder width
  const hip = heavy ? 0.21 : 0.18;

  push('torso', [0, 0, 0], (b) => {
    // Hips up to chest, tapering the other way from the boarders — a person is
    // widest at the shoulder, which is most of why a humanoid reads as human.
    b.box([-hip, H * 0.46, -0.13], [hip, H * 0.63, 0.13], L, { uvScale: 2.0 });
    b.box([-sh, H * 0.63, -0.15], [sh, H * 0.83, 0.15], L, { uvScale: 1.8 });
    // Jacket yoke across the shoulders — the accent that separates the archetypes.
    b.box([-sh - 0.02, H * 0.78, -0.17], [sh + 0.02, H * 0.845, 0.17], A, { uvScale: 2.6 });
    // Belt.
    b.box([-hip - 0.02, H * 0.52, -0.15], [hip + 0.02, H * 0.57, 0.15], A, { uvScale: 3.4 });
    // Neck, then head. The step between them is what stops head and body
    // reading as one mass at 480x270.
    b.box([-0.055, H * 0.845, -0.055], [0.055, H * 0.885, 0.055], L, { uvScale: 3.6 });
    if (K.helm) {
      // A half-suit helmet with the visor up: a shell and a dark band.
      b.box([-0.115, H * 0.875, -0.115], [0.115, H * 1.0, 0.115], A, { uvScale: 2.4 });
      b.box([-0.1, H * 0.915, -0.135], [0.1, H * 0.96, -0.1], L, { uvScale: 4, ...GLOW });
    } else {
      b.box([-0.095, H * 0.875, -0.095], [0.095, H * 0.995, 0.095], L, { uvScale: 3.0 });
      // Hair/cap mass on the crown, so the head is not a bare cube.
      b.box([-0.1, H * 0.965, -0.1], [0.1, H * 1.005, 0.1], A, { uvScale: 3.8 });
      // Collar tab — the lit detail.
      b.box([-0.045, H * 0.836, -0.16], [0.045, H * 0.862, -0.14], A, { uvScale: 5, ...GLOW });
    }
  });

  for (const s of [-1, 1]) {
    // Arms hang. `swing` is tiny — this is a weight shift, not a walk cycle.
    push(`arm${s}`, [s * (sh + 0.055), H * 0.815, 0], (b) => {
      b.box([-0.055, -0.24, -0.06], [0.055, 0.02, 0.06], L, { uvScale: 2.8 });
      b.box([-0.05, -0.47, -0.055], [0.05, -0.22, 0.055], L, { uvScale: 3.0 });
      b.box([-0.052, -0.55, -0.06], [0.052, -0.45, 0.06], A, { uvScale: 4.0 }); // glove
    }, 0.16, s, -1);
    push(`leg${s}`, [s * (hip * 0.55), H * 0.48, 0], (b) => {
      b.box([-0.08, -0.36, -0.08], [0.08, 0.02, 0.08], L, { uvScale: 2.6 });
      b.box([-0.07, -0.76, -0.075], [0.07, -0.34, 0.075], L, { uvScale: 2.9 });
      b.box([-0.085, -0.84, -0.13], [0.085, -0.74, 0.09], A, { uvScale: 3.6 }); // boot
    }, 0.1, s, 1);
  }
  return parts;
}

export class Crew {
  constructor() {
    /** @type {Array<{kind:string,pos:number[],yaw:number,home:number,zone:string,id:string,phase:number,shift:number}>} */
    this.actors = [];
    this.meshes = {};
    this._built = false;
    this.clock = 0;
    this._a = new Float32Array(16);
    this._b = new Float32Array(16);
    this._m = new Float32Array(16);
    this._c = new Float32Array(16);
  }

  build(atlas, renderer) {
    if (this._built) return;
    this._built = true;
    for (const kind of Object.keys(CREW_KINDS)) {
      const K = CREW_KINDS[kind];
      const parts = buildParts(kind, atlas.layer(K.mat), atlas.layer(K.accent));
      this.meshes[kind] = parts.map((p) => ({
        name: p.name, pivot: p.pivot, swing: p.swing, side: p.side, anti: p.anti,
        mesh: renderer.createInteriorMesh(p.data.vertexData, p.data.indexData),
      }));
    }
  }

  /**
   * Take a deck's roster. Each entry is authored by the room dresser it belongs
   * to (see interior/rooms/Station.js), so placement lives with every other
   * placement rather than in a table over here that nobody would keep in sync.
   */
  place(list) {
    this.actors.length = 0;
    for (let i = 0; i < (list?.length ?? 0); i++) {
      const n = list[i];
      if (!CREW_KINDS[n.kind]) continue;
      this.actors.push({
        kind: n.kind, id: n.id, name: n.name, zone: n.zone,
        pos: [n.x, 0, n.z],
        yaw: n.yaw ?? 0,
        home: n.yaw ?? 0,      // the way they face when nobody is near
        phase: i * 1.7,        // desynchronised breathing
        shift: 0,              // -1..1 weight shift, drifts
      });
    }
  }

  clear() { this.actors.length = 0; }

  /**
   * Breathe, shift weight, and turn to face whoever walked up. The turn is the
   * only reactive thing they do and it is the whole illusion: a figure that
   * stares straight ahead while you circle it is a mannequin.
   */
  update(dt, eye) {
    this.clock += dt;
    for (const a of this.actors) {
      a.phase += dt * 1.25;
      // Weight shift on a slow, irrational period so two people standing near
      // each other never fall into step.
      a.shift = Math.sin(this.clock * 0.31 + a.phase * 0.17);
      if (!eye) continue;
      const dx = eye[0] - a.pos[0];
      const dz = eye[2] - a.pos[2];
      const d2 = dx * dx + dz * dz;
      // Six metres: close enough that being ignored would be strange, far
      // enough that they are not tracking you across the concourse.
      let want = a.home;
      if (d2 < 36) want = Math.atan2(-dx, -dz); // camera yaw convention
      let d = want - a.yaw;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      a.yaw += d * Math.min(1, dt * 2.6);
    }
  }

  /** Nearest actor within `range`, or null. Used for the talk prompt. */
  nearest(pos, range = 2.6) {
    let best = null;
    let bd = range * range;
    for (const a of this.actors) {
      const dx = pos[0] - a.pos[0], dz = pos[2] - a.pos[2];
      const d2 = dx * dx + dz * dz;
      if (d2 < bd) { bd = d2; best = a; }
    }
    return best;
  }

  /** Same contract as Boarders.draw — one call per part, zone-lit. */
  draw(drawZoneLit, zoneAt) {
    for (const a of this.actors) {
      const parts = this.meshes[a.kind];
      if (!parts) continue;
      const zone = zoneAt?.(a.pos[0], a.pos[2]);
      const zid = zone?.id ?? a.zone;
      const nbs = zone?.neighbours ?? [];

      // Breath: 2 cm of rise on the whole body. Small enough that you never
      // catch it directly and large enough that the figure is not a statue.
      const breath = Math.sin(a.phase * 0.9) * 0.012;
      Mat4.translation(this._a, a.pos[0], a.pos[1] + breath, a.pos[2]);
      Mat4.rotationY(this._b, a.yaw);
      Mat4.multiply(this._m, this._a, this._b);
      // Weight on one hip: a small roll about the forward axis.
      Mat4.rotationZ(this._a, a.shift * 0.022);
      Mat4.multiply(this._m, this._m, this._a);

      for (const p of parts) {
        Mat4.translation(this._a, p.pivot[0], p.pivot[1], p.pivot[2]);
        Mat4.multiply(this._b, this._m, this._a);
        if (p.swing) {
          Mat4.rotationX(this._c,
            Math.sin(a.phase * 0.62) * p.swing * 0.5 * p.side * p.anti);
          Mat4.multiply(this._b, this._b, this._c);
        }
        drawZoneLit(zid, nbs, p.mesh, this._b);
      }
    }
  }
}
