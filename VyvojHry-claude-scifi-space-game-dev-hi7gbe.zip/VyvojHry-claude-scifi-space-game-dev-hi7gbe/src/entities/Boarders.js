/**
 * BOARDERS — the things that are still aboard, and what happens when they
 * notice you.
 *
 * Owner ask, verbatim: *"there will be whole enemy ship model and whole enemy
 * ship interior with loot, enemy aliens which player needs to kill."* The hull
 * and its deck already existed (`WreckPlan`, `ShipMap`); this is the half that
 * was missing — an actor that occupies the deck, sees you, closes, hurts you,
 * and can be killed.
 *
 * WHY THIS IS NOT THE HOLLOW, and why that distinction is load-bearing.
 * `context/03` §6 and `context/04` are explicit that the Hollow cannot be
 * fought: it has no health, no hitbox and no defeat state, and `PersonalCombat`
 * enforces that by construction. If the only thing in the dark were unkillable,
 * a weapon would be a decoration. Boarders are the opposite pole and exist to
 * make the weapon mean something: they are ordinary, mortal, and they die. The
 * dread stays with the one thing that does not.
 *
 * THREE SPECIES, straight off the faction notes in `context/03` §5:
 *
 *   CARRION      Original to us: the scavenger organism that gets into a hull
 *                once nobody is maintaining it. Fast, weak, arrives in threes.
 *                It is the "something moved" enemy — the one that makes you
 *                spend a magazine on a noise.
 *   KETH BOARDER The Armada's own salvage party, angular black/red armour, and
 *                the only kind that shoots back. Slow, tough, deliberate.
 *   DRIFT DRONE  The machine race, chassis #2a2a30 with white fractal marking.
 *                It does not hurry, it does not stop, and it does not react to
 *                anything you do except by walking at you. Silent — the scanner
 *                is the only warning you get.
 *
 * PATHING IS A STRAIGHT LINE ON PURPOSE. A wreck deck is one spine (see
 * `WreckPlan`), so "toward the player" and "down the corridor" are the same
 * vector; the collision resolver slides an actor around a crate for free. A
 * navmesh would be a week of work to produce identical motion in a corridor
 * 2.8 m wide.
 *
 * EVERY ACTOR IS DETERMINISTIC PER HULL. The spawn rolls off the wreck's id, so
 * a given derelict has the same things aboard every time you visit it and the
 * one beside it has different ones — the same rule the loot already follows.
 * Kills persist in the save, so a hull you cleared stays cleared.
 */
import { Vec3, Mat4, rayAabb } from '../utils/MathUtils.js';
import { MeshBuilder } from '../rendering/MeshBuilder.js';
import { RNG } from '../utils/RNG.js';

/** FNV-1a over an id string — RNG wants a uint32, and hull ids are text. */
function hash(s) {
  let h = 0x811c9dc5;
  const t = String(s);
  for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}

/**
 * @typedef {object} BoarderKind
 * @property {string} name       what the HUD calls it
 * @property {number} hp
 * @property {number} speed      metres/second while hunting
 * @property {number} notice     metres at which it becomes aware of you
 * @property {number} reach      metres at which it can strike
 * @property {number} melee      damage per strike
 * @property {number} wind       seconds of windup before a strike lands
 * @property {number} cadence    seconds between strikes
 * @property {number} height     metres, floor to crown — drives the hitbox
 * @property {number} halfW      metres, half the body width
 * @property {string} mat        atlas layer for the body
 * @property {number} [shot]     damage per bolt (ranged kinds only)
 * @property {number} [shotRange] metres a bolt carries
 * @property {number} [shotEvery] seconds between bolts
 * @property {number} deaf       0..1 — how much noise it takes to rouse it
 * @property {string} rouse      the line printed when it wakes
 */

/** @type {Record<string, BoarderKind>} */
export const BOARDER_KINDS = {
  carrion: {
    name: 'CARRION', hp: 28, speed: 3.9, notice: 11, reach: 1.6,
    // 1.45 m and UPRIGHT. The first two builds were a low quadruped 2.3 m long
    // and 0.35 m tall, and from a standing eye at four metres you did not see a
    // creature — you looked down onto its back and saw a plank on the deck.
    // The camera runs an 84° VERTICAL field, which is very wide; anything that
    // presents its top face to a standing player is going to read as floor.
    melee: 7, wind: 0.28, cadence: 0.8, height: 1.45, halfW: 0.42,
    mat: 'alien_chitin', deaf: 0.25,
    rouse: 'SOMETHING COMES OFF THE DECKHEAD AT A RUN',
  },
  keth: {
    name: 'KETH BOARDER', hp: 74, speed: 2.2, notice: 17, reach: 2.0,
    melee: 15, wind: 0.5, cadence: 1.5, height: 1.95, halfW: 0.52,
    mat: 'alien_armour', deaf: 0.5,
    shot: 11, shotRange: 24, shotEvery: 1.9,
    rouse: 'ARMOURED FIGURE — IT HAS ALREADY SEEN YOU',
  },
  drift: {
    name: 'DRIFT DRONE', hp: 112, speed: 1.55, notice: 22, reach: 2.1,
    melee: 21, wind: 0.72, cadence: 2.1, height: 1.8, halfW: 0.6,
    mat: 'alien_crystal', deaf: 1.1, // effectively cannot be roused by noise
    rouse: 'A DRIFT DRONE UNFOLDS AND BEGINS WALKING',
  },
};

/** Where a hostile is in its head, one frame at a time. */
const STATE = {
  DORMANT: 'dormant', // has not noticed you
  ROUSING: 'rousing', // has, and is getting up
  HUNTING: 'hunting', // closing
  WINDING: 'winding', // committed to a strike
  DEAD: 'dead',
};

/** Seconds a corpse takes to go down, and how long the remains stay strippable. */
const FALL_TIME = 0.55;
/** How close you have to be to go through a body. */
const STRIP_REACH = 2.2;

/**
 * ONE BODY, FIVE PARTS. Torso (with head), two arms, two legs, each built with
 * its own joint at the mesh origin so the animation is a rotation about that
 * origin and nothing has to be re-skinned.
 *
 * Five draw calls per actor and at most six actors alive on a deck is thirty
 * draws against a 200 budget — affordable, and the alternative (one rigid mesh)
 * gives you a statue sliding along the floor, which at this resolution reads
 * worse than no enemy at all.
 */
function buildParts(kind, layer, accent) {
  const K = BOARDER_KINDS[kind];
  const H = K.height;
  const parts = [];
  /**
   * `side` and `anti` are stored rather than parsed back out of the name. The
   * first cut derived them from `name.endsWith('1')`, which is true of both
   * `arm1` and `arm-1` — every limb on the body swung in phase and the thing
   * walked like a wind-up toy.
   *
   * side: -1/+1, opposite limbs half a cycle apart.
   * anti: arms swing against legs, which is what makes a gait read as a gait.
   */
  const push = (name, pivot, fn, swing = 0, side = 0, anti = 1) => {
    const b = new MeshBuilder();
    fn(b);
    parts.push({ name, pivot, swing, side, anti, data: b.finish() });
  };
  const L = { all: layer };
  const A = { all: accent };
  /**
   * ONE LIT DETAIL PER BODY, and it is small.
   *
   * A derelict deck runs at ambient 0.06 × 0.18 and the helmet lamp reaches
   * about nine metres, so a wholly unlit creature at the edge of the cone is a
   * silhouette you cannot separate from a crate — which is the correct amount
   * of frightening exactly once and then just unfair. Each species gets a
   * single self-lit feature: eyes, a visor slit, a sensor strip.
   *
   * `emissive` blends the fragment toward its own unlit albedo (see
   * interior.frag), so at 0.5 this is a DIM feature in the species' existing
   * colours — not an added light, not a glow, and nothing near the banned neon
   * families. It is what makes the thing findable without making it a lamp.
   */
  const GLOW = { emissive: 0.5 };

  if (kind === 'carrion') {
    /**
     * HUNCHED, AND STANDING UP.
     *
     * Two builds went into the bin here and both failed the same way: a low
     * four-legged body 2.3 m long presents its BACK to a standing player, and
     * the back of a thing is a horizontal plane, and a horizontal plane at eye
     * height 1.6 reads as deck plating. It was a creature in the data and a
     * plank on the screen.
     *
     * So it stands. A hunched biped: heavy hind legs, a body carried high and
     * tilted forward, a skull thrust out ahead of the chest and a short tail
     * cocked up behind for balance. Every one of those is a VERTICAL edge or a
     * horizontal one against the wall behind it, which is what a silhouette is
     * made of. It still runs on its hind legs at nearly 4 m/s; the forelimbs
     * are what it kills with, which is why they hang free.
     */
    /**
     * THE PROPORTION THAT MATTERS is depth against height. The Keth reads at a
     * glance because its torso is 0.84 tall and 0.44 deep — a tall, shallow
     * shape, so almost all of it faces you. The carrion's first two builds were
     * 1.76 m deep and 0.78 tall, and a shape with twice as much depth as height
     * shows you mostly its TOP, which under an 84° lens spills down the screen
     * as a flat plate. This one is 1.17 deep and 1.45 tall, and that single
     * ratio is the whole fix.
     */
    push('torso', [0, H * 0.6, 0], (b) => {
      // Chest, carried high and forward.
      b.box([-0.22, -0.02, -0.3], [0.22, 0.48, 0.22], L, { uvScale: 1.9 });
      // Hips, lower and narrower — the taper is the animal shape.
      b.box([-0.18, -0.16, -0.1], [0.18, 0.06, 0.24], L, { uvScale: 2.1 });
      // Dorsal spines up the back, tallest at the shoulder.
      for (let i = 0; i < 4; i++) {
        const y = 0.4 - i * 0.12;
        const w2 = 0.055 - i * 0.006;
        b.box([-w2, y, 0.18], [w2, y + 0.1, 0.18 + 0.16 - i * 0.03], A, { uvScale: 3.2 });
      }
      // Neck out of the top of the chest, then the skull, with a step between
      // them so head and body never read as one mass.
      b.box([-0.09, 0.28, -0.44], [0.09, 0.44, -0.26], L, { uvScale: 3 });
      b.box([-0.15, 0.18, -0.66], [0.15, 0.42, -0.4], L, { uvScale: 2.7 });
      // Mandibles, splayed wider than the neck.
      b.box([-0.22, 0.16, -0.8], [-0.07, 0.28, -0.6], A, { uvScale: 3.4 });
      b.box([0.07, 0.16, -0.8], [0.22, 0.28, -0.6], A, { uvScale: 3.4 });
      // The eye cluster between them — the one lit thing on it.
      b.box([-0.09, 0.3, -0.68], [0.09, 0.38, -0.62], A, { uvScale: 5, ...GLOW });
      // Tail: a stub, cocked up. Long enough to be a diagonal in the
      // silhouette, short enough not to turn the body back into a plank.
      b.box([-0.06, -0.06, 0.22], [0.06, 0.08, 0.5], L, { uvScale: 3 });
      b.box([-0.045, 0.02, 0.46], [0.045, 0.14, 0.72], A, { uvScale: 3.6 });
    });
    for (const s of [-1, 1]) {
      // Forelimbs: shoulder high, hanging, ending in the claw it strikes with.
      push(`fore${s}`, [s * 0.22, H * 0.88, -0.1], (b) => {
        b.box([-0.07, -0.3, -0.07], [0.07, 0.06, 0.07], L, { uvScale: 2.9 });
        b.box([-0.06, -0.54, -0.14], [0.06, -0.26, 0.04], L, { uvScale: 3.2 });
        b.box([-0.055, -0.66, -0.26], [0.055, -0.5, 0.0], A, { uvScale: 3.8 });
      }, 0.75, s, -1);
      // Hind legs: thigh back, shank down, splayed foot on the deck. These
      // carry the whole silhouette and they are what it runs on.
      push(`hind${s}`, [s * 0.18, H * 0.586, 0.02], (b) => {
        b.box([-0.1, -0.26, -0.04], [0.1, 0.06, 0.24], L, { uvScale: 2.5 });
        b.box([-0.08, -0.78, -0.02], [0.08, -0.22, 0.14], L, { uvScale: 2.9 });
        b.box([-0.095, -0.86, -0.18], [0.095, -0.74, 0.08], A, { uvScale: 3.6 });
      }, 0.62, s, 1);
    }
    return parts;
  }

  if (kind === 'drift') {
    // Geometric, symmetrical, and it has no face. A machine that was not
    // designed to be looked at by anything that would care.
    push('torso', [0, H * 0.55, 0], (b) => {
      b.box([-0.4, -0.42, -0.26], [0.4, 0.46, 0.26], L, { uvScale: 1.4 });
      // the fractal collar
      b.box([-0.46, 0.3, -0.32], [0.46, 0.44, 0.32], A, { uvScale: 2 });
      // sensor block where a head would be, canted forward
      b.box([-0.18, 0.46, -0.2], [0.18, 0.78, 0.14], L, { uvScale: 2.6 });
      b.box([-0.13, 0.56, -0.26], [0.13, 0.66, -0.18], A, { uvScale: 4, ...GLOW });
    });
    for (const s of [-1, 1]) {
      push(`arm${s}`, [s * 0.44, H * 0.78, 0], (b) => {
        b.box([-0.12, -0.5, -0.12], [0.12, 0.1, 0.12], L, { uvScale: 2.4 });
        b.box([-0.1, -0.82, -0.1], [0.1, -0.46, 0.1], A, { uvScale: 3 });
      }, 0.5, s, -1);
      push(`leg${s}`, [s * 0.22, H * 0.5, 0], (b) => {
        b.box([-0.14, -0.9, -0.14], [0.14, 0.06, 0.14], L, { uvScale: 2 });
        b.box([-0.16, -0.98, -0.22], [0.16, -0.86, 0.14], A, { uvScale: 3 });
      }, 0.62, s, 1);
    }
    return parts;
  }

  // KETH: a soldier in plate. Upright, broad in the shoulder, and the only one
  // of the three you would describe as a person.
  push('torso', [0, H * 0.56, 0], (b) => {
    b.box([-0.36, -0.4, -0.22], [0.36, 0.44, 0.22], L, { uvScale: 1.5 });
    // pauldrons — the angular Keth read, per context/03 §5
    b.box([-0.56, 0.2, -0.26], [-0.3, 0.46, 0.26], A, { uvScale: 2.2 });
    b.box([0.3, 0.2, -0.26], [0.56, 0.46, 0.26], A, { uvScale: 2.2 });
    // helm with a slit visor, no glass
    b.box([-0.19, 0.46, -0.2], [0.19, 0.82, 0.18], L, { uvScale: 2.6 });
    b.box([-0.17, 0.6, -0.24], [0.17, 0.68, -0.19], A, { uvScale: 4, ...GLOW });
    // backpack: the thing that makes the silhouette unmistakable from behind
    b.box([-0.24, -0.14, 0.2], [0.24, 0.4, 0.44], A, { uvScale: 2.4 });
  });
  for (const s of [-1, 1]) {
    push(`arm${s}`, [s * 0.42, H * 0.78, 0], (b) => {
      b.box([-0.13, -0.44, -0.13], [0.13, 0.1, 0.13], L, { uvScale: 2.4 });
      b.box([-0.11, -0.78, -0.11], [0.11, -0.4, 0.11], L, { uvScale: 2.8 });
      // the weapon, on the right arm only — a stubby bullpup slung under
      if (s > 0) b.box([-0.07, -0.82, -0.54], [0.07, -0.6, 0.1], A, { uvScale: 3 });
    }, 0.55, s, -1);
    push(`leg${s}`, [s * 0.2, H * 0.5, 0], (b) => {
      b.box([-0.15, -0.52, -0.15], [0.15, 0.06, 0.15], L, { uvScale: 2 });
      b.box([-0.13, -0.94, -0.13], [0.13, -0.48, 0.13], L, { uvScale: 2.2 });
      b.box([-0.15, -1.0, -0.2], [0.15, -0.88, 0.16], A, { uvScale: 3 });
    }, 0.72, s, 1);
  }
  return parts;
}

export class Boarders {
  /**
   * @param {object} deps
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(t:string)=>void} deps.notify
   * @param {(dmg:number, from:string)=>void} deps.hurtPlayer
   */
  constructor({ events, notify, hurtPlayer }) {
    this.events = events;
    this.notify = notify ?? (() => {});
    this.hurtPlayer = hurtPlayer ?? (() => {});
    /** @type {Array<object>} live and dead actors on the current deck */
    this.actors = [];
    /** Hulls already cleared, by id — rides in the save. */
    this.cleared = new Set();
    /** @type {Record<string, Array<object>>} built part meshes per kind */
    this.meshes = {};
    /** The collision map of the deck they are standing on. */
    this.collision = null;
    /** Seconds since the deck was entered; paces the first contact. */
    this.clock = 0;
    /** `(x, z) => void` — a moving body, for the handheld scanner. */
    this.onPing = null;
    /**
     * Enemy bolts in flight, world space: `{a, b, t, hit}`. Drawn projected
     * through the camera the same way `PersonalCombat` draws its impacts —
     * there is no third render pass here, only rects on the 480×270 grid.
     */
    this.tracers = [];
    this._hullId = null;
    // Scratch matrices — this runs per part per actor per frame.
    this._m = Mat4.create();
    this._a = Mat4.create();
    this._b = Mat4.create();
    this._c = Mat4.create();
    this._v = Vec3.create();
  }

  /**
   * Build the part meshes once. Called after the atlas exists, so the layer
   * lookups resolve; the meshes themselves never change.
   */
  build(atlas, renderer) {
    if (this._built) return;
    this._built = true;
    for (const kind of Object.keys(BOARDER_KINDS)) {
      const K = BOARDER_KINDS[kind];
      const layer = atlas.layer(K.mat);
      // Accent = the same material; the ACCENT is the geometry, not a second
      // texture. One layer per species keeps the silhouette legible in a helmet
      // lamp, which is the only light these are ever seen in.
      const parts = buildParts(kind, layer, layer);
      this.meshes[kind] = parts.map((p) => ({
        name: p.name, pivot: p.pivot, swing: p.swing, side: p.side, anti: p.anti,
        mesh: renderer.createInteriorMesh(p.data.vertexData, p.data.indexData),
      }));
    }
  }

  /** Nothing aboard, nothing to draw. */
  clear() {
    this.actors.length = 0;
    this.tracers.length = 0;
    this._hullId = null;
    this.clock = 0;
  }

  get alive() { return this.actors.filter((a) => a.state !== STATE.DEAD).length; }
  get hunting() { return this.actors.some((a) => a.state === STATE.HUNTING || a.state === STATE.WINDING); }

  /**
   * Populate a hull. `spots` are candidate floor positions with the zone they
   * are in — supplied by the caller from the deck plan, because the deck knows
   * its own geometry and this module should not have to parse a room rect.
   *
   * @param {string} hullId          stable id — the same hull rolls the same crew
   * @param {Array<{pos:number[], zone:string, depth:number}>} spots
   * @param {object} opts            {danger: 0..1, collision}
   */
  spawnFor(hullId, spots, opts = {}) {
    this.clear();
    this._hullId = hullId;
    this.collision = opts.collision ?? null;
    if (this.cleared.has(hullId)) return 0; // you have already been through here

    const rng = new RNG(hash(`boarders:${hullId}`));
    const danger = opts.danger ?? 0.5;
    // Between two and six aboard. A wreck with one thing in it is a jump scare;
    // a wreck with ten is a shooting gallery, and neither is the mood.
    const count = Math.min(spots.length, 2 + Math.round(rng.range(0, 2.2 + danger * 2.4)));

    // What is aboard is decided ONCE per hull, not per actor: a derelict has
    // been taken over by one thing, and a corridor with a Keth trooper AND a
    // carrion nest AND a Drift drone in it reads as a bestiary rather than a
    // place. One dominant species, with a chance of a single interloper.
    /**
     * A hull you crippled yourself has its OWN crew aboard, and there is no
     * question about who they are — you have been shooting at them. `species`
     * forces the roll in that case; a found derelict still rolls for what
     * moved in after the crew stopped answering.
     */
    const roll = rng.next();
    const dominant = opts.species
      ?? (roll < 0.45 ? 'carrion' : roll < 0.78 ? 'keth' : 'drift');

    const used = new Set();
    for (let i = 0; i < count; i++) {
      // Deeper spots first — the thing guarding the sealed compartment should
      // be there whether or not the shallow rolls came up.
      let best = -1, bestScore = -1;
      for (let s = 0; s < spots.length; s++) {
        if (used.has(s)) continue;
        const score = spots[s].depth + rng.range(0, 1.4);
        if (score > bestScore) { bestScore = score; best = s; }
      }
      if (best < 0) break;
      used.add(best);
      const spot = spots[best];
      // A found derelict gets the occasional interloper of another kind. A hull
      // with its own crew still aboard does not — everyone in there arrived on
      // the same ship.
      const kind = !opts.species && i > 0 && rng.next() < 0.18
        ? (dominant === 'carrion' ? 'keth' : 'carrion')
        : dominant;
      this.actors.push(this._make(kind, spot, rng));
    }
    return this.actors.length;
  }

  _make(kind, spot, rng) {
    const K = BOARDER_KINDS[kind];
    return {
      kind, K,
      pos: Vec3.create(spot.pos[0], spot.pos[1], spot.pos[2]),
      home: [spot.pos[0], spot.pos[1], spot.pos[2]],
      zone: spot.zone,
      yaw: rng.range(-Math.PI, Math.PI),
      hp: K.hp, maxHp: K.hp,
      state: STATE.DORMANT,
      /** Animation phase: advanced by distance walked, so the gait matches speed. */
      phase: rng.range(0, 6.28),
      /** Seconds left in the current timed state. */
      timer: 0,
      /** Seconds until this one may strike / shoot again. */
      cool: rng.range(0, 0.8),
      shotCool: rng.range(0.4, 2),
      /** Seconds until this one next shows up on the handheld scanner. */
      pingT: rng.range(0, 0.7),
      /** 0..1, drives the flinch lean when hit. */
      flinch: 0,
      /** Seconds into the fall; >= FALL_TIME means it is on the deck. */
      fall: 0,
      /** Loot rolled at death, or null once stripped. */
      remains: null,
      stripped: false,
      id: `${this._hullId}:${this.actors.length}`,
    };
  }

  // -- the deck's own frame ----------------------------------------------------

  /**
   * @param {number} dt
   * @param {number[]} eye        player's eye position
   * @param {object} ctx          {noise: 0..1, crouched: boolean, lampOn: boolean}
   */
  update(dt, eye, ctx = {}) {
    if (!this.actors.length) { this.tracers.length = 0; return; }
    this.clock += dt;
    const noise = ctx.noise ?? 0;
    for (let i = this.tracers.length - 1; i >= 0; i--) {
      this.tracers[i].t -= dt * 4.2; // a bolt is on the glass for about a fifth of a second
      if (this.tracers[i].t <= 0) this.tracers.splice(i, 1);
    }

    for (const a of this.actors) {
      if (a.state === STATE.DEAD) {
        if (a.fall < FALL_TIME) a.fall = Math.min(FALL_TIME, a.fall + dt);
        continue;
      }
      a.flinch = Math.max(0, a.flinch - dt * 3.4);
      a.cool = Math.max(0, a.cool - dt);
      a.shotCool = Math.max(0, a.shotCool - dt);

      const dx = eye[0] - a.pos[0];
      const dz = eye[2] - a.pos[2];
      const dist = Math.hypot(dx, dz);

      switch (a.state) {
        case STATE.DORMANT: {
          // Two ways to be noticed: get close enough to be seen, or make enough
          // noise to be heard. `deaf` is what separates the species — a Drift
          // drone's 1.1 means noise alone can never wake it, only proximity,
          // which is why it is the one you walk past and then regret.
          const seen = dist < a.K.notice * (ctx.crouched ? 0.62 : 1)
            * (ctx.lampOn ? 1.15 : 0.85);
          const heard = noise > a.K.deaf && dist < a.K.notice * 2.2;
          if ((seen || heard) && this.clock > 1.2) this._rouse(a);
          break;
        }
        case STATE.ROUSING:
          a.timer -= dt;
          a.yaw = this._faceYaw(a, dx, dz, dt, 7);
          if (a.timer <= 0) a.state = STATE.HUNTING;
          break;
        case STATE.HUNTING: {
          a.yaw = this._faceYaw(a, dx, dz, dt, 4.5);
          // Ranged kinds stand off and shoot; everything else closes.
          const wantsRange = a.K.shot && dist > a.K.reach * 2.4 && dist < a.K.shotRange;
          if (wantsRange && a.shotCool <= 0) {
            this._shoot(a, dist, eye);
          } else if (dist > a.K.reach * 0.92) {
            this._step(a, dx, dz, dist, dt);
          } else if (a.cool <= 0) {
            a.state = STATE.WINDING;
            a.timer = a.K.wind;
            this.events?.emit('boarder:wind', { kind: a.kind });
          }
          break;
        }
        case STATE.WINDING:
          a.timer -= dt;
          a.yaw = this._faceYaw(a, dx, dz, dt, 6);
          if (a.timer <= 0) {
            // The strike lands only if you are STILL there. A windup you can
            // back out of is the difference between a fight and a damage tick.
            if (dist <= a.K.reach * 1.25) {
              this.hurtPlayer(a.K.melee, a.K.name, a.pos);
              this.events?.emit('boarder:strike', { kind: a.kind, hit: true });
            } else {
              this.events?.emit('boarder:strike', { kind: a.kind, hit: false });
            }
            a.cool = a.K.cadence;
            a.state = STATE.HUNTING;
          }
          break;
        default: break;
      }
    }
  }

  _rouse(a) {
    a.state = STATE.ROUSING;
    a.timer = a.kind === 'carrion' ? 0.35 : a.kind === 'keth' ? 0.6 : 1.1;
    this.notify(a.K.rouse);
    this.events?.emit('boarder:rouse', { kind: a.kind });
  }

  /** Turn toward the player at a limited rate, so nothing snaps. */
  _faceYaw(a, dx, dz, dt, rate) {
    const want = Math.atan2(-dx, -dz); // matches forwardFromAngles' convention
    let d = want - a.yaw;
    while (d > Math.PI) d -= Math.PI * 2;
    while (d < -Math.PI) d += Math.PI * 2;
    return a.yaw + d * Math.min(1, dt * rate);
  }

  /** One step of pursuit, slid around whatever is in the way. */
  _step(a, dx, dz, dist, dt) {
    const sp = a.K.speed * (a.flinch > 0 ? 0.45 : 1);
    const inv = dist > 1e-4 ? 1 / dist : 0;
    const move = [dx * inv * sp * dt, 0, dz * inv * sp * dt];
    if (this.collision) {
      // Half-extents from the species, and a body that is not as tall as the
      // hitbox so it does not catch on the deckhead in a 1.9 m crawlway.
      const half = [a.K.halfW, a.K.height * 0.5 - 0.06, a.K.halfW];
      const c = [a.pos[0], a.pos[1] + half[1], a.pos[2]];
      this.collision.move(c, half, move);
      a.pos[0] = c[0];
      a.pos[2] = c[2];
    } else {
      a.pos[0] += move[0];
      a.pos[2] += move[2];
    }
    // Gait phase advances with DISTANCE, not time: a slowed actor takes slower
    // steps rather than the same steps in place.
    a.phase += sp * dt * 3.4;

    /**
     * THE SCANNER FINALLY HAS SOMETHING TO FIND.
     *
     * `ProximityScanner` has detected exactly one thing since Phase 5 — doors
     * opening — because nothing else aboard moved. A hostile crossing a deck is
     * movement, so it pings, and the handheld becomes the instrument it was
     * always described as: you raise it in a dark corridor to find out whether
     * the thing you heard is coming toward you or away.
     */
    a.pingT -= dt;
    if (a.pingT <= 0) { a.pingT = 0.7; this.onPing?.(a.pos[0], a.pos[2]); }
  }

  _shoot(a, dist, eye) {
    a.shotCool = a.K.shotEvery;
    // Accuracy falls off with range, and a miss is a real outcome — being shot
    // at and not hit is most of what makes a firefight feel like one.
    const hitChance = Math.max(0.25, 0.92 - dist / a.K.shotRange * 0.7);
    const hit = Math.random() < hitChance;
    if (hit) this.hurtPlayer(a.K.shot, a.K.name, a.pos);
    this.events?.emit('boarder:shot', { kind: a.kind, hit });

    /**
     * A BOLT YOU CAN SEE. The shot is a hitscan — at nine metres in a corridor
     * a projectile would only add latency — but a hitscan with no tracer is a
     * number going down for no visible reason, which in an unlit compartment is
     * indistinguishable from a bug. The line is drawn from the muzzle to where
     * the round actually went, so a miss visibly goes PAST you and reads as
     * being shot at rather than as nothing happening.
     */
    if (!eye) return;
    const mz = [
      a.pos[0] + Math.sin(a.yaw) * -0.42,
      a.pos[1] + a.K.height * 0.62,
      a.pos[2] + Math.cos(a.yaw) * -0.42,
    ];
    /**
     * NEVER AT THE EYE, and this is what makes the tracer visible at all.
     *
     * A line drawn from a muzzle straight to the camera projects to a single
     * point at the crosshair — geometrically perfect and completely useless:
     * the first version rendered a bolt every 1.9 seconds and none of them
     * could be seen. A round that hits you hits your SUIT, so the track ends at
     * a shoulder, offset across the line of fire; and every track carries on
     * past you, because a bolt that stopped at your chest reads as a wall
     * between you and the shooter.
     */
    const dx = eye[0] - mz[0], dz = eye[2] - mz[2];
    const dl = Math.hypot(dx, dz) || 1;
    // Perpendicular to the shot, in the horizontal plane.
    const px = -dz / dl, pz = dx / dl;
    const side = (Math.random() < 0.5 ? -1 : 1) * (hit ? 0.34 : 0.7 + Math.random() * 1.1);
    const drop = hit ? -0.28 : (Math.random() - 0.5) * 1.4;
    const end = [
      eye[0] + px * side,
      eye[1] + drop,
      eye[2] + pz * side,
    ];
    // Carry it past: a hit buries itself in you, a miss goes on down the deck.
    const over = hit ? 0.35 : 2.2;
    end[0] += (dx / dl) * over;
    end[2] += (dz / dl) * over;
    if (this.tracers.length > 12) this.tracers.shift();
    this.tracers.push({ a: mz, b: end, t: 1, hit });
  }

  // -- taking damage -----------------------------------------------------------

  /**
   * The hitbox: an AABB about the standing body, tested by `PersonalCombat`
   * before it tests the ship's geometry so a round meets flesh first.
   */
  boxOf(a, out = { min: [0, 0, 0], max: [0, 0, 0] }) {
    const w = a.K.halfW;
    const h = a.state === STATE.DEAD ? Math.min(0.5, a.K.height * 0.34) : a.K.height;
    out.min[0] = a.pos[0] - w; out.min[1] = a.pos[1]; out.min[2] = a.pos[2] - w;
    out.max[0] = a.pos[0] + w; out.max[1] = a.pos[1] + h; out.max[2] = a.pos[2] + w;
    return out;
  }

  /**
   * Nearest live boarder along a ray, or null. Same shape as a
   * `PersonalCombat._hitscan` result so the two can be compared by distance.
   */
  raycast(origin, dir, range) {
    let best = null, bd = range;
    const box = { min: [0, 0, 0], max: [0, 0, 0] };
    for (const a of this.actors) {
      if (a.state === STATE.DEAD) continue;
      this.boxOf(a, box);
      const d = rayAabb(origin[0], origin[1], origin[2], dir[0], dir[1], dir[2],
        box.min, box.max);
      if (d < bd && d > 0.02) { bd = d; best = a; }
    }
    if (!best) return null;
    const p = [origin[0] + dir[0] * bd, origin[1] + dir[1] * bd, origin[2] + dir[2] * bd];
    // Normal points back along the shot: an impact spark on a body should face
    // the shooter, and a body has no flat faces to derive one from.
    return { actor: best, p, dist: bd, n: [-dir[0], -dir[1], -dir[2]] };
  }

  /**
   * Put damage into one. Returns the label to report, or null if the shot did
   * not kill and does not need announcing.
   */
  hurt(a, dmg) {
    if (!a || a.state === STATE.DEAD) return null;
    a.hp -= dmg;
    a.flinch = 1;
    // Being shot at wakes anything, whatever it could or could not hear.
    if (a.state === STATE.DORMANT) this._rouse(a);
    if (a.hp > 0) {
      this.events?.emit('boarder:hurt', { kind: a.kind });
      return null;
    }
    a.state = STATE.DEAD;
    a.fall = 0;
    a.hp = 0;
    this.events?.emit('boarder:down', { kind: a.kind });
    // Everything aboard is worth stripping, and the roll happens at death so a
    // body holds the same thing however long you leave it.
    return a.K.name;
  }

  /** Are they all down? Marks the hull cleared, once. */
  checkCleared() {
    if (!this._hullId || this.cleared.has(this._hullId)) return false;
    if (!this.actors.length || this.alive > 0) return false;
    this.cleared.add(this._hullId);
    return true;
  }

  /** The nearest strippable body within arm's reach, or null. */
  nearRemains(pos) {
    let best = null, bd = STRIP_REACH * STRIP_REACH;
    for (const a of this.actors) {
      if (a.state !== STATE.DEAD || a.stripped) continue;
      const dx = pos[0] - a.pos[0], dz = pos[2] - a.pos[2];
      const d2 = dx * dx + dz * dz;
      if (d2 < bd) { bd = d2; best = a; }
    }
    return best;
  }

  // -- drawing -----------------------------------------------------------------

  /**
   * Draw every actor, one call per part, through the caller's zone-lit draw
   * function — so a boarder is lit by the compartment it is standing in and by
   * your helmet lamp, exactly like the walls around it. There is no separate
   * actor shader and no unlit sprite; the thing coming at you is made of the
   * same light as the deck, which is the only way it sits in the scene.
   *
   * @param {(zoneId:string, neighbours:string[], mesh:object, model:Float32Array)=>void} drawZoneLit
   * @param {(x:number, z:number)=>object} zoneAt
   */
  draw(drawZoneLit, zoneAt) {
    for (const a of this.actors) {
      const parts = this.meshes[a.kind];
      if (!parts) continue;
      const zone = zoneAt?.(a.pos[0], a.pos[2]);
      const zid = zone?.id ?? a.zone;
      const nbs = zone?.neighbours ?? [];

      // Body transform. A dead actor rolls onto its side as it falls, which is
      // one rotation rather than a ragdoll and reads correctly at 480×270.
      const dead = a.state === STATE.DEAD;
      const fall = dead ? Math.min(1, a.fall / FALL_TIME) : 0;
      // Ease-out: bodies drop fast and settle slowly.
      const f = fall * (2 - fall);
      const lean = a.state === STATE.WINDING
        ? Math.sin((1 - a.timer / Math.max(0.01, a.K.wind)) * Math.PI) * 0.34
        : a.flinch * -0.22;

      Mat4.translation(this._a, a.pos[0], a.pos[1], a.pos[2]);
      Mat4.rotationY(this._b, a.yaw);
      Mat4.multiply(this._m, this._a, this._b);
      if (dead || lean !== 0) {
        Mat4.rotationX(this._c, f * 1.48 + lean);
        Mat4.multiply(this._m, this._m, this._c);
      }

      for (const p of parts) {
        // Joint at the mesh origin: translate to the pivot, then swing about it.
        Mat4.translation(this._a, p.pivot[0], p.pivot[1], p.pivot[2]);
        Mat4.multiply(this._b, this._m, this._a);
        if (p.swing && !dead) {
          const amt = a.state === STATE.HUNTING ? 1 : a.state === STATE.WINDING ? 0.3 : 0.12;
          Mat4.rotationX(this._c, Math.sin(a.phase) * p.swing * amt * p.side * p.anti);
          Mat4.multiply(this._b, this._b, this._c);
        }
        drawZoneLit(zid, nbs, p.mesh, this._b);
      }
    }
  }

  /**
   * ENEMY FIRE, ON THE GLASS. Projected through the camera onto the 480×270 UI
   * grid — the same trick `PersonalCombat._drawImpacts` uses for its sparks, and
   * for the same reason: a third render pass to draw six line segments would
   * cost a program switch and a draw call to do what a handful of rects does.
   *
   * Drawn as a dashed run rather than a solid line. A solid one at this
   * resolution is a hard diagonal that reads as UI; a dashed one reads as
   * something moving fast enough that you only caught part of it.
   *
   * @param {object} pix     the 2D layer
   * @param {object} camera  player camera, for its viewProjection
   * @param {number} W       UI grid width
   * @param {number} H       UI grid height
   */
  drawFx(pix, camera, W, H) {
    if (!this.tracers.length || !camera?.viewProjection) return;
    const m = camera.viewProjection;
    /** World point → clip space (x, y, w). */
    const clip = (p, out) => {
      out[0] = m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12];
      out[1] = m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13];
      out[2] = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15];
      return out;
    };
    const WMIN = 0.05;
    const ca = [0, 0, 0], cb = [0, 0, 0];
    const A = [0, 0], B = [0, 0];
    for (const tr of this.tracers) {
      clip(tr.a, ca);
      clip(tr.b, cb);
      /**
       * CLIP, DO NOT DISCARD — and this was the whole reason the first cut of
       * this effect drew nothing at all.
       *
       * A bolt that misses carries on PAST you, so its far endpoint is behind
       * the camera; rejecting any segment with an end behind the eye therefore
       * threw away every near miss, which is precisely the shot most worth
       * seeing. Interpolating to the near plane instead gives the thing that
       * reads correctly: a round that comes in from the shooter and leaves the
       * bottom of the frame beside your head.
       *
       * Only the case where BOTH ends are behind is skipped, and that one
       * genuinely has nothing on screen to draw.
       */
      if (ca[2] <= WMIN && cb[2] <= WMIN) continue;
      if (ca[2] <= WMIN || cb[2] <= WMIN) {
        // w is linear along the segment, so the crossing parameter is exact.
        const t = (WMIN - ca[2]) / (cb[2] - ca[2]);
        const near = ca[2] <= WMIN ? ca : cb;
        near[0] = ca[0] + (cb[0] - ca[0]) * t;
        near[1] = ca[1] + (cb[1] - ca[1]) * t;
        near[2] = WMIN;
      }
      A[0] = (ca[0] / ca[2] * 0.5 + 0.5) * W;
      A[1] = (1 - (ca[1] / ca[2] * 0.5 + 0.5)) * H;
      B[0] = (cb[0] / cb[2] * 0.5 + 0.5) * W;
      B[1] = (1 - (cb[1] / cb[2] * 0.5 + 0.5)) * H;
      const dx = B[0] - A[0], dy = B[1] - A[1];
      const len = Math.hypot(dx, dy);
      if (len < 1) continue;
      // After a near-plane clip the segment can be several screens long; the
      // cap keeps the dash loop bounded regardless.
      const steps = Math.min(96, Math.max(2, Math.round(len / 2)));
      const t = tr.t;
      for (let i = 0; i <= steps; i++) {
        if ((i & 3) === 3) continue; // the dashes
        const f = i / steps;
        const x = Math.round(A[0] + dx * f);
        const y = Math.round(A[1] + dy * f);
        if (x < 0 || y < 0 || x >= W || y >= H) continue;
        // Warm at the muzzle, cooling along the track. AMBER_MACHINE family,
        // not the HUD amber — this is a thing in the world, not an instrument.
        const warm = 1 - f * 0.5;
        pix.rect(x, y, 1, 1, [0.82 * warm, 0.45 * warm, 0.12 * warm, Math.min(1, t * 1.2)]);
      }
      // Muzzle bloom: three frames of a bright block where it came from.
      if (t > 0.55) {
        const s = Math.round(1 + (t - 0.55) * 6);
        pix.rect(Math.round(A[0] - s / 2), Math.round(A[1] - s / 2), s, s,
          [0.95, 0.68, 0.3, (t - 0.55) * 2]);
      }
    }
  }

  /** What the HUD needs: how many are up, and whether any of them know. */
  status() {
    if (!this.actors.length) return null;
    return {
      alive: this.alive,
      total: this.actors.length,
      hunting: this.hunting,
      hullId: this._hullId,
    };
  }

  toJSON() { return { cleared: [...this.cleared] }; }
  fromJSON(d) {
    this.cleared = new Set(d?.cleared ?? []);
  }
}
