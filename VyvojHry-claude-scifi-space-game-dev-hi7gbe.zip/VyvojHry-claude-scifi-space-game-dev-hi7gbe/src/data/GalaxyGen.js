/**
 * GALAXY GENERATION — a different chart every commission.
 *
 * `CelestialGen.generateSystem` has always been rule-driven: give it a seed, a
 * star type and a planet count and it derives real-km radii, AU-spaced orbits,
 * moons, belts and comets from astronomy rather than from a table. What did not
 * exist was anything ABOVE it — the ten systems were a hand-written list, so
 * every save visited the same ten places in the same order.
 *
 * This is that layer. From one save seed it lays out a whole chart: where the
 * systems are in light-years, what they are called, what burns at the centre of
 * each, and which of them you can reach from where you are standing.
 *
 * THE TEN AUTHORED SYSTEMS SURVIVE. Sol Prime, the four route systems and the
 * five spurs carry the lore — the Hollow's haunts, the named colony, the
 * derelicts that quests point at, the stations trading depends on. Procedural
 * generation that threw those away would be trading a written world for a
 * random one, which is a bad trade. So they are ANCHORS: fixed ids, fixed
 * content, placed first, and the generated systems fill in around them. Every
 * game gets the same story and a different galaxy to find it in.
 *
 * NAVIGATION IS LOCAL. `neighbours()` returns only what is within jump range of
 * a given system, which is what turns the warp panel from a menu of ten
 * destinations into a chart you have to cross. The route to a distant system is
 * a sequence of hops through the ones between, and fuel is spent on each.
 */
import { RNG } from '../utils/RNG.js';
import { generateSystem } from './CelestialGen.js';

/**
 * Jump range in light-years. The chart is laid out in a ~46 ly disc, so this
 * reaches roughly three to six neighbours from a typical position — enough that
 * there is always a choice, few enough that the choice means something.
 */
export const JUMP_RANGE = 13.5;

/** Star types by rough frequency. M dwarfs dominate reality and should here. */
const STAR_WEIGHTS = [
  ['M', 40], ['K', 20], ['G', 14], ['F', 9], ['A', 6], ['B', 4], ['O', 2],
  ['WD', 3], ['RG', 2],
];

/**
 * Name parts. The register is worn, industrial and faintly nautical — the names
 * a survey office gives places it does not expect anyone to love. No invented
 * apostrophe-heavy fantasy, and nothing that reads as a brand.
 */
const HEAD = ['BAR', 'COLD', 'DEEP', 'DRY', 'FAR', 'GREY', 'HOLL', 'IRON', 'LOW',
  'MARR', 'NINE', 'PALE', 'RED', 'SALT', 'SHEAR', 'SLOW', 'STONE', 'TALL',
  'THIN', 'VAST', 'WAN', 'WEST', 'BLACK', 'BRINE', 'CIND', 'DUSK'];
const TAIL = ['ROW', 'FALL', 'GATE', 'HOLM', 'MERE', 'REACH', 'SPIT', 'STRAND',
  'WELL', 'WICK', 'MARCH', 'CROSS', 'HAVEN', 'DRIFT', 'SHOAL', 'BANK', 'LEDGE',
  'HOOK', 'BEND', 'MOOR'];
const BARE = ['ODEN', 'TASSEL', 'VARR', 'KELP', 'MIRE', 'OSSUARY', 'PENNANT',
  'QUILL', 'RIME', 'SABLE', 'TALLOW', 'UMBER', 'VESSEL', 'WICKER', 'YARROW'];
const SUFFIX = ['', '', '', '', ' II', ' IV', ' MINOR', ' DEPOT', ' JUNCTION',
  ' ANCHORAGE', ' TRANSIT'];

/** Traits that seed a blurb and shift the danger rating. */
const TRAITS = [
  { t: 'a dead relay station nobody has answered from in nine years', d: 1 },
  { t: 'three competing salvage claims and no authority to settle them', d: 2 },
  { t: 'a company ore contract that has been running since before you were born', d: -1 },
  { t: 'ice haulers working the outer belt on thin margins', d: 0 },
  { t: 'a quarantine buoy still broadcasting, cause unstated', d: 2 },
  { t: 'a Vrenn trade post that will deal with anyone who arrives quietly', d: -1 },
  { t: 'Keth transponders on the edge of the lane, holding position', d: 3 },
  { t: 'Drift wreckage in a slow orbit, picked over twice already', d: 2 },
  { t: 'nothing at all, which the last survey also reported', d: 0 },
  { t: 'a gas extraction platform running on automation and hope', d: 1 },
  { t: 'a beacon with the wrong registry burned into its casing', d: 2 },
  { t: 'good ore, clean lanes and a docking fee that explains why', d: -2 },
];

function weighted(rng, table) {
  let total = 0;
  for (const [, w] of table) total += w;
  let r = rng.next() * total;
  for (const [v, w] of table) { r -= w; if (r <= 0) return v; }
  return table[0][0];
}

/** A name, guaranteed unique against `used`. */
function starName(rng, used) {
  for (let attempt = 0; attempt < 64; attempt++) {
    const n = rng.next() < 0.62
      ? HEAD[rng.int(0, HEAD.length - 1)] + TAIL[rng.int(0, TAIL.length - 1)]
      : BARE[rng.int(0, BARE.length - 1)] + SUFFIX[rng.int(0, SUFFIX.length - 1)];
    if (!used.has(n)) { used.add(n); return n; }
  }
  // Exhausting 64 attempts means the tables are too small for the chart size;
  // fall back to a catalogue number rather than looping or returning a dupe.
  let i = 2;
  while (used.has(`SURVEY ${i}`)) i++;
  used.add(`SURVEY ${i}`);
  return `SURVEY ${i}`;
}

const DANGER = ['LOW', 'LOW', 'MODERATE', 'HIGH', 'EXTREME'];

/**
 * Build the whole chart.
 *
 * @param {number} seed        one number per save; the same seed always
 *                             reproduces the same galaxy, so a chart survives a
 *                             reload and a new commission gets a new one.
 * @param {object[]} anchors   the authored systems, already generated
 * @param {number} extra       how many procedural systems to add
 */
export function generateGalaxy(seed, anchors, extra = 18) {
  const rng = new RNG(seed >>> 0 || 0x51a2c3);
  const systems = [];
  const used = new Set();
  /** Positions in light-years, on a disc. y is thin: a galactic plane, not a ball. */
  const placed = [];

  /**
   * Reject-sample a position at least `MIN_SEP` from everything already placed,
   * so the chart has no unreachable clusters and no two systems that overlap on
   * the map. Falls through after 200 tries rather than looping forever — a
   * slightly tight pair is better than a hang.
   */
  const MIN_SEP = 6.0, R = 46;
  const site = () => {
    for (let i = 0; i < 200; i++) {
      // sqrt for uniform area rather than a centre-heavy blob
      const r = Math.sqrt(rng.next()) * R;
      const a = rng.next() * Math.PI * 2;
      const p = [Math.cos(a) * r, (rng.next() - 0.5) * 7, Math.sin(a) * r];
      let ok = true;
      for (const q of placed) {
        if (Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]) < MIN_SEP) { ok = false; break; }
      }
      if (ok) { placed.push(p); return p; }
    }
    const r = Math.sqrt(rng.next()) * R, a = rng.next() * Math.PI * 2;
    const p = [Math.cos(a) * r, (rng.next() - 0.5) * 7, Math.sin(a) * r];
    placed.push(p);
    return p;
  };

  // 1. the authored systems, placed first so they get the roomiest sites.
  //    Sol Prime is pinned near the centre because it is where you start and a
  //    start on the rim would make half the chart a one-way trip.
  for (const [i, a] of anchors.entries()) {
    a.pos = i === 0 ? (placed.push([0, 0, 0]), [0, 0, 0]) : site();
    a.authored = true;
    used.add(a.name);
    systems.push(a);
  }

  // 2. procedural fill
  for (let i = 0; i < extra; i++) {
    const sSeed = (seed ^ (0x9e3779b9 * (i + 1))) >>> 0;
    const r2 = new RNG(sSeed);
    const name = starName(r2, used);
    const type = weighted(r2, STAR_WEIGHTS);
    const trait = TRAITS[r2.int(0, TRAITS.length - 1)];
    // Danger rises with distance from the centre and with the trait, which
    // gives the chart a readable gradient: the deep lanes are worse, and you
    // can see that on the map before you commit fuel to a jump.
    const p = site();
    const rim = Math.hypot(p[0], p[2]) / R;
    const d = Math.max(0, Math.min(4, Math.round(rim * 2.2 + trait.d * 0.7 + r2.range(-0.4, 0.6))));
    const sys = generateSystem({
      id: `gen_${i}_${(sSeed % 9973).toString(36)}`,
      name,
      starName: name,
      starType: type,
      seed: sSeed,
      // A white dwarf or a red giant has had a violent history and keeps fewer
      // planets; a main-sequence star keeps more.
      planetCount: type === 'WD' ? r2.int(2, 4) : type === 'RG' ? r2.int(3, 5) : r2.int(4, 9),
      danger: DANGER[d],
      blurb: `Surveyed once, briefly. The report mentions ${trait.t}.`,
      group: 'DEEP LANES',
    });
    sys.pos = p;
    sys.authored = false;
    systems.push(sys);
  }

  const byId = new Map(systems.map((s) => [s.id, s]));

  /** Straight-line distance between two systems, light-years. */
  const distance = (a, b) => {
    const A = typeof a === 'string' ? byId.get(a) : a;
    const B = typeof b === 'string' ? byId.get(b) : b;
    if (!A?.pos || !B?.pos) return Infinity;
    return Math.hypot(A.pos[0] - B.pos[0], A.pos[1] - B.pos[1], A.pos[2] - B.pos[2]);
  };

  /**
   * Everything reachable in one jump from `id`, nearest first.
   *
   * A system with NO neighbours would be a dead end you could arrive at and
   * never leave, which a reject-sampled layout can produce at the rim. So the
   * nearest system is always included regardless of range — the drive can
   * always get you back out of wherever it got you into, even if it has to
   * strain to do it.
   */
  const neighbours = (id, range = JUMP_RANGE) => {
    const from = byId.get(id);
    if (!from) return [];
    const ranked = systems
      .filter((s) => s.id !== id)
      .map((s) => ({ sys: s, ly: distance(from, s) }))
      .sort((a, b) => a.ly - b.ly);
    const near = ranked.filter((r) => r.ly <= range);
    return (near.length ? near : ranked.slice(0, 1));
  };

  return { seed, systems, byId, distance, neighbours, radius: R };
}
