/**
 * CelestialGen — rule-based star-system generation grounded in real astronomy.
 *
 * Scale (compressed but proportional — full AU would make every body an
 * invisible speck light-seconds apart, so we keep the *ratios* real, not the
 * absolute clock):
 *   1 game unit = KM_PER_UNIT km        (body radii from real km)
 *   1 AU        = UNITS_PER_AU units     (orbits at real AU, spread wide)
 *
 * Real reference data (radii in km, distances in AU) is kept on every body so
 * the NAV panel can show true units even though the render scale is compressed.
 */
import { RNG } from '../utils/RNG.js';
import { makeOrbit, orbitPosition, apsides, rocheLimit, resonances, GRAV_MU, MOON_MU, SPACE_SCALE } from './Orbits.js';

/**
 * Orbital element distributions per body class, from the Solar System.
 *
 * These ranges are the reason a system now reads as a real one rather than a set
 * of concentric rings. Planets are nearly circular and nearly coplanar (the
 * Solar System's eight run e = 0.007–0.21 and i = 0–3.4° off the ecliptic);
 * dwarf planets are conspicuously not (Pluto is 0.25 and 17°, Eris 0.44 and
 * 44°); and comets are wild on both axes, which is exactly what makes them read
 * as visitors rather than residents.
 *
 * `e` eccentricity range, `iDeg` inclination range in degrees.
 */
const ORBIT_CLASS = {
  planet: { e: [0.005, 0.09], iDeg: [0, 3.4] },
  dwarf: { e: [0.06, 0.34], iDeg: [4, 28] },
  asteroid: { e: [0.04, 0.28], iDeg: [0, 18] },
  comet: { e: [0.45, 0.88], iDeg: [5, 42] },
  rogue: { e: [0.20, 0.60], iDeg: [10, 60] },
  moon: { e: [0.001, 0.05], iDeg: [0, 6] },
};

/**
 * Give a body a full Keplerian element set and place it at epoch.
 *
 * `aUnits` is the semi-major axis in game units — note that with a non-zero
 * eccentricity the body is NOT at that distance at t = 0; it is somewhere
 * between periapsis and apoapsis, which is the point. Everything downstream
 * (station placement, the ship spawn) reads `body.pos`, so this must run before
 * any of that.
 */
/**
 * Solve a ring system from the host's own moons.
 *
 * The previous version was a single number — `rings: { outer: 2.2 }` — and the
 * texture drew one hardcoded division two thirds of the way out. That reads fine
 * once and is the same ring on every giant in the game.
 *
 * A real ring system's structure is dictated by the moons around it:
 *
 * - The INNER edge is the Roche limit. Inside it tidal shear beats a moonlet's
 *   self-gravity, so material there can never accrete into a moon — which is
 *   why rings exist there and moons do not.
 * - The OUTER edge is set by the innermost shepherd. Saturn's rings stop around
 *   2.3 R with Mimas just beyond at 3.1 R; the moon's gravity confines the disc.
 * - The GAPS are mean-motion resonances with those moons. A particle whose
 *   period is a simple ratio of a moon's gets the same kick every orbit, the
 *   kicks accumulate, and it is swept out. The Cassini Division is the 2:1 with
 *   Mimas — not a decorative stripe.
 *
 * So a giant with three close moons gets a busy, heavily divided disc, and one
 * with a single distant moon gets a broad clean one, out of the same code.
 *
 * Radii here are in units of the host's radius; the texture maps them.
 */
function buildRings(rng, body) {
  if (!body.ringed) return;
  const R = body.radius;
  // icy debris around a hydrogen giant: density ratio ~2.0-2.5
  const inner = rocheLimit(rng.range(2.0, 2.5));
  const moonsA = (body.moons ?? []).map((m) => m.dist / R).filter((a) => a > inner).sort((a, b) => a - b);
  // confined just inside the innermost shepherd; with no moons at all the disc
  // spreads until collisions damp it, which lands near 2.3 R
  const outer = moonsA.length ? Math.min(2.6, Math.max(inner + 0.35, moonsA[0] * 0.78)) : 2.3;

  const gaps = [];
  for (const ma of moonsA.slice(0, 3)) {
    for (const res of resonances(ma)) {
      if (res.a <= inner + 0.04 || res.a >= outer - 0.04) continue;
      // a stronger resonance clears a wider, emptier gap
      gaps.push({
        r: res.a,
        width: (0.020 + res.strength * 0.055) * (outer - inner),
        depth: 0.15 + (1 - res.strength) * 0.55, // 0 = swept clean, 1 = untouched
        ratio: res.ratio,
      });
    }
  }
  // merge gaps that overlap, keeping the deeper clearing
  gaps.sort((a, b) => a.r - b.r);
  const merged = [];
  for (const g of gaps) {
    const prev = merged[merged.length - 1];
    if (prev && g.r - prev.r < (prev.width + g.width) * 0.5) {
      prev.width = Math.max(prev.width, (g.r + g.width * 0.5) - (prev.r - prev.width * 0.5));
      prev.depth = Math.min(prev.depth, g.depth);
    } else merged.push({ ...g });
  }

  body.rings = {
    inner, outer, gaps: merged,
    // the disc lies in the host's equatorial plane, which is tilted off its
    // orbit — Saturn's 26.7 degrees is why its rings open and close from Earth
    tiltDeg: rng.range(8, 34),
    shepherds: moonsA.slice(0, 3).map((a) => +a.toFixed(2)),
    // kept for the renderer, which scales the billboard by this
    outerMul: outer,
  };
}

function placeOrbit(rng, body, aUnits, klass, mu = GRAV_MU) {
  const c = ORBIT_CLASS[klass] ?? ORBIT_CLASS.planet;
  body.orbit = makeOrbit({
    a: aUnits,
    e: pick(rng, c.e),
    i: (pick(rng, c.iDeg) * Math.PI) / 180,
    node: rng.range(0, Math.PI * 2), // longitude of the ascending node
    peri: rng.range(0, Math.PI * 2), // argument of periapsis
    M0: rng.range(0, Math.PI * 2), // where it starts along the orbit
    // Retrograde motion is rare and worth keeping rare: one captured moon or
    // stray asteroid going the wrong way is a detail, a system full of them is
    // noise.
    dir: rng.chance(klass === 'moon' ? 0.08 : 0.03) ? -1 : 1,
    mu,
  });
  const ap = apsides(body.orbit);
  body.periapsis = Math.round(ap.peri);
  body.apoapsis = Math.round(ap.apo);
  body.periodS = Math.round(body.orbit.period);
  orbitPosition(body.pos, body.orbit, 0);
  return body;
}

/**
 * SCALE (0.37.0, owner: "upscale all celestial bodies, stations and ships — now
 * it's tiny").
 *
 * The complaint was right and the arithmetic says why. A world was 455 units in
 * radius and the ship is 62 units long, so a planet was fifteen ship-lengths
 * across; at a cruise of 1400 u/s you crossed one in under a second. Nothing
 * about that reads as a planet, however good the texture on it is.
 *
 * TWO SEPARATE FACTORS, because they do different jobs:
 *
 *   BODY_SCALE (6.4×) is what makes worlds big. It comes out of KM_PER_UNIT —
 *   Earth is now 2900 units in radius, a hundred ship-lengths across, and takes
 *   four seconds to cross at cruise instead of a third of one.
 *
 *   SPACE_SCALE (3.33×, shared with Orbits.js) is what keeps them apart. Radii
 *   alone would have put a 2900-unit world in a 4800-unit orbit, i.e. inside its
 *   own star. Distances grow too, but deliberately LESS than radii — that is the
 *   whole trick: the ratio of orbit to body is what decides how big a world
 *   looks when you are near it, and halving it is what makes the system read as
 *   inhabited instead of as a diagram.
 *
 * Everything downstream is expressed in MULTIPLES of `body.radius` — approach
 * spheres, collision margins, station stand-off, lift-off parking, moon orbits —
 * so it all follows from these two numbers without a single call-site change.
 * Orbital PERIODS are held constant by compensating μ; see Orbits.js.
 */
export const BODY_SCALE = 11.0;
/**
 * Stations, shipyards, refineries, wrecks, mines and traffic. Less than
 * BODY_SCALE on purpose: these are BUILT things and a station the size of a
 * continent stops reading as something people made. Four times is roughly a
 * kilometre-long trade post against a 60-metre hull, which is the Sevastopol
 * proportion the whole project is aiming at.
 */
export const STRUCTURE_SCALE = 7.0;
export const KM_PER_UNIT = 14 / BODY_SCALE; // Earth≈5000u, Jupiter≈54930u, Moon≈1365u
export const UNITS_PER_AU = 12000 * SPACE_SCALE; // 0.4AU≈16000u … 30AU≈1.2Mu
const R_SUN_KM = 696000;
const R = (km) => km / KM_PER_UNIT;
const AU = (au) => au * UNITS_PER_AU;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/**
 * Stars are compressed harder than planets (cube-root of solar radii): a truly
 * proportional Sun would be ~50 000 u across and swallow the inner orbits, so we
 * keep the *ordering* of star sizes real while scaling them to a big, readable
 * disc that dwarfs the ship. The true radius still rides along for the NAV panel.
 */
function starGameRadius(rSun) {
  // Scaled with the worlds, but by less than BODY_SCALE: a star already gets a
  // deliberately compressed radius (see above), and multiplying THAT by 6.4
  // would have put a G-type photosphere most of the way to the innermost orbit.
  return clamp(8200 * Math.cbrt(rSun), 2300, 34000);
}

/** Main-sequence + notable star classes (real approx radius in R_sun, temp K). */
export const STAR_TYPES = {
  O: { name: 'O-type', rSun: 7.4, temp: 40000, color: '#9bb0ff', lum: 90 },
  B: { name: 'B-type', rSun: 4.0, temp: 20000, color: '#aabfff', lum: 25 },
  A: { name: 'A-type', rSun: 1.8, temp: 8600, color: '#dbe4ff', lum: 5 },
  F: { name: 'F-type', rSun: 1.3, temp: 6600, color: '#f8f7ff', lum: 1.7 },
  G: { name: 'G-type', rSun: 1.0, temp: 5800, color: '#fff4e8', lum: 1.0 }, // the Sun
  K: { name: 'K-type', rSun: 0.8, temp: 4600, color: '#ffd2a1', lum: 0.45 },
  M: { name: 'M-type', rSun: 0.4, temp: 3300, color: '#ffb56b', lum: 0.08 },
  RG: { name: 'Red giant', rSun: 30, temp: 3500, color: '#ff9955', lum: 60 },
  WD: { name: 'White dwarf', rSun: 0.012, temp: 15000, color: '#dfe8ff', lum: 0.02 },
  KD: { name: 'K-subdwarf', rSun: 0.55, temp: 3900, color: '#e8b88a', lum: 0.035 }, // The Pale — dim, barely visible
  KM: { name: 'K+M binary', rSun: 0.85, temp: 4400, color: '#ffc890', lum: 0.5 }, // Twin Suns close pair (rendered as one disc)
  // A failed star: below the hydrogen-fusion limit, so it only glows from the
  // heat of its own collapse. Physically ~1 Jupiter radius, but a Jupiter-sized
  // primary would render smaller than the worlds orbiting it, so it takes a
  // deliberately inflated rSun — same compression licence as the rest of the table.
  BD: { name: 'Brown dwarf', rSun: 0.16, temp: 1100, color: '#a04a28', lum: 0.0006 },
  // Neutron star: 10 km across in reality. `starGameRadius` clamps at 700 u, so
  // it draws as the smallest primary in the game — which is the correct *relative*
  // read even though the absolute number is fiction.
  NS: { name: 'Neutron star', rSun: 0.000014, temp: 600000, color: '#c8d6ff', lum: 0.4 },
};

/**
 * Body archetypes. `rKm` is the real radius range; `kind` maps to an existing
 * planet texture; `zone` is where in the orbital sequence it may appear.
 * g = surface gravity (g), used for the info panel.
 */
const BODY_TYPES = {
  lava: { klass: 'Lava world', kind: 'lava', rKm: [2000, 4000], g: [0.4, 0.9], tempC: [+320, +480], atmo: 'None (vapourised rock)' },
  desert: { klass: 'Desert world', kind: 'rocky', rKm: [3000, 6500], g: [0.4, 1.1], tempC: [-30, +90], atmo: 'Thin CO₂' },
  rocky: { klass: 'Rocky world', kind: 'rocky', rKm: [2400, 6000], g: [0.4, 1.0], tempC: [-80, +20], atmo: 'Trace' },
  ocean: { klass: 'Oceanic world', kind: 'oceanic', rKm: [5500, 8500], g: [0.8, 1.4], tempC: [-5, +28], atmo: 'Breathable (N₂/O₂)' },
  jungle: { klass: 'Verdant world', kind: 'jungle', rKm: [5500, 9000], g: [0.8, 1.5], tempC: [+12, +40], atmo: 'Dense O₂/N₂' },
  superearth: { klass: 'Super-Earth', kind: 'rocky', rKm: [8000, 13000], g: [1.3, 2.6], tempC: [-40, +60], atmo: 'Thick' },
  ice: { klass: 'Ice world', kind: 'ice', rKm: [2000, 5500], g: [0.3, 0.9], tempC: [-220, -120], atmo: 'Thin nitrogen' },
  iceGiant: { klass: 'Ice giant', kind: 'ice', rKm: [20000, 28000], g: [0.9, 1.4], tempC: [-210, -180], atmo: 'H₂/He/CH₄' },
  gasGiant: { klass: 'Gas giant', kind: 'gas', rKm: [50000, 75000], g: [2.0, 2.6], tempC: [-160, -100], atmo: 'Hydrogen/helium' },
  dwarf: { klass: 'Dwarf planet', kind: 'comet', rKm: [500, 1300], g: [0.05, 0.3], tempC: [-240, -210], atmo: 'None' },
  moon: { klass: 'Moon', kind: 'moon', rKm: [800, 2600], g: [0.1, 0.4], tempC: [-180, -60], atmo: 'None' },
  iceMoon: { klass: 'Ice moon', kind: 'ice', rKm: [900, 2500], g: [0.1, 0.4], tempC: [-200, -130], atmo: 'None' },
  planetoid: { klass: 'Planetoid', kind: 'moon', rKm: [200, 600], g: [0.02, 0.1], tempC: [-230, -150], atmo: 'None' },
  // -- added with the second half of the chart (session 16n) --------------------
  toxic: { klass: 'Toxic greenhouse', kind: 'toxic', rKm: [5000, 7000], g: [0.7, 1.1], tempC: [+380, +470], atmo: 'CO₂ / sulphuric (crushing)' },
  carbon: { klass: 'Carbon world', kind: 'carbon', rKm: [3000, 7000], g: [0.5, 1.3], tempC: [-60, +240], atmo: 'Carbon monoxide, trace' },
  metal: { klass: 'Stripped core', kind: 'metal', rKm: [2200, 4200], g: [0.6, 1.6], tempC: [-120, +180], atmo: 'None' },
  tundra: { klass: 'Tundra world', kind: 'tundra', rKm: [4800, 7500], g: [0.7, 1.2], tempC: [-55, +6], atmo: 'Thin, breathable with a mask' },
  sulfurMoon: { klass: 'Volcanic moon', kind: 'sulfur', rKm: [1500, 2400], g: [0.1, 0.3], tempC: [-140, +120], atmo: 'Sulphur dioxide, trace' },
  // Ringed variants: identical bodies that carry a `rings` block (see makeBody).
  // Kept as separate archetypes rather than a flag on gasGiant so a planetSpec
  // reads as a picture of the system — 'ringedGiant' says what you'll see.
  ringedGiant: { klass: 'Ringed gas giant', kind: 'gas', rKm: [48000, 70000], g: [1.9, 2.6], tempC: [-165, -105], atmo: 'Hydrogen/helium', rings: [2.05, 2.55] },
  ringedIceGiant: { klass: 'Ringed ice giant', kind: 'ice', rKm: [19000, 27000], g: [0.9, 1.4], tempC: [-215, -185], atmo: 'H₂/He/CH₄', rings: [1.9, 2.3] },

  // -- 0.48.0: six more silhouettes on the chart -----------------------------
  // Each of these is a world the type table could not previously describe, and
  // four of them carry brand-new surface archetypes (data/SurfaceGen.js).
  ashWorld: { klass: 'Ash world', kind: 'ashen', rKm: [3200, 6200], g: [0.5, 1.1], tempC: [+30, +140], atmo: 'Ash and sulphur dioxide' },
  saltWorld: { klass: 'Desiccated world', kind: 'saltflat', rKm: [4200, 7200], g: [0.6, 1.1], tempC: [+18, +90], atmo: 'Thin, dust-laden' },
  ironWorld: { klass: 'Banded iron world', kind: 'ferrous', rKm: [2800, 5600], g: [0.7, 1.5], tempC: [-70, +40], atmo: 'Trace oxygen' },
  crystalWorld: { klass: 'Crystalline world', kind: 'crystal', rKm: [2200, 4800], g: [0.4, 0.9], tempC: [-140, -50], atmo: 'None' },
  // TIDALLY LOCKED. One face at the substellar point, one facing out forever.
  // Rendered as a lava world because the face you approach is the hot one; the
  // atmosphere string is what tells you the rest.
  tidalLocked: { klass: 'Tide-locked world', kind: 'lava', rKm: [3000, 5800], g: [0.5, 1.2], tempC: [+260, +410], atmo: 'Day-side vapour, night-side frost' },
  // Ocean under ice — the one place in a cold system worth a surface team.
  oceanIce: { klass: 'Subsurface-ocean moon', kind: 'ice', rKm: [1200, 2800], g: [0.1, 0.4], tempC: [-190, -140], atmo: 'Trace water vapour (venting)' },
};

const pick = (rng, [a, b]) => a + (b - a) * rng.next();
const roundish = (rng, v, j = 0.1) => v * (1 + rng.range(-j, j));

/** Compose a body record (game + real fields) from an archetype. */
function makeBody(rng, id, name, typeKey, orbitAU, extra = {}) {
  const t = BODY_TYPES[typeKey];
  const rKm = pick(rng, t.rKm);
  const body = {
    id, name, kind: t.kind, class: t.klass,
    radius: Math.max(1.2, R(rKm)), // game units
    realRadiusKm: Math.round(rKm),
    orbitAU: +orbitAU.toFixed(3),
    gravity: `${pick(rng, t.g).toFixed(2)} g`,
    temp: `${Math.round(pick(rng, t.tempC))} °C`,
    atmosphere: t.atmo,
    spin: rng.range(0.004, 0.02),
    pos: [0, 0, 0],
    ...extra,
  };
  // `rings.outer` is a multiple of the body radius; the renderer bakes the inner
  // edge and the viewing tilt into the ring sheet (TextureFactory.planetRingTexture).
  if (t.rings) body.ringed = true; // real structure is solved once the moons exist
  return body;
}

/** Choose a planet archetype for an orbit at `au`, given the habitable zone. */
function planetTypeFor(rng, au, hzInner, hzOuter) {
  // The inner edge is where a world either boils, keeps a runaway greenhouse, or
  // has had its mantle blown off — three very different silhouettes for the same
  // orbit, which is what stops procedural systems reading as one lava ball each.
  // Right up against the star, tidal locking is the rule rather than the
  // exception, and an ash world is what is left when the volcanism stops.
  if (au < hzInner * 0.4) {
    return rng.chance(0.4) ? 'tidalLocked' : rng.chance(0.5) ? 'lava' : 'ashWorld';
  }
  if (au < hzInner * 0.6) return rng.chance(0.45) ? 'lava' : rng.chance(0.5) ? 'toxic' : 'metal';
  // The hot edge of the zone: worlds that had water and do not any more.
  if (au < hzInner) {
    return rng.chance(0.3) ? 'desert' : rng.chance(0.35) ? 'saltWorld'
      : rng.chance(0.5) ? 'rocky' : 'toxic';
  }
  if (au <= hzOuter) return rng.chance(0.4) ? 'ocean' : rng.chance(0.5) ? 'jungle' : 'desert';
  // just past the habitable zone: cold enough to freeze over but not to freeze out
  if (au < hzOuter * 1.5) {
    return rng.chance(0.4) ? 'tundra' : rng.chance(0.35) ? 'ironWorld'
      : rng.chance(0.5) ? 'rocky' : 'superearth';
  }
  if (au < hzOuter * 2.2) {
    return rng.chance(0.35) ? 'ironWorld' : rng.chance(0.3) ? 'crystalWorld'
      : rng.chance(0.5) ? 'rocky' : 'superearth';
  }
  if (au < hzOuter * 6) return rng.chance(0.35) ? 'ringedGiant' : rng.chance(0.5) ? 'gasGiant' : 'iceGiant';
  return rng.chance(0.4) ? 'ringedIceGiant' : rng.chance(0.5) ? 'iceGiant' : 'ice';
}

/**
 * Generate a full system.
 * @param {object} def { id, name, starType, starName, seed, planetCount?,
 *   habitableName?, colony?, planetSpec?, belt?, comets?, rogue?, stations?,
 *   derelicts?, blurb?, danger? }
 *   planetSpec: ordered inner→outer [{type, name?, info?, colony?}] — forces the
 *   composition (lore systems); otherwise types follow the habitable zone.
 * @returns {object} StarSystemsData-shaped def (star + bodies + ships + shipStart)
 */
export function generateSystem(def) {
  const rng = new RNG(def.seed ?? 0x51a2);
  const star = STAR_TYPES[def.starType] ?? STAR_TYPES.G;
  const starRadius = starGameRadius(star.rSun);
  // habitable zone (AU) ~ sqrt(luminosity), Sun ≈ 0.95–1.4 AU
  const hzMid = Math.sqrt(star.lum) * 1.1;
  const hzInner = hzMid * 0.82, hzOuter = hzMid * 1.5;

  const spec = def.planetSpec ?? null;
  const n = spec ? spec.length : (def.planetCount ?? rng.int(6, 9));
  const bodies = [];
  // orbital spacing: a geometric progression (Titius–Bode-like), jittered
  let au = pick(rng, [0.3, 0.5]) * Math.max(0.4, Math.sqrt(star.lum));
  const ratio = () => pick(rng, [1.45, 1.9]);
  let colonyPlaced = false;
  for (let i = 0; i < n; i++) {
    let typeKey = spec ? spec[i].type : planetTypeFor(rng, au, hzInner, hzOuter);
    let name = spec?.[i]?.name ?? `${def.name} ${roman(i + 1)}`;
    // put the named colony world on the first habitable-zone planet
    if (!spec && !colonyPlaced && def.habitableName && au >= hzInner && au <= hzOuter) {
      typeKey = def.colony ? 'ocean' : typeKey;
      name = def.habitableName;
      colonyPlaced = true;
    }
    const body = makeBody(rng, `${def.id}_p${i}`, name, typeKey, au);
    if (name === def.habitableName && def.colony) {
      body.info = `Human colony. The ship shares its name. Green coasts under a blue sky.`;
      body.atmosphere = 'Breathable (N₂/O₂)';
      body.temp = '+16 °C';
      body.colony = true;
    } else {
      body.info = spec?.[i]?.info ?? flavour(typeKey, rng);
      if (spec?.[i]?.colony) body.colony = true;
    }
    // Full Keplerian elements. `au` is now the SEMI-MAJOR AXIS, not the current
    // distance — an eccentric world is nearer or further than its own orbit
    // number depending on where in its year you catch it.
    placeOrbit(rng, body, AU(au), 'planet');
    // moons for giants / large worlds. A planetSpec entry may name them outright
    // (`moons: ['sulfurMoon', {type:'iceMoon', name:'…', info:'…'}]`) — that's how
    // a lore system pins a specific moon, e.g. a volcanic one inside a giant's
    // tidal grip, without giving up procedural placement.
    const isGiant = /Giant$/.test(typeKey); // gasGiant, iceGiant, ringedGiant, ringedIceGiant
    const moonSpec = spec?.[i]?.moons ?? null;
    const moonN = moonSpec ? moonSpec.length
      : isGiant ? rng.int(2, 4)
        : (body.realRadiusKm > 5500 && rng.chance(0.5) ? 1 : 0);
    if (moonN) {
      body.moons = [];
      // Innermost moon distance is JITTERED, not fixed at 3.2 R. It used to be
      // constant, and since the ring gaps are resonances with that moon, every
      // ringed giant in the game came out with its divisions at identical radii.
      let md = body.radius * rng.range(2.55, 4.4);
      for (let m = 0; m < moonN; m++) {
        const ms = moonSpec?.[m];
        const msObj = typeof ms === 'string' ? { type: ms } : (ms ?? null);
        // Moons carry the new types too — an ocean-under-ice moon is a survey
        // target in its own right, and it only makes sense around a giant.
        const mk = msObj?.type ?? (rng.chance(0.18) ? 'oceanIce'
          : rng.chance(0.12) ? 'sulfurMoon'
            : rng.chance(0.5) ? 'iceMoon' : 'moon');
        const mName = msObj?.name ?? `${name} ${romanLower(m + 1)}`;
        const moon = makeBody(rng, `${body.id}_m${m}`, mName, mk, au);
        // Moons orbit their planet, not the star, so they take the much smaller
        // planetary gravitational parameter — which via the third law is what
        // makes a moon's month minutes long while its planet's year is an hour.
        moon.dist = md;
        placeOrbit(rng, moon, md, 'moon', MOON_MU);
        moon.info = msObj?.info ?? flavour(mk, rng);
        body.moons.push(moon);
        md += body.radius * rng.range(1.4, 2.6);
      }
    }
    // rings are solved FROM the moons, so this has to come after them
    buildRings(rng, body);
    bodies.push(body);
    au *= ratio();
  }

  // an asteroid belt — a ring of small rocky/icy planetoids, placed a couple of
  // times the habitable-zone width out (Sol's belt sits ~2.5× its HZ radius).
  // `beltAt` lets a lore system pin the belt somewhere the rules wouldn't put it
  // (Amber Well's belt is the *shredded inner system*, far closer in than 2.5×HZ).
  const beltAU = def.beltAt ?? hzOuter * pick(rng, [2.1, 2.8]);
  const beltN = def.belt === false ? 0 : (def.beltN ?? rng.int(11, 17));
  const beltSpread = def.beltSpread ?? 0.14;
  for (let k = 0; k < beltN; k++) {
    const bk = rng.chance(0.78) ? 'planetoid' : 'dwarf';
    const bAU = beltAU * (1 + rng.range(-beltSpread, beltSpread));
    const b = makeBody(rng, `${def.id}_a${k}`, `${beltTag(def)}-${100 + rng.int(0, 899)}`, bk, bAU);
    b.class = 'Asteroid';
    // Three materials, not two: an M-type nickel-iron shard next to a C-type rock
    // and a dirty snowball is what an actual belt survey reads like, and the metal
    // ones are the reason anyone mines here.
    const roll = rng.next();
    b.kind = roll < 0.55 ? 'rocky' : roll < 0.78 ? 'ice' : 'metal';
    if (b.kind === 'metal') { b.class = 'Metallic asteroid'; b.atmosphere = 'None'; }
    placeOrbit(rng, b, AU(bAU), 'asteroid');
    b.spin = rng.range(0.02, 0.06); // rubble tumbles fast
    // Explicit flag for the renderer, which draws shards as irregular tumbling
    // ellipsoids rather than spheres. It cannot infer this from `spin` (every
    // body spins) or from `kind` (a belt dwarf's kind is literally 'comet', while
    // a real comet's is 'ice' — see below), so the generator says so outright.
    b.shard = true;
    b.info = b.kind === 'metal'
      ? 'A nickel-iron shard — the core of something that never finished forming. Assay reads rich.'
      : 'A tumbling shard of the belt — barely a world, all rock and shadow.';
    bodies.push(b);
  }

  // a couple of outer dwarf planets / planetoids beyond the last planet
  for (let d = 0; d < rng.int(1, 3); d++) {
    au *= pick(rng, [1.3, 1.8]);
    const dk = rng.chance(0.5) ? 'dwarf' : 'planetoid';
    const b = makeBody(rng, `${def.id}_d${d}`, `${def.name} ${roman(n + d + 1)}`, dk, au);
    placeOrbit(rng, b, AU(au), 'dwarf');
    b.info = flavour(dk, rng);
    bodies.push(b);
  }

  // a rogue ice body drifting far beyond everything (The Pale's wanderer)
  if (def.rogue) {
    au *= 2.4;
    const b = makeBody(rng, `${def.id}_rogue`, 'THE WANDERER', 'ice', au);
    b.class = 'Rogue ice body';
    placeOrbit(rng, b, AU(au), 'rogue');
    b.info = 'Not from this system. Not from any charted one. It was passing through when the star caught it.';
    bodies.push(b);
  }

  // 1–2 long-period comets far out — dormant icy nuclei, no tail this far from
  // the star (tails only grow near perihelion; that's a future render pass).
  for (let c = 0; c < (def.comets ?? rng.int(1, 2)); c++) {
    au *= pick(rng, [1.4, 2.2]);
    const b = makeBody(rng, `${def.id}_c${c}`, `COMET ${cometTag(rng, c)}`, 'dwarf', au);
    b.class = 'Comet (nucleus)';
    b.kind = 'ice';
    b.radius = Math.max(6, b.radius * 0.5); // nuclei are small, icy
    // Steeply inclined and highly eccentric: a comet spends most of its period
    // crawling near apoapsis and whips through the inner system in a few
    // minutes, which the vis-viva speed makes visible on the NAV read-out.
    placeOrbit(rng, b, AU(au), 'comet');
    b.spin = rng.range(0.01, 0.03);
    // ...and the flag the coma/tail renderer keys off. `kind` is 'ice' here
    // because that is the SURFACE the nucleus should be textured with; the fact
    // that it is a comet is a separate property and needs its own field.
    b.comet = true;
    b.info = 'A dirty-ice nucleus. Grows a coma and twin tails as it nears the star.';
    bodies.push(b);
  }

  // start the ship just outside the colony world (or first body), sun beyond it
  const home = bodies.find((b) => b.colony) ?? bodies[Math.min(2, bodies.length - 1)];
  const hp = home.pos;
  const inward = normalize([-hp[0], -hp[1], -hp[2]]);
  // spawn close enough that the colony world is a big disc dead ahead, not a speck
  const off = home.radius * 1.9 + 500;
  // `look` is the direction that puts the home world (and the star behind it)
  // dead ahead. Without it an arrival kept whatever attitude the jump ended on,
  // which is usually empty sky — and staring at black is exactly why a jump read
  // as "the warp didn't work".
  const shipStart = {
    pos: [hp[0] - inward[0] * off, hp[1], hp[2] - inward[2] * off],
    look: [inward[0], 0, inward[2]],
  };

  // stations + derelicts park a few radii off their host planet, on the sunward
  // flank so they're lit. They ride in the `ships` list (same hull render path)
  // with extra fields the approach/docking system reads.
  const ships = [...(def.ships ?? [])];
  for (const st of def.stations ?? []) {
    const host = bodies[Math.min(st.near ?? 0, n - 1)];
    const d = host.radius * 2.2 + 380;
    const L = Math.hypot(host.pos[0], host.pos[2]) || 1;
    const sx = -host.pos[2] / L, sz = host.pos[0] / L; // tangential offset
    ships.push({
      id: st.id, name: st.name, station: true, refuel: st.refuel !== false,
      // Station KIND. Every authored station used to render as the same
      // freighter mesh, so a trade post and a shipyard were the same object —
      // and mechanically identical too. The kind now decides both the mesh and
      // what the docking counter offers.
      structure: st.kind ?? 'trade_post', kind: st.kind ?? 'trade_post', bodyR: 34,
      info: st.info ?? 'A Kestrel waypoint. Fuel, air, and a place to breathe.',
      pos: [host.pos[0] + sx * d, host.pos[1] + host.radius * 0.4, host.pos[2] + sz * d],
      // A station in orbit MOVES WITH ITS WORLD. Placing it relative to the host
      // once and leaving it there meant "Meridian Station, colony orbit" was
      // abandoned in empty space as soon as the colony went round the star —
      // harmless when orbits were slow circles, obvious now that they are not.
      hostId: host.id, hostOffset: [sx * d, host.radius * 0.4, sz * d], orbitPhase: 0,
      drift: [0, 0, 0], scale: st.scale ?? 3.2, reach: 420,
    });
  }
  for (const dr of def.derelicts ?? []) {
    const host = bodies[Math.min(dr.near ?? 0, n - 1)];
    const d = host.radius * 3.4 + 600;
    const L = Math.hypot(host.pos[0], host.pos[2]) || 1;
    const sx = host.pos[2] / L, sz = -host.pos[0] / L; // opposite flank — in shadow
    ships.push({
      id: dr.id, name: dr.name, derelict: true,
      structure: 'wreck', variant: rng.int(0, 2), dark: true, bodyR: 30,
      boardable: true,
      info: dr.info ?? 'No transponder. No lights. No answer.',
      pos: [host.pos[0] + sx * d, host.pos[1] - host.radius * 0.3, host.pos[2] + sz * d],
      // derelicts drift, but they drift RELATIVE to the world they died over
      hostId: host.id, hostOffset: [sx * d, -host.radius * 0.3, sz * d], orbitPhase: 0,
      drift: [rng.range(-0.4, 0.4), 0, rng.range(-0.4, 0.4)], scale: dr.scale ?? 1.0, reach: 300,
      tumble: [rng.range(-0.05, 0.05), rng.range(-0.03, 0.03)],
    });
  }
  populateStructures(rng, def, bodies, ships, n);
  // AFTER the structures: traffic routes terminate at stations, so the stations
  // have to exist before a route can be laid to one.
  populateTraffic(rng, def, bodies, ships);

  // -- and now make them all bigger -------------------------------------------
  // A trade post rendered at `scale` 3.2 on a ~40-unit mesh is 130 units across,
  // which was fine when a planet was 455 — and absurd now that one is 2900. The
  // multiplier is applied HERE, in one pass over the finished list, rather than
  // at each of the fourteen places a structure record is authored: a scale
  // factor that has to be remembered at every call site is a scale factor that
  // will be forgotten at one of them.
  //
  // `reach` grows by less than the mesh does. Reach is the stand-off at which
  // the docking prompt appears, and if it scaled with the hull you would still
  // meet a station as the same handful of pixels — the whole point is to be
  // allowed to get close to something big.
  for (const sh of ships) {
    sh.scale = (sh.scale ?? 1) * STRUCTURE_SCALE;
    sh.bodyR = (sh.bodyR ?? 20) * STRUCTURE_SCALE;
    if (sh.reach) sh.reach *= STRUCTURE_SCALE * 0.55;
    if (sh.trigger) sh.trigger *= STRUCTURE_SCALE * 0.55;
  }

  return {
    id: def.id, name: def.name,
    blurb: def.blurb ?? '', danger: def.danger ?? 'LOW',
    // 'ROUTE' = the commissioned survey line; 'SPUR' = charted but off it. The
    // warp chart groups on this so ten destinations still read as a route with
    // detours rather than a flat list.
    group: def.group ?? 'ROUTE',
    star: {
      name: def.starName ?? def.name, pos: [0, 0, 0], radius: starRadius, kind: 'star',
      color: star.color, starClass: star.name, classKey: def.starType ?? 'G', temp: star.temp,
      realRadiusKm: Math.round(R_SUN_KM * star.rSun),
    },
    bodies,
    ships,
    shipStart,
  };
}

/**
 * FILL THE SYSTEM WITH BUILT THINGS.
 *
 * Before this, a generated system contained a star, its worlds and — if a lore
 * record happened to list one — a station. Twenty-eight systems, and twenty-two
 * of them were empty sky with rocks in it. There was nothing to fly TOWARD.
 *
 * What goes in, and why each one earns its place rather than being scenery:
 *
 *   TRADE POST   somewhere to sell what you looted and buy what you need. One
 *                per system that is safe enough to have a counter.
 *   SHIPYARD     the only place a hull can be changed. Rare on purpose — the
 *                decision should cost a journey.
 *   REFINERY     sits ON the belt, because that is where the ore is. Buys raw
 *                ore above the going rate and sells refined metal.
 *   RELAY        no docking, no trade: a comms mast with a data core in it.
 *                Half of them are dead, and those are the interesting ones.
 *   WRECK FIELD  three to six broken hulls in a loose cluster, all boardable,
 *                all with loot in them. The reason to carry a suit.
 *   MINEFIELD    a volume somebody seeded and nobody swept. Pure hazard, and
 *                the only thing in the game that punishes flying in a straight
 *                line at speed.
 *   MONOLITH     unexplained. No trade, no dock, no answer. It exists so that
 *                "unknown structure" on the scanner sometimes means something
 *                nobody has a name for.
 *
 * Placement is DANGER-DRIVEN. A LOW-risk system gets the counter and the yard;
 * an EXTREME one gets the wrecks, the mines and the thing nobody built.
 */
function populateStructures(rng, def, bodies, ships, n) {
  if (def.noStructures) return;
  const danger = ['LOW', 'MODERATE', 'MEDIUM', 'HIGH', 'EXTREME'].indexOf(def.danger ?? 'LOW');
  const risk = danger < 0 ? 0 : danger > 2 ? danger - 1 : danger; // MEDIUM aliases MODERATE
  const planets = bodies.filter((b) => !b.shard && !b.comet && !b.isMoon);
  const belt = bodies.filter((b) => b.shard);
  const already = new Set(ships.map((s) => s.structure));

  /** Park a record a few radii off a host, on a stated flank. */
  const park = (rec, host, dist, up, flank) => {
    const L = Math.hypot(host.pos[0], host.pos[2]) || 1;
    const sx = (-host.pos[2] / L) * flank, sz = (host.pos[0] / L) * flank;
    rec.pos = [host.pos[0] + sx * dist, host.pos[1] + up, host.pos[2] + sz * dist];
    rec.hostId = host.id;
    rec.hostOffset = [sx * dist, up, sz * dist];
    rec.orbitPhase = rng.range(0, Math.PI * 2);
    rec.drift = [0, 0, 0];
    ships.push(rec);
    return rec;
  };

  // -- a trading post, unless the lore already put a station here ------------
  if (!already.has('trade_post') && planets.length && risk <= 2 && rng.chance(0.8)) {
    const host = planets[rng.int(0, Math.min(2, planets.length - 1))];
    park({
      id: `${def.id}_tp`, name: `${shortName(def.name)} TRANSFER`, station: true,
      structure: 'trade_post', kind: 'trade_post', refuel: true, trade: true,
      bodyR: 34, scale: 2.6, reach: 460,
      info: 'A transfer post. Bonded warehousing, a fuel bowser and a counter that '
        + 'will take anything you can prove you own.',
    }, host, host.radius * 2.4 + 420, host.radius * 0.4, 1);
  }

  // -- a shipyard: uncommon, and only where it is safe enough to build ------
  // 0.42 at risk<=1 produced ZERO shipyards across the ten authored systems on
  // the first roll — a feature that exists nowhere is not a rare feature, it is
  // a broken one. One in two of the calmer systems puts roughly one within a
  // couple of jumps wherever you start.
  if (planets.length > 1 && risk <= 2 && rng.chance(0.5)) {
    const host = planets[rng.int(0, planets.length - 1)];
    park({
      id: `${def.id}_yd`, name: `${shortName(def.name)} BUILDING SLIP`, station: true,
      structure: 'shipyard', kind: 'shipyard', refuel: true, shipyard: true,
      bodyR: 46, scale: 2.2, reach: 520,
      info: 'An open slip with something half-built in it. They will sell you a hull, '
        + 'take yours in part exchange, and not ask what happened to the last one.',
    }, host, host.radius * 3.0 + 700, -host.radius * 0.2, -1);
  }

  // -- a refinery, ON the belt where the ore is -----------------------------
  if (belt.length && rng.chance(0.62)) {
    const host = belt[rng.int(0, belt.length - 1)];
    park({
      id: `${def.id}_rf`, name: `${shortName(def.name)} SMELTER`, station: true,
      structure: 'refinery', kind: 'refinery', refuel: true, trade: true,
      bodyR: 30, scale: 2.0, reach: 400,
      info: 'A smelter riding the belt. It buys raw ore over the book price because '
        + 'hauling it anywhere else costs more than the ore is worth.',
    }, host, host.radius * 5.0 + 300, 0, 1);
  }

  // -- a comms relay. Half are dead, and a dead one is worth more -----------
  if (planets.length && rng.chance(0.55)) {
    const host = planets[planets.length - 1];
    const dead = rng.chance(0.5);
    park({
      id: `${def.id}_rl`, name: dead ? `RELAY ${rng.int(100, 999)} (SILENT)` : `RELAY ${rng.int(100, 999)}`,
      structure: 'relay', kind: 'relay', station: false, salvage: true, dark: dead,
      bodyR: 24, scale: 1.4, reach: 260, boardable: dead,
      info: dead
        ? 'It stopped answering nine years ago and nobody was sent. The dish is still '
          + 'pointed at something.'
        : 'An automated relay, working. It logs your transponder as you pass.',
    }, host, host.radius * 4.2 + 900, host.radius * 0.9, -1);
  }

  // -- a wreck field: the reason to own a suit ------------------------------
  if (risk >= 1 && rng.chance(0.7)) {
    const host = planets[rng.int(0, Math.max(0, planets.length - 1))] ?? bodies[0];
    const count = rng.int(3, 6);
    const base = host.radius * 3.8 + 1100;
    const L = Math.hypot(host.pos[0], host.pos[2]) || 1;
    const bx = -host.pos[2] / L, bz = host.pos[0] / L;
    for (let k = 0; k < count; k++) {
      const spread = 260;
      const ox = bx * base + rng.range(-spread, spread);
      const oz = bz * base + rng.range(-spread, spread);
      const oy = rng.range(-spread * 0.5, spread * 0.5);
      ships.push({
        id: `${def.id}_wk${k}`, name: `${WRECK_NAMES[rng.int(0, WRECK_NAMES.length - 1)]} (WRECK)`,
        derelict: true, structure: 'wreck', variant: rng.int(0, 2), dark: true,
        boardable: true, bodyR: 28, scale: rng.range(0.8, 1.6), reach: 240,
        info: WRECK_INFO[rng.int(0, WRECK_INFO.length - 1)],
        pos: [host.pos[0] + ox, host.pos[1] + oy, host.pos[2] + oz],
        hostId: host.id, hostOffset: [ox, oy, oz], orbitPhase: rng.range(0, 6.28),
        drift: [rng.range(-0.3, 0.3), 0, rng.range(-0.3, 0.3)],
        tumble: [rng.range(-0.06, 0.06), rng.range(-0.04, 0.04)],
      });
    }
  }

  // -- a minefield somebody seeded and nobody swept -------------------------
  if (risk >= 2 && rng.chance(0.6)) {
    const host = planets[rng.int(0, Math.max(0, planets.length - 1))] ?? bodies[0];
    const count = rng.int(9, 16);
    const base = host.radius * 2.9 + 800;
    const L = Math.hypot(host.pos[0], host.pos[2]) || 1;
    const bx = host.pos[2] / L, bz = -host.pos[0] / L;
    for (let k = 0; k < count; k++) {
      const s = 420;
      const ox = bx * base + rng.range(-s, s);
      const oz = bz * base + rng.range(-s, s);
      const oy = rng.range(-s * 0.4, s * 0.4);
      ships.push({
        id: `${def.id}_mn${k}`, name: 'PROXIMITY MINE', structure: 'mine',
        mine: true, damage: 22, trigger: 90, bodyR: 8, scale: 2.2, reach: 0,
        info: 'Unswept ordnance. It has been waiting a long time.',
        pos: [host.pos[0] + ox, host.pos[1] + oy, host.pos[2] + oz],
        hostId: host.id, hostOffset: [ox, oy, oz], orbitPhase: rng.range(0, 6.28),
        drift: [0, 0, 0], tumble: [rng.range(-0.02, 0.02), rng.range(-0.02, 0.02)],
      });
    }
  }

  // -- the thing nobody built ------------------------------------------------
  if (rng.chance(risk >= 3 ? 0.5 : 0.16)) {
    const host = planets[rng.int(0, Math.max(0, planets.length - 1))] ?? bodies[0];
    park({
      id: `${def.id}_mo`, name: 'UNKNOWN STRUCTURE', structure: 'monolith',
      variant: rng.int(0, 2), dark: true, anomaly: true, scan: true,
      bodyR: 34, scale: rng.range(1.4, 3.2), reach: 380,
      info: 'The scanner returns a mass and a shape and refuses to name a material. '
        + 'It is not on any chart, it answers nothing, and it has been here longer '
        + 'than the survey office has existed.',
    }, host, host.radius * 5.5 + 1400, rng.range(-400, 400), rng.chance(0.5) ? 1 : -1);
  }
}

/**
 * CIVILIAN TRAFFIC — the ships that are not trying to kill you.
 *
 * Before this the only moving thing in a system was a hostile patrol, which
 * made every system read as either empty or a fight. Traffic is the third
 * state: somebody else is out here, working, and paying you no attention.
 *
 * They fly ROUTES rather than wander, because a route is legible — a hauler
 * between the smelter and the transfer post is doing something you can watch
 * and predict, and a ship on a random walk is set dressing. `StarSystem.update`
 * flies them; this only lays out where and between what.
 *
 * Deliberately NOT hostile and deliberately not scripted into quests here. They
 * exist so the lanes are inhabited. What you do about that is your business,
 * and the faction system already knows how to feel about it.
 */
function populateTraffic(rng, def, bodies, ships) {
  if (def.noTraffic) return;
  const stations = ships.filter((s) => s.station);
  const planets = bodies.filter((b) => !b.shard && !b.comet && !b.isMoon);
  const belt = bodies.filter((b) => b.shard);
  const waypoints = [...stations.map((s) => s.pos), ...planets.map((b) => b.pos)];
  if (waypoints.length < 2) return;

  /** One traffic record on a two-point route. */
  const add = (kind, name, from, to, opts) => {
    const legLen = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]) || 1;
    ships.push({
      id: `${def.id}_tr${ships.length}`, name, traffic: true, kind,
      structure: kind, bodyR: opts.bodyR ?? 20, scale: opts.scale ?? 1.0,
      reach: opts.reach ?? 180, hail: opts.hail, info: opts.info,
      trade: !!opts.trade,
      // Route state. `t` walks 0→1 and bounces, so a hauler that reaches the
      // smelter turns round and takes the load back — which is what a shuttle
      // service is, and it means a route never needs re-planning.
      route: [[...from], [...to]], t: rng.next(), dir: rng.chance(0.5) ? 1 : -1,
      speed: opts.speed / legLen, // per-second fraction of the leg
      pos: [0, 0, 0], drift: [0, 0, 0],
    });
  };

  // Ore haulers: belt ↔ the nearest station, the busiest lane in any system
  // that has both a rock to cut and somewhere to sell it.
  if (belt.length && stations.length) {
    for (let k = 0; k < rng.int(1, 3); k++) {
      const rock = belt[rng.int(0, belt.length - 1)];
      const st = stations[rng.int(0, stations.length - 1)];
      add('miner', `ORE TENDER ${rng.int(10, 99)}`, rock.pos, st.pos, {
        speed: 340, bodyR: 20, scale: 1.5, reach: 200, trade: true,
        hail: 'ORE TENDER — CUTTING A CLAIM. KEEP YOUR DISTANCE FROM THE HEAD.',
        info: 'A mining tender working the belt. It will buy tools and sell you ore '
          + 'cheaper than the smelter does, because it does not have to haul it there.',
      });
    }
  }
  // Bulk haulers between the stations, or station ↔ colony if there is one post
  if (stations.length) {
    for (let k = 0; k < rng.int(1, 3); k++) {
      const a = stations[rng.int(0, stations.length - 1)].pos;
      const others = waypoints.filter((w) => w !== a);
      const bpt = others[rng.int(0, others.length - 1)];
      add('trader', `${HAULER_NAMES[rng.int(0, HAULER_NAMES.length - 1)]}`, a, bpt, {
        speed: 420, bodyR: 26, scale: 1.4, reach: 240, trade: true,
        hail: 'BULK HAULER — LOADED AND ON SCHEDULE. NOTHING TO DECLARE.',
        info: 'A container hauler on a scheduled run. The master will trade off the '
          + 'manifest if the price is right and nobody writes it down.',
      });
    }
  }
  // Couriers crossing the system between worlds — the neutral hull
  for (let k = 0; k < rng.int(1, 2); k++) {
    const a = waypoints[rng.int(0, waypoints.length - 1)];
    const others = waypoints.filter((w) => w !== a);
    if (!others.length) break;
    add('courier', `COURIER ${GREEK[rng.int(0, GREEK.length - 1)]}-${rng.int(10, 99)}`,
      a, others[rng.int(0, others.length - 1)], {
        speed: 760, bodyR: 12, scale: 1.0, reach: 150,
        hail: 'COURIER — PRIORITY TRAFFIC, NO CARGO, NO STOPS. GOOD LANES.',
        info: 'A dispatch runner. Carries paper, chips and occasionally people, '
          + 'and is not going to slow down for either of you.',
      });
  }
}

const HAULER_NAMES = ['KSV LONG PATIENCE', 'BULK CARRIER FEN', 'HAULER SIX PENNY',
  'KSV DRAY', 'ORE MASTER 12', 'THE SLOW MONDAY', 'CARRIER WICK', 'KSV STOUT'];

/** First word of a system name, for naming its structures after it. */
function shortName(name) { return String(name).split(/[\s-]/)[0].toUpperCase(); }

const WRECK_NAMES = ['KSV MARROW', 'HAULER BENT PIN', 'SURVEY 12', 'OSPREY', 'COLD ANNIE',
  'TRANSIT 7', 'KSV WICKER', 'THE LAST TUESDAY', 'ORE BARGE 44', 'CUTTER FEN',
  'LONG HAUL 9', 'KSV TALLOW'];
const WRECK_INFO = [
  'Broken across the spine. Whatever did it went through from the outside.',
  'Reactor cold, atmosphere gone, hatches still dogged from the inside.',
  'Cut apart for salvage and abandoned half-finished. Somebody was interrupted.',
  'No distress beacon was ever logged. The lifeboat cradles are all still full.',
  'Nine years on the register as OVERDUE. This is where it went.',
  'Scorched along one flank. The other side is untouched.',
];

function normalize(v) { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; }
const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
function roman(i) { return ROMAN[i - 1] ?? String(i); }
function romanLower(i) { return (ROMAN[i - 1] ?? String(i)).toLowerCase(); }
function beltTag(def) { return (def.name.match(/[A-Z]/g) ?? ['X']).slice(0, 2).join(''); }
const GREEK = ['ALPHA', 'BETA', 'GAMMA', 'DELTA', 'EPSILON', 'ZETA'];
// Sequence number included: the tag used to be two random draws from a
// six-name list, so two comets in one system collided about one time in six —
// and Sol Prime shipped with two objects both designated COMET ZETA-4.
function cometTag(rng, idx) { return `${GREEK[idx % GREEK.length]}-${rng.int(10, 99)}`; }

function flavour(typeKey, rng) {
  const F = {
    lava: ['Tide-locked and molten on the star side; mining claims cling to the terminator.', 'A cracked shell of cooling basalt over a churning interior.'],
    desert: ['Endless dune seas under a thin, dusty sky.', 'Wind-scoured rock; old survey markers half-buried.'],
    rocky: ['Cratered grey rock, airless and still.', 'Barren stone, scarred by ancient impacts.'],
    ocean: ['Deep global ocean broken by scattered archipelagos.', 'Blue world, storm bands wrapping the equator.'],
    jungle: ['Riotous green continents under heavy cloud.', 'Warm, wet, and teeming — the air is thick enough to drink.'],
    superearth: ['A heavy world; standing here would test your knees.', 'Vast and dense, its gravity pins the haze low.'],
    ice: ['Frozen silicate-ice crust; a thin nitrogen haze.', 'Glacial plains split by pressure ridges.'],
    iceGiant: ['A cold blue giant streaked with methane cloud.', 'Deep, freezing, and banded — no surface to speak of.'],
    gasGiant: ['A banded hydrogen giant; tankers skim its cloud deck for fuel.', 'Storms the size of moons roll through its belts.'],
    dwarf: ['A lonely ice-dwarf at the system’s edge.', 'Barely rounded by its own weak gravity.'],
    moon: ['A pockmarked rock in a giant’s shadow.', 'Airless, grey, tidally kneaded.'],
    iceMoon: ['A cracked ice shell over a slush ocean.', 'Bright ice, dark fracture veins.'],
    planetoid: ['A tumbling shard of rock, barely a world.', 'Little more than a captured mountain.'],
    toxic: ['An unbroken ochre cloud deck. Nothing has ever seen its ground and come back up.',
      'Surface pressure would fold the hull inside a minute. Beautiful from up here.'],
    carbon: ['Graphite crust, diamond in the fractures, tar where the light pools.',
      'A world made of soot and gemstone. No water was ever involved.'],
    metal: ['A planetary core with the world stripped off it. Assay reads like a shipyard.',
      'Bare nickel-iron, mirror-bright where the last impact scoured it.'],
    tundra: ['Ice sheets two thirds of the way to the equator; olive steppe between.',
      'Cold, thin, and just about breathable through a mask. Survivable, barely.'],
    ashWorld: ['Ash to the horizon over a crust that stopped moving a long time ago.',
      'Cinder cones in a row, all the same age, none of them smoking.'],
    saltWorld: ['It had an ocean. The tide line is eighty metres up a cliff with nothing under it.',
      'Salt polygons from pole to pole and a wind that never drops.'],
    ironWorld: ['Banded iron in rust and grey, a thousand layers, each one a summer.',
      'The assay reads like a shipyard invoice. The compass reads like nothing at all.'],
    crystalWorld: ['A field of shards taller than a survey cutter, all leaning the same way.',
      'They ring when the ground moves, and the ground moves often.'],
    tidalLocked: ['One face has never seen night. The other has never seen anything else.',
      'The terminator is a weather system four hundred kilometres wide.'],
    oceanIce: ['A cracked shell with a liquid ocean under it. Something is venting at the south pole.',
      'Fracture veins, dark and fresh. Whatever is below has been busy.'],
    sulfurMoon: ['Sulphur plains repainted by eruption faster than any chart can hold.',
      'Squeezed by its giant until it split. It has been erupting ever since.'],
    ringedGiant: ['A banded giant inside a ring system wide enough to see from the next orbit.',
      'Rings of dirty ice, sharp-edged, with one clean division through them.'],
    ringedIceGiant: ['A cold blue giant wearing a thin, hard-edged ring of shepherded ice.',
      'Methane haze below, shattered ice above.'],
  };
  const a = F[typeKey] ?? ['A cold, distant body.'];
  return a[rng.int(0, a.length - 1)];
}
