/**
 * WRECK PLAN — the inside of a dead ship, as somewhere you walk.
 *
 * Boarding has been a list since 0.31.0: a panel with a compartment name, an
 * oxygen figure and an ADVANCE button. The mechanic underneath is good — every
 * step deeper costs air twice, once going in and once walking back — but the
 * player was reading it rather than doing it.
 *
 * This is that same sequence laid out as a deck. Going deeper is WALKING
 * deeper; the salvage point in each compartment is what charges the oxygen and
 * rolls the hazard, so the decision "one more compartment" is now made with
 * your feet in a dark corridor rather than with a mouse on a button.
 *
 * WHY IT IS A STRAIGHT LINE. A wreck is not a place you explore, it is a place
 * you go into and have to come back out of, and the whole tension is the length
 * of the way back. Branching would make the return trip ambiguous; a single
 * spine means the exit is always behind you and always exactly as far as you
 * have come. It is also the only shape that maps cleanly onto the existing
 * compartment sequence, so nothing about the oxygen model had to change.
 *
 * EVERYTHING IS DARK. No zone declares a light. The compartments carry emergency
 * fittings that are dead, and the helmet lamp is the only working source aboard
 * — which is what the lamp has been for since Phase 1 and has never once been
 * necessary until now.
 */

const TEX_HULK = { wall: 'wall_military', floor: 'floor_plate', ceil: 'ceiling_panel' };
const TEX_BURNT = { wall: 'wall_engine', floor: 'floor_grate', ceil: 'ceiling_pipes' };
const TEX_HOLD = { wall: 'wall_cargo', floor: 'floor_cargo', ceil: 'ceiling_pipes' };

/** Through the breach, just inside. Facing further in, because that is the way. */
export const WRECK_SPAWN = { pos: [0, 0, 2.2], yaw: Math.PI, pitch: 0 };

export const WRECK_ZONES = [
  {
    id: 'breach', kind: 'room', name: 'BREACH', h: 3.0,
    rect: { x0: -3.5, x1: 3.5, z0: 0, z1: 6 }, tex: TEX_BURNT, surface: 'grating',
    // The hole you came in by. The only opening on the deck that shows stars,
    // and the reason you can always find the way out: it is the lit one.
    windows: [{ wall: 'nz', center: 0, w: 2.6, y0: 0.7, y1: 2.4 }],
  },
  { id: 'w_hold', kind: 'room', name: 'CARGO HOLD', h: 4.6, rect: { x0: -6, x1: 6, z0: 10, z1: 22 }, tex: TEX_HOLD, surface: 'grating' },
  { id: 'w_quarters', kind: 'room', name: 'CREW SPACES', h: 2.8, rect: { x0: -5, x1: 5, z0: 26, z1: 34 }, tex: TEX_HULK, surface: 'metal' },
  { id: 'w_medical', kind: 'room', name: 'SICK BAY', h: 2.8, rect: { x0: -5, x1: 5, z0: 38, z1: 45 }, tex: { wall: 'fixture_white', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'w_bridge', kind: 'room', name: 'BRIDGE', h: 3.0, rect: { x0: -5.5, x1: 5.5, z0: 49, z1: 56 }, tex: TEX_HULK, surface: 'metal' },
  { id: 'w_engine', kind: 'room', name: 'DRIVE SECTION', h: 4.2, rect: { x0: -5, x1: 5, z0: 60, z1: 68 }, tex: TEX_BURNT, surface: 'grating' },

  // -- OFF THE SPINE (0.53.0) ---------------------------------------------------
  //
  // Two side compartments and two more at the far end. The spine is still the
  // through-line and the exit is still always behind you — see the header — but
  // a hull with nothing opening off it is a tunnel, and now that there are
  // things aboard that hunt you, a doorway you have to turn your back on is
  // worth more than another ten metres of corridor.
  { id: 'w_galley', kind: 'room', name: 'GALLEY', h: 2.6, rect: { x0: -11.5, x1: -5, z0: 27, z1: 33 }, tex: TEX_HULK, surface: 'metal' },
  { id: 'w_shop', kind: 'room', name: 'WORKSHOP', h: 3.0, rect: { x0: 5.5, x1: 12, z0: 49.5, z1: 56 }, tex: TEX_BURNT, surface: 'grating' },
  // ...and the two the old compartment list promised and the deck never had.
  { id: 'w_reactor', kind: 'room', name: 'REACTOR SPACE', h: 4.4, rect: { x0: -6, x1: 6, z0: 72, z1: 81 }, tex: TEX_BURNT, surface: 'grating' },
  { id: 'w_core', kind: 'room', name: 'SEALED COMPARTMENT', h: 2.7, rect: { x0: -4.5, x1: 4.5, z0: 85, z1: 92 }, tex: TEX_HULK, surface: 'metal' },

  // -- the spine, unlit ---------------------------------------------------------
  { id: 'w_c1', kind: 'corridor', type: 'B', shape: 'flat', name: 'PASSAGE', rect: { x0: -1.4, x1: 1.4, z0: 6, z1: 10 }, h: 2.4, tex: TEX_BURNT, surface: 'grating' },
  { id: 'w_c2', kind: 'corridor', type: 'C', shape: 'buttress', name: 'PASSAGE', rect: { x0: -1.8, x1: 1.8, z0: 22, z1: 26 }, h: 3.0, tex: TEX_HULK, surface: 'metal' },
  { id: 'w_c3', kind: 'corridor', type: 'B', shape: 'flat', name: 'PASSAGE', rect: { x0: -1.4, x1: 1.4, z0: 34, z1: 38 }, h: 2.4, tex: TEX_HULK, surface: 'metal' },
  { id: 'w_c4', kind: 'corridor', type: 'C', shape: 'buttress', name: 'PASSAGE', rect: { x0: -1.8, x1: 1.8, z0: 45, z1: 49 }, h: 3.0, tex: TEX_HULK, surface: 'metal' },
  { id: 'w_c5', kind: 'corridor', type: 'D', shape: 'hex', name: 'CRAWLWAY', rect: { x0: -0.9, x1: 0.9, z0: 56, z1: 60 }, h: 1.9, tex: TEX_BURNT, surface: 'grating' },
  { id: 'w_c6', kind: 'corridor', type: 'B', shape: 'flat', name: 'AFT PASSAGE', rect: { x0: -1.6, x1: 1.6, z0: 68, z1: 72 }, h: 2.6, tex: TEX_BURNT, surface: 'grating' },
  // The last few metres are a crawl. Whatever is in the sealed compartment, you
  // meet it on your hands and knees, and you back out the same way.
  { id: 'w_c7', kind: 'corridor', type: 'D', shape: 'hex', name: 'ACCESS CRAWL', rect: { x0: -0.85, x1: 0.85, z0: 81, z1: 85 }, h: 1.85, tex: TEX_HULK, surface: 'metal' },
];

/**
 * All portals, no doors. A dead ship has no power to open one with, and a deck
 * full of doors you cannot open is a deck you cannot walk — the fiction is that
 * these are blown open or jammed wide, which is also why it is cold in here.
 */
export const WRECK_CONNECTIONS = [
  { id: 'wp1', kind: 'portal', a: 'breach', b: 'w_c1', plane: 'z', at: 6, center: 0, w: 2.2, h: 2.3 },
  { id: 'wp2', kind: 'portal', a: 'w_c1', b: 'w_hold', plane: 'z', at: 10, center: 0, w: 2.2, h: 2.3 },
  { id: 'wp3', kind: 'portal', a: 'w_hold', b: 'w_c2', plane: 'z', at: 22, center: 0, w: 2.8, h: 2.8 },
  { id: 'wp4', kind: 'portal', a: 'w_c2', b: 'w_quarters', plane: 'z', at: 26, center: 0, w: 2.8, h: 2.7 },
  { id: 'wp5', kind: 'portal', a: 'w_quarters', b: 'w_c3', plane: 'z', at: 34, center: 0, w: 2.2, h: 2.3 },
  { id: 'wp6', kind: 'portal', a: 'w_c3', b: 'w_medical', plane: 'z', at: 38, center: 0, w: 2.2, h: 2.3 },
  { id: 'wp7', kind: 'portal', a: 'w_medical', b: 'w_c4', plane: 'z', at: 45, center: 0, w: 2.8, h: 2.7 },
  { id: 'wp8', kind: 'portal', a: 'w_c4', b: 'w_bridge', plane: 'z', at: 49, center: 0, w: 2.8, h: 2.8 },
  { id: 'wp9', kind: 'portal', a: 'w_bridge', b: 'w_c5', plane: 'z', at: 56, center: 0, w: 1.4, h: 1.8 },
  { id: 'wp10', kind: 'portal', a: 'w_c5', b: 'w_engine', plane: 'z', at: 60, center: 0, w: 1.4, h: 1.8 },
  // The side compartments open straight off the rooms they serve, on the x
  // plane — a galley is next to the mess and a workshop is next to the bridge
  // on any hull anybody ever built.
  { id: 'wp11', kind: 'portal', a: 'w_quarters', b: 'w_galley', plane: 'x', at: -5, center: 30, w: 2.0, h: 2.2 },
  { id: 'wp12', kind: 'portal', a: 'w_bridge', b: 'w_shop', plane: 'x', at: 5.5, center: 52.5, w: 2.2, h: 2.4 },
  { id: 'wp13', kind: 'portal', a: 'w_engine', b: 'w_c6', plane: 'z', at: 68, center: 0, w: 2.4, h: 2.5 },
  { id: 'wp14', kind: 'portal', a: 'w_c6', b: 'w_reactor', plane: 'z', at: 72, center: 0, w: 2.4, h: 2.5 },
  { id: 'wp15', kind: 'portal', a: 'w_reactor', b: 'w_c7', plane: 'z', at: 81, center: 0, w: 1.3, h: 1.7 },
  { id: 'wp16', kind: 'portal', a: 'w_c7', b: 'w_core', plane: 'z', at: 85, center: 0, w: 1.3, h: 1.7 },
];

/** Compartment order, outward to innermost — what a salvage point charges for. */
export const WRECK_DEPTH = ['breach', 'w_hold', 'w_quarters', 'w_galley', 'w_medical',
  'w_bridge', 'w_shop', 'w_engine', 'w_reactor', 'w_core'];
