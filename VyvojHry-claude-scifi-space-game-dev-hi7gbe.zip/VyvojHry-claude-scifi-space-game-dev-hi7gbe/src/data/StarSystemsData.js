/**
 * StarSystemsData — the five systems of the survey route (context/03 §4),
 * generated from real-astronomy rules (CelestialGen.js). Lore systems force
 * their planet composition via planetSpec; everything else (real km radii,
 * AU-spaced Titius–Bode orbits, moons, belts, comets) comes from the rules.
 *
 * Scale is compressed but proportional: body radii come from real km
 * (KM_PER_UNIT) and orbits from real AU (UNITS_PER_AU), so the *ratios* and the
 * NAV read-out are real even though the absolute clock/size is game-tuned.
 */
import { generateSystem } from './CelestialGen.js';

export const SOL_PRIME = generateSystem({
  id: 'sol_prime',
  name: 'SOL PRIME',
  starType: 'G',
  starName: 'SOL PRIME',
  seed: 0x50f1a2,
  planetCount: 8,
  habitableName: 'AETHON',
  colony: true,
  danger: 'LOW',
  blurb: 'Home lane. Colony world, company stations, easy ore. Mostly safe — mostly.',
  stations: [
    { id: 'meridian', name: 'MERIDIAN STATION', near: 3, info: 'Kestrel’s colony-orbit hub. Fuel, cargo transfer, a bar that never closes.' },
    { id: 'outer_reach', name: 'OUTER REACH DOCKYARD', near: 6, info: 'Half shipyard, half scrapyard. The Aethon was refitted here twice.' },
  ],
  derelicts: [
    { id: 'shuttle_wreck', name: 'UNREGISTERED SHUTTLE', near: 3, info: 'A short-range shuttle, holed and cold. Someone was here. Now they aren’t.' },
  ],
  ships: [
    { id: 'ksv_gull', name: 'KSV MARROW GULL', pos: [0, 0, 0], drift: [-1.1, 0, 0.5], scale: 1.0 },
  ],
});

export const VEGA_REACH = generateSystem({
  id: 'vega_reach',
  name: 'VEGA REACH',
  starType: 'B',
  starName: 'VEGA REACH',
  seed: 0x7e6a01,
  danger: 'HIGH',
  blurb: 'Keth Armada home ground. Blue furnace star, scorched rock, no breathable air anywhere.',
  planetSpec: [
    { type: 'lava', name: 'CINDERON', info: 'Glass plains still cooling from the last stellar flare.' },
    { type: 'lava', name: 'PYRRHA', info: 'The Keth strip-mine its crust from orbit. Stay off their scopes.' },
    { type: 'lava', name: 'ASHFALL', info: 'Tide-locked. The terminator canyon hides old extraction rigs.' },
    { type: 'gasGiant', name: 'THUNDERHEAD', info: 'Permanent electrical storm. Lightning arcs longer than the ship.' },
    { type: 'ice', name: 'LAST LIGHT', info: 'The only quiet place in the system. Emphasis on quiet.' },
  ],
  belt: false,
  comets: 1,
  stations: [
    { id: 'vega_platform', name: 'VEGA EXTRACTION PLATFORM', near: 4, info: 'Armored company rig. The last human waypoint before Keth space proper.' },
  ],
});

export const REDFALL = generateSystem({
  id: 'redfall',
  name: 'REDFALL',
  starType: 'M',
  starName: 'REDFALL',
  seed: 0x9ed4a1,
  danger: 'MEDIUM',
  blurb: 'Vrenn home space. Two living worlds under a red dwarf. First-contact protocols apply.',
  planetSpec: [
    { type: 'lava', name: 'REDFALL I', info: 'A cinder skimming the red dwarf’s corona.' },
    { type: 'rocky', name: 'REDFALL II', info: 'Grey rock washed in permanent red dusk.' },
    { type: 'jungle', name: 'VERDANE', info: 'A lush alien jungle world. The canopy moves when nothing pushes it.' },
    { type: 'rocky', name: 'KERATH', info: 'The Vrenn city-world. Spire-cities visible from orbit, bioluminescent by night.' },
    { type: 'iceGiant', name: 'REDFALL V', info: 'Cold blue giant; the Vrenn skim it for reaction mass.' },
    { type: 'ice', name: 'REDFALL VI', info: 'Cracked ice shell. Vrenn burial barges orbit in silence.' },
    { type: 'dwarf', name: 'REDFALL VII', info: 'A dim outpost rock at the edge of Vrenn patrol range.' },
  ],
  stations: [
    { id: 'vrenn_hub', name: 'VRENN TRADE HUB', near: 3, info: 'Curved organic piers, warm damp air. Neutral ground — while your reputation holds.' },
  ],
});

export const TWIN_SUNS = generateSystem({
  id: 'twin_suns',
  name: 'TWIN SUNS',
  starType: 'KM',
  starName: 'TWIN SUNS',
  seed: 0x2b17,
  danger: 'HIGH',
  blurb: 'Binary pair. Tidally torn worlds, Drift patrols, and ruins older than either sun’s name.',
  planetSpec: [
    { type: 'lava', name: 'TWIN SUNS I', info: 'Kneaded molten by the binary tide. Never solid, never still.' },
    { type: 'rocky', name: 'TWIN SUNS II', info: 'Split by tidal stress. The canyon system is visible from orbit.' },
    { type: 'desert', name: 'TWIN SUNS III', info: 'Irradiated dune seas. Ruins on the innermost moon — older than any charted species.' },
    { type: 'superearth', name: 'TWIN SUNS IV', info: 'Heavy, dead, and drummed by meteor falls.' },
    { type: 'iceGiant', name: 'TWIN SUNS V', info: 'The Drift hold this orbit. Crystalline hulls against blue methane.' },
    { type: 'ice', name: 'TWIN SUNS VI', info: 'Silent ice. Something below it answers radar with radar.' },
  ],
  stations: [
    { id: 'l4_ancient', name: 'THE L4 RELIC', near: 3, scale: 4.5, refuel: false, info: 'An abandoned station at the L4 point. Not built by humans. Not built by Vrenn. Doors open.' },
  ],
  derelicts: [
    { id: 'drift_kill', name: 'GUTTED FREIGHTER', near: 4, info: 'Hull opened like fruit. Whatever boarded her wanted the machines, not the crew.' },
  ],
});

export const THE_PALE = generateSystem({
  id: 'the_pale',
  name: 'THE PALE',
  starType: 'KD',
  starName: 'THE PALE',
  seed: 0xa11d09,
  danger: 'EXTREME',
  blurb: 'A star barely burning. Four frozen worlds, one wanderer, and THE ARCHIVE. End of the survey line.',
  planetSpec: [
    { type: 'ice', name: 'PALE I', info: 'Nitrogen frost over black rock. The star gives no warmth here.' },
    { type: 'ice', name: 'PALE II', info: 'Glacial plains scored by straight lines no glacier makes.' },
    { type: 'ice', name: 'PALE III', info: 'THE ARCHIVE orbits here — fifty kilometres of ancient structure, still powered.' },
    { type: 'ice', name: 'PALE IV', info: 'The last world. Beyond it, the dark between stars.' },
  ],
  rogue: true,
  belt: false,
  comets: 2,
  stations: [
    { id: 'archive', name: 'THE ARCHIVE', near: 2, scale: 7, refuel: false, info: 'A 50 km megastructure, older than the star it orbits. It has been waiting. It is still waiting.' },
  ],
  derelicts: [
    { id: 'pale_survey', name: 'KSV LONG SILENCE', near: 2, info: 'The last Kestrel survey ship sent this far. Log buoy wiped. Airlocks open to vacuum.' },
  ],
});

// ---------------------------------------------------------------------------
// OFF-ROUTE SPURS (session 16n). The five above are the commissioned survey
// line; these five are charted systems hanging off it — the same lane network,
// nobody's contract. They exist to make the chart feel like a region rather than
// a corridor, and each one is built around body types the route never shows:
// greenhouse worlds, stripped cores, carbon planets, ring systems, a dead star.
// ---------------------------------------------------------------------------

export const ODESSA_CHAIN = generateSystem({
  id: 'odessa_chain',
  name: 'ODESSA CHAIN',
  starType: 'F',
  starName: 'ODESSA',
  seed: 0x0de55a,
  group: 'SPUR',
  danger: 'MEDIUM',
  blurb: 'Kestrel’s other lane. Metal-rich, badly regulated, and full of people who left Sol Prime for a reason.',
  planetSpec: [
    { type: 'toxic', name: 'ODESSA I', info: 'Runaway greenhouse. Two survey probes went in; the telemetry stops mid-sentence both times.' },
    { type: 'metal', name: 'THE ANVIL', info: 'A stripped planetary core, mined open on three continents. The scars are visible from this orbit.' },
    { type: 'metal', name: 'LOWER ANVIL', info: 'Smaller, colder, and worked out. The rigs are still bolted to it.' },
    { type: 'desert', name: 'BRINE', info: 'Salt flats over a dead ocean. Independent claim — they answer hails, eventually.' },
    { type: 'ringedGiant', name: 'ODESSA MAJOR', info: 'The chain’s landmark: a banded giant inside a ring system you can read from the inner orbits.' },
    { type: 'tundra', name: 'HARROW', info: 'Ice to the fortieth parallel, olive steppe between. Breathable through a mask, which is more than the route offers.' },
    { type: 'ice', name: 'ODESSA VII', info: 'Frozen and unclaimed. Someone has been parking something here.' },
  ],
  beltN: 22, // the reason anyone comes: the richest belt on the chart
  comets: 2,
  stations: [
    { id: 'odessa_transfer', name: 'ODESSA TRANSFER', near: 4, scale: 3.6, info: 'Ore transfer and a bonded warehouse. Fuel is cheap here and nobody logs your registry twice.' },
  ],
  derelicts: [
    { id: 'anvil_hauler', name: 'ORE HAULER — UNNAMED', near: 1, info: 'Loaded, holed, and still under thrust when it stopped. The cargo is intact. That should worry you.' },
  ],
});

export const THRESHER = generateSystem({
  id: 'thresher',
  name: 'THRESHER',
  starType: 'O',
  starName: 'THRESHER',
  seed: 0x74e53a,
  group: 'SPUR',
  danger: 'EXTREME',
  blurb: 'A blue supergiant burning through its own lifetime. Keth forward yard. Hull rads climb the moment you arrive.',
  planetSpec: [
    { type: 'carbon', name: 'THRESHER I', info: 'Graphite and diamond, blasted bare. The star took its atmosphere before anything could use it.' },
    { type: 'carbon', name: 'THRESHER II', info: 'Tar seas gone hard as rock. The Keth cut blocks out of it and haul them off.' },
    { type: 'metal', name: 'SHEAR', info: 'What survived being this close: a bare core, mirror-bright on the sunward face.' },
    { type: 'lava', name: 'THRESHER IV', info: 'Still molten after four billion years, because it has never once been allowed to cool.' },
    { type: 'ringedGiant', name: 'THE MILL', info: 'Its rings are being stripped by stellar wind — a ring system with a visible tail.' },
  ],
  belt: false,
  comets: 0, // nothing icy survives this star
  derelicts: [
    { id: 'thresher_survey', name: 'KSV BRIGHT ARREARS', near: 2, info: 'A Kestrel survey hull, paint burned to bare metal. Registry predates the Aethon’s refit.' },
  ],
});

export const AMBER_WELL = generateSystem({
  id: 'amber_well',
  name: 'AMBER WELL',
  starType: 'RG',
  starName: 'AMBER WELL',
  seed: 0xa3be11,
  group: 'SPUR',
  danger: 'HIGH',
  blurb: 'A red giant that already ate its inner worlds. What is left orbits through the debris of what is gone.',
  planetSpec: [
    { type: 'metal', name: 'THE REMNANT', info: 'The core of a world the star swallowed. It is still out here, still orbiting, mantle gone.' },
    { type: 'lava', name: 'AMBER WELL II', info: 'Resurfaced by the star’s expansion. Geologically, it is younger than the survey charts.' },
    { type: 'tundra', name: 'LATE SPRING', info: 'Frozen for four billion years until the star grew. It has had a habitable zone for ninety thousand of them.' },
    { type: 'ocean', name: 'THAW', info: 'Meltwater ocean over what was a nitrogen ice cap. Nothing lives in it yet. Yet.' },
    { type: 'ringedIceGiant', name: 'AMBER WELL V', info: 'Its ring is new — shepherded debris from whatever the star tore apart on the way out.' },
    { type: 'dwarf', name: 'AMBER WELL VI', info: 'Outer ice, sublimating steadily. It will not be here in a million years.' },
  ],
  beltAt: 0.9, // the shredded inner system, far inside where a belt should be
  beltN: 26,
  beltSpread: 0.3,
  comets: 3,
  stations: [
    { id: 'well_watch', name: 'WELL WATCH', near: 3, scale: 3.0, info: 'A company observation post with a skeleton rotation. They watch the star. The star is closer every year.' },
  ],
});

export const COLD_HARBOUR = generateSystem({
  id: 'cold_harbour',
  name: 'COLD HARBOUR',
  starType: 'BD',
  starName: 'COLD HARBOUR',
  seed: 0xc01dba,
  group: 'SPUR',
  danger: 'HIGH',
  blurb: 'A star that never lit. Four dark worlds under a dull maroon glow, and a Drift breaking yard among them.',
  planetSpec: [
    { type: 'ice', name: 'HARBOUR I', info: 'Close enough to the failed star to see it as a disc. Still cold enough to hold nitrogen ice.' },
    {
      type: 'ringedIceGiant', name: 'THE LANTERN',
      info: 'The brightest thing in the system after the dwarf, and it only reflects. Its rings are hard-edged and thin.',
      moons: [
        { type: 'sulfurMoon', name: 'KETTLE', info: 'Squeezed by the giant until it split. Sulphur plains, repainted by eruption faster than any chart holds.' },
        { type: 'iceMoon', name: 'KETTLE MINOR', info: 'Cracked ice shell. The fractures run parallel, which ice does not do on its own.' },
        { type: 'moon', name: 'THE HOOK', info: 'Captured, retrograde, and hollow on the scan return. Nobody has published on that.' },
      ],
    },
    { type: 'ice', name: 'HARBOUR III', info: 'Drift hulls are parked in this orbit in rows. Rows imply a filing system.' },
    { type: 'carbon', name: 'SOOT', info: 'Black even by this system’s standards. The albedo is close to zero.' },
    { type: 'dwarf', name: 'HARBOUR V', info: 'The last rounded body. Beyond it the dwarf gives no light at all.' },
  ],
  // No belt. A failed star's disc never had the mass or the stirring to leave one,
  // and the emptiness is the point: everything you see out here was PUT here.
  belt: false,
  comets: 2,
  derelicts: [
    { id: 'harbour_breaker', name: 'BREAKING YARD HULL 9', near: 2, info: 'Cut open lengthways, bulkhead by bulkhead, and stacked. The cuts are clean. Something did this patiently.' },
    { id: 'harbour_ksv', name: 'KSV SEVEN BELLS', near: 3, info: 'Kestrel registry, reported lost in Vega Reach eleven years ago. It is here instead.' },
  ],
});

export const THE_DRUM = generateSystem({
  id: 'the_drum',
  name: 'THE DRUM',
  starType: 'NS',
  starName: 'THE DRUM',
  seed: 0xd2007,
  group: 'SPUR',
  danger: 'EXTREME',
  blurb: 'A neutron star, spinning eleven times a second. Every instrument on the ship hears it. Nothing here is alive.',
  planetSpec: [
    { type: 'metal', name: 'DRUM I', info: 'A core, scoured to bare metal by the supernova that made this star. It should not still be in orbit. It is.' },
    { type: 'carbon', name: 'DRUM II', info: 'Carbon crust fused to glass on the star-facing side. The glass has the beam pattern burned into it.' },
    { type: 'planetoid', name: 'THE SHARD', info: 'A fragment of something larger, on an orbit nothing natural would take.' },
  ],
  beltN: 19,
  beltSpread: 0.24,
  comets: 0,
  rogue: true,
  stations: [
    { id: 'drum_relic', name: 'THE METRONOME', near: 1, scale: 5.5, refuel: false, info: 'A structure locked to the pulsar’s rotation, one face always toward the beam. It has been counting since before the star collapsed.' },
  ],
  derelicts: [
    { id: 'drum_hulk', name: 'UNIDENTIFIED HULK', near: 0, info: 'Not human, not Keth, not Vrenn, not Drift. A fifth hull design. No transponder has ever answered from it.' },
  ],
});

/**
 * Ordered chart: warp UI + galaxy state use this. The commissioned route first,
 * in survey order, then the off-route spurs — WarpPanel groups on `group`.
 */
/**
 * SIX MORE, 0.48.0 — the second ring of spurs.
 *
 * The commissioned route is five systems and the first spur ring added five
 * more, which was enough to make warp a decision. Sixteen is enough to make it
 * a CAREER: there is now more chart than one commission can survey, so where
 * you go stops being a sequence and starts being a choice with an opportunity
 * cost attached to it.
 *
 * Every one of them is here to show off something the route could not. Four
 * carry the new surface archetypes (ash, dried seabed, banded iron, crystal),
 * one is built around a tide-locked world, and one is a young system where the
 * planets have not finished forming.
 */
export const KILN = generateSystem({
  id: 'kiln',
  name: 'KILN',
  starType: 'K',
  starName: 'KILN',
  seed: 0x4b11,
  group: 'SPUR',
  danger: 'MODERATE',
  blurb: 'A quiet orange star with a violent past. Three of its worlds burned and the fourth is still deciding.',
  planetSpec: [
    { type: 'tidalLocked', name: 'KILN I', info: 'One face at eleven hundred degrees, the other at minus two hundred. The survey team works the terminator or does not work.' },
    { type: 'ashWorld', name: 'CINDERFALL', info: 'Ash forty metres deep over a crust that stopped moving a hundred million years ago. Nothing here is dangerous. Nothing here is anything.' },
    { type: 'ashWorld', name: 'KILN III', info: 'The younger sibling. Some of the cones are still warm at the throat.' },
    { type: 'rocky', name: 'KILN IV', info: 'Ordinary rock, which in this system is worth remarking on.' },
    { type: 'iceGiant', name: 'KILN V', info: 'Methane blue and utterly uninterested in the rest of the system.' },
  ],
  beltN: 12,
  comets: 2,
  stations: [
    { id: 'kiln_ashworks', name: 'ASHWORKS REFINERY', near: 1, structure: 'refinery', info: 'Sifts the ash for the metals that fell out of the eruptions. Company-run, thinly staffed, always hiring.' },
  ],
  derelicts: [
    { id: 'kiln_survey', name: 'SURVEY TENDER RAIL', near: 0, info: 'Went down on the day side and was recovered to orbit. Nobody has opened the forward compartments.' },
  ],
});

export const SALT_MERIDIAN = generateSystem({
  id: 'salt_meridian',
  name: 'SALT MERIDIAN',
  starType: 'F',
  starName: 'SALT MERIDIAN',
  seed: 0x5a17,
  group: 'SPUR',
  danger: 'LOW',
  blurb: 'A bright star and two worlds that used to have oceans. The tide lines are still there. The water is not.',
  planetSpec: [
    { type: 'saltWorld', name: 'THE SHALLOWS', info: 'A seabed you can walk for a week. Salt polygons, evaporite terraces, and things in the strata that were swimming.' },
    { type: 'saltWorld', name: 'MERIDIAN II', info: 'Drier and older. The tide line is eighty metres up a cliff with nothing beneath it.' },
    { type: 'desert', name: 'MERIDIAN III', info: 'Never had water. Somehow the least interesting world in a system defined by its absence.' },
    { type: 'ringedGiant', name: 'THE BASIN', info: 'A ringed giant whose rings are, on assay, mostly salt.' },
    { type: 'ice', name: 'MERIDIAN V', info: 'Frozen out beyond the line. The only water left in the system and it is not going anywhere.' },
  ],
  beltN: 8,
  comets: 3,
  stations: [
    { id: 'salt_pans', name: 'THE PANS', near: 0, structure: 'trade_post', info: 'A dozen prefabs on the seabed and a lift to orbit. They sell salt, samples and stories, in that order of honesty.' },
  ],
});

export const RUSTBELT = generateSystem({
  id: 'rustbelt',
  name: 'RUSTBELT',
  starType: 'M',
  starName: 'RUSTBELT',
  seed: 0x2057,
  group: 'SPUR',
  danger: 'MODERATE',
  blurb: 'Iron. All of it. A dim star and five worlds whose crusts are banded ore from pole to pole.',
  planetSpec: [
    { type: 'ironWorld', name: 'RUSTBELT I', info: 'Banded iron in rust and grey, a thousand layers deep, each one a summer that ended.' },
    { type: 'ironWorld', name: 'THE SEAM', info: 'The richest assay on the chart. Every hauler in three systems knows the name and half of them have been turned away.' },
    { type: 'metal', name: 'RUSTBELT III', info: 'Stripped to bare core by something. The something is not recorded.' },
    { type: 'crystalWorld', name: 'GLASSWORKS', info: 'Silicate needles standing off an iron plain. The two should not be in the same system.' },
    { type: 'iceGiant', name: 'RUSTBELT V', info: 'Cold, blue, and the only thing here that is not the colour of oxidation.' },
  ],
  beltN: 22,
  beltSpread: 0.2,
  stations: [
    { id: 'rust_seam', name: 'SEAM DOCKYARD', near: 1, structure: 'shipyard', info: 'Builds hulls out of what it digs. The plate is good and the paint is an afterthought.' },
    { id: 'rust_assay', name: 'ASSAY OFFICE 4', near: 0, structure: 'trade_post', info: 'Weighs, tests and buys. Argues about all three.' },
  ],
  derelicts: [
    { id: 'rust_hauler', name: 'ORE HAULER SEVENTY', near: 2, info: 'Loaded, holed and abandoned. The cargo is still aboard and still worth more than the ship.' },
  ],
});

export const THE_ORCHARD = generateSystem({
  id: 'the_orchard',
  name: 'THE ORCHARD',
  starType: 'A',
  starName: 'THE ORCHARD',
  seed: 0x0acd,
  group: 'SPUR',
  danger: 'HIGH',
  blurb: 'Crystal grows here. Nobody has established whether that is a figure of speech.',
  planetSpec: [
    { type: 'crystalWorld', name: 'ORCHARD I', info: 'A shard forest taller than the ship, all leaning one way. Nobody has found the wind that did it.' },
    { type: 'crystalWorld', name: 'THE STAND', info: 'The shards here have growth rings. This is in the survey record and has never been explained.' },
    { type: 'rocky', name: 'ORCHARD III', info: 'Bare rock, and the only place in the system a suit does not ring.' },
    { type: 'carbon', name: 'SOOTFALL', info: 'Graphite crust and diamond in the fracture faces. The Orchard\'s poor relation.' },
    { type: 'ringedIceGiant', name: 'ORCHARD V', info: 'Its rings are shards. They came from somewhere.' },
  ],
  beltN: 14,
  comets: 1,
  stations: [
    { id: 'orchard_watch', name: 'ORCHARD WATCH', near: 2, structure: 'relay', refuel: true, info: 'A listening post that has been listening for nineteen years. The log is the reason the danger rating is what it is.' },
  ],
  derelicts: [
    { id: 'orchard_lost', name: 'KSV FALLOW', near: 1, info: 'A Kestrel survey cutter, intact, powered down, hull unbreached. The crew are not aboard and the airlock was sealed from outside.' },
  ],
});

export const THE_FORGE = generateSystem({
  id: 'the_forge',
  name: 'THE FORGE',
  starType: 'RG',
  starName: 'THE FORGE',
  seed: 0xf02e,
  group: 'SPUR',
  danger: 'HIGH',
  blurb: 'A red giant eating its inner system. Two worlds are already gone. The third is a matter of decades.',
  planetSpec: [
    { type: 'lava', name: 'FORGE I', info: 'What is left. The star fills a third of its sky and the surface renews itself weekly.' },
    { type: 'ashWorld', name: 'FORGE II', info: 'Ash and glass. It was a rocky world before the star swelled.' },
    { type: 'toxic', name: 'FORGE III', info: 'Boiling off. Give it fifty years and there will be nothing here but a core.' },
    { type: 'superearth', name: 'ANVIL', info: 'Far enough out to survive it. Heavy, hot, and the only real estate in the system with a future.' },
    { type: 'gasGiant', name: 'FORGE V', info: 'Losing its outer envelope to the star in a visible stream. From orbit you can watch it happen.' },
  ],
  beltN: 6,
  comets: 4,
  stations: [
    { id: 'forge_anvil', name: 'ANVIL STATION', near: 3, structure: 'trade_post', info: 'Built to outlast the system. Thick shielding, deep stores, and a bar with no windows.' },
  ],
  derelicts: [
    { id: 'forge_burnt', name: 'BURNT TENDER', near: 0, info: 'Went too close. The sunward half is slag; the aft compartments are intact and cold.' },
  ],
});

export const NURSERY = generateSystem({
  id: 'nursery',
  name: 'NURSERY',
  starType: 'F',
  starName: 'NURSERY',
  seed: 0x0e51,
  group: 'SPUR',
  danger: 'MODERATE',
  blurb: 'A young system. The planets are not finished and the disc is still full of the material they were made from.',
  planetSpec: [
    { type: 'lava', name: 'NURSERY I', info: 'Still molten from accretion rather than from the star. It has not had time to cool.' },
    { type: 'ashWorld', name: 'NURSERY II', info: 'A crust forming over a magma ocean. It will be a rocky world in about eighty million years.' },
    { type: 'ocean', name: 'THE SHOAL', info: 'Water, warmth and nothing in it. The chemistry is right and the clock has not run long enough.' },
    { type: 'superearth', name: 'NURSERY IV', info: 'Enormous and still gathering. Its ring is not a ring, it is a queue.' },
    { type: 'ringedGiant', name: 'NURSERY V', info: 'A giant with a moon system that is visibly incomplete.' },
  ],
  beltN: 28,
  beltSpread: 0.32,
  comets: 6,
  stations: [
    { id: 'nursery_watch', name: 'ACCRETION WATCH', near: 2, structure: 'relay', refuel: true, info: 'Science station, permanently understaffed, permanently thrilled. They will trade for any sample from the disc.' },
  ],
});

export const SYSTEMS = [
  SOL_PRIME, VEGA_REACH, REDFALL, TWIN_SUNS, THE_PALE,
  ODESSA_CHAIN, AMBER_WELL, COLD_HARBOUR, THRESHER, THE_DRUM,
  KILN, SALT_MERIDIAN, RUSTBELT, THE_ORCHARD, THE_FORGE, NURSERY,
];

// Park Sol Prime's freighter a short hop off the colony world, on the approach
// lane the player spawns on, so there's a hull to see near the start.
(() => {
  const colony = SOL_PRIME.bodies.find((b) => b.colony) ?? SOL_PRIME.bodies[0];
  const s = SOL_PRIME.ships.find((x) => x.id === 'ksv_gull');
  if (colony && s) {
    s.pos = [colony.pos[0] + colony.radius * 4 + 900, colony.pos[1] + 40, colony.pos[2] - colony.radius * 3];
  }
})();
