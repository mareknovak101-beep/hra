/**
 * ItemRegistry — every item in the game (context/04 §3 schema). Families are
 * built by small generators so the registry stays dense but consistent:
 * consumables (food/drink/med/fuel/O2), materials (ores in three grades,
 * crystals, salvage), components, tools, weapons, artifacts, data chips,
 * trade goods and personal effects. Each item: { id, name, category,
 * subCategory, weight kg, volume slots, value cr, stackable, maxStack,
 * description, onUse?, effect?, rarity, found[] }.
 */

const R = {};
const add = (item) => { R[item.id] = item; return item; };

const def = (id, name, category, subCategory, weight, volume, value, rarity, description, extra = {}) =>
  add({ id, name, category, subCategory, weight, volume, value, rarity, description,
    stackable: extra.stackable ?? true, maxStack: extra.maxStack ?? 10,
    onUse: extra.onUse, effect: extra.effect, found: extra.found ?? ['cargo'] });

// -- food (restores hunger) ---------------------------------------------------
const FOODS = [
  ['ration_protein', 'Protein Ration', 22, 'Grey block, grey taste. Keeps you alive.', 28],
  ['ration_grain', 'Grain Ration', 16, 'Compressed wheat brick stamped KESTREL.', 24],
  ['ration_stew', 'Stew Pack (Self-Heat)', 30, 'Pull the tab, wait, try not to read the ingredients.', 34],
  ['ration_noodle', 'Noodle Brick', 14, 'Dehydrated noodles. The galley kettle remembers.', 22],
  ['ration_fish', 'Preserved Fish Tin', 26, 'Colony-side mackerel. Someone hoards these.', 30],
  ['ration_fruit', 'Fruit Leather Roll', 18, 'Aethon orchard surplus, rolled thin.', 20],
  ['ration_curry', 'Curry Pack', 28, 'The one everyone trades for.', 36],
  ['ration_bar', 'Field Bar', 12, 'Dense, sweet, survives vacuum and neglect.', 16],
];
for (const [id, name, val, desc, hunger] of FOODS) {
  def(id, name, 'consumable', 'food', 0.4, 0.2, val, 'common', desc,
    { onUse: 'eat', effect: { hunger }, maxStack: 20, found: ['galley', 'cargo', 'trade'] });
}

// -- drink (restores thirst) --------------------------------------------------
const DRINKS = [
  ['water_pouch', 'Water Pouch', 8, 'Recycled, triple-filtered, tastes of the filter.', 30],
  ['water_can', 'Water Canister', 20, 'Five litres, dented, trustworthy.', 60],
  ['coffee_pack', 'Coffee Pack', 15, 'Freeze-dried. The reason the crew got up.', 18],
  ['tea_tin', 'Tea Tin', 14, 'Mercer\'s. Was Mercer\'s.', 16],
  ['electrolyte_mix', 'Electrolyte Mix', 18, 'For after EVA. Salt-sweet.', 34],
  ['juice_box', 'Juice Concentrate', 12, 'Aethon citrus, mostly sugar.', 22],
];
for (const [id, name, val, desc, thirst] of DRINKS) {
  def(id, name, 'consumable', 'drink', 0.5, 0.2, val, 'common', desc,
    { onUse: 'drink', effect: { thirst }, maxStack: 20, found: ['galley', 'cargo', 'trade'] });
}

// -- medical ------------------------------------------------------------------
const MEDS = [
  ['bandage', 'Sterile Bandage', 14, 'Pressure wrap. Stops the small leaks.', { health: 15 }, 'common'],
  ['medkit_field', 'Field Medkit', 55, 'Sutures, sealant, stims. The real fix.', { health: 45 }, 'uncommon'],
  ['stim_shot', 'Stim Shot', 40, 'Wakes the body up. The crash comes later.', { health: 8, fatigue: 30 }, 'uncommon'],
  ['radaway_dose', 'Chelation Dose', 60, 'Binds the hot particles. Drink water after.', { radiation: -35 }, 'uncommon'],
  ['analgesic', 'Analgesic Strip', 18, 'Dissolves under the tongue.', { health: 8 }, 'common'],
  ['burn_gel', 'Burn Gel', 26, 'For reactor-room lessons.', { health: 20 }, 'common'],
  ['antibiotic', 'Broad Antibiotic', 44, 'One course. Do not split it.', { health: 25 }, 'uncommon'],
  ['trauma_kit', 'Trauma Kit', 120, 'Everything the med bay has, in a bag.', { health: 80 }, 'rare'],
];
for (const [id, name, val, desc, effect, rarity] of MEDS) {
  def(id, name, 'consumable', 'medical', 0.6, 0.3, val, rarity, desc,
    { onUse: 'med', effect, maxStack: 8, found: ['medbay', 'stations', 'trade'] });
}

// -- ship consumables ---------------------------------------------------------
def('fuel_cell_standard', 'Standard Fuel Cell', 'consumable', 'fuel', 2.4, 0.8, 85, 'common',
  'Standard deuterium fuel cell. Powers sub-light drive systems.',
  { onUse: 'refuel_ship', effect: { fuel: 50 }, maxStack: 20, found: ['stations', 'cargo', 'trade', 'derelict'] });
def('fuel_cell_dense', 'Dense Fuel Cell', 'consumable', 'fuel', 3.1, 0.8, 160, 'uncommon',
  'Double-packed deuterium lattice. Handles warm.',
  { onUse: 'refuel_ship', effect: { fuel: 100 }, maxStack: 12, found: ['stations', 'trade'] });
def('warp_cell', 'Warp Fuel Cell', 'consumable', 'fuel', 4.2, 1.0, 420, 'rare',
  'Exotic condensate for the jump drive. Rare, and priced like it.',
  { onUse: 'refuel_warp', effect: { warpFuel: 25 }, maxStack: 8, found: ['stations', 'trade', 'derelict'] });
def('o2_canister', 'O₂ Canister', 'consumable', 'oxygen', 1.8, 0.5, 45, 'common',
  'Compressed breathing oxygen, suit-valve fitting.',
  { onUse: 'breathe', effect: { oxygen: 40 }, maxStack: 12, found: ['stations', 'cargo', 'derelict'] });
def('o2_candle', 'Oxygen Candle', 'consumable', 'oxygen', 2.6, 0.6, 90, 'uncommon',
  'Chemical oxygen generator. Burns hot, breathes long.',
  { onUse: 'breathe', effect: { oxygen: 100 }, maxStack: 6, found: ['stations', 'derelict'] });
def('shield_cell', 'Shield Cell', 'consumable', 'ship', 1.6, 0.5, 130, 'uncommon',
  'Capacitor brick for the deflector bank.',
  { onUse: 'ship_shield', effect: { shield: 40 }, maxStack: 10, found: ['stations', 'trade'] });
def('hull_plate', 'Hull Patch Plate', 'consumable', 'ship', 6.5, 1.2, 110, 'common',
  'Self-tapping micrometeorite patch. Weld to finish.',
  { onUse: 'ship_hull', effect: { hull: 15 }, maxStack: 10, found: ['stations', 'cargo', 'derelict'] });
def('power_cell', 'Power Cell', 'consumable', 'ship', 1.2, 0.4, 70, 'common',
  'Universal energy cell. Fits half the tools aboard.',
  { onUse: 'ship_power', effect: { power: 30 }, maxStack: 16, found: ['stations', 'cargo', 'trade', 'derelict'] });

// -- materials: ores in three grades -----------------------------------------
const ORES = [
  ['iron', 'Iron', 12, 'common'], ['copper', 'Copper', 18, 'common'],
  ['titanium', 'Titanium', 45, 'uncommon'], ['nickel', 'Nickel', 16, 'common'],
  ['cobalt', 'Cobalt', 38, 'uncommon'], ['tungsten', 'Tungsten', 56, 'uncommon'],
  ['iridium', 'Iridium', 140, 'rare'], ['thorium', 'Thorium', 170, 'rare'],
];
const GRADES = [['raw', 'Raw', 1, 'Ore straight off the cutter head.'],
  ['refined', 'Refined', 2.6, 'Smelted and slagged-off.'],
  ['pure', 'Pure', 6.2, 'Zone-refined ingot, assay-stamped.']];
for (const [mid, mname, base, rarity] of ORES) {
  for (const [gid, gname, mult, gdesc] of GRADES) {
    def(`ore_${mid}_${gid}`, `${gname} ${mname}`, 'material', 'ore', 2.2, 0.5, Math.round(base * mult), rarity,
      `${gdesc}`, { maxStack: 30, found: ['mining', 'cargo', 'trade'] });
  }
}

// -- materials: crystals ------------------------------------------------------
const CRYSTALS = [
  ['quartz_var', 'Vega Quartz', 60, 'uncommon', 'Grown in a furnace star\'s light.'],
  ['cryo_lattice', 'Cryo Lattice', 85, 'uncommon', 'Only forms below 40 kelvin.'],
  ['storm_glass', 'Storm Glass', 120, 'rare', 'Fulgurite from Thunderhead\'s eternal lightning.'],
  ['red_beryl', 'Redfall Beryl', 95, 'rare', 'The Vrenn cut these for their barges.'],
  ['void_opal', 'Void Opal', 260, 'rare', 'Found only in the dark between orbits.'],
  ['drift_shard', 'Drift Core Shard', 400, 'unique', 'A splinter of machine-race lattice. It is not quite inert.'],
];
for (const [id, name, val, rarity, desc] of CRYSTALS) {
  def(`crystal_${id}`, name, 'material', 'crystal', 0.8, 0.3, val, rarity, desc,
    { maxStack: 12, found: ['mining', 'derelict', 'trade'] });
}

// -- materials: salvage -------------------------------------------------------
const SALVAGE = [
  ['wire_spool', 'Wire Spool', 10, 'Fifty metres of shielded conductor.'],
  ['servo_motor', 'Servo Motor', 26, 'Still turns. Mostly.'],
  ['coolant_pump', 'Coolant Pump', 34, 'Impeller intact, seals suspect.'],
  ['pressure_valve', 'Pressure Valve', 18, 'Rated far beyond anything aboard.'],
  ['plating_scrap', 'Plating Scrap', 8, 'Somebody\'s hull. Now yours.'],
  ['optic_bundle', 'Optic Bundle', 22, 'Fibre trunk line, cut clean.'],
  ['gasket_kit', 'Gasket Kit', 12, 'The unglamorous heart of spaceflight.'],
  ['heat_sink', 'Heat Sink Fin', 15, 'Scorched but straight.'],
  ['mag_coil', 'Magnetic Coil', 40, 'Windings test within tolerance.'],
  ['gyro_core', 'Gyro Core', 55, 'Precession is a little off. A little.'],
  ['filter_stack', 'Air Filter Stack', 20, 'One careful owner, one careless one.'],
  ['bearing_set', 'Bearing Set', 14, 'Sealed units, still in grease.'],
];
for (const [id, name, val, desc] of SALVAGE) {
  def(`salvage_${id}`, name, 'material', 'salvage', 1.8, 0.5, val, 'common', desc,
    { maxStack: 20, found: ['derelict', 'cargo', 'stations'] });
}

// -- components (crafting/repair) --------------------------------------------
const COMPONENTS = [
  ['capacitor_bank', 'Capacitor Bank', 48, 'uncommon', 'Holds a grudge and a charge.'],
  ['relay_module', 'Relay Module', 30, 'common', 'Clicks when it switches. Reassuring.'],
  ['flow_injector', 'Flow Injector', 62, 'uncommon', 'Meters deuterium to the drive.'],
  ['nav_gyro', 'Nav Gyro Assembly', 88, 'uncommon', 'The ship\'s inner ear.'],
  ['field_coil', 'Deflector Field Coil', 95, 'uncommon', 'Bends the small stuff away.'],
  ['co2_scrubber', 'CO₂ Scrubber Cartridge', 42, 'common', 'Life support\'s lungs.'],
  ['heat_exchanger', 'Heat Exchanger Core', 70, 'uncommon', 'Moves the reactor\'s temper outboard.'],
  ['sensor_array', 'Sensor Array Head', 110, 'rare', 'Sees further than the glass does.'],
  ['drive_bearing', 'Drive Shaft Bearing', 56, 'uncommon', 'Spin without wobble.'],
  ['fuse_block', 'Fuse Block', 16, 'common', 'Dies so the bus doesn\'t.'],
  ['pump_assembly', 'Pump Assembly', 52, 'uncommon', 'Fuel, water, coolant — it doesn\'t care.'],
  ['airlock_seal', 'Airlock Seal Ring', 38, 'common', 'The line between in and out.'],
  ['cpu_board', 'Processor Board', 130, 'rare', 'Mil-spec, radiation-hardened.'],
  ['ancient_servo', 'Ancient Servo', 300, 'rare', 'Not human work. Still under warranty, somehow.'],
];
for (const [id, name, val, rarity, desc] of COMPONENTS) {
  def(`comp_${id}`, name, 'component', 'ship', 1.4, 0.4, val, rarity, desc,
    { maxStack: 10, found: ['stations', 'derelict', 'trade'] });
}

// -- tools --------------------------------------------------------------------
const TOOLS = [
  ['welder', 'Plasma Welder', 90, 'Joins metal and closes hulls.'],
  ['cutter', 'Rotary Cutter', 75, 'Opens what the welder closed.'],
  ['multimeter', 'Circuit Probe', 35, 'Tells you which wire lied.'],
  ['wrench_set', 'Torque Wrench Set', 28, 'Metric. Always metric.'],
  ['prybar', 'Prybar', 20, 'The universal key.'],
  ['scanner_hand', 'Hand Scanner', 150, 'Reads composition through a bulkhead.'],
  ['patch_gun', 'Sealant Gun', 55, 'Foams shut the whistling holes.'],
  ['flash_beacon', 'Flash Beacon', 24, 'Drops a light where you\'ll need to find your way back.'],
  ['tow_line', 'Mag Tow Line', 46, 'Two hundred metres of trust.'],
  ['sample_drill', 'Core Sample Drill', 130, 'For asking planets questions.'],
];
for (const [id, name, val, desc] of TOOLS) {
  def(`tool_${id}`, name, 'tool', 'hand', 2.8, 0.9, val, 'uncommon', desc,
    { stackable: false, maxStack: 1, found: ['workshop', 'stations', 'trade'] });
}

// -- weapons + ammo (placeholders until Phase 6 combat) ----------------------
def('weapon_pistol', 'Kestrel Sidearm', 'weapon', 'pistol', 1.1, 0.8, 220, 'uncommon',
  'Company-issue slug pistol. Six in the magazine, one question each.',
  { stackable: false, maxStack: 1, found: ['stations', 'derelict'] });
def('weapon_carbine', 'Salvage Carbine', 'weapon', 'rifle', 3.4, 1.6, 520, 'rare',
  'Rebuilt from three different rifles. All three worked.',
  { stackable: false, maxStack: 1, found: ['derelict', 'trade'] });
def('weapon_cutter', 'Arc Cutter', 'weapon', 'industrial', 4.0, 1.5, 380, 'uncommon',
  'A mining tool, technically.', { stackable: false, maxStack: 1, found: ['workshop', 'stations'] });
def('ammo_slug', 'Slug Magazine', 'weapon', 'ammo', 0.5, 0.2, 30, 'common',
  'Twelve caseless slugs.', { maxStack: 20, found: ['stations', 'derelict', 'trade'] });
def('ammo_cell', 'Arc Cell', 'weapon', 'ammo', 0.4, 0.2, 45, 'common',
  'Charge for the arc cutter.', { maxStack: 20, found: ['stations', 'trade'] });

// -- artifacts (Twin Suns / Pale lore) ---------------------------------------
const ARTIFACTS = [
  ['fragment_a', 'Etched Fragment', 350, 'A metal shard covered in script that predates the binary suns.'],
  ['fragment_b', 'Warm Tessera', 420, 'A tile that has stayed at body heat for ten thousand years.'],
  ['lens_relic', 'Relic Lens', 600, 'It focuses light that isn\'t there.'],
  ['song_cylinder', 'Song Cylinder', 750, 'Rotate it and the air hums two notes. Always the same two.'],
  ['null_cube', 'Null Cube', 900, 'Scanners read its mass as zero. Your hands disagree.'],
  ['archive_key', 'Archive Access Sliver', 1200, 'It wants to go home to the Pale.'],
  ['drift_node', 'Drift Node (Dormant)', 1000, 'A crystalline machine cell. Do not warm it.'],
  ['star_chart_old', 'Pre-Human Star Chart', 800, 'Five systems marked. One of them is circled.'],
];
for (const [id, name, val, desc] of ARTIFACTS) {
  def(`artifact_${id}`, name, 'artifact', 'ancient', 1.0, 0.6, val, 'unique', desc,
    { stackable: false, maxStack: 1, found: ['derelict', 'ruins'] });
}

// -- data chips (readable lore, Phase 7 JournalUI) ---------------------------
for (let i = 1; i <= 16; i++) {
  def(`datachip_${String(i).padStart(2, '0')}`, `Log Chip ${String(i).padStart(2, '0')}`, 'data', 'log',
    0.05, 0.1, 40, i > 11 ? 'rare' : 'common',
    'A crew log chip. The journal reader can play it back.',
    { maxStack: 1, stackable: false, found: ['derelict', 'cargo', 'stations'] });
}

// -- trade goods --------------------------------------------------------------
const TRADE = [
  ['textiles', 'Colony Textiles', 60, 'Aethon wool, vacuum-baled.'],
  ['spices', 'Spice Crate', 95, 'Worth more than the crate\'s weight in fuel.'],
  ['machine_parts', 'Machine Parts', 80, 'Standard couplings, always in demand.'],
  ['seed_stock', 'Seed Stock', 120, 'Certified viable. Life in a box.'],
  ['vrenn_resin', 'Vrenn Resin', 180, 'Smells of rain. The Vrenn use it for everything.'],
  ['vrenn_silk', 'Vrenn Weave', 260, 'Grown, not spun.'],
  ['keth_alloy', 'Keth Alloy Scrap', 210, 'Black, sharp, stronger than it should be.'],
  ['medical_supplies', 'Medical Supplies', 140, 'Sealed sterile cases.'],
  ['lux_spirits', 'Meridian Spirits', 110, 'The bar that never closes bottles its own.'],
  ['data_cores', 'Blank Data Cores', 70, 'Petabytes of nothing, yet.'],
  ['bio_samples', 'Verdane Bio Samples', 300, 'The canopy moves when nothing pushes it. Sample it anyway.'],
  ['ice_cores', 'Pale Ice Cores', 240, 'Ice older than the star it orbits.'],
];
for (const [id, name, val, desc] of TRADE) {
  def(`trade_${id}`, name, 'trade', 'goods', 4.5, 1.2, val, 'uncommon', desc,
    { maxStack: 10, found: ['stations', 'trade', 'cargo'] });
}

// -- personal effects (mood items) -------------------------------------------
const PERSONAL = [
  ['photo_crew', 'Crew Photograph', 'Six people on a dock. You are the one on the left.'],
  ['deck_cards', 'Deck of Cards', 'Fifty-one cards. The ace of spades is a torn ration label.'],
  ['harmonica', 'Harmonica', 'Someone practised. The vents remember.'],
  ['ring_plain', 'Plain Ring', 'Left in a locker. Engraved: COME HOME.'],
  ['novel_pulp', 'Pulp Novel', '"RED DUST RISING" — the spine is cracked at chapter nine.'],
  ['dice_pair', 'Machined Dice', 'Turned from reactor shielding offcuts. Slightly loaded.'],
  ['flask_dented', 'Dented Flask', 'Empty. It has been empty for a long time.'],
  ['tags_id', 'ID Tags', 'MERCER, T. — KESTREL EX&S. Blood type O.'],
  ['toy_kestrel', 'Toy Kestrel', 'A carved bird. The wings fold.'],
  ['letter_unsent', 'Unsent Letter', 'Addressed, sealed, stamped. Never posted.'],
  ['patch_mission', 'Mission Patch', 'HSV AETHON — FIRST SURVEY. Gold thread, worn.'],
  ['key_nowhere', 'Key to Nowhere', 'A door key. No door aboard fits it.'],
];
for (const [id, name, desc] of PERSONAL) {
  def(`personal_${id}`, name, 'personal', 'effects', 0.2, 0.1, 5, 'common', desc,
    { stackable: false, maxStack: 1, found: ['lockers', 'bunks', 'derelict'] });
}

// -- refined alloys (smelted from ore pairs — crafting feedstock) --------------
const ALLOYS = [
  ['steel_plate', 'Ship Steel Billet', 30, 'Iron and carbon, rated for hull work.'],
  ['bronze_bearing', 'Bearing Bronze', 42, 'Copper-tin, machined to sing.'],
  ['titanium_weave', 'Titanium Weave', 110, 'Woven strut mesh — strong and light.'],
  ['invar_rod', 'Invar Rod Stock', 66, 'Barely notices temperature. Ideal for optics.'],
  ['carballoy_bit', 'Carballoy Cutter Bit', 88, 'Tungsten-carbide. Eats rock politely.'],
  ['iridium_contact', 'Iridium Contact Set', 190, 'For relays that must never corrode.'],
  ['thorium_pellet', 'Thorium Fuel Pellet', 220, 'Reactor feedstock. Handle with the pole.'],
  ['duralumin_spar', 'Duralumin Spar', 74, 'Aircraft-grade, older than aircraft.'],
];
for (const [id, name, val, desc] of ALLOYS) {
  def(`alloy_${id}`, name, 'material', 'alloy', 3.2, 0.6, val, 'uncommon', desc,
    { maxStack: 16, found: ['workshop', 'stations', 'trade'] });
}

// -- electronics salvage --------------------------------------------------------
const ELECTRONICS = [
  ['crt_tube', 'CRT Tube', 34, 'Phosphor intact. They do not make these anymore. Anywhere.'],
  ['keypad', 'Sealed Keypad', 18, 'Every key still clicks.'],
  ['tape_drive', 'Tape Drive Motor', 28, 'The archive format that survives everything.'],
  ['amp_board', 'Amplifier Board', 40, 'Warm-sounding, the engineer swore.'],
  ['antenna_whip', 'Whip Antenna', 22, 'Two metres of listening.'],
  ['power_regulator', 'Power Regulator', 52, 'Smooths the reactor\'s moods.'],
  ['display_driver', 'Display Driver Card', 46, 'Draws the amber the ship thinks in.'],
  ['crypto_module', 'Crypto Module', 130, 'Company-sealed. The seal is broken.'],
];
for (const [id, name, val, desc] of ELECTRONICS) {
  def(`elec_${id}`, name, 'component', 'electronics', 0.9, 0.3, val, 'uncommon', desc,
    { maxStack: 12, found: ['derelict', 'stations', 'cargo'] });
}

// -- exotic gases (Vega Reach volatiles, bottled) --------------------------------
const GASES = [
  ['deuterium', 'Deuterium Bottle', 64, 'Drive fuel in its rawest form.'],
  ['helium3', 'Helium-3 Bottle', 150, 'Skimmed from Thunderhead\'s cloud deck.'],
  ['xenon', 'Xenon Bottle', 90, 'For thrusters that whisper.'],
  ['argon_weld', 'Welding Argon', 36, 'The welder\'s patience, compressed.'],
  ['methane_cryo', 'Cryo Methane', 44, 'Blue giant weather in a can.'],
  ['volatile_mix', 'Volatile Mix', 120, 'Unlabeled. The Keth want it back.'],
];
for (const [id, name, val, desc] of GASES) {
  def(`gas_${id}`, name, 'material', 'gas', 2.0, 0.5, val, 'uncommon', desc,
    { maxStack: 10, found: ['mining', 'stations', 'trade'] });
}

// -- faction salvage (Keth / Vrenn / Drift field pickups) ------------------------
const FACTION_SALVAGE = [
  ['keth_plate', 'Keth Hull Plate', 160, 'rare', 'Black, sharp-edged, no curves anywhere.'],
  ['keth_cell', 'Keth Energy Cell', 140, 'rare', 'Hums at a pitch that sets teeth on edge.'],
  ['keth_blade', 'Keth Boarding Blade', 210, 'rare', 'A tool for a job you hope stays theirs.'],
  ['keth_beacon', 'Keth Swarm Beacon', 180, 'rare', 'Dead. Probably dead. Keep it cold.'],
  ['vrenn_membrane', 'Vrenn Hull Membrane', 170, 'rare', 'Leathery, self-sealing, faintly warm.'],
  ['vrenn_node', 'Vrenn Light Node', 150, 'rare', 'Bioluminescent vein-cluster. Still glowing.'],
  ['vrenn_gland', 'Vrenn Resin Gland', 190, 'rare', 'The source of their everything-material.'],
  ['vrenn_chime', 'Vrenn Hail Chime', 120, 'rare', 'The sound they greet ships with.'],
  ['drift_lattice', 'Drift Lattice Fragment', 260, 'rare', 'Fractal to the limit of the loupe.'],
  ['drift_eye', 'Drift Sensor Eye', 300, 'rare', 'It tracks nothing now. It used to track everything.'],
  ['drift_limb', 'Drift Actuator Limb', 240, 'rare', 'Machined by nothing human.'],
  ['drift_wafer', 'Drift Logic Wafer', 340, 'unique', 'The Archive might read this.'],
  // Variant-hull pickups. Each one names the part that made that hull behave the
  // way it did, so a wreck tells you what killed you.
  ['keth_vane', 'Keth Thrust Vane', 230, 'rare', 'Warped by its own last turn. Nothing that light should move that hard.'],
  ['keth_optic', 'Keth Gunsight Optic', 250, 'rare', 'Ground glass, no coating, no electronics. It never needed any.'],
  ['keth_barbette', 'Keth Barbette Ring', 320, 'rare', 'A warship\'s gun mount. Heavier than the fighter it came off would have been.'],
  ['drift_emitter', 'Drift Emitter Node', 290, 'rare', 'The business end of a picket. Cold, and it stays cold.'],
  ['drift_spine', 'Drift Spar Section', 200, 'rare', 'Structural, from something built to ram and keep going.'],
  ['drift_relay', 'Drift Chorus Relay', 310, 'unique', 'They coordinate somehow. This is part of the somehow.'],
  ['vrenn_bladder', 'Vrenn Ballast Bladder', 165, 'rare', 'Half full of something that sloshes and should not.'],
  ['vrenn_scale', 'Vrenn Hull Scale', 145, 'rare', 'Overlapping plate, shed rather than cut. It grew back.'],
];
for (const [id, name, val, rarity, desc] of FACTION_SALVAGE) {
  def(`fsalvage_${id}`, name, 'material', 'faction', 1.6, 0.5, val, rarity, desc,
    { maxStack: 8, found: ['derelict', 'ruins', 'trade'] });
}

// -- planetary minerals (survey samples) -----------------------------------------
const MINERALS = [
  ['regolith', 'Regolith Sample', 10, 'Grey dust that gets into everything.'],
  ['basalt_core', 'Basalt Core', 14, 'A column of cooled fire.'],
  ['sulfur_chunk', 'Sulfur Chunk', 16, 'Volcanic yellow, rotten-egg honest.'],
  ['ice_ancient', 'Ancient Ice Core', 55, 'Bubbles of an atmosphere no one breathed.'],
  ['salt_crystal', 'Salt Pan Crystal', 12, 'A dried ocean\'s last word.'],
  ['magnetite_lump', 'Magnetite Lump', 20, 'The compass hates it.'],
  ['olivine_sand', 'Olivine Sand', 18, 'A green beach on a dead world.'],
  ['geode_whole', 'Unopened Geode', 80, 'Shake it. Something answers.'],
];
for (const [id, name, val, desc] of MINERALS) {
  def(`mineral_${id}`, name, 'material', 'mineral', 1.5, 0.4, val, 'common', desc,
    { maxStack: 20, found: ['mining', 'cargo'] });
}

// -- extra galley stock + field consumables ---------------------------------------
def('ration_soup', 'Soup Concentrate', 'consumable', 'food', 0.4, 0.2, 20, 'common',
  'Add water. Add more water than that.', { onUse: 'eat', effect: { hunger: 24 }, maxStack: 20, found: ['galley', 'trade'] });
def('ration_bread', 'Shelf Bread', 'consumable', 'food', 0.4, 0.2, 18, 'common',
  'Rated for nine years. Tastes like year eight.', { onUse: 'eat', effect: { hunger: 20 }, maxStack: 20, found: ['galley', 'cargo'] });
def('ration_sweet', 'Sugar Tab Tin', 'consumable', 'food', 0.2, 0.1, 14, 'common',
  'Morale, compressed.', { onUse: 'eat', effect: { hunger: 10, fatigue: 6 }, maxStack: 20, found: ['galley', 'lockers'] });
def('drink_broth', 'Hot Broth Pack', 'consumable', 'drink', 0.5, 0.2, 22, 'common',
  'Warms the hands first, then everything else.', { onUse: 'drink', effect: { thirst: 24, hunger: 6 }, maxStack: 20, found: ['galley'] });
def('drink_cocoa', 'Cocoa Pack', 'consumable', 'drink', 0.4, 0.2, 26, 'uncommon',
  'Saved for good days. There are fewer left than packs.', { onUse: 'drink', effect: { thirst: 18, fatigue: 8 }, maxStack: 12, found: ['galley', 'lockers'] });
def('scanner_cell', 'Scanner Battery Cell', 'consumable', 'equipment', 0.3, 0.2, 55, 'uncommon',
  'A fresh cell for the proximity sweep.', { maxStack: 8, found: ['workshop', 'stations'] });
def('suit_patch', 'Suit Patch Kit', 'consumable', 'equipment', 0.4, 0.2, 48, 'uncommon',
  'For when the helmet HUD starts naming the leak.', { onUse: 'med', effect: { oxygen: 15 }, maxStack: 10, found: ['airlock', 'stations'] });
def('flare_stick', 'Chem Flare', 'consumable', 'equipment', 0.3, 0.2, 12, 'common',
  'Thirty minutes of stubborn amber light.', { maxStack: 16, found: ['cargo', 'stations'] });
def('glow_tape', 'Glow Tape Roll', 'consumable', 'equipment', 0.4, 0.2, 16, 'common',
  'Mark the way back. Always mark the way back.', { maxStack: 12, found: ['workshop', 'cargo'] });
def('noisemaker', 'Noisemaker Charge', 'consumable', 'equipment', 0.5, 0.3, 65, 'uncommon',
  'A spring-loaded clatter on a timer. For when something is listening and you need it listening elsewhere.',
  { onUse: 'noisemaker', maxStack: 6, found: ['workshop', 'stations', 'derelict'] });

// -- EVA and suit stores ---------------------------------------------------------
// The suit is the only thing between you and the outside, and until now nothing
// in the hold acknowledged that it wears out. These are the consumable half of
// it: things you fit, burn through and replace.
const SUIT = [
  ['glove_liner', 'Suit Glove Liner', 0.2, 32, 'common', 'Fresh liners. The old ones stopped being liners some time ago.'],
  ['visor_film', 'Visor Anti-Fog Film', 0.1, 26, 'common', 'One breath too fast and the helmet goes white. This stops that.'],
  ['thermal_layer', 'Thermal Underlayer', 0.6, 58, 'uncommon', 'Woven heating element. Shade-side hulls run to two hundred below.'],
  ['seal_grease', 'Seal Grease Tube', 0.2, 22, 'common', 'For the collar ring. Apply thin, apply often, apply before you need it.'],
  ['co2_cartridge', 'Suit Scrubber Cartridge', 0.5, 64, 'uncommon', 'Twelve hours of not breathing your own exhale.'],
  ['lamp_cell', 'Helmet Lamp Cell', 0.3, 38, 'common', 'The cell the helmet light runs on. Carry two.'],
  ['mag_boots', 'Mag Boot Plates', 1.4, 120, 'uncommon', 'Bolt-on soles. Walking on a spinning hull is a skill; these are the excuse to learn it.'],
  ['eva_tether', 'EVA Tether Reel', 1.1, 95, 'uncommon', 'Forty metres of braid rated to nine tonnes. The reel is the part that fails.'],
  ['jet_charge', 'Manoeuvre Pack Charge', 1.6, 140, 'uncommon', 'Cold gas for the backpack. Four seconds of thrust and a great deal of regret.'],
  ['dosimeter_strip', 'Dosimeter Strip', 0.05, 18, 'common', 'Goes from cream to brown. Brown means the med bay, now.'],
];
for (const [id, name, weight, val, rarity, desc] of SUIT) {
  def(`suit_${id}`, name, 'component', 'suit', weight, 0.3, val, rarity, desc,
    { maxStack: 10, found: ['airlock', 'stations', 'trade', 'lockers'] });
}

// -- ship spares (the parts a hull actually breaks) --------------------------------
// Distinct from `comp_*`, which is generic crafting feedstock: every one of these
// names a specific fitting on the deck plan, which is what makes a repair read as
// a repair to something rather than a number going up.
const SPARES = [
  ['drive_bell_liner', 'Drive Bell Liner', 8.5, 240, 'uncommon', 'Ablative throat lining. It is supposed to erode. Not this fast.'],
  ['radiator_panel', 'Radiator Wing Panel', 11.0, 210, 'uncommon', 'One segment of a heat wing. The Drayman carries no wings and pays for it.'],
  ['deflector_node', 'Deflector Bank Node', 2.2, 265, 'rare', 'One emitter of eight. The bank runs at seven-eighths and nobody mentions it.'],
  ['gyro_cage', 'Gyro Cage Assembly', 5.6, 195, 'uncommon', 'Holds the ship\'s inner ear steady while the ship is not.'],
  ['fuel_polisher', 'Fuel Polisher Element', 1.9, 130, 'common', 'Deuterium picks up metal on the way in. This takes it back out.'],
  ['sensor_dome', 'Sensor Dome Cover', 3.4, 175, 'uncommon', 'Ceramic blister. Micrometeorites frost it until it sees nothing.'],
  ['avionics_bus', 'Avionics Bus Card', 1.1, 285, 'rare', 'Everything the cockpit says passes through this. Twice.'],
  ['docking_collar', 'Docking Collar Seal', 6.2, 155, 'uncommon', 'The ring that decides whether a station is a place or a hazard.'],
  ['warp_coil_spare', 'Spare Warp Coil', 9.8, 520, 'rare', 'Hand-wound. There is no automated way to make one and never has been.'],
  ['reactor_rod', 'Reactor Control Rod', 7.4, 340, 'rare', 'The thing that stops it. Handle at arm\'s length with the pole.'],
  ['lifesupport_core', 'Life Support Core', 4.8, 300, 'rare', 'Scrubs, humidifies, warms. Fails in that order.'],
  ['hatch_actuator', 'Hatch Actuator', 3.0, 145, 'common', 'What makes a door a door instead of a wall.'],
];
for (const [id, name, weight, val, rarity, desc] of SPARES) {
  def(`spare_${id}`, name, 'component', 'spares', weight, 1.0, val, rarity, desc,
    { maxStack: 6, found: ['workshop', 'stations', 'trade', 'derelict'] });
}

// -- ammunition and weapon stores -------------------------------------------------
// The sidearm and carbine share `ammo_slug` and the cutter runs on `ammo_cell`;
// these are the specialist loads on top of those, plus the kit that keeps a
// weapon working after a hundred rounds through it in a damp hold.
def('ammo_slug_ap', 'AP Slug Magazine', 'weapon', 'ammo', 0.6, 0.2, 55, 'uncommon',
  'Tungsten penetrator cores. For things wearing plate.',
  { maxStack: 20, found: ['stations', 'derelict', 'trade'] });
def('ammo_slug_frang', 'Frangible Magazine', 'weapon', 'ammo', 0.5, 0.2, 48, 'uncommon',
  'Breaks up on impact. Made for shooting inside a pressure hull without opening it.',
  { maxStack: 20, found: ['stations', 'trade'] });
def('ammo_cell_heavy', 'Overcharged Arc Cell', 'weapon', 'ammo', 0.5, 0.2, 80, 'rare',
  'Beyond the cutter\'s rating. It will do it twice, maybe three times.',
  { maxStack: 12, found: ['workshop', 'derelict'] });
def('weapon_kit_clean', 'Weapon Service Kit', 'tool', 'hand', 1.2, 0.5, 110, 'uncommon',
  'Rod, solvent, oil, spare springs. A carbine that has not been stripped is a club.',
  { stackable: false, maxStack: 1, found: ['workshop', 'stations', 'trade'] });
def('weapon_sight_amber', 'Amber Reflex Sight', 'tool', 'hand', 0.4, 0.3, 190, 'rare',
  'A lit chevron on a glass plate. Battery lasts a year, the mount does not.',
  { stackable: false, maxStack: 1, found: ['stations', 'derelict'] });
def('weapon_brace', 'Recoil Brace', 'tool', 'hand', 0.9, 0.4, 130, 'uncommon',
  'Straps forearm to receiver. The second shot arrives where you meant the first to.',
  { stackable: false, maxStack: 1, found: ['workshop', 'trade'] });

// -- navigation and records ---------------------------------------------------------
const NAVDATA = [
  ['lane_chart', 'Lane Chart Reel', 130, 'uncommon', 'Someone else\'s jump solutions, on tape. Some of them worked.'],
  ['orbital_almanac', 'Orbital Almanac', 95, 'common', 'Ephemerides for a system nobody has visited in six years. Still correct.'],
  ['survey_tape', 'Survey Tape', 110, 'uncommon', 'Raw sensor capture from a pass somebody did not live to file.'],
  ['beacon_codes', 'Beacon Code Sheet', 160, 'uncommon', 'Handshake strings for eleven navigation buoys. Three have been changed.'],
  ['black_box', 'Recovered Flight Recorder', 380, 'rare', 'Orange, dented, still pinging. The last four minutes are the ones worth having.'],
  ['manifest_forged', 'Amended Manifest', 210, 'rare', 'The cargo it lists is not the cargo it accompanied.'],
  ['crew_roster', 'Crew Roster Card', 60, 'common', 'Six names, five struck through. Nobody struck the sixth.'],
  ['dock_writ', 'Docking Writ', 140, 'uncommon', 'Prepaid berth at a station whose name has changed twice since.'],
];
for (const [id, name, val, rarity, desc] of NAVDATA) {
  def(`nav_${id}`, name, 'data', 'records', 0.2, 0.2, val, rarity, desc,
    { maxStack: 6, found: ['derelict', 'stations', 'trade'] });
}

// -- restricted goods ------------------------------------------------------------
// High value, no legitimate paperwork. Kestrel does not audit your hold, but the
// Vrenn price these like they know exactly what they are, because they do.
const RESTRICTED = [
  ['unlogged_cells', 'Unlogged Fuel Cells', 340, 'Serial numbers ground off with a file. A hurried file.'],
  ['cut_stones', 'Cut Stones', 520, 'Loose, unmounted, untraceable. The oldest currency there is.'],
  ['keth_black_box', 'Keth Recorder', 610, 'They take these off wrecks. Somebody took one off them.'],
  ['company_seals', 'Blank Company Seals', 290, 'Kestrel embossing dies. Whoever cut these did it well.'],
  ['med_schedule', 'Scheduled Pharmacopoeia', 450, 'Sealed, dated, in demand at every station that denies wanting it.'],
  ['drift_sample', 'Contained Drift Sample', 780, 'The container is the expensive part. Do not open the container.'],
  ['bonded_ore', 'Bonded Iridium', 560, 'Assay-stamped for a buyer who never took delivery.'],
  ['salvage_writ_void', 'Voided Salvage Writ', 230, 'The claim was rescinded. The wreck was not.'],
];
for (const [id, name, val, desc] of RESTRICTED) {
  def(`contra_${id}`, name, 'trade', 'restricted', 3.0, 0.8, val, 'rare', desc,
    { maxStack: 6, found: ['derelict', 'trade'] });
}

// -- xeno and biological samples ---------------------------------------------------
const SAMPLES = [
  ['spore_vial', 'Spore Vial', 180, 'uncommon', 'Sealed. The lab wants it sealed. Keep it sealed.'],
  ['tissue_unknown', 'Unclassified Tissue', 260, 'rare', 'It does not decay and it does not dry out.'],
  ['microbe_culture', 'Extremophile Culture', 150, 'uncommon', 'Happy at four hundred kelvin. Unhappy anywhere the crew is.'],
  ['seed_alien', 'Alien Seed Casing', 220, 'rare', 'Hard as a bearing. Something inside it shifts.'],
  ['chitin_plate', 'Chitin Plate', 130, 'uncommon', 'Shed, not cut. Whatever shed it got bigger afterwards.'],
  ['fluid_amber', 'Amber Fluid Ampoule', 300, 'rare', 'Viscous, faintly luminous, and it moves against the shake.'],
  ['coral_vac', 'Vacuum Coral', 190, 'uncommon', 'Grows in hard radiation and full vacuum. Nobody has explained how.'],
  ['nest_fragment', 'Nest Fragment', 240, 'rare', 'Chewed metal, bonded with something organic. It was a bulkhead once.'],
];
for (const [id, name, val, rarity, desc] of SAMPLES) {
  def(`sample_${id}`, name, 'material', 'biological', 0.9, 0.4, val, rarity, desc,
    { maxStack: 8, found: ['derelict', 'ruins', 'mining', 'trade'] });
}

// -- more hand tools ---------------------------------------------------------------
const TOOLS2 = [
  ['spectro_pen', 'Spectrometer Pen', 165, 'Touch it to a surface and it names the alloy. Usually.'],
  ['borescope', 'Borescope', 120, 'Two metres of fibre and a lens. For looking where the hand will not go.'],
  ['seal_tester', 'Seal Tester', 85, 'Pressurises a joint and listens. It is never good news quickly.'],
  ['torch_cutting', 'Cutting Torch', 140, 'Slower than the rotary and it does not care what the metal is.'],
  ['grapple_hook', 'Mag Grapple', 175, 'Fires, sticks, winches. Rated for one person and no cargo.'],
  ['sample_tongs', 'Sample Tongs', 45, 'A metre of distance between the hand and the interesting thing.'],
  ['hand_pump', 'Hand Transfer Pump', 60, 'When the ship\'s pump is the thing that failed.'],
  ['signal_mirror', 'Signal Mirror', 30, 'No power, no failure mode. Every EVA kit has carried one for four hundred years.'],
];
for (const [id, name, val, desc] of TOOLS2) {
  def(`tool_${id}`, name, 'tool', 'hand', 2.0, 0.7, val, 'uncommon', desc,
    { stackable: false, maxStack: 1, found: ['workshop', 'stations', 'trade'] });
}

// -- more personal effects ----------------------------------------------------------
const PERSONAL2 = [
  ['cassette_mix', 'Hand-Labelled Cassette', 'FOR THE LONG WATCH, in someone\'s handwriting. Side B is blank.'],
  ['plant_dead', 'Potted Cutting', 'Dead. Watered right up until it was.'],
  ['boots_spare', 'Broken-In Boots', 'Two sizes wrong for you. Somebody wore them for years.'],
  ['chess_set', 'Magnetic Chess Set', 'Mid-game. Black is losing and has been for eleven months.'],
  ['recipe_card', 'Recipe Card', 'Galley curry, in full, including the step everyone skips.'],
  ['medal_service', 'Service Medal', 'KESTREL — TWENTY YEARS. Pinned to nothing.'],
  ['sketch_pad', 'Sketch Pad', 'Forty drawings of the same window.'],
  ['comb_bone', 'Bone Comb', 'Hand-cut. Vrenn work, traded for at some point.'],
  ['tin_buttons', 'Tin of Buttons', 'Sixty-one buttons. None of them match anything aboard.'],
  ['calendar_marked', 'Marked Calendar', 'Crossed off daily to a date four months back, then not.'],
];
for (const [id, name, desc] of PERSONAL2) {
  def(`personal_${id}`, name, 'personal', 'effects', 0.3, 0.15, 6, 'common', desc,
    { stackable: false, maxStack: 1, found: ['lockers', 'bunks', 'derelict'] });
}

// =============================================================================
// 0.47.0 — the content expansion. Four new families and a lot more of the old
// ones, and every single addition is REACHABLE: each id below appears in a loot
// table (data/LootTables.js), a surface find list (data/SurfaceGen.js), a
// trading stock list, or a work-order reward. An item nobody can get is not an
// item, it is a line in a file.
// =============================================================================

// -- FITTINGS: the first items in the game that CHANGE THE SHIP ---------------
/**
 * Everything above this line is consumed, sold or read. These are worn.
 *
 * A fitting sits in the hold and its `fit` block is read by whatever system it
 * governs — the suit, the gun, the hull. That is the whole mechanic: no slots
 * to manage, no paper doll, no menu. Carry it and it works; sell it and it does
 * not. Deliberately small numbers, because the point is that a run where you
 * found the long barrel FEELS different, not that it is twice as good.
 */
const FITTINGS = [
  ['barrel_long', 'Long Barrel Assembly', 'weapon', 260, 'rare',
    'Adds two hundred millimetres and a lot of patience. The shot goes where you meant.',
    { damage: 1.14, spread: 0.72 }],
  ['sight_thermal', 'Thermal Sight', 'weapon', 340, 'rare',
    'Sees what is warm through what is not. Runs hot itself after a while.',
    { spread: 0.6, marksTag: 'thermal' }],
  ['cell_overcharge', 'Overcharge Cell Housing', 'weapon', 300, 'rare',
    'Dumps the whole cell into one bolt. The housing is rated for about two hundred of those.',
    { damage: 1.3, ammoUse: 1.35 }],
  ['brace_recoil', 'Shoulder Recoil Brace', 'weapon', 180, 'uncommon',
    'A strut from the shoulder to the hip. Ugly, and you stop climbing off target.',
    { spread: 0.78 }],
  ['suit_rebreather', 'Closed-Circuit Rebreather', 'suit', 420, 'rare',
    'Scrubs and returns instead of venting. Doubles a canister and weighs like a canister.',
    { o2Rate: 0.62 }],
  ['suit_ablative', 'Ablative Oversuit', 'suit', 380, 'rare',
    'A sacrificial layer that goes chalky and then goes away. Buys you a bad afternoon.',
    { hazardDamage: 0.7 }],
  ['suit_thermal_liner', 'Thermal Liner', 'suit', 240, 'uncommon',
    'For the worlds where the suit heaters are the thing that is losing.',
    { coldResist: 0.6 }],
  ['suit_grip_soles', 'Regolith Soles', 'suit', 150, 'uncommon',
    'Deep tread and a mag core. You stop sliding on scree.',
    { walkSpeed: 1.12 }],
  ['hull_bracing', 'Internal Bracing Set', 'hull', 520, 'rare',
    'Struts across the frames. The hull takes a landing better and turns worse.',
    { gearTolerance: 1.2, turn: 0.94 }],
  ['hull_ablator', 'Entry Ablator Panels', 'hull', 470, 'rare',
    'Bolt-on shielding for the forward plating. Burns off, slowly, instead of you.',
    { entryHeat: 0.72 }],
  ['drive_polisher', 'Drive Flow Polisher', 'hull', 400, 'rare',
    'Cleaner burn, less waste. Two percent of everything, forever.',
    { fuelBurn: 0.86 }],
  ['scan_booster', 'Scanner Pre-Amp', 'hull', 330, 'uncommon',
    'A better front end on a bad receiver. The ghosts get closer to real.',
    { scanRange: 1.25 }],
];
for (const [id, name, slot, val, rarity, desc, fit] of FITTINGS) {
  def(`mod_${id}`, name, 'component', 'fitting', 1.6, 0.8, val, rarity, desc,
    { stackable: false, maxStack: 1, fit, fitSlot: slot,
      found: ['derelict', 'stations', 'trade'] });
}

// -- WEAPON SERVICE -----------------------------------------------------------
def('weapon_service_kit', 'Armourer\'s Service Kit', 'tool', 'hand', 1.8, 0.7, 210, 'uncommon',
  'Rods, solvent, a bore light and the small brush nobody replaces. Restores what carrying it has cost.',
  { stackable: false, maxStack: 1, onUse: 'service', found: ['armoury', 'stations', 'trade'] });

// -- DATA: the things worth carrying off a dead bridge -------------------------
const DATA2 = [
  ['chip_blank', 'Blank Data Chip', 25, 'common',
    'Empty. Worth something to anyone who needs to write something down that cannot be overheard.'],
  ['survey_partial', 'Partial Survey', 120, 'uncommon',
    'Two thirds of a body scan. The interesting third is the missing one.'],
  ['deep_chart', 'Deep-Range Chart', 460, 'rare',
    'Jump solutions past the commissioned route. Someone plotted them and did not come back to use them.'],
  ['black_ledger', 'Encrypted Ledger', 520, 'rare',
    'Somebody\'s real numbers. The Company would pay to have it, and pay more to have it not exist.'],
  ['crew_manifest', 'Sealed Crew Manifest', 280, 'rare',
    'Names, next of kin, and a column headed DISPOSITION that is filled in.'],
  ['xeno_index', 'Xenological Index', 640, 'rare',
    'A classification scheme for things nobody has agreed are alive. Forty-one entries. Nine are crossed out.'],
];
for (const [id, name, val, rarity, desc] of DATA2) {
  def(`data_${id}`, name, 'data', 'records', 0.15, 0.15, val, rarity, desc,
    { maxStack: 6, found: ['derelict', 'stations', 'ruins'] });
}
def('nav_beacon_key', 'Beacon Key', 'data', 'records', 0.1, 0.1, 300, 'rare',
  'A physical handshake token for a navigation buoy. Buoys do not argue with these.',
  { maxStack: 4, found: ['derelict', 'stations'] });

// -- ARTIFACTS: three more, and these ones are the ones you talk about --------
const ARTIFACTS2 = [
  ['lattice_core', 'Lattice Core', 2200,
    'A cage of something that is not metal, holding nothing, at a temperature that is not a temperature.'],
  ['song_shard', 'Song Shard', 1600,
    'Broken off something larger. It still finishes the phrase when you set it down.'],
  ['still_water', 'Vessel of Still Water', 3100,
    'Sealed, full, and the contents have not moved through eleven gravities of manoeuvring.'],
  ['counting_stone', 'Counting Stone', 1400,
    'Sixty-one notches. A sixty-second is started and abandoned. Nobody knows what was being counted.'],
  ['quiet_bell', 'Quiet Bell', 1900,
    'Struck, it takes the sound out of the room for as long as it would have rung.'],
];
for (const [id, name, val, desc] of ARTIFACTS2) {
  def(`artifact_${id}`, name, 'artifact', 'ancient', 1.2, 0.7, val, 'unique', desc,
    { stackable: false, maxStack: 1, found: ['ruins', 'derelict'] });
}

// -- TRADE: bulk goods a hold is actually for ---------------------------------
const TRADE2 = [
  ['rare_earths', 'Rare Earth Concentrate', 180, 'uncommon',
    'Fourteen elements nobody can pronounce, in a drum. Every drive in the sector needs some.'],
  ['reactor_grade', 'Reactor-Grade Fuel Salts', 240, 'uncommon',
    'Sealed, hot, and the customs form for it is four pages.'],
  ['medical_stock', 'Bonded Medical Stock', 200, 'uncommon',
    'Sterile, dated, and the date is the only thing anyone checks.'],
  ['hydroponic_stock', 'Hydroponic Starter Stock', 130, 'common',
    'Trays of green under a lid. Colonies pay for this and stations pay more.'],
  ['ceramic_stock', 'Refractory Ceramics', 165, 'common',
    'Tiles that do not care about temperature. Every entry-capable hull eats these.'],
  ['coolant_bulk', 'Bulk Coolant', 110, 'common',
    'Forty litres of the blue stuff. It is always the blue stuff.'],
];
for (const [id, name, val, rarity, desc] of TRADE2) {
  def(`trade_${id}`, name, 'trade', 'bulk', 6.0, 2.4, val, rarity, desc,
    { maxStack: 30, found: ['cargo', 'stations', 'trade'] });
}

// -- CONTRABAND + PERSONAL, two more each -------------------------------------
def('contra_forged_papers', 'Forged Registry Papers', 'trade', 'restricted', 0.2, 0.15, 420, 'rare',
  'A hull identity that has never existed, notarised twice. Do not be caught holding it.',
  { maxStack: 3, found: ['derelict', 'stations'] });
const PERSONAL3 = [
  ['ring_wedding', 'Worn Wedding Band', 'Inside: a date and two initials, rubbed nearly out.'],
  ['letter_unsent', 'Unsent Letter', 'Four pages, folded, addressed, never given to a courier.'],
  ['tooth_child', 'Milk Tooth in a Twist of Paper', 'Carried a very long way from wherever it was lost.'],
];
for (const [id, name, desc] of PERSONAL3) {
  def(`personal_${id}`, name, 'personal', 'effects', 0.2, 0.12, 8, 'common', desc,
    { stackable: false, maxStack: 1, found: ['lockers', 'bunks', 'derelict'] });
}

// -- COMPONENTS: one more, for the engineering shelf ---------------------------
def('comp_field_coil', 'Field Coil', 'component', 'ship', 2.4, 1.0, 290, 'rare',
  'Superconducting, and it has held its charge since before you were commissioned.',
  { maxStack: 4, found: ['workshop', 'derelict', 'trade'] });


// =============================================================================
// SESSION 18 CONTENT PASS (0.56.0) — toward the roadmap's four-figure registry.
//
// Everything below is written to the same rule as everything above it: an item
// exists because somewhere in this world it would plausibly be sitting on a
// shelf, and its description is a sentence somebody who had handled one would
// say. Generated names were considered and rejected — "Composite Alloy Mk IV"
// three hundred times is not content, it is a filled table.
//
// The families are chosen to give every LOOT TABLE and every SUBCATEGORY enough
// members that two searches of the same kind of container do not return the
// same three things — which is the actual gameplay complaint a small registry
// produces, long before anybody counts the entries.
// =============================================================================

// -- galley: things the crew actually ate --------------------------------------
const FOOD2 = [
  ['ration_soup_thick', 'Thick Soup Pack', 26, 'Claims eleven vegetables. Four are identifiable.', 30],
  ['ration_hash', 'Protein Hash Tin', 24, 'Fries up if you have a hot plate and no standards.', 32],
  ['ration_biscuit', 'Ship Biscuit Tin', 15, 'Outlasts the ship. Softened in tea, barely edible.', 18],
  ['ration_paste_veg', 'Vegetable Paste Tube', 17, 'Green. Assertively green.', 22],
  ['ration_cheese', 'Processed Cheese Block', 21, 'Vacuum-stable at any temperature anyone has tried.', 26],
  ['ration_jerky', 'Cured Strips', 34, 'Someone aboard used to make these properly.', 30],
  ['ration_pickle', 'Pickled Roots Jar', 23, 'The brine is the point. Nobody agrees on that.', 24],
  ['ration_honey', 'Sealed Honey Pot', 44, 'Orchard stock. Will outlive everyone who handles it.', 26],
  ['ration_egg_powder', 'Egg Powder Sachet', 19, 'Reconstitutes into something adjacent to eggs.', 24],
  ['ration_choc', 'Cocoa Solid Bar', 30, 'Traded for, never issued. Kept in a sock.', 20],
  ['ration_kelp', 'Pressed Kelp Sheet', 16, 'Verdane farm stock. Salt and iodine.', 20],
  ['ration_mush', 'Cultured Mushroom Tin', 27, 'Grown in a drawer in the hydro bay. It worked.', 28],
];
for (const [id, name, val, desc, hunger] of FOOD2) {
  def(id, name, 'consumable', 'food', 0.4, 0.2, val, 'common', desc,
    { onUse: 'eat', effect: { hunger }, maxStack: 20, found: ['galley', 'cargo', 'trade'] });
}

const DRINK2 = [
  ['drink_broth', 'Salt Broth Sachet', 14, 'Hot water and something like a memory of chicken.', 26],
  ['drink_cider', 'Orchard Cider Bottle', 48, 'Aethon fruit, fermented in a fuel drum. Excellent.', 30],
  ['drink_spirit', 'Grain Spirit Flask', 62, 'Distilled in an engine room. Tastes of the engine room.', 24],
  ['drink_isotonic', 'Isotonic Concentrate', 26, 'Issued for EVA recovery. Tastes of pennies.', 40],
  ['drink_milk_uht', 'Long-Life Milk Carton', 18, 'Dated three years out. Still, technically, fine.', 28],
  ['drink_vrenn_tea', 'Vrenn Steeping Leaf', 90, 'Purple-black, brews clear, smells like rain on stone.', 34],
];
for (const [id, name, val, desc, thirst] of DRINK2) {
  def(id, name, 'consumable', 'drink', 0.5, 0.2, val, 'common', desc,
    { onUse: 'drink', effect: { thirst }, maxStack: 20, found: ['galley', 'cargo', 'trade'] });
}

// -- medical: the cabinet, properly stocked -----------------------------------
const MEDS2 = [
  ['med_suture_kit', 'Suture Kit', 48, 'Curved needle, braided thread, a mirror for the hard ones.', { health: 30 }, 'uncommon'],
  ['med_coag_spray', 'Coagulant Spray', 36, 'Foams into the wound and sets. Hurts more than the wound.', { health: 22 }, 'common'],
  ['med_splint', 'Vacuum Splint', 32, 'Wraps, then you pump the air out and it goes rigid.', { health: 18 }, 'common'],
  ['med_antinausea', 'Anti-Nausea Tab', 16, 'For the first hour of spin-up. Chalky.', { health: 6 }, 'common'],
  ['med_sleep_aid', 'Sedative Tab', 30, 'Eight hours, whatever the ship is doing.', { fatigue: 55 }, 'common'],
  ['med_stim_strong', 'Combat Stim', 88, 'Two hours of being someone else. Then the bill.', { health: 14, fatigue: 60 }, 'rare'],
  ['med_chelate_strong', 'Deep Chelation Course', 140, 'Three days of it. Clears almost everything.', { radiation: -70 }, 'rare'],
  ['med_burn_dressing', 'Burn Dressing Roll', 34, 'Silvered, non-adherent. For the reactor room.', { health: 24 }, 'common'],
  ['med_eyewash', 'Eyewash Ampoule', 20, 'After coolant. Use before you can no longer see the label.', { health: 10 }, 'common'],
  ['med_plasma_bag', 'Plasma Expander', 110, 'Buys an hour you would not otherwise have had.', { health: 55 }, 'rare'],
  ['med_antitoxin', 'Broad Antitoxin', 96, 'Works on most things this side of the Pale.', { health: 35 }, 'uncommon'],
  ['med_dental', 'Field Dental Cement', 22, 'Because it always happens a long way from a dentist.', { health: 8 }, 'common'],
];
for (const [id, name, val, desc, effect, rarity] of MEDS2) {
  def(id, name, 'consumable', 'medical', 0.6, 0.3, val, rarity, desc,
    { onUse: 'med', effect, maxStack: 8, found: ['medbay', 'stations', 'trade'] });
}

// -- ORES_S18: a real assay list ---------------------------------------------------
// Each ore exists in raw and refined form; the refined one is worth roughly
// three times the raw and weighs less per unit value, which is the whole reason
// a refinery is somewhere you would fly to.
const ORES_S18 = [
  ['copper', 'Copper', 14, 'Green-crusted, soft, endlessly useful.'],
  ['nickel', 'Nickel', 20, 'Silvery, tough, and it is in every alloy worth having.'],
  ['cobalt', 'Cobalt', 34, 'Blue in the crust. Magnets and grief.'],
  ['tungsten', 'Tungsten', 46, 'Absurdly dense. Melts at temperatures nothing else survives.'],
  ['platinum', 'Platinum', 96, 'Catalyst metal. The reason a scrubber works.'],
  ['iridium', 'Iridium', 140, 'From the impact layers. Rare enough to fly for.'],
  ['lithium', 'Lithium', 40, 'Cell stock. Light, reactive, awkward to store.'],
  ['uranium', 'Uranium', 118, 'Yellow, heavy, and the dosimeter has opinions.'],
  ['silicate', 'Silicate', 8, 'Glass, optics, and half the mass of most worlds.'],
  ['zinc', 'Zinc', 12, 'Galvanising stock. Dull and necessary.'],
  ['chromite', 'Chromite', 30, 'Where stainless comes from.'],
  ['antimony', 'Antimony', 52, 'Brittle, silver, faintly sinister in the hand.'],
];
for (const [id, name, val, desc] of ORES_S18) {
  def(`ore_${id}_raw`, `${name} Ore`, 'material', 'ore', 1.6, 0.7, val, 'common',
    `${desc} Unprocessed, and mostly rock by weight.`,
    { maxStack: 24, found: ['mining', 'surface', 'cargo'] });
  def(`ore_${id}_refined`, `Refined ${name}`, 'material', 'alloy', 1.0, 0.4, Math.round(val * 3.1), 'uncommon',
    `${desc} Refinery stock, cast in bars and stamped.`,
    { maxStack: 20, found: ['stations', 'trade', 'cargo'] });
}

// -- crystals and gemstones ----------------------------------------------------
const CRYSTALS_S18 = [
  ['crystal_lattice_blue', 'Blue Lattice Crystal', 180, 'Grows in cold vacuum. Rings when tapped.', 'uncommon'],
  ['crystal_pale_quartz', 'Pale Quartz Cluster', 90, 'Common as sand, and still worth carrying.', 'common'],
  ['crystal_storm_glass', 'Storm Glass', 260, 'Fulgurite from a world where the lightning never stops.', 'rare'],
  ['crystal_hollow_geode', 'Hollow Geode', 150, 'Sealed. Something moves in it if you shake it. Do not.', 'uncommon'],
  ['crystal_black_prism', 'Black Prism', 340, 'Absorbs more light than it should. Cold to hold.', 'rare'],
  ['crystal_salt_rose', 'Salt Rose', 70, 'From a dried seabed. Beautiful and structurally useless.', 'common'],
  ['crystal_iron_needle', 'Ferrous Needle Cluster', 120, 'Grown along a magnetic seam, all pointing one way.', 'uncommon'],
  ['crystal_ice_core', 'Deep Ice Core', 110, 'Air from a world nobody has ever breathed, still sealed in.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of CRYSTALS_S18) {
  def(id, name, 'material', 'crystal', 0.8, 0.5, val, rarity, desc,
    { maxStack: 12, found: ['mining', 'surface', 'trade'] });
}

// -- gases ---------------------------------------------------------------------
const GASES_S18 = [
  ['gas_helium3', 'Helium-3 Flask', 220, 'Scooped from a giant. The good fuel, and the hard one to get.', 'rare'],
  ['gas_nitrogen', 'Liquid Nitrogen Flask', 40, 'Coolant, propellant, and a very bad idea in a glove.', 'common'],
  ['gas_argon', 'Argon Flask', 55, 'Welding cover. Inert and indifferent.', 'common'],
  ['gas_methane', 'Methane Flask', 34, 'Ice-world scrapings, thawed and bottled.', 'common'],
  ['gas_ammonia', 'Ammonia Flask', 46, 'Smells through the seal. Everything smells through the seal.', 'common'],
  ['gas_xenon', 'Xenon Flask', 190, 'Thruster stock for something finer than this ship.', 'uncommon'],
  ['gas_chlorine', 'Chlorine Flask', 62, 'Industrial. Carry it in the hold, never in the cabin.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of GASES_S18) {
  def(id, name, 'material', 'gas', 2.0, 1.0, val, rarity, desc,
    { maxStack: 10, found: ['mining', 'stations', 'trade'] });
}

// -- ship spares: the shelf an engineer would recognise ------------------------
const SPARES2 = [
  ['spare_coolant_pump', 'Coolant Pump Assembly', 380, 'Second-hand, resealed, and it will do.', 'uncommon'],
  ['spare_o2_scrubber', 'CO2 Scrubber Cartridge', 140, 'Six hundred hours, then it is a brick.', 'common'],
  ['spare_water_recycler', 'Recycler Membrane', 210, 'Do not think about what crosses it.', 'uncommon'],
  ['spare_grav_plate', 'Gravity Plate Segment', 460, 'One square metre of down.', 'rare'],
  ['spare_door_seal', 'Hatch Seal Ring', 60, 'The cheapest part that will kill you if it fails.', 'common'],
  ['spare_sensor_head', 'Sensor Head', 320, 'The dish is fine. It is always the head.', 'uncommon'],
  ['spare_power_bus', 'Power Bus Bar', 175, 'Copper, thumb-thick, scorched at one end.', 'common'],
  ['spare_gyro_rotor', 'Gyro Rotor', 290, 'Balanced to a thousandth. Do not drop it.', 'uncommon'],
  ['spare_heat_fin', 'Radiator Fin', 130, 'Panel section. Bent ones still radiate.', 'common'],
  ['spare_landing_strut', 'Landing Strut Damper', 340, 'Rebuilt. The last one bottomed out on a hard set-down.', 'uncommon'],
  ['spare_airlock_motor', 'Airlock Drive Motor', 400, 'Cycles the outer door. Worth carrying two.', 'uncommon'],
  ['spare_reactor_shim', 'Reactor Shim Set', 520, 'Machined foils. Getting the gap wrong is a bad afternoon.', 'rare'],
  ['spare_fuel_line', 'Braided Fuel Line', 95, 'Two metres, rated well beyond anything you will do.', 'common'],
  ['spare_light_ballast', 'Lighting Ballast', 70, 'Why the aft corridor flickers.', 'common'],
];
for (const [id, name, val, desc, rarity] of SPARES2) {
  def(id, name, 'component', 'spares', 2.6, 1.2, val, rarity, desc,
    { maxStack: 6, found: ['workshop', 'stations', 'derelict', 'trade'] });
}

// -- electronics ---------------------------------------------------------------
const ELEC2 = [
  ['elec_nav_board', 'Navigation Board', 420, 'Holds a lane solution. Holds a grudge if reseated wrong.', 'uncommon'],
  ['elec_signal_amp', 'Signal Amplifier', 260, 'Turns a whisper at nine AU into a legible whisper.', 'uncommon'],
  ['elec_relay_block', 'Relay Block', 110, 'Twelve channels, four of them still work.', 'common'],
  ['elec_gyro_chip', 'Attitude Chip', 190, 'The difference between flying and spinning.', 'common'],
  ['elec_optic_coupler', 'Optical Coupler', 150, 'Glass to copper and back. Fussy about dust.', 'common'],
  ['elec_power_regulator', 'Power Regulator', 300, 'Keeps the bus flat. When it fails, everything fails.', 'uncommon'],
  ['elec_scanner_core', 'Scanner Core', 540, 'Ex-survey. Sees more than the panel is willing to show.', 'rare'],
  ['elec_transponder', 'Transponder Unit', 380, 'Says who you are. Some of them say who you were.', 'uncommon'],
  ['elec_dampener', 'Inertial Dampener Node', 610, 'The reason a hard burn does not liquefy you.', 'rare'],
  ['elec_thermal_probe', 'Thermal Probe Array', 230, 'Nine sensors on a loom. Reads a hull like a chart.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of ELEC2) {
  def(id, name, 'component', 'electronics', 1.2, 0.6, val, rarity, desc,
    { maxStack: 8, found: ['workshop', 'stations', 'derelict', 'trade'] });
}

// -- hand tools ----------------------------------------------------------------
const TOOLS2_S18 = [
  ['tool_torque_wrench', 'Torque Wrench', 120, 'Clicks. Everyone lies about hearing the click.', 'common'],
  ['tool_pry_bar', 'Pry Bar', 60, 'Opens what was not meant to open. Frequently.', 'common'],
  ['tool_multimeter', 'Multimeter', 145, 'Two leads and the truth about a circuit.', 'common'],
  ['tool_thread_tap', 'Thread Tap Set', 90, 'For when the bolt hole gives up before the bolt does.', 'common'],
  ['tool_hole_saw', 'Hole Saw Kit', 105, 'Cuts a clean round hole in the wrong bulkhead very quickly.', 'common'],
  ['tool_seal_iron', 'Seal Iron', 130, 'Heats and rolls a gasket flat. Smells appalling.', 'common'],
  ['tool_micrometer', 'Micrometer', 165, 'Thousandths. Kept in a lined case by people who care.', 'uncommon'],
  ['tool_inspection_mirror', 'Inspection Mirror', 45, 'For seeing the thing you cannot reach either.', 'common'],
  ['tool_cable_crimp', 'Cable Crimper', 85, 'Makes an honest joint out of a bad one.', 'common'],
  ['tool_vacuum_gauge', 'Vacuum Gauge', 155, 'Tells you the compartment is not as sealed as you hoped.', 'uncommon'],
  ['tool_magnet_boots', 'Mag Boot Soles', 240, 'Replacements. The old ones stopped holding in the yard.', 'uncommon'],
  ['tool_glow_stick', 'Chem Light Bundle', 25, 'Six hours of not-quite-enough light. Never fails.', 'common'],
  ['tool_line_reel', 'Safety Line Reel', 190, 'Forty metres of braid and a brake that has been tested.', 'uncommon'],
  ['tool_sample_kit', 'Sample Collection Kit', 170, 'Tubes, tongs, labels. The survey half of the job.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of TOOLS2_S18) {
  def(id, name, 'tool', 'hand', 1.1, 0.6, val, rarity, desc,
    { stackable: false, maxStack: 1, found: ['workshop', 'stations', 'derelict'] });
}

// -- suit consumables ----------------------------------------------------------
const SUIT2 = [
  ['suit_glove_liner', 'Glove Liners', 34, 'Cotton. The difference between a shift and a nightmare.', 'common'],
  ['suit_co2_cartridge', 'Suit Scrubber Cartridge', 90, 'Four hours. The number that ends an EVA.', 'common'],
  ['suit_heater_pack', 'Suit Heater Pack', 110, 'For night side. Chemical, single use, blessed.', 'common'],
  ['suit_comms_bud', 'Comms Earpiece', 55, 'Loose in the helmet until you tape it. Everybody tapes it.', 'common'],
  ['suit_visor_wipe', 'Visor Wipe Pack', 22, 'Because you will fog it at the worst moment.', 'common'],
  ['suit_tether_clip', 'Tether Carabiner', 68, 'Rated for far more than a person. Reassuring.', 'common'],
  ['suit_urine_sleeve', 'Relief Sleeve', 18, 'Nobody mentions these. Everybody packs one.', 'common'],
  ['suit_thermal_layer', 'Thermal Under-Layer', 130, 'Worn under everything. Washed rarely.', 'common'],
];
for (const [id, name, val, desc, rarity] of SUIT2) {
  def(id, name, 'component', 'suit', 0.5, 0.3, val, rarity, desc,
    { maxStack: 10, found: ['airlock', 'stations', 'derelict'] });
}

// -- trade goods and bulk ------------------------------------------------------
const TRADE3 = [
  ['trade_medical_stock', 'Bonded Medical Stock', 620, 'Sealed, bonded, and worth more the further out you take it.', 'uncommon'],
  ['trade_seed_stock', 'Seed Stock Crate', 340, 'Orchard lines. Colonies pay in things other than money.', 'uncommon'],
  ['trade_bearings', 'Precision Bearings', 280, 'A crate of them. Every yard in the chart wants some.', 'common'],
  ['trade_optics', 'Optical Blanks', 410, 'Ground but not figured. The last step is done on site.', 'uncommon'],
  ['trade_polymer', 'Structural Polymer Rolls', 190, 'Bulk sheet. Becomes anything with enough heat.', 'common'],
  ['trade_fabric', 'Woven Fabric Bales', 150, 'Colony-side textiles, sold by the bale.', 'common'],
  ['trade_ceramics', 'Refractory Tile Pallet', 330, 'Tile stock. What stands between a drive and a crew.', 'uncommon'],
  ['trade_lubricant', 'Drum of Lubricant', 120, 'Forty litres. The least glamorous cargo in the lanes.', 'common'],
  ['trade_batteries', 'Cell Bank Crate', 460, 'Charged, crated, and heavy enough to notice.', 'uncommon'],
  ['trade_water_bulk', 'Bulk Water Bladder', 90, 'Out here it is a commodity, not a given.', 'common'],
  ['trade_salvage_lot', 'Mixed Salvage Lot', 210, 'Sold by weight, sight unseen. Sometimes worth it.', 'common'],
  ['trade_luxury_goods', 'Case of Luxuries', 780, 'Soap, coffee, real paper. Sells anywhere people are tired.', 'rare'],
];
for (const [id, name, val, desc, rarity] of TRADE3) {
  def(id, name, 'trade', 'bulk', 6.0, 3.0, val, rarity, desc,
    { maxStack: 8, found: ['stations', 'cargo', 'trade'] });
}

// -- restricted ----------------------------------------------------------------
const CONTRA2 = [
  ['contra_stolen_cores', 'Stolen Data Cores', 720, 'Somebody is still looking for these. Actively.', 'rare'],
  ['contra_weapon_parts', 'Unlogged Weapon Parts', 540, 'No serials. There were serials.', 'uncommon'],
  ['contra_narcotic', 'Refined Narcotic Bricks', 880, 'The trade nobody at a counter will discuss.', 'rare'],
  ['contra_bio_sample', 'Unlicensed Biological', 640, 'Sealed twice. The inner seal is not yours.', 'rare'],
  ['contra_hull_tags', 'Cut Hull Registry Tags', 300, 'Ground off one ship, ready for another.', 'uncommon'],
  ['contra_ration_black', 'Diverted Relief Rations', 260, 'Stamped for a colony that never got them.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of CONTRA2) {
  def(id, name, 'trade', 'restricted', 3.0, 1.6, val, rarity, desc,
    { maxStack: 6, found: ['derelict', 'stations'] });
}

// -- artifacts -----------------------------------------------------------------
const ART3 = [
  ['artifact_quiet_bell', 'Quiet Bell', 1200, 'Struck, it makes no sound, and the room gets colder.', 'rare'],
  ['artifact_counting_stone', 'Counting Stone', 940, 'The marks on it increase. Nobody has seen one added.', 'rare'],
  ['artifact_folded_map', 'Folded Map of Nowhere', 860, 'Six systems, correctly placed, and a seventh that is not there.', 'rare'],
  ['artifact_still_lamp', 'Lamp That Does Not Warm', 1050, 'Bright, steady, and the glass stays at ambient.', 'rare'],
  ['artifact_paired_rings', 'Paired Rings', 1400, 'Move one; the other moves. They are not touching.', 'rare'],
  ['artifact_dry_vessel', 'Vessel That Is Never Empty', 1600, 'A thimble of water. Always a thimble of water.', 'rare'],
  ['artifact_long_needle', 'Needle That Points', 780, 'Not at north. Consistently not at north.', 'uncommon'],
  ['artifact_grey_tile', 'Grey Tile', 620, 'Records what is said near it. Nobody has found the playback.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of ART3) {
  def(id, name, 'artifact', 'ancient', 1.4, 0.8, val, rarity, desc,
    { stackable: false, maxStack: 1, found: ['ruins', 'derelict', 'surface'] });
}

// -- data and records ----------------------------------------------------------
const DATA3 = [
  ['data_yard_schedules', 'Yard Berthing Schedules', 210, 'Who was where, and for how long. Useful to the wrong people.', 'uncommon'],
  ['data_assay_archive', 'Assay Archive', 380, 'Every core sample a survey took, and what it was worth.', 'uncommon'],
  ['data_drift_telemetry', 'Drift Telemetry Capture', 720, 'Forty seconds of something talking to itself.', 'rare'],
  ['data_keth_freqs', 'Keth Fleet Frequencies', 640, 'Current as of some date nobody wrote down.', 'rare'],
  ['data_medical_files', 'Sealed Medical Files', 260, 'A crew of six, and the reason four of them were grounded.', 'uncommon'],
  ['data_insurance_claim', 'Insurance Claim Bundle', 180, 'A hull loss, disputed. The dispute is the interesting part.', 'common'],
  ['data_lane_survey', 'Deep Lane Survey', 460, 'Three routes nobody files. Two of them work.', 'uncommon'],
  ['data_black_box_partial', 'Partial Flight Recorder', 340, 'The last nine minutes. Eight of them are quiet.', 'uncommon'],
  ['data_crew_letters', 'Crew Correspondence Spool', 120, 'Private, unsent, and heavy in a way data should not be.', 'common'],
  ['data_hollow_trace', 'Anomalous Trace Log', 980, 'A sensor recording nothing was in front of. It is not empty.', 'rare'],
];
for (const [id, name, val, desc, rarity] of DATA3) {
  def(id, name, 'data', 'records', 0.2, 0.15, val, rarity, desc,
    { maxStack: 12, found: ['derelict', 'stations', 'ruins'] });
}

// -- faction salvage -----------------------------------------------------------
const FSAL2 = [
  ['fsalvage_keth_visor', 'Keth Helm Visor', 240, 'Slit-cut, scorched at one corner. Still holds a seal.', 'uncommon'],
  ['fsalvage_keth_thruster', 'Keth Attitude Nozzle', 380, 'Angular, unlovely, and machined beautifully inside.', 'uncommon'],
  ['fsalvage_keth_ammo_drum', 'Keth Ammunition Drum', 300, 'Empty. Whatever it fed is not on the wreck.', 'uncommon'],
  ['fsalvage_vrenn_vein', 'Vrenn Luminous Vein', 520, 'Cut from a hull. Still faintly warm, still faintly lit.', 'rare'],
  ['fsalvage_vrenn_resin', 'Vrenn Hull Resin', 300, 'Grown, not laid. It heals a scratch overnight.', 'uncommon'],
  ['fsalvage_drift_facet', 'Drift Chassis Facet', 610, 'A plane so flat it reads as a hole in the light.', 'rare'],
  ['fsalvage_drift_thread', 'Drift Fractal Thread', 880, 'The white marking, lifted intact. It continues at every scale.', 'rare'],
  ['fsalvage_drift_node', 'Drift Junction Node', 740, 'Twelve faces, twelve connections, no obvious front.', 'rare'],
];
for (const [id, name, val, desc, rarity] of FSAL2) {
  def(id, name, 'material', 'faction', 1.8, 0.9, val, rarity, desc,
    { maxStack: 8, found: ['derelict', 'alien', 'trade'] });
}

// -- biological samples --------------------------------------------------------
const BIO2 = [
  ['bio_lichen_mat', 'Rock Lichen Mat', 90, 'Grows on the night side and nowhere else. Slowly.', 'common'],
  ['bio_ice_algae', 'Ice Algae Core', 140, 'Green through the sample tube. Alive at minus ninety.', 'uncommon'],
  ['bio_tube_worm', 'Vent Tube Worm', 220, 'From a thermal seam. Prefers heat you could not stand.', 'uncommon'],
  ['bio_spore_sac', 'Sealed Spore Sac', 260, 'Do not open. The label says so twice, in two hands.', 'uncommon'],
  ['bio_carrion_chitin', 'Carrion Plate Sample', 310, 'Segmented, wet-looking, and it does not dry out.', 'uncommon'],
  ['bio_jungle_sap', 'Verdane Canopy Sap', 180, 'Sweet, adhesive, and mildly anaesthetic.', 'common'],
  ['bio_salt_extremophile', 'Halophile Culture', 200, 'Lives in brine that would strip a hull.', 'uncommon'],
  ['bio_unknown_tissue', 'Unidentified Tissue', 480, 'Catalogued as "pending". It has been pending for years.', 'rare'],
];
for (const [id, name, val, desc, rarity] of BIO2) {
  def(id, name, 'material', 'biological', 0.7, 0.5, val, rarity, desc,
    { maxStack: 10, found: ['surface', 'derelict', 'alien'] });
}

// -- personal effects: the things that make a wreck a place ---------------------
const PERSONAL4 = [
  ['boots_worn', 'Worn Deck Boots', 'Broken in by somebody with a different gait to yours.'],
  ['harmonica', 'Dented Harmonica', 'Three reeds gone. Played anyway, at length, aft.'],
  ['photo_dog', 'Photograph of a Dog', 'Nobody aboard a survey ship has ever had a dog.'],
  ['deck_cards', 'Deck of Cards, 51', 'The missing one is the ace. It always is.'],
  ['pressed_flower', 'Pressed Flower in Film', 'Aethon orchard. Carried a very long way from it.',],
  ['prayer_beads', 'String of Beads', 'Counted through so often the paint is gone from four.'],
  ['child_drawing', 'Child\'s Drawing of a Ship', 'The proportions are wrong and the name is right.'],
  ['service_watch', 'Service Watch', 'Stopped. The date on the back is nine years before that.'],
  ['recipe_tin', 'Recipe Tin', 'Handwritten cards, greasy at the corners. Galley property.'],
  ['sketch_book', 'Sketchbook', 'Forty pages of the same corridor from forty angles.'],
  ['lock_hair', 'Lock of Hair in Paper', 'Folded small. Nothing written on the paper.'],
  ['toy_shuttle', 'Die-Cast Toy Shuttle', 'Paint worn through at the nose where a thumb went.'],
  ['ticket_stub', 'Transit Ticket Stub', 'One way, inbound, and never used for the return.',],
  ['coin_foreign', 'Coin From Nowhere Nearby', 'Currency of a colony that changed its name twice.'],
  ['glasses_cracked', 'Cracked Reading Glasses', 'Taped at the bridge. Somebody kept using them.'],
  ['knitting', 'Half-Finished Knitting', 'Needles still in it. It is a sleeve, or it was going to be.'],
];
for (const [id, name, desc] of PERSONAL4) {
  def(`personal_${id}`, name, 'personal', 'effects', 0.2, 0.12, 10, 'common', desc,
    { stackable: false, maxStack: 1, found: ['lockers', 'bunks', 'derelict'] });
}

// -- fittings: the wearables that change the ship ------------------------------
const FIT2 = [
  ['mod_scrubber_high', 'High-Flow Scrubber', 'oxygen', 640, 'Suit air lasts noticeably longer. Bulky at the shoulder.'],
  ['mod_boot_grip', 'Grip Sole Upgrade', 'traction', 420, 'Holds on plating a standard sole slides off.'],
  ['mod_lamp_wide', 'Wide-Field Helmet Lamp', 'light', 480, 'Less range, far more of the corridor.'],
  ['mod_visor_amber', 'Amber Visor Film', 'glare', 300, 'Cuts a star\'s glare to something you can work in.'],
  ['mod_pack_baffle', 'Jet Baffle Kit', 'jet', 700, 'Finer control on the cold gas. Costs a little thrust.'],
  ['mod_hull_plate_ext', 'Auxiliary Plating', 'hull', 900, 'Bolted over the fore section. Heavy, and it has been worth it.'],
  ['mod_cargo_racking', 'Additional Racking', 'cargo', 820, 'More of the hold usable, none of it comfortable.'],
  ['mod_sensor_filter', 'Sensor Filter Set', 'scan', 560, 'Pulls a real return out of a noisy one.'],
];
for (const [id, name, fitSlot, val, desc] of FIT2) {
  def(id, name, 'component', 'fitting', 1.6, 0.8, val, 'uncommon', desc,
    { maxStack: 2, fit: true, fitSlot, found: ['stations', 'trade', 'derelict'] });
}

// -- ammunition and ordnance ---------------------------------------------------
const AMMO2 = [
  ['ammo_slug_match', 'Match-Grade Slugs', 190, 'Weighed and sorted. Tighter than you can shoot.', 'uncommon'],
  ['ammo_slug_tracer', 'Tracer Slugs', 130, 'You see where it went. So does everyone else.', 'common'],
  ['ammo_cell_short', 'Short-Cycle Cells', 110, 'Faster recharge, smaller bite.', 'common'],
  ['ammo_shot_canister', 'Canister Shot', 160, 'For corridors. Emphatically not for hulls.', 'uncommon'],
];
for (const [id, name, val, desc, rarity] of AMMO2) {
  def(id, name, 'weapon', 'ammo', 1.0, 0.4, val, rarity, desc,
    { maxStack: 12, found: ['stations', 'derelict', 'trade'] });
}

/** id → item def */
export const ITEMS = R;
export const ITEM_COUNT = Object.keys(R).length;
export const CATEGORIES = ['consumable', 'material', 'component', 'tool', 'weapon', 'artifact', 'data', 'trade', 'personal'];
