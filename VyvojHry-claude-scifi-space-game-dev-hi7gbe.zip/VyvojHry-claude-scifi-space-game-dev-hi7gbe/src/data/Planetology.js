/**
 * Planetology — a physical surface model for celestial bodies.
 *
 * WHY THIS EXISTS. The first version of `planetTexture` was a chain of
 * if-blocks, one bespoke noise recipe per body kind: "oceanic = threshold some
 * fbm and call the low half sea", "rocky = tan ramp plus craters". That gets you
 * a plausible marble at a glance and nothing survives a second look, because
 * none of the features have a *cause*. Mountains do not sit on plate boundaries,
 * deserts do not sit behind mountains, rivers do not run downhill, and ice does
 * not care where the sunlight is. Adding a new body type meant inventing another
 * recipe from scratch.
 *
 * This module replaces all of that with one simulation that every body runs, and
 * a per-kind SPEC that only sets the physical parameters — water budget, mean
 * temperature, atmospheric pressure, crust composition, tectonic vigour, impact
 * history. A carbon world and an ocean world are then the same code with
 * different numbers, and both get mountain belts where plates collide.
 *
 * THE PIPELINE, in causal order:
 *
 *   1. tectonic plates      seeded on the sphere, each continental or oceanic,
 *                           each with a drift vector
 *   2. plate boundaries     classified by relative motion into convergent
 *                           (orogeny / subduction), divergent (ridge / rift) and
 *                           transform (fracture)
 *   3. elevation            crust type + boundary uplift decaying with distance
 *                           + hotspot volcanism + impact basins + fractal detail
 *   4. sea level            solved from the spec's water budget as an elevation
 *                           percentile, so "30% water" really means 30% water
 *   5. temperature          insolation by latitude, axial tilt, greenhouse
 *                           forcing from pressure, and an altitude lapse rate
 *   6. winds                three-cell circulation: trade easterlies, mid-latitude
 *                           westerlies, polar easterlies
 *   7. precipitation        moisture picked up over water, advected downwind,
 *                           dropped on rising ground — which is what produces
 *                           rain shadows, and therefore deserts in the right places
 *   8. hydrology            steepest-descent flow accumulation; cells over a
 *                           threshold are rivers, closed basins become lakes
 *   9. biomes               a Whittaker classification on (temperature,
 *                           precipitation), plus crust-specific overrides
 *
 * Everything runs once on a coarse grid (cheap, and neighbour operations like
 * river tracing need a grid). The texture pass samples that grid and adds
 * high-frequency detail on top, so the 384x192 sheet gets its large-scale
 * structure from physics and its fine structure from noise.
 *
 * No rendering here on purpose: this is data. TextureFactory colours it, and the
 * survey/info panel can quote it.
 */
import { RNG } from '../utils/RNG.js';
import { fbm2 } from '../utils/NoiseUtils.js';

/** Simulation grid. 208x104 = 21,632 cells — the geography behind a 768x384 sheet. */
export const GW = 208;
export const GH = 104;

// -- biome ids ---------------------------------------------------------------
// Ordered roughly cold->hot, dry->wet within each band. TextureFactory maps
// these to colour ramps; the info panel can name them.
export const BIOME = {
  OCEAN_DEEP: 0,
  OCEAN_SHELF: 1,
  SEA_ICE: 2,
  ICE_SHEET: 3,
  TUNDRA: 4,
  TAIGA: 5,
  TEMPERATE_FOREST: 6,
  GRASSLAND: 7,
  SHRUBLAND: 8,
  DESERT: 9,
  SAVANNA: 10,
  RAINFOREST: 11,
  ALPINE: 12,
  BEACH: 13,
  RIVER: 14,
  LAKE: 15,
  // non-Earthlike surfaces — same pipeline, different crust
  BARE_ROCK: 16,
  REGOLITH: 17,
  LAVA_FIELD: 18,
  LAVA_FLOW: 19,
  BASALT: 20,
  SULFUR_PLAIN: 21,
  SULFUR_VENT: 22,
  CARBON_CRUST: 23,
  DIAMOND_SEAM: 24,
  TAR_SEA: 25,
  METAL_PLAIN: 26,
  METAL_FRESH: 27,
  ICE_CRUST: 28,
  ICE_FRACTURE: 29,
  DUST_MARE: 30,
  HIGHLAND: 31,
  CLOUD_DECK: 32,
};

export const BIOME_NAME = {
  0: 'deep ocean', 1: 'shelf sea', 2: 'sea ice', 3: 'ice sheet', 4: 'tundra',
  5: 'boreal forest', 6: 'temperate forest', 7: 'grassland', 8: 'shrubland',
  9: 'desert', 10: 'savanna', 11: 'tropical forest', 12: 'alpine', 13: 'littoral',
  14: 'river', 15: 'lake', 16: 'bare rock', 17: 'regolith', 18: 'lava field',
  19: 'active flow', 20: 'basalt plain', 21: 'sulphur plain', 22: 'volcanic vent',
  23: 'carbon crust', 24: 'diamond seam', 25: 'tar sea', 26: 'metal plain',
  27: 'exposed nickel', 28: 'ice crust', 29: 'fracture', 30: 'mare', 31: 'highland',
  32: 'cloud deck',
};

/**
 * Per-kind physical parameters. This table IS the difference between body types
 * now — there is no per-kind branch in the simulation itself.
 *
 *   water        fraction of the surface below sea level (0 = airless/dry)
 *   meanTempC    global mean surface temperature before latitude/altitude terms
 *   tilt         axial tilt in degrees; drives how strong the pole-equator
 *                gradient is and how far the ice reaches
 *   pressure     bar-ish; drives greenhouse forcing and how much moisture the
 *                air can hold and move
 *   tectonics    0 = dead crust (no plate motion, so no mountain belts),
 *                1 = vigorous (Earth is ~0.6)
 *   volcanism    hotspot count and lava expression
 *   cratering    impact preservation: high on airless bodies, ~0 where erosion
 *                or resurfacing wipes the record
 *   crust        which override table the biome classifier uses
 *   relief       vertical exaggeration of the whole elevation field
 */
export const PLANET_SPEC = {
  oceanic: { water: 0.68, meanTempC: 14, tilt: 23, pressure: 1.0, tectonics: 0.7, volcanism: 0.3, cratering: 0.02, crust: 'silicate', relief: 1.0 },
  jungle: { water: 0.55, meanTempC: 27, tilt: 8, pressure: 1.4, tectonics: 0.75, volcanism: 0.45, cratering: 0.01, crust: 'silicate', relief: 0.9 },
  tundra: { water: 0.42, meanTempC: -14, tilt: 31, pressure: 0.55, tectonics: 0.5, volcanism: 0.15, cratering: 0.08, crust: 'silicate', relief: 1.05 },
  rocky: { water: 0.0, meanTempC: -30, tilt: 18, pressure: 0.006, tectonics: 0.25, volcanism: 0.1, cratering: 0.75, crust: 'silicate', relief: 1.15 },
  ice: { water: 0.0, meanTempC: -170, tilt: 12, pressure: 0.02, tectonics: 0.35, volcanism: 0.05, cratering: 0.35, crust: 'ice', relief: 0.7 },
  lava: { water: 0.0, meanTempC: 420, tilt: 3, pressure: 0.3, tectonics: 0.95, volcanism: 1.0, cratering: 0.05, crust: 'molten', relief: 1.3 },
  toxic: { water: 0.0, meanTempC: 440, tilt: 2, pressure: 92, tectonics: 0.55, volcanism: 0.8, cratering: 0.05, crust: 'silicate', relief: 0.8 },
  carbon: { water: 0.0, meanTempC: 90, tilt: 14, pressure: 0.12, tectonics: 0.4, volcanism: 0.35, cratering: 0.5, crust: 'carbon', relief: 1.2 },
  metal: { water: 0.0, meanTempC: 20, tilt: 9, pressure: 0.0, tectonics: 0.1, volcanism: 0.02, cratering: 0.95, crust: 'metal', relief: 1.25 },
  sulfur: { water: 0.0, meanTempC: -60, tilt: 5, pressure: 0.01, tectonics: 0.8, volcanism: 1.0, cratering: 0.02, crust: 'sulfur', relief: 0.85 },
  moon: { water: 0.0, meanTempC: -110, tilt: 6, pressure: 0.0, tectonics: 0.05, volcanism: 0.25, cratering: 1.0, crust: 'regolith', relief: 1.1 },
  comet: { water: 0.0, meanTempC: -220, tilt: 20, pressure: 0.0, tectonics: 0.0, volcanism: 0.4, cratering: 0.45, crust: 'dirtyice', relief: 1.4 },
  // -- 0.48.0: four more crusts, each one a world the route did not have -------
  // A world after the eruption stopped. High volcanism history, no water, thick
  // dust: the tectonics are dead but the surface remembers them.
  ashen: { water: 0.0, meanTempC: 60, tilt: 11, pressure: 0.35, tectonics: 0.2, volcanism: 0.55, cratering: 0.25, crust: 'silicate', relief: 0.95 },
  // A world that HAD an ocean. Water budget of zero and a sea-level basin
  // anyway, which is what makes it read as dried rather than as never-wet.
  saltflat: { water: 0.04, meanTempC: 46, tilt: 16, pressure: 0.45, tectonics: 0.3, volcanism: 0.08, cratering: 0.3, crust: 'silicate', relief: 0.6 },
  // Banded iron: oxidised, layered, and the layers are the landscape.
  ferrous: { water: 0.0, meanTempC: -8, tilt: 21, pressure: 0.09, tectonics: 0.45, volcanism: 0.12, cratering: 0.55, crust: 'metal', relief: 1.2 },
  // Something grew here, in the mineral sense. Sparse, tall, and sharp.
  crystal: { water: 0.0, meanTempC: -95, tilt: 7, pressure: 0.03, tectonics: 0.15, volcanism: 0.3, cratering: 0.4, crust: 'carbon', relief: 1.35 },
};

const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;

/**
 * Vertical scale. After the hypsometric remap elevation runs -1..+1, and this is
 * what one unit is worth in kilometres — so a relief-1.0 world spans 20 km
 * bottom to top, near enough Earth's 20 km from the Marianas to Everest. The
 * temperature lapse rate and the reported relief both key off it.
 */
const KM_PER_UNIT = 10;

/** Grid cell -> unit vector on the sphere (for great-circle work). */
function cellDir(i, j, out) {
  const lon = (i / GW) * Math.PI * 2;
  const lat = (0.5 - (j + 0.5) / GH) * Math.PI;
  const cl = Math.cos(lat);
  out[0] = cl * Math.cos(lon);
  out[1] = Math.sin(lat);
  out[2] = cl * Math.sin(lon);
  return out;
}

/** Longitude wraps; latitude clamps (the poles are edges, not seams). */
const wrapI = (i) => (i < 0 ? i + GW : i >= GW ? i - GW : i);

export class PlanetSurface {
  /**
   * @param {string} kind key into PLANET_SPEC
   * @param {number} seed deterministic per body
   */
  constructor(kind, seed = 1) {
    this.kind = kind;
    this.spec = PLANET_SPEC[kind] ?? PLANET_SPEC.rocky;
    this.rng = new RNG(seed >>> 0 || 1);
    this.nseed = this.rng.int(0, 9999);

    const N = GW * GH;
    this.plate = new Int16Array(N);
    this.elevation = new Float32Array(N); // -1 (trench) .. +1 (peak), sea level solved later
    this.boundary = new Float32Array(N); // signed convergence at the nearest boundary
    this.bdist = new Int16Array(N); // cells to the nearest plate boundary
    this.temperature = new Float32Array(N); // °C
    this.precip = new Float32Array(N); // 0..1
    this.flow = new Float32Array(N); // accumulated upstream cells
    this.biome = new Uint8Array(N);
    this.slope = new Float32Array(N);

    this._buildPlates();
    this._assignPlates();
    this._classifyBoundaries();
    this._buildElevation();
    this._hypsometry();
    this._buildTemperature();
    this._buildPrecipitation();
    this._buildHydrology();
    this._classifyBiomes();
    this._buildSlope();
  }

  // -- 1. plates -------------------------------------------------------------

  /**
   * Seeds spread by the golden-angle spiral (an even sphere covering without
   * the pole clustering a lat/lon grid would give), then jittered so the result
   * doesn't look manufactured. Continental crust is buoyant and sits high;
   * oceanic crust is dense and sits low — that single distinction is what makes
   * continents have coherent shapes instead of being a noise threshold.
   */
  _buildPlates() {
    const r = this.rng;
    // vigorous tectonics fragments the lithosphere into more, smaller plates
    const n = Math.max(3, Math.round(lerp(4, 17, this.spec.tectonics)));
    this.plates = [];
    const ga = Math.PI * (3 - Math.sqrt(5)); // golden angle
    for (let k = 0; k < n; k++) {
      const y = 1 - (k / Math.max(1, n - 1)) * 2;
      const rad = Math.sqrt(Math.max(0, 1 - y * y));
      const th = ga * k + r.range(-0.35, 0.35);
      const dir = [
        Math.cos(th) * rad + r.range(-0.08, 0.08),
        y + r.range(-0.08, 0.08),
        Math.sin(th) * rad + r.range(-0.08, 0.08),
      ];
      const L = Math.hypot(dir[0], dir[1], dir[2]) || 1;
      dir[0] /= L; dir[1] /= L; dir[2] /= L;
      // a drift vector must be TANGENT to the sphere at the seed, or "relative
      // motion along the boundary normal" is meaningless
      let d = [r.range(-1, 1), r.range(-1, 1), r.range(-1, 1)];
      const dot = d[0] * dir[0] + d[1] * dir[1] + d[2] * dir[2];
      d = [d[0] - dir[0] * dot, d[1] - dir[1] * dot, d[2] - dir[2] * dot];
      const DL = Math.hypot(d[0], d[1], d[2]) || 1;
      const speed = r.range(0.35, 1) * this.spec.tectonics;
      this.plates.push({
        dir,
        drift: [(d[0] / DL) * speed, (d[1] / DL) * speed, (d[2] / DL) * speed],
        // a dry world's "continental" plates are just thicker crust
        continental: r.chance(this.spec.water > 0 ? 0.42 : 0.5),
        base: 0,
      });
    }
    // continental plates float ~1.5 km higher than oceanic; jitter each so no
    // two continents share an elevation and the coastlines differ in character
    for (const p of this.plates) p.base = (p.continental ? 0.30 : -0.34) + r.range(-0.07, 0.07);
  }

  /**
   * Nearest-seed assignment, but the distance is warped by low-frequency noise
   * before comparison. A clean spherical Voronoi gives suspiciously straight
   * boundaries; warping makes them wander the way real sutures do.
   */
  _assignPlates() {
    const d = [0, 0, 0];
    for (let j = 0; j < GH; j++) {
      for (let i = 0; i < GW; i++) {
        cellDir(i, j, d);
        const warp = 0.16 * (fbm2(d[0] * 2.4 + 11, d[2] * 2.4 + d[1] * 2.4, this.nseed, 3) - 0.5);
        let best = 0, bestD = -2;
        for (let k = 0; k < this.plates.length; k++) {
          const pd = this.plates[k].dir;
          const dot = d[0] * pd[0] + d[1] * pd[1] + d[2] * pd[2] + warp;
          if (dot > bestD) { bestD = dot; best = k; }
        }
        this.plate[j * GW + i] = best;
      }
    }
  }

  /**
   * For every boundary cell, project the two plates' relative drift onto the
   * boundary normal. Positive = closing (convergent), negative = opening
   * (divergent), near zero = sliding (transform). Then a multi-source BFS
   * spreads distance-from-boundary across the grid so uplift can decay inland —
   * that decay is what makes a mountain RANGE rather than a one-cell ridge.
   */
  _classifyBoundaries() {
    const N = GW * GH;
    const q = new Int32Array(N);
    let qh = 0, qt = 0;
    this.bdist.fill(9999);
    const a = [0, 0, 0], b = [0, 0, 0];
    for (let j = 0; j < GH; j++) {
      for (let i = 0; i < GW; i++) {
        const idx = j * GW + i;
        const p = this.plate[idx];
        let other = -1;
        // 4-neighbourhood; latitude edges simply have no neighbour past the pole
        const nb = [[wrapI(i + 1), j], [wrapI(i - 1), j], [i, j + 1], [i, j - 1]];
        for (const [ni, nj] of nb) {
          if (nj < 0 || nj >= GH) continue;
          const o = this.plate[nj * GW + ni];
          if (o !== p) { other = o; break; }
        }
        if (other < 0) continue;
        cellDir(i, j, a);
        const A = this.plates[p], B = this.plates[other];
        // boundary normal ~ the direction from this plate's seed toward the other
        b[0] = B.dir[0] - A.dir[0]; b[1] = B.dir[1] - A.dir[1]; b[2] = B.dir[2] - A.dir[2];
        const L = Math.hypot(b[0], b[1], b[2]) || 1;
        b[0] /= L; b[1] /= L; b[2] /= L;
        const rel = [A.drift[0] - B.drift[0], A.drift[1] - B.drift[1], A.drift[2] - B.drift[2]];
        const conv = rel[0] * b[0] + rel[1] * b[1] + rel[2] * b[2];
        this.boundary[idx] = conv;
        this.bdist[idx] = 0;
        q[qt++] = idx;
      }
    }
    // BFS outward, carrying the boundary's convergence value with it
    while (qh < qt) {
      const idx = q[qh++];
      const i = idx % GW, j = (idx / GW) | 0;
      const dNext = this.bdist[idx] + 1;
      if (dNext > 14) continue; // uplift is spent by here; stop early
      const nb = [[wrapI(i + 1), j], [wrapI(i - 1), j], [i, j + 1], [i, j - 1]];
      for (const [ni, nj] of nb) {
        if (nj < 0 || nj >= GH) continue;
        const nIdx = nj * GW + ni;
        if (this.bdist[nIdx] <= dNext) continue;
        this.bdist[nIdx] = dNext;
        this.boundary[nIdx] = this.boundary[idx];
        q[qt++] = nIdx;
      }
    }
  }

  /**
   * Elevation = plate base + tectonic contribution + hotspots + impacts + fbm.
   *
   * The tectonic term is the interesting one. Convergent boundaries between two
   * continental plates raise a broad range (Himalaya); a continental-oceanic pair
   * digs a trench on the ocean side and raises a narrow volcanic arc on the land
   * side (Andes); divergent boundaries raise a mid-ocean ridge or drop a rift
   * valley depending on which crust they split.
   */
  _buildElevation() {
    const s = this.spec;
    const r = this.rng;
    const d = [0, 0, 0];

    // hotspots: mantle plumes, fixed while plates move over them
    const hotN = Math.round(lerp(0, 9, s.volcanism));
    const hots = [];
    for (let k = 0; k < hotN; k++) {
      const v = [r.range(-1, 1), r.range(-1, 1), r.range(-1, 1)];
      const L = Math.hypot(v[0], v[1], v[2]) || 1;
      hots.push({ dir: [v[0] / L, v[1] / L, v[2] / L], r: r.range(0.05, 0.16), h: r.range(0.25, 0.75) });
    }

    // impact basins: a few large ones, many small. Only bodies that preserve
    // them get any — an ocean world's record is erased in tens of millions of years.
    const impN = Math.round(lerp(0, 26, s.cratering));
    const imps = [];
    for (let k = 0; k < impN; k++) {
      const v = [r.range(-1, 1), r.range(-1, 1), r.range(-1, 1)];
      const L = Math.hypot(v[0], v[1], v[2]) || 1;
      // size distribution biased small: many little craters, a couple of basins
      const t = r.next() * r.next();
      imps.push({ dir: [v[0] / L, v[1] / L, v[2] / L], r: lerp(0.018, 0.19, t), depth: lerp(0.12, 0.5, t) });
    }
    this.impacts = imps;

    for (let j = 0; j < GH; j++) {
      for (let i = 0; i < GW; i++) {
        const idx = j * GW + i;
        cellDir(i, j, d);
        const plate = this.plates[this.plate[idx]];
        let h = plate.base;

        // -- tectonic uplift, decaying with distance from the boundary --------
        const bd = this.bdist[idx];
        if (bd < 14) {
          const conv = this.boundary[idx];
          const falloff = Math.pow(1 - bd / 14, 1.7);
          if (conv > 0.02) {
            // convergent: orogeny. Continental collision builds high and wide;
            // subduction builds a narrow arc and digs a trench alongside it.
            const both = plate.continental;
            const amp = conv * (both ? 1.5 : 0.95) * s.tectonics;
            h += amp * falloff * (both ? 1.0 : 0.75);
            if (!both && bd < 3) h -= conv * 0.9 * (1 - bd / 3); // trench
          } else if (conv < -0.02) {
            // divergent: ridge in ocean crust, rift valley in continental
            const amp = -conv * s.tectonics;
            h += plate.continental ? -amp * 0.7 * falloff : amp * 0.55 * falloff;
          } else if (bd < 2) {
            // transform: no vertical motion to speak of, just offset fracturing
            h += 0.05 * (fbm2(d[0] * 30, d[2] * 30, this.nseed + 3, 2) - 0.5);
          }
        }

        // -- hotspot volcanism ------------------------------------------------
        for (const ht of hots) {
          const dot = d[0] * ht.dir[0] + d[1] * ht.dir[1] + d[2] * ht.dir[2];
          const ang = Math.acos(clamp(dot, -1, 1)) / Math.PI;
          if (ang < ht.r) h += ht.h * Math.pow(1 - ang / ht.r, 2.2);
        }

        // -- impacts: bowl floor, raised rim, ejecta apron --------------------
        for (const im of imps) {
          const dot = d[0] * im.dir[0] + d[1] * im.dir[1] + d[2] * im.dir[2];
          const ang = Math.acos(clamp(dot, -1, 1)) / Math.PI;
          if (ang > im.r * 1.45) continue;
          if (ang < im.r * 0.82) {
            h -= im.depth * (1 - Math.pow(ang / (im.r * 0.82), 2)); // bowl
          } else if (ang < im.r * 1.02) {
            h += im.depth * 0.55; // rim
          } else {
            h += im.depth * 0.16 * (1 - (ang - im.r * 1.02) / (im.r * 0.43)); // ejecta
          }
        }

        // -- fractal roughness -------------------------------------------------
        // sampled on the 3D direction so it wraps with no seam at longitude 0
        const rough = fbm2(d[0] * 3.1 + 7, d[2] * 3.1 + d[1] * 5.0, this.nseed + 17, 5) - 0.5;
        const fine = fbm2(d[0] * 11 + 23, d[2] * 11 + d[1] * 13, this.nseed + 29, 3) - 0.5;
        h += rough * 0.42 + fine * 0.13;

        this.elevation[idx] = h * s.relief;
      }
    }
  }

  /**
   * HYPSOMETRIC REMAP — rank each cell by raw elevation, then reassign its
   * height from a target curve. This is the single most important correction in
   * the model and it took a measurement to find: the raw field came out roughly
   * Gaussian, which put the average land cell 3 km up, froze most of an
   * ocean world under a lapse rate that steep, and reported 16–31 km of relief.
   *
   * Real hypsometry is nothing like a Gaussian. It is strongly bimodal — a broad
   * abyssal plain, a narrow continental shelf, then land that is overwhelmingly
   * low with a thin tail of mountains (Earth's mean land elevation is 840 m
   * against an 8.8 km maximum). Remapping by rank imposes exactly that
   * distribution while leaving the SPATIAL arrangement untouched, because a
   * monotone function of rank cannot move a peak off a plate boundary.
   *
   * It also makes the water budget exact and puts sea level at precisely 0.
   */
  _hypsometry() {
    const N = GW * GH;
    const idx = new Int32Array(N);
    for (let i = 0; i < N; i++) idx[i] = i;
    const e = this.elevation;
    Array.prototype.sort.call(idx, (a, b) => e[a] - e[b]);

    const w = this.spec.water;
    const rel = this.spec.relief;
    if (w > 0) {
      this.seaLevel = 0;
      for (let k = 0; k < N; k++) {
        const r = k / (N - 1);
        let h;
        if (r < w) {
          // ocean: most of the floor sits near the abyssal plain, and the shelf
          // is a thin band just below the shoreline
          const u = r / w;
          h = -1 + Math.pow(u, 0.45);
        } else {
          // land: 85% of it below 0.18, then a steep mountain tail
          // 85% of land below 1 km, then a steep tail to the peaks. Measured
          // against Earth: mean land elevation 840 m out of an 8.8 km maximum.
          // An earlier curve capped the low band at 0.18 (1.8 km) and the lapse
          // rate then froze a temperate world into tundra.
          const u = (r - w) / (1 - w);
          h = u < 0.85 ? (u / 0.85) * 0.10 : 0.10 + Math.pow((u - 0.85) / 0.15, 1.7) * 0.90;
        }
        e[idx[k]] = h * rel;
      }
    } else {
      // No ocean, so no shoreline to organise around: a symmetric signed curve
      // that keeps impact basins as real depressions and highlands as real
      // highlands, with a flatter middle than the raw Gaussian.
      this.seaLevel = -Infinity;
      for (let k = 0; k < N; k++) {
        const t = (k / (N - 1)) * 2 - 1;
        e[idx[k]] = Math.sign(t) * Math.pow(Math.abs(t), 1.7) * rel;
      }
    }
  }

  /**
   * Insolation falls with latitude; axial tilt widens the seasonal swing, which
   * over a year averages to a *flatter* gradient, so high-tilt worlds have
   * warmer poles relative to their equator. Pressure drives greenhouse forcing
   * (logarithmic, as it is in reality — Venus is hot because 92 bar, not because
   * it is closer in). Land above sea level cools at a lapse rate.
   */
  _buildTemperature() {
    const s = this.spec;
    const tiltRad = (s.tilt * Math.PI) / 180;
    /**
     * `meanTempC` is the GLOBAL MEAN including whatever greenhouse the world
     * has — it is a measured number, not a pre-greenhouse baseline. So the
     * latitude term must distribute around it with zero net effect, which means
     * subtracting the area-weighted mean insolation rather than 1.0. Adding a
     * separate greenhouse offset on top (the first version did) double-counted
     * and still came out cold, because it also anchored the equator instead of
     * the average.
     *
     * The area-weighted mean of cos(latitude) over a sphere is π/4.
     */
    // Annual-mean insolation is NOT cos(latitude) — that is the instantaneous
    // noon-equinox value and it is far too steep. The standard energy-balance
    // approximation is a second Legendre polynomial, S(φ) = 1 − 0.482·P₂(sin φ),
    // which is flatter in the mid-latitudes and integrates to exactly 1 over the
    // sphere. Using cos put 45° latitude six degrees too cold and turned every
    // temperate world's continents into tundra.
    const insolAt = (lat) => {
      const s2 = Math.sin(lat) ** 2;
      return 1 - 0.482 * ((3 * s2 - 1) / 2);
    };
    // A thick atmosphere transports heat poleward and flattens the gradient:
    // Venus at 92 bar is nearly isothermal pole to equator, Mars at 0.006 bar
    // is anything but.
    const evenness = clamp(0.18 + 0.5 * Math.log10(1 + s.pressure * 9), 0.18, 0.94);
    // Calibrated on Earth: at 1 bar and 23° tilt this gives a ~46 °C pole-to-
    // equator span (equator ~24 °C, pole ~-22 °C), against the real ~52.
    // High obliquity evens the annual average out, so it damps the gradient.
    // Calibrated on Earth: at 1 bar and 23° tilt the P₂ profile spans 1.5 units
    // pole to equator, so a gradient of ~30 gives the real ~45 °C span
    // (equator ~29 °C, pole ~-16 °C). High obliquity evens the annual mean out.
    const gradient = lerp(62, 19, evenness) * (1 - 0.25 * Math.sin(tiltRad));
    for (let j = 0; j < GH; j++) {
      const lat = (0.5 - (j + 0.5) / GH) * Math.PI;
      const rowT = s.meanTempC + gradient * (insolAt(lat) - 1);
      for (let i = 0; i < GW; i++) {
        const idx = j * GW + i;
        const e = this.elevation[idx];
        const above = this.seaLevel === -Infinity ? Math.max(0, e) : Math.max(0, e - this.seaLevel);
        // After the hypsometric remap, 1.0 unit of elevation is KM_PER_UNIT km,
        // so the standard 6.5 °C/km environmental lapse rate lands here. Thin air
        // carries less heat away, so the rate weakens with pressure.
        const lapse = above * KM_PER_UNIT * 6.5 * clamp(s.pressure, 0.06, 1.5);
        this.temperature[idx] = rowT - lapse;
      }
    }
  }

  /**
   * Three-cell circulation and orographic rainfall.
   *
   * Winds blow east or west depending on the latitude band (trade easterlies in
   * the tropics, westerlies in the mid-latitudes, polar easterlies above 60°).
   * We march each row along its wind direction carrying a humidity value: water
   * cells add moisture, land cells drain it, and any climb in elevation forces
   * a heavy drop. Two laps around the sphere so the wrap converges.
   *
   * The rain shadow this produces is the whole reason the model exists — it puts
   * deserts *behind mountains* rather than wherever a noise field happened to dip.
   */
  _buildPrecipitation() {
    const s = this.spec;
    if (s.pressure < 0.02) { this.precip.fill(0); return; }
    const capacity = clamp(0.35 + 0.65 * Math.log10(1 + s.pressure * 4), 0.2, 1.6);
    for (let j = 0; j < GH; j++) {
      const latDeg = Math.abs((0.5 - (j + 0.5) / GH) * 180);
      // +1 = wind blows toward +i (eastward), -1 = westward
      const dir = latDeg < 30 ? -1 : latDeg < 60 ? 1 : -1;
      // how much water the air can hold at this temperature (Clausius-Clapeyron
      // in spirit: warm air carries far more)
      let hum = 0;
      for (let lap = 0; lap < 2; lap++) {
        for (let step = 0; step < GW; step++) {
          const i = wrapI(dir > 0 ? step : GW - 1 - step);
          const idx = j * GW + i;
          const e = this.elevation[idx];
          const isWater = this.seaLevel !== -Infinity && e <= this.seaLevel;
          const warm = clamp((this.temperature[idx] + 40) / 80, 0.05, 1.6);
          if (isWater) {
            hum = Math.min(capacity * warm, hum + 0.16 * warm); // evaporation
            if (lap === 1) this.precip[idx] = clamp(hum * 0.45, 0, 1);
            continue;
          }
          // Orographic lift plus a convective baseline. The baseline matters:
          // with only the orographic term, flat coastal land got 0.09 of rain
          // and the classifier called an entire temperate world desert. Real
          // rainfall over warm flat ground is substantial — most of the tropics
          // never sees a mountain.
          const prev = j * GW + wrapI(dir > 0 ? i - 1 : i + 1);
          const climb = Math.max(0, e - this.elevation[prev]);
          const drop = hum * clamp(0.16 + climb * 5.0, 0, 0.9);
          hum -= drop;
          hum *= 0.985; // continentality: air dries as it crosses land
          if (lap === 1) this.precip[idx] = clamp(drop * 3.2, 0, 1);
        }
      }
    }
    // a light blur so rainfall bands aren't single-cell stripes
    const tmp = Float32Array.from(this.precip);
    for (let j = 0; j < GH; j++) {
      for (let i = 0; i < GW; i++) {
        let sum = 0, n = 0;
        for (let dj = -1; dj <= 1; dj++) {
          const nj = j + dj;
          if (nj < 0 || nj >= GH) continue;
          for (let di = -1; di <= 1; di++) { sum += tmp[nj * GW + wrapI(i + di)]; n++; }
        }
        this.precip[j * GW + i] = sum / n;
      }
    }
  }

  /**
   * Steepest-descent flow accumulation. Process land cells from high to low so
   * every cell's upstream area is final before it drains; cells whose neighbours
   * are all higher are closed basins and become lakes.
   */
  _buildHydrology() {
    if (this.spec.water <= 0 || this.spec.pressure < 0.02) { this.lake = new Uint8Array(GW * GH); return; }
    const N = GW * GH;
    const order = [];
    for (let idx = 0; idx < N; idx++) if (this.elevation[idx] > this.seaLevel) order.push(idx);
    order.sort((a, b) => this.elevation[b] - this.elevation[a]);
    this.lake = new Uint8Array(N);
    for (const idx of order) {
      // rainfall is the source term, so wet highlands feed big rivers
      this.flow[idx] += 0.25 + this.precip[idx] * 2.4;
      const i = idx % GW, j = (idx / GW) | 0;
      let bestIdx = -1, bestE = this.elevation[idx];
      for (let dj = -1; dj <= 1; dj++) {
        const nj = j + dj;
        if (nj < 0 || nj >= GH) continue;
        for (let di = -1; di <= 1; di++) {
          if (!di && !dj) continue;
          const nIdx = nj * GW + wrapI(i + di);
          if (this.elevation[nIdx] < bestE) { bestE = this.elevation[nIdx]; bestIdx = nIdx; }
        }
      }
      if (bestIdx < 0) this.lake[idx] = 1; // nowhere downhill — endorheic basin
      else this.flow[bestIdx] += this.flow[idx];
    }
    // River threshold as a PERCENTILE of land flow, not an absolute number. The
    // flow scale is proportional to rainfall, so a fixed cutoff drew a dense
    // river net on a wet world and none at all on a dry one. This draws the
    // top ~2.5% of drainage whatever the climate, which is roughly the fraction
    // of a real continent that reads as a mapped watercourse.
    const flows = order.map((i) => this.flow[i]).sort((a, b) => a - b);
    this.riverThreshold = flows.length
      ? Math.max(4, flows[Math.floor(flows.length * 0.975)]) : Infinity;
  }

  /**
   * Whittaker-style classification for silicate worlds with an atmosphere, and
   * crust-specific tables for everything else. The point of routing all of them
   * through one classifier is that the *geography* — where the highlands are,
   * where the basins are — is shared, so a carbon world's tar seas pool in the
   * lowlands the same way an ocean world's water does.
   */
  _classifyBiomes() {
    const s = this.spec;
    const N = GW * GH;
    const B = BIOME;
    /**
     * Whittaker's precipitation axis is RELATIVE to this world, not absolute.
     * The moisture scale depends on pressure, temperature and how much ocean
     * there is, so an absolute millimetre threshold collapses a whole planet
     * onto one side of it — the first version classified every continent on a
     * temperate world as tundra because flat land happened to land just under a
     * fixed cutoff. Normalising to the 20th/80th percentile of the world's own
     * land rainfall guarantees a real spread of biomes on any planet that has
     * a hydrological cycle at all, and still puts the dry end downwind of the
     * mountains where the physics put it.
     */
    let pLo = 0, pHi = 1;
    if (s.water > 0) {
      const lp = [];
      for (let i = 0; i < N; i++) if (this.elevation[i] > this.seaLevel) lp.push(this.precip[i]);
      if (lp.length > 8) {
        lp.sort((a, b) => a - b);
        pLo = lp[Math.floor(lp.length * 0.20)];
        pHi = lp[Math.floor(lp.length * 0.80)];
        if (pHi - pLo < 1e-4) pHi = pLo + 1e-4;
      }
    }
    const pnorm = (p) => clamp((p - pLo) / (pHi - pLo), 0, 1.5);
    // relative elevation range, for "is this a highland" tests
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i < N; i++) { const e = this.elevation[i]; if (e < lo) lo = e; if (e > hi) hi = e; }
    const span = Math.max(1e-4, hi - lo);
    this.elevLo = lo; this.elevHi = hi;

    for (let idx = 0; idx < N; idx++) {
      const e = this.elevation[idx];
      const t = this.temperature[idx];
      const p = pnorm(this.precip[idx]);
      const rel = (e - lo) / span; // 0 lowest .. 1 highest
      const water = this.seaLevel !== -Infinity && e <= this.seaLevel;
      const depth = water ? (this.seaLevel - e) / span : 0;
      let bi;

      if (water) {
        bi = t < -2 ? B.SEA_ICE : depth > 0.09 ? B.OCEAN_DEEP : B.OCEAN_SHELF;
      } else if (s.crust === 'molten') {
        // active volcanism: the hottest, lowest ground is still liquid
        bi = rel < 0.22 ? B.LAVA_FLOW : rel < 0.55 ? B.LAVA_FIELD : B.BASALT;
      } else if (s.crust === 'sulfur') {
        // sulphur plains ARE the surface of an Io-analog; basalt only shows in
        // the deepest resurfaced basins, and the vents crown the high ground
        bi = rel > 0.82 ? B.SULFUR_VENT : rel < 0.14 ? B.BASALT : B.SULFUR_PLAIN;
      } else if (s.crust === 'carbon') {
        bi = rel < 0.24 ? B.TAR_SEA : rel > 0.8 ? B.DIAMOND_SEAM : B.CARBON_CRUST;
      } else if (s.crust === 'metal') {
        bi = rel > 0.72 ? B.METAL_FRESH : B.METAL_PLAIN;
      } else if (s.crust === 'ice' || s.crust === 'dirtyice') {
        bi = rel > 0.74 ? B.ICE_FRACTURE : rel < 0.26 ? B.DUST_MARE : B.ICE_CRUST;
      } else if (s.crust === 'regolith') {
        bi = rel < 0.34 ? B.DUST_MARE : rel > 0.72 ? B.HIGHLAND : B.REGOLITH;
      } else if (s.water <= 0) {
        // NO OCEAN, SO NO HYDROLOGICAL CYCLE — and therefore no biomes, whatever
        // the air pressure is. Gating this on pressure instead was the earlier
        // mistake: it sent Venus (92 bar, bone dry) down the Whittaker path and
        // classified its basalt plains as "desert" and its tesserae as scrub.
        // A dry world's surface is geology, and elevation is the only story.
        bi = rel > 0.7 ? B.HIGHLAND : rel < 0.3 ? B.BASALT : B.BARE_ROCK;
      } else if (t < -18) {
        bi = p > 0.5 ? B.ICE_SHEET : B.TUNDRA;
      } else if (rel > 0.88 && t < 6) {
        bi = B.ALPINE;
      } else if (t < 4) {
        bi = p > 0.45 ? B.TAIGA : B.TUNDRA;
      } else if (t < 20) {
        bi = p > 0.75 ? B.TEMPERATE_FOREST : p > 0.40 ? B.GRASSLAND : p > 0.15 ? B.SHRUBLAND : B.DESERT;
      } else {
        bi = p > 0.80 ? B.RAINFOREST : p > 0.45 ? B.SAVANNA : p > 0.18 ? B.SHRUBLAND : B.DESERT;
      }

      // hydrology paints last: rivers and lakes override the land biome
      if (!water && this.lake?.[idx]) bi = B.LAKE;
      else if (!water && this.flow[idx] >= (this.riverThreshold ?? Infinity)) bi = B.RIVER;
      // a thin littoral strip wherever land meets sea
      else if (!water && this.seaLevel !== -Infinity && e - this.seaLevel < span * 0.012) bi = B.BEACH;

      this.biome[idx] = bi;
    }
  }

  /** Slope magnitude per cell — the texture pass uses it for relief shading. */
  _buildSlope() {
    for (let j = 0; j < GH; j++) {
      for (let i = 0; i < GW; i++) {
        const idx = j * GW + i;
        const l = this.elevation[j * GW + wrapI(i - 1)];
        const r = this.elevation[j * GW + wrapI(i + 1)];
        const u = this.elevation[Math.max(0, j - 1) * GW + i];
        const d = this.elevation[Math.min(GH - 1, j + 1) * GW + i];
        this.slope[idx] = (r - l) * 0.5 + (d - u) * 0.25; // signed: lit from NW
      }
    }
  }

  // -- sampling ---------------------------------------------------------------

  /** Nearest-cell index for normalised (u = longitude 0..1, v = latitude 0..1). */
  cellAt(u, v) {
    const i = wrapI(Math.floor(u * GW));
    const j = clamp(Math.floor(v * GH), 0, GH - 1);
    return j * GW + i;
  }

  /** Bilinear elevation, so relief shading doesn't step at cell edges. */
  elevationAt(u, v) {
    const fx = u * GW - 0.5, fy = clamp(v * GH - 0.5, 0, GH - 1.001);
    const i0 = wrapI(Math.floor(fx)), j0 = Math.floor(fy);
    const i1 = wrapI(i0 + 1), j1 = Math.min(GH - 1, j0 + 1);
    const tx = fx - Math.floor(fx), ty = fy - j0;
    const e = this.elevation;
    return lerp(
      lerp(e[j0 * GW + i0], e[j0 * GW + i1], tx),
      lerp(e[j1 * GW + i0], e[j1 * GW + i1], tx), ty,
    );
  }

  /** Summary the survey/info panel can quote — real numbers from the model. */
  report() {
    const N = GW * GH;
    // AREA WEIGHTING, not a cell count. An equirectangular grid gives a polar row
    // the same number of cells as the equator while it covers a sliver of the
    // real surface, so an unweighted census reported 23% sea ice on a world whose
    // ice actually reaches 64° — and made a temperate planet look frozen.
    let water = 0, ice = 0, tSum = 0, tMin = Infinity, tMax = -Infinity, rivers = 0, wSum = 0;
    const counts = new Map();
    for (let i = 0; i < N; i++) {
      const j = (i / GW) | 0;
      const w = Math.cos((0.5 - (j + 0.5) / GH) * Math.PI);
      wSum += w;
      const b = this.biome[i];
      counts.set(b, (counts.get(b) ?? 0) + w);
      if (b === BIOME.OCEAN_DEEP || b === BIOME.OCEAN_SHELF || b === BIOME.LAKE) water += w;
      if (b === BIOME.ICE_SHEET || b === BIOME.SEA_ICE || b === BIOME.ICE_CRUST) ice += w;
      if (b === BIOME.RIVER) rivers++;
      const t = this.temperature[i];
      tSum += t * w; if (t < tMin) tMin = t; if (t > tMax) tMax = t;
    }
    const dominant = [...counts.entries()].sort((a, b) => b[1] - a[1])[0];
    this.areaWeight = wSum;
    return {
      waterPct: Math.round((water / wSum) * 100),
      icePct: Math.round((ice / wSum) * 100),
      meanTempC: Math.round(tSum / wSum),
      tempRangeC: [Math.round(tMin), Math.round(tMax)],
      riverCells: rivers,
      plates: this.plates.length,
      craters: this.impacts.length,
      dominantBiome: BIOME_NAME[dominant[0]],
      reliefKm: +((this.elevHi - this.elevLo) * KM_PER_UNIT).toFixed(1),
    };
  }
}

/** Cache: a body's surface is deterministic, and the texture pass wants it twice. */
const CACHE = new Map();
export function planetSurface(kind, seed = 1) {
  const key = `${kind}:${seed}`;
  let s = CACHE.get(key);
  if (!s) { s = new PlanetSurface(kind, seed); CACHE.set(key, s); }
  return s;
}
