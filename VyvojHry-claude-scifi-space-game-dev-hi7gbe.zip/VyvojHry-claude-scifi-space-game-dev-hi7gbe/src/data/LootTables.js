/**
 * LOOT TABLES — what is in a thing you open, and why it is worth opening.
 *
 * The first version was one flat list per container pattern, every row rolled
 * independently at a fixed chance. That works and it is boring in a specific
 * way: the distribution never changes, so after the tenth locker you know
 * exactly what a locker is, and there is no reason to open the eleventh. A loot
 * system's whole job is to make the eleventh worth opening.
 *
 * THREE THINGS FIX THAT, and they are all here rather than in the roller:
 *
 *   1. A RARE SHELF per container. Most searches return the common rows and
 *      nothing else. Occasionally the rare shelf opens and you get the thing at
 *      the bottom of the box — a tool you cannot buy, a data chip, a piece of
 *      somebody's life. The odds are small and they are the reason to keep
 *      looking.
 *   2. CONTAINER CLASS. The same word on the label means different things in
 *      different places: a crate on your own ship is stores, a crate in a
 *      derelict is what the last crew did not get to, and a crate in an alien
 *      structure is not a crate. `tier` scales the odds and gates the shelf.
 *   3. THE PILOT. `SALVAGE` proficiency adds to every row's chance and shifts
 *      the rare gate — see gameplay/Progression.js. Getting better at looking
 *      is the one progression term the player can feel inside a single session.
 *
 * Rows are `[itemId, minQty, maxQty, chance]`. Chance is the probability at
 * tier 1.0 with an unskilled pilot, so the numbers here read as "how often does
 * a locker have a bandage in it" and stay legible.
 */

/**
 * How generous a place is. Multiplies every common chance and is added to the
 * rare gate — a derelict is not just fuller than your own hold, it is fuller of
 * the things nobody stocks on purpose.
 */
export const TIERS = {
  ship: 1.00,        // the Aethon's own fittings
  station: 1.12,     // a concourse store room
  surface: 1.20,     // scattered on a world, weathered
  derelict: 1.38,    // a hull that did not make it
  alien: 1.65,       // not built by anyone with hands like yours
};

/** Base probability the rare shelf opens at all, before tier and skill. */
export const RARE_GATE = 0.09;

/**
 * @typedef {{re: RegExp, common: Array, rare: Array}} LootTable
 * Ordered — `find` takes the FIRST match, so specific patterns come before
 * general ones. The airlock's "EVA SUIT STORAGE" matches SUIT, RACK and
 * STORAGE; it has to hit the suit table.
 */
export const TABLES = [
  // -- alien and anomalous, first because nothing else should catch these -----
  {
    re: /ALIEN|XENO|MONOLITH|RELIC|SHRINE|VAULT/i,
    common: [
      ['sample_tissue_unknown', 1, 2, 0.4], ['sample_chitin_plate', 1, 2, 0.35],
      ['artifact_fragment_a', 1, 1, 0.3], ['mineral_geode_whole', 1, 1, 0.25],
      ['sample_spore_vial', 1, 1, 0.28], ['crystal_void_opal', 1, 1, 0.2],
    ],
    rare: [
      ['artifact_lattice_core', 1, 1, 0.5], ['artifact_song_shard', 1, 1, 0.4],
      ['data_xeno_index', 1, 1, 0.45], ['artifact_still_water', 1, 1, 0.22],
    ],
  },
  // -- weapons and ordnance ---------------------------------------------------
  {
    re: /ARMOUR|ARMORY|ARMOURY|ORDNANCE|MAGAZINE|WEAPON|GUN/i,
    common: [
      ['ammo_slug', 2, 5, 0.6], ['ammo_cell', 2, 4, 0.5],
      ['ammo_slug_frang', 1, 3, 0.3], ['ammo_slug_ap', 1, 2, 0.25],
      ['ammo_cell_heavy', 1, 2, 0.2], ['tool_wrench_set', 1, 1, 0.12],
      /**
       * THE ARMS LOCKER HOLDS ARMS (0.50.0).
       *
       * It held ammunition and nothing to fire it with, which was survivable
       * while nothing aboard could be shot. Two of the four backgrounds start
       * with no weapon at all, and a boarded hull now has things on it that
       * have to be killed — so a company lifer who never bought a sidearm has
       * one findable place to get one, and it is the one place a ship would
       * actually keep it.
       */
      ['weapon_pistol', 1, 1, 0.4],
    ],
    rare: [
      ['mod_barrel_long', 1, 1, 0.4], ['mod_sight_thermal', 1, 1, 0.35],
      ['mod_cell_overcharge', 1, 1, 0.3], ['weapon_service_kit', 1, 1, 0.4],
      ['weapon_carbine', 1, 1, 0.3], ['weapon_cutter', 1, 1, 0.35],
    ],
  },
  // -- the airlock stores -----------------------------------------------------
  {
    re: /SUIT|EVA|AIRLOCK/i,
    common: [
      ['suit_visor_film', 1, 2, 0.4], ['suit_seal_grease', 1, 1, 0.35],
      ['suit_co2_cartridge', 1, 1, 0.3], ['suit_dosimeter_strip', 1, 3, 0.35],
      ['suit_eva_tether', 1, 1, 0.18], ['suit_jet_charge', 1, 1, 0.2],
      ['o2_canister', 1, 2, 0.35], ['suit_patch', 1, 1, 0.3],
      ['suit_lamp_cell', 1, 2, 0.22], ['suit_glove_liner', 1, 1, 0.18],
    ],
    rare: [
      ['suit_mag_boots', 1, 1, 0.45], ['mod_suit_rebreather', 1, 1, 0.35],
      ['mod_suit_ablative', 1, 1, 0.3], ['suit_jet_charge', 2, 3, 0.4],
    ],
  },
  // -- science and survey -----------------------------------------------------
  {
    re: /LAB|ASSAY|SURVEY|SCIENCE|SAMPLE|SPECIMEN/i,
    common: [
      ['sample_microbe_culture', 1, 2, 0.4], ['mineral_regolith', 1, 3, 0.4],
      ['tool_sample_tongs', 1, 1, 0.2], ['data_survey_partial', 1, 1, 0.25],
      ['sample_seed_alien', 1, 1, 0.18], ['trade_bio_samples', 1, 1, 0.2],
    ],
    rare: [
      ['tool_spectro_pen', 1, 1, 0.4], ['data_xeno_index', 1, 1, 0.3],
      ['sample_fluid_amber', 1, 1, 0.35], ['data_deep_chart', 1, 1, 0.3],
    ],
  },
  // -- engineering and the machine spaces --------------------------------------
  {
    re: /ENGINE|REACTOR|MACHIN|WORKSHOP|TOOL|PUMP|CONDUIT/i,
    common: [
      ['salvage_gasket_kit', 1, 2, 0.45], ['salvage_bearing_set', 1, 2, 0.4],
      ['comp_relay_module', 1, 1, 0.3], ['comp_fuse_block', 1, 2, 0.3],
      ['salvage_wire_spool', 1, 2, 0.35], ['fuel_cell_standard', 1, 2, 0.3],
      ['tool_wrench_set', 1, 1, 0.18], ['salvage_filter_stack', 1, 1, 0.3],
    ],
    rare: [
      ['spare_gyro_cage', 1, 1, 0.4], ['spare_fuel_polisher', 1, 1, 0.35],
      ['tool_torch_cutting', 1, 1, 0.3], ['comp_field_coil', 1, 1, 0.3],
      ['mod_hull_bracing', 1, 1, 0.22],
    ],
  },
  // -- the bridge, the core, and anything that stores a number -----------------
  {
    re: /CONSOLE|TERMINAL|BRIDGE|CORE|COMPUTER|ARCHIVE|RECORD/i,
    common: [
      ['data_chip_blank', 1, 2, 0.4], ['nav_orbital_almanac', 1, 1, 0.2],
      ['data_survey_partial', 1, 1, 0.3], ['comp_fuse_block', 1, 1, 0.2],
    ],
    rare: [
      ['data_deep_chart', 1, 1, 0.4], ['data_black_ledger', 1, 1, 0.3],
      ['data_crew_manifest', 1, 1, 0.35], ['nav_beacon_key', 1, 1, 0.25],
    ],
  },
  // -- medical ----------------------------------------------------------------
  {
    re: /SUPPLY|CABINET|MED|INFIRM|SURG/i,
    common: [
      ['bandage', 1, 3, 0.6], ['analgesic', 1, 2, 0.4],
      ['medkit_field', 1, 1, 0.25], ['radaway_dose', 1, 1, 0.2],
      ['burn_gel', 1, 1, 0.3], ['electrolyte_mix', 1, 2, 0.3],
      ['antibiotic', 1, 1, 0.2],
    ],
    rare: [
      ['trauma_kit', 1, 1, 0.45], ['stim_shot', 1, 2, 0.4],
      ['mod_suit_rebreather', 1, 1, 0.2],
    ],
  },
  // -- cargo ------------------------------------------------------------------
  {
    re: /CRATE|CARGO|PALLET|CONTAINER|HOLD/i,
    common: [
      ['salvage_plating_scrap', 1, 3, 0.5], ['salvage_wire_spool', 1, 2, 0.4],
      ['fuel_cell_standard', 1, 2, 0.35], ['power_cell', 1, 2, 0.35],
      ['ration_protein', 1, 2, 0.3], ['hull_plate', 1, 1, 0.2],
      ['trade_machine_parts', 1, 1, 0.15], ['comp_fuse_block', 1, 2, 0.2],
    ],
    rare: [
      ['spare_hatch_actuator', 1, 1, 0.4], ['spare_fuel_polisher', 1, 1, 0.3],
      ['trade_rare_earths', 1, 2, 0.3], ['contra_cut_stones', 1, 1, 0.2],
      ['nav_orbital_almanac', 1, 1, 0.3],
    ],
  },
  // -- personal ---------------------------------------------------------------
  {
    re: /LOCKER|BUNK|FOOT ?LOCKER|WARDROBE/i,
    common: [
      ['ration_bar', 1, 2, 0.45], ['water_pouch', 1, 2, 0.45],
      ['personal_photo_crew', 1, 1, 0.1], ['personal_deck_cards', 1, 1, 0.1],
      ['personal_tags_id', 1, 1, 0.08], ['personal_flask_dented', 1, 1, 0.1],
      ['bandage', 1, 1, 0.3], ['tool_prybar', 1, 1, 0.12],
      ['personal_cassette_mix', 1, 1, 0.09], ['personal_calendar_marked', 1, 1, 0.08],
      ['personal_chess_set', 1, 1, 0.07], ['suit_lamp_cell', 1, 2, 0.22],
    ],
    rare: [
      ['personal_medal_service', 1, 1, 0.35], ['data_crew_manifest', 1, 1, 0.3],
      ['personal_ring_wedding', 1, 1, 0.25], ['personal_letter_unsent', 1, 1, 0.4],
      ['contra_forged_papers', 1, 1, 0.15],
    ],
  },
  // -- general stores ---------------------------------------------------------
  {
    re: /RACK|SHELF|STORAGE|BIN|CHEST/i,
    common: [
      ['salvage_gasket_kit', 1, 2, 0.4], ['salvage_bearing_set', 1, 2, 0.35],
      ['comp_relay_module', 1, 1, 0.25], ['tool_wrench_set', 1, 1, 0.15],
      ['o2_canister', 1, 1, 0.25], ['salvage_filter_stack', 1, 1, 0.3],
      ['ammo_slug', 1, 2, 0.15], ['noisemaker', 1, 1, 0.18],
    ],
    rare: [
      ['tool_borescope', 1, 1, 0.35], ['tool_seal_tester', 1, 1, 0.35],
      ['ammo_cell_heavy', 1, 1, 0.3], ['spare_gyro_cage', 1, 1, 0.25],
    ],
  },
  // -- food -------------------------------------------------------------------
  {
    re: /GALLEY|PANTRY|FRIDGE|MESS/i,
    common: [
      ['ration_stew', 1, 2, 0.5], ['ration_noodle', 1, 3, 0.5],
      ['coffee_pack', 1, 2, 0.4], ['juice_box', 1, 2, 0.35],
      ['ration_curry', 1, 1, 0.2], ['water_can', 1, 1, 0.3],
      ['ration_fish', 1, 1, 0.25],
    ],
    rare: [
      ['personal_recipe_card', 1, 1, 0.4], ['ration_curry', 3, 5, 0.35],
      ['tea_tin', 1, 1, 0.3],
    ],
  },
  // -- what is lying on a world ------------------------------------------------
  {
    re: /WRECK|DEBRIS|HULK|SCATTER|CACHE|DROP|POD/i,
    common: [
      ['salvage_plating_scrap', 1, 4, 0.55], ['salvage_wire_spool', 1, 2, 0.35],
      ['hull_plate', 1, 2, 0.3], ['power_cell', 1, 2, 0.3],
      ['ore_iron_raw', 1, 3, 0.3], ['comp_relay_module', 1, 1, 0.2],
      ['suit_patch', 1, 1, 0.2],
    ],
    rare: [
      ['data_survey_partial', 1, 1, 0.35], ['personal_tags_id', 1, 1, 0.3],
      ['nav_beacon_key', 1, 1, 0.2], ['spare_hatch_actuator', 1, 1, 0.3],
      ['artifact_fragment_a', 1, 1, 0.18],
    ],
  },
];

/** Anything that matched nothing. Thin on purpose — an unnamed surface is not a prize. */
export const GENERIC = {
  common: [
    ['salvage_plating_scrap', 1, 2, 0.35], ['water_pouch', 1, 1, 0.3],
    ['ration_bar', 1, 1, 0.3], ['power_cell', 1, 1, 0.2],
  ],
  rare: [['comp_relay_module', 1, 1, 0.3], ['data_chip_blank', 1, 1, 0.3]],
};

/** The table a label falls into. */
export function tableFor(label) {
  return TABLES.find((t) => t.re.test(String(label))) ?? GENERIC;
}
