/**
 * Orbits — classical two-body orbital mechanics.
 *
 * WHAT THIS REPLACES. Bodies used to move on circles: a radius, an angle, and an
 * angular speed of `K / r^1.5`. The exponent was right, so the *ordering* was
 * right — inner worlds led outer ones — but everything else was wrong in ways
 * that show. Every orbit was perfectly round and exactly on the ecliptic, so the
 * system read as a set of concentric rings on a flat plane. Nothing sped up at
 * periapsis. A comet on a 150 AU orbit tracked at the same steady rate as a
 * planet at 1 AU rather than crawling in the deep and whipping through the inner
 * system. And a moon's orbit was a circle of fixed radius around a parent that
 * was itself on a circle, so the pair could never look like a real hierarchy.
 *
 * This module does it properly, with the six classical Keplerian elements:
 *
 *   a   semi-major axis          size of the orbit
 *   e   eccentricity             0 = circle, →1 = increasingly elongated
 *   i   inclination              tilt of the orbit plane off the reference plane
 *   Ω   longitude of asc. node   where the orbit crosses the plane going north
 *   ω   argument of periapsis    where the closest point sits within the orbit
 *   M₀  mean anomaly at epoch    where the body is along the orbit at t = 0
 *
 * Position comes out by solving Kepler's equation M = E − e·sin E for the
 * eccentric anomaly E, converting to the true anomaly ν, then rotating the
 * in-plane position through ω, i and Ω. Kepler's equation is transcendental —
 * there is no closed form — so it takes Newton–Raphson, which is the one piece
 * of real numerical work in here.
 *
 * SCALE. The game's distances are compressed (see CelestialGen: 1 AU is
 * UNITS_PER_AU units, not 150 million km), and so is the clock — a real orbital
 * period would be invisible over a session. `GRAV_MU` is therefore a game
 * constant chosen so the inner planets take a few minutes, not a physical
 * gravitational parameter. Kepler's third law then does the rest honestly: every
 * period follows T = 2π√(a³/μ), so the relative timing across a system is
 * exactly right even though the absolute clock is not.
 */

const TAU = Math.PI * 2;

/**
 * Gravitational parameter, in game units. Tuned so a body at 12,000 units
 * (1 AU) takes about five minutes to go round, which was the old ORBIT_K
 * behaviour at that radius — so the pacing players already have is preserved
 * while the mechanics underneath become real.
 *
 * T = 2π√(a³/μ) → μ = 4π²a³/T².  a = 12000, T = 300 s → μ ≈ 7.58e8.
 *
 * SLOWED 6× (0.34.0, owner request). Five minutes for an inner planet's whole
 * year meant a world you lined up on had visibly moved by the time you got
 * there, stations swung round their hosts while you were docking, and the
 * system read as a clockwork orrery rather than as space. Period goes as
 * 1/√μ, so dividing μ by 36 multiplies every period by six — an inner world
 * now takes half an hour and the RELATIVE timing across the system, which is
 * the part Kepler's third law gets right, is untouched.
 */
/**
 * WORLDS GOT BIGGER, AND SO DID THE SPACE BETWEEN THEM (0.37.0). Orbital radii
 * are `SPACE_SCALE`× what they were — see CelestialGen — and the third law is
 * ruthless about that: `T = 2π√(a³/μ)`, so cubing the axis multiplies every
 * period by `SPACE_SCALE^1.5`, which at 10/3 is a factor of six. Left alone,
 * an inner planet's year would have gone from half an hour to three.
 *
 * μ therefore takes `SPACE_SCALE³` — the exact compensation, because a³/μ is
 * what the period depends on and nothing else. Every period in the game is
 * bit-for-bit what it was before the rescale, which is the point: the pacing
 * was tuned deliberately last session and a change of units must not silently
 * retune it.
 */
export const SPACE_SCALE = 4.2;

/**
 * SLOWED AGAIN (0.39.0, owner: "slow the orbiting"). The 0.34.0 divisor of 36
 * multiplied every period by six; this one is 324, which is another factor of
 * three on top — an inner world's year is now over an hour and a moon's month
 * is measured in tens of minutes. At this rate a station has effectively
 * stopped moving over the time it takes to fly to it, which is the point: the
 * complaint was never about the numbers, it was that things you were lining up
 * on went somewhere while you were lining up on them.
 */
export const GRAV_MU = (7.58e8 / 324) * SPACE_SCALE ** 3;

/**
 * Gravitational parameter for a PLANET, used by its moons. Far smaller than the
 * star's, which via the third law is exactly why a moon's month is minutes long
 * while its planet's year is an hour — the hierarchy of timescales comes out of
 * the physics instead of being hand-set per body.
 *
 * a = 1000, T = 90 s → μ = 4π²a³/T² ≈ 4.9e6.
 *
 * Slowed by the same factor as the star's, so the hierarchy of timescales the
 * third law produces survives intact: a month is still a fraction of a year,
 * it is just no longer nine seconds of one.
 */
export const MOON_MU = (4.9e6 / 324) * SPACE_SCALE ** 3;

/** Orbital period in seconds for a semi-major axis, by Kepler's third law. */
export function orbitalPeriod(a, mu = GRAV_MU) {
  return TAU * Math.sqrt(Math.max(1, a * a * a) / mu);
}

/** Mean motion — radians of mean anomaly per second. */
export function meanMotion(a, mu = GRAV_MU) {
  return Math.sqrt(mu / Math.max(1, a * a * a));
}

/**
 * Solve Kepler's equation M = E − e·sin(E) for the eccentric anomaly E.
 *
 * Newton–Raphson: f(E) = E − e·sin E − M, f'(E) = 1 − e·cos E.
 *
 * Two details that matter for robustness:
 *
 * - The starting guess is E₀ = M + e·sin(M), not E₀ = M. For near-circular
 *   orbits either converges instantly, but the better seed keeps the iteration
 *   count flat as e climbs toward the comet range, where a naive seed can take
 *   twice as many steps or oscillate.
 * - The derivative 1 − e·cos E approaches zero at periapsis of a very eccentric
 *   orbit, which makes the Newton step blow up. It is floored, which turns a
 *   potential divergence into a slower but safe approach.
 *
 * Converges to ~1e-10 in three or four iterations for anything under e = 0.9.
 *
 * @param {number} M mean anomaly, radians (any range — wrapped internally)
 * @param {number} e eccentricity, 0 ≤ e < 1
 * @returns {number} eccentric anomaly E in radians
 */
export function solveKepler(M, e) {
  // wrap to [-π, π]; Newton behaves best near zero
  let m = M % TAU;
  if (m > Math.PI) m -= TAU;
  else if (m < -Math.PI) m += TAU;

  if (e < 1e-6) return m; // circular — E is M, skip the iteration entirely

  let E = m + e * Math.sin(m);
  for (let k = 0; k < 8; k++) {
    const f = E - e * Math.sin(E) - m;
    if (Math.abs(f) < 1e-10) break;
    // floor the derivative: it tends to (1 - e) at periapsis, which is tiny for
    // a comet and would otherwise throw the step to infinity
    const fp = Math.max(1e-4, 1 - e * Math.cos(E));
    E -= f / fp;
  }
  return E;
}

/**
 * True anomaly from eccentric anomaly. The half-angle form is used rather than
 * acos(...) because it is well-conditioned across the whole orbit and gets the
 * quadrant right without a sign test.
 */
export function trueAnomaly(E, e) {
  const s = Math.sqrt(Math.max(0, 1 + e)) * Math.sin(E / 2);
  const c = Math.sqrt(Math.max(0, 1 - e)) * Math.cos(E / 2);
  return 2 * Math.atan2(s, c);
}

/**
 * Build an element set. Angles in radians. `M0` is the mean anomaly at t = 0,
 * which is what fixes where in its orbit a body starts.
 */
export function makeOrbit({ a, e = 0, i = 0, node = 0, peri = 0, M0 = 0, dir = 1, mu = GRAV_MU }) {
  return {
    a, e, i, node, peri, M0, dir,
    n: meanMotion(a, mu) * (dir >= 0 ? 1 : -1),
    period: orbitalPeriod(a, mu),
    // cached rotation terms — these never change, and the position solve runs
    // for every body every frame
    cosI: Math.cos(i), sinI: Math.sin(i),
    cosN: Math.cos(node), sinN: Math.sin(node),
    cosW: Math.cos(peri), sinW: Math.sin(peri),
  };
}

/**
 * Position on the orbit at time `t`, written into `out` (x, y, z), relative to
 * the focus. The game's reference plane is XZ with Y up, so the standard
 * textbook Z-up result is swizzled on the way out.
 *
 * @param {number[]} out destination [x, y, z]
 * @param {object} o element set from makeOrbit
 * @param {number} t seconds since epoch
 */
export function orbitPosition(out, o, t) {
  const M = o.M0 + o.n * t;
  const E = solveKepler(M, o.e);
  const nu = trueAnomaly(E, o.e);
  // radius from the focus: the conic equation
  const r = o.a * (1 - o.e * Math.cos(E));

  // position in the orbital plane, measured from periapsis
  const px = r * Math.cos(nu);
  const py = r * Math.sin(nu);

  // rotate by argument of periapsis, then inclination, then ascending node.
  // Expanded rather than composed from matrices — this runs per body per frame.
  const cw = o.cosW, sw = o.sinW;
  const x1 = px * cw - py * sw;
  const y1 = px * sw + py * cw;

  const ci = o.cosI, si = o.sinI;
  const x2 = x1;
  const y2 = y1 * ci;
  const z2 = y1 * si; // out of the reference plane

  const cn = o.cosN, sn = o.sinN;
  out[0] = x2 * cn - y2 * sn;
  out[2] = x2 * sn + y2 * cn; // game's second in-plane axis is Z
  out[1] = z2; // game's up axis
  return out;
}

/**
 * Orbital speed at the current radius — the vis-viva equation,
 * v = √(μ·(2/r − 1/a)). Used for the NAV read-out, and it is the number that
 * makes eccentricity legible: a comet at periapsis is genuinely moving an order
 * of magnitude faster than the same comet at aphelion.
 */
export function orbitalSpeed(o, r, mu = GRAV_MU) {
  return Math.sqrt(Math.max(0, mu * (2 / Math.max(1, r) - 1 / Math.max(1, o.a))));
}

/** Periapsis and apoapsis distances — the closest and furthest approach. */
export function apsides(o) {
  return { peri: o.a * (1 - o.e), apo: o.a * (1 + o.e) };
}

// ---------------------------------------------------------------------------
// Ring dynamics
// ---------------------------------------------------------------------------

/**
 * The RIGID Roche limit, in units of the primary's radius:
 *
 *   d = R · (2·ρ_primary / ρ_satellite)^(1/3)
 *
 * Inside it, tidal shear beats a moonlet's self-gravity and it cannot hold
 * together — which is exactly why ring systems exist there and moons do not.
 * This is what sets the INNER edge of a ring: material further in than the
 * Roche limit stays rubble forever.
 *
 * For icy debris around a gas giant the density ratio lands near 2.0–2.5,
 * giving 1.26–1.35 R. Saturn's rings run out to about 2.3 R and its innermost
 * proper moons sit beyond that, which is the pattern this reproduces.
 */
export function rocheLimit(densityRatio = 2.2) {
  return Math.cbrt(2 * densityRatio);
}

/**
 * Mean-motion resonance radii with a shepherd moon.
 *
 * A ring particle at the radius where its orbital period is a simple ratio
 * (p:q) of a moon's period gets a gravitational kick at the same point in every
 * orbit. Those kicks accumulate instead of averaging out, and the particle is
 * pumped onto an eccentric orbit and swept away. The result is a GAP.
 *
 * This is not decorative: the Cassini Division is the 2:1 resonance with Mimas,
 * and the Encke and Keeler gaps are cleared by moonlets embedded in the ring.
 * Deriving the gaps from the moons means a giant with different moons gets a
 * genuinely different ring system rather than a different noise seed.
 *
 * From the third law, a_res = a_moon · (p/q)^(2/3) for the p:q resonance.
 *
 * @param {number} moonA the moon's semi-major axis
 * @returns {{ratio:string, a:number, strength:number}[]} resonance radii inside
 *   the moon's orbit, strongest first
 */
export function resonances(moonA) {
  // Low-order resonances are the strong ones — the kick is coherent over few
  // orbits. 2:1 is the strongest, and strength falls off as the integers grow.
  const ORDERS = [
    [2, 1, 1.00], [3, 1, 0.62], [3, 2, 0.78], [4, 3, 0.45],
    [5, 3, 0.40], [5, 2, 0.34], [7, 3, 0.24],
  ];
  return ORDERS
    .map(([p, q, strength]) => ({
      ratio: `${p}:${q}`,
      a: moonA * Math.pow(q / p, 2 / 3),
      strength,
    }))
    .filter((r) => r.a < moonA * 0.995) // only interior resonances clear a gap
    .sort((a, b) => b.strength - a.strength);
}
