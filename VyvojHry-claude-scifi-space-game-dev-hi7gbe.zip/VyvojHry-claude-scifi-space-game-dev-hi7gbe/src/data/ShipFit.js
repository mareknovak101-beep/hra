/**
 * SHIP FIT — what makes a hull class a different PLACE, not just a shorter one.
 *
 * 0.25.0 gave each class its own compartment list and stopped there, so every
 * hull was the Aethon with rooms deleted: the same grey-green military plating,
 * the same doors, the same fittings, the same names on the same walls. Walk a
 * Petrel and a Drayman back to back and the only difference was how soon you
 * ran out of ship. That is a smaller Aethon, not another vessel.
 *
 * Three levers here, in increasing order of how much they change the read:
 *
 *   FINISH    per-zone texture families, including a default that repaints the
 *             whole corridor spine. A hull whose passages are cargo plating and
 *             grating instead of tiled steel is a different ship from the first
 *             corridor, before you have opened a single door.
 *   REFIT     a kept compartment renamed and re-dressed as something else. The
 *             Harrier's blurb has promised a magazine since 0.25.0 and the room
 *             behind that door was general stores; now it is a magazine. This
 *             is the lever that adds new content rather than recolouring old.
 *   FIT-OUT   class-specific props scattered through compartments both hulls
 *             share, so even the identical rooms are not identical.
 *
 * WHAT THIS DELIBERATELY DOES NOT TOUCH. The spine — cockpit, corridors A-E,
 * the four junctions, cargo bay, airlock, engine room — and every `at`/`center`
 * in CONNECTIONS. See the LEAF_ZONES note in interior/ShipMap.js: re-cutting
 * the deck graph is how the geometry audits of sessions 16f and 16x happened,
 * and finish and dressing buy most of the difference for none of that risk.
 */

/**
 * @typedef {object} ClassFit
 * @property {object} [finish]  zoneId → {wall,floor,ceil}; `default` repaints
 *   every corridor and junction that has no entry of its own
 * @property {object} [refit]   zoneId → {name, dress} — rename and re-dress a
 *   compartment this hull keeps. `dress` names a module in interior/rooms/.
 * @property {string} [note]    one line, for the commission card and the log
 */

/** @type {Record<string, ClassFit>} */
export const SHIP_FITS = {
  /**
   * The reference. The Aethon IS the authored ship and every texture in ShipMap
   * is its finish, so there is nothing to override — an empty fit is the honest
   * way to say that rather than restating the defaults and inviting drift.
   */
  aethon: {
    note: 'Kestrel survey standard. Grey-green plate, tiled wet spaces.',
  },

  /**
   * KSV PETREL — a courier, fitted out by weight.
   *
   * Bare steel and grating everywhere, because panelling is mass. The wet
   * spaces keep their tile (you cannot save weight by not having a floor in the
   * washroom) but everything else is stripped to structure. Storage becomes the
   * dispatch locker: on a mail hull the hold IS the job.
   */
  petrel: {
    finish: {
      default: { wall: 'wall_steel', floor: 'floor_grate', ceil: 'ceiling_pipes' },
      crew_bunks: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' },
      galley: { wall: 'fixture_white', floor: 'floor_plate', ceil: 'ceiling_panel' },
      cargo_bay: { wall: 'wall_steel', floor: 'floor_grate', ceil: 'ceiling_pipes' },
      engine_room: { wall: 'wall_engine', floor: 'floor_grate', ceil: 'ceiling_pipes' },
    },
    refit: {
      storage: { name: 'DISPATCH LOCKER', dress: 'dispatch' },
    },
    note: 'Stripped to structure. Bare steel, open grating, no panelling.',
  },

  /**
   * KSV DRAYMAN — an ore hauler with survey equipment bolted into it.
   *
   * Cargo plating throughout, because the whole ship is a hold with a corridor
   * through it. It runs hot and the reactor spaces show it. There is no doctor
   * on a hauler and never was: the med bay is an assay bench, which is what the
   * compartment was actually used for before the refit paperwork renamed it.
   */
  drayman: {
    finish: {
      default: { wall: 'wall_cargo', floor: 'floor_cargo', ceil: 'ceiling_pipes' },
      crew_bunks: { wall: 'wall_cargo', floor: 'floor_plate', ceil: 'ceiling_panel' },
      galley: { wall: 'wall_tile', floor: 'floor_plate', ceil: 'ceiling_panel' },
      bathroom: { wall: 'fixture_white', floor: 'floor_grate', ceil: 'ceiling_panel' },
      med_bay: { wall: 'wall_cargo', floor: 'floor_hazard', ceil: 'ceiling_pipes' },
      workshop: { wall: 'wall_engine', floor: 'floor_hazard', ceil: 'ceiling_pipes' },
      reactor_room: { wall: 'wall_reactor', floor: 'floor_hazard', ceil: 'ceiling_pipes' },
    },
    refit: {
      med_bay: { name: 'ASSAY BAY', dress: 'assay' },
    },
    note: 'Ore hull. Cargo plate throughout, hazard deck where it runs hot.',
  },

  /**
   * KSV HARRIER — a patrol hull the company bought at auction.
   *
   * Naval grey and hazard decking: it was fitted out by a service that expected
   * to be shot at, and nobody has repainted it. The magazine is the promise the
   * class blurb has been making since 0.25.0 finally standing behind a door.
   */
  harrier: {
    finish: {
      default: { wall: 'wall_military', floor: 'floor_hazard', ceil: 'ceiling_pipes' },
      crew_bunks: { wall: 'wall_military', floor: 'floor_plate', ceil: 'ceiling_panel' },
      galley: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' },
      med_bay: { wall: 'fixture_white', floor: 'floor_plate', ceil: 'ceiling_panel' },
      computer_core: { wall: 'wall_military', floor: 'floor_hazard', ceil: 'ceiling_pipes' },
      cargo_bay: { wall: 'wall_military', floor: 'floor_hazard', ceil: 'ceiling_panel' },
    },
    refit: {
      storage: { name: 'MAGAZINE', dress: 'magazine' },
    },
    note: 'Naval surplus. Grey plate, hazard deck, ordnance where the stores were.',
  },
};

/** The fit for a class id, falling back to the reference hull's empty one. */
export function shipFit(id) {
  return SHIP_FITS[id] ?? SHIP_FITS.aethon;
}
