/**
 * SURFACE GENERATION — what a world is actually LIKE once you are standing on it.
 *
 * `CelestialGen` already derives what a body IS: radius, gravity, temperature,
 * atmosphere, orbit. Everything below the exosphere was fiction — LANDING SITE
 * LOGGED, SURFACE OPS PENDING, printed as a notification and nothing else, for
 * six sessions.
 *
 * This turns the body's own physical figures into a place. Nothing here is
 * invented independently of what the chart already says: the terrain follows
 * from the composition, the sky colour follows from the atmosphere, the hazards
 * follow from the temperature and the pressure, and the ground shakes if the
 * gravity is high enough to make it worth mentioning.
 *
 * TWO PRODUCTS, deliberately separate:
 *
 *   `surfaceProfile(body)` — the DESCRIPTOR. Palette, sky, terrain statistics,
 *   hazard set, resource pools, weather. Cheap, deterministic per body, and it
 *   is what the landing panel and the surface-ops mechanics read.
 *
 *   `buildTerrain(profile, seed)` — the MESH. A heightfield patch under the
 *   landing site, in the ship's own units. Built once per landing, thrown away
 *   on takeoff.
 *
 * The split matters because the descriptor is needed the moment a body is
 * scanned from orbit and the mesh is only needed if you actually commit.
 */
import { RNG } from '../utils/RNG.js';
import { PALETTE } from '../core/Constants.js';
import { landform, provinces, impacts } from './Landforms.js';
import { fbm3, erode, seedDir } from './TerrainNoise.js';

/**
 * TERRAIN ARCHETYPES, keyed by the `kind` CelestialGen already assigns.
 *
 * `relief` is the vertical range in WORLD UNITS across the patch — not a
 * unitless "scale" as it was in the first pass, where 34 became about nine
 * units of actual relief over an eighteen-hundred-unit square and every world
 * came out a painted floor. These numbers are what the skyline is made of, and
 * a value of 600 means the ridge line really is six hundred units above the
 * valley you are standing in.
 *
 * `land` names the field in data/Landforms.js that gives the world its shape;
 * `talus` is the angle of repose the erosion pass sands everything down to,
 * which is a material property (sand slumps, basalt does not); `rocks`
 * describes what is scattered ON the ground, which is most of what tells you
 * how big everything else is.
 *
 * `rough` survives only as a texture-grain multiplier. `ground`/`accent` are
 * the two ends of the surface ramp, `sky` is the horizon wash, and `haze` is
 * how much of the distance the atmosphere eats — the single strongest cue for
 * how thick the air is.
 */
const TERRAIN = {
  rocky: {
    name: 'CRATERED REGOLITH', relief: 300, rough: 0.62, crater: 1.0,
    land: 'plains', land2: 'basin', prov: 0.0, rel2: 1.5, talus: 0.72, rocks: { n: 315, size: 9, mix: ['boulder', 'boulder', 'cobble', 'slab', 'shard', 'plate'] },
    ground: '#5a5148', accent: '#8b8073', sky: '#0a0b10', haze: 0.05,
    feature: ['a crater rim you could park a barge in', 'ejecta rays still sharp after a billion years',
      'a boulder field the survey chart does not mention', 'rille systems running to the horizon'],
    finds: ['mineral_regolith', 'mineral_basalt_core', 'ore_iron_raw', 'ore_nickel_raw',
      'mineral_magnetite_lump', 'crystal_void_opal'],
  },
  desert: {
    name: 'DUNE SEA', relief: 190, rough: 0.24, crater: 0.15,
    land: 'dunes', land2: 'mesas', prov: -0.10, rel2: 2.4, talus: 0.30, rocks: { n: 147, size: 7, mix: ['slab', 'cobble', 'hoodoo', 'arch', 'rib', 'plate'] },
    ground: '#8a6f45', accent: '#c2a171', sky: '#3a2c1c', haze: 0.34,
    feature: ['transverse dunes marching to the horizon', 'a wind-scoured yardang field',
      'a dry pan crusted white with salt', 'half-buried survey markers, decades old'],
    finds: ['mineral_salt_crystal', 'mineral_olivine_sand', 'ore_copper_raw',
      'mineral_geode_whole', 'crystal_storm_glass', 'personal_key_nowhere'],
  },
  oceanic: {
    name: 'ARCHIPELAGO SHELF', relief: 290, rough: 0.44, crater: 0.05,
    land: 'shelf', land2: 'fjords', prov: 0.05, rel2: 1.6, talus: 0.68, rocks: { n: 273, size: 8, mix: ['slab', 'boulder', 'cobble', 'stack', 'rib'] },
    ground: '#3d5a4a', accent: '#7aa08a', sky: '#2e4a6a', haze: 0.62,
    feature: ['black basalt headlands and a surf you can hear through the hull',
      'a shallow lagoon the colour of old glass', 'tidal flats going out further than the eye',
      'a stack of sea cliffs with something nesting on them'],
    finds: ['sample_microbe_culture', 'sample_coral_vac', 'mineral_salt_crystal',
      'trade_bio_samples', 'sample_tissue_unknown', 'crystal_red_beryl'],
  },
  jungle: {
    name: 'CANOPY FLOOR', relief: 240, rough: 0.7, crater: 0.0,
    land: 'hills', land2: 'karst', prov: 0.0, rel2: 1.7, talus: 0.80, rocks: { n: 270, size: 11, mix: ['trunk', 'trunk', 'boulder', 'cobble', 'hoodoo'] },
    ground: '#2c4028', accent: '#5c7a44', sky: '#3a4a2e', haze: 0.78,
    feature: ['a canopy so dense the lamp is on at noon', 'buttress roots the size of the airlock',
      'standing water that moves when nothing pushes it', 'a clearing nothing has grown back into'],
    finds: ['sample_spore_vial', 'sample_tissue_unknown', 'sample_seed_alien',
      'trade_bio_samples', 'sample_chitin_plate', 'sample_nest_fragment'],
  },
  ice: {
    name: 'GLACIAL PLAIN', relief: 330, rough: 0.5, crater: 0.4,
    land: 'icefield', land2: 'fjords', prov: -0.05, rel2: 1.3, talus: 0.85, rocks: { n: 273, size: 14, mix: ['spire', 'needle', 'slab', 'cobble', 'arch'] },
    ground: '#6f8698', accent: '#c2d4e0', sky: '#16202e', haze: 0.22,
    feature: ['pressure ridges shouldering up out of the sheet', 'a crevasse field with no safe line through it',
      'blue ice under a metre of old snow', 'nitrogen frost that sublimes where the lamp touches it'],
    finds: ['mineral_ice_ancient', 'trade_ice_cores', 'crystal_cryo_lattice',
      'gas_methane_cryo', 'sample_microbe_culture', 'mineral_regolith'],
  },
  tundra: {
    name: 'FROZEN STEPPE', relief: 180, rough: 0.42, crater: 0.2,
    land: 'polygons', land2: 'foldbelt', prov: -0.05, rel2: 2.2, talus: 0.55, rocks: { n: 315, size: 7, mix: ['boulder', 'cobble', 'cobble', 'slab', 'rib'] },
    ground: '#5c5c4a', accent: '#9a9a7a', sky: '#243040', haze: 0.4,
    feature: ['patterned ground, polygons to the horizon', 'a frozen river course cut deep',
      'olive lichen on every south face', 'wind that has not stopped since the survey began'],
    finds: ['mineral_regolith', 'ore_iron_raw', 'sample_microbe_culture',
      'mineral_basalt_core', 'crystal_cryo_lattice', 'ration_fruit'],
  },
  lava: {
    name: 'ACTIVE BASALT', relief: 380, rough: 0.92, crater: 0.3,
    land: 'flows', land2: 'volcano', prov: -0.05, rel2: 3.4, talus: 1.05, rocks: { n: 346, size: 8, mix: ['slab', 'boulder', 'vent', 'vent', 'cobble', 'shard'] },
    ground: '#3a2018', accent: '#b0501c', sky: '#2a0e08', haze: 0.5, glow: '#e08a30',
    feature: ['a lava tube you could fly the ship down', 'pahoehoe still cooling and still moving',
      'a fountain on the far ridge, throwing a hundred metres', 'ground that reads eleven hundred through the boot'],
    finds: ['ore_titanium_raw', 'ore_tungsten_raw', 'mineral_basalt_core',
      'mineral_sulfur_chunk', 'ore_iridium_raw', 'crystal_storm_glass'],
  },
  sulfur: {
    name: 'SULPHUR PLAIN', relief: 400, rough: 0.66, crater: 0.25,
    land: 'terraces', land2: 'rift', prov: 0.0, rel2: 1.5, talus: 0.90, rocks: { n: 273, size: 9, mix: ['spire', 'vent', 'hoodoo', 'cobble', 'shard'] },
    ground: '#7a6420', accent: '#c8b04a', sky: '#4a3a10', haze: 0.55,
    feature: ['yellow plains repainted since the last chart', 'a vent throwing a plume you can see from orbit',
      'crusted pools that give under weight', 'the smell gets into the suit scrubbers and stays'],
    finds: ['mineral_sulfur_chunk', 'gas_volatile_mix', 'ore_cobalt_raw',
      'crystal_storm_glass', 'mineral_geode_whole', 'gas_helium3'],
  },
  toxic: {
    name: 'PRESSURE FLOOR', relief: 120, rough: 0.36, crater: 0.1,
    land: 'flats', land2: 'badlands', prov: -0.05, rel2: 2.8, talus: 0.34, rocks: { n: 178, size: 6, mix: ['boulder', 'cobble', 'plate', 'rib'] },
    ground: '#6a5230', accent: '#a08248', sky: '#5a3c14', haze: 0.9,
    feature: ['visibility of forty metres and falling', 'a surface nobody has photographed twice',
      'pressure that folds the sample tongs on the first try', 'lightning somewhere above the cloud deck'],
    finds: ['gas_volatile_mix', 'mineral_sulfur_chunk', 'ore_thorium_raw',
      'sample_fluid_amber', 'crystal_void_opal', 'gas_xenon'],
  },
  carbon: {
    name: 'GRAPHITE CRUST', relief: 300, rough: 0.58, crater: 0.5,
    land: 'shards', land2: 'pinnacles', prov: -0.05, rel2: 1.2, talus: 1.15, rocks: { n: 367, size: 10, mix: ['slab', 'shard', 'shard', 'needle', 'cobble', 'stack'] },
    ground: '#1e1e22', accent: '#5a5a64', sky: '#0c0c10', haze: 0.12,
    feature: ['soot that takes a bootprint and keeps it', 'diamond in the fracture faces, catching the lamp',
      'tar pooled where the light collects', 'a crust that rings hollow underfoot'],
    finds: ['crystal_void_opal', 'ore_iridium_raw', 'mineral_geode_whole',
      'contra_cut_stones', 'ore_thorium_raw', 'mineral_basalt_core'],
  },
  metal: {
    name: 'EXPOSED CORE', relief: 620, rough: 0.74, crater: 0.8,
    land: 'mountains', land2: 'rift', prov: 0.0, rel2: 0.8, talus: 0.98, rocks: { n: 315, size: 13, mix: ['spire', 'slab', 'plate', 'plate', 'cobble', 'stack'] },
    ground: '#4a4e56', accent: '#9aa2b0', sky: '#0a0c12', haze: 0.04,
    feature: ['bare nickel-iron, mirror-bright where the last strike scoured it',
      'a shear face two hundred metres high', 'the compass is useless and knows it',
      'assay reads like a shipyard inventory'],
    finds: ['ore_nickel_pure', 'ore_iron_refined', 'ore_iridium_raw', 'ore_cobalt_raw',
      'alloy_invar_rod', 'ore_tungsten_raw'],
  },
  moon: {
    name: 'AIRLESS REGOLITH', relief: 480, rough: 0.6, crater: 1.2,
    land: 'plains', land2: 'basin', prov: 0.05, rel2: 1.9, talus: 0.66, rocks: { n: 388, size: 8, mix: ['boulder', 'cobble', 'cobble', 'slab', 'plate'] },
    ground: '#54514c', accent: '#8a8680', sky: '#08090d', haze: 0.0,
    feature: ['craters inside craters inside craters', 'a shadow with an edge like a cut',
      'dust that hangs where you kick it and comes down all at once',
      'the primary filling a third of the sky'],
    finds: ['mineral_regolith', 'ore_iron_raw', 'mineral_magnetite_lump',
      'gas_helium3', 'mineral_basalt_core', 'crystal_void_opal'],
  },
  /**
   * 0.48.0 — four more archetypes, and each one exists because there was a
   * silhouette the route could not produce. An ash plain reads nothing like a
   * lava world (the eruption is OVER); a dried seabed is the only flat that is
   * flat for a reason; banded iron is the only world whose strata are the whole
   * landscape rather than a detail on a cliff; and a crystal field is the only
   * place where the things standing up are not rock.
   */
  ashen: {
    name: 'ASH PLAIN', relief: 250, rough: 0.5, crater: 0.35,
    land: 'flats', land2: 'volcano', prov: -0.05, rel2: 3.0, talus: 0.42, rocks: { n: 320, size: 8, mix: ['cobble', 'cobble', 'boulder', 'vent', 'plate', 'hoodoo'] },
    ground: '#3e3a38', accent: '#8a8078', sky: '#2a2420', haze: 0.62,
    feature: ['ash to the ankle and no wind to move it', 'cinder cones in a line, all the same age',
      'a pumice raft that never reached water', 'footprints from an hour ago, already softening'],
    finds: ['mineral_basalt_core', 'mineral_sulfur_chunk', 'ore_titanium_raw',
      'mineral_regolith', 'crystal_storm_glass', 'ore_iron_raw'],
  },
  saltflat: {
    name: 'DRIED SEABED', relief: 110, rough: 0.28, crater: 0.3,
    land: 'polygons', land2: 'basin', prov: 0.10, rel2: 2.6, talus: 0.32, rocks: { n: 150, size: 7, mix: ['slab', 'cobble', 'plate', 'rib', 'hoodoo'] },
    ground: '#8e8878', accent: '#ded4bc', sky: '#5a5240', haze: 0.44,
    feature: ['salt polygons to the horizon, each one a metre across',
      'a tide line eighty metres up a cliff that has no sea below it',
      'evaporite terraces stepping down to nothing', 'something\'s skeleton, articulated, enormous'],
    finds: ['mineral_salt_crystal', 'mineral_geode_whole', 'sample_microbe_culture',
      'crystal_storm_glass', 'ore_copper_raw', 'mineral_olivine_sand'],
  },
  ferrous: {
    name: 'BANDED IRON', relief: 430, rough: 0.66, crater: 0.6,
    land: 'foldbelt', land2: 'mesas', prov: 0.0, rel2: 1.4, talus: 0.88, rocks: { n: 300, size: 9, mix: ['slab', 'boulder', 'plate', 'stack', 'cobble', 'shard'] },
    ground: '#6a4232', accent: '#c08a52', sky: '#2e1c14', haze: 0.16,
    feature: ['strata in rust and grey, a thousand of them, each a summer',
      'a shear face where the bands go vertical', 'ore so pure the assay reads like a shipyard invoice',
      'the compass swings and keeps swinging'],
    finds: ['ore_iron_refined', 'ore_nickel_pure', 'mineral_magnetite_lump',
      'ore_cobalt_raw', 'alloy_invar_rod', 'ore_iron_raw'],
  },
  crystal: {
    name: 'CRYSTAL FIELD', relief: 390, rough: 0.72, crater: 0.45,
    land: 'pinnacles', land2: 'shards', prov: 0.05, rel2: 1.3, talus: 1.25, rocks: { n: 340, size: 11, mix: ['shard', 'shard', 'needle', 'cobble', 'arch', 'plate'] },
    ground: '#2e3440', accent: '#8aa2b8', sky: '#0e1420', haze: 0.10,
    feature: ['a forest of shards taller than the ship, all leaning one way',
      'they ring when the ground moves and the ground moves often',
      'growth rings, in something that should not have them',
      'the lamp goes further than it should and comes back wrong'],
    finds: ['crystal_void_opal', 'crystal_red_beryl', 'crystal_storm_glass',
      'mineral_geode_whole', 'crystal_cryo_lattice', 'contra_cut_stones'],
  },
  comet: {
    name: 'DIRTY ICE', relief: 380, rough: 0.86, crater: 0.3,
    land: 'chaos', land2: 'pinnacles', prov: -0.05, rel2: 1.1, talus: 1.35, rocks: { n: 325, size: 12, mix: ['spire', 'needle', 'shard', 'cobble', 'arch'] },
    ground: '#3a4046', accent: '#8a9aa6', sky: '#06070c', haze: 0.0,
    feature: ['a jet going off two hundred metres away, silently', 'ice under a metre of black crust',
      'gravity you could jump off', 'the tail overhead, from underneath'],
    finds: ['mineral_ice_ancient', 'crystal_cryo_lattice', 'gas_methane_cryo',
      'trade_ice_cores', 'sample_microbe_culture', 'artifact_fragment_a'],
  },
};

/** Gas giants and stars: there is no surface, and saying so is the point. */
const NO_SURFACE = new Set(['gas', 'star']);

/**
 * HAZARDS. Chosen by the body's own figures rather than rolled, so the danger
 * on the ground is the danger the NAV panel already warned you about.
 */
function hazardsFor(body, profile) {
  const out = [];
  const t = profile.tempC;
  const g = profile.gravity;
  if (t > 120) out.push({ id: 'heat', text: 'SURFACE HEAT — SUIT COOLING AT MAXIMUM', health: 9, o2: 4 });
  if (t < -120) out.push({ id: 'cold', text: 'CRYOGENIC SURFACE — THE SUIT HEATERS ARE LOSING', health: 6, o2: 6 });
  if (g > 1.6) out.push({ id: 'grav', text: 'HIGH GRAVITY — EVERY STEP COSTS', health: 5, o2: 8 });
  if (profile.haze > 0.7) out.push({ id: 'press', text: 'ATMOSPHERIC PRESSURE — SEALS COMPLAINING', health: 8, o2: 5 });
  if (profile.glow) out.push({ id: 'lava', text: 'GROUND GAVE WAY OVER A TUBE', health: 18, o2: 0 });
  if (/rad|thorium|metal/.test(profile.name.toLowerCase()) || body.kind === 'metal') {
    out.push({ id: 'rad', text: 'THE ROCK IS HOT — DOSIMETER CLIMBING', health: 0, o2: 0, rad: 16 });
  }
  // Every world gets the boring one, so no site is risk-free.
  out.push({ id: 'fall', text: 'LOOSE FOOTING — YOU GO DOWN HARD', health: 7, o2: 2 });
  return out;
}

/**
 * The whole descriptor for standing on `body`.
 *
 * Deterministic in the body's id: the same world is the same place every time
 * you come back to it, which is what makes a landing site somewhere you can
 * return to rather than a fresh roll.
 */
export function surfaceProfile(body) {
  if (!body || NO_SURFACE.has(body.kind)) return null;
  const t = TERRAIN[body.kind] ?? TERRAIN.rocky;
  const rng = new RNG(hash(body.id ?? body.name ?? 'x'));
  // `gravity` and `temp` are DISPLAY STRINGS on a body — "0.85 g", "+16 °C" —
  // because they were authored for the NAV panel. Reading them as numbers gave
  // a NaN landing-fuel cost that propagated all the way to the entry heat term
  // and silently made every descent free. Parse, don't assume.
  const g = num(body.gravity, 0.8);
  const profile = {
    ...t,
    bodyId: body.id,
    bodyName: body.name,
    gravity: g,
    tempC: num(body.temp ?? body.tempC, 0),
    // Breathable is rare and worth flagging hard: it is the difference between
    // a site you can work all day and one the suit is counting down through.
    breathable: /breathable/i.test(body.atmosphere ?? ''),
    atmosphere: body.atmosphere ?? 'None',
    // One feature line per site, drawn once and kept.
    feature: t.feature[rng.int(0, t.feature.length - 1)],
    // Site count: how many places on this world are worth walking to. Bigger,
    // more varied worlds have more.
    sites: Math.max(2, Math.min(6, Math.round(2 + (body.realRadiusKm ?? 3000) / 2600 + rng.next() * 1.5))),
    /**
     * THE BODY'S RADIUS IN METRES — the number that turns a patch into a planet.
     *
     * `body.radius` is in SPACE units, where one unit is about 1.3 km, and it is
     * the right number for drawing the world from orbit. The ground is in
     * WALKER units, where one unit is a metre and the pilot is 1.6 of them. The
     * two scales differ by more than a thousand, and confusing them is how you
     * get a player two kilometres tall. This is the chart's own figure in the
     * ground's own units, and everything spherical is derived from it.
     *
     * Floored well below any real world: a small asteroid genuinely does have a
     * horizon you can see the curve of, and that is worth having.
     */
    radiusM: Math.max(4e4, (body.realRadiusKm ?? 3000) * 1000),
    seed: hash(body.id ?? body.name ?? 'x'),
  };
  // Where the default landing site is, until a descent says otherwise. A world
  // is a whole sphere now, so "the landing site" has to be a direction on it.
  profile.padDir = seedDir([0, 0, 0], profile.seed ^ 0x51a2);
  profile.padHeight = fieldHeight(profile, profile.padDir);
  profile.hazards = hazardsFor(body, profile);
  // Landing DIFFICULTY, and it is the gravity and the air that set it: a heavy
  // world wants more fuel to arrest on, and a thick one buffets you the whole
  // way down.
  profile.entryHeat = 0.25 + profile.haze * 1.5;
  profile.landingFuel = Math.round(6 + g * 9 + profile.haze * 6);
  return profile;
}

/**
 * The raw ground height at one direction on the body, with no cap and no mesh.
 *
 * Two callers, both of which need a height BEFORE there is anything built: the
 * profile, to know how high the default landing site sits, and `setLandingSite`
 * when a descent picks a different one. Cheap — one field evaluation — and it
 * agrees with the mesh because it is the same field, minus the erosion pass
 * that only a grid can run.
 */
export function fieldHeight(profile, dir) {
  const F = profile.radiusM / FEAT_M;
  const field = profile.land2
    ? provinces(landform(profile.land), landform(profile.land2),
      profile.prov ?? 0, profile.rel2 ?? 1)
    : landform(profile.land ?? 'plains');
  const P = [dir[0] * F, dir[1] * F, dir[2] * F, dir[0], dir[1], dir[2]];
  const relief = profile.relief ?? 200;
  const detail = relief * 0.045 * (0.55 + profile.rough * 0.9);
  return (field(P, profile.seed) + impacts(P, profile.seed, profile.crater ?? 0)) * relief
    + fbm3(P[0] * 10, P[1] * 10, P[2] * 10, profile.seed + 8123, 3, 2.2, 0.45) * detail;
}

/**
 * WHERE YOU CAME DOWN. Called at the moment a descent commits, with the
 * direction the ship was over.
 *
 * This is the whole difference between "a world has a landing site" and "a world
 * has one landing site": the pad is a place on the sphere, chosen by where you
 * were in orbit, so two descents onto the same body from different approaches
 * put you on genuinely different ground — and walking away from the ship still
 * leaves the ship where you parked it, because the flattened disc travels with
 * the site rather than with the mesh.
 */
export function setLandingSite(profile, dir) {
  const m = Math.hypot(dir[0], dir[1], dir[2]) || 1;
  profile.padDir = [dir[0] / m, dir[1] / m, dir[2] / m];
  profile.padHeight = fieldHeight(profile, profile.padDir);
  return profile.padDir;
}

/**
 * THE BODY FRAME — where on the world you are, and which way is up there.
 *
 * A surface used to be a square with a wall round it: `buildTerrain` made a
 * 3200-unit patch, the walker was clamped inside it, and that was the planet.
 * Everything below exists to remove that wall.
 *
 * A frame is a point on the body's sphere (`c`, a unit direction) plus two
 * tangents (`t`, `b`). The mesh is a CAP around `c`, expressed in the frame's
 * own local coordinates so that every consumer — the renderer, the walker, the
 * flight controller, the collision — keeps working in the flat-ish local space
 * it already understands. When you travel far enough the frame slides to where
 * you are and the cap is rebuilt around the new centre.
 *
 * WHY NOTHING JUMPS WHEN IT SLIDES. The height field is a pure function of the
 * DIRECTION on the sphere, so the rebuilt cap contains exactly the same ground.
 * The new frame is the old one rigidly rotated (parallel transport, no twist),
 * so a heading expressed in frame components is unchanged, and the player's own
 * local coordinates go to the origin. The physical world, the physical heading
 * and the physical position are all identical either side of the swap; only the
 * numbers describing them change, and they change together.
 */
export function makeFrame(dir) {
  const c = norm3([dir[0], dir[1], dir[2]]);
  // Any helper axis not parallel to c. The choice is arbitrary — the frame's
  // spin about its own centre never matters, because nothing outside reads it.
  const helper = Math.abs(c[1]) > 0.94 ? [1, 0, 0] : [0, 1, 0];
  const t = norm3(cross3(helper, c));
  const b = cross3(c, t);
  return { c, t, b };
}

/** Tangent offsets (u,v) in metres → the unit direction they land on. */
export function frameDir(out, frame, u, v, R) {
  const s = Math.hypot(u, v);
  const { c, t, b } = frame;
  if (s < 1e-9) { out[0] = c[0]; out[1] = c[1]; out[2] = c[2]; return out; }
  // Azimuthal equidistant: the tangent offset IS arc length, so a walker who
  // covers five metres of local x has covered five metres of ground. Anything
  // else would make the terrain stretch under your feet as you crossed the cap.
  const a = s / R;
  const k = Math.sin(a) / s, ca = Math.cos(a);
  out[0] = c[0] * ca + (t[0] * u + b[0] * v) * k;
  out[1] = c[1] * ca + (t[1] * u + b[1] * v) * k;
  out[2] = c[2] * ca + (t[2] * u + b[2] * v) * k;
  const m = Math.hypot(out[0], out[1], out[2]) || 1;
  out[0] /= m; out[1] /= m; out[2] /= m;
  return out;
}

/**
 * Slide the frame so its centre lands on the point currently at (u,v), by
 * PARALLEL TRANSPORT — the whole basis is turned by the same rotation that
 * takes the old centre to the new one, with no twist about the new centre.
 * That is what makes a heading's components survive the move untouched.
 */
export function slideFrame(frame, u, v, R) {
  const c2 = frameDir([0, 0, 0], frame, u, v, R);
  const ax = cross3(frame.c, c2);
  const sn = Math.hypot(ax[0], ax[1], ax[2]);
  if (sn < 1e-12) { frame.c = c2; return frame; }
  ax[0] /= sn; ax[1] /= sn; ax[2] /= sn;
  const ang = Math.atan2(sn, dot3(frame.c, c2));
  frame.t = norm3(rot3(frame.t, ax, ang));
  frame.b = norm3(rot3(frame.b, ax, ang));
  frame.c = c2;
  // Re-orthonormalise: a few hundred slides of accumulated float drift would
  // otherwise shear the basis, and a sheared basis stretches the ground.
  frame.t = norm3(sub3(frame.t, scale3(frame.c, dot3(frame.t, frame.c))));
  frame.b = cross3(frame.c, frame.t);
  return frame;
}

const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross3 = (a, b) => [
  a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const sub3 = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const scale3 = (a, k) => [a[0] * k, a[1] * k, a[2] * k];
function norm3(a) {
  const m = Math.hypot(a[0], a[1], a[2]) || 1;
  return [a[0] / m, a[1] / m, a[2] / m];
}
/** Rodrigues rotation of `v` about unit axis `k` by `ang`. */
function rot3(v, k, ang) {
  const c = Math.cos(ang), s = Math.sin(ang);
  const kv = cross3(k, v), kd = dot3(k, v) * (1 - c);
  return [v[0] * c + kv[0] * s + k[0] * kd,
    v[1] * c + kv[1] * s + k[1] * kd,
    v[2] * c + kv[2] * s + k[2] * kd];
}

/**
 * One noise unit is this many metres of ground. Everything in data/Landforms.js
 * is written against it: a dune wavelength, a belt width, a crater radius are
 * all quoted in noise units and this is what turns them into a size.
 */
const FEAT_M = 620;

/**
 * BUILD THE GROUND — a cap of the body's sphere around `frame.c`, returned as a
 * `{vertexData, indexData}` pair in the same pos3/normal3/uv2 layout every
 * other mesh in the game uses.
 *
 * WHY A CAP AND NOT THE WHOLE SPHERE. A world is four thousand kilometres
 * across and its ground resolution is twenty metres; the whole globe at that
 * resolution is eight hundred billion triangles. What you can actually SEE from
 * standing height on a body that size is about three and a half kilometres —
 * the geometric horizon — so the cap is built out to a little past that and
 * moved with you. There is no wall, no repeat, and no edge to walk off, because
 * the height at any point is a function of the direction and the cap is only
 * ever a window onto it.
 *
 * The curvature is REAL: vertices sit at `(R + h)` along their own direction,
 * so the ground falls away over the cap exactly as much as it should. On an
 * Earth-sized world that is a couple of metres and you will never notice; on a
 * small moon it is tens of metres and the horizon visibly bends.
 *
 * @param {object} profile from `surfaceProfile`
 * @param {object} frame   from `makeFrame` — where on the body this cap sits
 * @param {number} extent  half-width of the cap in metres
 * @param {number} grid    vertices per side
 */
export function buildTerrain(profile, frame = null, extent = 1600, grid = 161) {
  const it = terrainSteps(profile, frame ?? makeFrame(profile.padDir), extent, grid);
  let r;
  do { r = it.next(); } while (!r.done);
  return r.value;
}

/**
 * THE SAME BUILD, HANDED OUT IN SLICES.
 *
 * A world costs a couple of hundred milliseconds to generate, which is a dozen
 * dropped frames if you spend it all at once — and there are two moments you
 * are guaranteed to need one: when the player commits to a landing and is
 * watching, and when they fly far enough that the cap has to move under them.
 *
 * `step` runs the generator until its time budget is gone and returns null
 * while there is more to do, the finished terrain when there is not. The caller
 * (gameplay/Landing.js) drives it behind the ionisation envelope on the way in,
 * and in the background — with the old cap still on screen — while flying.
 *
 * @param {number} budgetMs work to do per call, in milliseconds
 */
export function terrainJob(profile, frame = null, extent = 1600, grid = 161) {
  const it = terrainSteps(profile, frame ?? makeFrame(profile.padDir), extent, grid);
  let done = null;
  return {
    get done() { return done; },
    step(budgetMs = 6) {
      if (done) return done;
      const t0 = performance.now();
      // At least one slice per call, however tight the budget: a zero-progress
      // pump on a slow frame would stall the build exactly when the frame rate
      // is already suffering, which is the wrong way round.
      do {
        const r = it.next();
        if (r.done) { done = r.value; return done; }
      } while (performance.now() - t0 < budgetMs);
      return null;
    },
  };
}

/** Yields between stages and every `ROWS_PER_SLICE` rows of the big loops. */
const ROWS_PER_SLICE = 16;

function* terrainSteps(profile, frame, extent, grid) {
  const seed = profile.seed | 0;
  const verts = [];
  const indices = [];
  const H = new Float32Array(grid * grid);
  /** Unit direction per vertex — the geographic position, kept for the colour pass. */
  const DIR = new Float32Array(grid * grid * 3);
  const step = (extent * 2) / (grid - 1);
  // TWO PROVINCES, not one field corner to corner. See Landforms.provinces —
  // the uniformity of a single field was doing more damage to these worlds than
  // any shortfall in relief, because a landscape with nothing new in any
  // direction stops being a place the moment you turn round in it.
  const field = profile.land2
    ? provinces(landform(profile.land), landform(profile.land2),
      profile.prov ?? 0, profile.rel2 ?? 1)
    : landform(profile.land ?? 'plains');
  const relief = profile.relief ?? 200;
  const talus = profile.talus ?? 0.7;
  const crater = profile.crater ?? 0;
  const R = profile.radiusM;
  const F = R / FEAT_M;
  const P = [0, 0, 0, 0, 0, 0];
  const N = [0, 0, 0];

  /** Fill the shared scratch from a unit direction. See Landforms' P layout. */
  const setP = (n) => {
    P[0] = n[0] * F; P[1] = n[1] * F; P[2] = n[2] * F;
    P[3] = n[0]; P[4] = n[1]; P[5] = n[2];
  };

  // -- 1. the landform, sampled ON THE SPHERE ---------------------------------
  // One call per vertex into the archetype's own field (data/Landforms.js),
  // plus the global impact record. The field is normalised, so `relief` alone
  // decides how tall this world is and the shape does not change when it is
  // retuned.
  for (let j = 0; j < grid; j++) {
    const v = -extent + j * step;
    for (let i = 0; i < grid; i++) {
      const u = -extent + i * step;
      frameDir(N, frame, u, v, R);
      const k = j * grid + i;
      DIR[k * 3] = N[0]; DIR[k * 3 + 1] = N[1]; DIR[k * 3 + 2] = N[2];
      setP(N);
      H[k] = (field(P, seed) + impacts(P, seed, crater)) * relief;
    }
    if (j % ROWS_PER_SLICE === 0) yield;
  }

  // -- 2. erosion --------------------------------------------------------------
  // Thermal talus. This is the pass that turns noise into landscape: valley
  // floors flatten, cliff bases gain scree, and nothing stands steeper than the
  // material allows. Cheap, and no amount of extra noise octaves substitutes
  // for it, because these are consequences of a process rather than shapes.
  //
  // Six passes, one slice each: it is the single most expensive stage and one
  // sweep of the grid is about as much work as a frame can absorb.
  //
  // It is the ONE stage that is not a pure function of direction — it looks at
  // neighbours in the cap's own grid — so a cap boundary can differ by a metre
  // or two from where the same ground sat in the previous cap. At six passes of
  // a quarter-excess move that is well under the detail octave's own amplitude,
  // and it is invisible against the swap being hidden by distance.
  for (let e = 0; e < 6; e++) { erode(H, grid, step, talus, 1); yield; }

  // -- 2b. surface detail, AFTER the erosion ----------------------------------
  // Erosion is what makes the large forms read, and it is also what sands off
  // everything at grid scale — so a world with a beautiful skyline had a
  // billiard-table plain in front of it. This is the loose material ON the
  // eroded surface: a few metres of high-frequency noise, applied last so
  // nothing smooths it away, at an amplitude the walker does not notice but the
  // raking light very much does. Sampled off the DIRECTION, so it stays put
  // when the cap moves.
  const detail = relief * 0.045 * (0.55 + profile.rough * 0.9);
  for (let j = 0; j < grid; j++) {
    for (let i = 0; i < grid; i++) {
      const k = j * grid + i;
      const d0 = DIR[k * 3] * F * 10, d1 = DIR[k * 3 + 1] * F * 10, d2 = DIR[k * 3 + 2] * F * 10;
      H[k] += fbm3(d0, d1, d2, seed + 8123, 3, 2.2, 0.45) * detail;
    }
    if (j % ROWS_PER_SLICE === 0) yield;
  }

  // -- 3. the pad --------------------------------------------------------------
  // You have to be able to put a ship down and walk off it, so the ground under
  // the LANDING SITE is levelled and blended out over its own radius.
  //
  // Around `profile.padDir`, not around the middle of the cap: the site is a
  // place on the world now, and the cap moves. Fly a kilometre and the pad is
  // behind you where you left the ship, which is the whole point of it.
  const pad = 50;
  const padH = profile.padHeight;
  const padCos = Math.cos((pad * 2.2) / R);
  const D = profile.padDir;
  for (let j = 0; j < grid; j++) {
    for (let i = 0; i < grid; i++) {
      const k = j * grid + i;
      const c = DIR[k * 3] * D[0] + DIR[k * 3 + 1] * D[1] + DIR[k * 3 + 2] * D[2];
      if (c < padCos) continue;
      const d = Math.acos(Math.min(1, c)) * R;
      const t = Math.max(0, Math.min(1, 1 - (d - pad) / (pad * 1.2)));
      H[k] += (padH - H[k]) * t * t * (3 - 2 * t);
    }
    if (j % ROWS_PER_SLICE === 0) yield;
  }
  yield;

  // -- 3b. CAVITY ---------------------------------------------------------------
  /**
   * WHERE THE LIGHT DOES NOT REACH, computed once and baked into the mesh.
   *
   * The scene has one directional sun and a flat fill, so a hollow and a
   * shoulder at the same slope come out the same value and the ground reads as
   * a corrugated sheet rather than as something with volume. That flatness is
   * the plasticity complaint, and it cannot be fixed by adding relief — the
   * relief was already there.
   *
   * Real ambient occlusion needs to know how much sky a point can see, and the
   * cheap honest proxy for that on a heightfield is how far the point sits above
   * its own neighbourhood: a separable box blur, then `h - blur`. Positive on
   * ridges, crests and boulder tops; negative in gullies, crater floors and the
   * inside corner of every scarp. It costs two sweeps of the grid and it is what
   * makes the ground look like it is made of something.
   *
   * Baked into the vertex `v` coordinate, so the terrain ramp's row axis stops
   * being decorative grain and becomes a SHADE axis. No shader change, no extra
   * texture, no second draw call.
   */
  const BR = 5;                                    // blur radius in cells
  const tmp = new Float32Array(grid * grid);
  const blur = new Float32Array(grid * grid);
  for (let j = 0; j < grid; j++) {
    for (let i = 0; i < grid; i++) {
      let acc = 0, n = 0;
      for (let d = -BR; d <= BR; d++) {
        const ii = i + d;
        if (ii < 0 || ii >= grid) continue;
        acc += H[j * grid + ii]; n++;
      }
      tmp[j * grid + i] = acc / n;
    }
    if (j % ROWS_PER_SLICE === 0) yield;
  }
  for (let j = 0; j < grid; j++) {
    for (let i = 0; i < grid; i++) {
      let acc = 0, n = 0;
      for (let d = -BR; d <= BR; d++) {
        const jj = j + d;
        if (jj < 0 || jj >= grid) continue;
        acc += tmp[jj * grid + i]; n++;
      }
      blur[j * grid + i] = acc / n;
    }
    if (j % ROWS_PER_SLICE === 0) yield;
  }

  // -- 4. emit -----------------------------------------------------------------
  const at = (i, j) => H[Math.max(0, Math.min(grid - 1, j)) * grid + Math.max(0, Math.min(grid - 1, i))];
  let lo = Infinity, hi = -Infinity;
  for (let k = 0; k < H.length; k++) { if (H[k] < lo) lo = H[k]; if (H[k] > hi) hi = H[k]; }
  const span = Math.max(1, hi - lo);
  // Normaliser for the cavity term: the typical local departure from the blur,
  // not the global range, or a world with one big mountain would have flat
  // shading everywhere else.
  let cavScale = 0;
  for (let k = 0; k < H.length; k += 7) cavScale += Math.abs(H[k] - blur[k]);
  cavScale = Math.max(0.5, (cavScale / Math.ceil(H.length / 7)) * 2.2);
  yield;

  /**
   * THE CURVATURE, applied here and nowhere else.
   *
   * A vertex's tangent offset (u,v) is arc length from the cap centre, so its
   * angular distance is `a = |(u,v)| / R`. It sits at radius `R + h` along its
   * own direction, and in the frame's local coordinates that is a horizontal
   * component of `(R+h)·sin a` and a vertical of `(R+h)·cos a − R`. As `a → 0`
   * this collapses to `(u, h, v)`, which is exactly the flat patch the rest of
   * the game was written against — so nothing downstream had to change.
   */
  const localY = (u, v, h) => {
    const s = Math.hypot(u, v);
    if (s < 1e-9) return h;
    const a = s / R;
    return (R + h) * Math.cos(a) - R;
  };
  const localScale = (u, v, h) => {
    const s = Math.hypot(u, v);
    if (s < 1e-9) return 1;
    const a = s / R;
    return ((R + h) * Math.sin(a)) / s;
  };

  // Strata thickness in metres: how thick one bed is on an exposed face.
  // Scaled to the world's relief so a 620-metre shear face gets a dozen beds
  // and a 90-metre pressure floor gets two.
  const BED = Math.max(6, relief * 0.055);

  const bandUV = (y, ny, k, cav) => {
    const hN = (y - lo) / span;
    const slope = 1 - Math.max(0, Math.min(1, ny));
    const dx = DIR[k * 3] * F, dy = DIR[k * 3 + 1] * F, dz = DIR[k * 3 + 2] * F;
    // MOTTLE. Height alone is not enough: a levelled pad or a dune trough is
    // all at ONE height, so a pure height ramp paints it a single flat colour —
    // which is precisely what the first version of this did, and a plain in one
    // value reads as a painted floor no matter how much relief stands behind
    // it. A low-frequency noise term pushes neighbouring vertices across band
    // boundaries, so flat ground breaks into patches of two or three bands the
    // way real regolith does.
    //
    // Every one of these terms is sampled off the DIRECTION rather than off the
    // cap's local coordinates, which is what stops the colour of the ground
    // swimming when the cap slides.
    const m = fbm3(dx * 2.36, dy * 2.36, dz * 2.36, seed + 1201, 4);
    /**
     * AND A NEAR-FIELD BREAK, at a wavelength you can WALK ACROSS.
     *
     * The mottle is a 260-metre patch and the province below is a 1200-metre
     * region. The walker is 1.6 metres tall, so from standing height the whole
     * near field — everything inside a hundred metres, which is most of the
     * frame — falls inside ONE patch of each, and comes out a single flat
     * colour. That was the last reason a landscape with real relief in the
     * distance still read as a painted floor underfoot.
     */
    const near = fbm3(dx * 5.17, dy * 5.17, dz * 5.17, seed + 7717, 2);
    const hM = Math.max(0, Math.min(1, hN + m * 0.22 + near * 0.10));
    /**
     * COLOUR PROVINCES, on their own much larger scale than the mottle: a
     * sulphur stain across one region, a dark flow across another, oxide where
     * the water used to sit. Thresholded into three states, and it is the
     * difference between a texture and a geography.
     */
    const pv = fbm3(dx * 0.527, dy * 0.527, dz * 0.527, seed + 3311, 3);
    const stain = pv > 0.20 ? 1 : pv < -0.22 ? 2 : 0;

    let band;
    if (slope > 0.46) {
      /**
       * EXPOSED FACE — and it is BEDDED. A cliff painted one flat colour is the
       * single most artificial thing a heightfield can do, because the one place
       * you can see a world's insides is the one place it was showing you no
       * information at all. Alternating beds keyed to ABSOLUTE height (not to
       * the local surface) means the bands line up across a valley from one wall
       * to the other, which is exactly the read that says "these layers were
       * laid down before this valley was cut".
       */
      const bed = Math.floor((y - lo) / BED);
      const jitter = fbm3(dx * 2.5, dy * 2.5, dz * 2.5, seed + 981, 2) * 0.6;
      const kind = ((bed % 3) + 3) % 3;
      band = kind === 0 ? 8 : kind === 1 ? 9 : (jitter > 0.1 ? 10 : 8);
      // The steepest faces of all are fresh fracture, not weathered bed.
      if (slope > 0.78) band = 11;
    } else if (hM > 0.93 && slope < 0.30) band = 15;             // cap
    else if (hM > 0.84) band = 14;                               // ridge
    else if (hM > 0.72) band = 13;                               // upper accent
    else if (cav < -0.55) band = 0;                              // deep hollow
    else if (cav < -0.22) band = 1;                              // hollow
    else {
      // The main body of the ground: five steps of height, shifted bodily by
      // the province so a whole region reads as a different material.
      const s5 = Math.max(0, Math.min(4, Math.floor(hM * 5.4)));
      band = 2 + s5 + (stain === 1 ? 5 : 0);
      if (stain === 2) band = Math.max(2, band - 1);
      // One more step, at the near-field scale, so adjacent patches of the same
      // height still differ by a band. This is what the ground you are standing
      // on is made of.
      if (near > 0.30) band += 1;
      else if (near < -0.30) band -= 1;
      band = Math.max(1, Math.min(12, band));
    }
    /**
     * THE SHADE AXIS. `v` used to be pure noise — decorative grain, and nothing
     * more. It now carries the CAVITY (see above), so hollows come out of the
     * ramp dark and crests come out bright before the sun has said anything.
     * The noise survives at a third weight, because ordered stipple is what
     * keeps the transitions from being smooth.
     */
    const g = fbm3(dx * 16.3, dy * 16.3, dz * 16.3, seed + 4242, 3) * 0.5 + 0.5;
    // A second, finer grain that varies from one vertex to the next. Because
    // `v` is interpolated across the triangle and the ramp's rows are QUANTISED,
    // a facet whose corners land on different rows comes out as stepped bands
    // rather than a smooth blend — which is the dither language doing the work
    // that flat ground has no geometry left to do.
    const g2 = fbm3(dx * 68.9, dy * 68.9, dz * 68.9, seed + 6161, 2) * 0.5 + 0.5;
    const shade = Math.max(0, Math.min(1,
      0.5 + cav * 0.42 + (g - 0.5) * 0.38 + (g2 - 0.5) * 0.30));
    return [(band + 0.5) / RAMP_BANDS, Math.min(0.999, shade * 0.96 + 0.02)];
  };

  for (let j = 0; j < grid; j++) {
    for (let i = 0; i < grid; i++) {
      const u = -extent + i * step, v = -extent + j * step;
      const k = j * grid + i;
      const h = at(i, j);
      const dhu = (at(i + 1, j) - at(i - 1, j)) / (2 * step);
      const dhv = (at(i, j + 1) - at(i, j - 1)) / (2 * step);
      const nl = Math.hypot(-dhu, 1, -dhv) || 1;
      const ny = 1 / nl;
      const cav = Math.max(-1, Math.min(1, (h - blur[k]) / cavScale));
      const [tu, tv] = bandUV(h, ny, k, cav);
      const sc = localScale(u, v, h);
      verts.push(u * sc, localY(u, v, h), v * sc, -dhu / nl, ny, -dhv / nl, tu, tv);
    }
    if (j % ROWS_PER_SLICE === 0) yield;
  }
  yield;
  for (let j = 0; j < grid - 1; j++) {
    for (let i = 0; i < grid - 1; i++) {
      const a = j * grid + i, b = a + 1, c = a + grid, d = c + 1;
      indices.push(a, c, b, b, c, d);
    }
  }

  /**
   * Ground height under a local (u,v). Returns the LOCAL y — curvature drop
   * included — because that is what the walker stands on and what the ship's
   * altitude is measured against.
   */
  const heightAt = (x, z) => {
    const fi = (x + extent) / step, fj = (z + extent) / step;
    const i = Math.floor(fi), j = Math.floor(fj);
    if (i < 0 || j < 0 || i >= grid - 1 || j >= grid - 1) {
      return localY(x, z, padH);
    }
    const uu = fi - i, vv = fj - j;
    const h00 = at(i, j), h10 = at(i + 1, j), h01 = at(i, j + 1), h11 = at(i + 1, j + 1);
    const h = (h00 * (1 - uu) + h10 * uu) * (1 - vv) + (h01 * (1 - uu) + h11 * uu) * vv;
    return localY(x, z, h);
  };

  yield;
  // -- 5. what is standing ON the ground --------------------------------------
  const props = scatterProps(verts, indices, profile, heightAt, extent, frame, R, F, seed);
  yield;

  return {
    vertexData: new Float32Array(verts),
    indexData: new Uint32Array(indices),
    heightAt,
    /** Upright cylinders the walker is pushed out of: {x,z,r}. */
    props,
    /** The frame this cap was built in — where on the body you are standing. */
    frame,
    /** Ground height at the cap centre; the entry reads it to place the hull. */
    padHeight: heightAt(0, 0),
    minHeight: lo,
    maxHeight: hi,
    extent,
    radiusM: R,
    /** Palette strip the UVs above index into — uploaded by the renderer. */
    ramp: terrainRamp(profile),
  };
}

/**
 * How many colour bands the terrain ramp carries.
 *
 * Eight was not enough to say anything. Every world got hollow / ground / two
 * mixes / accent / one face colour / ridge / cap, which meant a cliff was ONE
 * colour, a stained region was impossible, and there was no band left over for
 * scree, vein or organics. Sixteen buys: two hollows, five steps of ground,
 * five of a second regional material, three rock materials for the bedding, and
 * the ridge and cap that were already there.
 */
const RAMP_BANDS = 16;

/**
 * SCATTER — everything standing ON the ground, written straight into the
 * terrain's own vertex arrays.
 *
 * A heightfield alone has no scale: there is nothing in it whose size you
 * already know, so a two-hundred-unit ridge and a two-unit ripple look
 * identical. A boulder you could stand behind is the reference that makes the
 * ridge read as a ridge — and folding it into the terrain mesh costs nothing,
 * because it is the same material, the same ramp and the same draw call.
 *
 * WHAT CHANGED IN 0.43.0, and why. The first pass gave each world exactly ONE
 * kind of object, placed uniformly at random. Uniform random is the thing that
 * looks least like nature: real ground is mostly empty with things gathered in
 * fields — scree below a scarp, boulders in a crater's ejecta, stacks along a
 * fracture. And one silhouette repeated a hundred and forty times reads as a
 * repeated asset however well it is jittered.
 *
 * So: a weighted MIX per archetype, twelve silhouettes, and CLUSTERED placement.
 * Most props come out of a handful of fields with a size gradient inside each,
 * plus a scatter of loners so the fields do not read as a grid of clumps.
 *
 * Every solid is a stack of jittered rings around a profile — a lump with flat
 * facets, which is what a rock looks like at 16-bit resolution and cheaper than
 * any smooth primitive. Three shapes that a ring stack cannot express (`arch`,
 * `rib`, `plate`) are built by hand below.
 */

/**
 * THE SILHOUETTE TABLE. `rings` are `[height fraction, radius fraction]`, `h`
 * and `w` are the height and width ranges as multiples of the archetype's own
 * `size`, `band` picks the material out of the terrain ramp, and `jit` is how
 * irregular the ring is — low for crystal, high for weathered rock.
 */
const SHAPE = {
  /** The default lump. Wider than tall, buried a little at the foot. */
  boulder: { rings: [[0, 1.0], [0.42, 0.86], [0.80, 0.52]], h: [0.7, 1.3], w: [0.9, 1.15], sides: 7, band: 8, jit: 0.26 },
  /** Small, and there are always more of them than anything else. */
  cobble: { rings: [[0, 1.0], [0.5, 0.78], [0.85, 0.4]], h: [0.3, 0.6], w: [0.28, 0.5], sides: 6, band: 9, jit: 0.3 },
  /** Wide flat plate, tilted — a broken bed rather than a rounded stone. */
  slab: { rings: [[0, 1.0], [0.5, 1.06], [0.9, 0.74]], h: [0.2, 0.46], w: [1.5, 2.6], sides: 7, band: 9, jit: 0.2 },
  /** Tall and tapering. The thing that gives a skyline its verticals. */
  spire: { rings: [[0, 1.0], [0.42, 0.64], [0.84, 0.28]], h: [2.6, 5.4], w: [0.8, 1.1], sides: 6, band: 10, jit: 0.22 },
  /** A very tall, very thin needle: sublimation form, low gravity. */
  needle: { rings: [[0, 1.0], [0.32, 0.44], [0.74, 0.17]], h: [4.2, 8.5], w: [0.42, 0.7], sides: 5, band: 15, jit: 0.16 },
  /** Organic. Takes the vegetation band so a jungle reads green. */
  trunk: { rings: [[0, 1.0], [0.42, 0.72], [0.86, 0.5]], h: [3.2, 6.2], w: [0.7, 1.0], sides: 6, band: 5, jit: 0.18, lean: 0.06 },
  /** Mushroom rock: wide foot, eaten-out waist, hard cap on top. */
  hoodoo: { rings: [[0, 0.92], [0.44, 0.32], [0.70, 0.98], [0.90, 0.60]], h: [2.0, 3.8], w: [0.7, 1.05], sides: 7, band: 9, jit: 0.2 },
  /** Angular crystal. Low jitter is the whole read — facets, not lumps. */
  shard: { rings: [[0, 1.0], [0.55, 0.74], [0.86, 0.26]], h: [1.6, 3.6], w: [0.5, 0.95], sides: 4, band: 11, jit: 0.06 },
  /** A pile: several rounded blocks stacked, the classic weathered tor. */
  stack: { rings: [[0, 1.0], [0.30, 0.62], [0.52, 0.94], [0.74, 0.56], [0.92, 0.72]], h: [1.8, 3.4], w: [0.8, 1.2], sides: 7, band: 8, jit: 0.24 },
  /** A vent cone. Open at the top and dark inside, so it reads as a hole. */
  vent: { rings: [[0, 1.0], [0.55, 0.66], [0.92, 0.48]], h: [0.9, 1.8], w: [1.3, 2.0], sides: 8, band: 0, jit: 0.18, open: true },
};

/** Kinds built by hand rather than from a ring stack. */
const BESPOKE = new Set(['arch', 'rib', 'plate']);

/**
 * One ring-stack solid. Returns the collision radius.
 *
 * The rings are jittered per vertex and the whole thing leans with a random
 * bearing, so no two are the same object even before the size roll — which is
 * what stops a field of a hundred boulders reading as a hundred copies.
 */
function ringSolid(verts, indices, rng, shape, x, y, z, s, bandOf) {
  const h = s * rng.range(shape.h[0], shape.h[1]);
  const rad = s * rng.range(shape.w[0], shape.w[1]);
  const sides = shape.sides;
  const tilt = rng.range(0, Math.PI * 2);
  const lean = shape.lean ?? 0.16;
  const lx = Math.cos(tilt) * lean, lz = Math.sin(tilt) * lean;
  const base = verts.length / 8;
  const y0 = y - s * 0.35;
  const jit = shape.jit;
  for (const [t, r] of shape.rings) {
    const up = h * t;
    for (let i = 0; i < sides; i++) {
      const a = (i / sides) * Math.PI * 2 + tilt;
      const rr = rad * r * rng.range(1 - jit, 1 + jit);
      const px = x + Math.cos(a) * rr + lx * up;
      const pz = z + Math.sin(a) * rr + lz * up;
      const py = y0 + up + (t > 0 ? rng.range(-s * 0.1, s * 0.1) : 0);
      const nl = Math.hypot(Math.cos(a), 0.42, Math.sin(a));
      // Rows: the shade axis. Low on the flanks, high near the top, so a
      // solid picks up occlusion from the ramp the same way the ground does.
      verts.push(px, py, pz, Math.cos(a) / nl, 0.42 / nl, Math.sin(a) / nl,
        bandOf(shape.band), 0.22 + t * 0.62 + (i % 3) * 0.04);
    }
  }
  const nr = shape.rings.length;
  for (let r = 0; r < nr - 1; r++) {
    for (let i = 0; i < sides; i++) {
      const a0 = base + r * sides + i, a1 = base + r * sides + ((i + 1) % sides);
      indices.push(a0, a0 + sides, a1, a1, a0 + sides, a1 + sides);
    }
  }
  if (shape.open) {
    // A vent is a tube: cap it with an inward-sloping throat one step DARKER,
    // which is what makes it read as an opening rather than a flat lid.
    const throat = verts.length / 8;
    verts.push(x + lx * h, y0 + h * 0.72, z + lz * h, 0, 1, 0, bandOf(0), 0.04);
    const last = base + (nr - 1) * sides;
    for (let i = 0; i < sides; i++) {
      indices.push(last + i, throat, last + ((i + 1) % sides));
    }
  } else {
    const tip = verts.length / 8;
    verts.push(x + lx * h, y0 + h, z + lz * h, 0, 1, 0, bandOf(shape.band), 0.95);
    const last = base + (nr - 1) * sides;
    for (let i = 0; i < sides; i++) {
      indices.push(last + i, tip, last + ((i + 1) % sides));
    }
  }
  return rad * 0.85;
}

/** A box between two corners, six quads, one band. All the bespoke kinds use it. */
function boxAt(verts, indices, cx, cy, cz, hx, hy, hz, yaw, u, v) {
  const c = Math.cos(yaw), s = Math.sin(yaw);
  const base = verts.length / 8;
  const P = [[-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1],
    [-1, 1, -1], [1, 1, -1], [1, 1, 1], [-1, 1, 1]];
  for (const [sx, sy, sz] of P) {
    const lx = sx * hx, lz = sz * hz;
    verts.push(cx + lx * c - lz * s, cy + sy * hy, cz + lx * s + lz * c,
      // Face normals would need split vertices; a corner normal is enough at
      // this size and keeps the box at eight vertices.
      (sx * c - sz * s) * 0.5, sy * 0.7, (sx * s + sz * c) * 0.5, u, v);
  }
  const F = [[0, 1, 2, 3], [7, 6, 5, 4], [0, 4, 5, 1], [1, 5, 6, 2], [2, 6, 7, 3], [3, 7, 4, 0]];
  for (const [a, b, cc, d] of F) {
    indices.push(base + a, base + cc, base + b, base + a, base + d, base + cc);
  }
}

/**
 * A NATURAL ARCH. Two legs and a lintel, and it is here because it is the one
 * silhouette in the set you can see THROUGH — a hole in a landscape is worth
 * more than another lump on it, and it gives a survey site a landmark.
 */
function archAt(verts, indices, rng, x, y, z, s, bandOf) {
  const span = s * rng.range(2.4, 4.2);
  const h = s * rng.range(2.0, 3.6);
  const th = s * rng.range(0.34, 0.6);
  const yaw = rng.range(0, Math.PI * 2);
  const c = Math.cos(yaw), sn = Math.sin(yaw);
  const u = bandOf(9);
  for (const k of [-1, 1]) {
    boxAt(verts, indices, x + c * span * 0.5 * k, y + h * 0.5 - s * 0.3, z + sn * span * 0.5 * k,
      th, h * 0.5, th * 1.2, yaw, u, 0.4);
  }
  boxAt(verts, indices, x, y + h - s * 0.3 + th * 0.6, z,
    span * 0.5 + th, th * 0.8, th * 1.2, yaw, u, 0.82);
  return span * 0.5 + th;
}

/**
 * A HALF-BURIED RIB. An arc of tapering segments coming out of the ground and
 * going back into it — the one prop on a world that is not geology, and the one
 * that makes a player stop and look. Deliberately ambiguous: it could be bone.
 */
function ribAt(verts, indices, rng, x, y, z, s, heightAt, bandOf) {
  const len = s * rng.range(3.0, 6.5);
  const yaw = rng.range(0, Math.PI * 2);
  const c = Math.cos(yaw), sn = Math.sin(yaw);
  const N = 7;
  const u = bandOf(13);
  for (let i = 0; i < N; i++) {
    const t = i / (N - 1);
    const d = (t - 0.5) * len;
    // An arc: out of the ground, over, and back in.
    const rise = Math.sin(t * Math.PI) * s * rng.range(1.1, 2.0);
    const px = x + c * d, pz = z + sn * d;
    const seg = s * (0.16 + Math.sin(t * Math.PI) * 0.13);
    boxAt(verts, indices, px, heightAt(px, pz) + rise - s * 0.2, pz,
      seg, seg * 1.3, seg, yaw, u, 0.5 + Math.sin(t * Math.PI) * 0.4);
  }
  return len * 0.3;
}

/**
 * A PLATE — a flat panel of something manufactured, tilted where it landed and
 * half swallowed. On a metal world it is a shear face's fallen slab; anywhere
 * else it is wreckage, and the game already has a fiction full of ships that
 * did not make it. Costs one box and does more for the mood than any rock.
 */
function plateAt(verts, indices, rng, x, y, z, s, bandOf) {
  const w = s * rng.range(1.4, 3.4);
  const l = s * rng.range(1.8, 4.0);
  const yaw = rng.range(0, Math.PI * 2);
  boxAt(verts, indices, x, y + s * rng.range(0.1, 0.5), z,
    w, s * rng.range(0.10, 0.22), l, yaw, bandOf(11), 0.72);
  return Math.max(w, l) * 0.7;
}

/**
 * SCATTER, ON A GLOBAL LATTICE.
 *
 * The 0.43.0 version rolled prop positions with the build's own RNG inside the
 * patch. That was fine while the patch WAS the world, and it stops being fine
 * the moment the cap can move: fly a kilometre, let the cap re-centre, fly back,
 * and every boulder you passed would be somewhere else. Worse, the overlap
 * between the old cap and the new one would disagree with itself — half the
 * rocks would jump on the swap frame.
 *
 * So the props come off a jittered 3D lattice in the body's own noise space,
 * exactly like the volcanoes and the impact craters. One candidate per cell, its
 * existence, size and kind hashed from the cell index — so a prop belongs to a
 * PLACE ON THE WORLD, is the same every time any cap covers it, and survives
 * every re-centre untouched.
 *
 * The clustering survived the move. Uniform random is the placement that looks
 * least like nature; real ground is mostly empty with things gathered in fields
 * — scree below a scarp, boulders in a crater's ejecta, stacks along a fracture.
 * A low-frequency noise field modulates the accept rate, so the lattice still
 * produces dense fields and bare ground, and now those fields are in fixed
 * places you can fly back to.
 */
function scatterProps(verts, indices, profile, heightAt, extent, frame, R, F, seed) {
  const spec = profile.rocks;
  const out = [];
  if (!spec || !spec.n) return out;
  const bandOf = (b) => (b + 0.5) / RAMP_BANDS;
  const mix = spec.mix ?? [spec.kind ?? 'boulder'];

  // Cell size scales with the cap, so a wide low-detail cap seen from altitude
  // carries the same NUMBER of props as a tight one on the ground rather than
  // fifty times as many.
  const cellM = Math.max(24, extent * 0.069);
  const cellN = (cellM * F) / R;
  const centreN = [frame.c[0] * F, frame.c[1] * F, frame.c[2] * F];
  const hs = (extent * 1.5 * F) / R + cellN * 2;
  // How many of the cells that land on the cap should actually carry something.
  const onCap = Math.max(1, ((2 * extent) / cellM) ** 2 * 0.785);
  // 0.62 corrects for the clustering multiplier below, whose mean is above one:
  // without it a world came out with twice the props it asked for.
  const accept = Math.min(1, (spec.n / onCap) * 0.62);
  const cosCap = Math.cos((extent * 1.45) / R);

  const pad = 50;
  const D = profile.padDir;
  const n = [0, 0, 0];

  const i0 = Math.floor((centreN[0] - hs) / cellN), i1 = Math.ceil((centreN[0] + hs) / cellN);
  const j0 = Math.floor((centreN[1] - hs) / cellN), j1 = Math.ceil((centreN[1] + hs) / cellN);
  const k0 = Math.floor((centreN[2] - hs) / cellN), k1 = Math.ceil((centreN[2] + hs) / cellN);

  for (let ci = i0; ci <= i1; ci++) {
    for (let cj = j0; cj <= j1; cj++) {
      for (let ck = k0; ck <= k1; ck++) {
        const h0 = cellHash(ci, cj, ck, seed ^ 0x51ed270b);
        const qx = (ci + h0) * cellN;
        const qy = (cj + cellHash(ci, cj, ck, seed ^ 0x1a2b3c4d)) * cellN;
        const qz = (ck + cellHash(ci, cj, ck, seed ^ 0x6f4e2d1b)) * cellN;
        const qm = Math.hypot(qx, qy, qz);
        // The lattice fills a volume; only the shell that the sphere passes
        // through can hold anything standing on the ground.
        if (Math.abs(qm - F) > cellN * 0.87) continue;
        n[0] = qx / qm; n[1] = qy / qm; n[2] = qz / qm;
        const ca = n[0] * frame.c[0] + n[1] * frame.c[1] + n[2] * frame.c[2];
        if (ca < cosCap) continue;

        // FIELDS, not a uniform spray.
        const dens = fbm3(qx * 0.9, qy * 0.9, qz * 0.9, seed + 5507, 3);
        const hA = cellHash(ci, cj, ck, seed ^ 0x2c1b3c6d);
        if (hA > accept * (0.35 + 1.9 * Math.max(0, dens + 0.35))) continue;

        // Direction → the cap's local tangent offsets. Inverse of `frameDir`.
        const a = Math.acos(Math.min(1, ca));
        const sa = Math.sin(a);
        let u = 0, v = 0;
        if (sa > 1e-9) {
          const ex = n[0] - frame.c[0] * ca, ey = n[1] - frame.c[1] * ca, ez = n[2] - frame.c[2] * ca;
          const arc = (a * R) / sa;
          u = arc * (ex * frame.t[0] + ey * frame.t[1] + ez * frame.t[2]);
          v = arc * (ex * frame.b[0] + ey * frame.b[1] + ez * frame.b[2]);
        }
        if (Math.abs(u) > extent * 0.96 || Math.abs(v) > extent * 0.96) continue;

        const hB = cellHash(ci, cj, ck, seed ^ 0x297a2d39);
        const hC = cellHash(ci, cj, ck, seed ^ 0x165667b1);
        const s = spec.size * (0.5 + hB * 1.15) * (0.7 + Math.max(0, dens) * 0.9);
        if (s < 0.4) continue;

        /**
         * KEEP THE PAD CLEAR — but only as clear as it has to be, and around the
         * LANDING SITE rather than around the cap. The ship needs room to sit; a
         * scatter of loose stone around the feet of it is what a landing site
         * looks like. Big things stay out, small things come in.
         */
        const pc = Math.min(1, n[0] * D[0] + n[1] * D[1] + n[2] * D[2]);
        const d0 = Math.acos(pc) * R;
        if (d0 < pad * (s > spec.size * 0.7 ? 1.5 : 0.72)) continue;

        const kind = mix[Math.min(mix.length - 1, Math.floor(hC * mix.length))];
        const y = heightAt(u, v);
        // Per-prop randomness, seeded from the cell so the same rock is the same
        // rock forever.
        const prng = new RNG(((h0 * 0xffffff) | 0) ^ (ci * 7919) ^ (cj * 104729) ^ (ck * 1299709));
        let r;
        if (BESPOKE.has(kind)) {
          r = kind === 'arch' ? archAt(verts, indices, prng, u, y, v, s, bandOf)
            : kind === 'rib' ? ribAt(verts, indices, prng, u, y, v, s, heightAt, bandOf)
              : plateAt(verts, indices, prng, u, y, v, s, bandOf);
        } else {
          r = ringSolid(verts, indices, prng, SHAPE[kind] ?? SHAPE.boulder,
            u, y, v, s, bandOf);
        }
        /**
         * SOMETHING TO WALK TO (0.47.0).
         *
         * Manufactured debris and the half-buried ribs are the only props on a
         * world that were not always there, so they are the only ones worth
         * approaching — and now they can be searched. The key is the LATTICE
         * CELL, not the local position, so a cache you emptied stays emptied
         * across cap slides, save/loads and coming back to the world a week
         * later. See gameplay/Loot.js and the SURFACE branch of main.js.
         */
        out.push({ x: u, z: v, r });
      }
    }
  }

  /**
   * SOMETHING TO WALK TO (0.47.0) — a second, much sparser lattice, and the
   * reason it is separate from the rock scatter above is that it must not
   * depend on the world's mix. A lava world scatters slabs and vents; a comet
   * scatters needles. Neither of them would ever produce wreckage, so under the
   * old arrangement half the archetypes had nothing on them worth approaching
   * and the other half had it by accident.
   *
   * These are the things that were not always there: a hull panel, a strut, a
   * drop pod nobody came back for. About one every four hundred metres, so a
   * walk across a cap passes two or three, and every one of them can be
   * searched exactly once — the key is the LATTICE CELL, not the local
   * position, so a cache you emptied stays emptied across cap slides, save
   * loads and coming back to the world a month later.
   */
  const dCell = Math.max(120, extent * 0.26);
  const dN = (dCell * F) / R;
  const di0 = Math.floor((centreN[0] - hs) / dN), di1 = Math.ceil((centreN[0] + hs) / dN);
  const dj0 = Math.floor((centreN[1] - hs) / dN), dj1 = Math.ceil((centreN[1] + hs) / dN);
  const dk0 = Math.floor((centreN[2] - hs) / dN), dk1 = Math.ceil((centreN[2] + hs) / dN);
  const DEBRIS = ['plate', 'plate', 'rib', 'slab'];
  const LABEL = { plate: 'HULL DEBRIS', rib: 'BURIED WRECKAGE', slab: 'CRUSHED CANISTER' };
  for (let ci = di0; ci <= di1; ci++) {
    for (let cj = dj0; cj <= dj1; cj++) {
      for (let ck = dk0; ck <= dk1; ck++) {
        const h0 = cellHash(ci, cj, ck, seed ^ 0x3f9a72c1);
        if (h0 > 0.34) continue;                        // most cells are empty ground
        const qx = (ci + h0) * dN;
        const qy = (cj + cellHash(ci, cj, ck, seed ^ 0x77c1b3a5)) * dN;
        const qz = (ck + cellHash(ci, cj, ck, seed ^ 0x1de3f907)) * dN;
        const qm = Math.hypot(qx, qy, qz);
        if (Math.abs(qm - F) > dN * 0.87) continue;
        n[0] = qx / qm; n[1] = qy / qm; n[2] = qz / qm;
        const ca = n[0] * frame.c[0] + n[1] * frame.c[1] + n[2] * frame.c[2];
        if (ca < cosCap) continue;
        const a = Math.acos(Math.min(1, ca));
        const sa = Math.sin(a);
        let u = 0, v = 0;
        if (sa > 1e-9) {
          const ex = n[0] - frame.c[0] * ca, ey = n[1] - frame.c[1] * ca, ez = n[2] - frame.c[2] * ca;
          const arc = (a * R) / sa;
          u = arc * (ex * frame.t[0] + ey * frame.t[1] + ez * frame.t[2]);
          v = arc * (ex * frame.b[0] + ey * frame.b[1] + ez * frame.b[2]);
        }
        if (Math.abs(u) > extent * 0.94 || Math.abs(v) > extent * 0.94) continue;
        const hB = cellHash(ci, cj, ck, seed ^ 0x5c2ab19f);
        const kind = DEBRIS[Math.min(DEBRIS.length - 1, Math.floor(hB * DEBRIS.length))];
        const size = spec.size * (0.9 + hB * 0.8);
        const y = heightAt(u, v);
        const prng = new RNG(((h0 * 0xffffff) | 0) ^ (ci * 15487) ^ (cj * 32749) ^ (ck * 65537));
        const r = kind === 'rib'
          ? ribAt(verts, indices, prng, u, y, v, size, heightAt, bandOf)
          : kind === 'plate'
            ? plateAt(verts, indices, prng, u, y, v, size, bandOf)
            : ringSolid(verts, indices, prng, SHAPE.slab, u, y, v, size, bandOf);
        out.push({
          x: u,
          z: v,
          r,
          cache: true,
          key: `${profile.bodyId ?? 'w'}#${ci}:${cj}:${ck}`,
          label: LABEL[kind],
        });
      }
    }
  }
  return out;
}

/** 3D integer hash → [0,1). The lattice's own randomness, and nothing else's. */
function cellHash(ix, iy, iz, seed) {
  let h = (ix | 0) * 0x27d4eb2d ^ (iy | 0) * 0x9e3779b1 ^ (iz | 0) * 0x165667b1
    ^ (seed | 0);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  h ^= h >>> 15;
  return (h >>> 0) / 4294967296;
}

/**
 * THE TERRAIN RAMP — a 16-band palette strip the ground's UVs index into.
 *
 * Returned as a `{width, height, data}` image the renderer uploads like any
 * other texture. Sixteen columns, one per material; sixty-four rows per column
 * carrying the SHADE axis, which the mesh drives with baked cavity (see
 * `bandUV`) rather than with noise. Both axes are quantised into steps with a
 * per-row jitter, so the surface stipples between values instead of sliding —
 * the project's rule about gradients, applied to the one place that used to
 * have no colour variation at all.
 *
 * Bands: 0-1 hollows · 2-6 the ground, low to accent · 7-10 and 12 a second
 * regional material, which is also what the strata on a cliff face alternate
 * between · 11 fresh fracture and manufactured debris · 13-15 upper accent,
 * ridge and cap.
 */
export function terrainRamp(profile) {
  const W = RAMP_BANDS, Hh = 64;
  const data = new Uint8Array(W * Hh * 4);
  const g = hexRgb255(profile.ground);
  const a = hexRgb255(profile.accent);
  const glow = profile.glow ? hexRgb255(profile.glow) : null;
  const mix = (c0, c1, t) => [
    c0[0] + (c1[0] - c0[0]) * t, c0[1] + (c1[1] - c0[1]) * t, c0[2] + (c1[2] - c0[2]) * t];
  const shade = (c, k) => [c[0] * k, c[1] * k, c[2] * k];
  // The face bands are deliberately DESATURATED and darker, not just a darker
  // ground: exposed rock is a different material from the weathered surface
  // over it, and matching hues is what made every cliff read as a shadow.
  const grey = (c) => { const m = (c[0] + c[1] + c[2]) / 3; return mix(c, [m, m, m], 0.55); };
  /**
   * THE SECOND MATERIAL. Bands 7..12 are the same height ramp in a different
   * substance, and the province noise in `bandUV` decides which one a whole
   * region of the patch is made of. Rotating the hue rather than merely
   * lightening it is what makes the boundary read as "a different rock" instead
   * of "the same rock in better light" — and rotating it TOWARD the accent
   * keeps it inside the world's own palette rather than inventing a colour the
   * archetype never authorised.
   */
  const warm = (c) => [
    Math.min(255, c[0] * 1.09 + 7), c[1] * 0.99, Math.max(0, c[2] * 0.86 - 2)];
  const g2 = warm(mix(g, a, 0.22));
  const a2 = warm(mix(a, [200, 182, 152], 0.12));
  const BANDS = [
    shade(g, 0.46),                       // 0  deep hollow — the dark collects
    shade(g, 0.68),                       // 1  hollow
    shade(g, 0.88),                       // 2  ground, low
    g,                                    // 3  ground
    mix(g, a, 0.34),                      // 4
    mix(g, a, 0.66),                      // 5
    a,                                    // 6  accent
    shade(g2, 0.86),                      // 7  second material, low
    g2,                                   // 8  bedding A / second ground
    mix(g2, a2, 0.5),                     // 9  bedding B
    a2,                                   // 10 bedding C — the odd bed out
    shade(grey(a), 0.62),                 // 11 fresh fracture — steepest faces
    mix(g2, a2, 0.8),                     // 12 second material, high
    mix(a, [232, 236, 244], 0.18),        // 13 upper accent
    mix(a, [232, 236, 244], 0.40),        // 14 ridge
    mix(a, [242, 246, 252], 0.70),        // 15 cap
  ];
  // WHAT SITS ON THE HIGH GROUND depends on the world, and the first version
  // put frost on it unconditionally — which produced a snow-capped crater rim
  // on a world whose ground reads eleven hundred degrees through the boot.
  // Above freezing the tops are scoured bare and bleached instead; a glowing
  // world gets its own light on them.
  if ((profile.tempC ?? 0) > 40) {
    BANDS[13] = mix(a, shade(a, 1.22), 0.5);
    BANDS[14] = mix(a, shade(a, 1.35), 0.6);
    BANDS[15] = glow ? mix(a, glow, 0.5) : shade(a, 1.28);
  }
  // A glowing world (lava) lights its own hollows from below rather than
  // darkening them, which is the one case where the deep bands are brightest.
  if (glow) {
    BANDS[0] = mix(shade(g, 0.7), glow, 0.7);
    BANDS[1] = mix(shade(g, 0.8), glow, 0.4);
  }

  // LIFT. The archetype's `ground`/`accent` hexes were authored as finished
  // screen colours for a pass that drew the terrain with a flat 0.9 fill —
  // effectively unlit. They are now going through a real light term with a
  // raking sun, so at face value every world came out near-black. The ramp is
  // the right place to pay that back: brighten the palette and let the lighting
  // take it down again, rather than flattening the lighting.
  const LIFT = 1.62;
  for (let bx = 0; bx < W; bx++) {
    const c = BANDS[bx].map((v) => v * LIFT);
    for (let y = 0; y < Hh; y++) {
      /**
       * THE ROW AXIS IS SHADE NOW, not decoration.
       *
       * It used to be a four-level value step whose only job was to keep
       * adjacent vertices off the same value — grain, and nothing more. The
       * mesh now writes baked cavity into `v` (see `bandUV`), so this axis
       * carries occlusion: row 0 is the inside of a gully, row 63 is the top of
       * a boulder. Six steps across a 0.55..1.30 range, which is a wide enough
       * swing that a hollow reads as a hollow before the sun has said anything
       * — and quantised, so it is still steps rather than a gradient.
       */
      const t = y / (Hh - 1);
      const stepK = 0.55 + Math.round(t * 6) * 0.125;
      const jit = ((y * 37 + bx * 101) % 7) / 7 * 0.07 - 0.035;
      const k = stepK + jit;
      const o = (y * W + bx) * 4;
      data[o] = Math.max(0, Math.min(255, c[0] * k));
      data[o + 1] = Math.max(0, Math.min(255, c[1] * k));
      data[o + 2] = Math.max(0, Math.min(255, c[2] * k));
      data[o + 3] = 255;
    }
  }
  return { width: W, height: Hh, data };
}

/**
 * THE SKY STRIP — a dithered vertical fade for the horizon wash.
 *
 * The wash used to borrow the amber glow SPRITE, which is a radial sheet with
 * dithered rings in it. Mapped up a cylinder those rings came out as concentric
 * arcs painted across the sky, which is not a thing an atmosphere does. This is
 * one column of honest gradient — dense at the skyline, gone at the zenith —
 * carried in the alpha channel so the additive blend does the rest.
 *
 * Ordered dithering rather than a smooth ramp, per the project's standing rule:
 * the fade is quantised to six steps and a 4x4 Bayer threshold decides which
 * pixels in the transition rows belong to which step.
 */
const BAYER4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
export function skyStrip() {
  const W = 8, H = 64;
  const data = new Uint8Array(W * H * 4);
  for (let y = 0; y < H; y++) {
    // v = 0 at the bottom of the texture; the band is built with the horizon
    // at v = 1, so the DENSE end is the top of this strip.
    const t = y / (H - 1);
    const dens = Math.pow(t, 1.55);           // thickest right at the skyline
    for (let x = 0; x < W; x++) {
      const th = (BAYER4[(y & 3) * 4 + (x & 3)] + 0.5) / 16;
      // STEPS matters more than it looks. At six the bands were wide enough
      // that, wrapped round a cylinder, they read as concentric arcs painted on
      // the sky rather than as dithering. Fourteen puts each step inside the
      // dither's own transition width, which is the whole point of dithering.
      const STEPS = 14;
      const lv = dens * STEPS;
      const q = Math.max(0, Math.min(1, (Math.floor(lv) + (lv - Math.floor(lv) > th ? 1 : 0)) / STEPS));
      const o = (y * W + x) * 4;
      data[o] = 255; data[o + 1] = 255; data[o + 2] = 255;
      data[o + 3] = Math.round(q * 255);
    }
  }
  return { width: W, height: H, data };
}

function hexRgb255(h) {
  const v = parseInt(String(h).replace('#', ''), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}

/**
 * SURFACE SITES — the places on a world worth walking to.
 *
 * Same shape of decision as a boarding: each costs suit oxygen to reach and
 * work, each carries the world's own hazards, and each yields from the world's
 * own resource pool. What differs is that a world does not run out — it is a
 * planet — so the sites regenerate their yield between visits and the limit is
 * always the suit rather than the supply.
 */
export function surfaceSites(profile) {
  const rng = new RNG(profile.seed ^ 0x51ed);
  const KINDS = [
    { id: 'outcrop', name: 'MINERAL OUTCROP', o2: 8, yield: 2,
      text: 'A seam standing proud of the plain. The drill goes in easily and comes out full.' },
    { id: 'crater', name: 'IMPACT SITE', o2: 11, yield: 3,
      text: 'Something arrived here fast enough to turn the bedrock inside out. Whatever it was is still in the floor.' },
    { id: 'vent', name: 'THERMAL VENT', o2: 12, yield: 3,
      text: 'The planet breathing. Everything precipitated around the mouth of it is worth having.' },
    { id: 'wreck', name: 'DOWNED CRAFT', o2: 10, yield: 3,
      text: 'It came in too fast and too steep. Nobody logged it and nobody came back for it.' },
    { id: 'cache', name: 'SURVEY CACHE', o2: 7, yield: 2,
      text: 'A previous expedition left supplies here against a return they did not make.' },
    { id: 'ruin', name: 'UNNATURAL FORMATION', o2: 14, yield: 4,
      text: 'The angles are too regular and the material is not on the assay list.' },
  ];
  const out = [];
  const pool = [...KINDS];
  for (let k = 0; k < profile.sites && pool.length; k++) {
    const pick = pool.splice(rng.int(0, pool.length - 1), 1)[0];
    out.push({
      ...pick,
      // Bearing and range, so the panel can say WHERE and a site feels placed
      // rather than picked off a list.
      bearing: rng.int(0, 359),
      range: rng.int(2, 14) * 100,
      finds: profile.finds,
    });
  }
  return out;
}

/** Sky and ground colours as float rgb, for the renderer. */
export function surfaceColors(profile) {
  return {
    ground: hexRgb(profile.ground),
    accent: hexRgb(profile.accent),
    sky: hexRgb(profile.sky),
    glow: profile.glow ? hexRgb(profile.glow) : null,
    haze: profile.haze,
  };
}

function hexRgb(h) {
  const v = parseInt(String(h).replace('#', ''), 16);
  return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
}

/** First number in a value that may be a display string like "-42 °C". */
function num(v, dflt) {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  const m = String(v ?? '').match(/-?\d+(\.\d+)?/);
  return m ? parseFloat(m[0]) : dflt;
}

function hash(s) {
  let h = 0x811c9dc5;
  const t = String(s);
  for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}

export { TERRAIN, NO_SURFACE };
void PALETTE;
