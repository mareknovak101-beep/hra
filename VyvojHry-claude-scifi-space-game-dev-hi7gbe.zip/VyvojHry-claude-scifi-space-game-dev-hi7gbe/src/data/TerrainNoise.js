/**
 * TERRAIN NOISE — the field functions the ground is carved out of.
 *
 * The first surface pass built its heightfield out of products of sines:
 * `sin(x·f)·cos(z·f·1.31)` summed over four octaves. That is cheap and it is
 * WRONG in a way you can see from the first step you take — a product of sines
 * is periodic on a regular lattice, so every "hill" is the same hill repeated on
 * a grid, and no amount of octaves hides it. Combined with a vertical scale of
 * about nine units over an eighteen-hundred-unit patch, the result was a
 * near-flat plane with a faint corrugation in it.
 *
 * This module is the fix and nothing else: hash-based value noise, fractal sums
 * built on it, and the three derived fields that actually make landscapes.
 *
 *   fbm      ordinary fractal noise — rolling ground, the base of everything
 *   ridged   `(1 - |n|)²` summed — SHARP CRESTS. This is what a mountain range
 *            is; ordinary fbm gives you lumps, and no amount of amplitude turns
 *            a lump into a ridge.
 *   billow   `|n|` summed — rounded, piled forms. Dunes and pillow lava.
 *
 * And the one trick that does more than all three: DOMAIN WARP. Sampling the
 * field at `(x + fbm(x,z), z + fbm(x,z))` instead of `(x,z)` bends every
 * feature along a flow, which is what turns concentric blobs into something
 * that looks eroded, folded and directional. It is one extra noise lookup and
 * it is the difference between "procedural" and "a place".
 *
 * Everything is deterministic in the seed and stateless, so a world is the same
 * world every time you come back to it.
 */

/** 2D integer hash → [0,1). Cheap, well-mixed enough for value noise. */
function h2(ix, iz, seed) {
  let h = (ix | 0) * 0x27d4eb2d ^ (iz | 0) * 0x165667b1 ^ (seed | 0);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  h ^= h >>> 15;
  return (h >>> 0) / 4294967296;
}

/** Quintic smoothstep — C² continuous, so derived normals do not facet. */
const fade = (t) => t * t * t * (t * (t * 6 - 15) + 10);

/**
 * Value noise on the unit lattice, returned in [-1,1].
 *
 * Value rather than gradient noise on purpose: this is a 16-bit pixel-art game
 * whose ground gets a hard-stepped colour ramp on top, so Perlin's smoother
 * gradients buy nothing visible and cost a table lookup per corner.
 */
export function noise2(x, z, seed = 0) {
  const x0 = Math.floor(x), z0 = Math.floor(z);
  const fx = fade(x - x0), fz = fade(z - z0);
  const a = h2(x0, z0, seed), b = h2(x0 + 1, z0, seed);
  const c = h2(x0, z0 + 1, seed), d = h2(x0 + 1, z0 + 1, seed);
  const top = a + (b - a) * fx;
  const bot = c + (d - c) * fx;
  return (top + (bot - top) * fz) * 2 - 1;
}

/**
 * Fractal sum. `oct` octaves, each `lac`× the frequency and `gain`× the
 * amplitude of the last. Normalised to roughly [-1,1] whatever the gain.
 */
export function fbm(x, z, seed, oct = 5, lac = 2.03, gain = 0.5) {
  let sum = 0, amp = 1, norm = 0, f = 1;
  for (let i = 0; i < oct; i++) {
    sum += noise2(x * f, z * f, seed + i * 131) * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / (norm || 1);
}

/**
 * Ridged multifractal. The crest-maker.
 *
 * Each octave is `(1 - |n|)`, squared to sharpen the ridge line, and weighted
 * by the previous octave so detail concentrates ON the ridges rather than
 * spraying evenly — which is why real mountains are rough at the top and smooth
 * in the valleys. Returns [0,1].
 */
export function ridged(x, z, seed, oct = 5, lac = 2.07, gain = 0.52) {
  let sum = 0, amp = 1, norm = 0, f = 1, prev = 1;
  for (let i = 0; i < oct; i++) {
    let n = 1 - Math.abs(noise2(x * f, z * f, seed + i * 197));
    n *= n;
    n *= prev;              // detail rides on the previous octave's ridges
    prev = Math.min(1, n * 1.4);
    sum += n * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / (norm || 1);
}

/** Billow: `|n|` summed. Rounded, piled, no crest. Returns [0,1]. */
export function billow(x, z, seed, oct = 4, lac = 2.11, gain = 0.5) {
  let sum = 0, amp = 1, norm = 0, f = 1;
  for (let i = 0; i < oct; i++) {
    sum += Math.abs(noise2(x * f, z * f, seed + i * 313)) * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / (norm || 1);
}

/**
 * DOMAIN WARP. Offsets the sample point by a low-frequency noise field before
 * the caller reads its own field there.
 *
 * `out` is a two-element scratch the caller reuses — this runs a few hundred
 * thousand times per landing and allocating a pair each call is the difference
 * between a build you do not notice and one you do.
 */
export function warp(out, x, z, seed, freq, amp) {
  out[0] = x + fbm(x * freq, z * freq, seed + 7717, 3) * amp;
  out[1] = z + fbm(x * freq + 41.3, z * freq - 17.9, seed + 9241, 3) * amp;
  return out;
}

/**
 * Worley / cellular F1 distance, on a jittered lattice. Returns the distance to
 * the nearest feature point, in cells.
 *
 * This is what patterned ground, polygonal ice, columnar basalt and cracked
 * playa all are: a Voronoi partition. Nothing built out of fbm produces a cell
 * boundary, so this earns its place.
 */
export function worley(x, z, seed) {
  const xi = Math.floor(x), zi = Math.floor(z);
  let best = 8;
  for (let dz = -1; dz <= 1; dz++) {
    for (let dx = -1; dx <= 1; dx++) {
      const cx = xi + dx, cz = zi + dz;
      const px = cx + h2(cx, cz, seed);
      const pz = cz + h2(cx, cz, seed ^ 0x5bf03635);
      const d = Math.hypot(x - px, z - pz);
      if (d < best) best = d;
    }
  }
  return best;
}

// ---------------------------------------------------------------------------
// THREE DIMENSIONS (0.45.0), and the reason is that a world is a sphere.
//
// Everything above samples a plane, which is exactly right for a square patch
// and cannot be right for a whole planet: a 2D field mapped onto a globe either
// tears at a seam, pinches at the poles, or repeats. Sampling a 3D field ON the
// sphere's surface has none of those problems — there is no seam because there
// is no edge, no pole because every direction is the same kind of direction,
// and no repeat because the sphere never revisits a point in noise space.
//
// The cost is one extra dimension of lattice: eight corners instead of four,
// twenty-seven Worley cells instead of nine. Worth it; nothing else gives a
// world you can fly across in any direction for as long as you like.
// ---------------------------------------------------------------------------

/** 3D integer hash → [0,1). Same construction as `h2`, one more term. */
function h3(ix, iy, iz, seed) {
  let h = (ix | 0) * 0x27d4eb2d ^ (iy | 0) * 0x9e3779b1 ^ (iz | 0) * 0x165667b1
    ^ (seed | 0);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  h ^= h >>> 15;
  return (h >>> 0) / 4294967296;
}

/** Trilinear value noise on the unit lattice, in [-1,1]. */
export function noise3(x, y, z, seed = 0) {
  const x0 = Math.floor(x), y0 = Math.floor(y), z0 = Math.floor(z);
  const fx = fade(x - x0), fy = fade(y - y0), fz = fade(z - z0);
  const c000 = h3(x0, y0, z0, seed), c100 = h3(x0 + 1, y0, z0, seed);
  const c010 = h3(x0, y0 + 1, z0, seed), c110 = h3(x0 + 1, y0 + 1, z0, seed);
  const c001 = h3(x0, y0, z0 + 1, seed), c101 = h3(x0 + 1, y0, z0 + 1, seed);
  const c011 = h3(x0, y0 + 1, z0 + 1, seed), c111 = h3(x0 + 1, y0 + 1, z0 + 1, seed);
  const x00 = c000 + (c100 - c000) * fx, x10 = c010 + (c110 - c010) * fx;
  const x01 = c001 + (c101 - c001) * fx, x11 = c011 + (c111 - c011) * fx;
  const y0v = x00 + (x10 - x00) * fy, y1v = x01 + (x11 - x01) * fy;
  return (y0v + (y1v - y0v) * fz) * 2 - 1;
}

/** Fractal sum in three dimensions. Normalised to roughly [-1,1]. */
export function fbm3(x, y, z, seed, oct = 5, lac = 2.03, gain = 0.5) {
  let sum = 0, amp = 1, norm = 0, f = 1;
  for (let i = 0; i < oct; i++) {
    sum += noise3(x * f, y * f, z * f, seed + i * 131) * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / (norm || 1);
}

/** Ridged multifractal in three dimensions. The crest-maker. Returns [0,1]. */
export function ridged3(x, y, z, seed, oct = 5, lac = 2.07, gain = 0.52) {
  let sum = 0, amp = 1, norm = 0, f = 1, prev = 1;
  for (let i = 0; i < oct; i++) {
    let n = 1 - Math.abs(noise3(x * f, y * f, z * f, seed + i * 197));
    n *= n;
    n *= prev;
    prev = Math.min(1, n * 1.4);
    sum += n * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / (norm || 1);
}

/** Billow in three dimensions. Rounded, piled, no crest. Returns [0,1]. */
export function billow3(x, y, z, seed, oct = 4, lac = 2.11, gain = 0.5) {
  let sum = 0, amp = 1, norm = 0, f = 1;
  for (let i = 0; i < oct; i++) {
    sum += Math.abs(noise3(x * f, y * f, z * f, seed + i * 313)) * amp;
    norm += amp;
    amp *= gain;
    f *= lac;
  }
  return sum / (norm || 1);
}

/**
 * Worley F1 in three dimensions, in cells. Twenty-seven neighbours.
 *
 * Expensive enough to be worth saying out loud: this is the single costliest
 * primitive in the build, and the fields that use it (karst, polygons, shards,
 * pinnacles, flows) are the ones that cannot be made any other way.
 */
export function worley3(x, y, z, seed) {
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  let best = 8;
  for (let dz = -1; dz <= 1; dz++) {
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const cx = xi + dx, cy = yi + dy, cz = zi + dz;
        const px = cx + h3(cx, cy, cz, seed);
        const py = cy + h3(cx, cy, cz, seed ^ 0x2f1b7a41);
        const pz = cz + h3(cx, cy, cz, seed ^ 0x5bf03635);
        const ex = x - px, ey = y - py, ez = z - pz;
        const d = Math.sqrt(ex * ex + ey * ey + ez * ez);
        if (d < best) best = d;
      }
    }
  }
  return best;
}

/** Domain warp in three dimensions. `out` is a three-element scratch. */
export function warp3(out, x, y, z, seed, freq, amp) {
  out[0] = x + fbm3(x * freq, y * freq, z * freq, seed + 7717, 3) * amp;
  out[1] = y + fbm3(x * freq + 41.3, y * freq - 17.9, z * freq + 5.1, seed + 9241, 3) * amp;
  out[2] = z + fbm3(x * freq - 12.7, y * freq + 63.2, z * freq - 31.4, seed + 3313, 3) * amp;
  return out;
}

/**
 * A deterministic unit direction from a seed — where a world puts the features
 * that have a place rather than a distribution: the volcano, the impact basin,
 * the axis a fold belt runs along.
 *
 * Uses the equal-area z/azimuth parameterisation so the point is uniform over
 * the sphere and not bunched at the poles.
 */
export function seedDir(out, seed) {
  const a = h3(seed, 0x51ed, 0x1a7b, 0x9e13);
  const b = h3(0x2c33, seed, 0x77af, 0x3d51);
  const z = a * 2 - 1;
  const r = Math.sqrt(Math.max(0, 1 - z * z));
  const th = b * Math.PI * 2;
  out[0] = Math.cos(th) * r; out[1] = z; out[2] = Math.sin(th) * r;
  return out;
}

/**
 * THERMAL EROSION, in place, on a square heightfield.
 *
 * Any slope steeper than the material's angle of repose sheds material downhill
 * until it is not. Four-neighbour, `iters` passes; a handful is enough to turn
 * noise into landscape, and it is the pass that produces talus slopes, flat
 * valley floors and cliff bases — none of which any noise function gives you,
 * because they are consequences of a process rather than shapes.
 *
 * @param {Float32Array} H  grid×grid heights, mutated
 * @param {number} grid
 * @param {number} step     world units between samples
 * @param {number} talus    max stable slope (rise/run)
 * @param {number} iters
 */
export function erode(H, grid, step, talus = 0.62, iters = 5) {
  const maxDrop = talus * step;
  for (let it = 0; it < iters; it++) {
    for (let j = 1; j < grid - 1; j++) {
      for (let i = 1; i < grid - 1; i++) {
        const k = j * grid + i;
        const h = H[k];
        // steepest downhill neighbour
        let bi = -1, bd = maxDrop;
        const n = [k - 1, k + 1, k - grid, k + grid];
        for (const m of n) {
          const d = h - H[m];
          if (d > bd) { bd = d; bi = m; }
        }
        if (bi < 0) continue;
        // move half the excess — half, not all, so repeated passes converge
        // smoothly instead of oscillating across the ridge line
        const move = (bd - maxDrop) * 0.25;
        H[k] -= move;
        H[bi] += move;
      }
    }
  }
}

/**
 * Terrace a height into `steps` bands with a soft riser.
 *
 * Sedimentary layering and lava benches are both this: hard flats separated by
 * short steep faces, because the strata weather at different rates. `sharp`
 * runs 0 (untouched) to 1 (hard steps).
 */
export function terrace(h, steps, sharp = 0.7) {
  const s = h * steps;
  const f = Math.floor(s);
  const t = s - f;
  const stepped = f + Math.pow(t, 2.4);
  return ((stepped / steps) * sharp + h * (1 - sharp));
}
