/**
 * SHIP CLASSES — the hull the survey commission puts under you.
 *
 * Until now there was exactly one player ship, the HSV Aethon, and every stat
 * that described it lived as a constant in `FLIGHT` or a field initialiser in
 * `ShipSystems`. A class here is the whole description of a vessel in one
 * record: how it flies, how much it can take, what it carries, what its hull
 * looks like from outside, and which compartments you can actually walk.
 *
 * THREE AXES OF DIFFERENCE, and each one is felt somewhere else in play:
 *
 *   FLIGHT     `thrust`, `turn`, `damp` and `mass` multiply the FLIGHT
 *              constants. A courier turns inside a hauler and cannot take a
 *              hit; a hauler shrugs off a fighter pass and cannot escape one.
 *   ENDURANCE  hull, shield, fuel, power and hold slots. This is what decides
 *              whether a long spur is a trip or an expedition.
 *   THE SHIP   the compartments you walk between save terminals, and the
 *              silhouette other things see. A five-room courier is a different
 *              place to be alone than a thirteen-room survey vessel, which is
 *              most of what this game is.
 *
 * ON THE HULL MESHES. `ShipExterior.buildAethon` is a hand-authored mesh with
 * every greeble, frame band, canopy pane and RCS blister placed at an absolute
 * model coordinate. Stretching that table would slide four hundred authored
 * details off the surfaces they belong to. So `hull` below varies the things
 * that can vary SAFELY and still change a silhouette at a glance: how many
 * cruciform arms are stamped, how far they reach, how many drive bells are lit,
 * and the overall scale. Four hulls, one authored detail set, no drift.
 *
 * ON THE INTERIORS. Every side compartment on the deck plan is a LEAF: it hangs
 * off a junction by a single door and nothing routes through it. That means a
 * class can drop compartments without touching the spine — the corridor run
 * from cockpit to engine room is identical on every hull, and what changes is
 * which doors off it open onto anything. Dropping a leaf is safe; re-cutting
 * the spine is not, and this deliberately does not try.
 */

/**
 * @typedef {object} ShipClass
 * @property {string} id
 * @property {string} name       full designation, shown on the commission card
 * @property {string} hullName    the vessel's own name (HUD, save, journal)
 * @property {string} role        one-line class description
 * @property {string} blurb       flavour, second person, present tense
 * @property {string} accent      card accent, from the sanctioned families
 * @property {object} flight     multipliers on the FLIGHT constants
 * @property {object} stats      absolute endurance figures
 * @property {object} hull       exterior mesh profile (see ShipExterior)
 * @property {string[]} drop     zone ids this hull does NOT have
 * @property {string} perk       compact summary for the card
 */

/** @type {ShipClass[]} */
export const SHIP_CLASSES = [
  {
    id: 'aethon', crew: 6,
    name: 'SURVEY CUTTER',
    hullName: 'HSV AETHON',
    role: 'HEAVY SURVEY VESSEL · RATED SIX',
    blurb: 'The commission hull. Thirteen compartments, four radiator wings and '
      + 'a three-bell drive, rated for a crew of six and carrying one. Slow to '
      + 'turn, hard to break, and there is a great deal of it to be alone in.',
    accent: '#b08040',
    flight: { thrust: 1.0, turn: 1.0, damp: 1.0, mass: 1.0 },
    stats: { hull: 100, shield: 100, fuel: 100, power: 100, slots: 120, scan: 1.0 },
    hull: { arms: 4, span: 1.0, nozzles: 3, scale: 1.0 },
    drop: [],
    perk: 'BALANCED · 13 COMPARTMENTS · 120 SLOTS',
  },
  {
    id: 'petrel', crew: 2,
    name: 'FAST COURIER',
    hullName: 'KSV PETREL',
    role: 'LIGHT DISPATCH HULL · RATED TWO',
    blurb: 'A mail runner with the mail taken out. Two wings, one bell, and a '
      + 'frame light enough to turn inside anything that comes looking. There '
      + 'is no medical bay, no laboratory and nowhere to put anything.',
    accent: '#8a9aa8',
    // Turns hard and accelerates hard; the damping is loose because a light
    // frame carries less momentum to fight.
    flight: { thrust: 1.45, turn: 1.6, damp: 0.85, mass: 0.62 },
    stats: { hull: 62, shield: 70, fuel: 88, power: 82, slots: 64, scan: 1.15 },
    hull: { arms: 2, span: 0.78, nozzles: 1, scale: 0.72 },
    // No lab, no core, no med bay, no workshop, no second cabin: a two-berth
    // hull with a galley, a head and somewhere to put the cargo.
    drop: ['research_lab', 'computer_core', 'med_bay', 'workshop', 'capt_quarters'],
    perk: 'FASTEST · FRAGILE · 8 COMPARTMENTS · 64 SLOTS',
  },
  {
    id: 'drayman', crew: 8,
    name: 'BULK HAULER',
    hullName: 'KSV DRAYMAN',
    role: 'HEAVY LIFT HULL · RATED EIGHT',
    blurb: 'Built to move ore and nothing else, then refitted badly for survey '
      + 'work. No wings at all — the radiators are internal and it runs hot. '
      + 'It will take a beating no other hull on the register would survive.',
    accent: '#a04e1a',
    // Enormous mass: it accelerates like a building and stops like one, and the
    // assist damping has to work much harder to null a rate.
    flight: { thrust: 0.72, turn: 0.55, damp: 1.5, mass: 1.9 },
    stats: { hull: 165, shield: 120, fuel: 130, power: 115, slots: 210, scan: 0.8 },
    hull: { arms: 0, span: 1.0, nozzles: 3, scale: 1.35 },
    // A working hull: it keeps the workshop and the reactor and loses the
    // science spaces and the captain's cabin it never had a captain for.
    drop: ['research_lab', 'computer_core', 'capt_quarters'],
    perk: 'TOUGHEST · SLOWEST · 210 SLOTS · RUNS HOT',
  },
  {
    id: 'harrier', crew: 4,
    name: 'ARMED PINNACE',
    hullName: 'KSV HARRIER',
    role: 'ESCORT CONVERSION · RATED FOUR',
    blurb: 'A patrol hull the company bought at auction and never repainted. '
      + 'Four short wings, two bells, a magazine where the laboratory used to '
      + 'be, and a deflector that draws more power than the galley.',
    accent: '#aa5a40',
    flight: { thrust: 1.15, turn: 1.25, damp: 1.0, mass: 0.85 },
    stats: { hull: 108, shield: 155, fuel: 78, power: 128, slots: 88, scan: 0.95 },
    hull: { arms: 4, span: 0.62, nozzles: 2, scale: 0.88 },
    drop: ['research_lab', 'bathroom'],
    perk: 'HEAVY SHIELD · AGILE · THIRSTY · 88 SLOTS',
  },
];

/** Look a class up by id, falling back to the commission hull. */
export function shipClass(id) {
  return SHIP_CLASSES.find((c) => c.id === id) ?? SHIP_CLASSES[0];
}

/**
 * Apply a class to the live systems. Called once at commission and again on
 * every save restore, so the two paths cannot drift.
 *
 * Endurance figures are ABSOLUTE, not multipliers, and `ShipSystems` clamps
 * against 100 everywhere — so the maxima travel with the class and the bars
 * read as a fraction of what THIS hull can hold, not of what the Aethon could.
 */
export function applyShipClass(cls, systems, inventory) {
  const c = typeof cls === 'string' ? shipClass(cls) : cls;
  systems.classId = c.id;
  systems.hullMax = c.stats.hull;
  systems.shieldMax = c.stats.shield;
  systems.fuelMax = c.stats.fuel;
  systems.powerMax = c.stats.power;
  systems.scanGain = c.stats.scan;
  if (inventory) inventory.capacitySlots = c.stats.slots;
  return c;
}

/**
 * HULL LIVERIES — what the ship is painted.
 *
 * The tint multiplies the plating albedo BEFORE lighting (see space.frag), so a
 * repaint reads as paint ON the metal: every panel edge, weld line, streak of
 * wear and value-stepped tile survives and simply comes through in the new
 * colour. A tint applied after lighting would have washed all of that flat.
 *
 * Every entry stays inside the palette families `context/01` sanctions — these
 * are industrial finishes on a working hull, not a colour wheel. Nothing here
 * is saturated enough to read as a toy, and there is deliberately no green in
 * the `#00ff00` family anywhere near it.
 */
export const LIVERIES = [
  { id: 'company', name: 'COMPANY GREY', tint: [1.00, 1.00, 1.00],
    note: 'Kestrel factory finish. Unpainted since the yard.' },
  { id: 'rust', name: 'OXIDE', tint: [1.12, 0.86, 0.68],
    note: 'Primer showing through where the topcoat gave up.' },
  { id: 'void', name: 'VOID BLACK', tint: [0.55, 0.58, 0.66],
    note: 'Salvager habit: harder to see, harder to find.' },
  { id: 'ice', name: 'GLACIER', tint: [0.82, 0.94, 1.14],
    note: 'Survey white, for working close to a star.' },
  { id: 'ochre', name: 'HAZARD OCHRE', tint: [1.20, 0.98, 0.60],
    note: 'High-visibility yard paint. Nobody rams you twice.' },
  { id: 'olive', name: 'FIELD OLIVE', tint: [0.86, 0.96, 0.74],
    note: 'Surplus military stock, applied with a roller.' },
  { id: 'oxblood', name: 'OXBLOOD', tint: [1.10, 0.72, 0.70],
    note: 'A Vrenn trade fleet colour, worn out of sentiment.' },
  { id: 'slate', name: 'DEEP SLATE', tint: [0.74, 0.80, 0.92],
    note: 'Cold blue-grey. The lane haulers all wear it.' },
];

/** Look a livery up by id, falling back to the factory finish. */
export function livery(id) {
  return LIVERIES.find((l) => l.id === id) ?? LIVERIES[0];
}
