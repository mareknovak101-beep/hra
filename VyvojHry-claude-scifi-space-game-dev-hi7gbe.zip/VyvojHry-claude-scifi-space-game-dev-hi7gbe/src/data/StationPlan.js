/**
 * STATION PLAN — the deck you walk when you dock.
 *
 * Docking has meant a menu since Phase 4: the clamps take, the fuel gauge fills,
 * and a DOM panel opens over the cockpit. The owner's ask was to physically go
 * aboard and buy things at shops, and this is the deck that makes that possible.
 *
 * IT IS THE SAME BUILDER. `ShipMap` takes a plan now (see SHIP_PLAN there), and
 * everything below is data fed to the identical machinery: room shells, corridor
 * shells, door frames, the greeble pass, the collision map and the interact
 * raycast. Nothing about the ship's own geometry moved to allow it — the deck
 * graph is what three sessions of audits stabilised and it should not be
 * rewritten to add a feature somewhere else.
 *
 * THE SHAPE, and why it is this shape rather than a ring:
 *
 *   DOCKING ARM    where your ship is clamped. The way home, and the only zone
 *                  with windows, so the first and last thing you see aboard is
 *                  your own hull outside the glass.
 *   CONCOURSE      one long hall, tall, with the shopfronts opening off it. A
 *                  station's public space is a street, and a street is legible
 *                  in a way a hub-and-spoke is not.
 *   FOUR COUNTERS  chandler (general goods), broker (hulls), outfitter (parts
 *                  and ordnance), and a bar. Each is a compartment with a
 *                  counter you walk up to and press E at — the trade UI is
 *                  still the trade UI, it just has a place now.
 *   HARBOUR OFFICE the administrative end: manifests, a save terminal, and the
 *                  station's own log.
 *
 * Coordinates: x = starboard(+)/port(-), z = fore(0)→aft(+), y = up. Same
 * convention as the ship, because the same builder reads them.
 */

const TEX_CONCOURSE = { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' };
const TEX_SHOP = { wall: 'wall_tile', floor: 'floor_plate', ceil: 'ceiling_panel' };
const TEX_DOCK = { wall: 'wall_military', floor: 'floor_hazard', ceil: 'ceiling_pipes' };

/** Where you stand when the airlock cycles: on the dock arm, facing inboard. */
export const STATION_SPAWN = { pos: [0, 0, 2.4], yaw: Math.PI, pitch: 0 };

export const STATION_ZONES = [
  {
    id: 'dock_arm', kind: 'room', name: 'DOCKING ARM', h: 3.4,
    rect: { x0: -4, x1: 4, z0: 0, z1: 7 }, tex: TEX_DOCK, surface: 'grating',
    // The only glass on the deck, and it looks back at your own ship. A station
    // that never shows you the thing you arrived in is a corridor set.
    windows: [
      { wall: 'nz', center: -2.1, w: 1.5, y0: 1.0, y1: 2.5 },
      { wall: 'nz', center: 2.1, w: 1.5, y0: 1.0, y1: 2.5 },
    ],
  },
  {
    id: 'concourse', kind: 'room', name: 'CONCOURSE', h: 5.2,
    rect: { x0: -6, x1: 6, z0: 11, z1: 37 }, tex: TEX_CONCOURSE, surface: 'metal',
  },
  { id: 'chandler', kind: 'room', name: 'CHANDLER', h: 3.0, rect: { x0: -12, x1: -6, z0: 13, z1: 20 }, tex: TEX_SHOP, surface: 'metal' },
  { id: 'outfitter', kind: 'room', name: 'OUTFITTER', h: 3.0, rect: { x0: 6, x1: 12, z0: 13, z1: 20 }, tex: { wall: 'wall_engine', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'broker', kind: 'room', name: 'HULL BROKER', h: 3.0, rect: { x0: -12, x1: -6, z0: 24, z1: 31 }, tex: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'taproom', kind: 'room', name: 'TAPROOM', h: 3.0, rect: { x0: 6, x1: 12, z0: 24, z1: 31 }, tex: { wall: 'wall_tile', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  {
    id: 'harbour_office', kind: 'room', name: 'HARBOUR OFFICE', h: 3.0,
    rect: { x0: -5, x1: 5, z0: 41, z1: 48 }, tex: TEX_CONCOURSE, surface: 'metal',
  },

  // -- THE REST OF THE STATION (0.53.0) -----------------------------------------
  //
  // Four counters and an office is a shopping arcade, not a place people live.
  // These are the compartments that make it somewhere with a night shift: a
  // clinic, bunks for crews between hulls, a bonded transfer bay where the
  // cargo actually moves, and the office that decides who is allowed in.
  //
  // All four open off the concourse or the aft passage, so the street is still
  // the spine and the deck is still legible from the dock arm.
  { id: 'clinic', kind: 'room', name: 'STATION CLINIC', h: 3.0, rect: { x0: -12, x1: -6, z0: 32, z1: 37 }, tex: { wall: 'fixture_white', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'bunkhouse', kind: 'room', name: 'TRANSIT BUNKS', h: 2.8, rect: { x0: 6, x1: 12, z0: 32, z1: 37 }, tex: TEX_CONCOURSE, surface: 'metal' },
  { id: 'transfer', kind: 'room', name: 'BONDED TRANSFER', h: 4.6, rect: { x0: -13, x1: -5, z0: 41, z1: 50 }, tex: { wall: 'wall_cargo', floor: 'floor_cargo', ceil: 'ceiling_pipes' }, surface: 'grating' },
  { id: 'custom', kind: 'room', name: 'CUSTOMS POST', h: 3.0, rect: { x0: 5, x1: 12, z0: 41, z1: 47 }, tex: TEX_DOCK, surface: 'metal' },

  // -- the spine ---------------------------------------------------------------
  {
    id: 'st_lock', kind: 'corridor', type: 'B', shape: 'flat', name: 'ACCESS LOCK',
    rect: { x0: -1.5, x1: 1.5, z0: 7, z1: 11 }, h: 2.6, tex: TEX_DOCK, surface: 'grating',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.46, 9], flicker: 'occasional_cut', fixture: { len: 0.9 } }],
  },
  {
    id: 'st_aft', kind: 'corridor', type: 'C', shape: 'buttress', name: 'OFFICE PASSAGE',
    rect: { x0: -2, x1: 2, z0: 37, z1: 41 }, h: 3.2, tex: TEX_CONCOURSE, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 3.0, 39], fixture: { len: 1.2 } }],
  },
];

export const STATION_CONNECTIONS = [
  { id: 'sp_dock_lock', kind: 'portal', a: 'dock_arm', b: 'st_lock', plane: 'z', at: 7, center: 0, w: 2.4, h: 2.5 },
  { id: 'sp_lock_conc', kind: 'portal', a: 'st_lock', b: 'concourse', plane: 'z', at: 11, center: 0, w: 2.4, h: 2.5 },
  { id: 'sd_chandler', kind: 'door', a: 'concourse', b: 'chandler', plane: 'x', at: -6, center: 16.5 },
  { id: 'sd_outfitter', kind: 'door', a: 'concourse', b: 'outfitter', plane: 'x', at: 6, center: 16.5 },
  { id: 'sd_broker', kind: 'door', a: 'concourse', b: 'broker', plane: 'x', at: -6, center: 27.5 },
  { id: 'sd_taproom', kind: 'door', a: 'concourse', b: 'taproom', plane: 'x', at: 6, center: 27.5 },
  { id: 'sp_conc_aft', kind: 'portal', a: 'concourse', b: 'st_aft', plane: 'z', at: 37, center: 0, w: 3.2, h: 3.0 },
  { id: 'sd_office', kind: 'door', a: 'st_aft', b: 'harbour_office', plane: 'z', at: 41, center: 0, w: 2.0, h: 2.4 },
  { id: 'sd_clinic', kind: 'door', a: 'concourse', b: 'clinic', plane: 'x', at: -6, center: 34.5 },
  { id: 'sd_bunks', kind: 'door', a: 'concourse', b: 'bunkhouse', plane: 'x', at: 6, center: 34.5 },
  { id: 'sd_transfer', kind: 'door', a: 'harbour_office', b: 'transfer', plane: 'x', at: -5, center: 45 },
  { id: 'sd_custom', kind: 'door', a: 'harbour_office', b: 'custom', plane: 'x', at: 5, center: 44 },
];
