/**
 * LANDFORMS — the shape a particular kind of world takes, over the WHOLE world.
 *
 * Every archetype in SurfaceGen used to share ONE height function: four octaves
 * of sine products at a vertical scale of about nine units over an
 * eighteen-hundred-unit patch. A lava world and a glacier were the same
 * corrugated plane in different colours, and the plane was flat enough that the
 * screenshot of it reads as a painted floor. 0.36.0 replaced that with real
 * fields; 0.43.0 gave each world two of them meeting along a province boundary.
 *
 * 0.45.0 MOVES THEM ONTO THE SPHERE, and that is a different kind of change.
 *
 * Until now a landform was `f(x, z)` on a plane, and the plane was a
 * thirty-two-hundred-unit square with a wall around it. However good the field
 * was, the world was a square: walk far enough in any direction and you stopped.
 * A field on a plane cannot be wrapped onto a globe without tearing at a seam,
 * pinching at the poles, or repeating.
 *
 * So a landform is now `f(P, seed)` where `P` is a point ON THE BODY'S SPHERE —
 * a six-element scratch carrying the sample position in noise space and the unit
 * direction it came from. Sampling a 3D field on a sphere has no seam because
 * there is no edge, no pole because every direction is the same kind of
 * direction, and no repeat because the surface never revisits a point in noise
 * space. The result is a whole planet: unbounded in every direction, the same
 * place when you come back to it, and different everywhere else.
 *
 * P LAYOUT: `[px, py, pz, nx, ny, nz]`.
 *   `n` is the unit direction — the geographic position on the body.
 *   `p` is `n * F`, where `F` is the body's radius expressed in noise units
 *       (SurfaceGen sets it so one noise unit is ~620 m of ground, as before).
 * `F = |p|`, so a field that needs true arc length — a dune spacing, a belt
 * width, the distance to a crater rim — recovers it as `angle * |p|` and comes
 * out in the same units the flat version used.
 *
 * WHAT MAKES EACH ONE READ. In every case it is a specific field, not a tuning:
 *
 *   mountains  RIDGED noise. Fractal sums give lumps; only `(1-|n|)²` gives a
 *              crest line, and a crest line is what a mountain is.
 *   dunes      billow along the wind, crests sharpened and lee faces steep, and
 *              on a sphere the wind is ZONAL — dune ranks run along parallels,
 *              because that is what trade winds do to sand.
 *   mesas      terracing. Hard flats and short risers, because strata weather
 *              at different rates.
 *   canyons    a plateau MINUS a warped channel network. Cut, not built.
 *   polygons   Worley cells. Patterned ground is a Voronoi partition and no
 *              amount of fbm makes a cell boundary.
 *   icefield   long parallel pressure ridges, plus crevasses cut across them.
 *   flows      channelised billow with collapse pits — pahoehoe and lava tubes.
 *   shards     Worley ridges with vertical faces: fractured plate.
 *   chaos      steep broken relief at every scale, for a body with no gravity
 *              worth the name to smooth it.
 *   volcano    a CONE, at a real place, one of many scattered over the globe.
 *   basin      an impact structure with a rim and a ring, likewise.
 *   foldbelt   parallel anticlines running along a great circle.
 *   rift       a graben along a great circle, with step faults down to it.
 *
 * Domain warp is applied inside the ones that want it rather than uniformly:
 * warping a dune field destroys the wind direction that makes it a dune field.
 */
import {
  fbm3, ridged3, billow3, worley3, warp3, seedDir, terrace,
} from './TerrainNoise.js';

const W = [0, 0, 0];  // shared warp scratch — see TerrainNoise.warp3
const AX = [0, 0, 0]; // shared great-circle pole / feature centre scratch
const CF = [0, 0, 0, 0]; // shared cell-feature scratch: [dx, dy, dz, hash]

/** Angular distance from the sample direction to a unit axis, in noise units. */
function arcTo(P, ax) {
  const d = Math.max(-1, Math.min(1, P[3] * ax[0] + P[4] * ax[1] + P[5] * ax[2]));
  return Math.acos(d) * Math.hypot(P[0], P[1], P[2]);
}

/**
 * Signed distance ACROSS a great-circle belt whose pole is `ax`, in noise units.
 *
 * A belt on a sphere is the set of points at a constant angle from a pole, so
 * "how far across the belt am I" is the arcsine of the projection — and because
 * it is a real spherical construction, the belt closes on itself all the way
 * round the world instead of running off the edge of a square.
 */
function beltAcross(P, ax) {
  const d = Math.max(-1, Math.min(1, P[3] * ax[0] + P[4] * ax[1] + P[5] * ax[2]));
  return Math.asin(d) * Math.hypot(P[0], P[1], P[2]);
}

/** Latitude arc, in noise units. What a zonal wind organises everything around. */
function latArc(P) {
  return Math.asin(Math.max(-1, Math.min(1, P[4]))) * Math.hypot(P[0], P[1], P[2]);
}

/** 3D hash → [0,1). Local copy so the cell helpers do not import one. */
function hc(ix, iy, iz, seed) {
  let h = (ix | 0) * 0x27d4eb2d ^ (iy | 0) * 0x9e3779b1 ^ (iz | 0) * 0x165667b1
    ^ (seed | 0);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d);
  h = Math.imul(h ^ (h >>> 12), 0x297a2d39);
  h ^= h >>> 15;
  return (h >>> 0) / 4294967296;
}

/**
 * NEAREST SCATTERED FEATURE, on a jittered 3D lattice of cell size `cell`.
 *
 * This is what puts a volcano, an impact basin or a crater at a PLACE rather
 * than in a distribution. A seeded single point on a globe is useless — the
 * player would never find it — so the features that have a location are
 * scattered on a lattice: one per cell, jittered, with its size and shape
 * hashed from the cell index. Deterministic, global, and dense enough that
 * flying for a few minutes brings you to one.
 *
 * Writes `[dist, hashA, hashB, hashC]` into `out`. `dist` is in noise units.
 */
function nearestFeature(out, P, cell, seed) {
  const s = 1 / cell;
  const x = P[0] * s, y = P[1] * s, z = P[2] * s;
  const xi = Math.floor(x), yi = Math.floor(y), zi = Math.floor(z);
  let best = 1e9, bh = 0, bi = 0, bj = 0;
  for (let dz = -1; dz <= 1; dz++) {
    for (let dy = -1; dy <= 1; dy++) {
      for (let dx = -1; dx <= 1; dx++) {
        const cx = xi + dx, cy = yi + dy, cz = zi + dz;
        const h0 = hc(cx, cy, cz, seed);
        const px = cx + h0;
        const py = cy + hc(cx, cy, cz, seed ^ 0x2f1b7a41);
        const pz = cz + hc(cx, cy, cz, seed ^ 0x5bf03635);
        const ex = x - px, ey = y - py, ez = z - pz;
        const d = Math.sqrt(ex * ex + ey * ey + ez * ez);
        if (d < best) {
          best = d; bh = h0;
          bi = hc(cx, cy, cz, seed ^ 0x11f27b03);
          bj = hc(cx, cy, cz, seed ^ 0x7d3e91c5);
        }
      }
    }
  }
  out[0] = best * cell; out[1] = bh; out[2] = bi; out[3] = bj;
  return out;
}

export const LANDFORM = {
  /**
   * ANCIENT PLAINS. Long low swells and nothing else — deliberately the
   * quietest field in the set, because on a cratered world the craters are the
   * landscape and a busy base terrain fights them.
   */
  plains(P, s) {
    return 0.5 + fbm3(P[0] * 0.9, P[1] * 0.9, P[2] * 0.9, s, 4, 2.0, 0.45) * 0.5;
  },

  /**
   * MOUNTAINS. Warped ridged multifractal over a broad fbm base, so ranges run
   * in bent chains rather than radiating from a point, with real valleys
   * between them instead of gaps.
   */
  mountains(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.55, 0.42);
    const r = ridged3(W[0] * 0.8, W[1] * 0.8, W[2] * 0.8, s, 6, 2.09, 0.5);
    const base = fbm3(P[0] * 0.35, P[1] * 0.35, P[2] * 0.35, s + 51, 3) * 0.5 + 0.5;
    // r^1.35 pushes the valleys down and leaves the crests where they are, which
    // is the difference between hills and a range with relief between them.
    return Math.min(1, Math.pow(r, 1.35) * 0.82 + base * 0.28);
  },

  /**
   * DUNE SEA, and on a sphere it knows which way the wind blows: ranks run
   * along the parallels, because a planet's low-latitude circulation is zonal
   * and sand goes where the wind puts it. The crest profile is asymmetric —
   * long windward ramp, short steep slip face — and that asymmetry IS the read.
   */
  dunes(P, s) {
    const u = latArc(P);
    const meander = fbm3(P[0] * 0.5, P[1] * 0.08, P[2] * 0.5, s + 909, 3) * 0.6;
    const t = (u * 2.4 + meander * 2.2) % 1;
    const tt = t < 0 ? t + 1 : t;
    const prof = tt < 0.72 ? tt / 0.72 : 1 - (tt - 0.72) / 0.28;
    const draa = billow3(P[0] * 0.3, P[1] * 0.3, P[2] * 0.3, s + 17, 3) * 0.55;
    return Math.min(1, prof * 0.62 + draa * 0.5);
  },

  /**
   * MESAS AND BUTTES. Terraced warped fbm: flat tops at a few discrete levels,
   * short vertical risers, talus at the feet once erosion has run.
   */
  mesas(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.7, 0.3);
    const h = fbm3(W[0] * 0.75, W[1] * 0.75, W[2] * 0.75, s, 5, 2.05, 0.48) * 0.5 + 0.5;
    return terrace(h, 5, 0.86);
  },

  /**
   * CANYON COUNTRY. Start from a high plateau and CUT. The channel network is
   * a ridged field inverted and thresholded, so the cuts branch and join the
   * way drainage does rather than crossing each other at random.
   */
  canyons(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.45, 0.55);
    const plateau = terrace(
      fbm3(P[0] * 0.4, P[1] * 0.4, P[2] * 0.4, s + 31, 4) * 0.5 + 0.5, 3, 0.6);
    const channel = ridged3(W[0] * 1.15, W[1] * 1.15, W[2] * 1.15, s + 88, 5, 2.11, 0.55);
    // Only the top of the ridged field becomes a cut, so the canyons are narrow.
    const cut = Math.max(0, channel - 0.52) / 0.48;
    return Math.max(0.02, plateau * 0.92 - cut * 0.85);
  },

  /**
   * ARCHIPELAGO SHELF. Land above a sea level, a flat pan below it. The
   * flat is the whole point — a coastline needs something to be a coastline
   * against.
   */
  shelf(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.6, 0.35);
    const h = fbm3(W[0] * 0.85, W[1] * 0.85, W[2] * 0.85, s, 5, 2.06, 0.5) * 0.5 + 0.5;
    const sea = 0.46;
    if (h < sea) return sea - (sea - h) * 0.12;   // shallow shelf, nearly flat
    return sea + Math.pow((h - sea) / (1 - sea), 1.25) * (1 - sea);
  },

  /** ROLLING HILLS under a canopy: busy at small scale, gentle at large. */
  hills(P, s) {
    const base = fbm3(P[0] * 0.5, P[1] * 0.5, P[2] * 0.5, s, 3, 2.0, 0.5) * 0.5 + 0.5;
    const rough = fbm3(P[0] * 3.1, P[1] * 3.1, P[2] * 3.1, s + 401, 3) * 0.5 + 0.5;
    return Math.min(1, base * 0.78 + rough * 0.3);
  },

  /**
   * ICE FIELD. Parallel pressure ridges where two sheets meet, running along a
   * great circle so the stress field closes on itself the way a real ice cap's
   * does, with crevasses cut ACROSS them — the crossing is what makes it read
   * as ice under stress rather than as a corrugated roof.
   */
  icefield(P, s) {
    seedDir(AX, s + 4001);
    const u = beltAcross(P, AX);
    const ridgeF = ridged3(u * 1.6, P[1] * 0.35, P[2] * 0.35, s, 4, 2.1, 0.5);
    const sheet = fbm3(P[0] * 0.45, P[1] * 0.45, P[2] * 0.45, s + 61, 3) * 0.5 + 0.5;
    seedDir(AX, s + 4002);
    const cre = ridged3(beltAcross(P, AX) * 2.3, u * 0.5, P[0] * 0.4, s + 733, 3);
    const slot = Math.max(0, cre - 0.74) / 0.26;
    return Math.max(0.02, sheet * 0.5 + ridgeF * 0.62 - slot * 0.55);
  },

  /**
   * PATTERNED GROUND. Freeze-thaw sorts the regolith into polygons; the cell
   * boundaries stand slightly proud and the centres dish. Worley, straight.
   */
  polygons(P, s) {
    const cell = worley3(P[0] * 1.35, P[1] * 1.35, P[2] * 1.35, s);
    const edge = Math.min(1, cell * 1.6);
    const base = fbm3(P[0] * 0.4, P[1] * 0.4, P[2] * 0.4, s + 11, 4) * 0.5 + 0.5;
    return Math.min(1, base * 0.72 + (1 - edge) * 0.42);
  },

  /**
   * LAVA FLOWS. Billow piled into channels, with collapse pits where the roof
   * of a tube has fallen in. Low relief and violent texture — the opposite of
   * a mountain range, and the reason `rough` alone could never produce it.
   */
  flows(P, s) {
    warp3(W, P[0], P[1], P[2], s, 1.1, 0.22);
    const pillow = billow3(W[0] * 2.2, W[1] * 2.2, W[2] * 2.2, s, 4, 2.13, 0.52);
    const channel = ridged3(P[0] * 0.7, P[1] * 0.7, P[2] * 0.7, s + 55, 3);
    const pits = worley3(P[0] * 0.9, P[1] * 0.9, P[2] * 0.9, s + 313);
    const pit = pits < 0.26 ? (0.26 - pits) / 0.26 : 0;
    return Math.max(0.02, 0.32 + pillow * 0.5 + channel * 0.24 - pit * 0.7);
  },

  /** SULPHUR TERRACES: precipitated benches around vents, hard-stepped. */
  terraces(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.8, 0.26);
    const h = billow3(W[0] * 0.95, W[1] * 0.95, W[2] * 0.95, s, 4, 2.04, 0.5);
    return terrace(h, 7, 0.9);
  },

  /**
   * PRESSURE FLOOR. Almost nothing: broad shallow swells under a sky you
   * cannot see forty metres through. Deliberately the flattest field here,
   * because on this world the ATMOSPHERE is the antagonist and a dramatic
   * skyline would be a distraction you could not see anyway.
   */
  flats(P, s) {
    return 0.5 + fbm3(P[0] * 0.55, P[1] * 0.55, P[2] * 0.55, s, 3, 2.0, 0.4) * 0.28;
  },

  /**
   * FRACTURED PLATE. Worley ridges with the cell walls standing as sharp
   * faces: graphite crust that rings hollow and breaks in slabs.
   */
  shards(P, s) {
    const c = worley3(P[0] * 1.1, P[1] * 1.1, P[2] * 1.1, s);
    const wall = Math.max(0, 1 - c * 2.3);
    const base = fbm3(P[0] * 0.6, P[1] * 0.6, P[2] * 0.6, s + 77, 4) * 0.5 + 0.5;
    return Math.min(1, base * 0.55 + wall * 0.75);
  },

  /**
   * CHAOS. A body too small for gravity to have smoothed anything: steep,
   * broken and self-similar at every scale, with overhang-steep faces that the
   * erosion pass is deliberately given a high talus angle so it does not sand
   * them off.
   */
  chaos(P, s) {
    warp3(W, P[0], P[1], P[2], s, 1.4, 0.5);
    const a = ridged3(W[0] * 1.3, W[1] * 1.3, W[2] * 1.3, s, 5, 2.2, 0.58);
    const b = billow3(P[0] * 2.6, P[1] * 2.6, P[2] * 2.6, s + 191, 4);
    return Math.min(1, a * 0.7 + b * 0.45);
  },

  /**
   * BADLANDS. A soft plateau dissected to death: dense narrow gullies at three
   * scales cut into terraced beds, leaving knife ridges between them. What
   * separates this from `canyons` is DENSITY — canyons are a few big cuts in a
   * lot of plateau, badlands are a lot of plateau left over from the cutting.
   */
  badlands(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.5, 0.34);
    const beds = terrace(
      fbm3(W[0] * 0.55, W[1] * 0.55, W[2] * 0.55, s, 4) * 0.5 + 0.5, 6, 0.72);
    const g1 = ridged3(P[0] * 1.7, P[1] * 1.7, P[2] * 1.7, s + 12, 4, 2.1, 0.55);
    const g2 = ridged3(P[0] * 4.3, P[1] * 4.3, P[2] * 4.3, s + 77, 3, 2.2, 0.5);
    const cut = Math.max(0, g1 - 0.44) / 0.56 * 0.62 + Math.max(0, g2 - 0.58) / 0.42 * 0.3;
    return Math.max(0.02, beds * 0.96 - cut * 0.72);
  },

  /**
   * KARST. Towers. Worley cells inverted so the CELL is the pillar and the
   * boundary is the gap, raised to a high power so the walls go vertical, with
   * sinkholes punched through the floor between them. Nothing else in the set
   * produces isolated stacks with air all round them.
   */
  karst(P, s) {
    const c = worley3(P[0] * 0.85, P[1] * 0.85, P[2] * 0.85, s);
    const tower = Math.pow(Math.max(0, 1 - c * 1.9), 0.45);
    const sink = worley3(P[0] * 1.9, P[1] * 1.9, P[2] * 1.9, s + 404);
    const hole = sink < 0.2 ? (0.2 - sink) / 0.2 : 0;
    const floor = fbm3(P[0] * 0.5, P[1] * 0.5, P[2] * 0.5, s + 88, 3) * 0.5 + 0.5;
    return Math.max(0.02, floor * 0.3 + tower * 0.8 - hole * 0.55);
  },

  /**
   * VOLCANOES — and note the plural, which is the whole point of moving these
   * fields onto a sphere.
   *
   * The flat version put ONE cone at one seeded place in a 3200-unit square,
   * because a square is small enough that one landmark is enough. A planet is
   * not: a single volcano on a globe is a thing you would never find. They are
   * scattered on a lattice now, one per cell, each with its own hashed height,
   * caldera and flank gullies — so "volcanic province" means a landscape you
   * can fly across finding cone after cone, and the one on the horizon is a
   * real place you can go to.
   */
  volcano(P, s) {
    nearestFeature(CF, P, 26, s + 9101);
    const R = 6 + CF[1] * 9;             // cone radius, noise units (~3.7-9 km)
    const d = CF[0];
    const cone = Math.max(0, 1 - d / R) ** 1.6;
    // Caldera: the summit is bitten out, with a rim standing proud of the floor.
    const cal = d < R * 0.15 ? (1 - d / (R * 0.15)) : 0;
    // Radial gullies — the ash flanks are cut by every rainstorm since it built.
    const gully = Math.abs(Math.sin(
      (CF[2] * 40 + fbm3(P[0] * 0.8, P[1] * 0.8, P[2] * 0.8, s + 5, 2) * 9) * 1.7));
    const skirt = fbm3(P[0] * 0.9, P[1] * 0.9, P[2] * 0.9, s + 61, 4) * 0.5 + 0.5;
    return Math.max(0.02, cone * (0.72 + CF[3] * 0.4) - cal * 0.42
      - gully * cone * 0.16 + skirt * 0.24);
  },

  /**
   * FJORDS. A high plateau with deep, straight-walled glacial troughs cut into
   * it and flooded flat at the bottom. The flat bottoms are what make it read as
   * drowned rather than merely eroded — a V-valley is a river, a U-valley with a
   * level floor is ice.
   */
  fjords(P, s) {
    warp3(W, P[0], P[1], P[2], s, 0.4, 0.5);
    const plateau = fbm3(W[0] * 0.6, W[1] * 0.6, W[2] * 0.6, s, 5, 2.05, 0.48) * 0.5 + 0.5;
    const trough = ridged3(P[0] * 0.95, P[1] * 0.95, P[2] * 0.95, s + 141, 4, 2.08, 0.55);
    const cut = Math.max(0, trough - 0.46) / 0.54;
    const h = plateau * 0.95 - cut * 1.05;
    // Below the waterline everything is one flat pan.
    return h < 0.16 ? 0.16 - (0.16 - h) * 0.06 : h;
  },

  /**
   * IMPACT BASINS, scattered like the volcanoes and for the same reason: one
   * enormous shallow depression with a raised rim, a ring-mountain arc inside
   * it, and a dead-flat playa floor. The counterpart to `volcano` — one built
   * the landscape up, this one took it away.
   */
  basin(P, s) {
    nearestFeature(CF, P, 44, s + 7717);
    const R = 12 + CF[1] * 14;
    const d = CF[0] / R;
    const rim = Math.exp(-((d - 0.86) * (d - 0.86)) / 0.030) * 0.62;
    const ring = Math.exp(-((d - 0.44) * (d - 0.44)) / 0.010) * 0.30;
    const bowl = d < 1 ? -(1 - d * d) * 0.5 : 0;
    const floor = fbm3(P[0] * 1.2, P[1] * 1.2, P[2] * 1.2, s + 27, 4) * 0.5 + 0.5;
    // Inside the ring it is playa — flat, and deliberately so.
    const flat = d < 0.4 ? 0.86 : 0.34;
    return Math.max(0.02, 0.48 + bowl + rim + ring + floor * (1 - flat) * 0.5);
  },

  /**
   * FOLD BELT. Parallel anticlines — long straight ridges in rank, bent as a
   * set, with the beds plunging at the ends. On a sphere the belt runs along a
   * GREAT CIRCLE, so it wraps the whole world and closes on itself, which is
   * what an orogenic belt on a real planet does.
   */
  foldbelt(P, s) {
    seedDir(AX, s + 2207);
    const strike = arcTo(P, AX);
    const across = beltAcross(P, AX)
      + fbm3(strike * 0.35, P[1] * 0.2, P[2] * 0.2, s + 3, 3) * 1.7;
    const fold = Math.abs(Math.sin(across * 3.1));
    const plunge = fbm3(strike * 0.5, across * 0.15, P[0] * 0.1, s + 210, 3) * 0.5 + 0.5;
    const base = fbm3(P[0] * 0.4, P[1] * 0.4, P[2] * 0.4, s + 9, 3) * 0.5 + 0.5;
    return Math.min(1, (1 - fold) ** 1.4 * 0.72 * plunge + base * 0.34);
  },

  /**
   * PINNACLES. Isolated needles standing off a low plain, the classic
   * low-gravity / sublimation form: a sparse Worley field with only the sharpest
   * peaks surviving a hard threshold, so most of the patch is floor and what
   * stands on it is genuinely tall.
   */
  pinnacles(P, s) {
    const c = worley3(P[0] * 0.6, P[1] * 0.6, P[2] * 0.6, s);
    const spike = Math.max(0, 1 - c * 3.4) ** 0.5;
    const fine = worley3(P[0] * 2.2, P[1] * 2.2, P[2] * 2.2, s + 55);
    const needle = Math.max(0, 1 - fine * 4.6) ** 0.6;
    const floor = fbm3(P[0] * 0.7, P[1] * 0.7, P[2] * 0.7, s + 12, 3) * 0.5 + 0.5;
    return Math.min(1, floor * 0.24 + spike * 0.86 + needle * 0.34);
  },

  /**
   * RIFT. A graben running along a great circle: two parallel scarps with a
   * dropped floor between them and subsidiary faults stepping down to it. A
   * tectonic form rather than an erosional one, and the only one here with a
   * hard straight edge — because a fault is a hard straight edge. On a sphere it
   * girdles the planet, which is what a spreading centre actually does.
   */
  rift(P, s) {
    seedDir(AX, s + 3301);
    const across = beltAcross(P, AX)
      + fbm3(arcTo(P, AX) * 0.4, P[1] * 0.2, P[2] * 0.2, s + 71, 3) * 0.6;
    const a = Math.abs(across);
    const drop = a < 0.34 ? 1 : a < 0.52 ? 0.55 : a < 0.7 ? 0.24 : 0;
    const shoulder = Math.exp(-((a - 0.78) * (a - 0.78)) / 0.02) * 0.5;
    const base = fbm3(P[0] * 0.55, P[1] * 0.55, P[2] * 0.55, s, 4) * 0.5 + 0.5;
    return Math.max(0.02, base * 0.78 + shoulder - drop * 0.62);
  },
};

/**
 * IMPACT CRATERING, as a global field.
 *
 * This used to be a loop in `buildTerrain`: roll twenty craters at random
 * positions inside the square and stamp them. That cannot survive the move to a
 * sphere — a crater has to be at a place on the WORLD, not at a place in the
 * current patch, or it would move every time the patch re-centred and vanish
 * when you flew away and came back.
 *
 * Same profile as the stamped version, which was the good part: a floor below
 * the plain, a rim standing proud, an ejecta apron outside it, and on the big
 * ones a CENTRAL PEAK — the single detail that says "this was an impact" rather
 * than "this is a hole". Two lattices, coarse and fine, so a heavily cratered
 * world genuinely has craters inside craters.
 *
 * @returns height offset in normalised units (multiply by relief, as the fields)
 */
export function impacts(P, s, density) {
  if (density <= 0.001) return 0;
  let k = 0;
  // Three lattices — eighteen kilometres, seven, and two and a half — because
  // "craters inside craters inside craters" is the actual feature line for an
  // airless world and one scale cannot produce it.
  for (let pass = 0; pass < 3; pass++) {
    const cell = pass === 0 ? 30 : pass === 1 ? 11 : 4;
    nearestFeature(CF, P, cell, s + 5501 + pass * 977);
    // Not every cell gets one: `density` is the archetype's cratering figure,
    // and the cell's own hash decides whether this one was ever struck.
    if (CF[2] > Math.min(0.95, density * 0.62)) continue;
    const R = cell * (0.16 + CF[1] * 0.30);
    const d = CF[0] / R;
    if (d > 1.5) continue;
    const depth = (0.18 + CF[3] * 0.30) * (pass === 0 ? 1 : pass === 1 ? 0.5 : 0.22);
    const peak = CF[1] > 0.55 ? depth * (0.35 + CF[3] * 0.3) : 0;
    if (d < 1) {
      k += -depth * (1 - d * d) + depth * 0.34 * d * d;
      if (peak && d < 0.28) k += peak * (1 - d / 0.28) * (1 - d / 0.28);
    } else {
      k += depth * 0.34 * Math.max(0, 1 - (d - 1) / 0.5);
    }
  }
  return k;
}

/** Look a landform up by id, falling back to the quietest one. */
export function landform(id) {
  return LANDFORM[id] ?? LANDFORM.plains;
}

/**
 * TWO LANDFORMS, ONE WORLD.
 *
 * The single flattest-reading thing about the first surfaces was not the relief
 * — it was the UNIFORMITY. One field ran corner to corner, so every direction
 * you turned gave you statistically the same view, and a landscape whose whole
 * content is visible from the first frame is wallpaper no matter how much
 * vertical range it has.
 *
 * A world now carries a primary and a secondary landform and a province field
 * decides, per sample, which one you are standing in. The transition is
 * SHARPENED rather than lerped: real terrain provinces meet along a boundary —
 * a scarp, a shoreline, the edge of a flow — and a slow cross-fade produces
 * neither one landscape nor the other but a mush of both. Sharpening leaves
 * most of the world decisively in one province and confines the blend to a band
 * you can stand on and see the join.
 *
 * On a sphere the province field is global too, so the provinces are continents:
 * they have shapes, they are in fixed places, and flying from one to another is
 * a journey with a boundary in the middle of it.
 *
 * @param {Function} a  primary field
 * @param {Function} b  secondary field
 * @param {number} bias -1 all primary … +1 all secondary
 * @param {number} rel2 how tall the secondary province is relative to the first
 */
export function provinces(a, b, bias = 0, rel2 = 1) {
  return (P, s) => {
    // Province scale: a few tenths of a radian, so a world carries a handful of
    // regions rather than one of each or a mosaic of hundreds.
    const p = fbm3(P[0] * 0.42, P[1] * 0.42, P[2] * 0.42, s + 6607, 3, 2.0, 0.5)
      + bias * 0.5;
    // Sharpen: a smoothstep over a narrow window centred on zero.
    const t = Math.max(0, Math.min(1, p * 2.6 + 0.5));
    const k = t * t * (3 - 2 * t);
    if (k < 0.004) return a(P, s);
    if (k > 0.996) return b(P, s) * rel2;
    return a(P, s) * (1 - k) + b(P, s) * rel2 * k;
  };
}
