/**
 * HackingMinigame — the terminal-intrusion ritual (Phase 7, context/04 §7). A
 * locked console throws up a grid of glyph cells cycling through a scrambled
 * cassette-terminal charset; the intruder has to lock a target sequence by
 * clicking the matching glyph before a bar of ICE (the countermeasure clock)
 * fills. Lock the whole sequence in time and the terminal yields; run out of
 * clock and it locks you out for this attempt. Pure DOM over the pixel plate,
 * so it works identically on touch and mouse.
 */
import { plasticButton, plasticPanel, hazardBar, framePanel, showScrim } from './Chrome.js';

const GLYPHS = '0123456789ABCDEF#%&@=+*<>/'.split('');

export class HackingMinigame {
  /** @param {(text:string)=>void} notify */
  constructor(notify) {
    this.notify = notify;
    this.visible = false;
    this.onDone = null;
    this._raf = null;

    this.root = document.createElement('div');
    this.root.style.cssText = plasticPanel([
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:44', 'display:none', 'width:min(360px,90vw)', 'padding:16px 18px',
      'text-align:center', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none',
    ].join(';'));

    this.title = document.createElement('div');
    this.title.textContent = 'ICE BREAK — INTRUSION';
    this.title.style.cssText = 'font-size:13px;letter-spacing:0.18em;color:#d0a060;margin-bottom:2px;';
    this.sub = document.createElement('div');
    this.sub.style.cssText = 'font-size:10px;color:#8a6030;margin-bottom:8px;';

    // target sequence readout
    this.seqRow = document.createElement('div');
    this.seqRow.style.cssText = 'display:flex;justify-content:center;gap:6px;margin-bottom:8px;';

    // ICE countermeasure bar
    this.iceWrap = document.createElement('div');
    this.iceWrap.style.cssText = 'height:8px;background:#0c0c12;border:1px solid #3a2a1a;margin-bottom:10px;overflow:hidden;';
    this.iceFill = document.createElement('div');
    this.iceFill.style.cssText = 'height:100%;width:0%;background:#aa2020;';
    this.iceWrap.appendChild(this.iceFill);

    // the clickable glyph grid
    this.grid = document.createElement('div');
    this.grid.style.cssText = 'display:grid;grid-template-columns:repeat(4,1fr);gap:6px;';

    this.root.append(this.title, hazardBar('70%'), this.sub, this.seqRow, this.iceWrap, this.grid);
    document.body.appendChild(this.root);
    framePanel(this.root, { seed: 43 });
  }

  /**
   * Start an intrusion. difficulty scales the sequence length and the clock.
   * @param {(success:boolean)=>void} onDone
   * @param {number} difficulty 1..3
   */
  /**
   * @param {(ok:boolean)=>void} onDone
   * @param {number} difficulty  3+difficulty glyphs to reproduce
   * @param {number} clockMult   ENGINEERING proficiency — more time on the
   *   countermeasure clock, which is the only thing that makes a long sequence
   *   winnable. See gameplay/Progression.js.
   */
  start(onDone, difficulty = 1, clockMult = 1) {
    this.onDone = onDone;
    this.clockMult = Math.max(0.5, clockMult || 1);
    if (!this.visible) showScrim(true);
    this.visible = true;
    const seqLen = 3 + difficulty; // 4..6 glyphs
    this.seqLen = seqLen;
    this.target = Array.from({ length: seqLen }, () => GLYPHS[(Math.random() * 16) | 0]);
    this.locked = 0; // how many of the sequence are locked in
    this.ice = 0;
    // Fill per second. A better engineer does not solve the puzzle for you —
    // the sequence is the same length — they just buy you the seconds to do it.
    this.iceRate = (0.06 + difficulty * 0.055) / this.clockMult;
    this.sub.textContent = 'LOCK THE SEQUENCE BEFORE THE ICE CLOSES';
    this._buildSeq();
    this._buildGrid();
    this.root.style.display = 'block';
    this._last = performance.now();
    this._tick();
  }

  _buildSeq() {
    this.seqRow.textContent = '';
    this.seqCells = this.target.map((g, i) => {
      const c = document.createElement('div');
      c.textContent = g;
      c.style.cssText = 'width:26px;height:30px;line-height:30px;font:14px monospace;' +
        'background:#0c0c12;border:1px solid #3a2a1a;color:#5a4830;';
      this.seqRow.appendChild(c);
      return c;
    });
    this._paintSeq();
  }

  _paintSeq() {
    this.seqCells.forEach((c, i) => {
      const done = i < this.locked;
      c.style.color = done ? '#d0a060' : '#5a4830';
      c.style.borderColor = i === this.locked ? '#b08040' : '#3a2a1a';
      c.style.background = done ? '#1a1710' : '#0c0c12';
    });
  }

  _buildGrid() {
    this.grid.textContent = '';
    this.cells = [];
    for (let i = 0; i < 12; i++) {
      const cell = document.createElement('div');
      cell.style.cssText = plasticButton('height:34px;line-height:22px;font-size:15px;padding:6px 0;');
      cell.textContent = GLYPHS[(Math.random() * GLYPHS.length) | 0];
      const pick = (e) => { e.preventDefault(); e.stopPropagation(); this._pick(cell); };
      cell.addEventListener('click', pick);
      cell.addEventListener('touchend', pick, { passive: false });
      this.grid.appendChild(cell);
      this.cells.push(cell);
    }
    // guarantee the needed glyph is somewhere on the board each cycle
    this._seedTarget();
  }

  _seedTarget() {
    const need = this.target[this.locked];
    if (!need) return;
    if (!this.cells.some((c) => c.textContent === need)) {
      this.cells[(Math.random() * this.cells.length) | 0].textContent = need;
    }
  }

  _pick(cell) {
    if (!this.visible) return;
    if (cell.textContent === this.target[this.locked]) {
      this.locked++;
      this._paintSeq();
      if (this.locked >= this.seqLen) return this._end(true);
      this._seedTarget();
    } else {
      // wrong glyph: the ICE lurches forward
      this.ice = Math.min(1, this.ice + 0.12);
    }
  }

  _tick() {
    const now = performance.now();
    const dt = Math.min(0.1, (now - this._last) / 1000);
    this._last = now;
    if (!this.visible) return;
    // scramble the grid so it reads as a live terminal; keep target reachable
    for (const c of this.cells) if (Math.random() < 0.08) c.textContent = GLYPHS[(Math.random() * GLYPHS.length) | 0];
    this._seedTarget();
    this.ice = Math.min(1, this.ice + this.iceRate * dt);
    this.iceFill.style.width = `${(this.ice * 100).toFixed(1)}%`;
    if (this.ice >= 1) return this._end(false);
    this._raf = requestAnimationFrame(() => this._tick());
  }

  _end(success) {
    if (this.visible) showScrim(false);
    this.visible = false;
    if (this._raf) cancelAnimationFrame(this._raf);
    this.root.style.display = 'none';
    const cb = this.onDone; this.onDone = null;
    cb?.(success);
  }

  cancel() { if (this.visible) this._end(false); }
}
