/**
 * Crosshair — amber, 5×5 max (context/07 checklist), center screen.
 * Widens by a pixel when an interactable is under it.
 */
import { RENDER, PALETTE } from '../core/Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';

export class Crosshair {
  constructor() {
    this.amber = hexToRgbf(PALETTE.HUD_AMBER[1]);
  }

  /** @param {boolean} active something interactable under the reticle */
  render(pix, active) {
    const cx = RENDER.UI_WIDTH / 2;
    const cy = RENDER.UI_HEIGHT / 2;
    const c = [this.amber[0], this.amber[1], this.amber[2], active ? 1 : 0.8];
    if (active) {
      // open bracket form, still within 5×5
      pix.rect(cx - 2, cy - 2, 1, 2, c);
      pix.rect(cx - 2, cy - 2, 2, 1, c);
      pix.rect(cx + 2, cy - 2, 1, 2, c);
      pix.rect(cx + 1, cy - 2, 2, 1, c);
      pix.rect(cx - 2, cy + 1, 1, 2, c);
      pix.rect(cx - 2, cy + 2, 2, 1, c);
      pix.rect(cx + 2, cy + 1, 1, 2, c);
      pix.rect(cx + 1, cy + 2, 2, 1, c);
    } else {
      pix.rect(cx, cy - 2, 1, 2, c);
      pix.rect(cx, cy + 1, 1, 2, c);
      pix.rect(cx - 2, cy, 2, 1, c);
      pix.rect(cx + 1, cy, 2, 1, c);
    }
  }
}
