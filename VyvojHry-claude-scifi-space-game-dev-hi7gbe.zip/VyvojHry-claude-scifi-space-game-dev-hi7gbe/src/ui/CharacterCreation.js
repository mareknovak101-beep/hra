/**
 * CharacterCreation — the pilot commission screen (Phase 8, context/05 §5).
 * The game's front door on a fresh save: name the sole survivor of a crew of
 * six and pick the service record they carry aboard. Each background seeds a
 * different opening — starting credits, a kit, and where the four powers start
 * with you — so no two runs begin the same. Shown once (skipped when a save
 * exists); its choice feeds TradingSystem, Inventory and FactionSystem before
 * the gate ever appears.
 *
 * DOM over the shared pixel-art plate, so it matches the rest of the chrome and
 * works on touch and mouse alike.
 */
import { SHIP_CLASSES, shipClass, LIVERIES, livery } from '../data/ShipClasses.js';
import { shipFit } from '../data/ShipFit.js';
import { plasticButton, plasticPanel, hazardBar, bulkheadFrame, pilotPNG, platePNG } from './Chrome.js';

export const BACKGROUNDS = [
  {
    id: 'lifer', name: 'COMPANY LIFER',
    blurb: 'Twenty years on Kestrel manifests. The company owes you — and it never forgets a debt, either direction.',
    credits: 150, faction: { kestrel: 15 }, accent: '#b08040',
    items: [['medkit_field', 1], ['ration_protein', 2], ['personal_tags_id', 1]],
    perk: 'KESTREL +15 · 150 CR · MEDKIT',
  },
  {
    id: 'salvager', name: 'VOID SALVAGER',
    blurb: 'You strip wrecks for a living, out past the buoys where salvage law is a rumour. The Drift have noticed you.',
    credits: 260, faction: { drift: -10 }, accent: '#8a9aa8',
    // Arc cells added with 0.23.0: the cutter was inert loot until personal
    // combat existed, and a tool with no charge is not a starting kit.
    items: [['fuel_cell_standard', 2], ['scanner_cell', 2], ['weapon_cutter', 1],
      ['ammo_cell', 2]],
    perk: '260 CR · FUEL ×2 · CUTTER +2 CELL · DRIFT −10',
  },
  {
    id: 'factor', name: 'VRENN FACTOR',
    blurb: 'You brokered cargo for the Combine before you flew it. Warm handshakes, fair quotes, very long memories.',
    credits: 60, faction: { vrenn: 25 }, accent: '#6f8f6a',
    items: [['coffee_pack', 2], ['tea_tin', 1], ['personal_letter_unsent', 1]],
    perk: 'VRENN +25 · 60 CR · SUNDRIES',
  },
  {
    id: 'officer', name: 'DECK OFFICER',
    blurb: 'Bridge-certified, clean record, steady hands and no illusions left about what the deep lanes cost.',
    credits: 120, faction: { kestrel: 5 }, accent: '#aa5a40',
    items: [['weapon_pistol', 1], ['ammo_slug', 2], ['bandage', 2],
      ['water_pouch', 2], ['personal_photo_crew', 1]],
    perk: '120 CR · SIDEARM +2 MAG · MEDS',
  },
];

// granted to every pilot regardless of background — the standard-issue kit
const BASE_KIT = [['ration_protein', 2], ['water_pouch', 2], ['bandage', 1],
  ['fuel_cell_standard', 1], ['personal_patch_mission', 1]];

export class CharacterCreation {
  constructor() {
    this.visible = false;
    this.pick = BACKGROUNDS[0].id;
    this.ship = SHIP_CLASSES[0].id;
    this.livery = LIVERIES[0].id;
    this.name = 'SURVEYOR';
    this.callsign = '';

    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:38', 'display:none',
      "font-family:'Courier New',monospace", 'letter-spacing:0.12em',
      'background:#000006', 'touch-action:pan-y',
    ].join(';');

    // Same bulkhead surround and deep-space backdrop as the main menu, per the
    // owner's concept art: the commission screen is a terminal in a room on the
    // ship, not a form floating on a black page.
    const { root: frame, content } = bulkheadFrame('SURVEY COMMISSION', { skySeed: 29 });
    this.root.appendChild(frame);
    const sub = document.createElement('div');
    sub.textContent = 'KESTREL EXTRACTION & SALVAGE CO. — SOLE SURVIVOR, HSV AETHON';
    sub.style.cssText = 'position:relative;margin-top:6px;color:#6f4f26;font-size:9px;'
      + 'letter-spacing:0.22em;text-align:center;';
    frame.insertBefore(sub, content);
    content.style.alignItems = 'stretch';
    content.style.gap = '14px';

    // -- left column: the portrait, framed like a personnel file photo -------
    const left = document.createElement('div');
    left.style.cssText = 'display:flex;flex-direction:column;gap:8px;flex:0 0 auto;'
      + 'align-items:center;justify-content:center;';
    this.portrait = document.createElement('div');
    this.portrait.style.cssText = 'width:168px;height:196px;image-rendering:pixelated;'
      + 'border:2px solid #4a361e;box-shadow:0 4px 16px #000000d0, inset 0 0 0 1px #000;'
      + 'background-size:100% 100%;background-repeat:no-repeat;';
    const idPlate = document.createElement('div');
    idPlate.style.cssText = 'width:168px;padding:5px 0;text-align:center;color:#c89a58;'
      + `font-size:9px;letter-spacing:0.2em;background:url("${platePNG(96, 20, 'button', 31)}") center/100% 100% no-repeat;`
      + 'image-rendering:pixelated;';
    idPlate.textContent = 'PERSONNEL FILE';
    this.fileLine = document.createElement('div');
    this.fileLine.style.cssText = 'width:168px;text-align:center;color:#7d6038;font-size:9px;letter-spacing:0.14em;';
    left.append(idPlate, this.portrait, this.fileLine);

    // -- right column: name + service record ---------------------------------
    const panel = document.createElement('div');
    panel.style.cssText = plasticPanel('flex:1 1 auto;max-width:560px;min-width:0;padding:12px 14px;'
      + 'display:flex;flex-direction:column;gap:8px;overflow-y:auto;');

    const nameRow = document.createElement('div');
    nameRow.style.cssText = 'display:flex;align-items:center;gap:10px;';
    const nameLbl = document.createElement('div');
    nameLbl.textContent = 'PILOT NAME';
    nameLbl.style.cssText = 'color:#8a7050;font-size:11px;min-width:88px;';
    this.nameInput = document.createElement('input');
    this.nameInput.type = 'text';
    this.nameInput.maxLength = 16;
    this.nameInput.value = this.name;
    this.nameInput.style.cssText = [
      'flex:1', 'min-width:0', 'background:#0c0c12', 'border:1px solid #3a2a1a', 'color:#d0a060',
      "font-family:'Courier New',monospace", 'font-size:13px', 'letter-spacing:0.18em',
      'padding:6px 10px', 'text-transform:uppercase', 'outline:none',
    ].join(';');
    this.nameInput.addEventListener('input', () => {
      this.name = this.nameInput.value.toUpperCase().replace(/[^A-Z0-9 .\-]/g, '') || 'SURVEYOR';
      this._paint();
    });
    nameRow.append(nameLbl, this.nameInput);
    panel.appendChild(nameRow);

    // CALLSIGN. Purely yours: it is what the gate, the HUD nameplate and the
    // journal call you, while PILOT NAME stays the company's record. Two names
    // for one person is exactly the sort of thing a corporation does.
    const csRow = document.createElement('div');
    csRow.style.cssText = 'display:flex;align-items:center;gap:10px;';
    const csLbl = document.createElement('div');
    csLbl.textContent = 'CALLSIGN';
    csLbl.style.cssText = 'color:#8a7050;font-size:11px;min-width:88px;';
    this.csInput = document.createElement('input');
    this.csInput.type = 'text';
    this.csInput.maxLength = 10;
    this.csInput.placeholder = 'OPTIONAL';
    this.csInput.style.cssText = [
      'flex:1', 'min-width:0', 'background:#0c0c12', 'border:1px solid #3a2a1a', 'color:#d0a060',
      "font-family:'Courier New',monospace", 'font-size:13px', 'letter-spacing:0.18em',
      'padding:6px 10px', 'text-transform:uppercase', 'outline:none',
    ].join(';');
    this.csInput.addEventListener('input', () => {
      this.callsign = this.csInput.value.toUpperCase().replace(/[^A-Z0-9.\-]/g, '');
      this._paint();
    });
    csRow.append(csLbl, this.csInput);
    panel.appendChild(csRow);

    // -- HULL. The single biggest choice on this screen: it decides how the ship
    // flies, how much it survives, how much it carries and how many rooms there
    // are to be alone in. Laid out as a compact row of plates rather than full
    // cards, so it does not push the service records off a short viewport.
    const hullLbl = document.createElement('div');
    hullLbl.textContent = '— ASSIGNED HULL —';
    hullLbl.style.cssText = 'color:#8a6030;font-size:10px;letter-spacing:0.3em;text-align:center;';
    panel.appendChild(hullLbl);
    const hullRow = document.createElement('div');
    hullRow.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;';
    this.hullCards = new Map();
    for (const sc of SHIP_CLASSES) {
      const t = document.createElement('div');
      t.style.cssText = 'flex:1 1 108px;min-width:0;padding:6px 8px;cursor:pointer;'
        + 'border:1px solid #2a2a36;background:#0e0e16;text-align:center;';
      const nm = document.createElement('div');
      nm.textContent = sc.name;
      nm.style.cssText = 'font-size:10px;letter-spacing:0.1em;color:#c09050;';
      const hn = document.createElement('div');
      hn.textContent = sc.hullName;
      hn.style.cssText = 'font-size:9px;color:#6f5636;letter-spacing:0.08em;margin-top:2px;';
      t.append(nm, hn);
      const pickHull = (e) => { e.preventDefault(); e.stopPropagation(); this.ship = sc.id; this._paint(); };
      t.addEventListener('click', pickHull);
      t.addEventListener('touchend', pickHull, { passive: false });
      hullRow.appendChild(t);
      this.hullCards.set(sc.id, { card: t, nm });
    }
    panel.appendChild(hullRow);
    // the chosen hull's dossier: blurb, then the four numbers that decide how it
    // feels, as bars rather than a table — this is a cockpit, not a spreadsheet
    this.hullInfo = document.createElement('div');
    this.hullInfo.style.cssText = 'font-size:10px;color:#8a7050;line-height:1.4;min-height:34px;';
    panel.appendChild(this.hullInfo);
    this.hullStats = document.createElement('div');
    this.hullStats.style.cssText = 'display:flex;flex-direction:column;gap:2px;';
    panel.appendChild(this.hullStats);

    // -- LIVERY. A row of swatches painted with the actual tint the shader will
    // apply, so what you pick is what you fly rather than a name you have to
    // imagine. The swatch is drawn over a mid-grey, which is roughly what the
    // plating averages to, so a multiply tint previews honestly.
    const livLbl = document.createElement('div');
    livLbl.textContent = '— HULL LIVERY —';
    livLbl.style.cssText = 'color:#8a6030;font-size:10px;letter-spacing:0.3em;text-align:center;';
    panel.appendChild(livLbl);
    const livRow = document.createElement('div');
    livRow.style.cssText = 'display:flex;gap:5px;flex-wrap:wrap;justify-content:center;';
    this.livCards = new Map();
    for (const lv of LIVERIES) {
      const sw = document.createElement('div');
      const base = 150; // the plating's rough mean value
      const rgb = lv.tint.map((t) => Math.max(0, Math.min(255, Math.round(base * t))));
      sw.title = lv.name;
      sw.style.cssText = 'width:34px;height:26px;cursor:pointer;border:2px solid #2a2a36;'
        + `background:rgb(${rgb.join(',')});image-rendering:pixelated;`
        // a darker band across the bottom so the swatch reads as a lit panel
        + `box-shadow:inset 0 -8px 0 rgba(0,0,0,0.35), inset 0 3px 0 rgba(255,255,255,0.12);`;
      const pickLiv = (e) => { e.preventDefault(); e.stopPropagation(); this.livery = lv.id; this._paint(); };
      sw.addEventListener('click', pickLiv);
      sw.addEventListener('touchend', pickLiv, { passive: false });
      livRow.appendChild(sw);
      this.livCards.set(lv.id, sw);
    }
    panel.appendChild(livRow);
    this.livNote = document.createElement('div');
    this.livNote.style.cssText = 'font-size:9px;color:#7d6038;text-align:center;min-height:12px;'
      + 'letter-spacing:0.08em;';
    panel.appendChild(this.livNote);

    const bgLbl = document.createElement('div');
    bgLbl.textContent = '— SERVICE RECORD —';
    bgLbl.style.cssText = 'color:#8a6030;font-size:10px;letter-spacing:0.3em;text-align:center;';
    panel.appendChild(bgLbl);

    this.cards = new Map();
    for (const bg of BACKGROUNDS) {
      const card = document.createElement('div');
      card.style.cssText = 'padding:7px 10px;cursor:pointer;border:1px solid #2a2a36;background:#0e0e16;';
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;gap:8px;align-items:baseline;';
      const nm = document.createElement('div');
      nm.textContent = bg.name;
      nm.style.cssText = 'font-size:12px;letter-spacing:0.12em;color:#c09050;';
      const pk = document.createElement('div');
      pk.textContent = bg.perk;
      pk.style.cssText = 'font-size:9px;color:#7a5a30;letter-spacing:0.06em;text-align:right;';
      head.append(nm, pk);
      const bl = document.createElement('div');
      bl.textContent = bg.blurb;
      bl.style.cssText = 'font-size:10px;color:#8a7050;line-height:1.4;margin-top:2px;';
      card.append(head, bl);
      const choose = (e) => { e.preventDefault(); e.stopPropagation(); this.pick = bg.id; this._paint(); };
      card.addEventListener('click', choose);
      card.addEventListener('touchend', choose, { passive: false });
      panel.appendChild(card);
      this.cards.set(bg.id, { card, nm });
    }
    content.append(left, panel);

    // -- bottom action bar (the concept's footer strip) -----------------------
    const bar = document.createElement('div');
    bar.style.cssText = 'position:absolute;left:0;right:0;bottom:22px;display:flex;'
      + 'justify-content:center;gap:12px;pointer-events:none;';
    this.beginBtn = document.createElement('div');
    this.beginBtn.textContent = 'BEGIN SURVEY';
    this.beginBtn.style.cssText = plasticButton('padding:9px 30px;font-size:13px;'
      + 'letter-spacing:0.25em;pointer-events:auto;');
    const go = (e) => { e.preventDefault(); e.stopPropagation(); this._commit(); };
    this.beginBtn.addEventListener('click', go);
    this.beginBtn.addEventListener('touchend', go, { passive: false });
    bar.appendChild(this.beginBtn);
    frame.appendChild(bar);
    content.style.paddingBottom = '58px';

    // narrow viewports: the portrait is the first thing to go
    const fit = () => { left.style.display = window.innerWidth < 660 ? 'none' : 'flex'; };
    fit();
    window.addEventListener('resize', fit);

    document.body.appendChild(this.root);
    this._paint();
  }

  /** One labelled 0..1 bar, as an inline row of blocks. */
  _statRow(label, frac, note) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:9px;color:#7d6038;';
    const l = document.createElement('div');
    l.textContent = label;
    l.style.cssText = 'min-width:62px;letter-spacing:0.14em;';
    const track = document.createElement('div');
    track.style.cssText = 'flex:1;height:6px;background:#0a0a10;border:1px solid #241c12;'
      + 'position:relative;min-width:0;';
    const fill = document.createElement('div');
    fill.style.cssText = `position:absolute;left:0;top:0;bottom:0;width:${Math.round(Math.max(0, Math.min(1, frac)) * 100)}%;`
      + 'background:#b08040;';
    track.appendChild(fill);
    const v = document.createElement('div');
    v.textContent = note;
    v.style.cssText = 'min-width:52px;text-align:right;color:#8a7050;';
    row.append(l, track, v);
    return row;
  }

  _paint() {
    const bg = BACKGROUNDS.find((b) => b.id === this.pick) ?? BACKGROUNDS[0];
    const sc = shipClass(this.ship);
    for (const [id, { card, nm }] of this.hullCards) {
      const on = id === this.ship;
      card.style.borderColor = on ? sc.accent : '#2a2a36';
      card.style.background = on ? '#1a1710' : '#0e0e16';
      nm.style.color = on ? '#e0b070' : '#c09050';
    }
    // Role, blurb, and what the INSIDE is fitted out like — the last of those
    // is the half of a hull you spend the most time in and the only half the
    // stat bars below cannot show. See data/ShipFit.js.
    this.hullInfo.textContent = `${sc.role} — ${sc.blurb} ${shipFit(sc.id).note ?? ''}`;
    const lv = livery(this.livery);
    for (const [id, sw] of this.livCards) {
      sw.style.borderColor = id === this.livery ? '#e0b070' : '#2a2a36';
    }
    this.livNote.textContent = `${lv.name} — ${lv.note}`;
    this.hullStats.innerHTML = '';
    // Normalised against the widest value any class reaches, so the bars compare
    // the four hulls against each other rather than against an invented ceiling.
    const maxT = 1.45 / 0.62, maxTurn = 1.6, maxHull = 165, maxSlot = 210;
    this.hullStats.append(
      this._statRow('ACCEL', (sc.flight.thrust / sc.flight.mass) / maxT,
        `${(sc.flight.thrust / sc.flight.mass).toFixed(2)}x`),
      this._statRow('AGILITY', sc.flight.turn / maxTurn, `${sc.flight.turn.toFixed(2)}x`),
      this._statRow('STRUCTURE', sc.stats.hull / maxHull, `${sc.stats.hull}`),
      this._statRow('DEFLECTOR', sc.stats.shield / 155, `${sc.stats.shield}`),
      this._statRow('HOLD', sc.stats.slots / maxSlot, `${sc.stats.slots} SL`),
      this._statRow('DECKS', (13 - sc.drop.length) / 13, `${13 - sc.drop.length} RM`),
    );
    // the portrait's shoulder patch takes the commission's colour, so picking a
    // record visibly re-badges the pilot instead of only moving a highlight
    this.portrait.style.backgroundImage = `url("${pilotPNG(bg.accent ?? '#b08040', 3)}")`;
    this.fileLine.textContent = `${this.callsign || this.name || 'SURVEYOR'} · ${bg.name}`;
    for (const [id, { card, nm }] of this.cards) {
      const on = id === this.pick;
      card.style.borderColor = on ? '#b08040' : '#2a2a36';
      card.style.background = on ? '#1a1710' : '#0e0e16';
      nm.style.color = on ? '#e0b070' : '#c09050';
    }
  }

  /**
   * Show the screen. `onComplete({name, background})` fires when BEGIN is
   * pressed, after which the caller applies the grants.
   */
  show(onComplete) {
    this.onComplete = onComplete;
    this.visible = true;
    this.root.style.display = 'flex';
  }

  _commit() {
    const bg = BACKGROUNDS.find((b) => b.id === this.pick) ?? BACKGROUNDS[0];
    this.visible = false;
    this.root.style.display = 'none';
    this.onComplete?.({
      name: this.name || 'SURVEYOR',
      callsign: this.callsign || '',
      background: bg,
      ship: shipClass(this.ship),
      livery: livery(this.livery),
    });
  }

  /**
   * Apply a chosen commission to the live systems (base kit + background).
   * @param {object} choice { name, background }
   * @param {object} sys { inventory, trading, factions }
   */
  static apply(choice, { inventory, trading, factions }) {
    const bg = choice.background;
    for (const [id, n] of BASE_KIT) inventory.add(id, n);
    for (const [id, n] of bg.items ?? []) inventory.add(id, n);
    if (bg.credits) trading.credits += bg.credits;
    for (const [fid, d] of Object.entries(bg.faction ?? {})) {
      if (factions.rep[fid] != null) factions.rep[fid] = Math.max(-100, Math.min(100, factions.rep[fid] + d));
    }
  }
}
