/**
 * Chrome — the shared styling for every DOM control. Since 0.8.3 the plates
 * are REAL generated pixel art (owner task): each button/panel background is a
 * canvas-painted texture — Bayer-dithered brushed charcoal, a hard 2px bevel,
 * corner rivets, paint chips, hazard ticks, vent slots — exported as a data
 * URI and stretched with image-rendering:pixelated. No CSS gradients: the
 * depth is painted into the texture, the same way the game paints its walls.
 */
import { iconPNG } from './ItemIcons.js';


const AMBER = [176, 128, 64];      // #b08040 worn machine amber
const AMBER_HI = [208, 160, 96];   // #d0a060
const RIVET = [138, 106, 66];
const RIVET_HI = [190, 158, 108];

const BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
const bay = (x, y) => (BAYER[(y & 3) * 4 + (x & 3)] + 0.5) / 16;

function rng(seed) {
  let s = (seed >>> 0) || 1;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

/** Paint one moulded plate into ImageData. kind: 'button' | 'panel' | 'gate'. */
function paintPlate(d, w, h, kind, seed) {
  const R = rng(seed);
  // 4-tone charcoal plastic ramp (context/01: no flat fills, no gradients)
  const tones = kind === 'button'
    ? [[16, 16, 23], [20, 20, 28], [25, 25, 35], [31, 31, 42]]
    : [[11, 11, 17], [15, 15, 22], [19, 19, 27], [24, 24, 33]];
  const put = (x, y, c, a = 255) => {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    const i = (y * w + x) * 4;
    if (a >= 255) { d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255; return; }
    const t = a / 255;
    d[i] = d[i] * (1 - t) + c[0] * t; d[i + 1] = d[i + 1] * (1 - t) + c[1] * t;
    d[i + 2] = d[i + 2] * (1 - t) + c[2] * t; d[i + 3] = 255;
  };
  // column-noise "brushed" bands + point grain, quantized through the Bayer
  const colSeed = R() * 999;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const band = Math.sin(x * 0.9 + colSeed) * 0.5 + Math.sin(x * 0.23 + colSeed * 2) * 0.5;
      const grain = Math.sin(x * 12.9898 + y * 78.233 + seed) * 43758.5453;
      let v = 0.42 + band * 0.14 + (grain - Math.floor(grain)) * 0.24;
      if (kind === 'button' && y < h * 0.4) v += 0.14; // raised face catches light
      if (y % 3 === 2) v -= 0.05; // scanline weave
      let lvl = Math.floor(v * tones.length);
      if (v * tones.length - lvl > bay(x, y)) lvl++;
      put(x, y, tones[Math.max(0, Math.min(tones.length - 1, lvl))]);
    }
  }
  // wear: dark pits and pale scuffs
  const pits = Math.floor(w * h / 90);
  for (let i = 0; i < pits; i++) {
    const x = 2 + Math.floor(R() * (w - 4)), y = 2 + Math.floor(R() * (h - 4));
    put(x, y, R() < 0.5 ? [7, 7, 11] : [40, 40, 52]);
  }
  // scratches: short pale horizontal streaks
  for (let i = 0; i < Math.max(2, w >> 5); i++) {
    const y = 3 + Math.floor(R() * (h - 6)), x0 = Math.floor(R() * (w - 12));
    const len = 4 + Math.floor(R() * 9);
    for (let x = x0; x < x0 + len; x++) put(x, y, [46, 46, 60], 140);
  }
  // hard bevel: lit top/left, shadowed bottom/right, dark outline
  for (let x = 0; x < w; x++) { put(x, 0, [3, 3, 6]); put(x, h - 1, [2, 2, 4]); }
  for (let y = 0; y < h; y++) { put(0, y, [3, 3, 6]); put(w - 1, y, [2, 2, 4]); }
  for (let x = 1; x < w - 1; x++) { put(x, 1, [52, 52, 68]); put(x, 2, [38, 38, 50]); put(x, h - 2, [6, 6, 10]); put(x, h - 3, [9, 9, 14]); }
  for (let y = 1; y < h - 1; y++) { put(1, y, [44, 44, 58]); put(w - 2, y, [7, 7, 11]); }
  // corner rivets: dark ring, amber head, one catch-light pixel
  const rivet = (cx, cy) => {
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) put(cx + dx, cy + dy, [5, 5, 9]);
    put(cx, cy, RIVET); put(cx - 1, cy, RIVET); put(cx, cy - 1, RIVET_HI);
  };
  const m = 4;
  rivet(m, m); rivet(w - 1 - m, m); rivet(m, h - 1 - m); rivet(w - 1 - m, h - 1 - m);
  if (w > 120) { rivet(w >> 1, m); rivet(w >> 1, h - 1 - m); }
  if (kind !== 'button') {
    // hazard ticks: short amber diagonals near the top-right corner
    for (let s2 = 0; s2 < 3; s2++) {
      for (let t = 0; t < 5; t++) put(w - 24 + s2 * 6 + t, 4 + (4 - t), AMBER, 210);
    }
    // vent slots along the bottom-right
    for (let s2 = 0; s2 < 3; s2++) {
      for (let x = 0; x < 6; x++) {
        put(w - 34 + s2 * 9 + x, h - 6, [4, 4, 8]);
        put(w - 34 + s2 * 9 + x, h - 5, [30, 30, 40]);
      }
    }
    // stencil tally marks bottom-left (maintenance paint)
    for (let s2 = 0; s2 < 4; s2++) put(7 + s2 * 3, h - 6, [96, 70, 40]);
  }
  if (kind === 'gate') {
    // full-width warning bands top and bottom — worn, dither-broken
    for (let y0 of [0, h - 4]) {
      for (let y = y0; y < y0 + 4; y++) {
        for (let x = 2; x < w - 2; x++) {
          const on = ((x + y) % 10) < 5;
          if (on && bay(x, y) > 0.15) put(x, y, y % 2 ? AMBER : [140, 100, 50]);
          else put(x, y, [10, 10, 15]);
        }
      }
    }
  }
}

const _cache = new Map();

/** Generated pixel-art plate as a data URI (cached). */
export function platePNG(w, h, kind = 'panel', seed = 1) {
  const key = `${w}x${h}:${kind}:${seed}`;
  if (_cache.has(key)) return _cache.get(key);
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(w, h);
  paintPlate(img.data, w, h, kind, seed);
  ctx.putImageData(img, 0, 0);
  const uri = cv.toDataURL();
  _cache.set(key, uri);
  return uri;
}

/** Tileable amber/charcoal hazard stripe strip (for menu accents). */
export function hazardPNG(w = 40, h = 6) {
  const key = `hz${w}x${h}`;
  if (_cache.has(key)) return _cache.get(key);
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(w, h);
  const d = img.data;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const on = ((x + y) % 10) < 5;
      const c = on ? (bay(x, y) > 0.2 ? AMBER : [140, 100, 50]) : [12, 12, 18];
      const i = (y * w + x) * 4;
      d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const uri = cv.toDataURL();
  _cache.set(key, uri);
  return uri;
}

/**
 * Deep-space backdrop as generated pixel art: dithered navy void, two muted
 * nebula blooms, and a scattered star field at three brightnesses. Painted once
 * at a low resolution and stretched with image-rendering:pixelated, so the
 * menus sit in the same 16-bit space the game renders rather than over a CSS
 * radial-gradient that reads as a completely different medium.
 */
export function spacePNG(w = 320, h = 180, seed = 5) {
  const key = `sky${w}x${h}:${seed}`;
  if (_cache.has(key)) return _cache.get(key);
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(w, h);
  const d = img.data;
  const R = rng(seed);
  const put = (x, y, c) => {
    if (x < 0 || y < 0 || x >= w || y >= h) return;
    const i = (y * w + x) * 4;
    d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255;
  };
  // void: two-tone dither so it isn't a flat black rectangle
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) put(x, y, bay(x, y) > 0.55 ? [4, 4, 10] : [2, 2, 6]);
  }
  // Nebula clouds. A plain radial falloff quantized into steps just draws
  // concentric rings — the shape has to be broken up before it's stepped, so
  // the radius is warped by summed sines and the whole thing is then snapped to
  // 4 hard levels and dither-masked. Ragged cloud, no gradient (context/01 §3).
  const blooms = [
    [w * 0.22, h * 0.70, w * 0.30, [50, 28, 60], 11.3],
    [w * 0.80, h * 0.26, w * 0.24, [58, 32, 22], 4.7],
  ];
  for (const [bx, by, br, col, ph] of blooms) {
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const dx = (x - bx) / br, dy = (y - by) / br;
        const ang = Math.atan2(dy, dx);
        const warp = 1
          + 0.30 * Math.sin(ang * 3 + ph) + 0.20 * Math.sin(ang * 7 - ph * 2)
          + 0.14 * Math.sin(x * 0.09 + ph) + 0.14 * Math.sin(y * 0.11 - ph);
        const t = warp - Math.hypot(dx, dy);
        if (t <= 0) continue;
        const q = Math.floor(Math.min(1, t) * 4) / 4;
        if (q > 0 && q > bay(x, y) * 1.15) {
          const i = (y * w + x) * 4;
          put(x, y, [Math.min(255, d[i] + col[0] * q), Math.min(255, d[i + 1] + col[1] * q),
            Math.min(255, d[i + 2] + col[2] * q)]);
        }
      }
    }
  }
  // stars: mostly faint, a few bright, a handful tinted
  const tints = [[232, 236, 248], [190, 202, 236], [236, 214, 180]];
  const n = Math.round((w * h) / 120);
  for (let i = 0; i < n; i++) {
    const x = Math.floor(R() * w), y = Math.floor(R() * h);
    const t = tints[Math.floor(R() * tints.length)];
    const b = R();
    const k = b > 0.94 ? 1 : b > 0.7 ? 0.62 : 0.34;
    put(x, y, [t[0] * k, t[1] * k, t[2] * k]);
    if (b > 0.985) { // the rare bright one gets a cross flare
      const dim = [t[0] * 0.4, t[1] * 0.4, t[2] * 0.4];
      put(x - 1, y, dim); put(x + 1, y, dim); put(x, y - 1, dim); put(x, y + 1, dim);
    }
  }
  ctx.putImageData(img, 0, 0);
  const uri = cv.toDataURL();
  _cache.set(key, uri);
  return uri;
}

/**
 * Full-screen bulkhead surround, per the owner's concept art: heavy bevelled
 * rails down every edge, cut corner plates, an amber trim line and a row of
 * indicator ticks. Returns { root, content, titleEl } — `content` is the clear
 * middle the caller fills, `titleEl` the plate at the top.
 *
 * The frame is DOM rather than one big generated bitmap so it reflows with the
 * viewport; the rails themselves are generated plates, so the material still
 * matches the ship.
 */
export function bulkheadFrame(title = '', opts = {}) {
  const rail = platePNG(48, 24, 'panel', 21);
  const root = document.createElement('div');
  root.style.cssText = [
    'position:absolute', 'inset:0', 'display:flex', 'flex-direction:column',
    'align-items:center', 'justify-content:flex-start',
    `background:url("${spacePNG(320, 180, opts.skySeed ?? 5)}") center/cover no-repeat, #000003`,
    'image-rendering:pixelated', 'overflow:hidden',
  ].join(';');

  const edge = (css) => {
    const el = document.createElement('div');
    el.style.cssText = 'position:absolute;pointer-events:none;image-rendering:pixelated;'
      + `background:url("${rail}") center/100% 100% no-repeat;` + css;
    root.appendChild(el);
    return el;
  };
  const T = opts.thin ? 12 : 18;
  edge(`left:0;top:0;right:0;height:${T}px;`);
  edge(`left:0;bottom:0;right:0;height:${T}px;`);
  edge(`left:0;top:0;bottom:0;width:${T}px;`);
  edge(`right:0;top:0;bottom:0;width:${T}px;`);
  // cut corner plates — the diagonal shoulders in the concept
  for (const c of [`left:0;top:0`, `right:0;top:0`, `left:0;bottom:0`, `right:0;bottom:0`]) {
    edge(`${c};width:${T * 2.4}px;height:${T * 2.4}px;opacity:0.95;`);
  }
  // amber trim line just inside the rails
  const trim = document.createElement('div');
  trim.style.cssText = `position:absolute;inset:${T + 3}px;border:1px solid #6b4d24;`
    + 'pointer-events:none;box-shadow:inset 0 0 0 1px #00000080;';
  root.appendChild(trim);
  // indicator ticks along the bottom rail: dead machine lights, mostly out
  const ticks = document.createElement('div');
  ticks.style.cssText = `position:absolute;left:${T * 3}px;right:${T * 3}px;bottom:${Math.round(T / 2) - 2}px;`
    + 'height:4px;display:flex;gap:5px;pointer-events:none;';
  for (let i = 0; i < 26; i++) {
    const t = document.createElement('div');
    const lit = i % 7 === 3;
    t.style.cssText = `flex:1;height:4px;background:${lit ? '#b08040' : '#241a10'};`
      + (lit ? 'box-shadow:0 0 4px #b0804070;' : '');
    ticks.appendChild(t);
  }
  root.appendChild(ticks);

  let titleEl = null;
  if (title) {
    titleEl = document.createElement('div');
    titleEl.textContent = title;
    titleEl.style.cssText = [
      'position:relative', `margin-top:${T + 10}px`, 'padding:7px 30px',
      `background:url("${platePNG(160, 28, 'button', 13)}") center/100% 100% no-repeat`,
      'image-rendering:pixelated', 'color:#d8ac68', 'font:14px monospace',
      'letter-spacing:0.42em', 'text-shadow:0 2px 0 #000, 0 0 12px #b0804055',
      'box-shadow:0 3px 10px #000000d0',
    ].join(';');
    root.appendChild(titleEl);
  }

  const content = document.createElement('div');
  content.style.cssText = [
    'position:relative', 'flex:1', 'width:100%',
    `padding:${title ? 10 : T + 12}px ${T + 14}px ${T + 14}px`,
    'display:flex', 'align-items:center', 'justify-content:center', 'gap:18px',
    'min-height:0', 'overflow:hidden',
  ].join(';');
  root.appendChild(content);

  return { root, content, titleEl };
}

/**
 * cssText for a control button. Styled as a piece of flight hardware rather
 * than a rounded web chip: the moulded plate texture, corners CUT on the
 * diagonal (clip-path) the way every bulkhead and console bezel in this ship
 * is, an amber edge line that reads as a lit bezel, and an inner shadow so the
 * cap sits DOWN in its housing. The cut corners are the single biggest cue —
 * a rectangle reads as UI, a chamfered plate reads as a switch on a panel.
 */
/**
 * One themed scrollbar for every window in the game, injected once.
 *
 * Most panels already had `overflow-y:auto`, so long content technically
 * scrolled — but with the browser's default scrollbar, which is a rounded grey
 * pill and reads as a web page bolted onto a 16-bit console. Worse, on touch
 * there was no visible affordance at all: a player with a long journal or a
 * ten-row warp chart had no way to know there was more below the fold.
 *
 * This is a hard-edged amber slider in a recessed channel, sized so it is
 * comfortably grabbable, plus `scrollbar-color` for Firefox, which does not
 * implement the WebKit pseudo-elements. `overscroll-behavior: contain` stops a
 * flick inside a panel from scrolling the page behind it, and `touch-action:
 * pan-y` makes the drag actually work on a device where the canvas is otherwise
 * swallowing gestures.
 */
let _scrollCssInstalled = false;
export function installScrollChrome() {
  if (_scrollCssInstalled || typeof document === 'undefined') return;
  _scrollCssInstalled = true;
  const el = document.createElement('style');
  el.textContent = `
    .sr-scroll {
      overflow-y: auto;
      overscroll-behavior: contain;
      touch-action: pan-y;
      scrollbar-width: thin;
      scrollbar-color: #b08040 #14141a;
    }
    .sr-scroll::-webkit-scrollbar { width: 10px; }
    .sr-scroll::-webkit-scrollbar-track {
      background: #0f0f14;
      box-shadow: inset 1px 0 0 #2a2118, inset -1px 0 0 #2a2118;
    }
    .sr-scroll::-webkit-scrollbar-thumb {
      background: #8a6030;
      border: 1px solid #c09050;
      /* chamfered, to match the machined plate the buttons use */
      clip-path: polygon(0 3px, 3px 0, 100% 0, 100% calc(100% - 3px),
                         calc(100% - 3px) 100%, 0 100%);
    }
    .sr-scroll::-webkit-scrollbar-thumb:hover { background: #a87a44; }
    .sr-scroll::-webkit-scrollbar-thumb:active { background: #c09050; }
    /* the little grip notches, so the thumb reads as hardware */
    .sr-scroll::-webkit-scrollbar-thumb {
      background-image: linear-gradient(#c0905000 40%, #c0905060 40%, #c0905060 45%,
        #c0905000 45%, #c0905000 55%, #c0905060 55%, #c0905060 60%, #c0905000 60%);
    }
  `;
  document.head.appendChild(el);
}

/**
 * Mark an element as a themed scroll region. Call instead of hand-writing
 * `overflow-y:auto` so every window scrolls and looks the same doing it.
 */
export function scrollable(el) {
  installScrollChrome();
  el.classList.add('sr-scroll');
  return el;
}

/**
 * A themed close button, pinned to a panel's top-right corner.
 *
 * Every window had a different way out — TradingUI had a LEAVE COUNTER chip,
 * InventoryUI a CLOSE button, and the journal, warp chart and approach panel had
 * nothing at all except the key that opened them. On touch, with no keyboard,
 * that left three windows you could open and not get out of.
 */
export function closeButton(onClose, label = '\u2715') {
  const b = document.createElement('div');
  b.textContent = label;
  b.setAttribute('role', 'button');
  b.setAttribute('aria-label', 'Close');
  // Tagged so `windowFrame` can push it inside the rails it adds afterwards —
  // otherwise the key sits on top of the cut corner plate and reads as loose.
  b.dataset.closeKey = '1';
  b.style.cssText = plasticButton([
    'position:absolute', 'top:6px', 'right:6px', 'z-index:3',
    'width:30px', 'height:30px', 'min-height:30px', 'padding:0',
    'display:flex', 'align-items:center', 'justify-content:center',
    'font-size:14px', 'line-height:1',
    // Chrome.js deliberately has no imports — it owns its own palette constants
    `color:rgb(${AMBER_HI[0]},${AMBER_HI[1]},${AMBER_HI[2]})`,
  ].join(';'));
  const h = (e) => { e.preventDefault(); e.stopPropagation(); onClose(); };
  b.addEventListener('click', h);
  b.addEventListener('touchend', h, { passive: false });
  return b;
}

/** Panels that currently have Escape wired, innermost last. */
const _escStack = [];

/**
 * Give a panel the standard way out: a close button in the corner, Escape on a
 * keyboard, and a themed scroll region so long content can be reached on touch.
 *
 * Escape goes through ONE shared document listener with a stack, rather than one
 * listener per panel. With per-panel listeners, opening the warp chart from the
 * pause screen and hitting Escape closed both, because every listener fires.
 * Here only the innermost visible panel responds.
 *
 * @param {HTMLElement} root the panel element (must be positioned)
 * @param {() => void} onClose
 * @param {{scroll?: boolean, esc?: boolean, isOpen?: () => boolean}} [opts]
 */
export function panelChrome(root, onClose, opts = {}) {
  const { scroll = true, esc = true, isOpen } = opts;
  if (getComputedStyle(root).position === 'static') root.style.position = 'relative';
  root.appendChild(closeButton(onClose));
  if (scroll) scrollable(root);
  if (esc) {
    _escStack.push({ root, onClose, isOpen });
    _installEsc();
  }
  return root;
}

let _escInstalled = false;
function _installEsc() {
  if (_escInstalled || typeof document === 'undefined') return;
  _escInstalled = true;
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' && e.key !== 'Esc') return;
    // innermost-first: the last panel registered that is actually on screen
    for (let i = _escStack.length - 1; i >= 0; i--) {
      const p = _escStack[i];
      // NOT offsetParent: it is null for every `position:fixed` element, which
      // is what all of these panels are, so the naive check reported every panel
      // closed and Escape did nothing at all. A measured rect is the honest test.
      const open = p.isOpen
        ? p.isOpen()
        : p.root.style.display !== 'none' && p.root.getBoundingClientRect().width > 0;
      if (!open) continue;
      e.preventDefault();
      e.stopPropagation();
      p.onClose();
      return;
    }
  }, true); // capture, so the game's own key handling does not eat it first
}

export function plasticButton(extra = '') {
  const c = '6px'; // corner cut
  return [
    'border:none', 'border-radius:0',
    `background:url("${platePNG(96, 24, 'button', 7)}") center/100% 100% no-repeat`,
    'image-rendering:pixelated',
    `clip-path:polygon(${c} 0, calc(100% - ${c}) 0, 100% ${c}, 100% calc(100% - ${c}),`
      + ` calc(100% - ${c}) 100%, ${c} 100%, 0 calc(100% - ${c}), 0 ${c})`,
    // Deeper bevel and a warm rim glow: the key should read as a lit, machined
    // instrument switch rather than a flat plate with a border. The extra inset
    // ring is the bezel; the outer glow is the panel light bleeding around it.
    'box-shadow:0 2px 7px #000000d0, inset 0 1px 0 #ffe0b022, inset 0 -3px 5px #00000098,'
      + ' inset 0 0 0 1px #0a0b0fcc, 0 0 9px #b0804026',
    'outline:1px solid #7d5a2a90', 'outline-offset:-2px',
    'color:#e0b070', 'font:10px monospace', 'letter-spacing:0.16em',
    'text-shadow:0 1px 2px #000000, 0 0 7px #c0905060',
    // 44px floor on the short axis: the owner reported the chips hard to hit, and
    // 7px of padding on a 10px font gives a 24px target, well under the
    // context/07 checklist's own minimum.
    'padding:12px 12px', 'min-width:46px', 'min-height:44px', 'box-sizing:border-box',
    'display:flex', 'align-items:center', 'justify-content:center',
    'text-align:center',
    // NO `position` here. Several callers append this after their own
    // `position:fixed` (the left-edge chips), and a later `position:relative`
    // silently overrode it and dropped them out of their column. addLamp sets
    // positioning itself, only when the element is still static.
    'cursor:pointer', 'user-select:none', '-webkit-user-select:none',
    'touch-action:none',
    extra,
  ].join(';');
}

/**
 * Turn a button element into a switch with a status LED: a small amber lamp in
 * the top-left of the cap, lit when `on()` says so. Cheap, and it's what makes
 * a row of buttons read as a powered console instead of labelled boxes.
 */
export function addLamp(el, on = () => true) {
  if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
  const lamp = document.createElement('span');
  lamp.style.cssText = 'position:absolute;left:4px;top:4px;width:3px;height:3px;'
    + 'background:#b08040;box-shadow:0 0 4px #b0804090;pointer-events:none;';
  el.appendChild(lamp);
  el.dataset.lamped = '1';
  const paint = () => {
    const lit = !!on();
    lamp.style.background = lit ? '#d8ac68' : '#3a2c18';
    lamp.style.boxShadow = lit ? '0 0 4px #d8ac6890' : 'none';
  };
  paint();
  return paint;
}

/** cssText fragment for a panel (menus, popups): riveted pixel-art plate. */
export function plasticPanel(extra = '') {
  return [
    'border:none', 'border-radius:0',
    `background:url("${platePNG(200, 140, 'panel', 3)}") center/100% 100% no-repeat`,
    'image-rendering:pixelated',
    'box-shadow:0 4px 14px #000000e0',
    'color:#c09050', 'font:12px monospace', 'letter-spacing:0.06em',
    extra,
  ].join(';');
}

/** A thin hazard-stripe accent bar element (themed decoration for menus). */
export function hazardBar(widthCss = '100%') {
  const el = document.createElement('div');
  el.style.cssText = `width:${widthCss};height:6px;margin:4px auto;` +
    `background:url("${hazardPNG()}") left top/auto 100% repeat-x;image-rendering:pixelated;opacity:0.85;`;
  return el;
}

/**
 * Pilot bust for the commission screen — a 48x56 pixel portrait painted from
 * the ship palette: EVA hood, worn visor with a phosphor reflection band,
 * collar ring, shoulder patch in the commission's colour, and a rim light off
 * the left. Deliberately shadowed and low-contrast; the reference for this crew
 * is a tired industrial worker, not a hero shot.
 * @param {string} accent hex for the shoulder patch / visor tint
 */
export function pilotPNG(accent = '#b08040', seed = 3, scale = 1) {
  const key = `pil${accent}:${seed}:${scale}`;
  if (_cache.has(key)) return _cache.get(key);
  const W = 48, H = 56;
  const cv = document.createElement('canvas');
  cv.width = W; cv.height = H;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(W, H);
  const d = img.data;
  const R = rng(seed);
  const hex = (s) => [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)];
  const acc = hex(accent);
  const put = (x, y, c) => {
    if (x < 0 || y < 0 || x >= W || y >= H) return;
    const i = (y * W + x) * 4;
    d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255;
  };
  const rect = (x0, y0, w2, h2, c) => {
    for (let y = y0; y < y0 + h2; y++) for (let x = x0; x < x0 + w2; x++) put(x, y, c);
  };
  // backdrop: the compartment behind them, dithered two-tone with a light strip
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) put(x, y, bay(x, y) > 0.5 ? [17, 17, 24] : [12, 12, 18]);
  }
  rect(3, 6, 2, 30, [30, 30, 40]);
  rect(3, 12, 2, 9, [92, 74, 44]); // a wall light behind the shoulder
  rect(W - 7, 4, 3, 44, [22, 22, 30]);
  // shoulders / suit — wide and low, so the head reads as a head and not a
  // grey oval filling the plate. Head is ~45% of the frame, per the concept.
  const suit = [46, 53, 48], suitHi = [70, 79, 71], suitLo = [24, 28, 26];
  for (let y = 34; y < H; y++) {
    const spread = Math.min(21, 6 + (y - 34) * 2.2);
    rect(24 - spread, y, spread * 2, 1, suit);
    put(24 - spread, y, suitLo); put(23 + spread, y, suitLo);
    put(25 - spread, y, suitHi); // rim light down the left shoulder
  }
  rect(8, 44, 9, 7, acc.map((v) => v * 0.55)); // shoulder patch, sunk
  rect(9, 45, 7, 5, acc);
  rect(10, 46, 3, 1, acc.map((v) => Math.min(255, v * 1.45)));
  for (let i = 0; i < 3; i++) rect(31, 44 + i * 3, 9 - i * 2, 2, [96, 72, 40]); // rank ticks
  rect(6, 52, 36, 1, suitLo); // chest seam
  // suit weave: vertical rib shading so the shoulders aren't a flat slab
  for (let y = 36; y < H; y++) for (let x = 5; x < 43; x += 4) put(x, y, suitLo);

  // collar ring
  rect(16, 31, 16, 4, [74, 81, 76]);
  rect(16, 31, 16, 1, [112, 120, 112]);
  rect(16, 34, 16, 1, [30, 34, 31]);
  for (let x = 18; x < 31; x += 4) put(x, 33, [22, 25, 23]);

  // helmet shell: a narrow dome, hard-edged, lit from the left
  const shell = [62, 67, 70], shellHi = [104, 112, 114], shellLo = [26, 29, 33];
  for (let y = 6; y < 34; y++) {
    const t = (y - 6) / 28;
    const half = Math.round(4 + 8 * Math.sin(Math.min(1, t * 2.1) * Math.PI * 0.5));
    for (let x = 24 - half; x <= 23 + half; x++) {
      // shade across the dome: bright left third, mid, dark right quarter
      const f = (x - (24 - half)) / Math.max(1, half * 2);
      put(x, y, f < 0.22 ? shellHi : f > 0.76 ? shellLo : shell);
    }
    put(24 - half - 1, y, [10, 11, 14]); // hard outline both sides
    put(24 + half, y, [10, 11, 14]);
  }
  for (let x = 19; x < 29; x++) { put(x, 5, [10, 11, 14]); put(x, 6, shellHi); }

  // visor: wide dark glass, phosphor reflection band, two eye glints behind it
  rect(14, 14, 20, 12, [12, 16, 20]);
  rect(13, 14, 1, 12, [10, 11, 14]);
  rect(34, 14, 1, 12, [10, 11, 14]);
  rect(14, 13, 20, 1, [10, 11, 14]);
  rect(14, 26, 20, 1, [34, 38, 40]);   // lower bezel catches light
  for (let x = 15; x < 33; x++) { put(x, 17, [34, 52, 58]); put(x, 18, [26, 42, 48]); }
  rect(16, 20, 6, 2, [52, 72, 76]);    // reflection streak
  rect(27, 23, 5, 1, [40, 58, 62]);
  rect(31, 15, 2, 2, [78, 92, 92]);    // scuffed corner
  put(19, 22, [110, 98, 76]); put(20, 22, [86, 76, 58]);
  put(28, 22, [110, 98, 76]); put(29, 22, [86, 76, 58]);

  // helmet lamp on the crown + air hose down the left
  rect(21, 7, 6, 3, [88, 94, 96]);
  rect(22, 8, 4, 1, acc);
  rect(22, 7, 4, 1, [120, 126, 128]);
  for (let y = 27; y < 40; y++) put(10 + ((y >> 1) & 1), y, [42, 46, 44]);
  for (let y = 28; y < 40; y += 3) put(10 + ((y >> 1) & 1), y, [66, 70, 68]);

  // wear: scuffs and pits across the shell
  for (let i = 0; i < 30; i++) {
    const x = 15 + Math.floor(R() * 18), y = 7 + Math.floor(R() * 26);
    put(x, y, R() < 0.5 ? shellLo : shellHi);
  }
  ctx.putImageData(img, 0, 0);
  const uri = cv.toDataURL();
  _cache.set(key, uri);
  return uri;
}

// Category → [base hue rgb, silhouette]. The owner's item concepts are chunky
// isometric solids with a hard black outline, a lit top face and two shaded
// sides — so every icon is built from one iso cuboid plus a category glyph,
// with the hue nudged per item id. That gives 200+ distinguishable icons out of
// nine shapes without a single asset file.





/**
 * ITEM ICONS moved to ui/ItemIcons.js (0.56.0).
 *
 * This was a generator keyed on the nine top-level CATEGORIES, which meant
 * every consumable in the game was the same tin and every component the same
 * chip — three hundred items resolving to nine silhouettes. Icons are now keyed
 * on the SUBCATEGORY, of which there are thirty-odd, and this remains only as
 * the call the UI files already make.
 *
 * @param {string} category kept first, for the existing call sites
 * @param {string} id       item id — seeds colour, features and wear
 * @param {string} [sub]    subcategory; the silhouette comes from this
 */
export function itemIconPNG(category = 'trade', id = '', sub = null) {
  return iconPNG(sub ?? category, id, category);
}

/**
 * Decorate an EXISTING centred modal in place so it speaks the same language as
 * the framed screens: a bigger generated plate behind it, hard corner brackets,
 * a hazard strip along the top edge, and a heavier drop shadow.
 *
 * In place, rather than re-parenting, because the journal, trade counter,
 * intrusion clock and warp chart each build their own layout and hold
 * references into it — wrapping them would mean rewriting five files to gain
 * the same pixels.
 */
export function framePanel(el, opts = {}) {
  if (!el || el.dataset.framed) return el;
  el.dataset.framed = '1';
  el.style.border = 'none';
  el.style.borderRadius = '0';
  el.style.position = el.style.position || 'relative';
  el.style.imageRendering = 'pixelated';
  el.style.background = `url("${platePNG(180, 150, 'panel', opts.seed ?? 19)}") center/100% 100% no-repeat`;
  el.style.boxShadow = '0 6px 26px #000000e6, inset 0 0 0 1px #00000090';
  const bracket = (css) => {
    const b = document.createElement('div');
    b.style.cssText = 'position:absolute;width:11px;height:11px;pointer-events:none;' + css;
    el.appendChild(b);
  };
  const C = '#b08040';
  bracket(`left:5px;top:5px;border-left:2px solid ${C};border-top:2px solid ${C};`);
  bracket(`right:5px;top:5px;border-right:2px solid ${C};border-top:2px solid ${C};`);
  bracket(`left:5px;bottom:5px;border-left:2px solid ${C};border-bottom:2px solid ${C};`);
  bracket(`right:5px;bottom:5px;border-right:2px solid ${C};border-bottom:2px solid ${C};`);
  const hz = document.createElement('div');
  hz.style.cssText = 'position:absolute;left:20px;right:20px;top:3px;height:4px;pointer-events:none;'
    + `background:url("${hazardPNG()}") left top/auto 100% repeat-x;image-rendering:pixelated;opacity:0.75;`;
  el.appendChild(hz);
  return el;
}

/**
 * A SELECTABLE ROW, as a piece of hardware (0.46.0, roadmap #84).
 *
 * The DOM buttons in this game have been moulded plates since 0.8.3 — but the
 * LIST ROWS never were. A survey site, a hull on the broker's board, a recovered
 * log: every one of them was `border:1px solid #2a2a36; border-radius:5px`,
 * which is a web list item, and they sit inside screens that had grown rails
 * and cut corners around them. That contrast is what "the buttons still look
 * like a web page" comes down to.
 *
 * Same language as `plasticButton` at row proportions: the moulded plate, a
 * chamfer on the leading corners only (a full chamfer on a wide row reads as a
 * ticket stub), a recessed inner ring, and a LIT LEFT EDGE when the row is
 * selected — which is how a rack-mounted selector actually shows you which
 * channel is live.
 *
 * @param {string} extra appended cssText
 * @param {{on?:boolean, dead?:boolean}} opts selected / unavailable
 */
export function plasticRow(extra = '', opts = {}) {
  const { on = false, dead = false } = opts;
  const c = '7px';
  return [
    'border:none', 'border-radius:0', 'position:relative',
    `background:url("${platePNG(140, 40, 'panel', on ? 29 : 17)}") center/100% 100% no-repeat`,
    'image-rendering:pixelated',
    // Leading corners cut, trailing corners square: a row is a card slid into a
    // rack, and a rack has a back.
    `clip-path:polygon(${c} 0, 100% 0, 100% 100%, ${c} 100%, 0 calc(100% - ${c}), 0 ${c})`,
    on
      ? 'box-shadow:inset 3px 0 0 #d8ac68, inset 0 1px 0 #ffe0b026, inset 0 0 0 1px #0a0b0fcc,'
        + ' 0 2px 8px #000000c0, 0 0 10px #b0804030'
      : 'box-shadow:inset 3px 0 0 #34281a, inset 0 1px 0 #ffe0b014,'
        + ' inset 0 0 0 1px #0a0b0fcc, 0 2px 6px #000000b0',
    'outline:1px solid ' + (on ? '#8a6430b0' : '#3a2c1a90'), 'outline-offset:-2px',
    'padding:9px 12px 9px 14px', 'min-height:44px', 'box-sizing:border-box',
    dead ? 'opacity:0.42;cursor:default;' : 'cursor:pointer;',
    'user-select:none', '-webkit-user-select:none', 'touch-action:manipulation',
    extra,
  ].join(';');
}

/**
 * THE MIDDLE SIZE. A bulkhead surround around a PANEL rather than around the
 * whole screen (0.46.0, roadmap #85).
 *
 * There were only two treatments before this: `framePanel`, which is a moulded
 * plate with corner brackets, and `bulkheadFrame`, which takes the entire
 * viewport. Anything that has to stay small AND has to read as part of the ship
 * fell between them — most visibly the approach panel, which cannot go
 * full-screen because its whole job is to be read while you are looking at the
 * body it is describing.
 *
 * Applied in place, like `framePanel`, so a caller that already built its layout
 * and holds references into it does not have to be rewritten to gain the rails.
 * Same materials as the full-screen frame at a smaller gauge: bevelled rails on
 * every edge, cut corner plates, an amber trim line inside them, and a row of
 * indicator ticks along the bottom that are mostly dead, because on this ship
 * most of them are.
 *
 * @param {HTMLElement} el
 * @param {{seed?:number, rail?:number, title?:string}} opts
 */
export function windowFrame(el, opts = {}) {
  if (!el || el.dataset.winFramed) return el;
  el.dataset.winFramed = '1';
  const T = opts.rail ?? 9;
  const rail = platePNG(48, 24, 'panel', opts.seed ?? 21);
  el.style.border = 'none';
  el.style.borderRadius = '0';
  el.style.position = el.style.position || 'relative';
  el.style.imageRendering = 'pixelated';
  el.style.background = `url("${platePNG(180, 150, 'panel', (opts.seed ?? 21) + 6)}") center/100% 100% no-repeat`;
  el.style.boxShadow = '0 6px 26px #000000e6, inset 0 0 0 1px #00000090';
  // The content has to clear the rails, so whatever padding the caller set gets
  // the rail thickness added to it rather than replaced — its own spacing was
  // chosen for its own layout and is none of this function's business.
  const pad = (v) => `${Math.round(parseFloat(v) || 0) + T}px`;
  const cs = getComputedStyle(el);
  el.style.padding = [cs.paddingTop, cs.paddingRight, cs.paddingBottom, cs.paddingLeft]
    .map(pad).join(' ');

  const edge = (css) => {
    const d = document.createElement('div');
    d.style.cssText = 'position:absolute;pointer-events:none;image-rendering:pixelated;z-index:2;'
      + `background:url("${rail}") center/100% 100% no-repeat;` + css;
    el.appendChild(d);
  };
  edge(`left:0;top:0;right:0;height:${T}px;`);
  edge(`left:0;bottom:0;right:0;height:${T}px;`);
  edge(`left:0;top:0;bottom:0;width:${T}px;`);
  edge(`right:0;top:0;bottom:0;width:${T}px;`);
  for (const c of ['left:0;top:0', 'right:0;top:0', 'left:0;bottom:0', 'right:0;bottom:0']) {
    edge(`${c};width:${T * 2.2}px;height:${T * 2.2}px;opacity:0.95;`);
  }
  const trim = document.createElement('div');
  trim.style.cssText = `position:absolute;inset:${T + 2}px;border:1px solid #6b4d24;`
    + 'pointer-events:none;box-shadow:inset 0 0 0 1px #00000080;z-index:1;';
  el.appendChild(trim);
  const ticks = document.createElement('div');
  ticks.style.cssText = `position:absolute;left:${T * 2.6}px;right:${T * 2.6}px;`
    + `bottom:${Math.round(T / 2) - 1}px;height:3px;display:flex;gap:4px;pointer-events:none;z-index:3;`;
  for (let i = 0; i < 14; i++) {
    const t = document.createElement('div');
    const lit = i % 5 === 2;
    t.style.cssText = `flex:1;height:3px;background:${lit ? '#b08040' : '#241a10'};`
      + (lit ? 'box-shadow:0 0 3px #b0804070;' : '');
    ticks.appendChild(t);
  }
  el.appendChild(ticks);

  /**
   * Push the close key inside the rails, now and whenever one is added later —
   * `panelChrome` is usually called after this, so the key does not exist yet.
   */
  const insetClose = () => {
    for (const k of el.querySelectorAll('[data-close-key]')) {
      k.style.top = `${T + 3}px`;
      k.style.right = `${T + 3}px`;
      k.style.zIndex = '5';
    }
  };
  insetClose();
  new MutationObserver(insetClose).observe(el, { childList: true });

  if (opts.title) {
    const cap = document.createElement('div');
    cap.textContent = opts.title;
    cap.style.cssText = ['position:absolute', `top:${T - 3}px`, 'left:50%',
      'transform:translateX(-50%)', 'padding:3px 16px', 'white-space:nowrap',
      `background:url("${platePNG(160, 28, 'button', 13)}") center/100% 100% no-repeat`,
      'image-rendering:pixelated', 'color:#d8ac68', 'font:9px monospace',
      'letter-spacing:0.3em', 'text-shadow:0 1px 0 #000', 'pointer-events:none', 'z-index:4',
    ].join(';');
    el.appendChild(cap);
  }
  return el;
}

/**
 * Slide the bulkhead surround + star field in BEHIND an existing full-screen
 * overlay's own children, rather than re-parenting them. Same reasoning as
 * framePanel: the settings sheet and the death screen already lay themselves
 * out, and they only need the room drawn around them.
 */
export function frameBackdrop(root, opts = {}) {
  if (!root || root.dataset.backdropped) return root;
  root.dataset.backdropped = '1';
  const { root: frame } = bulkheadFrame('', opts);
  frame.style.zIndex = '0';
  frame.style.pointerEvents = 'none';
  for (const c of Array.from(root.children)) {
    c.style.position = c.style.position || 'relative';
    c.style.zIndex = '1';
  }
  root.insertBefore(frame, root.firstChild);
  root.style.background = '#000006';
  return root;
}

/**
 * The shared dimmed star-field scrim that sits behind any open modal, so a
 * popup reads as a panel inside the ship rather than a box on a black page.
 * Reference-counted: several modals can be open across a session and the last
 * one to close takes it down.
 */
let _scrimEl = null;
let _scrimUses = 0;
export function showScrim(on) {
  if (!_scrimEl) {
    _scrimEl = document.createElement('div');
    _scrimEl.style.cssText = 'position:fixed;inset:0;z-index:28;display:none;pointer-events:none;'
      + `background:url("${spacePNG(320, 180, 61)}") center/cover no-repeat;`
      + 'image-rendering:pixelated;opacity:0.55;';
    document.body.appendChild(_scrimEl);
  }
  _scrimUses = Math.max(0, _scrimUses + (on ? 1 : -1));
  _scrimEl.style.display = _scrimUses > 0 ? 'block' : 'none';
}

// Body-kind palettes for the approach thumbnail. Same earth/machine discipline
// as the item icons: these are the colours the 3D planet textures already use.
const BODY_TONES = {
  oceanic: [[34, 78, 132], [52, 108, 168], [90, 150, 196], [58, 112, 68]],
  jungle: [[42, 84, 46], [58, 108, 58], [96, 140, 80], [150, 150, 110]],
  rocky: [[92, 78, 62], [128, 108, 84], [168, 146, 116], [66, 56, 46]],
  ice: [[132, 156, 178], [176, 198, 214], [214, 228, 238], [98, 120, 146]],
  lava: [[86, 34, 20], [148, 62, 28], [214, 116, 44], [246, 186, 88]],
  gas: [[124, 84, 58], [168, 116, 78], [206, 176, 132], [232, 219, 190]],
  star: [[168, 60, 20], [232, 120, 30], [255, 180, 60], [255, 233, 122]],
  station: [[60, 64, 70], [92, 98, 104], [130, 136, 142], [176, 128, 64]],
  // Every kind the generator can produce needs an entry, or the thumbnail lies:
  // a moon or a carbon world falling back to `rocky` shows the player a tan
  // marble for a body that is grey or black in the window right next to it.
  // Tone sets mirror the surface ramps in TextureFactory.planetTexture.
  moon: [[58, 55, 52], [88, 84, 78], [124, 119, 110], [166, 160, 148]],
  comet: [[38, 40, 46], [64, 68, 74], [104, 112, 118], [186, 200, 208]],
  toxic: [[102, 76, 44], [138, 106, 62], [190, 160, 100], [214, 186, 128]],
  carbon: [[20, 21, 24], [44, 46, 51], [76, 79, 86], [188, 192, 202]],
  metal: [[50, 53, 60], [82, 87, 96], [122, 129, 140], [190, 198, 210]],
  tundra: [[70, 76, 60], [110, 112, 84], [166, 160, 124], [214, 222, 232]],
  sulfur: [[88, 70, 32], [134, 108, 44], [186, 92, 48], [206, 186, 120]],
};

/**
 * 40x40 shaded disc for the approach panel — a thumbnail of what you're flying
 * at, in that body kind's own tones, lit from the upper left with hard terminator
 * steps and a dither-broken night side. Gives the landing prompt the same
 * "here is the thing, here are its numbers" shape as the inventory readout.
 */
export function bodyDiscPNG(kind = 'rocky', seed = 3) {
  const key = `disc${kind}:${seed}`;
  if (_cache.has(key)) return _cache.get(key);
  const S = 40;
  const cv = document.createElement('canvas');
  cv.width = S; cv.height = S;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(S, S);
  const d = img.data;
  const tones = BODY_TONES[kind] ?? BODY_TONES.rocky;
  const R = rng(seed + kind.length * 17);
  const half = S / 2, rad = half - 2;
  const put = (x, y, c, a = 255) => {
    const i = (y * S + x) * 4;
    d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = a;
  };
  for (let y = 0; y < S; y++) {
    for (let x = 0; x < S; x++) {
      const dx = (x - half + 0.5) / rad, dy = (y - half + 0.5) / rad;
      const r2 = dx * dx + dy * dy;
      if (r2 > 1) continue;
      // sphere normal, lit from the upper-left
      const nz = Math.sqrt(Math.max(0, 1 - r2));
      const ndl = Math.max(0, (-dx * 0.62) + (-dy * 0.55) + nz * 0.56);
      // surface mottling so it isn't a smooth ball
      const m = (Math.sin(x * 1.7 + y * 0.9 + seed) * 0.5 + Math.sin(x * 0.6 - y * 1.3) * 0.5);
      let lvl = Math.floor((ndl * 0.86 + m * 0.14 + 0.06) * tones.length);
      if (bay(x, y) > 0.55) lvl += 1; // hard terminator, dither-broken
      lvl = Math.max(0, Math.min(tones.length - 1, lvl));
      const lit = ndl > 0.06;
      const c = tones[lvl];
      // night side: not black — a dim, cool version, so the disc still reads
      put(x, y, lit ? c : [c[0] * 0.22 + 6, c[1] * 0.22 + 6, c[2] * 0.26 + 10]);
      if (!lit && bay(x, y) > 0.7) put(x, y, [10, 10, 16]);
    }
  }
  // limb: one darker pixel ring so it sits against the panel
  for (let a2 = 0; a2 < 360; a2 += 3) {
    const t = (a2 * Math.PI) / 180;
    const x = Math.round(half + Math.cos(t) * (rad - 0.2));
    const y = Math.round(half + Math.sin(t) * (rad - 0.2));
    if (x >= 0 && y >= 0 && x < S && y < S) put(x, y, [8, 8, 12]);
  }
  void R;
  ctx.putImageData(img, 0, 0);
  const uri = cv.toDataURL();
  _cache.set(key, uri);
  return uri;
}

/** A labelled readout panel: title strip over a body of lines. */
function infoPanel(heading, lines, opts = {}) {
  const el = document.createElement('div');
  el.style.cssText = [
    'position:relative', `width:${opts.w ?? 200}px`, 'padding:0 0 9px',
    `background:url("${platePNG(120, 96, 'panel', opts.seed ?? 3)}") center/100% 100% no-repeat`,
    'image-rendering:pixelated', 'box-shadow:0 3px 12px #000000c0',
    'flex:0 0 auto',
  ].join(';');
  const h = document.createElement('div');
  h.textContent = heading;
  h.style.cssText = 'margin:0 7px 7px;padding:5px 0 4px;color:#c89a58;font:10px monospace;'
    + 'letter-spacing:0.28em;text-align:center;border-bottom:1px solid #4a361e;'
    + 'text-shadow:0 1px 0 #000;';
  el.appendChild(h);
  for (const line of lines) {
    const row = document.createElement('div');
    if (Array.isArray(line)) {
      row.style.cssText = 'display:flex;justify-content:space-between;gap:10px;padding:2px 11px;'
        + 'font:9px monospace;letter-spacing:0.1em;';
      const a = document.createElement('span'); a.textContent = line[0]; a.style.color = '#7d6038';
      const b = document.createElement('span'); b.textContent = line[1]; b.style.color = '#c89a58';
      row.append(a, b);
    } else {
      row.textContent = line;
      row.style.cssText = 'padding:2px 11px;color:#8a6a3e;font:9px monospace;'
        + 'letter-spacing:0.1em;line-height:1.5;';
    }
    el.appendChild(row);
  }
  return el;
}

/**
 * Rebuild #gate as a real main menu: the ship's deep-space view inside a
 * bulkhead surround, the title on its own plate, and the content split into
 * three columns — survey route on the left, the boarding action in the middle,
 * the control reference on the right.
 *
 * The old gate was one centred slab with the whole controls list crammed under
 * the title, which is why everything read as a wall of text with no hierarchy.
 * index.html still ships the plain-CSS version so the first paint needs no JS;
 * this replaces it the moment the engine boots.
 */
function buildMainMenu() {
  const gate = document.getElementById('gate');
  if (!gate) return;
  gate.innerHTML = '';
  gate.style.background = '#000003';
  gate.style.padding = '0';
  gate.style.gap = '0';

  const { root, content } = bulkheadFrame('STARRIFT', { skySeed: 5 });
  gate.appendChild(root);

  const sub = document.createElement('div');
  sub.innerHTML = 'KESTREL EXTRACTION &amp; SALVAGE CO.<br>'
    + 'HSV AETHON — HEAVY SURVEY VESSEL — CREW 1 OF 6';
  sub.style.cssText = 'position:relative;margin-top:7px;color:#6f4f26;font:9px monospace;'
    + 'letter-spacing:0.22em;text-align:center;line-height:1.7;';
  root.insertBefore(sub, content);

  const route = infoPanel('SURVEY ROUTE', [
    ['1 SOL PRIME', 'LOW'], ['2 VEGA REACH', 'HIGH'], ['3 REDFALL', 'MED'],
    ['4 TWIN SUNS', 'HIGH'], ['5 THE PALE', 'EXTREME'],
  ], { w: 186, seed: 3 });

  // middle column: the action, with room to breathe
  const mid = document.createElement('div');
  mid.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:12px;flex:0 0 auto;';
  const board = document.createElement('div');
  board.className = 'hint blink';
  board.textContent = '[ TAP / CLICK TO BOARD ]';
  board.style.cssText += ';font:13px monospace;letter-spacing:0.26em;color:#d8ac68;'
    + 'text-shadow:0 0 14px #b0804070, 0 2px 0 #000;';
  mid.append(hazardBar('250px'), board, hazardBar('250px'));
  const seal = document.createElement('div');
  seal.textContent = 'AIRLOCK 1 — PRESSURE EQUALIZED';
  seal.style.cssText = 'color:#6f4f26;font:9px monospace;letter-spacing:0.2em;';
  mid.appendChild(seal);

  const keys = infoPanel('CONTROLS', [
    'ON FOOT', ' WASD MOVE · MOUSE LOOK', ' E USE · SHIFT RUN · C DUCK',
    ' G LAMP · TAB SCAN · I BAG · L LOG', '',
    'PILOT', ' W/S THRUST · A/D ROLL', ' Q/E STRAFE · R/F CLIMB·DIVE',
    ' SHIFT BOOST · SPACE BRAKE', ' Z ASSIST · X FIRE · V VIEW', ' J WARP · C STAND',
  ], { w: 214, seed: 9 });

  content.append(route, mid, keys);
  // narrow viewports: drop the side panels rather than squeeze them to shreds
  const fit = () => {
    const narrow = window.innerWidth < 720;
    route.style.display = narrow ? 'none' : 'block';
    keys.style.display = narrow ? 'none' : 'block';
  };
  fit();
  window.addEventListener('resize', fit);
}

/**
 * Same surround for the boot screen, with a segmented pixel progress bar.
 * Exported because it has to run at the START of boot — applyBootChrome fires
 * after generation finishes, by which point the loading screen is already gone.
 * Keeps the existing #loading-status / #loading-bar / #loading-fill elements
 * (main.js holds references to them) and just re-parents them.
 */
export function applyLoadingChrome() {
  const el = document.getElementById('loading');
  if (!el || el.dataset.chromed) return;
  el.dataset.chromed = '1';
  const status = document.getElementById('loading-status');
  const bar = document.getElementById('loading-bar');
  const fill = document.getElementById('loading-fill');
  el.style.background = '#000003';
  el.style.padding = '0';
  el.style.gap = '0';

  const { root, content } = bulkheadFrame('STARRIFT', { skySeed: 17 });
  const col = document.createElement('div');
  col.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:12px;';
  const corp = document.createElement('div');
  corp.innerHTML = 'KESTREL EXTRACTION &amp; SALVAGE CO. — HSV AETHON';
  corp.style.cssText = 'color:#6f4f26;font:9px monospace;letter-spacing:0.24em;';
  col.appendChild(corp);
  if (bar && fill) {
    // segmented, riveted gauge instead of a plain bordered div — same language
    // as the in-game bars so the boot screen belongs to the game
    bar.style.cssText = 'width:250px;height:12px;border:none;padding:2px;'
      + `background:url("${platePNG(64, 12, 'panel', 15)}") center/100% 100% no-repeat;`
      + 'image-rendering:pixelated;box-shadow:0 2px 8px #000000c0;';
    fill.style.cssText = 'height:100%;width:0%;background:'
      + 'repeating-linear-gradient(90deg,#b08040 0 3px,#8a6430 3px 4px);'
      + 'box-shadow:0 0 6px #b0804060;transition:width 0.18s linear;';
    col.appendChild(bar);
  }
  if (status) { status.style.letterSpacing = '0.22em'; col.appendChild(status); }
  content.appendChild(col);
  el.innerHTML = '';
  el.appendChild(root);
}

/**
 * Reskin the static boot overlays (#gate main menu, #pause) with generated
 * plates — index.html ships plain CSS so the first paint needs no JS, and
 * this upgrades it the moment the engine boots.
 */
export function applyBootChrome() {
  buildMainMenu();
  applyLoadingChrome(); // covers the boot-fault path, which re-shows #loading
  const pause = document.getElementById('pause');
  const pausePlate = document.querySelector('#pause > div');
  if (pausePlate) framePanel(pausePlate, { seed: 5 });
  // the pause veil gets the same star field as every other screen, dimmed so
  // the frozen game still reads through it
  if (pause) {
    pause.style.background = `url("${spacePNG(320, 180, 83)}") center/cover no-repeat, rgba(0,0,3,0.72)`;
    pause.style.backgroundBlendMode = 'soft-light';
    pause.style.imageRendering = 'pixelated';
  }
  const pauseBtn = document.getElementById('pause-settings');
  if (pauseBtn) pauseBtn.style.cssText += ';' + plasticButton('font-size:11px;letter-spacing:0.22em;padding:8px 20px;min-height:34px;');
}

/**
 * BOOKMARK TAB BAR — a strip of tabs across the top of the screen that switches
 * between the full-screen panels.
 *
 * Why this exists: BAG and LOG were merged into one chip in session 17a, and the
 * chip CYCLED (hold → journal → closed). The owner's verdict was blunt and correct
 * — tapping a button labelled BAG/LOG opens the hold, and nothing on screen tells
 * you the journal is one more tap away. A cycle is a hidden state machine wearing a
 * button's clothes.
 *
 * Tabs make the choice visible instead: the bar appears whenever any of its panels
 * is open, shows which one you are in, and every other panel is one direct tap
 * away. It is styled like a row of index bookmarks clipped over a folder — a
 * physical object, in keeping with a ship where everything else is machined.
 *
 * @param {{label:string, isOpen:()=>boolean, open:()=>void}[]} tabs
 * @returns {{sync:()=>void, root:HTMLElement}}
 */
export function bookmarkBar(tabs) {
  // Chrome.js is deliberately standalone — it carries its own AMBER/AMBER_HI rather
  // than importing PALETTE, so that the plate painters can run before Constants
  // resolves the render scale. Use the local constants, not PALETTE.
  const amber = `rgb(${AMBER_HI.join(',')})`;
  const dim = `rgb(${RIVET.join(',')})`;
  const root = document.createElement('div');
  // z above the panels themselves (they sit at 30-34) so the bar is always
  // reachable, and centred so it reads as furniture rather than as a floating chip
  // Anchored to the top LEFT of the frame, not centred.
  //
  // Centred put the row straight through each panel's own centred title plate —
  // the HOLD tab covered the word HOLD — and `top:0` clipped the three pixels an
  // inactive tab is raised by, so JOURNAL sat at y=-3 with its top edge off the
  // viewport. Left of the title, three pixels down: still bookmarks hanging off
  // the top edge, but clear of the panel's own furniture and fully on screen.
  root.style.cssText = [
    'position:fixed', 'left:40px', 'top:3px',
    'z-index:40', 'display:none', 'gap:0', 'pointer-events:auto',
    'font:11px monospace', 'letter-spacing:0.16em',
  ].join(';');

  const made = tabs.map((t) => {
    const el = document.createElement('div');
    el.textContent = t.label;
    // The tab shape is the point: square along the top edge where it meets the
    // screen border, chamfered along the bottom, so the row reads as bookmarks
    // hanging off an edge rather than as buttons floating near one.
    el.style.cssText = [
      'position:relative', 'padding:9px 18px 8px', 'min-width:74px', 'min-height:44px',
      'display:flex', 'align-items:center', 'justify-content:center',
      'cursor:pointer', 'user-select:none', '-webkit-user-select:none', 'touch-action:none',
      'clip-path:polygon(0 0,100% 0,100% calc(100% - 7px),calc(100% - 7px) 100%,7px 100%,0 calc(100% - 7px))',
      'image-rendering:pixelated',
    ].join(';');
    const press = (e) => { e.preventDefault(); e.stopPropagation(); t.open(); sync(); };
    el.addEventListener('click', press);
    el.addEventListener('touchend', press, { passive: false });
    root.appendChild(el);
    return { ...t, el };
  });

  /** Repaint: the open tab sits proud and lit, the rest recede. */
  function sync() {
    let anyOpen = false;
    for (const t of made) {
      const on = t.isOpen();
      if (on) anyOpen = true;
      t.el.style.background = on
        ? 'linear-gradient(180deg,#2b2620,#171410)'
        : 'linear-gradient(180deg,#14141a,#0c0c11)';
      t.el.style.color = on ? amber : dim;
      // the lit tab gains a thick underline and loses its top shadow, so it reads
      // as the sheet in front
      t.el.style.boxShadow = on
        ? `inset 0 -3px 0 ${amber}, inset 0 1px 0 #ffe0b026, 0 3px 8px rgba(0,0,0,0.8)`
        : 'inset 0 -3px 0 #3a2c1c, inset 0 -6px 8px rgba(0,0,0,0.55)';
      t.el.style.transform = on ? 'translateY(0)' : 'translateY(-3px)';
    }
    root.style.display = anyOpen ? 'flex' : 'none';
  }

  document.body.appendChild(root);
  return { sync, root };
}
