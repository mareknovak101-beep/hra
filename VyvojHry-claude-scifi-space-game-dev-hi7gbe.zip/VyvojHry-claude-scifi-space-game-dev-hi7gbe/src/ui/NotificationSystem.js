/**
 * NotificationSystem — short diegetic-ish text lines (interact feedback, system
 * messages), bottom-center, AMBER-9, quantized fade (no smooth alpha ramps).
 */
import { PALETTE, RENDER } from '../core/Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';
import { FONT_FACES } from '../rendering/PixelFont.js';

const MAX_VISIBLE = 2; // the free band below the prompt is 22px — two lines
const DURATION = 4.5; // seconds
const FADE_STEPS = 4; // alpha quantization — dither-era fade

export class NotificationSystem {
  constructor() {
    /** @type {Array<{text:string, age:number}>} */
    this.items = [];
    this.amber = hexToRgbf(PALETTE.HUD_AMBER[1]);
    this.bg = hexToRgbf(PALETTE.HUD_PANEL_BG[0]);
  }

  push(text) {
    this.items.push({ text: String(text).toUpperCase(), age: 0 });
    if (this.items.length > MAX_VISIBLE) this.items.shift();
  }

  update(dt) {
    for (const item of this.items) item.age += dt;
    this.items = this.items.filter((i) => i.age < DURATION);
  }

  /**
   * @param {import('../rendering/PixelRenderer.js').PixelRenderer} pix
   * @param {import('../rendering/PixelFont.js').PixelFont} font
   */
  render(pix, font) {
    // Centred in the 162–184 band, stacking DOWNWARD, newest first.
    //
    // This took two goes. It used to sit at y=168 stacking UPWARD, which put the
    // second and third lines straight through the interact prompt (`[E] OPEN
    // DOOR` occupies 147–160) and the crosshair. Moving the whole stack to the
    // top under the compass fixed that but traded it for a worse collision: a
    // long message is ~385px wide on a 480px grid, so it ran clean across the
    // SENSORS panel at x 34–126.
    //
    // So it stays low, below the prompt and above the VITALS/SHIP consoles at
    // y=184 — the only band on the screen that is full-width AND empty. It is
    // 22px, which is two lines at a 10px pitch, hence MAX_VISIBLE 2: the third
    // line has nowhere to go that isn't on top of something the player needs.
    for (let i = 0; i < this.items.length; i++) {
      const item = this.items[this.items.length - 1 - i];
      const remain = 1 - item.age / DURATION;
      const alpha = Math.ceil(remain * FADE_STEPS) / FADE_STEPS;
      const w = font.measure(FONT_FACES.AMBER9, item.text);
      const x = Math.round((RENDER.UI_WIDTH - w) / 2);
      // y=62, not 162. The command bar took the last 19 rows of the buffer and
      // the VITALS plate moved up to 176 to clear it, which put the message
      // stack straight through the plate's header. Under the compass and the
      // critical-alert strip is the one band nothing else claims in either mode:
      // SENSORS is hard left, the NAV and TARGET plates are hard right, and
      // messages read better near the top anyway.
      const y = 62 + i * 10;
      pix.rect(x - 4, y - 2, w + 8, 11, [this.bg[0], this.bg[1], this.bg[2], 0.75 * alpha]);
      pix.text(font, FONT_FACES.AMBER9, x, y, item.text,
        [this.amber[0], this.amber[1], this.amber[2], alpha]);
    }
  }
}
