/**
 * DialogueUI — the conversation panel.
 *
 * Deliberately NOT a wall of options. A person on a counter has four things
 * they will talk about, the last thing they said stays on screen while you pick
 * the next one, and the topics you have already spent stop appearing. That is
 * the entire interaction: no timers, no persuasion checks, no reputation gate
 * on the buttons — the gate is that some of them only work once.
 *
 * The panel keeps a short TRANSCRIPT, because a line generated from live state
 * ("your deflector is at 31%") is the sort of thing you want still readable
 * while you decide what to ask next, and because scrolling back through what
 * somebody told you is what makes them feel like a person rather than a menu.
 */
import { plasticButton, plasticPanel, hazardBar, framePanel, showScrim, panelChrome } from './Chrome.js';

export class DialogueUI {
  /**
   * @param {import('../gameplay/Dialogue.js').Dialogue} dialogue
   * @param {() => void} [onClose]
   */
  constructor(dialogue, onClose) {
    this.dialogue = dialogue;
    this.onClose = onClose;
    this.visible = false;
    this.station = null;
    this.kind = null;
    /** @type {string[]} */
    this.log = [];

    this.root = document.createElement('div');
    this.root.style.cssText = plasticPanel([
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:32', 'display:none', 'width:min(480px,94vw)', 'max-height:82vh',
      'overflow-y:auto', 'padding:14px 16px', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none',
    ].join(';'));

    this.who = document.createElement('div');
    this.who.style.cssText = 'font-size:14px;letter-spacing:0.12em;color:#d0a060;margin-bottom:2px;';
    this.role = document.createElement('div');
    this.role.style.cssText = 'font-size:9px;color:#7d6038;letter-spacing:0.24em;margin-bottom:6px;';
    this.body = document.createElement('div');
    this.body.style.cssText = 'display:flex;flex-direction:column;gap:7px;margin-bottom:10px;'
      + 'min-height:64px;';
    this.opts = document.createElement('div');
    this.opts.style.cssText = 'display:flex;flex-direction:column;gap:5px;';
    this.root.append(this.who, hazardBar('60%'), this.role, this.body, this.opts);
    document.body.appendChild(this.root);
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });
    framePanel(this.root, { seed: 53 });
  }

  _tap(el, fn) {
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    el.addEventListener('click', h);
    el.addEventListener('touchend', h, { passive: false });
  }

  _rebuild() {
    this.body.textContent = '';
    if (!this.log.length) {
      const idle = document.createElement('div');
      idle.textContent = 'They look up, and wait.';
      idle.style.cssText = 'font-size:10px;color:#5f4b2c;font-style:italic;line-height:1.6;';
      this.body.appendChild(idle);
    }
    // Oldest first, the newest one bright — a transcript, not a speech bubble.
    for (let i = 0; i < this.log.length; i++) {
      const p = document.createElement('div');
      p.textContent = this.log[i];
      const last = i === this.log.length - 1;
      p.style.cssText = `font-size:${last ? 11 : 10}px;line-height:1.6;`
        + `color:${last ? '#c09050' : '#6f5836'};`
        + (last ? '' : 'padding-bottom:5px;border-bottom:1px solid #2a2a36;');
      this.body.appendChild(p);
    }

    this.opts.textContent = '';
    const list = this.dialogue.topics(this.station, this.kind);
    for (const t of list) {
      const b = document.createElement('div');
      b.textContent = t.once ? `${t.label}  ·  ONCE` : t.label;
      b.style.cssText = plasticButton('padding:7px 10px;font-size:9px;min-width:0;'
        + 'letter-spacing:0.14em;text-align:left;justify-content:flex-start;'
        + (t.once ? 'color:#c8a058;' : ''));
      this._tap(b, () => {
        const line = this.dialogue.ask(this.station, this.kind, t.id);
        if (line) {
          this.log.push(line);
          // Three deep. Any more and the buttons leave the screen.
          if (this.log.length > 3) this.log.shift();
        }
        this._rebuild();
      });
      this.opts.appendChild(b);
    }
    const leave = document.createElement('div');
    leave.textContent = 'THAT IS ALL';
    leave.style.cssText = plasticButton('margin-top:5px;padding:7px 10px;font-size:9px;'
      + 'min-width:0;letter-spacing:0.2em;opacity:0.8;');
    this._tap(leave, () => this.hide());
    this.opts.appendChild(leave);
  }

  /**
   * @param {object} station the docked station body
   * @param {string} kind crew archetype id
   * @param {string} name generated person name
   * @param {string} role what the prompt called them
   */
  open(station, kind, name, role) {
    this.station = station;
    this.kind = kind;
    this.log = [];
    this.who.textContent = name ?? 'CREW';
    this.role.textContent = `${role ?? ''} — ${station?.name ?? 'STATION'}`.toUpperCase();
    if (!this.visible) showScrim(true);
    this.visible = true;
    this._rebuild();
    this.root.style.display = 'block';
  }

  hide() {
    if (this.visible) showScrim(false);
    this.visible = false;
    this.root.style.display = 'none';
    this.onClose?.();
  }
}
