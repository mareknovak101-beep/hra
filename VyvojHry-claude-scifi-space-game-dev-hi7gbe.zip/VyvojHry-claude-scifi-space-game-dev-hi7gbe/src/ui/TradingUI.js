/**
 * TradingUI — the station counter (Phase 7). Opens on docking at any trading
 * station: BUY tab lists the station's seeded stock, SELL tab lists the hold.
 * Same pixel-art plate chrome as every other panel; prices come live from
 * TradingSystem so the station's bias shows in the quotes.
 */
import { plasticButton, plasticPanel, hazardBar, framePanel, showScrim, panelChrome } from './Chrome.js';

export class TradingUI {
  /**
   * @param {import('../gameplay/TradingSystem.js').TradingSystem} trading
   * @param {import('../gameplay/Inventory.js').Inventory} inventory
   * @param {(text:string)=>void} notify
   * @param {() => void} [onClose] called when the counter is left (re-lock/resume)
   */
  constructor(trading, inventory, notify, onClose) {
    this.trading = trading;
    this.inventory = inventory;
    this.notify = notify;
    this.onClose = onClose;
    this.visible = false;
    this.station = null;
    this.tab = 'buy';

    this.root = document.createElement('div');
    this.root.style.cssText = plasticPanel([
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:32', 'display:none', 'width:min(470px,92vw)', 'max-height:82vh',
      'overflow-y:auto', 'padding:14px 16px', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none',
    ].join(';'));

    this.title = document.createElement('div');
    this.title.style.cssText = 'font-size:14px;letter-spacing:0.12em;color:#d0a060;margin-bottom:2px;';
    this.credLine = document.createElement('div');
    this.credLine.style.cssText = 'font-size:11px;color:#b08040;margin-bottom:6px;';
    this.tabs = document.createElement('div');
    this.tabs.style.cssText = 'display:flex;gap:6px;margin-bottom:10px;';
    this.list = document.createElement('div');
    this.root.append(this.title, hazardBar('60%'), this.credLine, this.tabs, this.list);
    document.body.appendChild(this.root);
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });
    framePanel(this.root, { seed: 17 });
  }

  _chip(label, active, fn) {
    const c = document.createElement('div');
    c.textContent = label;
    c.style.cssText = plasticButton('padding:4px 9px;font-size:9px;min-width:0;' +
      (active ? 'color:#d0a060;' : 'opacity:0.65;'));
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    c.addEventListener('click', h);
    c.addEventListener('touchend', h, { passive: false });
    return c;
  }

  _row(name, sub, price, verb, fn) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;' +
      'padding:6px 2px;border-bottom:1px solid #2a2a36;';
    const left = document.createElement('div');
    const n = document.createElement('div');
    n.textContent = name;
    n.style.cssText = 'font-size:11px;color:#c09050;letter-spacing:0.06em;';
    const s = document.createElement('div');
    s.textContent = sub;
    s.style.cssText = 'font-size:9px;color:#704a20;';
    left.append(n, s);
    const right = document.createElement('div');
    right.style.cssText = 'display:flex;align-items:center;gap:8px;';
    const p = document.createElement('div');
    p.textContent = `${price} CR`;
    p.style.cssText = 'font-size:11px;color:#b08040;min-width:56px;text-align:right;';
    const btn = document.createElement('div');
    btn.textContent = verb;
    btn.style.cssText = plasticButton('padding:4px 10px;font-size:9px;min-width:0;');
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    btn.addEventListener('click', h);
    btn.addEventListener('touchend', h, { passive: false });
    right.append(p, btn);
    row.append(left, right);
    return row;
  }

  _rebuild() {
    if (!this.station) return;
    this.title.textContent = `${this.station.name} — TRADE COUNTER`;
    this.credLine.textContent = `ACCOUNT: ${this.trading.credits} CR`;
    this.tabs.textContent = '';
    this.tabs.append(
      this._chip('BUY', this.tab === 'buy', () => { this.tab = 'buy'; this._rebuild(); }),
      this._chip('SELL', this.tab === 'sell', () => { this.tab = 'sell'; this._rebuild(); }),
      this._chip('LEAVE COUNTER', false, () => this.hide()),
    );
    this.list.textContent = '';
    if (this.tab === 'buy') {
      for (const { id, def, price } of this.trading.stock(this.station)) {
        this.list.appendChild(this._row(def.name, `${def.category.toUpperCase()} — ${def.weight} kg`, price, 'BUY', () => {
          const r = this.trading.buy(id, this.station);
          if (r !== true) this.notify(r);
          this._rebuild();
        }));
      }
    } else {
      const rows = this.inventory.grouped();
      if (!rows.length) {
        const empty = document.createElement('div');
        empty.textContent = 'THE HOLD IS EMPTY. NOTHING TO MOVE.';
        empty.style.cssText = 'font-size:11px;color:#8a7050;';
        this.list.appendChild(empty);
      }
      for (const { id, qty, def } of rows) {
        const price = this.trading.sellPrice(id, this.station);
        this.list.appendChild(this._row(`${def.name} ×${qty}`, `${def.category.toUpperCase()}`, price, 'SELL', () => {
          const r = this.trading.sell(id, this.station);
          if (r !== true) this.notify(r);
          this._rebuild();
        }));
      }
    }
  }

  /** Open the counter for a docked station body. */
  open(station) {
    this.station = station;
    this.tab = 'buy';
    if (!this.visible) showScrim(true);
    this.visible = true;
    this._rebuild();
    this.root.style.display = 'block';
  }

  hide() { if (this.visible) showScrim(false); this.visible = false; this.root.style.display = 'none'; this.onClose?.(); }
}
