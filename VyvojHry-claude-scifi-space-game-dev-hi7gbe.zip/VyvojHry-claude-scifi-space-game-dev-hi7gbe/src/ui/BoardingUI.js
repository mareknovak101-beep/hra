/**
 * BoardingUI — the panel you work a wreck through.
 *
 * Two buttons and one number, and the number is the point: OXYGEN against
 * RETURN MARGIN. Every compartment you open costs air twice, once to be in it
 * and once to walk back out past it, so the margin climbs while the tank falls
 * and the two figures converge on screen while you decide. When they meet, the
 * decision has been made for you.
 *
 * DOM rather than the 480×270 buffer, like every other panel that needs a
 * pointer: the HUD grid is for things you read while flying, and this is a
 * thing you stop and think about.
 */
import { PALETTE } from '../core/Constants.js';
import { plasticButton, plasticPanel, framePanel, showScrim, panelChrome } from './Chrome.js';

export class BoardingUI {
  /**
   * @param {import('../gameplay/Boarding.js').Boarding} boarding
   * @param {() => void} onClose called after the run finishes, so main.js can
   *   hand the pointer back to the flight controls
   */
  constructor(boarding, onClose = () => {}) {
    this.boarding = boarding;
    this.onClose = onClose;
    this.visible = false;

    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    const border = PALETTE.HUD_AMBER[0];

    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:31', 'display:none', 'width:min(460px,90vw)', 'max-height:84vh', 'overflow-y:auto',
      'padding:14px 16px', 'pointer-events:auto', 'user-select:none', '-webkit-user-select:none',
    ].join(';') + ';' + plasticPanel();

    this.title = document.createElement('div');
    this.title.style.cssText = `font-size:15px;letter-spacing:0.14em;margin-bottom:2px;color:${amber};`;
    this.sub = document.createElement('div');
    this.sub.style.cssText = `font-size:10px;letter-spacing:0.16em;color:${amberLo};margin-bottom:10px;opacity:0.85;`;
    this.root.append(this.title, this.sub);

    // -- the two figures that matter -----------------------------------------
    this.gauge = document.createElement('div');
    this.gauge.style.cssText = `border:1px solid ${border}66;border-radius:6px;padding:9px 11px;`
      + 'margin-bottom:10px;background:#0a0b0e;';
    this.root.appendChild(this.gauge);

    // -- the compartment you are standing in ---------------------------------
    this.body = document.createElement('div');
    this.body.style.cssText = `font-size:11px;line-height:1.55;color:${amberLo};`
      + `border-left:2px solid ${border}88;padding:2px 0 2px 9px;margin-bottom:12px;min-height:44px;`;
    this.root.appendChild(this.body);

    // -- the log of what this run has produced -------------------------------
    this.log = document.createElement('div');
    this.log.style.cssText = `font-size:10px;line-height:1.5;color:${amberLo};opacity:0.8;`
      + 'max-height:120px;overflow-y:auto;margin-bottom:12px;';
    this.root.appendChild(this.log);

    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:9px;';
    this.deeper = this._btn('PUSH DEEPER', () => {
      this.boarding.advance();
      // `advance` can end the run outright (out of air, or out of hull), and
      // the panel has to follow it rather than sit on a finished state.
      if (!this.boarding.active) this.hide(); else this.refresh();
    });
    this.leave = this._btn('BACK TO THE SHIP', () => {
      this.boarding.finish(this.boarding.status()?.atEnd ?? false);
      this.hide();
    });
    row.append(this.deeper, this.leave);
    this.root.appendChild(row);

    document.body.appendChild(this.root);
    framePanel(this.root, { seed: 41 });
    panelChrome(this.root, () => {
      // Closing the panel is LEAVING, not cancelling. There is no way to be
      // aboard a wreck and not be in this panel, so a close that did nothing
      // would strand the run with no way back to it.
      if (this.boarding.active) this.boarding.finish(false);
      this.hide();
    }, { isOpen: () => this.visible });
  }

  _btn(label, fn) {
    const b = document.createElement('div');
    b.textContent = label;
    b.style.cssText = 'flex:1;justify-content:center;min-height:44px;' + plasticButton();
    const go = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    return b;
  }

  /** Add one line to the run log. */
  push(text) {
    const d = document.createElement('div');
    d.textContent = `· ${text}`;
    this.log.appendChild(d);
    this.log.scrollTop = this.log.scrollHeight;
  }

  refresh() {
    const s = this.boarding.status();
    if (!s) return;
    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    this.title.textContent = s.name;
    this.sub.textContent = `COMPARTMENT ${s.at} OF ${s.of} — ${s.compartment}`;
    // Margin against tank, and the colour flips when going deeper stops being
    // a choice and starts being a gamble.
    const margin = s.exitCost;
    const tight = s.oxygen - margin < 14;
    const col = tight ? '#aa2020' : amber;
    this.gauge.innerHTML = '';
    const line = (k, v, c) => {
      const d = document.createElement('div');
      d.style.cssText = 'display:flex;justify-content:space-between;font-size:11px;letter-spacing:0.1em;'
        + `color:${c};margin:2px 0;`;
      const a = document.createElement('span'); a.textContent = k;
      const b = document.createElement('span'); b.textContent = v;
      d.append(a, b);
      this.gauge.appendChild(d);
    };
    line('SUIT OXYGEN', `${Math.round(s.oxygen)}%`, col);
    line('RETURN MARGIN', `${Math.round(margin)}%`, amberLo);
    line('WORKABLE', `${Math.max(0, Math.round(s.oxygen - margin))}%`, col);
    line('RECOVERED', `${s.taken} ITEM${s.taken === 1 ? '' : 'S'}`, amberLo);
    this.deeper.textContent = s.atEnd ? 'NOTHING DEEPER' : 'PUSH DEEPER';
    this.deeper.style.opacity = s.atEnd ? '0.45' : '1';
    this.leave.textContent = tight ? 'GO NOW' : 'BACK TO THE SHIP';
  }

  show() {
    if (!this.visible) showScrim(true);
    this.visible = true;
    this.root.style.display = 'block';
    this.log.innerHTML = '';
    this.body.textContent = '';
    this.refresh();
  }

  hide() {
    if (this.visible) showScrim(false);
    this.visible = false;
    this.root.style.display = 'none';
    this.onClose();
  }
}
