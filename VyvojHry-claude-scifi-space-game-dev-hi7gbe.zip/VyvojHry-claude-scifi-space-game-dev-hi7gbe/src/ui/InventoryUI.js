/**
 * InventoryUI — the hold manifest: a slot GRID of generated item icons inside
 * the shared bulkhead surround, with a category rail down the left and a
 * SELECTED readout on the right.
 *
 * Every icon is generated (ui/ItemIcons.js) from the item's subcategory and a
 * hash of its id, so all 483 items get a distinguishable pixel sprite without a
 * single asset file.
 *
 * SESSION 18j — DEEPER. With four hundred and eighty three items in the
 * registry, a rail of nine top-level categories and a raw grid stopped being a
 * manifest and started being a haystack. This pass adds the four things you
 * need to actually find something in a full hold:
 *
 *   SEARCH   — types against name AND description, because "the one with the
 *              lithium in it" is how anybody actually remembers an item.
 *   SORT     — five orders, cycled from one chip. Value and bulk are the two
 *              that matter when a hold is full and something has to go.
 *   SUBRAIL  — a second rail of subcategories under the chosen category, so
 *              MATERIAL splits into ore / alloy / crystal / salvage rather
 *              than being a hundred and thirty four tiles in one heap.
 *   READOUT  — the real record: value, mass and bulk per unit AND per stack,
 *              rarity, stack limit, what USE actually does to which stat, and
 *              where the thing is normally found.
 *
 * Plus a live capacity bar on the header — a number told you how full you were
 * and a bar tells you at a glance, which is the difference between reading the
 * panel and glancing at it.
 *
 * JETTISON needs two taps. A hold this deep will eventually be full at a bad
 * moment, and the fix for that has to be reachable — but not so reachable that
 * a fat finger costs you a Precursor relic.
 *
 * DOM-based like the other panels: touch-first, never touches the 480x270
 * buffer, amber chrome.
 */
import { CAPACITY_SLOTS } from '../gameplay/Inventory.js';
import { plasticButton, hazardBar, bulkheadFrame, platePNG, itemIconPNG } from './Chrome.js';
import { panelChrome } from './Chrome.js';

const CAT_LABEL = {
  consumable: 'CONSUM', material: 'MATERIAL', component: 'COMPONENT',
  tool: 'TOOLS', weapon: 'WEAPONS', artifact: 'ARTIFACT', data: 'DATA',
  trade: 'TRADE', personal: 'PERSONAL',
};
/** Subcategory labels, kept short enough for a 74px chip. */
const SUB_LABEL = {
  food: 'FOOD', drink: 'DRINK', medical: 'MEDICAL', fuel: 'FUEL', oxygen: 'O2',
  ship: 'SHIP PARTS', ore: 'ORE', alloy: 'ALLOY', crystal: 'CRYSTAL',
  salvage: 'SALVAGE', mineral: 'MINERAL', gas: 'GAS', hand: 'HAND TOOL',
  pistol: 'SIDEARM', rifle: 'LONG ARM', industrial: 'CUTTER', ammo: 'AMMO',
  ancient: 'PRECURSOR', log: 'LOGS', records: 'RECORDS', restricted: 'SEALED',
  goods: 'GOODS', bulk: 'BULK', effects: 'EFFECTS', electronics: 'ELECTRONIC',
  faction: 'FACTION', biological: 'BIOLOGY', equipment: 'FIELD KIT',
  suit: 'SUIT', spares: 'SPARES', fitting: 'FITTING',
};
/** What an effect key does to you or the hull, in the HUD's own words. */
const STAT_LABEL = {
  hunger: 'FOOD', thirst: 'WATER', health: 'HEALTH', fatigue: 'REST',
  radiation: 'RADIATION', oxygen: 'OXYGEN', fuel: 'SHIP FUEL',
  warpFuel: 'WARP FUEL', shield: 'SHIELD', hull: 'HULL', power: 'POWER',
};
const RARITY_COLOR = {
  common: '#8a7050', uncommon: '#8ea070', rare: '#c09050', unique: '#c07a40',
};
/** Sort orders, cycled by the SORT chip. */
const SORTS = [
  { id: 'kind', label: 'SORT: KIND' },
  { id: 'name', label: 'SORT: NAME' },
  { id: 'value', label: 'SORT: VALUE' },
  { id: 'mass', label: 'SORT: MASS' },
  { id: 'bulk', label: 'SORT: BULK' },
  { id: 'qty', label: 'SORT: COUNT' },
];
const GRID_COLS = 6;
const GRID_ROWS = 5;
/**
 * A phone stacks rail / grid / readout into one column, and five rows of
 * sockets plus a full item record does not fit in 760px. Three rows and a pager
 * does — and thirty sockets on a phone was always more scrolling than paging.
 */
const GRID_ROWS_NARROW = 3;

export class InventoryUI {
  /**
   * @param {import('../gameplay/Inventory.js').Inventory} inventory
   * @param {(id:string)=>void} onUse called with the item id to consume
   * @param {(text:string)=>void} [notify] for the jettison confirmation
   * @param {{onOpen?:()=>void, onClose?:()=>void}} [hooks] pointer-lock handover.
   *   The SEARCH field is a real DOM input, and a real DOM input cannot be
   *   clicked into while the pointer is locked to the canvas — so the panel
   *   hands the mouse back on open and asks for it again on close. It is a
   *   full-screen opaque overlay, so the lock was doing nothing anyway.
   */
  constructor(inventory, onUse, notify, hooks = {}) {
    this.inventory = inventory;
    this.onUse = onUse;
    this.notify = notify ?? (() => {});
    this.onOpen = hooks.onOpen;
    this.onClose = hooks.onClose;
    this.visible = false;
    this.filter = null;
    this.subFilter = null;
    this.query = '';
    this.sort = 'kind';
    this.selected = null;
    this.page = 0;
    /** id the JETTISON button is armed for, cleared on any other interaction */
    this._armed = null;

    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:30', 'display:none',
      "font-family:'Courier New',monospace", 'letter-spacing:0.1em',
      'background:#000006', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none', 'touch-action:none',
    ].join(';');

    const { root: frame, content } = bulkheadFrame('HOLD MANIFEST', { skySeed: 41, thin: true });
    this.frame = frame;
    this.root.appendChild(frame);

    // -- header: the capacity bar and the numbers behind it ---------------------
    const head = document.createElement('div');
    head.style.cssText = 'position:relative;margin-top:5px;display:flex;flex-direction:column;'
      + 'align-items:center;gap:3px;';
    this.capLine = document.createElement('div');
    this.capLine.style.cssText = 'color:#7d6038;font-size:9px;letter-spacing:0.2em;text-align:center;';
    // A bar, because "94.5 / 120" is a number you read and a bar is a thing you
    // glance at. Two layers: a sunk track and a fill that goes warning red as
    // the hold closes out.
    const track = document.createElement('div');
    track.style.cssText = 'width:min(300px,60vw);height:6px;background:#14140f;'
      + 'box-shadow:inset 0 1px 3px #000000e0;border:1px solid #3a2e1c;';
    this.capFill = document.createElement('div');
    this.capFill.style.cssText = 'height:100%;width:0%;background:#8a6a3e;';
    track.appendChild(this.capFill);
    head.append(this.capLine, track);
    frame.insertBefore(head, content);

    content.style.alignItems = 'stretch';
    content.style.gap = '10px';
    content.style.paddingBottom = '46px';

    // -- left rail: category filters, then subcategories ------------------------
    this.tabs = document.createElement('div');
    // `min-height:0` is load-bearing: a flex item defaults to min-height:auto,
    // which refuses to shrink below its content, so `overflow-y:auto` never
    // engages and a long sub-rail runs off the bottom of the screen instead of
    // scrolling inside its column.
    this.tabs.style.cssText = 'display:flex;flex-direction:column;gap:4px;flex:0 0 auto;'
      + 'justify-content:flex-start;padding-top:2px;overflow-y:auto;min-height:0;';

    // -- centre: toolbar, slot grid, pager -------------------------------------
    const mid = document.createElement('div');
    mid.style.cssText = 'flex:1 1 auto;min-width:0;display:flex;flex-direction:column;'
      + 'align-items:center;justify-content:flex-start;gap:6px;';

    this.toolbar = document.createElement('div');
    this.toolbar.style.cssText = 'display:flex;align-items:center;gap:6px;width:100%;'
      + 'justify-content:center;flex-wrap:wrap;';
    this.search = document.createElement('input');
    this.search.type = 'text';
    this.search.placeholder = 'SEARCH';
    this.search.style.cssText = 'flex:0 1 150px;min-width:96px;padding:5px 7px;'
      + "font-family:'Courier New',monospace;font-size:9px;letter-spacing:0.14em;"
      + 'color:#d8ac68;background:#12120c;border:1px solid #4a361e;outline:none;'
      + 'box-shadow:inset 0 1px 4px #000000d0;'
      // The panel root sets `user-select:none` and `touch-action:none` so a drag
      // scrolls the page instead of selecting the chrome. A text field needs
      // both of those back or it cannot be typed into on a phone.
      + 'user-select:text;-webkit-user-select:text;touch-action:auto;';
    this.search.addEventListener('input', () => {
      this.query = this.search.value.trim().toLowerCase();
      this.page = 0;
      this._rebuild();
    });
    // The panel swallows keys elsewhere; the field needs them. Escape still
    // closes, because a search box you cannot escape out of is a trap.
    this.search.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { this.search.blur(); return; }
      e.stopPropagation();
    });
    // panelChrome installs a drag-to-scroll handler on the root; without this
    // the pointerdown that should focus the field is claimed as a drag start.
    for (const ev of ['pointerdown', 'mousedown', 'touchstart']) {
      this.search.addEventListener(ev, (e) => e.stopPropagation());
    }
    this.sortChip = document.createElement('div');
    this._tap(this.sortChip, () => {
      const i = SORTS.findIndex((s) => s.id === this.sort);
      this.sort = SORTS[(i + 1) % SORTS.length].id;
      this.page = 0;
      this._rebuild();
    });
    this.countLine = document.createElement('div');
    this.countLine.style.cssText = 'color:#6a5432;font-size:8px;letter-spacing:0.16em;';
    this.toolbar.append(this.search, this.sortChip, this.countLine);

    this.grid = document.createElement('div');
    this.grid.style.cssText = `display:grid;grid-template-columns:repeat(${GRID_COLS},44px);`
      + 'grid-auto-rows:44px;gap:5px;padding:8px;image-rendering:pixelated;'
      + `background:url("${platePNG(120, 100, 'panel', 23)}") center/100% 100% no-repeat;`
      + 'box-shadow:0 4px 16px #000000c0;';
    this.pager = document.createElement('div');
    this.pager.style.cssText = 'display:flex;align-items:center;gap:8px;';
    mid.append(this.toolbar, this.grid, this.pager);

    // -- right: SELECTED readout ----------------------------------------------
    this.sel = document.createElement('div');
    this.sel.style.cssText = 'flex:0 0 200px;display:flex;flex-direction:column;gap:5px;'
      + 'padding:9px 10px;image-rendering:pixelated;overflow-y:auto;min-height:0;'
      + `background:url("${platePNG(120, 140, 'panel', 37)}") center/100% 100% no-repeat;`
      + 'box-shadow:0 4px 16px #000000c0;';

    content.append(this.tabs, mid, this.sel);
    this.content = content;

    // -- footer: close ---------------------------------------------------------
    const bar = document.createElement('div');
    bar.style.cssText = 'position:absolute;left:0;right:0;bottom:14px;display:flex;'
      + 'justify-content:center;gap:10px;';
    const close = document.createElement('div');
    close.textContent = 'CLOSE';
    close.style.cssText = plasticButton('padding:7px 26px;font-size:11px;letter-spacing:0.22em;');
    this._tap(close, () => this.hide());
    bar.appendChild(close);
    frame.appendChild(bar);

    document.body.appendChild(this.root);
    // already has its own CLOSE chip, so this is for Escape and touch scrolling
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });

    // BAG chip in the left-edge column (main.js reflows the stack)
    this.button = document.createElement('div');
    this.button.textContent = 'BAG';
    this.button.style.cssText = 'position:fixed;left:1.5%;top:8px;z-index:26;display:none;' + plasticButton();
    this._tap(this.button, () => this.toggle());
    document.body.appendChild(this.button);

    /**
     * NARROW VIEWPORTS STACK, THEY DO NOT DROP.
     *
     * The old rule hid both side columns below 620px, which was survivable when
     * the right-hand panel was a name and a mass — and is not now that it is the
     * only place USE and JETTISON live. So on a phone the three columns become
     * three rows: the category rail scrolls sideways above the grid, the grid
     * keeps its six sockets, and the readout sits underneath where there was
     * nothing but starfield before.
     */
    this._fit = () => {
      const narrow = window.innerWidth < 620;
      this.content.style.flexDirection = narrow ? 'column' : 'row';
      this.content.style.alignItems = narrow ? 'center' : 'stretch';
      // `justify-content:center` on an overflowing flex column pushes the START
      // of the column out past the scroll origin, where it cannot be scrolled
      // back to — the category rail ended up behind the title plate at y=10 and
      // read as missing. Stacked content grows downward from the top.
      this.content.style.justifyContent = narrow ? 'flex-start' : 'center';
      // Stacked, the column is taller than the frame, so `content` becomes the
      // scroller. `sr-scroll` is what gives it `touch-action: pan-y` — the panel
      // root sets `touch-action:none` so a stray drag does not pan the page, and
      // without this the readout at the bottom of the column is unreachable on a
      // phone: visible in the DOM, impossible to scroll to with a finger.
      this.content.classList.toggle('sr-scroll', narrow);
      this.content.style.overflowY = narrow ? 'auto' : '';
      this.tabs.style.display = 'flex';
      this.tabs.style.flexDirection = narrow ? 'row' : 'column';
      this.tabs.style.flexWrap = 'nowrap';
      this.tabs.style.overflowX = narrow ? 'auto' : '';
      this.tabs.style.overflowY = narrow ? '' : 'auto';
      this.tabs.style.maxWidth = narrow ? '100%' : '';
      this.tabs.style.minWidth = narrow ? '0' : '';
      this.sel.style.display = 'flex';
      this.sel.style.flex = narrow ? '0 0 auto' : '0 0 200px';
      this.sel.style.width = narrow ? 'min(320px,94%)' : '';
      // The CLOSE bar is pinned 14px off the frame's bottom edge. Stacked, the
      // readout grows down into it, so the column needs clearance the row
      // layout does not.
      this.content.style.paddingBottom = narrow ? '68px' : '46px';
      this._narrow = narrow;
      // A sub-rail indent means nothing in a horizontal strip.
      for (const c of this.tabs.children) {
        if (c.dataset.sub) c.style.marginLeft = narrow ? '0px' : '8px';
      }
    };
    this._fit();
    window.addEventListener('resize', this._fit);
  }

  /** Bind click + touchend once, with the propagation guards these need. */
  _tap(el, fn) {
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    el.addEventListener('click', h);
    el.addEventListener('touchend', h, { passive: false });
  }

  setInGame(on) { this.button.style.display = on ? 'flex' : 'none'; if (!on) this.hide(); }

  /** A rail chip. `pad` distinguishes the category rail from the sub-rail. */
  _railChip(label, active, fn, indent = false) {
    const chip = document.createElement('div');
    chip.textContent = label;
    chip.style.cssText = plasticButton(`padding:${indent ? '4px 5px' : '5px 6px'};`
      + `font-size:${indent ? '7px' : '8px'};min-width:${indent ? '66px' : '74px'};`
      + (indent && !this._narrow ? 'margin-left:8px;' : '')
      + (indent ? 'flex:0 0 auto;' : 'flex:0 0 auto;')
      + (active ? 'color:#e0b070;box-shadow:inset 0 1px 4px #000000d0, 0 0 6px #b0804055;'
        : 'opacity:0.68;'));
    if (indent) chip.dataset.sub = '1';
    this._tap(chip, fn);
    return chip;
  }

  /** Apply search + category + subcategory, then order. */
  _rows(all) {
    let rows = all;
    if (this.filter) rows = rows.filter((r) => r.def.category === this.filter);
    if (this.subFilter) rows = rows.filter((r) => r.def.subCategory === this.subFilter);
    if (this.query) {
      const q = this.query;
      rows = rows.filter((r) => r.def.name.toLowerCase().includes(q)
        || (r.def.description ?? '').toLowerCase().includes(q)
        || (SUB_LABEL[r.def.subCategory] ?? r.def.subCategory).toLowerCase().includes(q));
    }
    const by = {
      // KIND is the old order and stays the default: it groups the rack the way
      // a person would stow it, which is what you want when you are not looking
      // for anything in particular.
      kind: (a, b) => (a.def.category + a.def.subCategory + a.def.name)
        .localeCompare(b.def.category + b.def.subCategory + b.def.name),
      name: (a, b) => a.def.name.localeCompare(b.def.name),
      value: (a, b) => (b.def.value * b.qty) - (a.def.value * a.qty),
      mass: (a, b) => (b.def.weight * b.qty) - (a.def.weight * a.qty),
      bulk: (a, b) => (b.def.volume * b.qty) - (a.def.volume * a.qty),
      qty: (a, b) => b.qty - a.qty,
    };
    return [...rows].sort(by[this.sort] ?? by.kind);
  }

  _rebuild() {
    const inv = this.inventory;
    const cap = inv.capacitySlots ?? CAPACITY_SLOTS;
    const used = inv.usedSlots;
    const frac = Math.max(0, Math.min(1, used / cap));
    this.capLine.textContent =
      `${used.toFixed(1)} / ${cap} SLOTS — ${inv.weightKg.toFixed(1)} KG — ${inv.stacks.length} STACKS`;
    this.capFill.style.width = `${(frac * 100).toFixed(1)}%`;
    // amber working, rust at three quarters, warning red when it is about to
    // start refusing things
    this.capFill.style.background = frac > 0.92 ? '#aa2020' : frac > 0.75 ? '#a04e1a' : '#8a6a3e';

    const all = inv.grouped();

    // -- rail: categories, and the subcategories of the chosen one ------------
    this.tabs.textContent = '';
    const cats = [...new Set(all.map((r) => r.def.category))].sort();
    this.tabs.appendChild(this._railChip('ALL', !this.filter, () => {
      this.filter = null; this.subFilter = null; this.page = 0; this._rebuild();
    }));
    for (const cat of cats) {
      const active = cat === this.filter;
      this.tabs.appendChild(this._railChip(CAT_LABEL[cat] ?? cat.toUpperCase(), active, () => {
        this.filter = cat; this.subFilter = null; this.page = 0; this._rebuild();
      }));
      if (!active) continue;
      // Only the OPEN category expands. A rail with every subcategory of every
      // category on it is the haystack again, one level down.
      const subs = [...new Set(all.filter((r) => r.def.category === cat)
        .map((r) => r.def.subCategory))].sort();
      if (subs.length < 2) continue;
      for (const sub of subs) {
        this.tabs.appendChild(this._railChip(SUB_LABEL[sub] ?? sub.toUpperCase(),
          sub === this.subFilter,
          () => {
            this.subFilter = this.subFilter === sub ? null : sub;
            this.page = 0;
            this._rebuild();
          }, true));
      }
    }

    // -- toolbar --------------------------------------------------------------
    const sortDef = SORTS.find((s) => s.id === this.sort) ?? SORTS[0];
    this.sortChip.textContent = sortDef.label;
    this.sortChip.style.cssText = plasticButton('padding:5px 8px;font-size:8px;min-width:0;'
      + 'letter-spacing:0.14em;color:#c09050;');

    const rows = this._rows(all);
    this.countLine.textContent = rows.length === all.length
      ? `${all.length} STACKS`
      : `${rows.length} OF ${all.length}`;

    const perPage = GRID_COLS * (this._narrow ? GRID_ROWS_NARROW : GRID_ROWS);
    const pages = Math.max(1, Math.ceil(rows.length / perPage));
    this.page = Math.min(this.page, pages - 1);
    const slice = rows.slice(this.page * perPage, this.page * perPage + perPage);

    // grid: one cell per stack, then empty sockets out to a full page so the
    // rack always reads as hardware rather than a ragged list
    this.grid.textContent = '';
    for (let i = 0; i < perPage; i++) {
      const rec = slice[i];
      const cell = document.createElement('div');
      const on = rec && this.selected === rec.id;
      cell.style.cssText = 'position:relative;width:44px;height:44px;image-rendering:pixelated;'
        + `background:url("${platePNG(24, 24, 'button', rec ? 5 : 2)}") center/100% 100% no-repeat;`
        + (rec ? 'cursor:pointer;' : 'opacity:0.45;')
        + (on ? 'box-shadow:inset 0 0 0 2px #b08040, 0 0 8px #b0804070;' : '');
      if (rec) {
        const icon = document.createElement('div');
        icon.style.cssText = 'position:absolute;inset:5px;image-rendering:pixelated;'
          + `background:url("${itemIconPNG(rec.def.category, rec.id, rec.def.subCategory)}") center/100% 100% no-repeat;`;
        cell.appendChild(icon);
        if (rec.qty > 1) {
          const q = document.createElement('div');
          q.textContent = String(rec.qty);
          q.style.cssText = 'position:absolute;right:1px;bottom:0;color:#e0b070;font-size:9px;'
            + 'text-shadow:0 1px 0 #000,1px 0 0 #000,-1px 0 0 #000;';
          cell.appendChild(q);
        }
        // A rarity pip in the corner. Four colours, none of them neon, and it
        // is the only thing on the tile that says "this one is worth carrying".
        if (rec.def.rarity && rec.def.rarity !== 'common') {
          const pip = document.createElement('div');
          pip.style.cssText = 'position:absolute;left:2px;top:2px;width:4px;height:4px;'
            + `background:${RARITY_COLOR[rec.def.rarity]};box-shadow:0 0 3px #00000090;`;
          cell.appendChild(pip);
        }
        cell.title = rec.def.name;
        this._tap(cell, () => { this.selected = rec.id; this._armed = null; this._rebuild(); });
      }
      this.grid.appendChild(cell);
    }

    // pager
    this.pager.textContent = '';
    if (pages > 1) {
      const mk = (label, delta) => {
        const b = document.createElement('div');
        b.textContent = label;
        b.style.cssText = plasticButton('padding:4px 12px;font-size:9px;min-width:0;');
        this._tap(b, () => {
          this.page = Math.max(0, Math.min(pages - 1, this.page + delta));
          this._rebuild();
        });
        return b;
      };
      const n = document.createElement('div');
      n.textContent = `${this.page + 1} / ${pages}`;
      n.style.cssText = 'color:#8a6a3e;font-size:9px;letter-spacing:0.16em;';
      this.pager.append(mk('<', -1), n, mk('>', +1));
    }

    this._paintSelected(rows);
  }

  /** A label/value line in the readout's stat block. */
  _stat(label, value, color = '#8a7050') {
    const d = document.createElement('div');
    d.style.cssText = `display:flex;justify-content:space-between;gap:8px;color:${color};`
      + 'font-size:9px;line-height:1.5;';
    const a = document.createElement('span'); a.textContent = label;
    const b = document.createElement('span'); b.textContent = value;
    b.style.cssText = 'color:#c09050;text-align:right;';
    d.append(a, b);
    return d;
  }

  /** Right-hand readout for whatever is selected (or a prompt when nothing is). */
  _paintSelected(rows) {
    this.sel.textContent = '';
    const head = document.createElement('div');
    head.textContent = 'SELECTED';
    head.style.cssText = 'color:#c89a58;font-size:10px;letter-spacing:0.28em;text-align:center;'
      + 'padding-bottom:4px;border-bottom:1px solid #4a361e;';
    this.sel.appendChild(head);

    const rec = rows.find((r) => r.id === this.selected)
      ?? this.inventory.grouped().find((r) => r.id === this.selected);
    if (!rec) {
      const hint = document.createElement('div');
      hint.textContent = rows.length
        ? 'TAP A SLOT TO INSPECT.'
        : (this.query || this.filter
          ? 'NOTHING IN THE HOLD MATCHES THAT.'
          : 'THE HOLD IS EMPTY. SEARCH CRATES, LOCKERS AND CABINETS.');
      hint.style.cssText = 'color:#7d6038;font-size:10px;line-height:1.6;padding-top:6px;';
      this.sel.appendChild(hint);
      return;
    }
    const def = rec.def;

    const big = document.createElement('div');
    big.style.cssText = 'align-self:center;width:64px;height:64px;image-rendering:pixelated;'
      + `background:url("${itemIconPNG(def.category, rec.id, def.subCategory)}") center/100% 100% no-repeat;`;
    const nm = document.createElement('div');
    nm.textContent = rec.qty > 1 ? `${def.name} x${rec.qty}` : def.name;
    nm.style.cssText = 'color:#d8ac68;font-size:11px;text-align:center;line-height:1.4;';
    const cat = document.createElement('div');
    cat.textContent = `${CAT_LABEL[def.category] ?? def.category.toUpperCase()}`
      + ` · ${SUB_LABEL[def.subCategory] ?? def.subCategory.toUpperCase()}`;
    cat.style.cssText = 'color:#7d6038;font-size:8px;letter-spacing:0.16em;text-align:center;';
    const rar = document.createElement('div');
    rar.textContent = def.rarity.toUpperCase();
    rar.style.cssText = `color:${RARITY_COLOR[def.rarity] ?? '#8a7050'};font-size:8px;`
      + 'letter-spacing:0.24em;text-align:center;';
    const desc = document.createElement('div');
    desc.textContent = def.description ?? '';
    desc.style.cssText = 'color:#8a7050;font-size:9px;line-height:1.5;';
    this.sel.append(big, nm, cat, rar, hazardBar('100%'), desc);

    // -- the record: per unit and per stack, which is the comparison that
    // actually decides what gets jettisoned when the hold closes out ----------
    const block = document.createElement('div');
    block.style.cssText = 'display:flex;flex-direction:column;gap:1px;margin-top:2px;'
      + 'padding-top:4px;border-top:1px solid #3a2e1c;';
    block.appendChild(this._stat('VALUE', `${def.value} CR EA`));
    if (rec.qty > 1) block.appendChild(this._stat('STACK VALUE', `${def.value * rec.qty} CR`));
    block.appendChild(this._stat('MASS', `${def.weight.toFixed(1)} KG EA`));
    if (rec.qty > 1) block.appendChild(this._stat('STACK MASS', `${(def.weight * rec.qty).toFixed(1)} KG`));
    block.appendChild(this._stat('BULK', `${def.volume.toFixed(2)} SLOT EA`));
    if (rec.qty > 1) block.appendChild(this._stat('STACK BULK', `${(def.volume * rec.qty).toFixed(1)} SLOTS`));
    block.appendChild(this._stat('STACKS TO', def.stackable ? `${def.maxStack ?? 10}` : 'NO STACK'));
    this.sel.appendChild(block);

    // -- what using it does, in stat terms ------------------------------------
    if (def.effect && Object.keys(def.effect).length) {
      const eff = document.createElement('div');
      eff.style.cssText = 'display:flex;flex-direction:column;gap:1px;margin-top:2px;'
        + 'padding-top:4px;border-top:1px solid #3a2e1c;';
      const t = document.createElement('div');
      t.textContent = 'ON USE';
      t.style.cssText = 'color:#7d6038;font-size:8px;letter-spacing:0.24em;';
      eff.appendChild(t);
      for (const [k, v] of Object.entries(def.effect)) {
        // Radiation is the one stat where DOWN is good, so its sign is flipped
        // for colour purposes — a chelation dose reading red would be a lie.
        const good = k === 'radiation' ? v < 0 : v > 0;
        eff.appendChild(this._stat(STAT_LABEL[k] ?? k.toUpperCase(),
          `${v > 0 ? '+' : ''}${v}`, good ? '#8ea070' : '#aa6030'));
      }
      this.sel.appendChild(eff);
    }

    // -- where it turns up, which is the only hint the game gives -------------
    if (def.found?.length) {
      const f = document.createElement('div');
      f.textContent = `FOUND: ${def.found.join(', ').toUpperCase()}`;
      f.style.cssText = 'color:#5f4b2c;font-size:8px;letter-spacing:0.1em;line-height:1.5;'
        + 'margin-top:3px;';
      this.sel.appendChild(f);
    }

    // -- actions ---------------------------------------------------------------
    if (def.onUse) {
      const use = document.createElement('div');
      use.textContent = 'USE';
      use.style.cssText = plasticButton('margin-top:5px;padding:8px 0;font-size:11px;'
        + 'letter-spacing:0.24em;color:#e0b070;');
      this._tap(use, () => { this._armed = null; this.onUse(rec.id); this._rebuild(); });
      this.sel.appendChild(use);
    }
    const armed = this._armed === rec.id;
    const drop = document.createElement('div');
    drop.textContent = armed ? 'CONFIRM — VENT IT' : 'JETTISON ONE';
    drop.style.cssText = plasticButton('margin-top:4px;padding:6px 0;font-size:9px;'
      + `letter-spacing:0.2em;color:${armed ? '#cc5030' : '#8a6a3e'};`);
    this._tap(drop, () => {
      if (!armed) { this._armed = rec.id; this._rebuild(); return; }
      this._armed = null;
      this.inventory.remove(rec.id, 1);
      this.notify(`${def.name.toUpperCase()} VENTED. IT IS NOT COMING BACK.`);
      if (this.inventory.count(rec.id) <= 0) this.selected = null;
      this._rebuild();
    });
    this.sel.appendChild(drop);
  }

  toggle() { this.visible ? this.hide() : this.show(); }

  show() {
    const was = this.visible;
    this.visible = true;
    this._armed = null;
    this._fit();
    this._rebuild();
    this.root.style.display = 'block';
    if (!was) this.onOpen?.();
  }

  hide() {
    const was = this.visible;
    this.visible = false;
    this._armed = null;
    this.root.style.display = 'none';
    if (was) this.onClose?.();
  }
}
