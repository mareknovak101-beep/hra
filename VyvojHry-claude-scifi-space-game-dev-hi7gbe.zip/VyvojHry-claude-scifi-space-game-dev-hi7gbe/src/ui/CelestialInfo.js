/**
 * CelestialInfo — the "you are approaching a body" panel. When the ship enters
 * a body's approach sphere (StarSystem.approach) this slides in a diegetic
 * NAV readout with the body's class + basic data and a LAND / LEAVE choice.
 * Landing is a placeholder for now (a surface pop-up); LEAVE just dismisses.
 *
 * DOM-based (like SettingsMenu) so it never touches the 480×270 buffer. Amber
 * retro-future chrome to match the HUD.
 */
import { PALETTE } from '../core/Constants.js';
import { KM_PER_UNIT } from '../data/CelestialGen.js';
import { plasticButton, windowFrame, hazardBar, bodyDiscPNG, panelChrome } from './Chrome.js';

const fmt = (n) => Math.round(n).toLocaleString('en-US');

export class CelestialInfo {
  /** @param {(body:object)=>void} onLand */
  constructor(onLand) {
    this.onLand = onLand;
    this.currentId = null;
    this.dismissedId = null; // don't re-pop the same body until you leave + return

    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    const border = PALETTE.HUD_AMBER[0];

    // Placement is squeezed from three sides and it took three tries to land it.
    // The right edge (its original home) is now the flight button column, so it
    // covered A/S, VIEW, STAND, FIRE. Dead centre clears the buttons but covers
    // the BODY you are approaching, which is worse. So: left-of-centre, below
    // the SENSORS panel and above VITALS — clear of both button gutters, both
    // canvas HUD blocks, and the body itself, which sits centre-right of frame.
    //
    // `top` is 25%, not 31%: at 31% a body carrying every stat field (a full
    // atmosphere string wraps the ATMOS row) grew the plate down over the VITALS
    // header. `max-height` is the belt-and-braces — content can scroll inside the
    // plate, but it can never push the plate into the HUD again.
    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'left:8.5%', 'top:25%',
      'max-height:40vh', 'overflow-y:auto',
      'z-index:25', 'display:none', 'width:min(286px,33vw)',
      `color:${amber}`, 'font:11px monospace', 'letter-spacing:0.05em',
      'padding:10px 12px', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none',
    ].join(';');

    // header: thumbnail of the body beside its name and class
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;gap:9px;margin-bottom:5px;';
    this.disc = document.createElement('div');
    this.disc.style.cssText = 'flex:0 0 36px;width:36px;height:36px;image-rendering:pixelated;'
      + 'background-size:100% 100%;background-repeat:no-repeat;';
    const heads = document.createElement('div');
    heads.style.cssText = 'min-width:0;';
    this.title = document.createElement('div');
    this.title.style.cssText = `font-size:13px;color:${amber};letter-spacing:0.12em;`;
    this.klass = document.createElement('div');
    this.klass.style.cssText = `font-size:9px;color:${amberLo};letter-spacing:0.14em;`;
    heads.append(this.title, this.klass);
    head.append(this.disc, heads);
    this.body = document.createElement('div');
    this.body.style.cssText = `font-size:9px;line-height:1.45;color:${amber};margin-bottom:5px;`;
    this.stats = document.createElement('div');
    this.stats.style.cssText = `font-size:9px;line-height:1.5;color:${amberLo};margin:5px 0 8px;`;

    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex;gap:10px;';
    this.landBtn = this._button('LAND', amber);
    this.leaveBtn = this._button('LEAVE', amberLo);
    btnRow.append(this.landBtn, this.leaveBtn);

    this.root.append(head, this.body, hazardBar('100%'), this.stats, btnRow);
    document.body.appendChild(this.root);
    /**
     * THE APPROACH WINDOW, framed (0.46.0, roadmap #85).
     *
     * It used to be a plate with corner brackets — the same treatment a tooltip
     * gets — while every other screen in the game had grown rails and cut
     * corners. It cannot take the whole viewport the way the hold manifest does,
     * because its entire job is to be read WHILE you look at the body it is
     * describing, so it gets `windowFrame`: the same bulkhead materials at panel
     * gauge, with the readout's own title cast into the top rail.
     */
    windowFrame(this.root, { seed: 67, rail: 8, title: 'NAV · APPROACH' });
    // Approach panel dismisses rather than just hiding, so it does not re-pop
    panelChrome(this.root, () => this._dismiss());

    const press = (el, fn) => {
      const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
      el.addEventListener('click', h);
      el.addEventListener('touchend', h, { passive: false });
    };
    press(this.landBtn, () => { if (this._body) this.onLand(this._body); this._dismiss(); });
    press(this.leaveBtn, () => this._dismiss());
  }

  _button(label, color) {
    const b = document.createElement('div');
    b.textContent = label;
    b.style.cssText = plasticButton(`flex:1;padding:7px 0;font-size:11px;`
      + `letter-spacing:0.16em;min-height:34px;color:${color};`);
    return b;
  }

  _dismiss() {
    this.dismissedId = this.currentId;
    this.root.style.display = 'none';
  }

  /**
   * Per-frame: pass the current approach ({body,dist}|null). Shows the panel
   * when you enter a new body's sphere, hides it when you leave.
   */
  update(approach) {
    const id = approach?.body?.id ?? null;
    if (id !== this.currentId) {
      this.currentId = id;
      if (id && id !== this.dismissedId) this._show(approach.body, approach.dist);
      else if (!id) this.root.style.display = 'none';
    }
    if (id === null) this.dismissedId = null; // left the sphere — allow re-pop later
  }

  _show(body, dist) {
    this._body = body;
    this.title.textContent = body.name;
    this.klass.textContent = (body.class ?? (body.station ? 'Station' : body.derelict ? 'Derelict' : 'Celestial body')).toUpperCase();
    // thumbnail keyed to what it actually is, seeded by name so a given world
    // always shows the same face
    const dk = body.station || body.derelict ? 'station' : (body.kind ?? 'rocky');
    this.disc.style.backgroundImage = `url("${bodyDiscPNG(dk, (body.name ?? '').length * 7 + 3)}")`;
    this.body.textContent = body.info ?? '';
    const rows = body.station || body.derelict
      ? [
        ['STATUS', body.station ? (body.refuel ? 'DOCKING OPEN' : 'NO RESPONSE') : 'DEAD SHIP'],
        ['SERVICES', body.refuel ? 'FUEL / RESUPPLY' : '—'],
        ['RANGE', `${fmt(dist * KM_PER_UNIT)} km`],
      ]
      : [
        ['RADIUS', body.realRadiusKm ? `${fmt(body.realRadiusKm)} km` : `${Math.round(body.radius)} u`],
        ['ORBIT', body.orbitAU != null ? `${body.orbitAU.toFixed(2)} AU` : '—'],
        ['ATMOS', body.atmosphere ?? '—'],
        ['GRAVITY', body.gravity ?? '—'],
        ['TEMP', body.temp ?? '—'],
        ['RANGE', `${fmt(dist * KM_PER_UNIT)} km`],
      ];
    this.stats.innerHTML = rows.map(([k, v]) => `<div style="display:flex;justify-content:space-between"><span>${k}</span><span>${v}</span></div>`).join('');
    this.landBtn.textContent = body.station ? 'DOCK' : body.derelict ? 'INSPECT' : body.kind === 'gas' ? 'SCAN' : 'LAND';
    this.root.style.display = 'block';
  }

  hide() { this.root.style.display = 'none'; this.currentId = null; }
}
