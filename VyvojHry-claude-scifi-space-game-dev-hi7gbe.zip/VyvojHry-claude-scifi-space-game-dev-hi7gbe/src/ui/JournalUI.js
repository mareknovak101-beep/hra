/**
 * JournalUI — the survey clipboard (Phase 7): WORK ORDERS (quests with live
 * progress) and RECOVERED LOGS (lore entries, locked until their trigger
 * fires). One pixel-art plate, two tabs, LOG chip in the left-edge column.
 */
import {
  plasticButton, plasticPanel, plasticRow, hazardBar, framePanel, showScrim, panelChrome,
} from './Chrome.js';
import { QUESTS } from '../gameplay/QuestSystem.js';
import { LORE } from '../data/LoreEntries.js';

export class JournalUI {
  /**
   * @param {import('../gameplay/QuestSystem.js').QuestSystem} quests
   * @param {Set<string>} unlockedLore live set of recovered lore ids
   * @param {import('../gameplay/FactionSystem.js').FactionSystem} [factions]
   * @param {import('../gameplay/Progression.js').Progression} [progression]
   */
  constructor(quests, unlockedLore, factions, progression, audio = null) {
    this.quests = quests;
    this.unlocked = unlockedLore;
    this.factions = factions;
    this.progression = progression;
    /** For the tape bed under a log being read — see `_tape`. */
    this.audio = audio;
    this._tapeStop = null;
    this.visible = false;
    this.tab = 'orders';
    this.openLog = null;

    this.root = document.createElement('div');
    this.root.style.cssText = plasticPanel([
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:30', 'display:none', 'width:min(460px,90vw)', 'max-height:80vh',
      'overflow-y:auto', 'padding:14px 16px', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none',
    ].join(';'));

    this.title = document.createElement('div');
    this.title.textContent = 'SURVEY JOURNAL';
    this.title.style.cssText = 'font-size:15px;letter-spacing:0.14em;color:#d0a060;margin-bottom:2px;';
    this.tabs = document.createElement('div');
    this.tabs.style.cssText = 'display:flex;gap:6px;margin:8px 0 10px;';
    this.list = document.createElement('div');
    this.root.append(this.title, hazardBar('60%'), this.tabs, this.list);
    document.body.appendChild(this.root);
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });
    framePanel(this.root, { seed: 23 });

    // LOG chip, fifth in the left column (WARP, BAG, SCAN, MENU, LOG)
    this.button = document.createElement('div');
    this.button.textContent = 'LOG';
    this.button.style.cssText = 'position:fixed;left:1.5%;top:8px;z-index:26;display:none;' + plasticButton();
    const toggle = (e) => { e.preventDefault(); e.stopPropagation(); this.toggle(); };
    this.button.addEventListener('click', toggle);
    this.button.addEventListener('touchend', toggle, { passive: false });
    document.body.appendChild(this.button);
  }

  setInGame(on) { this.button.style.display = on ? 'flex' : 'none'; if (!on) this.hide(); }

  _chip(label, active, fn) {
    const c = document.createElement('div');
    c.textContent = label;
    c.style.cssText = plasticButton('padding:4px 9px;font-size:9px;min-width:0;' +
      (active ? 'color:#d0a060;' : 'opacity:0.65;'));
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    c.addEventListener('click', h);
    c.addEventListener('touchend', h, { passive: false });
    return c;
  }

  _rebuild() {
    this.tabs.textContent = '';
    this.tabs.append(
      this._chip(`WORK ORDERS ${this.quests.openCount ? `(${this.quests.openCount})` : '✓'}`,
        this.tab === 'orders', () => { this.tab = 'orders'; this._rebuild(); }),
      this._chip(`RECOVERED LOGS (${this.unlocked.size}/${LORE.length})`,
        this.tab === 'logs', () => { this.tab = 'logs'; this.openLog = null; this._rebuild(); }),
    );
    if (this.factions) {
      this.tabs.append(this._chip('STANDINGS',
        this.tab === 'standings', () => { this.tab = 'standings'; this._rebuild(); }));
    }
    if (this.progression) {
      this.tabs.append(this._chip('SERVICE RECORD',
        this.tab === 'skills', () => { this.tab = 'skills'; this._rebuild(); }));
    }
    this.list.textContent = '';
    if (this.tab === 'orders') this._buildOrders();
    else if (this.tab === 'standings') this._buildStandings();
    else if (this.tab === 'skills') this._buildSkills();
    else this._buildLogs();
  }

  /**
   * THE SERVICE RECORD — five proficiencies, what each is at, and what the next
   * level buys.
   *
   * Quoting the per-level effect on every row is the whole design of this
   * panel. A progression system whose numbers live only in the source is a
   * progression system the player is guessing at, and guessing is not a
   * mechanic. The tally underneath is the other half: not a score, a record of
   * what this particular pilot has actually spent their commission doing.
   */
  _buildSkills() {
    for (const s of this.progression.status()) {
      const row = document.createElement('div');
      row.style.cssText = plasticRow('margin-bottom:6px;', { on: s.level > 0 });
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;gap:8px;align-items:baseline;';
      const name = document.createElement('div');
      name.textContent = s.name;
      name.style.cssText = 'font-size:11px;letter-spacing:0.12em;color:#d0a060;';
      const lv = document.createElement('div');
      lv.textContent = s.capped ? 'MASTERED' : `LEVEL ${s.level}`;
      lv.style.cssText = `font-size:10px;letter-spacing:0.14em;color:${s.capped ? '#8aa060' : '#c09050'};`;
      head.append(name, lv);

      // A pixel meter to the next level. Hard-edged blocks, not a rounded bar.
      const bar = document.createElement('div');
      bar.style.cssText = 'height:6px;background:#0c0c12;margin:5px 0 4px;'
        + 'box-shadow:inset 0 0 0 1px #3a2c1a;display:flex;';
      const fill = document.createElement('div');
      fill.style.cssText = `width:${Math.round(s.frac * 100)}%;height:100%;`
        + `background:${s.capped ? '#8aa060' : '#b08040'};`;
      bar.appendChild(fill);

      const blurb = document.createElement('div');
      blurb.textContent = s.blurb;
      blurb.style.cssText = 'font-size:9px;line-height:1.4;color:#8a6a3a;opacity:0.9;';
      const per = document.createElement('div');
      per.textContent = `PER LEVEL: ${s.perLevel.toUpperCase()}`;
      per.style.cssText = 'font-size:8px;letter-spacing:0.06em;color:#704a20;margin-top:3px;';
      const prog = document.createElement('div');
      prog.textContent = s.capped ? `${s.xp} XP — NOTHING LEFT TO LEARN`
        : `${s.into} / ${s.need} TO LEVEL ${s.level + 1}`;
      prog.style.cssText = 'font-size:8px;letter-spacing:0.08em;color:#5a4830;margin-top:2px;';
      row.append(head, bar, blurb, per, prog);

      if (s.record.length) {
        const rec = document.createElement('div');
        rec.textContent = s.record.map(([k, n]) => `${k} \u00d7${n}`).join('  ·  ');
        rec.style.cssText = 'font-size:8px;letter-spacing:0.06em;color:#6a5230;margin-top:4px;opacity:0.85;';
        row.appendChild(rec);
      }
      this.list.appendChild(row);
    }
  }

  _buildStandings() {
    for (const { faction: f, value, tier } of this.factions.rows()) {
      const row = document.createElement('div');
      row.style.cssText = plasticRow('margin-bottom:5px;');
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;gap:8px;align-items:baseline;';
      const name = document.createElement('div');
      name.textContent = f.name;
      name.style.cssText = 'font-size:11px;letter-spacing:0.08em;color:#c09050;';
      const std = document.createElement('div');
      std.textContent = tier.name;
      std.style.cssText = `font-size:10px;letter-spacing:0.14em;color:${tier.col};`;
      head.append(name, std);
      // a pixel meter: −100…+100 with a centre tick, filled to the value
      const bar = document.createElement('div');
      bar.style.cssText = 'position:relative;height:8px;margin:5px 0 3px;background:#0c0c12;border:1px solid #2a2a36;overflow:hidden;';
      const fill = document.createElement('div');
      const pct = (value + 100) / 200 * 100;
      const from = value >= 0 ? 50 : pct;
      fill.style.cssText = `position:absolute;top:0;height:100%;left:${from}%;width:${Math.abs(pct - 50)}%;background:${tier.col};`;
      const mid = document.createElement('div');
      mid.style.cssText = 'position:absolute;top:0;left:50%;width:1px;height:100%;background:#5a4830;';
      bar.append(fill, mid);
      const blurb = document.createElement('div');
      blurb.textContent = f.blurb;
      blurb.style.cssText = 'font-size:10px;color:#8a7050;line-height:1.45;';
      row.append(head, bar, blurb);
      this.list.appendChild(row);
    }
  }

  _buildOrders() {
    for (const { quest: q, p, done } of this.quests.rows()) {
      const row = document.createElement('div');
      row.style.cssText = plasticRow('margin-bottom:5px;', { on: done, dead: false });
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;gap:8px;';
      const name = document.createElement('div');
      name.textContent = (done ? '■ ' : '□ ') + q.name;
      name.style.cssText = `font-size:11px;letter-spacing:0.1em;color:${done ? '#8a6030' : '#d0a060'};`;
      const prog = document.createElement('div');
      prog.textContent = done ? 'PAID' : `${Math.min(p, q.n)}/${q.n}`;
      prog.style.cssText = 'font-size:10px;color:#b08040;';
      head.append(name, prog);
      const desc = document.createElement('div');
      desc.textContent = q.desc;
      desc.style.cssText = 'font-size:10px;color:#8a7050;line-height:1.45;margin-top:2px;';
      const pay = document.createElement('div');
      pay.textContent = `REWARD: ${q.reward.credits ?? 0} CR${(q.reward.items ?? []).length ? ' + MATERIEL' : ''}`;
      pay.style.cssText = 'font-size:9px;color:#704a20;margin-top:2px;letter-spacing:0.1em;';
      row.append(head, desc, pay);
      this.list.appendChild(row);
    }
  }

  /**
   * A LOG PLAYING BACK.
   *
   * `context/06` §3 asks for a telephone-band noise bed under any audio-log
   * playback — a degraded recording without an audio file. It is not a sound
   * effect on a button: it starts when a log is opened and stops when the log
   * is closed or the journal is, because the point is that you are *listening
   * to something* while you read it.
   */
  _tape(on) {
    if (!on) { this._tapeStop?.(); this._tapeStop = null; return; }
    if (this._tapeStop) return;
    // 0 = run until stopped; the closer below is what ends it.
    this._tapeStop = this.audio?.playTapeLogCrackle?.(0) ?? null;
  }

  _buildLogs() {
    this._tape(!!this.openLog);
    if (this.openLog) {
      const e = LORE.find((l) => l.id === this.openLog);
      const back = this._chip('← BACK TO LOGS', false, () => { this.openLog = null; this._rebuild(); });
      back.style.marginBottom = '8px';
      const t = document.createElement('div');
      t.textContent = e.title;
      t.style.cssText = 'font-size:12px;color:#d0a060;letter-spacing:0.12em;';
      const a = document.createElement('div');
      a.textContent = `— ${e.author}`;
      a.style.cssText = 'font-size:9px;color:#704a20;margin:2px 0 8px;letter-spacing:0.12em;';
      const b = document.createElement('div');
      b.textContent = e.body;
      b.style.cssText = 'font-size:11px;color:#b09060;line-height:1.6;white-space:pre-wrap;';
      this.list.append(back, t, a, b);
      return;
    }
    for (const e of LORE) {
      const got = this.unlocked.has(e.id);
      const row = document.createElement('div');
      row.style.cssText = plasticRow(
        'display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:5px;',
        { dead: !got });
      const t = document.createElement('div');
      t.textContent = got ? e.title : 'UNRECOVERED ENTRY';
      t.style.cssText = `font-size:11px;letter-spacing:0.08em;color:${got ? '#c09050' : '#5a4830'};`;
      const a = document.createElement('div');
      a.textContent = got ? e.author : '· · ·';
      a.style.cssText = 'font-size:9px;color:#704a20;';
      row.append(t, a);
      if (got) {
        const open = (ev) => { ev.preventDefault(); ev.stopPropagation(); this.openLog = e.id; this._rebuild(); };
        row.addEventListener('click', open);
        row.addEventListener('touchend', open, { passive: false });
      }
      this.list.appendChild(row);
    }
  }

  show() { if (!this.visible) showScrim(true); this.visible = true; this._rebuild(); this.root.style.display = 'block'; }
  hide() {
    // Closing the journal mid-log has to stop the tape; otherwise the bed runs
    // under the corridor for the rest of the session.
    this._tape(false);
    if (this.visible) showScrim(false);
    this.visible = false;
    this.root.style.display = 'none';
  }
  toggle() { this.visible ? this.hide() : this.show(); }
}
