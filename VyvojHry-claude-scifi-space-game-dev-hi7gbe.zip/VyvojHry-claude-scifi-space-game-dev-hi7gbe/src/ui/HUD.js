/**
 * HUD — compact helmet/console display. Amber-only chrome (context/05 §1) with
 * a faked 3D bevel on every panel and a recessed, segmented look on the bars so
 * it reads as a physical console, not flat overlay. Every bar is driven live by
 * ShipSystems: health, oxygen, shield, hull, fuel, power, heat, radiation, plus
 * a surroundings/sensors readout. Helmet-glass overlay draws underneath.
 */
import { RENDER, PALETTE } from '../core/Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';
import { FONT_FACES } from '../rendering/PixelFont.js';
import { Quat, clamp } from '../utils/MathUtils.js';
import { Settings } from '../core/Settings.js';

// UI grid, not the scene buffer — every coordinate below is hand-placed on the
// 480×270 chrome grid and must stay there when the scene renders 2–4× finer.
const W = RENDER.UI_WIDTH;
const H = RENDER.UI_HEIGHT;
const A9 = FONT_FACES.AMBER9;

export class HUD {
  /**
   * @param {import('../rendering/PixelRenderer.js').PixelRenderer} pix
   * @param {import('../rendering/PixelFont.js').PixelFont} font
   * @param {WebGLTexture} fontTexture
   * @param {WebGLTexture} overlayTexture helmet glass
   */
  constructor(pix, font, fontTexture, overlayTexture) {
    this.pix = pix;
    this.font = font;
    this.fontTexture = fontTexture;
    this.overlayTexture = overlayTexture;
    /**
     * Animation clock in REAL seconds, advanced by tick() from the engine's frame
     * delta. It used to be `+= 1/60` inside render(), which is only correct on a
     * display that refreshes at exactly 60Hz: every sweep, blink and scroll in
     * this HUD ran at double speed on a 120Hz panel and half speed at 30fps.
     */
    this.time = 0;
    /**
     * Virtual pixels reserved down each side for the on-screen controls. The
     * touch buttons live in fixed viewport gutters, and every edge-anchored HUD
     * panel used to sit under them — VITALS behind the throttle column, SHIP
     * behind FIRE, the NAV scope behind BRAKE. Set by main.js when touch turns
     * on; 0 on a keyboard, where the edges are free.
     */
    this.inset = 0;
    /**
     * Command-bar hit rects on the UI grid, rebuilt every frame by
     * `_commandBar`. main.js maps pointer events into this space and calls
     * `hitTest`; nothing in here touches the DOM.
     * @type {Array<{id:string,x:number,y:number,w:number,h:number}>}
     */
    this.buttons = [];
    /**
     * Hit rects from blocks that draw BEFORE the command bar and so cannot push
     * into `buttons` directly — the bar clears that array when it runs. Folded
     * in at the end of `_commandBar` and emptied every frame.
     * @type {Array<{id:string,x:number,y:number,w:number,h:number}>}
     */
    this._pendingButtons = [];
    this._press = null;
    this._pressT = -9;
    /**
     * Optional `(id) => boolean` supplied by main.js: is this command currently
     * ACTIVE (scanner raised, weapon drawn, hold open)? The bar cannot know —
     * the state lives in five different systems — so it asks.
     */
    this._litButton = null;
    /** Cap a single advance so a long stall (tab switch, warp texture bake)
     * doesn't fast-forward every sweep and blink through several cycles. */
    this._maxTick = 0.1;

    const f = hexToRgbf;
    this.C = {
      amber: f(PALETTE.HUD_AMBER[1]),
      amberHi: f(PALETTE.HUD_AMBER[2]),
      amberLo: f(PALETTE.HUD_AMBER[0]),
      sec: f(PALETTE.HUD_SECONDARY[0]),
      border: f(PALETTE.HUD_BORDER[0]),
      borderHi: f(PALETTE.HUD_BORDER[1]),
      bg: f(PALETTE.HUD_PANEL_BG[0]),
      bgLo: f(PALETTE.SHADOW_BLACK[0]),
      health: f(PALETTE.HUD_HEALTH[1]),
      o2: f(PALETTE.HUD_O2[1]),
      shield: f('#5a90c0'),
      fuel: f(PALETTE.HUD_AMBER[1]),
      power: f(PALETTE.HUD_AMBER[2]),
      heat: f(PALETTE.HUD_ALERT[1]),
      rad: f('#c0a040'),
      hull: f('#8a9070'),
      alert: f(PALETTE.HUD_ALERT[1]),
      white: [1, 1, 1],
    };
  }

  // -- primitives: a raised, beveled panel + a recessed segmented bar --------

  /**
   * Rounded beveled panel: dark fill with 2px cut corners, lit top/left and
   * shadowed bottom/right edges following the rounded outline, corner rivets.
   * The corner cut softens the boxy console look (retro-future, less squared).
   */
  /**
   * A HUD panel, as a piece of machined hardware rather than a rounded box.
   *
   * Layers, outermost first — each one is a real thing on a real instrument
   * bezel, and together they are what stops the readouts reading as text
   * floating on glass:
   *
   *   1. CHAMFERED CORNERS. The 45-degree cut is the single strongest "milled
   *      plate" signal at this scale and it costs four pixels.
   *   2. A lit top/left and shadowed bottom/right edge, so the plate has a
   *      direction the light is coming from.
   *   3. An INNER shadow one pixel in from the top edge — the recess under the
   *      bezel lip. This is the layer that gives the panel depth rather than
   *      just an outline.
   *   4. CORNER BRACKETS: two-pixel L-marks inset from each corner, the way an
   *      instrument face is screwed down at its corners.
   *   5. RIVETS on anything wide enough to carry them, at the mid-span where a
   *      real panel needs its extra fixing.
   */
  _panel(x, y, w, h, o = {}) {
    const { pix, C } = this;
    const r = 2; // corner chamfer

    // (0) CAST SHADOW, one pixel down and right, drawn before the plate itself.
    // Bevelled edges alone only prove which way the light comes from; a shadow
    // falling on what's BEHIND the plate is what proves the plate stands off it.
    // This is the single cheapest depth cue on the whole HUD.
    pix.rect(x + 2, y + h, w - 2, 1, [0, 0, 0, 0.55]);
    pix.rect(x + w, y + 2, 1, h - 1, [0, 0, 0, 0.45]);

    const fill = [C.bg[0], C.bg[1], C.bg[2], 0.86];
    pix.rect(x, y + r, w, h - 2 * r, fill);
    pix.rect(x + r, y, w - 2 * r, r, fill);
    pix.rect(x + r, y + h - r, w - 2 * r, r, fill);

    const hi = [C.borderHi[0], C.borderHi[1], C.borderHi[2], 1];
    const lo = [C.bgLo[0], C.bgLo[1], C.bgLo[2], 1];
    const mid = [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.45];

    // (1) TWO-STEP FACE. The plate is lit from the top-left, so its lower
    // portion sits in its own shade with a machined step between the two. Two
    // flat levels and a hard rule — 2-bit shading, not a gradient (the art
    // direction bans those outright, and a step reads as a formed panel
    // anyway, which a smooth ramp never does).
    const step = y + Math.max(6, Math.round(h * 0.44));
    if (h >= 14) {
      pix.rect(x + 1, step + 1, w - 2, h - (step - y) - 2, [0, 0, 0, 0.2]);
      pix.rect(x + 2, step, w - 4, 1, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.16]);
    }

    pix.rect(x + r, y, w - 2 * r, 1, hi);          // top, lit
    pix.rect(x, y + r, 1, h - 2 * r, hi);          // left, lit
    pix.rect(x + r, y + h - 1, w - 2 * r, 1, lo);  // bottom, shadowed
    pix.rect(x + w - 1, y + r, 1, h - 2 * r, lo);  // right, shadowed
    // the chamfer pixels themselves
    pix.rect(x + 1, y + 1, 1, 1, hi);
    pix.rect(x + w - 2, y + 1, 1, 1, hi);
    pix.rect(x + 1, y + h - 2, 1, 1, lo);
    pix.rect(x + w - 2, y + h - 2, 1, 1, lo);

    // (3) recess under the lip — the depth cue
    pix.rect(x + 2, y + 1, w - 4, 1, [0, 0, 0, 0.5]);
    pix.rect(x + 1, y + 2, 1, h - 4, [0, 0, 0, 0.35]);

    // (4) corner brackets
    const br = (bx, by, dx, dy) => {
      pix.rect(bx, by, 2 * dx > 0 ? 2 : 1, 1, mid);
      pix.rect(bx, by, 1, 2, mid);
    };
    br(x + 2, y + 2, 1, 1);
    br(x + w - 4, y + 2, 1, 1);
    br(x + 2, y + h - 4, 1, 1);
    br(x + w - 4, y + h - 4, 1, 1);

    // (5) mid-span rivets on a wide plate
    if (w >= 72) {
      const cx = x + (w >> 1);
      pix.rect(cx, y + 1, 1, 1, mid);
      pix.rect(cx, y + h - 2, 1, 1, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.9]);
    }

    // (6) FIXINGS. A real instrument face is bolted down, and the bolt is the
    // detail the eye uses to size everything else on the plate. Suppressible
    // (`o.plain`) for the little inline plates — a 13px strip with four screws
    // in it is all screw.
    if (!o.plain && w >= 40 && h >= 20) {
      this._screw(x + 3, y + 4); this._screw(x + w - 6, y + 4);
      this._screw(x + 3, y + h - 7); this._screw(x + w - 6, y + h - 7);
    }
    // (7) EDGE INDEX TICKS down the right flank — the graduation marks a
    // machined bezel carries so a technician can talk about "the third notch".
    if (!o.plain && h >= 34) {
      for (let ty = y + 8; ty < y + h - 8; ty += 5) {
        pix.rect(x + w - 3, ty, ((ty - y) % 15 < 5) ? 2 : 1, 1,
          [C.sec[0], C.sec[1], C.sec[2], 0.3]);
      }
    }
  }

  /**
   * A 3×3 screw head: lit top-left, shadowed bottom-right, dark slot across the
   * middle. Three pixels is enough to read as a fastener at this scale, and it
   * is the detail that makes a plate look bolted rather than drawn.
   */
  _screw(x, y) {
    const { pix, C } = this;
    pix.rect(x, y, 3, 3, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.9]);
    pix.rect(x, y, 2, 1, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.55]);
    pix.rect(x + 2, y + 1, 1, 2, [0, 0, 0, 0.7]);
    pix.rect(x, y + 1, 3, 1, [C.sec[0], C.sec[1], C.sec[2], 0.4]);
  }

  /**
   * Diagonal hazard chevrons — the amber-and-black stripe every piece of
   * industrial hardware in this world wears. Purely decorative, and that is the
   * point: the chrome should look like it belongs to a working ship, and a
   * working ship is covered in warning paint.
   */
  _hazard(x, y, w, h, alpha = 0.4) {
    const { pix, C } = this;
    pix.rect(x, y, w, h, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.8]);
    const c = [C.amberLo[0], C.amberLo[1], C.amberLo[2], alpha];
    for (let i = -h; i < w; i += 4) {
      for (let k = 0; k < h; k++) {
        const sx = x + i + k;
        if (sx >= x && sx < x + w) pix.rect(sx, y + k, 2, 1, c);
      }
    }
  }

  /**
   * Ribbed cooling grille: alternating lit and shadowed 1px slats. Reads as a
   * physical vent cut into the bezel and costs one rect per slat.
   */
  _grille(x, y, w, h) {
    const { pix, C } = this;
    pix.rect(x, y, w, h, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.85]);
    for (let i = 0; i < h; i += 2) {
      pix.rect(x + 1, y + i, w - 2, 1, [0, 0, 0, 0.6]);
      if (i + 1 < h) {
        pix.rect(x + 1, y + i + 1, w - 2, 1,
          [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.18]);
      }
    }
  }

  /**
   * An engraved header: the label, a rule that runs from it to the plate's right
   * edge, and a lit pixel under the rule so the engraving has a depth. Replaces
   * a bare `_text` title — a legend on a real panel is stamped into the metal,
   * and the rule is what carries the eye across to the readouts.
   */
  _titlePlate(x, y, w, label, color = this.C.amberLo) {
    const { pix, font, C } = this;
    this._text(x, y, label, color, 0.95);
    const lw = font.measure(A9, label);
    const rx = x + lw + 3, rw = w - lw - 3;
    if (rw > 2) {
      pix.rect(rx, y + 3, rw, 1, [0, 0, 0, 0.6]);
      pix.rect(rx, y + 4, rw, 1, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.3]);
      // end cap, so the rule terminates in hardware rather than fading out
      pix.rect(x + w - 2, y + 1, 2, 4, [C.sec[0], C.sec[1], C.sec[2], 0.4]);
    }
  }


  _text(x, y, text, color = this.C.amber, alpha = 1) {
    this.pix.text(this.font, A9, x, y, text, [color[0], color[1], color[2], alpha]);
  }

  /**
   * Recessed segmented gauge with a label and value.
   * @param {number} frac 0..1
   * @param {number[]} color bar colour
   * @param {object} o { rtl, warn (pulse if frac<this), value }
   */
  _bar(x, y, w, label, frac, color, o = {}) {
    const { pix, C } = this;
    frac = Math.max(0, Math.min(1, frac));
    const low = o.warn != null && frac < o.warn;
    const pulse = low ? 0.55 + 0.45 * Math.sin(this.time * 6) : 1;
    // three zones: label · bar · value. 24 was exactly the width of a 4-glyph
    // label, so the bar's recessed groove ate the last pixel column of FOOD,
    // HEAT and RAD — they rendered as "FOOl", "HEAl".
    const labelW = 28, valueW = 22;
    this._text(x, y, label, low ? C.alert : C.sec, low ? pulse : 0.95);
    // 5px tall rather than 6: one pixel off every gauge is what buys the row
    // pitch to drop from 10 to 8, which is where the "smaller HUD" comes from.
    const bx = x + labelW, bw = w - labelW - valueW, by = y + 1, bh = 5;
    // recessed groove: dark inset + top-left shadow
    pix.rect(bx, by, bw, bh, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.95]);
    pix.rect(bx, by, bw, 1, [0, 0, 0, 0.8]);
    pix.rect(bx, by, 1, bh, [0, 0, 0, 0.8]);
    // ...and the LIT bottom-right lip that was missing. A groove needs both
    // sides: with only the top-left shadow the bar read as a dark rectangle
    // with a stain on it rather than a channel milled into the plate.
    pix.rect(bx, by + bh - 1, bw, 1, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.22]);
    pix.rect(bx + bw - 1, by, 1, bh, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.22]);
    // redline: the stretch of channel below the warn threshold, marked on the
    // hardware so the pilot knows where the limit is before the needle is there
    if (o.warn) {
      const rw = Math.max(1, Math.round((bw - 2) * o.warn));
      const rx2 = o.rtl ? bx + bw - 1 - rw : bx + 1;
      pix.rect(rx2, by + bh - 1, rw, 1, [C.alert[0], C.alert[1], C.alert[2], 0.5]);
    }
    const fill = Math.round((bw - 2) * frac);
    const fx = o.rtl ? bx + 1 + (bw - 2 - fill) : bx + 1;
    if (fill > 0) {
      pix.rect(fx, by + 1, fill, bh - 2, [color[0] * pulse, color[1] * pulse, color[2] * pulse, 1]);
      pix.rect(fx, by + 1, fill, 1, [Math.min(1, color[0] * 1.5), Math.min(1, color[1] * 1.5), Math.min(1, color[2] * 1.5), 1]);
      const cx = o.rtl ? fx : fx + fill - 1;
      pix.rect(cx, by + 1, 1, bh - 2, [C.white[0], C.white[1], C.white[2], 0.9]);
    }
    // segment ticks (recessed console gauge)
    for (let t = bx + 6; t < bx + bw - 2; t += 6) pix.rect(t, by + 1, 1, bh - 2, [0, 0, 0, 0.35]);
    if (o.value !== undefined) {
      const vs = String(o.value);
      const vw = this.font.measure(A9, vs);
      this._text(x + w - Math.min(vw, valueW), y, vs, low ? C.alert : C.amber, low ? pulse : 0.95);
    }
  }

  /**
   * THE COMMAND BAR — the row of keys along the bottom of the glass.
   *
   * These are HUD buttons, not a touch overlay. WARP, SCAN, the weapon select,
   * REPAIR and the two panel openers used to exist twice over: once as DOM chips
   * floating on top of the canvas, and again as keys in the touch gutters. That
   * is what made the frame feel crowded — the same five actions were on screen
   * in two places, in two visual languages, neither of which was the HUD's.
   *
   * Now there is one row, drawn in the HUD's own machined-plate chrome, on the
   * 480x270 grid, in both input modes. Every button prints its KEYBIND, so on a
   * keyboard the bar is a legend you can read at a glance rather than dead
   * decoration, and on a touch screen it is the button itself.
   *
   * Registers hit rects into `this.buttons` for main.js to test pointer events
   * against; nothing here knows what a DOM event is.
   */
  _commandBar(mode, extras) {
    const { pix, font, C } = this;
    const defs = mode === 'flight'
      ? [['warp', 'WARP', 'J'], ['scan', 'SCAN', 'N'], ['lock', 'LOCK', 'T'],
        ['wpn', 'WPN', 'C'], ['repair', 'RPR', 'H'], ['hold', 'HOLD', 'I'],
        ['log', 'LOG', 'L']]
      : [['scan', 'SCAN', 'N'], ['lamp', 'LAMP', 'G'], ['gun', 'ARM', 'B'],
        ['hold', 'HOLD', 'I'], ['log', 'LOG', 'L']];
    this.buttons.length = 0;
    // TALLER ON TOUCH. 15 rows of a 270-row buffer is 22 CSS pixels on an
    // 844x390 phone — half the context/07 touch floor. There is no size that is
    // both compact on a monitor and 44px on a phone, so the bar picks: 15 with a
    // mouse, 26 under a thumb (46 CSS px at that scale), plus a 5px hit pad. The
    // inset is already the signal that the touch layer is up.
    const touch = this.inset > 0;
    const bw = touch ? 46 : 40, bh = touch ? 26 : 15, gap = 3;
    const total = defs.length * bw + (defs.length - 1) * gap;
    let x = Math.round((W - total) / 2);
    const y = H - bh - 2;
    // seat rail the keys are set into, so the row reads as one machined strip
    pix.rect(x - 4, y - 2, total + 8, bh + 4, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.9]);
    pix.rect(x - 4, y - 2, total + 8, 1, [0, 0, 0, 0.8]);
    for (const [id, label, key] of defs) {
      const lit = this._litButton?.(id) ?? false;
      const held = this._press === id && this.time - this._pressT < 0.16;
      // a pressed key sinks: the bevel inverts and the face darkens
      const face = held ? 0.55 : lit ? 1.25 : 1;
      pix.rect(x, y, bw, bh, [C.bg[0] * face, C.bg[1] * face, C.bg[2] * face, 0.95]);
      pix.rect(x, y, bw, 1, held ? [0, 0, 0, 0.7]
        : [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.9]);
      pix.rect(x, y, 1, bh, held ? [0, 0, 0, 0.6]
        : [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.6]);
      pix.rect(x, y + bh - 1, bw, 1, held
        ? [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.5] : [0, 0, 0, 0.75]);
      pix.rect(x + bw - 1, y, 1, bh, [0, 0, 0, 0.6]);
      // lit keys carry a status pip down the leading edge
      if (lit) pix.rect(x + 1, y + 3, 1, bh - 6, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 1]);
      const lw = font.measure(A9, label);
      const col = lit ? C.amberHi : C.amber;
      const ty = y + Math.round((bh - 7) / 2) + (held ? 1 : 0);
      this._text(x + Math.round((bw - lw) / 2) - 3, ty, label, col, held ? 1 : 0.92);
      // the keybind, small and dim in the corner — a legend on a keyboard, and
      // harmless on a touch screen where nobody will look for it
      this._text(x + bw - 6, ty, key, C.sec, 0.6);
      // 5px of vertical pad on the HIT rect only — the key stays visually
      // compact while the target clears the floor.
      this.buttons.push({ id, x, y: y - 5, w: bw, h: bh + 7 });
      x += bw + gap;
    }
    // Hit rects registered EARLIER in the frame by blocks that draw before the
    // bar (the hull-cam zoom pad). They cannot push straight into `this.buttons`
    // because the line above wipes it, and they must not be tested against a
    // frame in which they were not drawn — so they are collected per frame and
    // folded in here, once, at the end.
    for (const b of this._pendingButtons) this.buttons.push(b);
    this._pendingButtons.length = 0;
  }

  /**
   * HULL CAM ZOOM — two small keys that dolly the external chase camera in and
   * out, plus the scale they are moving.
   *
   * Deliberately NOT two more entries in the command bar. That row is a list of
   * things you DO, one press each, and it is already seven wide in flight; two
   * more keys would have pushed it past the readable width of a 480px grid and
   * left two dead buttons on screen for the whole of the time spent in the seat,
   * where there is no chase camera to zoom. So the pad appears with the hull cam
   * and vanishes with it.
   *
   * It lives in the right instrument column, under the target block and above
   * the SHIP plate — the one band of that column nothing else claims — and is
   * inset like every other edge-anchored block so it never lands under the touch
   * gutters. The keys are small, as asked; the HIT rects are padded well past
   * them so a thumb still clears the touch floor.
   *
   * `this.buttons` is cleared by `_commandBar`, which runs LAST in `render`, so
   * this must register AFTER it or the entries are thrown away. It does — the
   * call site is the flight branch, and the bar re-adds its own rows on top.
   *
   * @param {number} x  left edge of the right instrument column
   * @param {number} y  top edge
   * @param {number} w  column width
   * @param {{zoom:number, min:number, max:number}} chase live dolly state
   */
  _zoomPad(x, y, w, chase) {
    const { pix, font, C } = this;
    this._panel(x, y, w, 20, { plain: true });
    // "CAM", not "HULL CAM". AMBER9 advances 7px per glyph, the column is 92
    // wide, and two keys plus a four-glyph percentage already claim 60 of it —
    // the long label ran straight through the number. The pad only exists while
    // the hull cam is out and the frame prints EXTERNAL HULL CAM in the centre
    // when it comes on, so the three letters are a reminder, not the whole
    // explanation.
    this._text(x + 4, y + 7, 'CAM', C.sec, 0.75);
    // Scale, printed as a magnification rather than a raw distance: zoom 1 is the
    // framing the cam pulls out to on its own, so 100% is "as designed" and the
    // number says how much closer or further than that you have pushed it.
    const pct = `${Math.round(100 / chase.zoom)}%`;
    const pw = font.measure(A9, pct);
    // Key WIDTH is fixed at 14 in both input modes — the column cannot spare the
    // extra four pixels a touch-sized pair would want, and the hit rect below is
    // what actually has to clear the touch floor, not the drawn key.
    const kw = 14, kh = 14, gap = 2;
    const kx0 = x + w - 4 - (kw * 2 + gap);
    this._text(kx0 - pw - 5, y + 7, pct, C.amber, 0.9);
    for (const [id, glyph, at] of [['zoomin', '+', 0], ['zoomout', '-', 1]]) {
      // A key at the end of its travel greys out, so a control that has stopped
      // moving the camera is visibly a control at its stop rather than a bug.
      const dead = at === 0 ? chase.zoom <= chase.min + 1e-3 : chase.zoom >= chase.max - 1e-3;
      const held = this._press === id && this.time - this._pressT < 0.16;
      const face = held ? 0.55 : dead ? 0.72 : 1;
      const kx = kx0 + at * (kw + gap), ky = y + 3;
      pix.rect(kx, ky, kw, kh, [C.bg[0] * face, C.bg[1] * face, C.bg[2] * face, 0.95]);
      pix.rect(kx, ky, kw, 1, held ? [0, 0, 0, 0.7]
        : [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.9]);
      pix.rect(kx, ky, 1, kh, held ? [0, 0, 0, 0.6]
        : [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.6]);
      pix.rect(kx, ky + kh - 1, kw, 1, held
        ? [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.5] : [0, 0, 0, 0.75]);
      pix.rect(kx + kw - 1, ky, 1, kh, [0, 0, 0, 0.6]);
      const gw = font.measure(A9, glyph);
      this._text(kx + Math.round((kw - gw) / 2) - 3, ky + Math.round((kh - 7) / 2) + (held ? 1 : 0),
        glyph, dead ? C.sec : C.amber, dead ? 0.55 : held ? 1 : 0.92);
      // Pad the HIT rect so the key stays small while the target clears the
      // 44 CSS px floor — but pad OUTWARD only. Padding both sides made the two
      // rects overlap by 10px across the gap, and `hitTest` returns the first
      // match, so a press aimed at the right-hand key landed on the left one.
      this._pendingButtons.push({
        id, y: ky - 7, h: kh + 14,
        x: kx - (at === 0 ? 7 : 1), w: kw + 8,
      });
    }
  }

  /**
   * Map a point already expressed on the 480x270 UI grid to a command-bar id.
   * @returns {string|null}
   */
  hitTest(ux, uy) {
    for (const b of this.buttons) {
      if (ux >= b.x && ux < b.x + b.w && uy >= b.y && uy < b.y + b.h) return b.id;
    }
    return null;
  }

  /** Flash a key as pressed. Purely visual; main.js does the actual work. */
  flashButton(id) { this._press = id; this._pressT = this.time; }

  /** Small labeled numeric readout box (no bar). */
  /** Advance the animation clock by one real frame. Called from Engine.frame. */
  tick(frameDt) {
    this._dt = Math.min(frameDt, this._maxTick);
    this.time += this._dt;
    // Directional damage marks age on the frame clock, not the fixed step: they
    // are a visual, and a mark that persisted for a fixed number of SIM steps
    // would linger longer on a slow machine than on a fast one.
    const marks = this._hurt;
    if (marks) {
      for (let i = marks.length - 1; i >= 0; i--) {
        marks[i].t -= this._dt * 0.85;
        if (marks[i].t <= 0) marks.splice(i, 1);
      }
    }
  }

  /**
   * SOMETHING HIT YOU, AND THIS IS WHERE IT CAME FROM.
   *
   * Added with the boarders (0.55.0), and it is the fix for a genuine fault in
   * the fight they created: a Keth trooper's bolt is a hitscan, so being shot
   * at from behind was a number going down with nothing on the glass to say
   * why, in a corridor that is unlit and where the thing shooting you is the
   * colour of the wall. A survival game may absolutely kill you from off
   * screen; it may not do so without telling you which way to turn.
   *
   * Takes a WORLD direction from you to whatever hit you. The arc is resolved
   * against the camera's yaw at draw time rather than baked here, so it stays
   * pinned to the attacker while you spin to face it — which is the entire
   * point of the thing.
   *
   * @param {number[]} dir world-space direction from the player toward the source
   */
  hitFrom(dir) {
    if (!dir) return;
    /**
     * The bearing has to be in the CAMERA's yaw convention, not the obvious
     * one. `forwardFromAngles` builds forward as (−sin yaw, ·, −cos yaw), so
     * the yaw that looks along `dir` is atan2(−x, −z). The first cut used
     * atan2(x, z), which is off by π — and the mark for a shooter standing
     * directly in front of you appeared at the BOTTOM of the visor, telling you
     * to turn around and walk away from it.
     *
     * Worth noting how that survived a test: the probe only checked that the
     * arc swung by π when the player span by π, which a mark that is wrong by a
     * constant π passes perfectly. A relative check cannot catch an absolute
     * error, and this is the second convention bug this session that a
     * self-consistent test waved through.
     */
    const a = Math.atan2(-dir[0], -dir[2]);
    this._hurt ??= [];
    // Fold marks that arrive from nearly the same bearing into one, refreshed —
    // an automatic weapon should read as sustained fire from one direction, not
    // as a stack of six identical wedges.
    for (const m of this._hurt) {
      let d = a - m.a;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      if (Math.abs(d) < 0.35) { m.t = 1; return; }
    }
    if (this._hurt.length > 5) this._hurt.shift();
    this._hurt.push({ a, t: 1 });
  }

  /**
   * The marks themselves: a thick arc at the edge of the visor, at the bearing
   * of whatever hit you, in the alert red the HUD already uses for damage.
   *
   * Drawn as a run of short radial ticks rather than a smooth curve, because
   * everything else on this glass is pixel rects on a 480×270 grid and a
   * carefully antialiased arc would be the one thing on screen that is not.
   */
  _hurtArcs(yaw) {
    const marks = this._hurt;
    if (!marks?.length) return;
    const { pix, C } = this;
    const cx = W / 2, cy = H / 2;
    const rx = W * 0.40, ry = H * 0.40;
    for (const m of marks) {
      // Where the source sits relative to where you are looking. Screen-forward
      // is up on this dial, so a hit from dead ahead sits at the top.
      let rel = m.a - yaw;
      while (rel > Math.PI) rel -= Math.PI * 2;
      while (rel < -Math.PI) rel += Math.PI * 2;
      const t = m.t;
      // Fatter and brighter when fresh; the arc also narrows as it fades, so a
      // stale mark reads as a memory rather than as live fire.
      const span = 0.30 + 0.16 * t;
      const steps = 9;
      for (let i = 0; i <= steps; i++) {
        const f = i / steps;
        const ang = rel - span / 2 + span * f;
        // taper the ends so the arc has a shape rather than being a bar
        const edge = 1 - Math.abs(f - 0.5) * 2;
        const len = Math.round(2 + 5 * edge * t);
        /**
         * MINUS the sine, and this is the second half of the convention.
         * Dead-ahead and dead-behind land correctly with either sign, so the
         * horizontal was mirrored — a shooter on your right was marked on your
         * left, which is worse than no mark at all. Measured, not reasoned:
         * with the camera facing +z the player's right hand is −x, and only
         * this sign puts that source on the right of the glass.
         */
        const sx = cx - Math.sin(ang) * rx;
        const sy = cy - Math.cos(ang) * ry;
        const a = Math.min(1, t * 0.9) * (0.35 + 0.65 * edge);
        // The tick points INWARD, and the inward direction is derived from the
        // centre rather than from the angle — one less place for a sign to be
        // wrong, and it stays correct if the ellipse is ever retuned.
        const ix = cx - sx, iy = cy - sy;
        const il = Math.hypot(ix, iy) || 1;
        for (let k = 0; k < len; k++) {
          const px = Math.round(sx + (ix / il) * k);
          const py = Math.round(sy + (iy / il) * k);
          if (px < 2 || py < 2 || px > W - 3 || py > H - 3) continue;
          pix.rect(px, py, 1, 1, [C.alert[0], C.alert[1], C.alert[2], a]);
        }
      }
    }
  }

  /**
   * HULL SECTION PLAN — a 28×24 schematic of the Aethon divided into the same
   * six sections `ShipSystems` actually tracks, each cell tinted by its own
   * integrity.
   *
   * The HULL bar next to it shows the MEAN, and a mean is exactly the wrong
   * number in a fight: 60% could be six even sections or five pristine ones and
   * a hole in the bow. This tells you WHERE, which is the number that decides
   * whether you turn to put a good flank toward the shooter, and it is what the
   * REPAIR key is choosing between. Breached cells (≤25%) flash.
   */
  _sectionGrid(sys, x, y) {
    const { pix, C } = this;
    const s = sys?.sections;
    if (!s) return;
    // plan view: nose up, tail down, flanks either side, dorsal/ventral as the
    // two spine bands through the middle
    // 18px tall, not 24: the SHIP plate's bottom edge is pinned to H-6, so a
    // 24px plan starting under the four gauges ran the AFT cell into the frame's
    // corner bracket and clipped it off the buffer entirely.
    const cells = [
      ['fore', 8, 0, 11, 5], ['port', 0, 5, 7, 7], ['stbd', 20, 5, 8, 7],
      ['dorsal', 8, 5, 11, 3], ['ventral', 8, 9, 11, 3], ['aft', 8, 13, 11, 5],
    ];
    const blink = Math.floor(this.time * 3) % 2 === 0;
    for (const [key, cx2, cy2, cw, ch] of cells) {
      const v = s[key] ?? 100;
      const breach = v <= 25;
      let col = C.hull, a = 0.34 + (v / 100) * 0.5;
      if (v < 60) { col = C.rad; a = 0.75; }
      if (v < 35) { col = C.alert; a = breach && blink ? 1 : 0.8; }
      pix.rect(x + cx2, y + cy2, cw, ch, [col[0] * a, col[1] * a, col[2] * a, 0.95]);
      // each cell is its own little plate: lit top-left, dark bottom-right
      pix.rect(x + cx2, y + cy2, cw, 1, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.3]);
      pix.rect(x + cx2, y + cy2 + ch - 1, cw, 1, [0, 0, 0, 0.6]);
      pix.rect(x + cx2 + cw - 1, y + cy2, 1, ch, [0, 0, 0, 0.5]);
      // a damaged cell gets scoring across it, so the diagram degrades visibly
      if (v < 60) {
        for (let i = 1; i < cw - 1; i += 3) {
          pix.rect(x + cx2 + i, y + cy2 + 1 + ((i * 5) % Math.max(1, ch - 2)), 1, 1,
            [0, 0, 0, 0.7]);
        }
      }
    }
    // nose pip, so which end is forward is never ambiguous
    pix.rect(x + 13, y - 2, 2, 2, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 0.9]);
  }

  /**
   * TARGET block: what the lock is holding. Only drawn when there IS a lock, so
   * it costs nothing in cruise and appears exactly when a pilot starts wanting
   * it. Range, closure rate (positive = closing) and the target's own shield and
   * hull as two short pips — the three numbers that decide whether to keep
   * pressing or break off.
   */
  _targetBlock(lock, ship, x, y, w) {
    const t = lock?.target;
    if (!t) return;
    const { pix, C } = this;
    this._panel(x, y, w, 30);
    const hot = lock.locked;
    this._titlePlate(x + 4, y + 3, w - 8, hot ? 'TARGET' : 'TRACKING',
      hot ? C.alert : C.amberLo);
    // The lock record carries no range — it holds the enemy, not the geometry —
    // so measure it here against the hull's own position.
    const p = ship?.pos ?? [0, 0, 0];
    const rng = Math.hypot(t.pos[0] - p[0], t.pos[1] - p[1], t.pos[2] - p[2]);
    // 7 glyphs, not 9: AMBER9 advances 7px, so a 9-character type name is 63px
    // of ink and "KETH_COR" welded straight into the range on a 78px plate.
    const name = (t.type ?? 'CONTACT').toString().toUpperCase().replace('_', ' ').slice(0, 7);
    this._readout(x + 4, y + 11, w - 8, name, fmtRange(rng),
      hot ? C.amberHi : C.amber);
    // Shield and hull as two short pips SIDE BY SIDE on one row. Stacking them
    // four pixels apart put two 7px-tall labels through each other and 'SH' over
    // 'HL' rendered as an unreadable 'AL'. An enemy's integrity lives in
    // `hp`/`hpMax`, not `hull` — a hostile is not a ShipSystems and has no six
    // sections to average.
    const bw = Math.max(12, (w - 44) >> 1);
    const py = y + 20;
    for (const [i, [frac, col]] of [
      [t.shieldMax ? (t.shield ?? 0) / t.shieldMax : 0, C.shield],
      [(t.hp ?? 0) / Math.max(1, t.hpMax ?? 1), C.hull],
    ].entries()) {
      const gx = x + 4 + i * (bw + 20);
      this._text(gx, py - 1, i ? 'HL' : 'SH', C.sec, 0.75);
      pix.rect(gx + 16, py, bw, 4, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.95]);
      pix.rect(gx + 16, py, bw, 1, [0, 0, 0, 0.7]);
      const fw = Math.round((bw - 2) * clamp(frac, 0, 1));
      if (fw > 0) pix.rect(gx + 17, py + 1, fw, 2, [col[0], col[1], col[2], 1]);
    }
    // lock-acquisition sweep along the plate's top edge while still tracking
    if (!hot) {
      const p = clamp(lock.progress ?? 0, 0, 1);
      pix.rect(x + 2, y + 1, Math.round((w - 4) * p), 1,
        [C.alert[0], C.alert[1], C.alert[2], 0.9]);
    }
  }

  /**
   * NAV STRIP: where you are, what is nearest, and how rich you are. A survey
   * pilot flies on these three and none of them were anywhere on the glass —
   * the system name only existed in the warp dialog, and credits only in the
   * trading screen. Two lines on one narrow plate, top-right under the compass.
   */
  _navStrip(x, y, w, extras) {
    const { C } = this;
    this._panel(x, y, w, 22);
    const sysName = (extras?.systemName ?? 'UNCHARTED').toUpperCase().slice(0, 11);
    this._titlePlate(x + 4, y + 3, w - 8, sysName, C.amberHi);
    const nb = extras?.nearest;
    this._readout(x + 4, y + 12, w - 8,
      nb ? nb.name.toUpperCase().slice(0, 7) : 'NO BODY',
      nb ? fmtRange(nb.dist) : '--', C.amber);
  }

  /**
   * G-LOAD and DRIFT, the two things inertia made real and the HUD never said.
   * G is how hard the frame is being pushed right now; drift is the angle
   * between where the nose points and where the hull is actually going, which is
   * the number that explains why a turn isn't turning.
   */
  _load(ship) {
    // MEASURED, not inferred from the throttle: read the velocity difference
    // between frames so a collision, a soft-limit clamp or an assist burn all
    // show up as load, which is the whole point of a G gauge. Expressed in
    // multiples of a 1g burn, with the main drive's 42 u/s^2 calibrated to 3g so
    // a full-throttle run reads the way a full-throttle run should.
    const dt = this._dt || 1 / 60;
    const v = ship?.vel ?? [0, 0, 0];
    if (!this._pv) this._pv = [v[0], v[1], v[2]];
    const inst = Math.hypot(v[0] - this._pv[0], v[1] - this._pv[1], v[2] - this._pv[2]) / dt;
    this._pv[0] = v[0]; this._pv[1] = v[1]; this._pv[2] = v[2];
    // heavy smoothing: a raw per-frame difference is pure noise at 3 significant
    // figures, and a needle that flickers is a needle nobody reads
    this._gs = (this._gs ?? 0) + (inst - (this._gs ?? 0)) * Math.min(1, dt * 5);
    const g = (this._gs / 42) * 3;
    const fwd = Quat.rotateVec3([0, 0, 0], ship.quat, [0, 0, -1]);
    const sp = Math.hypot(v[0], v[1], v[2]);
    let drift = 0;
    if (sp > 1) {
      const dot = (fwd[0] * v[0] + fwd[1] * v[1] + fwd[2] * v[2]) / sp;
      drift = Math.acos(clamp(dot, -1, 1)) * 57.2958;
    }
    return { g, drift };
  }

  /**
   * DRIFT DIAL: the nose is straight up on the face, the needle is where the
   * hull is actually travelling. The numbers live in the top strip with the
   * other flight scalars; this is the instrument that makes the number
   * intuitive, and it is 13 pixels wide, which is all the centre console's left
   * column has to spare.
   */
  _driftDial(drift, x, y) {
    const { pix, C } = this;
    const hi = drift > 35;
    this._text(x - 2, y - 9, 'DRF', C.sec, 0.8);
    // bezel, plus a lit pixel at the top so "up = nose" is stated on the hardware
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      pix.rect(Math.round(x + Math.cos(a) * 5), Math.round(y + Math.sin(a) * 5), 1, 1,
        [C.sec[0], C.sec[1], C.sec[2], i % 3 === 0 ? 0.55 : 0.28]);
    }
    pix.rect(x, y - 6, 1, 2, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 0.9]);
    const da = -Math.PI / 2 + (drift * Math.PI) / 180;
    this._line(x, y, x + Math.cos(da) * 5, y + Math.sin(da) * 5,
      hi ? C.alert : C.amberHi, 0.95);
    pix.rect(x, y, 1, 1, [C.white[0], C.white[1], C.white[2], 0.8]);
  }

  _readout(x, y, w, label, value, color = this.C.amber) {
    const { C } = this;
    this._text(x, y, label, C.sec, 0.9);
    const vw = this.font.measure(A9, value);
    this._text(x + w - vw, y, value, color, 1);
  }

  /** 1px line composed of pixel rects (no line primitive in the buffer). */
  _line(x0, y0, x1, y1, color, alpha = 1) {
    const { pix } = this;
    const dx = x1 - x0, dy = y1 - y0;
    const n = Math.max(1, Math.round(Math.max(Math.abs(dx), Math.abs(dy))));
    const c = [color[0], color[1], color[2], alpha];
    for (let i = 0; i <= n; i++) {
      pix.rect(Math.round(x0 + (dx * i) / n), Math.round(y0 + (dy * i) / n), 1, 1, c);
    }
  }

  /**
   * GUN SOLUTION — the reticle that says the assist has the shot.
   *
   * Four brackets that CONVERGE on the crosshair when a target enters the
   * firing cone and sit wide open when it does not, plus the lead point itself
   * as a small floating pip. The convergence is the whole message: an assist
   * you cannot see the state of is indistinguishable from bad aim, and a pilot
   * needs to know before pulling the trigger whether the guns are going to
   * correct or fire straight.
   */
  _gunSolution(aim, camera, cx, cy) {
    const { pix, C } = this;
    const on = !!aim;
    // 11px apart with no solution, 4px with one; eased so it snaps shut rather
    // than sliding, which reads as a mechanism latching
    this._aimT = (this._aimT ?? 0) + ((on ? 1 : 0) - (this._aimT ?? 0)) * Math.min(1, (this._dt || 0.016) * 14);
    const g = 11 - this._aimT * 7;
    const col = on ? C.alert : C.sec;
    const a = 0.35 + this._aimT * 0.65;
    for (const [sx, sy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      const x = Math.round(cx + sx * g), y = Math.round(cy + sy * g);
      pix.rect(x - (sx < 0 ? 0 : 3), y, 4, 1, [col[0], col[1], col[2], a]);
      pix.rect(x, y - (sy < 0 ? 0 : 3), 1, 4, [col[0], col[1], col[2], a]);
    }
    if (!on) return;
    // the intercept point, projected: where the rounds are actually going
    const m = camera?.viewProjection ?? null;
    if (!m || !aim.lead) return;
    const p = aim.lead;
    const cw = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15];
    if (cw <= 0.01) return;
    const sx2 = ((m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12]) / cw * 0.5 + 0.5) * W;
    const sy2 = (1 - ((m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13]) / cw * 0.5 + 0.5)) * H;
    if (sx2 < 0 || sx2 > W || sy2 < 0 || sy2 > H) return;
    const ix = Math.round(sx2), iy = Math.round(sy2);
    pix.rect(ix - 2, iy, 5, 1, [C.alert[0], C.alert[1], C.alert[2], 0.9]);
    pix.rect(ix, iy - 2, 1, 5, [C.alert[0], C.alert[1], C.alert[2], 0.9]);
    pix.rect(ix, iy, 1, 1, [1, 1, 1, 1]);
  }

  /** An L-shaped corner bracket; sx/sy are the inward direction signs. */
  _bracket(x, y, sx, sy, len, color, alpha = 0.8) {
    const c = [color[0], color[1], color[2], alpha];
    this.pix.rect(sx > 0 ? x : x - len + 1, y, len, 1, c);
    this.pix.rect(x, sy > 0 ? y : y - len + 1, 1, len, c);
  }

  /** Four corner frame brackets — the "viewport" chrome, both modes. */
  _corners(color, inset = 3, len = 9, alpha = 0.7) {
    this._bracket(inset, inset, +1, +1, len, color, alpha);
    this._bracket(W - 1 - inset, inset, -1, +1, len, color, alpha);
    this._bracket(inset, H - 1 - inset, +1, -1, len, color, alpha);
    this._bracket(W - 1 - inset, H - 1 - inset, -1, -1, len, color, alpha);
  }

  /**
   * Cockpit attitude indicator: a horizon line that banks with roll and slides
   * with pitch, a short pitch ladder, and a fixed waterline marker. Reads as the
   * ship's primary flight instrument.
   */
  _attitude(ship) {
    const { C } = this;
    const cx = W / 2, cy = H / 2;
    const fwd = Quat.rotateVec3([0, 0, 0], ship.quat, [0, 0, -1]);
    const up = Quat.rotateVec3([0, 0, 0], ship.quat, [0, 1, 0]);
    const right = Quat.rotateVec3([0, 0, 0], ship.quat, [1, 0, 0]);
    const pitch = Math.asin(clamp(fwd[1], -1, 1));
    const roll = Math.atan2(right[1], up[1]);
    const ca = Math.cos(roll), sa = Math.sin(roll);
    const py = cy + pitch * 70; // horizon vertical offset from pitch
    const seg = (dist, half, alpha) => {
      // a line parallel to the horizon, `dist` px below it (screen space)
      const ox = -sa * dist, oy = ca * dist; // perpendicular offset (down = +y)
      this._line(cx - ca * half + ox, py - sa * half + oy,
        cx + ca * half + ox, py + sa * half + oy, C.amber, alpha);
    };
    seg(0, 62, 0.85); // horizon
    for (const d of [-30, -15, 15, 30]) seg(d, d % 30 === 0 ? 20 : 12, 0.4); // pitch ladder
    // fixed waterline / boresight marker (ship-referenced)
    this._line(cx - 12, cy, cx - 4, cy, C.amberHi, 0.95);
    this._line(cx + 4, cy, cx + 12, cy, C.amberHi, 0.95);
    this.pix.rect(cx - 4, cy, 1, 3, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 0.95]);
    this.pix.rect(cx + 4, cy, 1, 3, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 0.95]);
  }

  /**
   * Flight-path markers: where the ship is actually MOVING, projected into the
   * seated cockpit view. Prograde is a ringed velocity vector; retrograde is a
   * hollow cross. Essential once you can strafe — it shows drift the nose hides.
   */
  _velocityMarker(ship) {
    const { pix, C } = this;
    const speed = ship.speed;
    if (speed < 0.6) return; // at rest: no meaningful heading
    const fov = ((Settings.get('fov') ?? 70) * Math.PI) / 180;
    const fH2 = (H / 2) / Math.tan(fov / 2);
    const cx = W / 2, cy = H / 2;
    const inv = 1 / speed;
    const vd = [ship.vel[0] * inv, ship.vel[1] * inv, ship.vel[2] * inv];
    const mark = (d, prograde) => {
      const l = Quat.rotateVec3([0, 0, 0], ship.qConj, d);
      if (-l[2] <= 0.05) return; // behind the ship
      const sx = cx + (l[0] / -l[2]) * fH2;
      const sy = cy - (l[1] / -l[2]) * fH2;
      if (sx < 8 || sx > W - 8 || sy < 22 || sy > H - 90) return; // off-glass / behind panels
      const col = prograde ? C.amberHi : C.sec;
      const a = prograde ? 0.95 : 0.6;
      if (prograde) {
        for (let i = 0; i < 12; i++) {
          const ang = (i / 12) * Math.PI * 2;
          pix.rect(Math.round(sx + Math.cos(ang) * 3), Math.round(sy + Math.sin(ang) * 3), 1, 1, [col[0], col[1], col[2], a]);
        }
        pix.rect(Math.round(sx), Math.round(sy), 1, 1, [col[0], col[1], col[2], 1]);
        this._line(sx - 6, sy, sx - 3, sy, col, 0.85);
        this._line(sx + 3, sy, sx + 6, sy, col, 0.85);
        this._line(sx, sy - 6, sx, sy - 3, col, 0.85);
      } else {
        this._line(sx - 3, sy - 3, sx + 3, sy + 3, col, a);
        this._line(sx - 3, sy + 3, sx + 3, sy - 3, col, a);
      }
    };
    mark(vd, true);
    mark([-vd[0], -vd[1], -vd[2]], false);
  }

  /**
   * Target-lock reticle, projected onto the target's actual screen position.
   *
   * Three states, because a lock is a process and the pilot needs to see which
   * part of it they are in:
   *  - tracking   — four corner brackets converging inward as `progress` rises
   *  - locked     — brackets closed tight, plus a solid box and a range readout
   *  - off-screen — an edge chevron pointing the way, since a locked target you
   *                 cannot see is exactly when you most need to know where it is
   *
   * Uses the same planar projection as the velocity markers rather than the full
   * view-projection matrix: this is the seated cockpit view, the maths is four
   * lines, and it cannot disagree with the flight-path markers beside it.
   */
  _lockReticle(ship, lock) {
    if (!lock?.target || lock.target.hp <= 0) return;
    const { pix, C } = this;
    const fov = ((Settings.get('fov') ?? 70) * Math.PI) / 180;
    const fH2 = (H / 2) / Math.tan(fov / 2);
    const cx = W / 2, cy = H / 2;
    const t = lock.target;
    const rel = [t.pos[0] - ship.pos[0], t.pos[1] - ship.pos[1], t.pos[2] - ship.pos[2]];
    const dist = Math.hypot(rel[0], rel[1], rel[2]) || 1;
    const l = Quat.rotateVec3([0, 0, 0], ship.qConj, rel);
    const col = lock.locked ? C.alert : C.amberHi;
    const a = lock.locked ? 1 : 0.5 + 0.5 * lock.progress;

    if (-l[2] <= 0.05) { this._lockChevron(l, col, a); return; }
    const sx = cx + (l[0] / -l[2]) * fH2;
    const sy = cy - (l[1] / -l[2]) * fH2;
    if (sx < 6 || sx > W - 6 || sy < 20 || sy > H - 88) { this._lockChevron(l, col, a); return; }

    // brackets march in from 16px to 6px as acquisition completes — the motion
    // is the progress indicator, so no separate bar is needed
    const r = Math.round(16 - 10 * lock.progress);
    const arm = 4;
    for (const [dx, dy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      const bx = sx + dx * r, by = sy + dy * r;
      this._line(bx, by, bx - dx * arm, by, col, a);
      this._line(bx, by, bx, by - dy * arm, col, a);
    }
    if (lock.locked) {
      // closed box + range/integrity, only once locked: showing numbers during
      // acquisition implies you already have data you have not earned yet
      pix.rect(Math.round(sx - 1), Math.round(sy - 1), 3, 3, [col[0], col[1], col[2], 1]);
      const hp = Math.max(0, Math.round((t.hp / (t.hpMax ?? t.hp ?? 1)) * 100));
      const txt = `${Math.round(dist)}u`;
      const tw = this.font.measure(A9, txt);
      this._text(Math.round(sx - tw / 2), Math.round(sy + r + 3), txt, col, 0.95);
      if (t.hpMax) {
        const bw = 22;
        pix.rect(Math.round(sx - bw / 2), Math.round(sy - r - 6), bw, 2,
          [C.sec[0], C.sec[1], C.sec[2], 0.5]);
        pix.rect(Math.round(sx - bw / 2), Math.round(sy - r - 6),
          Math.max(1, Math.round((bw * hp) / 100)), 2, [col[0], col[1], col[2], 1]);
      }
    }
  }

  /** Edge chevron pointing at an off-screen locked target. */
  _lockChevron(local, col, a) {
    const cx = W / 2, cy = H / 2;
    // direction in screen space; -z forward means a target behind has l[2] > 0
    let dx = local[0], dy = -local[1];
    const len = Math.hypot(dx, dy) || 1;
    dx /= len; dy /= len;
    const rx = W / 2 - 22, ry = (H - 88 - 20) / 2;
    // scale to whichever edge is hit first
    const k = Math.min(rx / Math.max(1e-3, Math.abs(dx)), ry / Math.max(1e-3, Math.abs(dy)));
    const px = cx + dx * k, py = (20 + H - 88) / 2 + dy * k;
    const nx = -dy, ny = dx; // perpendicular, for the chevron's base
    this._line(px, py, px - dx * 7 + nx * 5, py - dy * 7 + ny * 5, col, a);
    this._line(px, py, px - dx * 7 - nx * 5, py - dy * 7 - ny * 5, col, a);
  }

  /** Translational-RCS input dot: a 3×3 cross lighting the active thruster. */
  _strafeIndicator(ship, x, y) {
    const { pix, C } = this;
    const st = ship?.strafe ?? [0, 0];
    const on = st[0] || st[1];
    const base = [C.sec[0], C.sec[1], C.sec[2], 0.4];
    const lit = [C.amberHi[0], C.amberHi[1], C.amberHi[2], 1];
    // frame
    this._text(x, y - 8, 'RCS', C.sec, on ? 0.9 : 0.5);
    const cx = x + 4, cy = y + 4;
    pix.rect(cx, cy, 2, 2, [C.amber[0], C.amber[1], C.amber[2], 0.7]); // hub
    pix.rect(cx - 4, cy, 2, 2, st[0] < 0 ? lit : base); // left
    pix.rect(cx + 4, cy, 2, 2, st[0] > 0 ? lit : base); // right
    pix.rect(cx, cy - 4, 2, 2, st[1] > 0 ? lit : base); // up
    pix.rect(cx, cy + 4, 2, 2, st[1] < 0 ? lit : base); // down
  }

  /** Vertical throttle gauge with a centre detent; fills up (fwd) / down (rev). */
  _throttle(ship, x, y, h) {
    const { pix, C } = this;
    const thr = clamp(ship?.thrust ?? 0, -1, 1);
    // Publish the quadrant's own geometry so main.js can make it DRAGGABLE.
    // The THR+/THR- touch keys are gone (0.24.0): they were two of the largest
    // buttons on screen for a single scalar that already had an instrument
    // drawn for it. The instrument is the control now.
    this.throttleRect = { x: x - 2, y: y - 2, w: 16, h: h + 12, gy: y + 7, gh: h };
    this._panel(x - 2, y - 2, 16, h + 12);
    this._text(x, y - 1, 'T', C.sec, 0.8);
    const gy = y + 7, gh = h;
    pix.rect(x + 3, gy, 6, gh, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.95]);
    const mid = gy + gh / 2;
    pix.rect(x + 1, Math.round(mid), 10, 1, [C.sec[0], C.sec[1], C.sec[2], 0.6]); // detent
    const fh = Math.round((gh / 2) * Math.abs(thr));
    if (fh > 0) {
      const col = ship?.boosting ? C.amberHi : C.fuel;
      const fy = thr >= 0 ? mid - fh : mid;
      pix.rect(x + 4, Math.round(fy), 4, fh, [col[0], col[1], col[2], 1]);
    }
    for (let t = 0; t <= 4; t++) pix.rect(x + 9, Math.round(gy + (gh * t) / 4), 2, 1, [C.sec[0], C.sec[1], C.sec[2], 0.5]);
  }

  /**
   * Attitude-rate strip: three little centre-zero needles for pitch/yaw/roll
   * angular velocity. Once the hull carries momentum (0.9.1 inertia) you need
   * to *see* the tumble you're carrying, not just feel it — this is the gauge a
   * pilot reads to null out a spin.
   */
  _rateGauges(ship, x, y) {
    const { pix, C } = this;
    const av = ship?.angVel ?? [0, 0, 0];
    const rows = [['PCH', av[0]], ['YAW', av[1]], ['RLL', av[2]]];
    const w = 46;
    rows.forEach(([label, v], i) => {
      const gy = y + i * 8;
      this._text(x, gy, label, C.sec, 0.8);
      const bx = x + 18, bw = w - 18, mid = bx + bw / 2;
      pix.rect(bx, gy + 2, bw, 3, [C.bgLo[0], C.bgLo[1], C.bgLo[2], 0.95]);
      pix.rect(Math.round(mid), gy + 1, 1, 5, [C.sec[0], C.sec[1], C.sec[2], 0.7]); // zero tick
      const n = clamp(v / 1.6, -1, 1) * (bw / 2 - 1);
      if (Math.abs(n) > 0.5) {
        const from = n < 0 ? mid + n : mid;
        const hot = Math.abs(v) > 1.0;
        const col = hot ? C.alert : C.amberHi;
        pix.rect(Math.round(from), gy + 2, Math.max(1, Math.round(Math.abs(n))), 3, [col[0], col[1], col[2], 1]);
      }
    });
  }

  /**
   * Drive / power block: the numbers a pilot actually flies on, in a stacked
   * console readout rather than scattered around the glass.
   */
  _driveBlock(ship, sys, x, y, w) {
    const { C } = this;
    const spd = Math.round(ship?.speed ?? 0);
    const thr = Math.round(Math.abs(ship?.thrust ?? 0) * 100);
    this._panel(x, y, w, 44);
    this._text(x + 4, y + 3, 'DRIVE', C.amberLo, 0.9);
    this._readout(x + 4, y + 12, w - 8, 'VEL', `${spd}`, C.amberHi);
    this._readout(x + 4, y + 21, w - 8, 'THR', `${thr}%`, thr > 100 ? C.alert : C.amber);
    this._readout(x + 4, y + 30, w - 8, 'MODE',
      ship?.braking ? 'BRAKE' : ship?.flightAssist ? 'ASSIST' : 'MANUAL',
      ship?.flightAssist ? C.amber : C.alert);
    // capacitor charge for the lance
    this._bar(x + 4, y + 39, w - 8, 'CAP', (sys?.weapons ?? 0) / 100, C.power, { warn: 0.2 });
  }

  /**
   * Selected hardpoint and its magazine. Sits directly above the drive block so
   * the two things a pilot checks mid-fight — what is loaded and how much of it
   * is left — are adjacent rather than at opposite corners of the glass.
   *
   * Rounds go red under a fifth of a magazine and the label reads CAP for an
   * energy weapon, because "infinity rounds" is not a useful thing to print.
   */
  _weaponBlock(loadout, x, y, w) {
    if (!loadout) return;
    const { C } = this;
    const spec = loadout.current;
    const n = loadout.rounds();
    const energy = n === Infinity;
    const frac = energy ? 1 : n / Math.max(1, spec.ammoMax);
    this._panel(x, y, w, 22);
    // Right-align the name through _readout instead of hand-placing it after the
    // label. Two attempts at a fixed offset both rendered as "WPNPULSE": AMBER9
    // is a 7px-advance face, so 'WPN' from x+4 inks to x+23 and the x+26 that
    // looked like a 4px gap on paper was 2px on glass. Every other label/value
    // pair in this HUD pins the value to the panel's right edge, which cannot
    // collide by construction — the longest name (TORPEDO, 49px) still clears
    // the label by 30px at the narrowest panel width.
    this._readout(x + 4, y + 3, w - 8, 'WPN', spec.name,
      frac < 0.2 && !energy ? C.alert : C.amberHi);
    if (energy) this._readout(x + 4, y + 12, w - 8, 'AMMO', 'CAP', C.amber);
    else this._readout(x + 4, y + 12, w - 8, 'AMMO', `${n}`, frac < 0.2 ? C.alert : C.amber);
  }

  /** Small circular sweep scope — a "radar monitor", contacts as blips. */
  /**
   * TACTICAL RADAR. The old scope was decoration: a ring, a cross and a sweep
   * line, with a `contacts` count passed in and never drawn — it told you a
   * number, not a direction, so there was no way to know where anything was.
   *
   * This plots real bearings. Contacts arrive already rotated into SHIP-LOCAL
   * space (see main.js), so the display is nose-up: straight ahead is the top of
   * the ring, dead astern is the bottom, and the whole picture turns under you as
   * you turn. Radius is range, compressed with a square root so the near half of
   * the envelope — where a fight actually happens — gets most of the dial.
   *
   * The third dimension is the hard part on a 2D dial, and dropping it is what
   * makes most radars useless in a 6-DOF game. Elevation is carried by the GLYPH:
   * a contact above the ship's plane draws as an up-chevron, below as a
   * down-chevron, within it as a solid block. Two contacts at the same bearing
   * are still distinguishable, which is the whole point.
   *
   * @param {{x:number,y:number,z:number,hostile:boolean,locked:boolean,body:boolean}[]} contacts
   */
  _radar(x, y, r, contacts, range) {
    const { pix, C } = this;
    const dim = [C.sec[0], C.sec[1], C.sec[2], 0.7];
    const faint = [C.sec[0], C.sec[1], C.sec[2], 0.22];
    // Panel backing. Without it the dial was drawn straight onto the cockpit
    // bulkhead behind the glass, and a 2px blip on a mid-grey rivet is not
    // readable — every other instrument in this HUD sits on a plate.
    this._panel(x - r - 4, y - r - 4, r * 2 + 9, r * 2 + 16);
    // two range rings, so a blip's radius reads as a distance
    for (const [rr, a] of [[r, 0.7], [r * 0.5, 0.3]]) {
      const steps = Math.max(16, Math.round(rr * 2.4));
      for (let i = 0; i < steps; i++) {
        const ang = (i / steps) * Math.PI * 2;
        pix.rect(Math.round(x + Math.cos(ang) * rr), Math.round(y + Math.sin(ang) * rr), 1, 1,
          [C.sec[0], C.sec[1], C.sec[2], a]);
      }
    }
    pix.rect(x - r, y, r * 2, 1, faint);
    pix.rect(x, y - r, 1, r * 2, faint);
    // nose marker: a notch at the top, so "up = where I am pointing" is explicit
    pix.rect(x - 1, y - r - 2, 3, 2, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 0.9]);
    // sweep
    const sa = this.time * 1.6;
    this._line(x, y, x + Math.cos(sa) * r, y + Math.sin(sa) * r, C.amberHi, 0.55);

    for (const c of contacts ?? []) {
      // ship-local: -z is forward, +x starboard, +y up. Screen: -y is up.
      const flat = Math.hypot(c.x, c.z) || 0.0001;
      const dist = Math.hypot(c.x, c.y, c.z);
      // sqrt compression, and anything past the envelope pins to the rim so a
      // distant threat is still on the dial rather than silently missing
      const k = Math.min(1, Math.sqrt(Math.min(1, dist / range)));
      const px = x + (c.x / flat) * k * r;
      const py = y + (c.z / flat) * k * r;
      const col = c.body ? C.sec : c.hostile ? C.alert : C.amber;
      const bright = c.locked ? 1 : 0.88;
      const rgba = [col[0], col[1], col[2], bright];
      // elevation glyph — the ring is flat, the fight is not
      const rise = c.y / Math.max(1, dist);
      const ix = Math.round(px), iy = Math.round(py);
      if (c.body) {
        pix.rect(ix - 1, iy - 1, 3, 3, [col[0], col[1], col[2], 0.4]);
      } else if (rise > 0.25) {
        pix.rect(ix, iy - 1, 1, 1, rgba); pix.rect(ix - 1, iy, 3, 1, rgba);
      } else if (rise < -0.25) {
        pix.rect(ix - 1, iy - 1, 3, 1, rgba); pix.rect(ix, iy, 1, 1, rgba);
      } else {
        pix.rect(ix - 1, iy - 1, 2, 2, rgba);
      }
      // the locked target gets a bracket, so the dial agrees with the reticle
      if (c.locked) {
        pix.rect(ix - 3, iy - 3, 2, 1, C.amberHi); pix.rect(ix - 3, iy - 3, 1, 2, C.amberHi);
        pix.rect(ix + 2, iy - 3, 2, 1, C.amberHi); pix.rect(ix + 3, iy - 3, 1, 2, C.amberHi);
        pix.rect(ix - 3, iy + 3, 2, 1, C.amberHi); pix.rect(ix - 3, iy + 2, 1, 2, C.amberHi);
        pix.rect(ix + 2, iy + 3, 2, 1, C.amberHi); pix.rect(ix + 3, iy + 2, 1, 2, C.amberHi);
      }
    }
    // own hull, last so it is never covered by a blip sitting on top of us
    pix.rect(x - 1, y - 1, 2, 2, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 1]);
    return dim;
  }

  /**
   * @param {import('../player/Player.js').Player} player
   * @param {import('./Crosshair.js').Crosshair} crosshair
   * @param {import('./NotificationSystem.js').NotificationSystem} notifications
   * @param {'walk'|'flight'} mode
   * @param {import('../ship/Spaceship.js').Spaceship} [ship]
   * @param {import('../ship/ShipSystems.js').ShipSystems} [sys]
   */
  render(player, crosshair, notifications, mode = 'walk', ship = null, sys = null, extras = null) {
    const { pix, font, C } = this;

    // helmet glass first, under everything
    pix.setTexture(this.overlayTexture);
    pix.sprite(0, 0, W, H, { u0: 0, v0: 0, u1: 1, v1: 1 }, [1, 1, 1, 1]);
    pix.setTexture(this.fontTexture);

    const s = sys ?? fallbackSystems();

    // viewport frame — helmet visor edge on foot, cockpit glass in the seat
    this._corners(mode === 'flight' ? C.amber : C.sec, 3, 10, 0.6);
    this._compass(player.camera.yaw);
    // Directional damage, over the visor frame and under everything else — it
    // has to be readable at a glance without covering an instrument.
    this._hurtArcs(player.camera.yaw);

    // How many rows at the bottom the command bar owns, INCLUDING its seat rail
    // and hit pad. Every bottom-anchored block below derives from this rather
    // than from a hard-coded offset, because the bar is taller under a thumb
    // than under a mouse and the panels have to move with it.
    const BAR = (this.inset > 0 ? 26 : 15) + 5;
    const BOT = H - BAR - 3; // the lowest row a panel may occupy
    // Every edge-anchored block is pushed in by `inset` so the touch button
    // gutters stay clear (see the field's docstring). inset is 0 on desktop.
    const I = this.inset;

    // -- surroundings / sensors, top-left --------------------------------------
    // Denser than it was: the same SENSORS plate now also carries the suit's
    // environment line (pressure / gravity), which used to exist nowhere on the
    // glass despite the survival model tracking both.
    this._panel(5 + I, 22, 92, 42);
    this._titlePlate(9 + I, 25, 84, 'SENSORS', C.sec);
    this._readout(9 + I, 33, 84, 'CONTACTS', String(s.contacts ?? 0), s.contacts ? C.alert : C.amber);
    // noise signature meter — how loud you are (hiding feedback)
    const noise = extras?.noise ?? 0;
    this._bar(9 + I, 41, 84, 'NSE', noise, noise > 0.6 ? C.alert : C.amber, {
      warn: null, value: extras?.hidden ? 'HIDDEN' : noise > 0.6 ? 'LOUD' : '',
    });
    // suit environment: cabin pressure and local gravity, the two readings that
    // tell you whether the compartment you are standing in is survivable
    // Two-glyph labels and one decimal: AMBER9 advances 7px per glyph, so
    // "PRS" + "0.52" is 49px of ink in a 40px column and the first attempt
    // rendered as "PRS0.5" with the label and the value welded together.
    const env = extras?.env;
    this._readout(9 + I, 49, 38, 'PR', env ? `${env.pressure.toFixed(1)}` : '1.0',
      env && env.pressure < 0.6 ? C.alert : C.sec);
    this._readout(55 + I, 49, 38, 'GR', env ? `${env.gravity.toFixed(1)}` : '1.0', C.sec);
    // mini contact sweep dot, and a ribbed vent beside it — the plate has room
    // now and a bare strip of nothing is a missed decorative beat
    const sweep = (this.time * 0.6) % 1;
    pix.rect(9 + I + Math.round(sweep * 60), 59, 1, 2, [C.amber[0], C.amber[1], C.amber[2], 0.7]);
    this._grille(74 + I, 57, 19, 5);

    // -- VITALS panel, bottom-left: all seven stats (context/04 §1) -------------
    // With both gutters reserved the 480px buffer only has 392 usable, and two
    // 128px panels left the centre console 68px — not enough for "MODE ASSIST".
    // Narrowed a notch on the owner's "make the HUD a little smaller" note.
    // The floor is set by the DRIVE block's widest string, MODE / ASSIST, which
    // needs 96px of plate to render without the label column colliding with the
    // value column — below that the readouts start truncating.
    const panelW = I ? 100 : 114;
    // Row pitch 10 -> 8 (see _bar). Seven gauges that used to need 70px of plate
    // now need 56, which is where the smaller footprint comes from AND what pays
    // for the hazard strip and the condition footer below without losing a bar.
    // -19 on every bottom-anchored block: the command bar now owns the last
    // 19 rows of the buffer (see _commandBar), and a panel drawn under it was
    // the crowding the owner was pointing at.
    const lx = 5 + I, lw = panelW, lh = 78, ly = BOT - lh;
    this._panel(lx, ly, lw, lh);
    this._titlePlate(lx + 5, ly + 3, lw - 10, 'VITALS', C.amberLo);
    const bw = lw - 10;
    this._bar(lx + 5, ly + 11, bw, 'HP', s.health / 100, C.health, { warn: 0.25, value: `${Math.round(s.health)}` });
    this._bar(lx + 5, ly + 19, bw, 'O2', s.oxygen / 100, C.o2, { rtl: true, warn: 0.2, value: `${Math.round(s.oxygen)}` });
    this._bar(lx + 5, ly + 27, bw, 'FOOD', (s.hunger ?? 100) / 100, C.fuel, { warn: 0.25, value: `${Math.round(s.hunger ?? 100)}` });
    this._bar(lx + 5, ly + 35, bw, 'H2O', (s.thirst ?? 100) / 100, C.o2, { warn: 0.2, value: `${Math.round(s.thirst ?? 100)}` });
    this._bar(lx + 5, ly + 43, bw, 'RST', (s.fatigue ?? 100) / 100, C.amber, { warn: 0.2, value: `${Math.round(s.fatigue ?? 100)}` });
    this._bar(lx + 5, ly + 51, bw, 'HEAT', heatFrac(s.heat), heatColor(this, s.heat), { value: `${s.heat.toFixed(0)}C` });
    this._bar(lx + 5, ly + 59, bw, 'RAD', s.radiation / 100, C.rad, { warn: null, value: s.radBand ? s.radBand() : 'LOW' });
    // condition footer: the one-word summary a medic would give, plus the suit's
    // own integrity, on a hazard-striped sill so the block terminates in hardware
    this._hazard(lx + 5, ly + 68, 26, 6, 0.34);
    // Four-letter codes, not words: "IMPAIRED" is 56px of ink and it drove
    // straight through the COND label ("COMBAIRED") on a 75px column.
    const cond = s.health < 25 ? 'CRIT' : s.health < 55 ? 'IMPR'
      : (s.hunger ?? 100) < 30 || (s.thirst ?? 100) < 30 ? 'STRN' : 'NOM';
    this._readout(lx + 34, ly + 67, lw - 39, 'COND', cond,
      cond === 'NOM' ? C.amber : C.alert);

    // critical-stat alert strip — flashes under the compass when a vital is dire
    const crits = [];
    if (s.health < 25) crits.push('LOW HEALTH');
    if (s.oxygen < 20) crits.push('LOW O2');
    if ((s.thirst ?? 100) < 20) crits.push('DEHYDRATION');
    if ((s.hunger ?? 100) < 25) crits.push('STARVATION');
    if ((s.fatigue ?? 100) < 20) crits.push('EXHAUSTION');
    if (s.radiation > 60) crits.push('RAD SICKNESS');
    if (crits.length && Math.floor(this.time * 2.4) % 2 === 0) {
      const ctext = crits.join('  ·  ');
      const cw2 = font.measure(A9, ctext);
      const ax = Math.round((W - cw2) / 2);
      // y=48, not 38: the flight strip above grew a second line (HDG/PIT) and
      // now occupies 22..44, so the old position put the alert through it.
      this._panel(ax - 6, 48, cw2 + 12, 13, { plain: true });
      this._hazard(ax - 4, 49, 3, 11, 0.5);
      this._hazard(ax + cw2 + 1, 49, 3, 11, 0.5);
      this._text(ax, 51, ctext, C.alert);
    }

    // -- SHIP panel, bottom-right ----------------------------------------------
    // The four bars pack into 32px at the new pitch, leaving room underneath for
    // the six-section damage plan — the readout that says WHERE the hull is hurt
    // rather than only how much of it is left on average.
    const rx = W - panelW - 5 - I, rw = panelW, rh = 68, ry = BOT - rh;
    this._panel(rx, ry, rw, rh);
    this._titlePlate(rx + 5, ry + 3, rw - 10, 'SHIP', C.amberLo);
    this._bar(rx + 5, ry + 11, rw - 10, 'FUEL', s.fuel / 100, C.fuel, { warn: 0.1, value: `${Math.round(s.fuel)}` });
    this._bar(rx + 5, ry + 19, rw - 10, 'PWR', s.power / 100, C.power, { value: `${Math.round(s.power)}` });
    this._bar(rx + 5, ry + 27, rw - 10, 'SHLD', s.shield / 100, C.shield, { value: `${Math.round(s.shield)}` });
    this._bar(rx + 5, ry + 35, rw - 10, 'HULL', s.hull / 100, C.hull, { warn: 0.3, value: `${Math.round(s.hull)}` });
    // separator rule + hazard sill, then the schematic with its own legend column
    pix.rect(rx + 4, ry + 44, rw - 8, 1, [0, 0, 0, 0.6]);
    pix.rect(rx + 4, ry + 45, rw - 8, 1, [C.borderHi[0], C.borderHi[1], C.borderHi[2], 0.2]);
    this._sectionGrid(sys, rx + 6, ry + 48);
    // worstSection() hands back {name, value} — not a bare key.
    const worst = sys?.worstSection ? sys.worstSection() : null;
    this._readout(rx + 40, ry + 48, rw - 45, 'MEAN', `${Math.round(s.hull)}%`,
      s.hull < 40 ? C.alert : C.amber);
    this._readout(rx + 40, ry + 56, rw - 45, 'WST',
      worst ? worst.name.slice(0, 4).toUpperCase() : '--',
      worst && worst.value < 50 ? C.alert : C.sec);
    this._grille(rx + 40, ry + 65, rw - 45, 4);

    // -- centre: crosshair / flight reticle + prompts --------------------------
    const cx = W / 2, cy = H / 2;
    if (mode === 'flight') {
      // cockpit instrument cluster: attitude horizon + flight-path markers +
      // throttle quadrant + RCS grid + scope
      if (ship) {
        this._attitude(ship); this._velocityMarker(ship);
        this._lockReticle(ship, extras?.lock);
        this._gunSolution(extras?.aim, player.camera, cx, cy);
      }
      this._throttle(ship, 12 + I, cy - 26, 52);
      this._strafeIndicator(ship, 14 + I, cy + 34);
      // Centre console: the gap between the VITALS and SHIP panels was dead
      // space, and it's exactly where a cockpit's main instrument cluster sits.
      // (The right edge is off limits — the celestial approach popup is a DOM
      // overlay that covers it.)
      // Centre console, sized to whatever gap the VITALS and SHIP panels leave.
      // Hard-coded x/width put the DRIVE block straight through the SHIP panel
      // as soon as the touch gutters pushed the two edge panels inward.
      const gapL = lx + lw + 6, gapR = rx - 6;
      // Left column of the centre console: rate needles above, G-load and drift
      // below. Inertia has been real since 0.9.1 and neither number was anywhere
      // on the glass — a pilot could feel the hull sliding and had nothing to
      // read that explained it.
      const load = ship ? this._load(ship) : { g: 0, drift: 0 };
      if (ship) {
        this._rateGauges(ship, gapL, BOT - 46);
        this._driftDial(load.drift, gapL + 7, BOT - 12);
        this._grille(gapL + 18, BOT - 18, 22, 13);
      }
      const dw = Math.max(64, Math.min(112, gapR - (gapL + 42)));
      this._weaponBlock(extras?.loadout, gapL + 42, BOT - 74, dw);
      this._driveBlock(ship, s, gapL + 42, BOT - 50, dw);
      // Tactical radar. Bigger than the old 14px scope (a 2px blip on a 14px dial
      // could not resolve a bearing) and labelled with the live contact count and
      // the nearest range, which is the pair of numbers you actually fly on.
      // Upper right, under the compass — NOT vertically centred. The touch layer's
      // attitude stick occupies the right gutter at roughly mid-height, and a
      // centred dial sat directly behind it.
      const radR = 21;
      const radX = W - radR - 8 - I, radY = 52;
      const rc = extras?.contacts ?? [];
      this._radar(radX, radY, radR, rc, extras?.radarRange ?? 6000);
      const hostiles = rc.filter((c) => c.hostile && !c.body);
      let near = Infinity;
      for (const c of hostiles) near = Math.min(near, Math.hypot(c.x, c.y, c.z));
      const tag = hostiles.length
        ? `${hostiles.length}:${near > 9950 ? '10K+' : `${Math.round(near / 100) / 10}K`}`
        : 'CLEAR';
      const tw2 = font.measure(A9, tag);
      this._text(Math.round(radX - tw2 / 2), radY + radR + 4, tag,
        hostiles.length ? C.alert : C.sec, 0.85);
      // NAV then TARGET, stacked under the dial in the right gutter.
      //
      // NAV started out top-left under SENSORS and had to move: the celestial
      // approach popup is a DOM overlay that lands at roughly x=41..150, y=68..150
      // on the UI grid whenever a body is in range, and it covered the strip
      // exactly when the strip was most worth reading. The right column below the
      // radar is claimed by nothing until the SHIP plate at y=196.
      const navX = W - 5 - I - 92;
      this._navStrip(navX, radY + radR + 13, 92, extras);
      this._targetBlock(extras?.lock, ship, navX, radY + radR + 38, 92);
      // Hull-cam dolly, in the band the right column leaves between the target
      // block and the SHIP plate. Only while the external camera is actually out.
      if (extras?.chase) this._zoomPad(navX, ry - 22, 92, extras.chase);
      // compact SPD/THR strip, centre-top under the compass; flight-assist state
      const spd = Math.round(ship?.speed ?? 0);
      const thr = Math.round(Math.abs(ship?.thrust ?? 0) * 100);
      const asst = ship?.flightAssist ? 'A/S' : 'MAN';
      // HDG/PIT added: the attitude ball shows the ship's orientation but you
      // cannot call a bearing off a horizon line, and a survey pilot logs
      // bearings. Degrees, taken off the nose vector in the system's own frame.
      const nose = ship ? Quat.rotateVec3([0, 0, 0], ship.quat, [0, 0, -1]) : [0, 0, -1];
      const hdg = ((Math.atan2(nose[0], -nose[2]) * 57.2958) + 360) % 360;
      const pit = Math.asin(clamp(nose[1], -1, 1)) * 57.2958;
      const strip = `SPD ${spd}  THR ${thr}%  ${asst}${ship?.braking ? '  BRK' : ''}`;
      // Second line: bearing, pitch, and the two inertia numbers. All four are
      // scalars a pilot calls out, so they belong together on one line rather
      // than fighting for space in the centre console — the earlier attempt put
      // G and DRF in a 26px block where the label and the value overlapped.
      const hstr = `HDG ${String(Math.round(hdg)).padStart(3, '0')}  PIT ${pit > 0 ? '+' : ''}${Math.round(pit)}`
        + `  G ${load.g.toFixed(1)}  DRF ${Math.round(load.drift)}`;
      // Size the plate to the WIDER of the two lines. Sizing it to the first
      // line alone let the second run off both ends of its own panel.
      const sw = font.measure(A9, strip), hw = font.measure(A9, hstr);
      const pw2 = Math.max(sw, hw);
      this._panel(Math.round(cx - pw2 / 2) - 6, 22, pw2 + 12, 22);
      const ax = Math.round(cx - sw / 2);
      this._text(ax, 25, strip, C.amber);
      // colour the assist token: amber when on, dim alert when manual
      const asstX = ax + font.measure(A9, `SPD ${spd}  THR ${thr}%  `);
      this._text(asstX, 25, asst, ship?.flightAssist ? C.amberHi : C.alert);
      this._text(Math.round(cx - hw / 2), 34, hstr,
        load.g > 4 || load.drift > 35 ? C.amber : C.sec, 0.85);
    } else {
      const target = player.controller.interactTarget;
      /**
       * ON A WORLD there is no interact raycast — `player.update` does not run
       * out there and the ground is a heightfield, not a set of volumes. The
       * caller hands us the nearest searchable thing instead, and it takes the
       * same prompt so that "walk up to it and press E" is one habit whether
       * you are aboard or eight hundred metres from the ship. See main.js.
       */
      const label = target
        ? (typeof target.rec.label === 'function' ? target.rec.label() : target.rec.label)
        : (extras?.reach ?? null);
      crosshair.render(pix, !!label);
      if (label) {
        const text = `[E] ${label}`;
        const tw = font.measure(A9, text);
        const tx = Math.round((W - tw) / 2);
        this._panel(tx - 6, cy + 12, tw + 12, 13, { plain: true });
        this._text(tx, cy + 15, text, C.amberHi);
      }
      // Current compartment, on its own bolted nameplate rather than as bare
      // floating text, with the ship's designation and the mission clock beside
      // it — a survey crew logs everything against elapsed mission time and the
      // number existed nowhere in the interface.
      const zone = player.zone;
      // WHERE YOU ARE, and off the ship that is not a compartment. Standing on
      // a world or floating outside the hull, `player.zone` is whatever room
      // you were last in — so the nameplate read CREW QUARTERS while you were
      // stood on a lava plain.
      const zname = extras?.place ?? zone?.name ?? 'HSV AETHON';
      const clock = fmtClock(extras?.missionTime ?? this.time);
      const plate = `${zname}`;
      const zw = font.measure(A9, plate), cw3 = font.measure(A9, clock);
      const pw = zw + cw3 + 16;
      const px0 = Math.round((W - pw) / 2);
      this._panel(px0, 21, pw, 13, { plain: true });
      this._hazard(px0 + 2, 22, 3, 11, 0.45);
      this._text(px0 + 7, 24, plate, C.amber, 0.95);
      this._text(px0 + 7 + zw + 6, 24, clock, C.sec, 0.8);
    }

    // -- SUIT: the EVA panel ---------------------------------------------------
    // Drawn OVER the walk HUD rather than instead of it, because health, oxygen,
    // food and water matter exactly as much outside as in — an EVA screen that
    // hid the vitals would hide the one that kills you. What this adds is the
    // three figures that only exist out here, led by the one that decides
    // everything: RANGE against the length of the tether.
    if (extras?.eva) this._evaPanel(extras.eva, Math.round((W - 116) / 2), 74);

    // The command bar draws over everything else on the glass but under the
    // notifications, which have to stay readable while a key is lit.
    this._commandBar(mode, extras);
    notifications.render(pix, font);
    pix.flush();
  }

  /**
   * THE SUIT PANEL. Three budgets and a tether bar, centred high on the glass
   * where a helmet display would actually be projected — not tucked in a corner
   * like an instrument, because out here it is not an instrument, it is the
   * only thing between you and arithmetic.
   *
   * RANGE leads because it is the figure every decision turns on. The bar under
   * it is the tether: filled while the line still has slack, hazard-striped past
   * the end of it, so "outside the tether" is a state you can see rather than a
   * number you have to remember the limit of.
   *
   * @param {object} s SpaceWalk.status()
   */
  _evaPanel(s, x, y) {
    const { pix, font, C } = this;
    const W2 = 116, H2 = 46;
    this._panel(x, y, W2, H2);
    this._titlePlate(x + 4, y + 3, W2 - 8, 'SUIT', C.amberLo);

    // Range against the line. Red once the reel is out.
    const out = s.range > s.tether;
    const rcol = out ? C.alert : s.range > s.tether * 0.75 ? C.amberHi : C.amber;
    this._readout(x + 4, y + 11, W2 - 8, 'RANGE', `${Math.round(s.range)}M`, rcol);
    // The tether as a bar: 0..tether fills, and beyond it the whole bar goes
    // hazard so the state reads at a glance instead of by comparing two numbers.
    const bw = W2 - 8;
    pix.rect(x + 4, y + 19, bw, 3, [0, 0, 0, 0.7]);
    if (out) {
      this._hazard(x + 4, y + 19, bw, 3, 0.9);
    } else {
      const f = Math.max(0, Math.min(1, s.range / s.tether));
      pix.rect(x + 4, y + 19, Math.round(bw * f), 3, [rcol[0], rcol[1], rcol[2], 1]);
    }
    // Cold gas: the budget that actually strands people, so it gets a real bar.
    this._bar(x + 4, y + 24, bw, 'JET', s.jet / 100, s.jet < 25 ? C.alert : C.fuel,
      { warn: 0.25, value: `${Math.round(s.jet)}` });
    this._bar(x + 4, y + 32, bw, 'O2', s.oxygen / 100, s.oxygen < 25 ? C.alert : C.o2,
      { warn: 0.25, rtl: true, value: `${Math.round(s.oxygen)}` });
    // Closing speed and the hatch prompt share the sill row.
    this._hazard(x + 4, y + 40, 20, 4, 0.4);
    this._text(x + 27, y + 39, s.canEnter ? '[E] CYCLE LOCK' : `${s.speed.toFixed(1)} M/S`,
      s.canEnter ? C.amberHi : C.sec, s.canEnter ? 1 : 0.75);
  }

  _compass(yaw) {
    const { pix, font, C } = this;
    const cx = W / 2;
    const stripW = 132;
    const x0 = cx - stripW / 2;
    this._panel(x0, 5, stripW, 14);
    const dirs = [
      ['N', 0], ['NE', Math.PI / 4], ['E', Math.PI / 2], ['SE', (3 * Math.PI) / 4],
      ['S', Math.PI], ['SW', (5 * Math.PI) / 4], ['W', (3 * Math.PI) / 2], ['NW', (7 * Math.PI) / 4],
    ];
    const pxPerRad = 58;
    for (const [name, ang] of dirs) {
      let d = ang - (-yaw);
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      const off = d * pxPerRad;
      if (Math.abs(off) > stripW / 2 - 9) continue;
      const gw = font.measure(A9, name);
      const cardinal = name.length === 1;
      this._text(Math.round(cx + off - gw / 2), 8, name, cardinal ? C.amber : C.sec, cardinal ? 1 : 0.8);
    }
    pix.rect(cx, 16, 1, 3, [C.amberHi[0], C.amberHi[1], C.amberHi[2], 1]);
  }
}

/**
 * Range in the units a pilot would actually say out loud: metres under a
 * kilometre, then one decimal of kilometres, then whole kilometres. "4823" tells
 * you nothing at a glance; "4.8K" does.
 */
function fmtRange(u) {
  if (!isFinite(u)) return '--';
  if (u < 1000) return `${Math.round(u)}`;
  if (u < 100000) return `${(u / 1000).toFixed(1)}K`;
  return `${Math.round(u / 1000)}K`;
}

/** Elapsed mission time as HH:MM:SS, zero-padded — a log timestamp. */
function fmtClock(sec) {
  const t = Math.max(0, Math.floor(sec));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s2 = t % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s2).padStart(2, '0')}`;
}

// heat 10..45°C mapped to 0..1 for the bar
function heatFrac(c) { return Math.max(0, Math.min(1, (c - 10) / 35)); }
function heatColor(hud, c) { return c > 30 ? hud.C.heat : mixColor(hud.C.amber, hud.C.heat, Math.min(1, (c - 20) / 15)); }
function mixColor(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }

/** Static fallback so the HUD still draws if systems aren't wired (dev safety). */
function fallbackSystems() {
  return {
    health: 100, oxygen: 96, shield: 78, hull: 91, fuel: 87, power: 92,
    heat: 21, radiation: 4, contacts: 0, radBand: () => 'LOW',
  };
}
