/**
 * FabricatorUI — the workshop bench, finally switched on.
 *
 * The bench is the only place in the game that turns junk into stores, so the
 * panel is laid out like a job card rather than a shop: what comes out on the
 * left with its icon, what it eats underneath it in have/need form, and a RUN
 * button that is dead until the hold can actually pay. Nothing is hidden — a
 * recipe you cannot afford still shows, greyed, with the shortfall in red,
 * because "what do I need to look for out there" is the question the bench is
 * really answering.
 *
 * The STRIP tab is the other direction and reads deliberately worse: one row
 * per stack, a small return, and a warning colour. Breaking your own kit down
 * should feel like a decision made in trouble.
 *
 * Same plate chrome as the trade counter — this is ship's equipment, not a
 * menu.
 */
import { plasticButton, plasticPanel, hazardBar, framePanel, showScrim, panelChrome, itemIconPNG, platePNG } from './Chrome.js';
import { ITEMS } from '../data/ItemRegistry.js';

const GROUPS = ['SHIP', 'SUIT', 'ORDNANCE', 'MEDICAL', 'STOCK'];

/** How the bench talks about a spoil chance, because a percentage is not a feel. */
function riskWord(p) {
  if (p <= 0.001) return 'ROUTINE';
  if (p < 0.06) return 'STEADY WORK';
  if (p < 0.11) return 'FIDDLY';
  if (p < 0.16) return 'AWKWARD';
  return 'DANGEROUS';
}

export class FabricatorUI {
  /**
   * @param {import('../gameplay/Fabrication.js').Fabrication} fab
   * @param {import('../gameplay/Inventory.js').Inventory} inventory
   * @param {(text:string)=>void} notify
   * @param {() => void} [onClose] re-lock/resume when the bench is left
   */
  constructor(fab, inventory, notify, onClose) {
    this.fab = fab;
    this.inventory = inventory;
    this.notify = notify;
    this.onClose = onClose;
    this.visible = false;
    this.tab = 'SHIP';

    this.root = document.createElement('div');
    this.root.style.cssText = plasticPanel([
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:32', 'display:none', 'width:min(520px,94vw)', 'max-height:84vh',
      'overflow-y:auto', 'padding:14px 16px', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none',
    ].join(';'));

    this.title = document.createElement('div');
    this.title.style.cssText = 'font-size:14px;letter-spacing:0.12em;color:#d0a060;margin-bottom:2px;';
    this.title.textContent = 'FABRICATION BENCH';
    this.subLine = document.createElement('div');
    this.subLine.style.cssText = 'font-size:10px;color:#7d6038;margin-bottom:6px;line-height:1.5;';
    this.tabs = document.createElement('div');
    this.tabs.style.cssText = 'display:flex;flex-wrap:wrap;gap:5px;margin-bottom:10px;';
    this.list = document.createElement('div');
    this.root.append(this.title, hazardBar('60%'), this.subLine, this.tabs, this.list);
    document.body.appendChild(this.root);
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });
    framePanel(this.root, { seed: 29 });
  }

  _tap(el, fn) {
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    el.addEventListener('click', h);
    el.addEventListener('touchend', h, { passive: false });
  }

  _chip(label, active, fn) {
    const c = document.createElement('div');
    c.textContent = label;
    c.style.cssText = plasticButton('padding:4px 8px;font-size:8px;min-width:0;letter-spacing:0.14em;'
      + (active ? 'color:#e0b070;box-shadow:inset 0 1px 4px #000000d0, 0 0 6px #b0804055;' : 'opacity:0.62;'));
    this._tap(c, fn);
    return c;
  }

  /**
   * An item on a socket plate, the same way the hold manifest racks them —
   * a bare sprite on a dark panel reads as a stain, and the plate is what makes
   * it read as a part sitting in a tray.
   */
  _icon(id, px) {
    const socket = document.createElement('div');
    socket.style.cssText = `position:relative;flex:0 0 ${px}px;width:${px}px;height:${px}px;`
      + 'image-rendering:pixelated;'
      + `background:url("${platePNG(24, 24, 'button', 5)}") center/100% 100% no-repeat;`;
    const def = ITEMS[id];
    const d = document.createElement('div');
    d.style.cssText = 'position:absolute;inset:3px;image-rendering:pixelated;'
      + `background:url("${itemIconPNG(def?.category ?? 'trade', id, def?.subCategory)}") center/100% 100% no-repeat;`;
    socket.appendChild(d);
    return socket;
  }

  /** One job card: output, ingredients with have/need, risk, RUN. */
  _recipeRow(r) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:flex-start;gap:9px;padding:7px 2px;'
      + 'border-bottom:1px solid #2a2a36;' + (r.can ? '' : 'opacity:0.62;');
    row.appendChild(this._icon(r.out, 36));

    const mid = document.createElement('div');
    mid.style.cssText = 'flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:2px;';
    const n = document.createElement('div');
    n.textContent = `${r.name}  →  ${r.qty}× ${r.outName}`;
    n.style.cssText = 'font-size:11px;color:#c09050;letter-spacing:0.05em;';
    const ing = document.createElement('div');
    ing.style.cssText = 'font-size:9px;line-height:1.5;';
    // have/need per input, the short ones in warning red — this line is the
    // whole reason the panel exists
    for (const h of r.have) {
      const s = document.createElement('span');
      const ok = h.got >= h.n;
      s.textContent = `${h.name} ${h.got}/${h.n}`;
      s.style.cssText = `color:${ok ? '#8a7050' : '#aa4030'};margin-right:10px;`;
      ing.appendChild(s);
    }
    const note = document.createElement('div');
    note.textContent = r.note;
    note.style.cssText = 'font-size:9px;color:#5f4b2c;font-style:italic;line-height:1.45;';
    mid.append(n, ing, note);

    const right = document.createElement('div');
    right.style.cssText = 'flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-end;gap:4px;';
    const risk = document.createElement('div');
    // quote the SKILL-ADJUSTED figure, not the table's — engineering is not a
    // number anybody would otherwise see working
    const eff = (r.risk ?? 0) * (this.fab.prog?.bonus?.('craftRisk') ?? 1);
    risk.textContent = riskWord(eff);
    risk.style.cssText = `font-size:8px;letter-spacing:0.12em;color:${eff >= 0.13 ? '#aa6030' : '#70603a'};`;
    const btn = document.createElement('div');
    btn.textContent = 'RUN';
    btn.style.cssText = plasticButton('padding:5px 13px;font-size:9px;min-width:0;'
      + (r.can ? 'color:#e0b070;' : 'opacity:0.5;'));
    this._tap(btn, () => {
      if (!r.can) { this.notify('THE BENCH WILL NOT START A JOB IT CANNOT FINISH.'); return; }
      this.fab.craft(r.id);
      this._rebuild();
    });
    right.append(risk, btn);

    row.append(mid, right);
    return row;
  }

  /** One STRIP row: what you'd lose, what you'd get back. */
  _recycleRow(rec, y) {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:9px;padding:6px 2px;'
      + 'border-bottom:1px solid #2a2a36;';
    row.appendChild(this._icon(rec.id, 30));
    const mid = document.createElement('div');
    mid.style.cssText = 'flex:1 1 auto;min-width:0;';
    const n = document.createElement('div');
    n.textContent = `${rec.def.name} ×${rec.qty}`;
    n.style.cssText = 'font-size:11px;color:#c09050;';
    const s = document.createElement('div');
    s.textContent = `BREAKS DOWN INTO ${y.qty}× ${y.outName.toUpperCase()}`;
    s.style.cssText = 'font-size:9px;color:#70603a;letter-spacing:0.06em;';
    mid.append(n, s);
    const btn = document.createElement('div');
    btn.textContent = 'STRIP';
    btn.style.cssText = plasticButton('padding:5px 11px;font-size:9px;min-width:0;color:#c08050;');
    this._tap(btn, () => { this.fab.recycle(rec.id); this._rebuild(); });
    row.append(mid, btn);
    return row;
  }

  _rebuild() {
    const lvE = this.fab.prog?.level?.engineering ?? 0;
    const lvS = this.fab.prog?.level?.salvage ?? 0;
    this.subLine.textContent = `HOLD ${this.inventory.usedSlots.toFixed(1)}/${this.inventory.capacitySlots} SLOTS`
      + ` — ENGINEERING ${lvE}, SALVAGE ${lvS}`;

    this.tabs.textContent = '';
    for (const g of GROUPS) {
      this.tabs.appendChild(this._chip(g, this.tab === g, () => { this.tab = g; this._rebuild(); }));
    }
    this.tabs.appendChild(this._chip('STRIP', this.tab === 'STRIP', () => { this.tab = 'STRIP'; this._rebuild(); }));
    this.tabs.appendChild(this._chip('LEAVE BENCH', false, () => this.hide()));

    this.list.textContent = '';
    if (this.tab === 'STRIP') {
      let any = false;
      for (const rec of this.inventory.grouped()) {
        const y = this.fab.recycleYield(rec.id);
        if (!y) continue;
        any = true;
        this.list.appendChild(this._recycleRow(rec, y));
      }
      if (!any) this.list.appendChild(this._empty('NOTHING IN THE HOLD IS WORTH THE TIME IT WOULD TAKE.'));
      return;
    }
    const rows = this.fab.list().filter((r) => r.group === this.tab);
    // affordable first: the useful half of a long board should be at the top
    rows.sort((a, b) => (b.can ? 1 : 0) - (a.can ? 1 : 0));
    for (const r of rows) this.list.appendChild(this._recipeRow(r));
    if (!rows.length) this.list.appendChild(this._empty('NO JOBS ON THIS CARD.'));
  }

  _empty(text) {
    const d = document.createElement('div');
    d.textContent = text;
    d.style.cssText = 'font-size:10px;color:#7d6038;line-height:1.6;padding:8px 0;';
    return d;
  }

  open() {
    if (!this.visible) showScrim(true);
    this.visible = true;
    this._rebuild();
    this.root.style.display = 'block';
  }

  hide() {
    if (this.visible) showScrim(false);
    this.visible = false;
    this.root.style.display = 'none';
    this.onClose?.();
  }
}
