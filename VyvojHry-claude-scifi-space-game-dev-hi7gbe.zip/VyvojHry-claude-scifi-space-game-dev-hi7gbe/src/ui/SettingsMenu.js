/**
 * SettingsMenu — a DOM overlay of amber slider "bars" and toggle buttons,
 * generated from SETTING_FIELDS. DOM (not the 480×270 canvas) so it's
 * pixel-crisp text, works identically with mouse and touch, and the range
 * inputs get native drag behaviour on every device.
 *
 * Opened from the pause screen (and a gear button); writes straight to the
 * Settings store, which every system reads live.
 */
import { Settings, SETTING_FIELDS } from '../core/Settings.js';
import { PALETTE } from '../core/Constants.js';
import { plasticButton, plasticPanel, hazardBar, frameBackdrop, panelChrome } from './Chrome.js';

const C = {
  amber: PALETTE.HUD_AMBER[1],
  amberHi: PALETTE.HUD_AMBER[2],
  dim: PALETTE.HUD_SECONDARY[0],
  border: PALETTE.HUD_BORDER[1],
  panel: PALETTE.HUD_PANEL_BG[0],
  bg: '#000003',
};

export class SettingsMenu {
  /** @param {() => void} onClose called when the player leaves the menu */
  constructor(onClose) {
    this.onClose = onClose;
    this.visible = false;
    this._injectStyle();

    this.root = document.createElement('div');
    this.root.id = 'settings-menu';
    this.root.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:40', 'display:none',
      `background:${C.bg}`, 'flex-direction:column', 'align-items:center',
      'justify-content:center', 'gap:10px', 'padding:20px',
      "font-family:'Courier New',monospace", 'letter-spacing:0.15em',
      'text-transform:uppercase', 'overflow-y:auto', 'touch-action:pan-y',
    ].join(';');

    const title = document.createElement('div');
    title.textContent = 'SETTINGS';
    title.style.cssText = `color:${C.amberHi};font-size:22px;letter-spacing:0.4em;margin-bottom:2px;`;
    this.root.appendChild(title);
    this.root.appendChild(hazardBar('min(440px,92vw)'));

    const panel = document.createElement('div');
    // moulded pixel-art plate (generated texture — matches the game chrome)
    panel.style.cssText = plasticPanel([
      'display:flex', 'flex-direction:column', 'gap:12px', 'width:min(440px,92vw)',
      'padding:18px 20px',
    ].join(';'));
    this.root.appendChild(panel);

    this.controls = new Map();
    let lastSection = null;
    for (const field of SETTING_FIELDS) {
      if (field.section && field.section !== lastSection) {
        lastSection = field.section;
        const h = document.createElement('div');
        h.textContent = `— ${field.section} —`;
        h.style.cssText = 'color:#8a6030;font-size:10px;letter-spacing:0.3em;margin-top:4px;';
        panel.appendChild(h);
      }
      panel.appendChild(this._field(field));
    }

    // buttons row
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:12px;margin-top:8px;';
    row.appendChild(this._button('RESET', () => { Settings.reset(); this._syncAll(); }));
    row.appendChild(this._button('DONE', () => this.hide(), true));
    this.root.appendChild(row);

    document.body.appendChild(this.root);

    frameBackdrop(this.root, { skySeed: 53 });
    // root is already overflow-y:auto + pan-y, so only the button and Escape
    panelChrome(this.root, () => this.hide(), { scroll: false, isOpen: () => this.visible });
  }

  _injectStyle() {
    if (document.getElementById('settings-style')) return;
    const s = document.createElement('style');
    s.id = 'settings-style';
    // amber range track + thumb, no rounded corners (house style)
    s.textContent = `
      #settings-menu input[type=range]{-webkit-appearance:none;appearance:none;
        width:180px;height:10px;background:${C.bg};border:1px solid ${C.border};outline:none;}
      #settings-menu input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;
        width:14px;height:20px;background:${C.amber};cursor:pointer;border:0;}
      #settings-menu input[type=range]::-moz-range-thumb{width:14px;height:20px;
        background:${C.amber};cursor:pointer;border:0;border-radius:0;}
      #settings-menu input[type=range]::-moz-range-track{height:10px;background:${C.bg};}
    `;
    document.head.appendChild(s);
  }

  _field(field) {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:12px;';
    const label = document.createElement('div');
    label.textContent = field.label;
    label.style.cssText = `color:${C.dim};font-size:12px;`;
    wrap.appendChild(label);

    /**
     * The sub-label under a row. Every field type gets one — it was built
     * inside the `select` branch only, so the notes on CRT STRENGTH, HEAD BOB,
     * SHIP AMBIENCE and EFFECTS were written, stored and silently dropped.
     */
    const note = document.createElement('div');
    // Sits UNDER its row, not tucked up into it. The original -2px top margin
    // was tuned against the taller select rows and pulled the note into the
    // slider track on every range field.
    note.style.cssText = `color:${C.dim};font-size:9px;letter-spacing:0.16em;`
      + 'text-align:right;margin:2px 0 4px;opacity:0.85;line-height:1.2;';

    if (field.type === 'range') {
      const right = document.createElement('div');
      right.style.cssText = 'display:flex;align-items:center;gap:10px;';
      const input = document.createElement('input');
      input.type = 'range';
      input.min = field.min; input.max = field.max; input.step = field.step;
      input.value = Settings.get(field.key);
      const val = document.createElement('div');
      val.style.cssText = `color:${C.amber};font-size:12px;min-width:48px;text-align:right;`;
      /**
       * Reads the STORE, not the input.
       *
       * It used to read `input.value`, and `_syncAll` painted before it wrote
       * the new value into the input — so after RESET, or after anything else
       * changed a setting from outside this panel, every slider's thumb moved
       * and every number beside it still showed the old figure. A readout whose
       * source of truth is the widget it sits next to can always disagree with
       * the thing both of them are supposed to be describing.
       */
      const paint = () => {
        input.value = Settings.get(field.key);
        val.textContent = field.fmt(Number(Settings.get(field.key)));
        note.textContent = field.note ? field.note() : '';
      };
      paint();
      input.addEventListener('input', () => {
        Settings.set(field.key, Number(input.value));
        paint();
      });
      right.appendChild(input); right.appendChild(val);
      wrap.appendChild(right);
      this.controls.set(field.key, { input, paint });
    } else if (field.type === 'toggle') {
      const btn = document.createElement('button');
      const paint = () => {
        const on = Settings.get(field.key);
        btn.textContent = on ? 'ON' : 'OFF';
        btn.style.color = on ? C.amberHi : C.dim;
        note.textContent = field.note ? field.note() : '';
      };
      btn.style.cssText = plasticButton([
        'font-family:inherit', 'font-size:12px', 'letter-spacing:0.2em',
        'padding:5px 16px', 'min-width:60px', 'min-height:32px',
      ].join(';'));
      btn.addEventListener('click', () => { Settings.set(field.key, !Settings.get(field.key)); paint(); });
      paint();
      wrap.appendChild(btn);
      this.controls.set(field.key, { input: btn, paint });
    } else if (field.type === 'select') {
      // A click-through stepper, not a native <select>. A dropdown is the one
      // widget on this screen that would render as an OS-styled white rectangle
      // and break the bulkhead look completely; a two-arrow stepper is also the
      // right idiom for the hardware this HUD is pretending to be, and it needs
      // no tap-outside handling on touch.
      const right = document.createElement('div');
      right.style.cssText = 'display:flex;align-items:center;gap:6px;';
      const val = document.createElement('div');
      val.style.cssText = `color:${C.amberHi};font-size:11px;letter-spacing:0.08em;`
        + 'min-width:150px;text-align:center;';
      const step = (dir) => {
        const opts = field.options;
        const at = Math.max(0, opts.findIndex((o) => o.value === Settings.get(field.key)));
        Settings.set(field.key, opts[(at + dir + opts.length) % opts.length].value);
        paint();
      };
      const arrow = (glyph, dir) => {
        const b = document.createElement('button');
        b.textContent = glyph;
        b.style.cssText = plasticButton([
          `color:${C.amber}`, 'font-family:inherit', 'font-size:12px',
          'padding:5px 9px', 'min-width:32px', 'min-height:32px',
        ].join(';'));
        b.addEventListener('click', () => step(dir));
        return b;
      };
      const paint = () => {
        const cur = field.options.find((o) => o.value === Settings.get(field.key));
        val.textContent = cur?.label ?? '—';
        if (field.note) {
          note.textContent = field.note();
          // amber when the pending value differs from what is actually running
          note.style.color = note.textContent.includes('RELOAD') ? C.amberHi : C.dim;
        }
      };
      right.append(arrow('<', -1), val, arrow('>', +1));
      wrap.appendChild(right);
      paint();
      this.controls.set(field.key, { input: val, paint });
    }

    if (field.note) {
      const col = document.createElement('div');
      col.style.cssText = 'display:flex;flex-direction:column;';
      col.append(wrap, note);
      return col;
    }
    return wrap;
  }

  _button(text, onClick, primary = false) {
    const b = document.createElement('button');
    b.textContent = text;
    b.style.cssText = plasticButton([
      `color:${primary ? C.amberHi : C.amber}`, "font-family:'Courier New',monospace",
      'font-size:13px', 'letter-spacing:0.25em', 'padding:8px 22px',
      'min-height:40px',
    ].join(';'));
    b.addEventListener('click', onClick);
    return b;
  }

  /** Repaint every row from the store. `paint` writes the widget too. */
  _syncAll() {
    for (const { paint } of this.controls.values()) paint();
  }

  show() { this.visible = true; this._syncAll(); this.root.style.display = 'flex'; }
  hide() { this.visible = false; this.root.style.display = 'none'; this.onClose?.(); }
  toggle() { this.visible ? this.hide() : this.show(); }
}
