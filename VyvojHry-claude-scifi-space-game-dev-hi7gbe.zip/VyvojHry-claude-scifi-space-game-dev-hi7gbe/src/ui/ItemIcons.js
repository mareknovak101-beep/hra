/**
 * ITEM ICONS — one recognisable object per item, generated.
 *
 * WHAT WAS WRONG. The previous generator keyed on the nine top-level
 * CATEGORIES, so every consumable in the game was the same tin and every
 * component was the same chip: three hundred items resolved to nine
 * silhouettes, distinguished only by a hashed tint. A stew pack, a water
 * pouch, a chelation dose and a fuel cell were the same picture in four
 * shades of tan, and no amount of new content was going to fix that — adding
 * items to a nine-shape system only makes the sameness louder.
 *
 * WHAT THIS DOES INSTEAD. The silhouette comes from the SUBCATEGORY, of which
 * there are thirty-odd and which is exactly the level at which things stop
 * looking alike: `food` is a tin, `drink` is a pouch, `medical` is an ampoule,
 * `fuel` is a cell, `ore` is a lump, `crystal` is a shard, `records` is a
 * cartridge, `pistol` is a pistol. Then each item hashes its own id into a
 * base colour, a cap colour, a label band, and a wear pattern — so two rations
 * are both tins and are not the same tin.
 *
 * PIXEL RULES, same as everywhere else in this project: a 24×24 grid, hard
 * edges, no antialiasing, no gradients — the shading is three flat tones per
 * object (lit face, body, shadow face) plus a black outline. Nothing here is
 * allowed near the banned neon families; the palettes below are the muted
 * on-palette sets the rest of the game uses.
 */

/** Icon grid. Small on purpose: these are read at 24-32px in a grid cell. */
export const ICON_S = 24;

/**
 * Base colour sets per subcategory. An item picks one by hash, so a family
 * reads as a family without every member being identical.
 */
const PALETTES = {
  food: [[168, 138, 78], [150, 122, 70], [186, 160, 104], [140, 118, 82]],
  drink: [[96, 122, 138], [120, 138, 146], [86, 106, 122], [140, 152, 150]],
  medical: [[196, 190, 178], [174, 178, 172], [156, 168, 170], [188, 172, 156]],
  fuel: [[122, 96, 60], [138, 110, 62], [104, 92, 74], [146, 120, 74]],
  oxygen: [[92, 116, 140], [104, 128, 148], [80, 100, 124], [116, 136, 152]],
  equipment: [[120, 124, 118], [136, 132, 116], [104, 110, 106], [144, 138, 124]],
  ore: [[128, 116, 100], [110, 102, 96], [146, 128, 100], [96, 92, 92]],
  alloy: [[142, 146, 150], [124, 130, 136], [158, 158, 156], [110, 118, 126]],
  mineral: [[150, 132, 96], [128, 124, 112], [166, 148, 110], [116, 112, 104]],
  crystal: [[124, 138, 152], [138, 128, 156], [116, 148, 144], [150, 146, 168]],
  gas: [[96, 120, 116], [110, 116, 132], [88, 104, 112], [120, 130, 128]],
  salvage: [[112, 106, 98], [126, 114, 96], [98, 100, 104], [134, 122, 104]],
  biological: [[112, 128, 96], [126, 132, 104], [96, 114, 92], [136, 138, 112]],
  faction: [[104, 96, 108], [92, 104, 116], [116, 100, 96], [88, 96, 104]],
  electronics: [[86, 110, 128], [96, 120, 116], [78, 96, 112], [104, 116, 124]],
  ship: [[118, 122, 128], [104, 112, 120], [130, 130, 128], [96, 104, 112]],
  spares: [[124, 118, 108], [110, 116, 120], [136, 126, 108], [104, 108, 112]],
  fitting: [[108, 120, 132], [120, 126, 118], [96, 108, 120], [128, 128, 124]],
  suit: [[150, 142, 122], [132, 130, 124], [162, 150, 128], [124, 128, 130]],
  hand: [[120, 124, 130], [104, 112, 92], [148, 118, 74], [92, 96, 104]],
  pistol: [[92, 96, 104], [80, 84, 92], [104, 100, 96], [72, 78, 86]],
  rifle: [[86, 90, 98], [76, 82, 90], [98, 94, 88], [70, 76, 84]],
  ammo: [[146, 124, 82], [128, 112, 84], [158, 136, 92], [116, 106, 88]],
  industrial: [[112, 100, 88], [124, 112, 90], [98, 94, 90], [132, 118, 92]],
  ancient: [[124, 102, 146], [92, 124, 124], [176, 166, 142], [110, 92, 122]],
  records: [[92, 116, 104], [104, 112, 122], [116, 120, 96], [82, 98, 96]],
  log: [[118, 110, 92], [104, 112, 108], [126, 118, 96], [96, 104, 110]],
  goods: [[152, 122, 82], [136, 96, 64], [116, 124, 100], [128, 130, 134]],
  bulk: [[140, 118, 84], [120, 112, 96], [150, 132, 96], [112, 108, 100]],
  restricted: [[104, 88, 84], [92, 84, 92], [116, 96, 84], [84, 84, 92]],
  effects: [[178, 168, 146], [116, 128, 146], [146, 118, 92], [130, 124, 112]],
};

/** Which drawn FORM a subcategory uses. This is the whole point of the module. */
const FORMS = {
  food: 'tin',
  drink: 'pouch',
  medical: 'ampoule',
  fuel: 'cell',
  oxygen: 'bottle',
  equipment: 'case',
  ore: 'lump',
  alloy: 'ingot',
  mineral: 'lump',
  crystal: 'shard',
  gas: 'flask',
  salvage: 'scrap',
  biological: 'jar',
  faction: 'relicplate',
  electronics: 'board',
  ship: 'module',
  spares: 'gear',
  fitting: 'coil',
  suit: 'patch',
  hand: 'tool',
  pistol: 'pistol',
  rifle: 'rifle',
  ammo: 'mag',
  industrial: 'cutter',
  ancient: 'idol',
  records: 'cartridge',
  // Recovered crew logs — a spooled reel, not another cartridge: the journal
  // treats them as a different kind of thing and the icon should too.
  log: 'reel',
  goods: 'crate',
  bulk: 'sack',
  restricted: 'lockbox',
  effects: 'card',
};

/** FNV-1a → 0..1, so an item's look never changes between sessions. */
function hash01(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return ((h >>> 0) % 100000) / 100000;
}

/** mulberry32 — the same deterministic stream the textures use. */
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** A tiny drawing surface with the three-tone discipline baked in. */
function painter(S) {
  const d = new Uint8ClampedArray(S * S * 4);
  const put = (x, y, c, a = 255) => {
    x |= 0; y |= 0;
    if (x < 0 || y < 0 || x >= S || y >= S || !c) return;
    const i = (y * S + x) * 4;
    if (a >= 255) { d[i] = c[0]; d[i + 1] = c[1]; d[i + 2] = c[2]; d[i + 3] = 255; return; }
    const t = a / 255;
    d[i] = d[i] * (1 - t) + c[0] * t;
    d[i + 1] = d[i + 1] * (1 - t) + c[1] * t;
    d[i + 2] = d[i + 2] * (1 - t) + c[2] * t;
    d[i + 3] = Math.max(d[i + 3], a);
  };
  const rect = (x, y, w, h, c) => {
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) put(x + i, y + j, c);
  };
  /**
   * A solid with a lit left face, a shadowed right face and a black keyline —
   * the one shading idiom every form here shares, which is what makes thirty
   * different objects still look like one set.
   */
  const body = (x, y, w, h, lit, dark, line) => {
    const split = Math.max(1, Math.round(w * 0.55));
    rect(x, y, split, h, lit);
    rect(x + split, y, w - split, h, dark);
    for (let j = -1; j <= h; j++) { put(x - 1, y + j, line); put(x + w, y + j, line); }
    for (let i = -1; i <= w; i++) { put(x + i, y - 1, line); put(x + i, y + h, line); }
  };
  const hline = (x0, x1, y, c) => { for (let x = x0; x <= x1; x++) put(x, y, c); };
  const vline = (x, y0, y1, c) => { for (let y = y0; y <= y1; y++) put(x, y, c); };
  return { d, put, rect, body, hline, vline };
}

const shade = (c, k) => [Math.min(255, c[0] * k), Math.min(255, c[1] * k), Math.min(255, c[2] * k)];

/**
 * Draw one item.
 *
 * Every form gets the same three tones and the same keyline; what differs is
 * the outline it fills and the two or three details that say what it IS. Kept
 * deliberately blunt — at 24 px a "detail" is three pixels, and the thing that
 * reads is the SILHOUETTE, so the shapes differ in proportion and profile
 * before they differ in decoration.
 */
function drawForm(p, form, C, R, feat) {
  const { body, rect, put, hline, vline } = p;
  const { base, lit, dark, line, cap, hi } = C;

  switch (form) {
    case 'tin': // food — squat cylinder with a rolled rim
      body(7, 8, 10, 12, lit, dark, line);
      hline(7, 16, 8, cap); hline(7, 16, 19, shade(dark, 0.7));
      if (feat.band) rect(7, 12, 10, 3, shade(base, 1.28));
      break;
    case 'pouch': // drink — soft bag, wider at the bottom, with a spout
      body(7, 9, 10, 11, lit, dark, line);
      rect(10, 5, 4, 4, cap);
      for (let i = -1; i <= 4; i++) { put(9, 5 + i, line); put(14, 5 + i, line); }
      hline(10, 13, 4, line);
      if (feat.band) hline(7, 16, 14, shade(base, 0.72));
      break;
    case 'ampoule': // medical — vial with a shoulder, a coloured dose and a crimp
      body(8, 8, 8, 12, lit, dark, line);
      rect(9, 13, 6, 6, cap);                    // the dose, visible through it
      rect(10, 4, 4, 4, shade(base, 0.82));      // neck
      for (let i = -1; i <= 4; i++) { put(9, 4 + i, line); put(14, 4 + i, line); }
      rect(9, 3, 6, 2, shade(cap, 1.1));         // crimp cap
      put(10, 10, hi); put(11, 10, hi);
      break;
    case 'cell': // fuel — blocky brick with terminals
      body(5, 8, 14, 11, lit, dark, line);
      rect(7, 6, 3, 2, cap); rect(14, 6, 3, 2, cap);
      hline(5, 18, 12, shade(dark, 0.7));
      if (feat.band) hline(5, 18, 15, shade(base, 1.3));
      break;
    case 'bottle': // oxygen — tall bottle with a valve and a neck ring
      body(8, 8, 8, 12, lit, dark, line);
      rect(10, 4, 4, 4, shade(base, 0.85));
      for (let i = -1; i <= 4; i++) { put(9, 4 + i, line); put(14, 4 + i, line); }
      rect(9, 7, 6, 1, cap);
      put(10, 3, cap); put(13, 3, cap);
      break;
    case 'case': // equipment — hinged case with a handle
      body(4, 9, 16, 10, lit, dark, line);
      hline(4, 19, 13, shade(dark, 0.6));
      rect(10, 6, 4, 3, base);
      for (let i = -1; i <= 3; i++) { put(9, 6 + i, line); put(14, 6 + i, line); }
      rect(15, 12, 3, 3, cap);
      break;
    case 'lump': { // ore / mineral — irregular blob, no straight edges
      const w = [3, 5, 7, 8, 8, 7, 6, 4];
      for (let r = 0; r < w.length; r++) {
        const hw = w[r] + (R() < 0.4 ? 1 : 0);
        const y = 8 + r;
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, y, x < 12 ? lit : dark);
        put(12 - hw - 1, y, line); put(12 + hw, y, line);
      }
      hline(9, 14, 7, line); hline(9, 14, 16, line);
      for (let i = 0; i < 5; i++) put(8 + ((R() * 9) | 0), 9 + ((R() * 6) | 0), hi);
      break;
    }
    case 'ingot': // alloy — trapezoid bar, cast and stamped
      for (let r = 0; r < 7; r++) {
        const hw = 4 + r;
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, 11 + r, x < 12 ? lit : dark);
        put(12 - hw - 1, 11 + r, line); put(12 + hw, 11 + r, line);
      }
      hline(8, 15, 10, line); hline(2, 21, 18, line);
      hline(9, 14, 12, shade(base, 1.35));
      break;
    case 'shard': // crystal — tall faceted spike
      for (let r = 0; r < 15; r++) {
        const hw = Math.max(1, Math.round(1 + r * 0.42));
        const y = 4 + r;
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, y, x < 12 ? lit : dark);
        put(12 - hw - 1, y, line); put(12 + hw, y, line);
      }
      hline(5, 18, 19, line);
      vline(12, 5, 17, shade(base, 1.4));
      break;
    case 'flask': // gas — round-bottom flask with a pressure collar
      for (let r = 0; r < 9; r++) {
        const hw = Math.round(6 * Math.sin((r / 8) * Math.PI * 0.85 + 0.35));
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, 11 + r, x < 12 ? lit : dark);
        put(12 - hw - 1, 11 + r, line); put(12 + hw, 11 + r, line);
      }
      rect(10, 5, 4, 6, shade(base, 0.9));
      for (let i = -1; i <= 6; i++) { put(9, 5 + i, line); put(14, 5 + i, line); }
      rect(9, 4, 6, 2, cap);
      break;
    case 'scrap': // salvage — bent plate with a torn edge
      body(5, 10, 14, 7, lit, dark, line);
      for (let x = 5; x < 19; x += 2) put(x, 9 + ((R() * 2) | 0), base);
      hline(5, 18, 13, shade(dark, 0.65));
      put(7, 11, hi); put(15, 15, hi);
      break;
    case 'jar': // biological — wide jar, sealed lid, something in it
      body(7, 9, 10, 11, lit, dark, line);
      rect(6, 6, 12, 3, cap);
      for (let i = -1; i <= 3; i++) { put(5, 6 + i, line); put(18, 6 + i, line); }
      rect(9, 13, 6, 5, shade(base, 0.72));
      break;
    case 'relicplate': // faction salvage — angular plate with a punched sigil
      body(5, 8, 14, 12, lit, dark, line);
      hline(5, 18, 11, shade(dark, 0.6));
      rect(10, 13, 4, 4, shade(base, 0.6));
      put(9, 9, cap); put(14, 9, cap);
      break;
    case 'board': // electronics — circuit card with an edge connector
      body(5, 7, 14, 12, lit, dark, line);
      for (let x = 7; x <= 17; x += 3) vline(x, 9, 15, shade(base, 1.3));
      hline(6, 17, 18, cap);
      rect(8, 10, 3, 3, shade(dark, 0.6));
      break;
    case 'module': // ship component — boxed unit with a face plate and studs
      body(4, 8, 16, 11, lit, dark, line);
      rect(6, 10, 6, 7, shade(base, 0.7));
      put(15, 11, cap); put(17, 11, cap); put(15, 16, cap); put(17, 16, cap);
      hline(4, 19, 14, shade(dark, 0.7));
      break;
    case 'gear': // spares — toothed ring
      for (let r = 0; r < 10; r++) {
        const hw = Math.round(6 * Math.sin((r / 9) * Math.PI));
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, 8 + r, x < 12 ? lit : dark);
        put(12 - hw - 1, 8 + r, line); put(12 + hw, 8 + r, line);
      }
      for (const [x, y] of [[11, 6], [11, 19], [5, 12], [18, 12]]) rect(x, y, 2, 2, base);
      rect(10, 11, 4, 4, shade(dark, 0.5));
      break;
    case 'coil': // fitting — wound coil on a core
      for (let y = 8; y <= 18; y += 2) { hline(7, 16, y, shade(base, 1.25)); hline(7, 16, y + 1, shade(base, 0.75)); }
      for (let j = -1; j <= 12; j++) { put(6, 7 + j, line); put(17, 7 + j, line); }
      hline(7, 16, 7, line); hline(7, 16, 20, line);
      vline(12, 8, 19, cap);
      break;
    case 'patch': // suit consumable — folded fabric square with a seal
      body(6, 9, 12, 10, lit, dark, line);
      hline(6, 17, 12, shade(dark, 0.7));
      vline(12, 9, 18, shade(dark, 0.7));
      rect(8, 10, 2, 2, cap); rect(14, 15, 2, 2, cap);
      break;
    case 'tool': // hand tool — head, shaft and a wrapped grip, canted so it is
      // not just a vertical bar: at this size a symmetric upright reads as a
      // post, and every tool in the game was coming out the same post.
      body(10, 4, 5, 5, lit, dark, line);        // working head
      body(11, 9, 3, 8, lit, dark, line);        // shaft
      rect(9, 16, 7, 5, cap);                    // grip
      hline(9, 15, 18, shade(dark, 0.6));
      put(9, 5, hi); put(15, 7, hi);
      break;
    case 'pistol': // sidearm — slide over a grip, unmistakable at this size
      body(6, 8, 13, 4, lit, dark, line);
      body(8, 12, 4, 7, lit, dark, line);
      rect(16, 9, 2, 2, cap);
      hline(6, 18, 10, shade(dark, 0.6));
      break;
    case 'rifle': // long gun — barrel, receiver, stock
      body(3, 9, 18, 3, lit, dark, line);
      rect(3, 8, 4, 5, shade(base, 0.85));
      body(9, 12, 3, 5, lit, dark, line);
      rect(17, 10, 4, 1, cap);
      break;
    case 'mag': // ammunition — box magazine with witness holes
      body(8, 6, 8, 14, lit, dark, line);
      for (let y = 9; y <= 17; y += 3) hline(9, 14, y, shade(dark, 0.55));
      rect(9, 4, 6, 2, cap);
      break;
    case 'cutter': // industrial weapon — emitter head on a short haft
      body(10, 10, 5, 10, lit, dark, line);
      rect(8, 5, 9, 5, shade(base, 1.15));
      for (let i = -1; i <= 5; i++) { put(7, 5 + i, line); put(17, 5 + i, line); }
      hline(9, 15, 4, cap);
      break;
    case 'idol': // ancient artifact — a form that is not machinery
      for (let r = 0; r < 13; r++) {
        const hw = Math.round(2 + 4 * Math.sin((r / 12) * Math.PI * 1.1));
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, 6 + r, x < 12 ? lit : dark);
        put(12 - hw - 1, 6 + r, line); put(12 + hw, 6 + r, line);
      }
      hline(9, 14, 5, line); hline(7, 16, 19, line);
      put(10, 10, cap); put(13, 10, cap);
      vline(12, 12, 16, shade(base, 1.4));
      break;
    case 'cartridge': // data — tape/data cartridge with a window and a label
      body(4, 8, 16, 11, lit, dark, line);
      rect(6, 10, 12, 4, shade(dark, 0.5));
      rect(8, 11, 3, 2, cap); rect(13, 11, 3, 2, cap);
      hline(4, 19, 16, shade(base, 1.25));
      break;
    case 'crate': // trade goods — banded shipping box
      body(4, 8, 16, 12, lit, dark, line);
      hline(4, 19, 13, shade(dark, 0.6));
      vline(11, 8, 19, shade(dark, 0.6));
      rect(5, 9, 3, 2, cap);
      break;
    case 'sack': // bulk — soft sack tied at the neck
      for (let r = 0; r < 11; r++) {
        const hw = Math.round(3 + 5 * Math.sin((r / 10) * Math.PI * 0.9));
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, 9 + r, x < 12 ? lit : dark);
        put(12 - hw - 1, 9 + r, line); put(12 + hw, 9 + r, line);
      }
      rect(10, 5, 4, 4, shade(base, 0.8));
      hline(9, 14, 9, cap);
      hline(7, 16, 20, line);
      break;
    case 'lockbox': // restricted — strapped box with a seal
      body(5, 9, 14, 10, lit, dark, line);
      vline(9, 9, 18, cap); vline(15, 9, 18, cap);
      rect(11, 12, 3, 3, shade(dark, 0.5));
      hline(5, 18, 8, shade(base, 1.2));
      break;
    case 'reel': { // recovered log — tape reel on a hub
      for (let r = 0; r < 13; r++) {
        const hw = Math.round(7 * Math.sin(((r + 0.5) / 13) * Math.PI));
        for (let x = 12 - hw; x < 12 + hw; x++) put(x, 6 + r, x < 12 ? lit : dark);
        put(12 - hw - 1, 6 + r, line); put(12 + hw, 6 + r, line);
      }
      // hub and spokes — the thing that says "reel" rather than "disc"
      rect(10, 11, 4, 3, shade(dark, 0.45));
      put(9, 9, cap); put(14, 9, cap); put(9, 15, cap); put(14, 15, cap);
      hline(6, 17, 12, shade(base, 1.3));
      break;
    }
    case 'card': // personal effects — a flat thing you would keep in a pocket
    default:
      body(6, 7, 12, 14, lit, dark, line);
      hline(7, 16, 10, shade(base, 1.3));
      hline(7, 14, 13, shade(dark, 0.6));
      hline(7, 15, 15, shade(dark, 0.6));
      break;
  }
}

const _cache = new Map();

/**
 * @param {string} subCategory drives the SILHOUETTE — see FORMS
 * @param {string} id          seeds colour, features and wear
 * @param {string} [category]  fallback when a subcategory has no form
 * @returns {string} data: URI, cached forever (icons never change)
 */
export function iconPNG(subCategory = 'goods', id = '', category = 'trade') {
  const key = `${subCategory}|${id}`;
  const hit = _cache.get(key);
  if (hit) return hit;

  const S = ICON_S;
  const form = FORMS[subCategory] ?? FORMS[category] ?? 'crate';
  const pal = PALETTES[subCategory] ?? PALETTES[category] ?? PALETTES.goods;
  const h = hash01(id || subCategory);
  const R = rng(Math.floor(h * 1e6) + 7);

  const baseRGB = pal[Math.floor(h * pal.length) % pal.length];
  // a small brightness step so two items on the same base are not identical
  const k = 0.9 + R() * 0.22;
  const base = baseRGB.map((v) => Math.min(228, v * k));
  const C = {
    base,
    lit: shade(base, 1.18),
    dark: shade(base, 0.66),
    line: [9, 8, 11],
    // The cap/accent: a warm or cold partner, chosen per item, never neon.
    cap: R() < 0.5 ? shade(base, 0.48) : [Math.min(210, base[0] * 1.1 + 26),
      Math.min(190, base[1] * 0.9 + 12), Math.min(170, base[2] * 0.7)],
    hi: shade(base, 1.5),
  };
  const feat = { band: R() < 0.55, wear: 2 + ((R() * 4) | 0) };

  const p = painter(S);
  // Contact shadow, so the object sits on the cell instead of floating in it.
  for (let x = 5; x < 19; x++) p.put(x, 21, [0, 0, 0], x % 3 === 0 ? 70 : 110);
  drawForm(p, form, C, R, feat);
  // Wear: a few darker specks, the same trick every texture in the game uses to
  // stop a flat fill reading as plastic.
  for (let i = 0; i < feat.wear; i++) {
    p.put(5 + ((R() * 14) | 0), 7 + ((R() * 12) | 0), shade(base, 0.5));
  }

  const cv = document.createElement('canvas');
  cv.width = S; cv.height = S;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(S, S);
  img.data.set(p.d);
  ctx.putImageData(img, 0, 0);
  const uri = cv.toDataURL();
  _cache.set(key, uri);
  return uri;
}

/** How many distinct silhouettes exist — asserted by the icon probe. */
export const FORM_COUNT = new Set(Object.values(FORMS)).size;
