/**
 * ENTRY VEIL — the ionised air between a star system and a landscape.
 *
 * WHY THIS EXISTS AT ALL. Committing to a landing used to swap the world under
 * the player in one frame: a planet hanging ahead in space became a heightfield
 * underneath, with nothing in between to explain it. It read as a jump cut
 * because it *was* one. The fix is not a slower swap — a slower swap is just a
 * longer cut — it is something opaque in front of the swap, so the frame where
 * the world changes is a frame the player cannot see through.
 *
 * An atmospheric entry hands us that for free, because a real one already has
 * it: below the interface the shock layer ionises and the ship flies inside a
 * lit envelope of its own making, seeing nothing but plasma. So the veil is not
 * a wipe borrowed from a menu, it is the thing that would actually be there.
 * It closes over the starfield, the terrain goes up behind it, and when it
 * thins the ground has been under the hull all along.
 *
 * The ascent runs the same envelope backwards, for the same reason.
 *
 * DRAWN AS PIXEL ART, on the fixed 480×270 UI grid with the rest of the chrome
 * (context/01 pillar 3): chunky blocks, a quantised palette ramp, and ordered
 * 4×4 Bayer stipple at every band boundary. No smooth gradient anywhere — the
 * softness you read in it is dithered coverage, not interpolation.
 */
import { RENDER } from '../core/Constants.js';

const W = RENDER.UI_WIDTH;
const H = RENDER.UI_HEIGHT;

/** context/01 §3, verbatim. */
const BAYER = [
  0, 8, 2, 10,
  12, 4, 14, 6,
  3, 11, 1, 9,
  15, 7, 13, 5,
];

/**
 * The plasma ramp, coolest to hottest.
 *
 * Sampled from the sanctioned families (WARNING_RED → AMBER_MACHINE) and topped
 * with a hot bone white rather than a yellow, because the hottest part of a
 * shock layer is the part with the least colour left in it. Nothing here is
 * saturated enough to read as neon; the brightest entry is still a dirty cream.
 */
const RAMP = [
  [0.24, 0.06, 0.04],
  [0.42, 0.09, 0.06],
  [0.54, 0.13, 0.08],
  [0.67, 0.24, 0.09],
  [0.78, 0.40, 0.13],
  [0.86, 0.56, 0.20],
  [0.91, 0.71, 0.36],
  [0.94, 0.85, 0.62],
];

function ramp(x) {
  const i = Math.max(0, Math.min(RAMP.length - 1, Math.round(x * (RAMP.length - 1))));
  return RAMP[i];
}

/** Deterministic per-index hash — the streak field has to be stable frame to frame. */
function h1(n) {
  let x = Math.imul(n ^ 0x9e37, 0x85eb) ^ (n >>> 5);
  x = Math.imul(x ^ (x >>> 7), 0xc2b2) >>> 0;
  return (x & 0xffff) / 0xffff;
}

/** How many streaks the envelope carries. Chosen against the 4096-quad batch. */
const STREAKS = 54;
const EMBERS = 64;

export class EntryVeil {
  constructor() {
    /**
     * The streak field, built once. Each streak is a column of plasma dragged
     * up past the glass; they are seeded rather than random per frame so the
     * envelope has continuity instead of boiling.
     */
    this.streaks = [];
    for (let i = 0; i < STREAKS; i++) {
      const a = h1(i * 3 + 1), b = h1(i * 3 + 2), c = h1(i * 3 + 3);
      this.streaks.push({
        // Biased toward the middle of the frame: the shock cone is brightest on
        // the axis the ship is flying down, and the corners of a windshield see
        // the thin edge of it.
        x: Math.round((0.5 + (a - 0.5) * 1.9) * W),
        w: 2 + Math.floor(b * 5) * 2,      // even widths only — chunky by construction
        speed: 90 + c * 260,
        len: 14 + Math.floor(a * b * 62),
        heat: 0.35 + c * 0.6,
        phase: b * 400,
      });
    }
    this.embers = [];
    for (let i = 0; i < EMBERS; i++) {
      const a = h1(900 + i * 2), b = h1(901 + i * 2);
      this.embers.push({ x: a, drift: (b - 0.5) * 0.5, speed: 150 + b * 320, phase: a * 600 });
    }
  }

  /**
   * @param {import('../rendering/PixelRenderer.js').PixelRenderer} pix
   * @param {number} amount   0 clear → 1 fully enveloped
   * @param {number} time     seconds, for the flow
   * @param {number} heat     0..1+ skin temperature; drives how white it burns
   * @param {boolean} up      true on an ascent — the flow runs the other way
   */
  render(pix, amount, time, heat = 0.5, up = false) {
    const a = Math.max(0, Math.min(1, amount));
    if (a <= 0.002) return;
    // Quantised, like every other alpha in this game: eight steps, so the
    // envelope thickens in visible stages rather than sliding.
    const q = Math.round(a * 8) / 8;
    const hot = Math.max(0, Math.min(1, heat));

    // ---- 1. THE ENVELOPE. One flat wash, not a gradient: uniform translucency
    // is a fog, and a fog is the honest thing to put between two worlds.
    const base = ramp(0.10 + hot * 0.22);
    pix.rect(0, 0, W, H, [base[0], base[1], base[2], q * 0.93]);

    // ---- 2. THE SHOCK FRONT. Where the air is being compressed — off the nose
    // on the way down, off the tail on the way up. Discrete bands, each a
    // quantised step brighter than the last, with a Bayer stipple row along
    // every boundary so the steps interlock instead of banding.
    const bands = 11;
    const bandH = 9;
    for (let i = 0; i < bands; i++) {
      const f = i / (bands - 1);
      const y = up ? i * bandH : H - (i + 1) * bandH;
      const lit = (1 - f) ** 1.4;
      const col = ramp(0.30 + lit * (0.45 + hot * 0.30));
      const al = q * lit * (0.42 + hot * 0.34);
      if (al < 0.02) continue;
      pix.rect(0, y, W, bandH, [col[0], col[1], col[2], Math.round(al * 8) / 8]);
      // Boundary stipple: 8×3 cells thresholded against the ordered matrix, so
      // the edge between two bands dissolves in pixels rather than in alpha.
      const sy = up ? y + bandH - 3 : y;
      const cells = Math.ceil(W / 8);
      for (let cx = 0; cx < cells; cx++) {
        const th = BAYER[(i & 3) * 4 + (cx & 3)] / 16;
        if (th > lit * 0.9) continue;
        pix.rect(cx * 8, sy, 8, 3, [col[0], col[1], col[2], Math.round(al * 6) / 8]);
      }
    }

    // ---- 3. STREAKS. The envelope is not still: it is being dragged past the
    // glass at flight speed, and that motion is the only cue that the ship is
    // going somewhere while the view is closed.
    for (const s of this.streaks) {
      const span = H + s.len + 40;
      let y = ((s.phase + time * s.speed * (0.5 + a * 0.9)) % span);
      y = up ? y - s.len : span - y - s.len;
      const col = ramp(0.46 + s.heat * (0.42 + hot * 0.34));
      const al = Math.round(q * (0.42 + s.heat * 0.55) * 8) / 8;
      if (al < 0.02) continue;
      // Broken into 4px segments that thin out along the tail — a solid bar
      // would read as a UI element, a broken one reads as burning gas.
      for (let seg = 0; seg < s.len; seg += 4) {
        const f = seg / s.len;
        if (BAYER[((seg >> 2) & 3) * 4 + ((s.x >> 1) & 3)] / 16 > 1 - f) continue;
        pix.rect(s.x, Math.round(y + seg), s.w, 4,
          [col[0], col[1], col[2], al * (1 - f * 0.7)]);
      }
    }

    // ---- 4. EMBERS. Flecks of ablated plating going past, which is the detail
    // that sells "this is costing the hull something".
    const eCol = ramp(0.72 + hot * 0.28);
    for (const e of this.embers) {
      const span = H + 30;
      let y = (e.phase + time * e.speed * (0.4 + a)) % span;
      y = up ? y - 15 : span - y - 15;
      const x = Math.round((e.x + e.drift * (y / H)) * W);
      const al = Math.round(q * 0.9 * 8) / 8;
      if (al < 0.02) continue;
      pix.rect(x, Math.round(y), 2, 3, [eCol[0], eCol[1], eCol[2], al]);
    }

    // ---- 5. GLASS. The helmet/windshield in front of all of it picks up the
    // light: a couple of lit scratches and a bloom in the upper corners, so the
    // plasma reads as OUTSIDE rather than as a filter over the lens.
    const gCol = ramp(0.80);
    const ga = Math.round(q * 0.28 * 8) / 8;
    if (ga >= 0.02) {
      for (let i = 0; i < 7; i++) {
        const sx = Math.round(h1(2100 + i) * W);
        const sw = 8 + Math.floor(h1(2200 + i) * 34);
        const sy = Math.round(h1(2300 + i) * H);
        pix.rect(sx, sy, sw, 1, [gCol[0], gCol[1], gCol[2], ga]);
      }
      // Corner bloom, in stepped blocks — a real gradient here would be the one
      // smooth thing in the frame and it would show.
      for (let i = 0; i < 5; i++) {
        const s = 44 - i * 8;
        const al = Math.round(q * (0.05 + i * 0.028) * 8) / 8;
        if (al < 0.02) continue;
        const yy = up ? H - s : 0;
        pix.rect(0, yy, s, s, [gCol[0], gCol[1], gCol[2], al]);
        pix.rect(W - s, yy, s, s, [gCol[0], gCol[1], gCol[2], al]);
      }
    }
  }
}
