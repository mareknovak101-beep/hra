/**
 * TouchControls — mobile overlay per context/05 §7: floating dual virtual
 * joysticks (left half = MOVE, right half = LOOK) plus a bottom button strip
 * that swaps between walking and flight sets. DOM-based so it never touches
 * the 480×270 buffer; all targets ≥ 44px (context/07 checklist).
 *
 * Enabled when Constants.isMobile() or the page is opened with ?touch=1.
 */
import { PALETTE, MOBILE } from '../core/Constants.js';
import { plasticButton } from './Chrome.js';

// spec values from context/05 §7 — compact so they clear the HUD panels
const JOY = {
  baseRadius: 38,
  knobRadius: 15,
  deadZone: 0.12,
  color: PALETTE.HUD_AMBER[0], // #b08040
  opacityIdle: 0.28,
  opacityActive: 0.75,
};
const LOOK_SPEED = 9; // px of synthetic mouse delta per unit deflection per frame @60

class VirtualJoystick {
  /**
   * @param {HTMLElement} zone half-screen touch zone the stick floats in
   * @param {boolean} [silent] draw nothing at all — used for the attitude control,
   *   which the owner asked to be invisible. The region still works exactly the
   *   same; there is simply no ring or knob painted at any point.
   */
  constructor(zone, silent = false) {
    this.silent = silent;
    this.zone = zone;
    this.active = false;
    this.value = [0, 0]; // normalized [-1..1, -1..1], +y = down (screen space)
    this.touchId = null;

    this.base = document.createElement('div');
    this.base.style.cssText = [
      'position:absolute', `width:${JOY.baseRadius * 2}px`, `height:${JOY.baseRadius * 2}px`,
      `border:2px solid ${JOY.color}`, 'border-radius:50%',
      `opacity:${JOY.opacityIdle}`, 'display:none', 'pointer-events:none',
      'transform:translate(-50%,-50%)',
    ].join(';');
    this.knob = document.createElement('div');
    this.knob.style.cssText = [
      'position:absolute', `width:${JOY.knobRadius * 2}px`, `height:${JOY.knobRadius * 2}px`,
      `background:${JOY.color}`, 'border-radius:50%',
      'transform:translate(-50%,-50%)', 'left:50%', 'top:50%',
    ].join(';');
    this.base.appendChild(this.knob);
    zone.appendChild(this.base);

    zone.addEventListener('touchstart', (e) => {
      if (this.touchId !== null) return;
      const t = e.changedTouches[0];
      this.touchId = t.identifier;
      this.cx = t.clientX;
      this.cy = t.clientY;
      this.base.style.left = `${this.cx}px`;
      this.base.style.top = `${this.cy}px`;
      if (!this.silent) {
        this.base.style.display = 'block';
        this.base.style.opacity = JOY.opacityActive;
      }
      this.active = true;
      e.preventDefault();
    }, { passive: false });

    const track = (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier !== this.touchId) continue;
        const dx = (t.clientX - this.cx) / JOY.baseRadius;
        const dy = (t.clientY - this.cy) / JOY.baseRadius;
        const len = Math.hypot(dx, dy);
        const capped = len > 1 ? 1 / len : 1;
        let vx = dx * capped, vy = dy * capped;
        if (Math.hypot(vx, vy) < JOY.deadZone) { vx = 0; vy = 0; }
        this.value[0] = vx;
        this.value[1] = vy;
        this.knob.style.left = `${50 + vx * 38}%`;
        this.knob.style.top = `${50 + vy * 38}%`;
        e.preventDefault();
      }
    };
    zone.addEventListener('touchmove', track, { passive: false });

    const end = (e) => {
      for (const t of e.changedTouches) {
        if (t.identifier !== this.touchId) continue;
        this.touchId = null;
        this.active = false;
        this.value[0] = 0;
        this.value[1] = 0;
        this.base.style.display = 'none';
        this.knob.style.left = '50%';
        this.knob.style.top = '50%';
      }
    };
    zone.addEventListener('touchend', end);
    zone.addEventListener('touchcancel', end);
  }

  /** returns normalized [-1..1, -1..1] deflection */
  getInput() {
    return this.value;
  }
}

/**
 * ONE control geometry for both modes; only the labels change.
 *
 * Rebuilt AGAIN in session 17c, and the lesson from 17a is why: I had reduced the
 * right gutter from three columns to two and called the overlap solved, but the
 * owner's screenshot shows the real problem was never column count — it was that
 * twenty buttons cannot coexist with a HUD that owns the entire bottom third and
 * the top strip. Two changes:
 *
 * 1. FEWER BUTTONS. Twenty down to twelve. Cut: the four-key translation d-pad
 *    (strafing is a refinement the turn stick and throttle cover, and it sat
 *    directly on the DRIVE and SHIP panels), ORBIT (a desktop nicety — the hull
 *    cam does not need orbiting from a phone), SCAN (the proximity scanner is a
 *    walking tool; in the seat it does nothing), BOOST (fold into throttle — one
 *    fewer thing under the thumb that is already holding THR+), and STAND is kept
 *    because leaving the seat has to be reachable.
 *
 * 2. NOTHING IN THE MIDDLE. Every remaining button lives in the left or right
 *    gutter, in one of four short columns. The HUD's own inset (see main.js
 *    applyHudInset) reserves exactly those gutters, so a panel can never grow
 *    under a key again — which is what the screenshot shows happening to VITALS,
 *    DRIVE and SHIP.
 */
const CLUSTERS = {
  // LEFT gutter, upper third — the tap row, moved off the bottom strip entirely
  tapRow: 'left:1.5%;top:26%;flex-direction:column;gap:9px;',
  // LEFT gutter, lower — sustained holds under the left thumb
  primaryL: 'left:1.5%;bottom:23%;flex-direction:column;gap:9px;',
  // LEFT gutter, floor — roll, tapped while the left thumb still holds throttle
  secondaryL: 'left:1.5%;bottom:3.5%;flex-direction:row;gap:9px;',
  // RIGHT gutter, floor — the primary right-thumb position
  primaryR: 'right:1.5%;bottom:3.5%;flex-direction:column-reverse;gap:9px;align-items:flex-end;',
  // RIGHT gutter, above it — REPAIR, out of the way of a firing thumb
  midR: 'right:1.5%;bottom:24%;flex-direction:column-reverse;gap:9px;align-items:flex-end;',
  // TOP RIGHT — mode toggles, under the MENU chip that owns the corner
  util: 'right:1.5%;top:15%;flex-direction:column;gap:9px;align-items:flex-end;',
};

/*
 * WHAT IS LEFT IN THE GUTTERS, and what moved out (0.24.0).
 *
 * Everything that is a TAP — WARP, SCAN, LOCK, WPN, REPAIR, LAMP, the two panel
 * openers — moved into the HUD's own command bar along the bottom of the glass
 * (`HUD._commandBar`), where it is drawn in the HUD's chrome, works with a mouse
 * as well as a thumb, and prints its keybind. A tap needs no thumb rest and no
 * gutter; it just needs to be somewhere you can see and reach.
 *
 * What stays here is only what a tap CANNOT be: sustained holds that want a
 * thumb parked on them (FIRE, BRAKE, RUN, DUCK, roll) and the three mode
 * toggles that belong beside them.
 *
 * THE THROTTLE KEYS ARE GONE. THR+ and THR- were two of the biggest keys on
 * screen for a value that is a single scalar, and the HUD has drawn a throttle
 * QUADRANT at the left of the glass since 0.9. Dragging that gauge now sets the
 * throttle directly (see main.js throttlePointer) — the instrument became the
 * control, which is both fewer buttons and a better one.
 */
const WALK_BUTTONS = [
  { label: 'RUN', action: 'sprint', tap: false, cluster: 'primaryL', big: true },
  { label: 'DUCK', action: 'crouch', tap: false, cluster: 'primaryL', big: true },
  { label: 'USE', action: 'interact', tap: true, cluster: 'primaryR', big: true },
  { label: 'JUMP', action: 'jump', tap: true, cluster: 'primaryR' },
];

const FLIGHT_BUTTONS = [
  // left gutter floor: roll, the one sustained left-thumb input left
  { label: '⟲', action: 'left', tap: false, cluster: 'secondaryL', title: 'ROLL L' },
  { label: '⟳', action: 'right', tap: false, cluster: 'secondaryL', title: 'ROLL R' },
  // RIGHT gutter floor: FIRE alone at the corner, and bigger.
  //
  // It used to share `primaryR` with BRAKE, which stacked a 52px key directly on
  // top of the one your thumb rests on — the two most-pressed controls in a
  // fight, adjacent, with a 9px gap between them. BRAKE moves up to its own
  // cluster so a mis-hit costs nothing worse than a mis-hit.
  { label: 'FIRE', action: 'fire', tap: false, cluster: 'primaryR', big: true },
  { label: 'BRAKE', action: 'jump', tap: false, cluster: 'midR', big: true },
  // THE LANDING JETS. Held, not tapped, and on the right gutter beside BRAKE
  // because those are the two controls a descent is flown with. Without these
  // there is no vertical thrust on touch at all, which meant a mobile player
  // could enter an atmosphere and had no way to arrest the fall — the landing
  // was unwinnable rather than hard.
  { label: 'LIFT', action: 'strafeUp', tap: false, cluster: 'midR', title: 'VERTICAL JETS UP' },
  { label: 'DROP', action: 'strafeDown', tap: false, cluster: 'midR', title: 'VERTICAL JETS DOWN' },
  // top right: mode toggles
  { label: 'A/S', action: 'flightAssist', tap: true, cluster: 'util' },
  { label: 'VIEW', action: 'view', tap: true, cluster: 'util' },
  { label: 'STAND', action: 'crouch', tap: true, cluster: 'util' },
];

export class TouchControls {
  /** @param {import('../core/InputManager.js').InputManager} input */
  constructor(input) {
    this.input = input;
    this.mode = 'walk';
    this.visible = false;

    this.root = document.createElement('div');
    this.root.id = 'touch-ui';
    this.root.style.cssText =
      'position:fixed;inset:0;z-index:20;display:none;pointer-events:none;user-select:none;-webkit-user-select:none;';

    // left = MOVE, right = LOOK (context/05 §7); strip stays clear at the bottom
    this.leftZone = this._zone('0', '50%');
    this.rightZone = this._zone('50%', '50%');
    this.moveStick = new VirtualJoystick(this.leftZone);
    // SILENT. In the seat this stick IS the attitude control (see update()), and the
    // owner asked for the turn joystick to be invisible — so it paints nothing at
    // any point. On foot it is still look, where a ring appearing under the thumb is
    // useful, but one widget cannot be two things: silent wins, because a
    // free-floating ring is the thing that made the screen busy.
    this.lookStick = new VirtualJoystick(this.rightZone, true);
    // There is no separate attitude widget any more. It was a 92px dial competing
    // for the right gutter with FIRE, BRAKE and REPAIR, and it duplicated what the
    // right-half look region already does: in the seat that region now drives
    // attitude directly, so the whole right half of the screen is the turn control
    // and none of it is drawn.

    this.strip = document.createElement('div');
    this.strip.style.cssText = [
      'position:absolute', 'left:50%', 'bottom:6px', 'transform:translateX(-50%)',
      'display:flex', 'gap:6px', 'pointer-events:auto', 'touch-action:none',
      'flex-wrap:wrap', 'justify-content:center', 'max-width:64vw',
    ].join(';');
    this.root.appendChild(this.strip);

    document.body.appendChild(this.root);
    this._buildStrip();
    /** Canvas-rect bounds, set by main's layoutOverlay(). */
    this.bounds = null;

    // context/02 §10 mobile hygiene — touches are input, never page gestures
    document.addEventListener('contextmenu', (e) => { if (this.visible) e.preventDefault(); });
    document.addEventListener('touchmove', (e) => {
      if (!this.visible) return;
      // Do NOT swallow a drag that started inside a scrollable panel. This
      // blanket preventDefault is the reason touch scrolling never worked in any
      // window: `overflow-y:auto` and `touch-action:pan-y` were both set, but the
      // gesture was cancelled here before the browser could scroll anything.
      if (e.target instanceof Element && e.target.closest('.sr-scroll')) return;
      e.preventDefault();
    }, { passive: false });
  }

  /**
   * Confine the whole control layer to the canvas rectangle instead of the
   * viewport. Every cluster is positioned in percentages of this root, so
   * moving the root is enough to move all of them together.
   *
   * This matters because the canvas is letterboxed at some scales and fills the
   * screen at others (see fitCanvas): clusters pinned to the viewport drifted
   * relative to the HUD they are supposed to sit beside, and at fill scales they
   * landed on top of it.
   *
   * @param {{left:number,top:number,width:number,height:number}|null} r
   */
  setBounds(r) {
    this.bounds = r;
    const s = this.root.style;
    if (!r) { s.inset = '0'; s.width = s.height = ''; return; }
    s.inset = 'auto';
    s.left = `${Math.round(r.left)}px`;
    s.top = `${Math.round(r.top)}px`;
    s.width = `${Math.round(r.width)}px`;
    s.height = `${Math.round(r.height)}px`;
    // The stack is resolved against the root's measured height, so it has to be
    // recomputed whenever that height changes — rotate, resize, keyboard show.
    this._stackClusters();
  }

  _zone(left, width) {
    const el = document.createElement('div');
    el.style.cssText =
      `position:absolute;left:${left};top:0;width:${width};height:calc(100% - 80px);` +
      'pointer-events:auto;touch-action:none;';
    this.root.appendChild(el);
    return el;
  }

  /**
   * One control button wired to its action (hold or tap).
   *
   * Sized up from 46x34 / 60x44: the owner reported them hard to hit and too
   * close together, and 34px is under the 44px floor the checklist in context/07
   * asks for in the first place. Every target is now at least 48x40, the big ones
   * 68x50, and the clusters carry 10px gaps rather than 5-8.
   *
   * The sci-fi treatment is on top of Chrome's plasticButton: clipped corners on
   * the leading edge (a machined bezel, not a rounded app button), a warm inner
   * bevel, and a lit indicator bar down the left that brightens on press — so a
   * held control is visibly held even under a thumb.
   */
  _button(def) {
    const btn = document.createElement('div');
    if (def.title) btn.title = def.title;
    // 44px on BOTH axes is the context/07 floor, and the small keys were 48x40 —
    // wide enough, two pixels short in height. Caught by running the checklist
    // rather than by eye, which is the point of running it.
    const size = def.big
      ? 'min-width:68px;min-height:52px;font-size:12px;'
      : 'min-width:48px;min-height:44px;font-size:10px;';
    btn.style.cssText = plasticButton(
      `${size}padding:5px 9px;display:flex;align-items:center;justify-content:center;`
      + 'position:relative;opacity:0.86;letter-spacing:0.5px;'
      // corner cut top-left / bottom-right: reads as a bevelled instrument key
      + 'clip-path:polygon(6px 0,100% 0,100% calc(100% - 6px),calc(100% - 6px) 100%,0 100%,0 6px);'
      + 'box-shadow:inset 0 1px 0 rgba(255,226,178,0.20),inset 0 -2px 4px rgba(0,0,0,0.55),'
      + '0 2px 4px rgba(0,0,0,0.6);');
    // status bar down the leading edge — the "powered" tell
    const pip = document.createElement('div');
    pip.style.cssText = 'position:absolute;left:3px;top:20%;bottom:20%;width:2px;'
      + `background:${JOY.color};opacity:0.45;`;
    btn.appendChild(pip);
    const label = document.createElement('span');
    label.textContent = def.label;
    label.style.cssText = 'position:relative;';
    btn.appendChild(label);

    btn.addEventListener('touchstart', (e) => {
      btn.style.opacity = '1';
      pip.style.opacity = '1';
      if (def.tap) this.input.virtualPress(def.action);
      else this.input.setVirtualDown(def.action, true);
      e.preventDefault();
    }, { passive: false });
    const release = () => {
      btn.style.opacity = '0.86';
      pip.style.opacity = '0.45';
      if (!def.tap) this.input.setVirtualDown(def.action, false);
    };
    btn.addEventListener('touchend', release);
    btn.addEventListener('touchcancel', release);
    return btn;
  }

  _buildStrip() {
    this.strip.innerHTML = '';
    for (const el of this._clusterEls ?? []) el.remove();
    this._clusterEls = [];
    // Oversized keys, tracked so _stackClusters can drop them to the 44px floor
    // when a gutter runs out of height.
    this._bigBtns = [];
    const defs = this.mode === 'flight' ? FLIGHT_BUTTONS : WALK_BUTTONS;
    this.strip.style.display = 'none'; // the old centred strip is retired
    const groups = new Map();
    for (const def of defs) {
      if (!groups.has(def.cluster)) groups.set(def.cluster, []);
      groups.get(def.cluster).push(def);
    }
    for (const [name, list] of groups) {
      const box = document.createElement('div');
      box.style.cssText = 'position:absolute;display:flex;pointer-events:auto;touch-action:none;'
        + (CLUSTERS[name] ?? 'left:50%;bottom:6px;');
      for (const def of list) {
        const b = this._button(def);
        if (def.big) this._bigBtns.push(b);
        box.appendChild(b);
      }
      box.dataset.cluster = name;
      this.root.appendChild(box);
      this._clusterEls.push(box);
    }
    this._stackClusters();
  }

  /**
   * Resolve each gutter's clusters into a NON-OVERLAPPING vertical stack, in
   * pixels, measured after layout.
   *
   * The CLUSTERS table above anchors everything in percentages, which is what
   * kept the columns colliding: at 900x500 the left gutter's tap row (top 26%,
   * three 44px keys) reached y=280 while the throttle pair (bottom 23%, two 52px
   * keys) started at y=272, so THR+ sat eight pixels inside WPN — and BRAKE
   * three inside REPAIR on the other side. A percentage cannot know how tall the
   * keys it is separating are, so no choice of percentage fixes this for every
   * viewport; the arithmetic has to run against the real measured heights.
   *
   * Bottom-up per side, since the floor cluster is the one whose position
   * actually matters (it is under the resting thumb). Gaps compress before
   * anything is allowed to overlap.
   */
  _stackClusters() {
    if (!this.visible) return; // offsetHeight is 0 while the layer is hidden
    const H = this.root.clientHeight;
    if (!H) return;
    const ORDER = {
      L: ['secondaryL', 'primaryL', 'tapRow'],
      R: ['primaryR', 'midR', 'util'],
    };
    const byName = new Map((this._clusterEls ?? []).map((b) => [b.dataset.cluster, b]));
    const FLOOR = Math.round(H * 0.035);
    // Ceiling clears the MENU chip, which owns the top-right corner. The HUD's
    // own plates need no allowance here: `inset` already reserves both gutters
    // horizontally, so a panel cannot reach a key's column at any height.
    const CEIL = Math.min(46, Math.round(H * 0.12));
    const sides = ['L', 'R'].map((side) => ({
      side, boxes: ORDER[side].map((n) => byName.get(n)).filter(Boolean),
    }));
    const avail = H - FLOOR - CEIL;
    const measure = (boxes) => boxes.map((b) => b.offsetHeight || 44);
    // Pass 1: would either gutter overflow at the roomy key size? On a 740x360
    // landscape phone the left column wants 44 + 113 + 150 = 307px in 304px of
    // gutter, and no gap arithmetic recovers a deficit — so the OVERSIZED keys
    // (68x52 for throttle and FIRE) drop to the 48x44 checklist floor, which
    // gets the same thirteen keys into 291px. Shrinking to the floor is a real
    // cost; overlapping keys is a worse one, and 44px is still the documented
    // minimum touch target.
    const tight = sides.some(({ boxes }) =>
      measure(boxes).reduce((a, b) => a + b, 0) + 2 * (boxes.length - 1) > avail);
    for (const b of this._bigBtns ?? []) {
      b.style.minWidth = tight ? '48px' : '68px';
      b.style.minHeight = tight ? '44px' : '52px';
      b.style.fontSize = tight ? '10px' : '12px';
    }
    for (const { boxes } of sides) {
      if (!boxes.length) continue;
      const hs = measure(boxes);
      const total = hs.reduce((a, b) => a + b, 0);
      const n = boxes.length;
      const gap = n > 1 && total + 10 * (n - 1) > avail
        ? Math.max(2, Math.floor((avail - total) / (n - 1)))
        : 10;
      let bottomEdge = H - FLOOR;
      boxes.forEach((box, i) => {
        const top = Math.max(CEIL, bottomEdge - hs[i]);
        box.style.bottom = 'auto';
        box.style.top = `${top}px`;
        bottomEdge = top - gap;
      });
    }
  }

  setMode(mode) {
    if (mode === this.mode) return;
    this.mode = mode;
    this._buildStrip();
  }

  show() {
    this.visible = true;
    this.root.style.display = 'block';
    // Now that the layer is displayed the boxes have a measurable height, which
    // _stackClusters needs — every call made while hidden was a no-op.
    this._stackClusters();
    // orientation.lock is missing on iOS Safari and throws/rejects elsewhere
    // outside fullscreen — never let it take the boarding flow down with it
    try {
      const p = screen.orientation?.lock?.('landscape');
      p?.catch?.(() => {});
    } catch { /* unsupported — fine */ }
  }

  hide() {
    this.visible = false;
    this.root.style.display = 'none';
  }

  /** Per-frame: feed stick state into InputManager. */
  update() {
    if (!this.visible) return;
    const [mx, my] = this.moveStick.getInput();
    // screen-space +y is down; game forward is +1
    this.input.setVirtualAxis(mx, -my);
    const [lx, ly] = this.lookStick.getInput();
    if (this.mode === 'flight') {
      // In the seat the right half is ATTITUDE, not look. Screen +y is down and
      // pushing forward should drop the nose (aircraft convention), so pitch is
      // negated here; FlightController applies the invertY preference on top.
      this.input.setVirtualTurn(lx, -ly);
    } else {
      this.input.setVirtualTurn(0, 0);
      if (lx !== 0 || ly !== 0) this.input.injectLook(lx * LOOK_SPEED, ly * LOOK_SPEED);
    }
  }
}
