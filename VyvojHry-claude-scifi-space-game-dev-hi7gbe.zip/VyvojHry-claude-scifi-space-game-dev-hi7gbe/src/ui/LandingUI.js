/**
 * LandingUI — the surface operations board.
 *
 * Opened once the ship is down. Lists the sites the survey found on this world
 * with what each costs in suit oxygen and what it is, plus the one number that
 * decides when the visit ends: FUEL TO LEAVE against fuel in the tank.
 *
 * Deliberately shaped like the boarding panel, because it is the same decision
 * with a different clock — how much more can I take before the walk back costs
 * more than I have. The difference is that a planet does not run out, so the
 * limiting resource is always the suit and never the supply.
 */
import { PALETTE } from '../core/Constants.js';
import { plasticButton, plasticRow, bulkheadFrame, platePNG, panelChrome } from './Chrome.js';

export class LandingUI {
  /**
   * @param {import('../gameplay/Landing.js').Landing} landing
   * @param {() => void} onClose
   */
  constructor(landing, onClose = () => {}) {
    this.landing = landing;
    this.onClose = onClose;
    this.visible = false;

    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    const border = PALETTE.HUD_AMBER[0];

    /**
     * THE BULKHEAD FRAME (0.46.0, roadmap #85).
     *
     * This was a floating rounded plate over a dimmed game — the last screen in
     * the game still built that way, and it read as a web modal bolted onto a
     * 16-bit console while the hold manifest and the commission screen beside it
     * read as parts of the ship.
     *
     * It gets the same surround they do: heavy bevelled rails, cut corner
     * plates, an amber trim line, dead indicator ticks along the bottom, and a
     * star field behind. The sim is already frozen while this is up (main.js
     * returns early on `landingUI.visible`), so taking the whole screen costs
     * nothing and is the honest presentation — you are sitting at a board
     * reading a survey, not glancing at a pop-up.
     */
    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'inset:0', 'z-index:31', 'display:none',
      "font-family:'Courier New',monospace", 'letter-spacing:0.1em',
      'background:#000006', 'pointer-events:auto',
      'user-select:none', '-webkit-user-select:none', 'touch-action:none',
    ].join(';');
    const { root: frame, content } = bulkheadFrame('SURFACE OPERATIONS', { skySeed: 61, thin: true });
    this.frame = frame;
    this.root.appendChild(frame);
    content.style.alignItems = 'stretch';
    content.style.gap = '14px';
    content.style.paddingBottom = '52px';

    // -- left column: what this world IS ---------------------------------------
    const left = document.createElement('div');
    left.style.cssText = 'flex:0 0 clamp(210px,34%,320px);display:flex;flex-direction:column;'
      + 'gap:8px;min-height:0;';
    this.title = document.createElement('div');
    this.title.style.cssText = `font-size:15px;letter-spacing:0.14em;color:${amber};`;
    this.sub = document.createElement('div');
    this.sub.style.cssText = `font-size:10px;letter-spacing:0.16em;color:${amberLo};opacity:0.85;`;
    this.feature = document.createElement('div');
    this.feature.style.cssText = `font-size:11px;line-height:1.5;color:${amberLo};`
      + `border-left:2px solid ${border}88;padding:2px 0 2px 9px;margin-bottom:4px;`;
    this.env = document.createElement('div');
    this.env.style.cssText = 'padding:9px 11px;display:grid;grid-template-columns:1fr;gap:2px;'
      + 'image-rendering:pixelated;'
      + `background:url("${platePNG(120, 100, 'panel', 37)}") center/100% 100% no-repeat;`;
    left.append(this.title, this.sub, this.feature, this.env);

    // -- right column: the sites, and the record of working them ---------------
    const right = document.createElement('div');
    right.style.cssText = 'flex:1 1 auto;min-width:0;display:flex;flex-direction:column;gap:6px;min-height:0;';
    const h = document.createElement('div');
    h.textContent = '— SURVEY SITES —';
    h.style.cssText = `font-size:9px;letter-spacing:0.24em;color:${amberLo};text-align:center;opacity:0.8;`;
    this.siteList = document.createElement('div');
    this.siteList.style.cssText = 'flex:1 1 auto;min-height:0;overflow-y:auto;padding:8px;'
      + 'image-rendering:pixelated;'
      + `background:url("${platePNG(140, 120, 'panel', 59)}") center/100% 100% no-repeat;`;
    this.log = document.createElement('div');
    this.log.style.cssText = `font-size:10px;line-height:1.5;color:${amberLo};opacity:0.8;`
      + 'flex:0 0 auto;max-height:96px;overflow-y:auto;padding:6px 8px;image-rendering:pixelated;'
      + `background:url("${platePNG(120, 60, 'panel', 71)}") center/100% 100% no-repeat;`;
    right.append(h, this.siteList, this.log);
    content.append(left, right);

    // -- footer bar: the two things you can do about any of it -----------------
    const row = document.createElement('div');
    row.style.cssText = 'position:absolute;left:34px;right:34px;bottom:26px;display:flex;gap:9px;';
    this.stay = this._btn('STAY ON THE SURFACE', () => this.hide());
    this.launch = this._btn('LIFT OFF', () => {
      if (this.landing.launch()) this.hide();
      else this.refresh();
    });
    row.append(this.stay, this.launch);
    frame.appendChild(row);

    document.body.appendChild(this.root);
    // Closing this panel does NOT leave the planet — you are still standing on
    // it, and the panel reopens from the ship. That is the opposite of the
    // boarding panel, where closing means abandoning the run, and the two
    // behave differently because being on a planet is a place and being inside
    // a wreck is an expedition.
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });
  }

  _btn(label, fn) {
    const b = document.createElement('div');
    b.textContent = label;
    b.style.cssText = 'flex:1;justify-content:center;min-height:44px;' + plasticButton();
    const go = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    return b;
  }

  push(text) {
    const d = document.createElement('div');
    d.textContent = `· ${text}`;
    this.log.appendChild(d);
    this.log.scrollTop = this.log.scrollHeight;
  }

  refresh() {
    const s = this.landing.status();
    if (!s) return;
    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    this.title.textContent = s.name;
    this.sub.textContent = s.terrain;
    this.feature.textContent = s.feature;

    // Environment block. `breathable` is called out in the accent colour
    // because it is the single figure that changes how long you can work.
    this.env.innerHTML = '';
    const cell = (k, v, c) => {
      const d = document.createElement('div');
      d.style.cssText = 'display:flex;justify-content:space-between;font-size:10px;letter-spacing:0.08em;'
        + `color:${c ?? amberLo};`;
      const a = document.createElement('span'); a.textContent = k;
      const b = document.createElement('span'); b.textContent = v;
      d.append(a, b);
      this.env.appendChild(d);
    };
    cell('SITE', s.name.toUpperCase().slice(0, 18));
    cell('GRAVITY', `${s.gravity.toFixed(2)} G`);
    cell('SURFACE', `${Math.round(s.tempC)} °C`);
    cell('ATMOSPHERE', s.atmosphere.slice(0, 16), s.breathable ? '#8aa060' : amberLo);
    cell('SUIT O2', `${Math.round(s.oxygen)}%`, s.oxygen < 30 ? '#aa2020' : amber);
    cell('FUEL', `${Math.round(s.fuel)}%`, s.fuel < s.fuelToLeave ? '#aa2020' : amber);
    cell('TO LEAVE', `${s.fuelToLeave}%`, s.fuel < s.fuelToLeave ? '#aa2020' : amberLo);

    this.siteList.innerHTML = '';
    for (const [i, site] of s.sites.entries()) {
      const r = document.createElement('div');
      // A site is a card in a rack, not a row in a web list. See Chrome.plasticRow.
      r.style.cssText = plasticRow('margin-bottom:7px;',
        { dead: s.oxygen < site.o2 + 6, on: site.worked > 0 });
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;align-items:baseline;';
      const n = document.createElement('span');
      n.textContent = site.name;
      n.style.cssText = `font-size:12px;letter-spacing:0.1em;color:${amber};`;
      const cost = document.createElement('span');
      cost.textContent = `−${site.o2}% O2`;
      cost.style.cssText = `font-size:10px;color:${s.oxygen < site.o2 + 6 ? '#aa2020' : amberLo};`;
      head.append(n, cost);
      const where = document.createElement('div');
      // Bearing and range, so a site is somewhere rather than an entry in a list.
      where.textContent = `BEARING ${String(site.bearing).padStart(3, '0')}° · `
        + `${site.range} M${site.worked ? ` · WORKED ×${site.worked}` : ''}`;
      where.style.cssText = `font-size:9px;letter-spacing:0.1em;color:${amberLo};margin-top:2px;opacity:0.85;`;
      r.append(head, where);
      const go = (e) => {
        e.preventDefault(); e.stopPropagation();
        this.landing.workSite(i);
        this.refresh();
      };
      r.addEventListener('click', go);
      r.addEventListener('touchend', go, { passive: false });
      this.siteList.appendChild(r);
    }

    const canGo = s.fuel >= s.fuelToLeave;
    this.launch.style.opacity = canGo ? '1' : '0.45';
    this.launch.textContent = canGo ? `LIFT OFF (−${s.fuelToLeave}% FUEL)` : 'NOT ENOUGH FUEL TO LIFT';
  }

  show() {
    this.visible = true;
    this.root.style.display = 'block';
    this.refresh();
  }

  hide() {
    this.visible = false;
    this.root.style.display = 'none';
    this.onClose();
  }
}
