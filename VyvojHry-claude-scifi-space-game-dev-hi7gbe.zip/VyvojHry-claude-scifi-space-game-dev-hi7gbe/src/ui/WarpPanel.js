/**
 * WarpPanel — the interstellar jump chart. Opened with J (or the WARP button)
 * while piloting; lists every charted system with star class, danger rating,
 * body count and a lore blurb, and hands the chosen target back to main.
 *
 * Rows are grouped on `def.group`: the commissioned SURVEY ROUTE first, then the
 * OFF-ROUTE SPURS. Ten destinations in one flat column read as an undifferentiated
 * list where five read as an itinerary — the headers put the route back.
 *
 * DOM-based (like SettingsMenu/CelestialInfo) so it never touches the 480×270
 * buffer and stays touch-friendly. Amber retro-future chrome to match the HUD.
 */
import { PALETTE, FLIGHT } from '../core/Constants.js';
import { plasticButton, plasticPanel, framePanel, showScrim, panelChrome } from './Chrome.js';

const DANGER_COLOR = { LOW: '#7a9a6a', MEDIUM: '#c09050', HIGH: '#b06030', EXTREME: '#aa2020' };

export class WarpPanel {
  /**
   * @param {object[]} systems generated system defs (StarSystemsData.SYSTEMS)
   * @param {(def:object)=>void} onSelect called with the chosen target def
   */
  /**
   * @param {object[]} systems  every system on the chart
   * @param {Function} onSelect fired with the chosen system def
   * @param {object} [galaxy]   the generated chart: supplies `neighbours` and
   *   `distance`, which is what turns this from a menu of every system into a
   *   list of the ones the drive can actually reach from here.
   */
  constructor(systems, onSelect, galaxy = null) {
    this.systems = systems;
    this.galaxy = galaxy;
    this.onSelect = onSelect;
    this.currentId = systems[0].id;
    this.visible = false;

    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    const bg = PALETTE.HUD_PANEL_BG[0], border = PALETTE.HUD_AMBER[0];

    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:30', 'display:none', 'width:min(420px,86vw)', 'max-height:82vh', 'overflow-y:auto',
      'padding:14px 16px', 'pointer-events:auto', 'user-select:none', '-webkit-user-select:none',
    ].join(';') + ';' + plasticPanel();

    const title = document.createElement('div');
    // not "SURVEY ROUTE" any more — the chart carries the spurs too, and the
    // route is now one section heading inside it
    title.textContent = 'WARP CHART — CHARTED LANES';
    title.style.cssText = `font-size:15px;letter-spacing:0.14em;margin-bottom:4px;color:${amber};`;
    this.fuelLine = document.createElement('div');
    this.fuelLine.style.cssText = `font-size:11px;color:${amberLo};margin-bottom:10px;`;
    this.root.append(title, this.fuelLine);

    // -- THE CHART ------------------------------------------------------------
    // Plan view of the galactic plane. Not decoration: it is the only place the
    // shape of the galaxy is visible, and with jump range gating the list below
    // it only ever shows a handful of systems, so without this you would have no
    // idea what lies two hops away or which direction you are working across.
    this.chart = document.createElement('canvas');
    this.chart.width = 260; this.chart.height = 200;
    this.chart.style.cssText = 'width:100%;height:auto;image-rendering:pixelated;display:block;'
      + `border:1px solid ${border}66;background:#05060c;margin-bottom:10px;`;
    this.root.appendChild(this.chart);
    this.chartLabel = document.createElement('div');
    this.chartLabel.style.cssText = `font-size:9px;letter-spacing:0.16em;color:${amberLo};`
      + 'text-align:center;margin:-6px 0 9px;opacity:0.8;';
    this.root.appendChild(this.chartLabel);

    this.rows = [];
    let lastGroup = null;
    let lastHead = null;
    for (const def of systems) {
      const group = def.group ?? 'ROUTE';
      if (group !== lastGroup) {
        lastGroup = group;
        const head = document.createElement('div');
        head.textContent = group === 'ROUTE' ? '— COMMISSIONED SURVEY ROUTE —' : '— OFF-ROUTE SPURS —';
        head.style.cssText = `font-size:9px;letter-spacing:0.24em;color:${amberLo};`
          + 'text-align:center;margin:8px 0 7px;opacity:0.8;';
        this.root.appendChild(head);
        lastHead = head;
      }
      const row = document.createElement('div');
      row.style.cssText = [
        `border:1px solid ${border}88`, 'border-radius:8px', 'padding:9px 11px',
        'margin-bottom:8px', 'cursor:pointer', 'min-height:44px',
      ].join(';');
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;align-items:baseline;';
      const name = document.createElement('span');
      name.textContent = def.name;
      name.style.cssText = `font-size:13px;letter-spacing:0.12em;color:${amber};`;
      const dist = document.createElement('span');
      dist.style.cssText = `font-size:9px;color:${amberLo};letter-spacing:0.1em;opacity:0.9;`;
      const danger = document.createElement('span');
      danger.textContent = def.danger;
      danger.style.cssText = `font-size:10px;color:${DANGER_COLOR[def.danger] ?? amberLo};`;
      head.append(name, dist, danger);
      // planets only — the belt and comet swarm would drown the count
      const worlds = def.bodies.filter((b) => b.class !== 'Asteroid' && b.class !== 'Metallic asteroid').length;
      const spec = document.createElement('div');
      spec.textContent = `${def.star.starClass?.toUpperCase() ?? ''} · ${worlds} CHARTED BODIES`;
      spec.style.cssText = `font-size:9px;letter-spacing:0.1em;color:${amberLo};margin-top:2px;opacity:0.85;`;
      const sub = document.createElement('div');
      sub.textContent = def.blurb;
      sub.style.cssText = `font-size:10px;line-height:1.45;color:${amberLo};margin-top:3px;`;
      row.append(head, spec, sub);
      const pick = (e) => { e.preventDefault(); e.stopPropagation(); if (def.id !== this.currentId) { this.hide(); this.onSelect(def); } };
      row.addEventListener('click', pick);
      row.addEventListener('touchend', pick, { passive: false });
      this.root.appendChild(row);
      this.rows.push({ def, row, name, dist, group: lastHead });
    }
    document.body.appendChild(this.root);
    framePanel(this.root, { seed: 29 });
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });

    // the WARP button — visible only while piloting, mirrors the settings gear
    this.button = document.createElement('div');
    this.button.textContent = 'WARP';
    this.button.style.cssText = 'position:fixed;left:1.5%;top:8px;z-index:26;display:none;' + plasticButton();
    const toggle = (e) => { e.preventDefault(); e.stopPropagation(); this.toggle(); };
    this.button.addEventListener('click', toggle);
    this.button.addEventListener('touchend', toggle, { passive: false });
    document.body.appendChild(this.button);
  }

  /** Show/hide the WARP button with flight state. */
  setFlightMode(inFlight) {
    this.button.style.display = inFlight ? 'flex' : 'none';
    if (!inFlight) this.hide();
  }

  /** @param {string} id current system id  @param {number} warpFuel 0-100 */
  refresh(id, warpFuel) {
    this.currentId = id;
    this.fuelLine.textContent = `WARP FUEL ${Math.round(warpFuel)}% — COST ${FLIGHT.WARP_COST}% PER JUMP`;
    // Reachable set. Without a galaxy (older saves, or a hand-built list) every
    // system stays selectable, which is exactly the pre-0.28 behaviour — the
    // gate is additive, never a way for the panel to end up empty.
    const reach = this.galaxy
      ? new Map(this.galaxy.neighbours(id).map((n) => [n.sys.id, n.ly]))
      : null;
    let shown = 0;
    for (const { def, row, name, dist, group } of this.rows) {
      const here = def.id === id;
      const ly = reach ? reach.get(def.id) : null;
      const ok = here || !reach || ly != null;
      row.style.display = ok ? 'block' : 'none';
      if (group) group.style.display = 'none'; // headings are meaningless once gated
      if (!ok) continue;
      shown += here ? 0 : 1;
      row.style.opacity = here ? '0.45' : '1';
      name.textContent = here ? `${def.name} — CURRENT` : def.name;
      if (dist) dist.textContent = here ? 'YOU ARE HERE' : `${ly.toFixed(1)} LY`;
    }
    this.chartLabel.textContent = this.galaxy
      ? `${shown} LANE${shown === 1 ? '' : 'S'} IN RANGE — ${this.systems.length} SYSTEMS CHARTED`
      : '';
    this._drawChart(id, reach);
  }

  /**
   * Paint the plan view.
   *
   * Everything is drawn from the galactic x/z plane; the thin y spread is
   * ignored, because a chart that tried to show it would need a projection the
   * player has to learn, and the jump-range test still uses the real 3D
   * distance underneath. Systems are ranked by danger for colour, so the rim
   * reading as hostile is visible at a glance before you spend fuel on it.
   */
  _drawChart(id, reach) {
    const g = this.chart.getContext('2d');
    const W = this.chart.width, H = this.chart.height;
    g.fillStyle = '#05060c'; g.fillRect(0, 0, W, H);
    if (!this.galaxy) return;
    const R = this.galaxy.radius || 46;
    const sc = Math.min(W, H) / (R * 2.25);
    const cx = W / 2, cy = H / 2;
    const P = (s) => [cx + s.pos[0] * sc, cy + s.pos[2] * sc];
    const here = this.galaxy.byId.get(id);
    if (!here?.pos) return;
    const [hx, hy] = P(here);
    // jump envelope
    g.strokeStyle = '#3a2c1c'; g.lineWidth = 1;
    g.beginPath(); g.arc(hx, hy, 13.5 * sc, 0, Math.PI * 2); g.stroke();
    // lanes to everything in range
    if (reach) {
      g.strokeStyle = '#6f5020';
      for (const s of this.systems) {
        if (!reach.has(s.id) || !s.pos) continue;
        const [x, y] = P(s);
        g.beginPath(); g.moveTo(hx, hy); g.lineTo(x, y); g.stroke();
      }
    }
    // the systems themselves
    for (const s of this.systems) {
      if (!s.pos) continue;
      const [x, y] = P(s);
      const inRange = reach?.has(s.id);
      const cur = s.id === id;
      g.fillStyle = cur ? '#e0b070'
        : inRange ? (DANGER_COLOR[s.danger] ?? '#b08040')
          : s.authored ? '#4a4038' : '#2e2a26';
      const r = cur ? 3 : inRange ? 2.5 : 1.5;
      g.fillRect(Math.round(x - r), Math.round(y - r), Math.round(r * 2), Math.round(r * 2));
      if (cur || inRange) {
        g.fillStyle = cur ? '#e0b070' : '#7a5a30';
        g.font = '7px monospace';
        g.fillText(s.name.slice(0, 11), Math.round(x + 4), Math.round(y + 2));
      }
    }
    // own marker: a ring, so it survives being drawn over
    g.strokeStyle = '#e0b070'; g.lineWidth = 1;
    g.strokeRect(Math.round(hx - 5), Math.round(hy - 5), 10, 10);
  }

  toggle() { this.visible ? this.hide() : this.show(); }
  show() { if (!this.visible) showScrim(true); this.visible = true; this.root.style.display = 'block'; }
  hide() { if (this.visible) showScrim(false); this.visible = false; this.root.style.display = 'none'; }
}
