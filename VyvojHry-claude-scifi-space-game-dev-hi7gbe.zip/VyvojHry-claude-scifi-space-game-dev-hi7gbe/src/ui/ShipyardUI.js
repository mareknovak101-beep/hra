/**
 * ShipyardUI — the hull broker.
 *
 * Shipyards have generated, rendered and docked since 0.31.0, and docking at
 * one opened the general trade counter, so a building slip sold you rations.
 * This is the thing a yard is actually for.
 *
 * ONE DECISION, AND IT IS EXPENSIVE. Changing hulls is the only irreversible
 * purchase in the game: the deck plan is rebuilt, the hold capacity changes and
 * anything that no longer fits is lost. So the panel leads with the DIFFERENCE
 * against what you are flying — every stat shown as a delta, in the colour of
 * whether it is better or worse — rather than as an absolute table you would
 * have to hold two of in your head.
 *
 * THE TRADE-IN IS WHY THE PRICE IS FAIR. A hull is worth what it lists minus
 * what yours is worth, and yours is worth less the more damage is on it. That
 * makes the REPAIR you have been putting off into a number you can see, at the
 * exact moment it costs you.
 */
import { PALETTE } from '../core/Constants.js';
import { SHIP_CLASSES, LIVERIES, shipClass } from '../data/ShipClasses.js';
import { shipFit } from '../data/ShipFit.js';
import {
  plasticButton, plasticPanel, plasticRow, framePanel, showScrim, panelChrome,
} from './Chrome.js';

/**
 * List price per class, in credits.
 *
 * Not derived from the stats: a courier is cheap because it is small and a
 * hauler is expensive because it is large, and those are facts about the market
 * rather than about the spec sheet. The Aethon is the dearest because it is the
 * only one that is both big AND fitted out for science.
 */
const PRICE = { petrel: 5400, harrier: 9800, drayman: 12600, aethon: 15200 };

export class ShipyardUI {
  /**
   * @param {object} deps
   * @param {() => string} deps.currentClass   the hull id being flown
   * @param {() => object} deps.systems        for the trade-in condition
   * @param {import('../gameplay/TradingSystem.js').TradingSystem} deps.trading
   * @param {(clsId:string, liveryId:string|null)=>void} deps.onBuy
   * @param {(t:string)=>void} deps.notify
   * @param {() => void} deps.onClose
   */
  constructor({ currentClass, systems, trading, onBuy, notify, onClose }) {
    this.currentClass = currentClass;
    this.systems = systems;
    this.trading = trading;
    this.onBuy = onBuy;
    this.notify = notify ?? (() => {});
    this.onCloseCb = onClose ?? (() => {});
    this.visible = false;
    this.selected = null;
    this.liverySel = null;

    const amber = PALETTE.HUD_AMBER[2], amberLo = PALETTE.HUD_AMBER[0];
    this.C = { amber, amberLo, border: PALETTE.HUD_AMBER[0] };

    this.root = document.createElement('div');
    this.root.style.cssText = [
      'position:fixed', 'left:50%', 'top:50%', 'transform:translate(-50%,-50%)',
      'z-index:31', 'display:none', 'width:min(560px,94vw)', 'max-height:88vh', 'overflow-y:auto',
      'padding:14px 16px', 'pointer-events:auto', 'user-select:none', '-webkit-user-select:none',
    ].join(';') + ';' + plasticPanel();

    this.title = document.createElement('div');
    this.title.style.cssText = `font-size:15px;letter-spacing:0.14em;color:${amber};`;
    this.sub = document.createElement('div');
    this.sub.style.cssText = `font-size:10px;letter-spacing:0.16em;color:${amberLo};margin-bottom:10px;opacity:0.85;`;
    this.root.append(this.title, this.sub);

    this.tradeIn = document.createElement('div');
    this.tradeIn.style.cssText = `border:1px solid ${this.C.border}66;border-radius:6px;`
      + 'padding:8px 10px;margin-bottom:11px;background:#0a0b0e;';
    this.root.appendChild(this.tradeIn);

    this.list = document.createElement('div');
    this.root.appendChild(this.list);

    this.detail = document.createElement('div');
    this.detail.style.cssText = 'margin-top:6px;';
    this.root.appendChild(this.detail);

    const row = document.createElement('div');
    row.style.cssText = 'display:flex;gap:9px;margin-top:11px;';
    this.buyBtn = this._btn('SIGN FOR IT', () => this._buy());
    this.leaveBtn = this._btn('LEAVE THE YARD', () => this.hide());
    row.append(this.buyBtn, this.leaveBtn);
    this.root.appendChild(row);

    document.body.appendChild(this.root);
    framePanel(this.root, { seed: 67 });
    panelChrome(this.root, () => this.hide(), { isOpen: () => this.visible });
  }

  _btn(label, fn) {
    const b = document.createElement('div');
    b.textContent = label;
    b.style.cssText = 'flex:1;justify-content:center;min-height:44px;' + plasticButton();
    const go = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    b.addEventListener('click', go);
    b.addEventListener('touchend', go, { passive: false });
    return b;
  }

  /**
   * What the yard will give you for what you are flying.
   *
   * Condition is the mean hull integrity, so a ship you have been meaning to
   * patch is worth visibly less — which is the point. Floor of 40% of list:
   * even a wreck is worth its mass in plate.
   */
  tradeInValue() {
    const cur = shipClass(this.currentClass());
    const list = PRICE[cur.id] ?? 8000;
    const cond = Math.max(0.4, (this.systems().hull ?? 100) / 100);
    return { cls: cur, list, cond, value: Math.round(list * 0.62 * cond) };
  }

  refresh() {
    const { amber, amberLo, border } = this.C;
    const t = this.tradeInValue();
    const credits = this.trading?.credits ?? 0;

    this.tradeIn.innerHTML = '';
    const line = (k, v, c) => {
      const d = document.createElement('div');
      d.style.cssText = 'display:flex;justify-content:space-between;font-size:11px;'
        + `letter-spacing:0.08em;color:${c ?? amberLo};margin:1px 0;`;
      const a = document.createElement('span'); a.textContent = k;
      const b = document.createElement('span'); b.textContent = v;
      d.append(a, b);
      this.tradeIn.appendChild(d);
    };
    line('FLYING', `${t.cls.hullName} — ${t.cls.name}`, amber);
    line('CONDITION', `${Math.round(t.cond * 100)}%`, t.cond < 0.7 ? '#aa2020' : amberLo);
    line('TRADE-IN OFFER', `${t.value} CR`, amber);
    line('ON ACCOUNT', `${credits} CR`, amber);

    this.list.innerHTML = '';
    for (const c of SHIP_CLASSES) {
      const here = c.id === t.cls.id;
      const price = PRICE[c.id] ?? 8000;
      // SIGNED, not clamped. `Math.max(0, ...)` here reported "+0 CR BACK" on
      // every downgrade — trading a battered Aethon for a Petrel is worth a
      // thousand credits back and the panel was quietly rounding that to
      // nothing. The refund is the whole reason downgrading is a strategy.
      const net = price - t.value;
      const r = document.createElement('div');
      // A hull on the board is a card in a rack, and the selected one has its
      // leading edge lit — see Chrome.plasticRow.
      r.style.cssText = plasticRow('margin-bottom:7px;',
        { on: this.selected === c.id, dead: here });
      const head = document.createElement('div');
      head.style.cssText = 'display:flex;justify-content:space-between;align-items:baseline;';
      const n = document.createElement('span');
      n.textContent = here ? `${c.hullName} — YOURS` : c.hullName;
      n.style.cssText = `font-size:13px;letter-spacing:0.11em;color:${c.accent};`;
      const p = document.createElement('span');
      p.textContent = here ? '—' : net > 0 ? `${net} CR` : `${-net} CR BACK`;
      p.style.cssText = `font-size:11px;color:${net > credits && !here ? '#aa2020'
        : net <= 0 ? '#8aa060' : amber};`;
      head.append(n, p);
      const spec = document.createElement('div');
      spec.textContent = c.perk;
      spec.style.cssText = `font-size:9px;letter-spacing:0.09em;color:${amberLo};margin-top:2px;opacity:0.85;`;
      // What the INSIDE is like. The stat deltas below say how a hull flies and
      // how much it holds; nothing on this card used to say that its corridors
      // are bare steel and its stores compartment is a magazine, which is what
      // you actually live with. See data/ShipFit.js.
      const fit = document.createElement('div');
      fit.textContent = shipFit(c.id).note ?? '';
      fit.style.cssText = `font-size:9px;letter-spacing:0.06em;color:${amberLo};margin-top:2px;opacity:0.6;`;
      r.append(head, spec, fit);
      // The DELTA against what you fly. This is the whole reason the panel
      // exists in this shape: absolute stat tables make you hold two ships in
      // your head, and nobody does that correctly.
      if (!here) r.appendChild(this._deltas(c, t.cls));
      if (!here) {
        const go = (e) => {
          e.preventDefault(); e.stopPropagation();
          this.selected = this.selected === c.id ? null : c.id;
          this.refresh();
        };
        r.addEventListener('click', go);
        r.addEventListener('touchend', go, { passive: false });
      }
      this.list.appendChild(r);
    }

    // Livery, only once a hull is picked — repainting is part of the purchase
    // and the yard will not do it on its own.
    this.detail.innerHTML = '';
    if (this.selected) {
      const lab = document.createElement('div');
      lab.textContent = '— FINISH —';
      lab.style.cssText = `font-size:9px;letter-spacing:0.24em;color:${amberLo};`
        + 'text-align:center;margin:8px 0 6px;opacity:0.8;';
      this.detail.appendChild(lab);
      const sw = document.createElement('div');
      sw.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;justify-content:center;';
      for (const l of LIVERIES) {
        const b = document.createElement('div');
        b.textContent = l.name;
        const on = this.liverySel === l.id;
        b.style.cssText = plasticButton(`font-size:9px;letter-spacing:0.08em;`
          + `padding:6px 10px;min-height:34px;min-width:0;color:${on ? '#e8c890' : amberLo};`
          + (on ? 'outline-color:#d8ac68;box-shadow:0 0 10px #b0804055,'
            + ' inset 0 1px 0 #ffe0b033, inset 0 -3px 5px #00000098;' : ''));
        const go = (e) => {
          e.preventDefault(); e.stopPropagation();
          this.liverySel = l.id; this.refresh();
        };
        b.addEventListener('click', go);
        b.addEventListener('touchend', go, { passive: false });
        sw.appendChild(b);
      }
      this.detail.appendChild(sw);
    }

    const pick = this.selected ? shipClass(this.selected) : null;
    const net = pick ? (PRICE[pick.id] ?? 8000) - t.value : 0;
    const can = pick && net <= credits;
    this.buyBtn.style.opacity = can ? '1' : '0.45';
    this.buyBtn.textContent = !pick ? 'PICK A HULL'
      : net > credits ? `SHORT BY ${net - credits} CR`
        : net <= 0 ? `SIGN — ${-net} CR BACK`
          : `SIGN FOR THE ${pick.hullName.split(' ').pop()}`;
  }

  /** Six stat deltas, coloured by direction. */
  _deltas(c, cur) {
    const { amberLo } = this.C;
    const wrap = document.createElement('div');
    wrap.style.cssText = 'display:grid;grid-template-columns:repeat(3,1fr);gap:1px 10px;margin-top:6px;';
    const rows = [
      ['HULL', c.stats.hull, cur.stats.hull, 1],
      ['SHIELD', c.stats.shield, cur.stats.shield, 1],
      ['HOLD', c.stats.slots, cur.stats.slots, 1],
      ['THRUST', c.flight.thrust, cur.flight.thrust, 2],
      ['TURN', c.flight.turn, cur.flight.turn, 2],
      ['FUEL', c.stats.fuel, cur.stats.fuel, 1],
    ];
    for (const [k, a, b, dp] of rows) {
      const d = a - b;
      const el = document.createElement('div');
      el.style.cssText = 'display:flex;justify-content:space-between;font-size:9px;'
        + `letter-spacing:0.06em;color:${d > 0 ? '#8aa060' : d < 0 ? '#a06030' : amberLo};`;
      const x = document.createElement('span'); x.textContent = k;
      const y = document.createElement('span');
      y.textContent = d === 0 ? '—' : `${d > 0 ? '+' : ''}${dp === 2 ? d.toFixed(2) : Math.round(d)}`;
      el.append(x, y);
      wrap.appendChild(el);
    }
    return wrap;
  }

  _buy() {
    const pick = this.selected ? shipClass(this.selected) : null;
    if (!pick) return;
    const t = this.tradeInValue();
    const net = (PRICE[pick.id] ?? 8000) - t.value;
    if (net > (this.trading?.credits ?? 0)) {
      this.notify(`THE YARD WANTS ${net} CR AND YOU HAVE ${this.trading?.credits ?? 0}.`);
      return;
    }
    // Negative net is a refund and it is PAID. Subtracting a negative is the
    // whole of it, and the clamp that used to sit here is why it was not.
    if (this.trading) this.trading.credits -= net;
    this.onBuy(pick.id, this.liverySel);
    this.notify(`SIGNED FOR THE ${pick.hullName}. THE ${t.cls.hullName} STAYS HERE.`);
    this.selected = null;
    this.liverySel = null;
    this.hide();
  }

  open(station) {
    this.title.textContent = station?.name ?? 'BUILDING SLIP';
    this.sub.textContent = 'HULL BROKER — TRADE-IN AGAINST LIST, NO QUESTIONS ASKED';
    this.selected = null;
    this.liverySel = null;
    this.show();
  }

  show() {
    if (!this.visible) showScrim(true);
    this.visible = true;
    this.root.style.display = 'block';
    this.refresh();
  }

  hide() {
    if (this.visible) showScrim(false);
    this.visible = false;
    this.root.style.display = 'none';
    this.onCloseCb();
  }
}

export { PRICE };
