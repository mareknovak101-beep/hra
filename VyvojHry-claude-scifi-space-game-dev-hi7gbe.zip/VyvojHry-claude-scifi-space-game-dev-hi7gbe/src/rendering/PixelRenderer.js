/**
 * PixelRenderer — 2D pixel-space quad batcher for the HUD/UI pass.
 * All coordinates are logical 480×270 UI pixels and get integer-snapped here, so
 * callers can't accidentally break pixel alignment (context/07 checklist).
 *
 * The UI grid stays 480×270 even when the scene buffer is 2–4× that: u_resolution
 * carries the UI size, so the hud shader maps one UI pixel onto `RENDER.SCALE`
 * scene pixels and the chrome keeps its apparent size at every render scale.
 * Integer snapping is therefore still exact — a UI pixel lands on a whole
 * multiple of scene pixels, never a fraction of one.
 */
import { RENDER } from '../core/Constants.js';
import { HUD_FLOATS_PER_VERTEX } from '../core/Renderer.js';

const MAX_QUADS = 4096;

export class PixelRenderer {
  /** @param {import('../core/Renderer.js').Renderer} renderer */
  constructor(renderer) {
    this.renderer = renderer;
    const gl = renderer.gl;

    this.verts = new Float32Array(MAX_QUADS * 4 * HUD_FLOATS_PER_VERTEX);
    this.count = 0; // quads queued
    this.texture = null;

    this.vao = gl.createVertexArray();
    gl.bindVertexArray(this.vao);

    this.vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
    gl.bufferData(gl.ARRAY_BUFFER, this.verts.byteLength, gl.DYNAMIC_DRAW);
    const stride = HUD_FLOATS_PER_VERTEX * 4;
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 2, gl.FLOAT, false, stride, 8);
    gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(2, 4, gl.FLOAT, false, stride, 16);

    // static quad index pattern
    const idx = new Uint32Array(MAX_QUADS * 6);
    for (let q = 0; q < MAX_QUADS; q++) {
      const b = q * 4;
      idx.set([b, b + 1, b + 2, b, b + 2, b + 3], q * 6);
    }
    this.ibo = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    renderer.liveBuffers += 2;
    renderer.liveVaos += 1;

    /** UV of a guaranteed-white texel (set from PixelFont.whiteUV at boot). */
    this.whiteUV = { u0: 0, v0: 0, u1: 0, v1: 0 };
  }

  /** Switch source texture; flushes queued quads if it changes. */
  setTexture(texture) {
    if (this.texture !== texture && this.count > 0) this.flush();
    this.texture = texture;
  }

  /** Textured sub-rect. uv: {u0,v0,u1,v1}. color: [r,g,b,a] floats. */
  sprite(x, y, w, h, uv, color) {
    if (this.count >= MAX_QUADS) this.flush();
    x = Math.round(x); y = Math.round(y);
    const o = this.count * 4 * HUD_FLOATS_PER_VERTEX;
    const v = this.verts;
    const [r, g, b, a] = color;
    const write = (i, px, py, u, vv) => {
      const j = o + i * HUD_FLOATS_PER_VERTEX;
      v[j] = px; v[j + 1] = py; v[j + 2] = u; v[j + 3] = vv;
      v[j + 4] = r; v[j + 5] = g; v[j + 6] = b; v[j + 7] = a;
    };
    write(0, x, y, uv.u0, uv.v0);
    write(1, x + w, y, uv.u1, uv.v0);
    write(2, x + w, y + h, uv.u1, uv.v1);
    write(3, x, y + h, uv.u0, uv.v1);
    this.count++;
  }

  /** Solid rect (samples the atlas's white block). */
  rect(x, y, w, h, color) {
    this.sprite(x, y, w, h, this.whiteUV, color);
  }

  /** 1px border rectangle. */
  border(x, y, w, h, color) {
    this.rect(x, y, w, 1, color);
    this.rect(x, y + h - 1, w, 1, color);
    this.rect(x, y + 1, 1, h - 2, color);
    this.rect(x + w - 1, y + 1, 1, h - 2, color);
  }

  /**
   * Draw a string with a PixelFont face.
   * @returns {number} pixel width drawn
   */
  text(font, face, x, y, str, color) {
    let px = Math.round(x);
    y = Math.round(y);
    for (const ch of str) {
      const g = font.glyph(face, ch);
      if (ch !== ' ') this.sprite(px, y, g.w, g.h, g, color);
      px += g.advance;
    }
    return px - x;
  }

  flush() {
    if (this.count === 0 || !this.texture) { this.count = 0; return; }
    const gl = this.renderer.gl;
    const prog = this.renderer.use('hud');
    gl.uniform2f(prog.uniforms.u_resolution, RENDER.UI_WIDTH, RENDER.UI_HEIGHT);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.uniform1i(prog.uniforms.u_texture, 0);

    gl.bindVertexArray(this.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0,
      this.verts.subarray(0, this.count * 4 * HUD_FLOATS_PER_VERTEX));
    gl.drawElements(gl.TRIANGLES, this.count * 6, gl.UNSIGNED_INT, 0);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;
    this.count = 0;
  }
}
