/**
 * PostProcess — the full-frame CRT pass (Phase 8, context/01 phosphor + §9
 * pixel truth). The whole 480×270 scene renders into an offscreen framebuffer,
 * then a single fullscreen triangle blits it to the real backbuffer through a
 * shader that layers the analog-monitor look the mood asks for: aperture-grille
 * scanlines, an RGB phosphor triad mask, corner vignette, gentle chromatic
 * aberration off the tube's curve, rolling film grain and a faint mains flicker.
 *
 * It's deliberately restrained — mood over spectacle. Everything is quantized
 * so it stays pixel-honest (no smooth gradients), and the pass is one extra
 * 480×270 draw, so it costs almost nothing on mobile. Toggleable from Settings;
 * when off, begin()/end() bind the backbuffer directly and add zero cost.
 */
import { RENDER } from '../core/Constants.js';

const VERT = `#version 300 es
// fullscreen triangle from gl_VertexID — no vertex buffer needed
out vec2 v_uv;
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  v_uv = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}`;

const FRAG = `#version 300 es
precision highp float;
in vec2 v_uv;
uniform sampler2D u_tex;
// Pattern pitch, NOT the buffer size: the scanline, phosphor-triad and grain
// cells are a fixed 480×270 apparent grid at every render scale. Tying them to
// the real buffer instead would make the whole CRT layer vanish at the high
// presets (540 scanlines on a 1080-line buffer is invisible) — the effect is
// deliberate chrome the player toggles, so it holds its apparent size while the
// picture underneath it resolves finer.
uniform vec2 u_res;
uniform float u_time;
/**
 * 0..1 — how much of the tube to apply. The CRT was a single on/off, and the
 * two ends of that switch are "no period feel at all" and "scanlines over
 * everything", with nothing in between for a player who wants the phosphor but
 * can read 6px glyphs more easily without the grille on top of them.
 *
 * Applied as ONE mix at the end rather than by scaling each term: every term
 * here is tuned against the others, and dialling them independently would let
 * a middle setting land somewhere none of them were designed for.
 */
uniform float u_crt;
out vec4 fragColor;

// cheap hash for grain
float hash(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}

void main() {
  vec2 uv = v_uv;
  // Kept before the barrel warp: the un-curved sample is what the strength mix
  // blends back toward, so at u_crt = 0 the picture is exactly the raw buffer
  // and not a straight picture through a curved lens.
  vec2 uv0 = v_uv;

  // -- tube curvature: a very slight barrel so the frame reads as glass. Kept
  //    tiny so pixels stay put; sampling is NEAREST, so this only nudges rows.
  vec2 cc = uv - 0.5;
  float r2 = dot(cc, cc);
  uv = uv + cc * r2 * 0.028;

  // off-screen after the curve → black border (the bezel)
  if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
    fragColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
  }

  // -- chromatic aberration: split the channels along the radius, stronger at
  //    the edges — the classic cheap-lens colour fringe
  vec2 ab = cc * 0.0022 * (0.4 + r2);
  vec3 col;
  col.r = texture(u_tex, uv + ab).r;
  col.g = texture(u_tex, uv).g;
  col.b = texture(u_tex, uv - ab).b;

  // -- scanlines: darken alternate logical rows (aperture grille), quantized
  float row = floor(uv.y * u_res.y);
  float scan = mod(row, 2.0) < 1.0 ? 1.0 : 0.80;

  // -- phosphor triad: tint successive columns R/G/B so the picture reads as
  //    lit dots, not flat fill; subtle so colour barely shifts
  float col3 = mod(floor(uv.x * u_res.x), 3.0);
  vec3 mask = col3 < 1.0 ? vec3(1.06, 0.97, 0.97)
            : col3 < 2.0 ? vec3(0.97, 1.06, 0.97)
                         : vec3(0.97, 0.97, 1.06);

  col *= scan;
  col *= mask;

  // -- vignette: quantized corner falloff (no smooth gradient)
  float vig = 1.0 - r2 * 0.9;
  vig = clamp(vig, 0.0, 1.0);
  vig = floor(vig * 8.0) / 8.0 * 0.35 + 0.65; // 8 steps, floored at 0.65
  col *= vig;

  // -- film grain: rolling, quantized to a few levels so it dithers not blurs
  float g = hash(floor(uv * u_res) + floor(u_time * 24.0));
  col *= 0.94 + 0.06 * floor(g * 4.0) / 3.0;

  // -- mains flicker: a faint global brightness wobble
  col *= 1.0 + 0.015 * sin(u_time * 8.0);

  // lift a touch so the scanlines/vignette don't crush the picture
  col *= 1.10;

  // Back toward the raw picture. u_crt 1.0 is the tube as authored.
  vec3 raw = texture(u_tex, uv0).rgb;
  col = mix(raw, col, clamp(u_crt, 0.0, 1.0));

  fragColor = vec4(col, 1.0);
}`;

export class PostProcess {
  /** @param {import('../core/Renderer.js').Renderer} renderer */
  constructor(renderer) {
    this.renderer = renderer;
    this.gl = renderer.gl;
    this.enabled = true;
    this.strength = 1;
    this.W = RENDER.WIDTH;
    this.H = RENDER.HEIGHT;
    this._build();
  }

  _build() {
    const gl = this.gl;
    // colour target
    this.color = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.color);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, this.W, this.H, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindTexture(gl.TEXTURE_2D, null);
    this.renderer.liveTextures += 1;
    // depth (the scene needs a depth buffer)
    this.depth = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, this.depth);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, this.W, this.H);
    gl.bindRenderbuffer(gl.RENDERBUFFER, null);
    // framebuffer
    this.fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.color, 0);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.depth);
    const ok = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    if (!ok) { this.enabled = false; this.broken = true; }

    this.prog = this.renderer.createProgram('crt', VERT, FRAG);
    // WebGL2 still needs a bound VAO for the attributeless draw
    this.vao = gl.createVertexArray();
  }

  setEnabled(on) { this.enabled = on && !this.broken; }

  /** 0..1 — how much of the tube to apply. See the `u_crt` note in the shader. */
  setStrength(v) { this.strength = Math.max(0, Math.min(1, v ?? 1)); }

  /** Bind the scene target (the FBO when enabled, else the backbuffer). */
  begin() {
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.enabled ? this.fbo : null);
    gl.viewport(0, 0, this.W, this.H);
  }

  /** Resolve the FBO to the backbuffer through the CRT shader. */
  end(time) {
    if (!this.enabled) return;
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.W, this.H);
    gl.disable(gl.DEPTH_TEST);
    gl.disable(gl.CULL_FACE);
    gl.disable(gl.BLEND);
    const p = this.renderer.use('crt');
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.color);
    gl.uniform1i(p.uniforms.u_tex, 0);
    gl.uniform2f(p.uniforms.u_res, RENDER.UI_WIDTH, RENDER.UI_HEIGHT);
    gl.uniform1f(p.uniforms.u_time, time);
    gl.uniform1f(p.uniforms.u_crt, this.strength ?? 1);
    gl.bindVertexArray(this.vao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindVertexArray(null);
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    this.renderer.drawCalls++;
  }
}
