/**
 * PixelFont — the game's two bitmap font families (context/01 §5), generated
 * at runtime from an embedded 5×7 glyph set. No font files, no browser text.
 *
 * - AMBER-9    — player HUD face: blocky slab (horizontal double-strike),
 *                uppercase only, 7px advance.
 * - TERM-MONO-7 — diegetic terminal face: plain strict monospace, 6px advance.
 *
 * Both faces are rendered white into one atlas; tinting happens per-vertex in
 * the HUD pass, so palette discipline lives at the call site.
 */

const GLYPH_W = 5;
const GLYPH_H = 7;

// 5×7 glyph rows; '#' = pixel on. Uppercase-only by design.
const GLYPHS = {
  ' ': ['.....', '.....', '.....', '.....', '.....', '.....', '.....'],
  'A': ['.###.', '#...#', '#...#', '#####', '#...#', '#...#', '#...#'],
  'B': ['####.', '#...#', '#...#', '####.', '#...#', '#...#', '####.'],
  'C': ['.###.', '#...#', '#....', '#....', '#....', '#...#', '.###.'],
  'D': ['####.', '#...#', '#...#', '#...#', '#...#', '#...#', '####.'],
  'E': ['#####', '#....', '#....', '####.', '#....', '#....', '#####'],
  'F': ['#####', '#....', '#....', '####.', '#....', '#....', '#....'],
  'G': ['.###.', '#...#', '#....', '#.###', '#...#', '#...#', '.###.'],
  'H': ['#...#', '#...#', '#...#', '#####', '#...#', '#...#', '#...#'],
  'I': ['.###.', '..#..', '..#..', '..#..', '..#..', '..#..', '.###.'],
  'J': ['....#', '....#', '....#', '....#', '#...#', '#...#', '.###.'],
  'K': ['#...#', '#..#.', '#.#..', '##...', '#.#..', '#..#.', '#...#'],
  'L': ['#....', '#....', '#....', '#....', '#....', '#....', '#####'],
  'M': ['#...#', '##.##', '#.#.#', '#.#.#', '#...#', '#...#', '#...#'],
  'N': ['#...#', '##..#', '#.#.#', '#..##', '#...#', '#...#', '#...#'],
  'O': ['.###.', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
  'P': ['####.', '#...#', '#...#', '####.', '#....', '#....', '#....'],
  'Q': ['.###.', '#...#', '#...#', '#...#', '#...#', '#..#.', '.##.#'],
  'R': ['####.', '#...#', '#...#', '####.', '#.#..', '#..#.', '#...#'],
  'S': ['.####', '#....', '#....', '.###.', '....#', '....#', '####.'],
  'T': ['#####', '..#..', '..#..', '..#..', '..#..', '..#..', '..#..'],
  'U': ['#...#', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.'],
  'V': ['#...#', '#...#', '#...#', '#...#', '#...#', '.#.#.', '..#..'],
  'W': ['#...#', '#...#', '#...#', '#.#.#', '#.#.#', '##.##', '#...#'],
  'X': ['#...#', '#...#', '.#.#.', '..#..', '.#.#.', '#...#', '#...#'],
  'Y': ['#...#', '#...#', '.#.#.', '..#..', '..#..', '..#..', '..#..'],
  'Z': ['#####', '....#', '...#.', '..#..', '.#...', '#....', '#####'],
  '0': ['.###.', '#...#', '#..##', '#.#.#', '##..#', '#...#', '.###.'],
  '1': ['..#..', '.##..', '..#..', '..#..', '..#..', '..#..', '.###.'],
  '2': ['.###.', '#...#', '....#', '..##.', '.#...', '#....', '#####'],
  '3': ['.###.', '#...#', '....#', '..##.', '....#', '#...#', '.###.'],
  '4': ['...#.', '..##.', '.#.#.', '#..#.', '#####', '...#.', '...#.'],
  '5': ['#####', '#....', '####.', '....#', '....#', '#...#', '.###.'],
  '6': ['.###.', '#....', '#....', '####.', '#...#', '#...#', '.###.'],
  '7': ['#####', '....#', '...#.', '..#..', '.#...', '.#...', '.#...'],
  '8': ['.###.', '#...#', '#...#', '.###.', '#...#', '#...#', '.###.'],
  '9': ['.###.', '#...#', '#...#', '.####', '....#', '....#', '.###.'],
  '.': ['.....', '.....', '.....', '.....', '.....', '.....', '..#..'],
  ',': ['.....', '.....', '.....', '.....', '.....', '..#..', '.#...'],
  ':': ['.....', '.....', '..#..', '.....', '..#..', '.....', '.....'],
  ';': ['.....', '.....', '..#..', '.....', '..#..', '.#...', '.....'],
  '!': ['..#..', '..#..', '..#..', '..#..', '..#..', '.....', '..#..'],
  '?': ['.###.', '#...#', '....#', '..##.', '..#..', '.....', '..#..'],
  '-': ['.....', '.....', '.....', '.###.', '.....', '.....', '.....'],
  '+': ['.....', '..#..', '..#..', '#####', '..#..', '..#..', '.....'],
  '=': ['.....', '.....', '#####', '.....', '#####', '.....', '.....'],
  '/': ['....#', '...#.', '...#.', '..#..', '.#...', '.#...', '#....'],
  '(': ['...#.', '..#..', '.#...', '.#...', '.#...', '..#..', '...#.'],
  ')': ['.#...', '..#..', '...#.', '...#.', '...#.', '..#..', '.#...'],
  '[': ['.###.', '.#...', '.#...', '.#...', '.#...', '.#...', '.###.'],
  ']': ['.###.', '...#.', '...#.', '...#.', '...#.', '...#.', '.###.'],
  '<': ['...#.', '..#..', '.#...', '#....', '.#...', '..#..', '...#.'],
  '>': ['.#...', '..#..', '...#.', '....#', '...#.', '..#..', '.#...'],
  "'": ['..#..', '..#..', '.....', '.....', '.....', '.....', '.....'],
  '"': ['.#.#.', '.#.#.', '.....', '.....', '.....', '.....', '.....'],
  '%': ['##..#', '##..#', '...#.', '..#..', '.#...', '#..##', '#..##'],
  '_': ['.....', '.....', '.....', '.....', '.....', '.....', '#####'],
  '&': ['.##..', '#..#.', '#.#..', '.#...', '#.#.#', '#..#.', '.##.#'],
  '°': ['..#..', '.#.#.', '..#..', '.....', '.....', '.....', '.....'],
  '—': ['.....', '.....', '.....', '#####', '.....', '.....', '.....'], // em dash (full width)
  '·': ['.....', '.....', '.....', '..#..', '.....', '.....', '.....'], // middle dot
  '×': ['.....', '.....', '#...#', '.#.#.', '..#..', '.#.#.', '#...#'], // multiply sign
};

export const FONT_FACES = {
  AMBER9: 'AMBER9', // player HUD — bold slab
  TERM7: 'TERM7', // diegetic terminals — plain mono
};

export class PixelFont {
  constructor() {
    this.atlasW = 128;
    this.atlasH = 160;
    this.data = new Uint8Array(this.atlasW * this.atlasH * 4);
    /** @type {Map<string, Map<string, object>>} face -> char -> metrics */
    this.metrics = new Map([[FONT_FACES.AMBER9, new Map()], [FONT_FACES.TERM7, new Map()]]);
    this.lineHeight = GLYPH_H + 2;
    this._build();
  }

  _setPx(x, y) {
    const i = (y * this.atlasW + x) * 4;
    this.data[i] = 255; this.data[i + 1] = 255; this.data[i + 2] = 255; this.data[i + 3] = 255;
  }

  _build() {
    // Solid white 4×4 block at (0,0) — used by the HUD pass for plain rects.
    for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) this._setPx(x, y);
    this.whiteUV = this._uvRect(1, 1, 2, 2); // sample inside the block

    let cx = 8, cy = 0;
    const place = (face, ch, bold) => {
      const w = bold ? GLYPH_W + 1 : GLYPH_W;
      if (cx + w + 1 > this.atlasW) { cx = 0; cy += GLYPH_H + 1; }
      const rows = GLYPHS[ch];
      for (let ry = 0; ry < GLYPH_H; ry++) {
        for (let rx = 0; rx < GLYPH_W; rx++) {
          if (rows[ry][rx] !== '#') continue;
          this._setPx(cx + rx, cy + ry);
          if (bold) this._setPx(cx + rx + 1, cy + ry); // horizontal double-strike
        }
      }
      this.metrics.get(face).set(ch, {
        ...this._uvRect(cx, cy, w, GLYPH_H),
        w, h: GLYPH_H,
        advance: w + 1,
      });
      cx += w + 1;
    };

    const chars = Object.keys(GLYPHS);
    for (const ch of chars) place(FONT_FACES.AMBER9, ch, true);
    for (const ch of chars) place(FONT_FACES.TERM7, ch, false);
    if (cy + GLYPH_H >= this.atlasH) throw new Error('PixelFont atlas overflow');
  }

  _uvRect(x, y, w, h) {
    return {
      u0: x / this.atlasW, v0: y / this.atlasH,
      u1: (x + w) / this.atlasW, v1: (y + h) / this.atlasH,
    };
  }

  /** @returns {object|null} glyph metrics for a char (uppercased) */
  glyph(face, ch) {
    const m = this.metrics.get(face);
    return m.get(ch.toUpperCase()) ?? m.get('?');
  }

  /** Pixel width of a string in the given face. */
  measure(face, text) {
    let w = 0;
    for (const ch of text) w += this.glyph(face, ch).advance;
    return Math.max(0, w - 1);
  }

  /**
   * Stamp text directly into an RGBA buffer (used by TextureFactory for
   * stencils, labels and screen content).
   * @param {Uint8Array} dst RGBA buffer
   * @param {number} dstW buffer width in px
   * @param {number} dstH buffer height in px
   */
  stamp(dst, dstW, dstH, x, y, text, rgb, face = FONT_FACES.TERM7, scale = 1) {
    let px = x;
    const sc = Math.max(1, Math.round(scale));
    for (const ch of text) {
      const rows = GLYPHS[ch.toUpperCase()] ?? GLYPHS['?'];
      for (let ry = 0; ry < GLYPH_H; ry++) {
        for (let rx = 0; rx < GLYPH_W; rx++) {
          if (rows[ry][rx] !== '#') continue;
          // integer block scale only — the glyph stays a hard pixel grid, which
          // is why interior stencils survive the texture going to 128²
          for (let sy = 0; sy < sc; sy++) {
            for (let sx = 0; sx < sc; sx++) {
              const dx = px + rx * sc + sx, dy = y + ry * sc + sy;
              if (dx < 0 || dy < 0 || dx >= dstW || dy >= dstH) continue;
              const i = (dy * dstW + dx) * 4;
              dst[i] = rgb[0]; dst[i + 1] = rgb[1]; dst[i + 2] = rgb[2]; dst[i + 3] = 255;
            }
          }
        }
      }
      px += (GLYPH_W + 1) * sc;
    }
  }
}
