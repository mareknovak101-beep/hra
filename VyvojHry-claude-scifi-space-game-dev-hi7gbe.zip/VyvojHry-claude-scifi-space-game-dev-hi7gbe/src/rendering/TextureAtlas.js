/**
 * TextureAtlas — registry for the interior material texture arrays.
 * TextureFactory registers named layers here (albedo + matching normal map);
 * the atlas packs them into two parallel TEXTURE_2D_ARRAYs sharing layer
 * indices, so whole zones still draw in one call.
 */
import { RENDER } from '../core/Constants.js';

export class TextureAtlas {
  constructor() {
    /** @type {Map<string, number>} name -> layer index */
    this.layerIndex = new Map();
    /** @type {Uint8Array[]} RGBA albedo data per layer */
    this.layers = [];
    /** @type {Uint8Array[]} RGBA normal-map data per layer (same indices) */
    this.normalLayers = [];
    this.glTexture = null;
    this.glNormalTexture = null;
    this._flatNormal = null;
  }

  /**
   * @param {string} name
   * @param {Uint8Array} rgba TEXTURE_SIZE² RGBA albedo
   * @param {Uint8Array} [normal] matching normal map; flat if omitted
   * @returns {number} layer index
   */
  register(name, rgba, normal = null) {
    if (this.layerIndex.has(name)) throw new Error(`Duplicate texture layer: ${name}`);
    const index = this.layers.length;
    this.layerIndex.set(name, index);
    this.layers.push(rgba);
    this.normalLayers.push(normal ?? this._flat());
    return index;
  }

  _flat() {
    if (!this._flatNormal) {
      const s = RENDER.TEXTURE_SIZE;
      this._flatNormal = new Uint8Array(s * s * 4);
      for (let i = 0; i < s * s; i++) {
        this._flatNormal[i * 4] = 128;
        this._flatNormal[i * 4 + 1] = 128;
        this._flatNormal[i * 4 + 2] = 255;
        this._flatNormal[i * 4 + 3] = 255;
      }
    }
    return this._flatNormal;
  }

  /** @returns {number} layer index for a registered name (throws on typo) */
  layer(name) {
    const idx = this.layerIndex.get(name);
    if (idx === undefined) throw new Error(`Unknown texture layer: ${name}`);
    return idx;
  }

  /**
   * @param {import('../core/Renderer.js').Renderer} renderer
   * @returns {{albedo: WebGLTexture, normal: WebGLTexture}}
   */
  upload(renderer) {
    this.glTexture = renderer.createTextureArray(RENDER.TEXTURE_SIZE, this.layers);
    this.glNormalTexture = renderer.createTextureArray(RENDER.TEXTURE_SIZE, this.normalLayers);
    return { albedo: this.glTexture, normal: this.glNormalTexture };
  }
}
