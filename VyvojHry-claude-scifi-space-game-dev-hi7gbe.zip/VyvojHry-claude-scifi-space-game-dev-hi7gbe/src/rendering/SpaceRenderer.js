/**
 * SpaceRenderer — everything outside the glass: starfield, nebulae, the sun,
 * planets, other ships, dust. Drawn BEFORE the interior with depth disabled,
 * so space exists exactly where the hull doesn't.
 *
 * The interior never moves; the universe is transformed into ship-local space
 * by the inverse ship orientation (skybox) and inverse pose (bodies). Distant
 * bodies are projected onto a sky sphere inside the far plane with angular
 * size preserved.
 */
import { FLIGHT, PALETTE, RENDER } from '../core/Constants.js';
import { Mat4, Vec3, DEG2RAD } from '../utils/MathUtils.js';
import { hexToRgbf } from '../utils/ColorUtils.js';
import { RNG } from '../utils/RNG.js';
import { AETHON_FX } from '../ship/ShipExterior.js';
import { UNITS_PER_AU } from '../data/CelestialGen.js';
import { skyStrip } from '../data/SurfaceGen.js';

const SPACE_FLOATS = 8; // pos3 normal3 uv2
const STAR_FLOATS = 7; // pos3 color3 size1
// fixed up-references for camera-facing sprite construction (module-level so
// the batcher allocates nothing per sprite)
const AXIS_X_REF = [1, 0, 0];
const AXIS_Y_REF = [0, 1, 0];
// Cloud-deck frame rate. Deliberately slow — an atmosphere should drift and
// reshape over seconds, not flicker; the visible motion comes mostly from the
// shell's differential rotation. 0.45/s ≈ a 9-second loop over 4 frames.
const CLOUD_FPS = 0.45;
// Star photospheres DO churn fast (convection cells turn over quickly).
const STAR_FPS = 2.5; // 6 frames at 2.5/s = a 2.4 s churn cycle (was 4 at 3.2 = 1.25 s)

const PLANET_FILL = 0.5; // night-side floor: readable dim sphere from every angle
// (winding fix means the near hemisphere renders) while keeping a real terminator
// The Aethon is drawn smaller than life in the chase cam so the worlds it flies
// past read as genuinely huge beside it (owner request).
const SHIP_CHASE_SCALE = 0.55;
/** Neutral livery, so `u_tint` is never left carrying somebody else's paint. */
const WHITE3 = new Float32Array([1, 1, 1]);
/**
 * Hostile hull liveries. Variant types share their parent's mesh and texture,
 * so this is the only thing that separates them at combat range: a lancer runs
 * hot ochre yard paint, a picket is cold Drift white, a lance is dark oxide.
 * Multiplied into the albedo BEFORE lighting, so every panel line and weld on
 * the plating comes through in the new colour rather than being washed flat.
 */
/**
 * Structure liveries, multiplied into the plating albedo before lighting so the
 * panel lines survive. Everything shares one hull texture, so this is what stops
 * a refinery, a trade post and a monolith reading as the same grey metal — and
 * the wreck and monolith tints are the load-bearing ones: dead things should
 * look cold and colourless next to anything that still has power in it.
 */
const STRUCTURE_TINT = {
  trade_post: new Float32Array([1.06, 1.00, 0.90]),  // warm, lived-in
  shipyard: new Float32Array([1.10, 0.98, 0.76]),    // yard ochre
  refinery: new Float32Array([1.12, 0.88, 0.66]),    // oxide and soot
  relay: new Float32Array([0.88, 0.92, 1.00]),
  wreck: new Float32Array([0.72, 0.72, 0.78]),       // cold, unlit, dead
  monolith: new Float32Array([0.62, 0.64, 0.72]),    // not painted; not metal
  mine: new Float32Array([0.58, 0.58, 0.62]),        // matte, deliberately hard to see
  miner: new Float32Array([1.08, 0.92, 0.70]),
  trader: new Float32Array([0.94, 0.96, 1.04]),
  courier: new Float32Array([0.98, 1.00, 1.06]),
};

/** Default surface sun: low and off to one side, so the relief casts. */
/**
 * Sun direction on a surface — the vector pointing FROM the star TO the ground,
 * so a downward y is a sun that is up in the sky.
 *
 * Deliberately LOW: y of -0.30 puts the star about seventeen degrees above the
 * horizon. A high sun lights every upward face equally and a landscape lit that
 * way has no form in it — which, with the old fill of 0.9, is why five hundred
 * units of mountain range rendered as a flat silhouette. A raking light is what
 * makes a ridge a ridge, and it is also simply what a survey window looks like:
 * you land in the long light because that is when you can see the ground.
 */
/**
 * Bounding radius of a pos3/nrm3/uv2 vertex buffer, in model units.
 *
 * Cheap and exact enough: the shell projection only needs to know roughly how
 * big a mesh is so it can refuse to draw it larger than the shell it is being
 * projected onto.
 */
function meshRadius(vertexData) {
  let m = 0;
  for (let i = 0; i < vertexData.length; i += 8) {
    const d = vertexData[i] ** 2 + vertexData[i + 1] ** 2 + vertexData[i + 2] ** 2;
    if (d > m) m = d;
  }
  return Math.sqrt(m) || 1;
}

/**
 * Where the sun is on a surface. Points TOWARD the ground, so the y term is the
 * negative of the elevation.
 *
 * It was raked right down at −0.30 to force the relief to read, and it worked —
 * but it also put every horizontal surface at ndl 0.30, which is BELOW the 0.40
 * fill, so all flat ground clamped to fill and came out the same dead value
 * whatever colour band it was on. Half the terrain in a valley floor shot was
 * receiving no lighting information at all. At −0.44 flat ground sits just
 * above the fill and starts responding again, and a 26° sun is still low enough
 * to throw the long shadow shapes that make a landscape read.
 */
const SURFACE_SUN = new Float32Array([0.58, -0.44, -0.69]);

const HOSTILE_TINT = {
  keth_corvette: new Float32Array([0.88, 0.86, 0.92]),
  keth_lancer: new Float32Array([1.16, 0.98, 0.72]),
  drift_picket: new Float32Array([0.80, 0.90, 1.08]),
  drift_lance: new Float32Array([1.06, 0.72, 0.64]),
};
/**
 * Sub-pixel body cull. At FOV 70° one pixel subtends 1.222/HEIGHT rad, so a body
 * whose angular RADIUS is below a quarter of that covers less than half a pixel:
 * it renders as a flickering partial texel, not a world. Belts now run 19–26
 * rocks and the chart has ten systems, so skipping those is worth 10–15 draw
 * calls in a busy system — the difference between holding the <100 space budget
 * and not.
 *
 * Derived from the live buffer height rather than hardcoded at 270: a finer
 * render scale genuinely resolves smaller bodies, so the threshold has to follow
 * it or the cull would start eating worlds that are now several pixels across.
 * BODY_DRAW_CAP is what actually protects the budget at high scales.
 */
const BODY_MIN_RATIO = (RENDER.FOV_DEG * DEG2RAD) / RENDER.HEIGHT / 4;
/**
 * Quadratic limb-darkening coefficients (u1, u2) per spectral class.
 *
 * Measured values: the Sun is about (0.93, -0.23) in the visible. The trend is
 * physical — a cool star has a deep convective envelope and a steep temperature
 * gradient with depth, so the limb is much dimmer than the centre; a hot star's
 * radiative atmosphere is nearly isothermal over the same optical depth and
 * barely darkens. Degenerate remnants are effectively flat discs.
 */
/**
 * Differential-rotation rate, as fractions of a full sheet-width shift per
 * radian of the star's own slow drift. Small: the shear must be visible over
 * tens of seconds of watching, not a lap per second.
 */
const DIFF_ROT_RATE = 0.06;

const LIMB = {
  O: [0.28, 0.10], B: [0.34, 0.08], A: [0.46, 0.05], F: [0.62, -0.04],
  G: [0.93, -0.23], K: [0.88, -0.14], M: [0.82, -0.06],
  RG: [0.78, -0.02], KD: [0.86, -0.10], KM: [0.90, -0.18],
  BD: [0.70, 0.02], WD: [0.20, 0.06], NS: [0.12, 0.04],
};
/**
 * Hard ceiling on bodies drawn per frame, applied to the near end of the
 * far→near sort. The sub-pixel cull handles spread-out systems, but a COMPACT one
 * defeats it: a failed star has a habitable zone measured in hundredths of an AU,
 * so its whole disc — belt included — is in view at once and nothing is small
 * enough to drop. This is the guardrail that keeps the <100 space budget true no
 * matter what a future system definition asks for.
 */
const BODY_DRAW_CAP = 22;
/**
 * A stand-in for the ship in the CHASE frame, which is world-translated but not
 * world-rotated: directions there are already world directions, so "rotate into
 * ship-local" is the identity. Lets _drawComet keep one signature instead of
 * carrying a flag for which frame it is in.
 */
const IDENTITY_FRAME = { dirToLocal: (out, v) => { out[0] = v[0]; out[1] = v[1]; out[2] = v[2]; return out; } };
// per-biome atmosphere rim colour (limb glow)
const ATMO = {
  oceanic: [0.30, 0.48, 0.9], rocky: [0.5, 0.38, 0.26],
  ice: [0.6, 0.78, 0.98], lava: [0.95, 0.45, 0.2], jungle: [0.4, 0.72, 0.42],
  gas: [0.72, 0.56, 0.34], // thick warm haze
  toxic: [0.92, 0.74, 0.36], // crushing ochre greenhouse — the widest rim here
  tundra: [0.52, 0.68, 0.86], // thin, cold, pale
  sulfur: [0.62, 0.52, 0.28], // a trace SO₂ envelope, barely there
  // carbon and metal worlds deliberately have NO rim: an airless body with a
  // limb glow reads as a mistake, and their silhouettes are the whole point.
};

export class SpaceRenderer {
  /** @param {import('../core/Renderer.js').Renderer} renderer */
  constructor(renderer) {
    this.renderer = renderer;
    const gl = renderer.gl;

    // scratch matrices
    this._m = Mat4.create();
    this._a = Mat4.create();
    this._b = Mat4.create();
    this._viewRot = Mat4.create();
    this._skyVP = Mat4.create();
    /**
     * Per-system sky. Every system used to share one star field and one nebula
     * sheet, so arriving somewhere new looked exactly like where you left —
     * which is most of why a jump read as "nothing happened". `skyRot` rotates
     * the whole celestial sphere and `nebulaVariant` picks a different cloud,
     * both keyed off the system id, so the background itself tells you you
     * moved. Rotating beats rebuilding the star VBO: it's one matrix multiply.
     */
    this.skyRot = Mat4.create();
    Mat4.identity(this.skyRot);
    this.nebulaVariant = 0;
    this._L = Vec3.create();
    this._L2 = Vec3.create();
    this._L3 = Vec3.create();
    this._L4 = Vec3.create();
    // ring-billboard basis (_drawRingHalf) — kept off _L.._L4, which the star's
    // prominence placement aliases in a way that is easy to break by accident
    this._L5 = Vec3.create();
    this._L6 = Vec3.create();
    this._L7 = Vec3.create();
    this._ringPole = Vec3.create();
    // scratch for the plasma sprite batcher (no per-sprite allocation)
    this._sv0 = Vec3.create();
    this._sv1 = Vec3.create();
    this._sv2 = Vec3.create();
    this._lightDir = Vec3.create();
    this._dmgPuffs = []; // hull-damage smoke, ship-local coords

    this.starMesh = this._buildStars(gl);
    this.warpMesh = this._buildWarpStreaks(gl);
    /** 0 = no warp; 0..1 drives streak visibility during the jump sequence */
    this.warpT = 0;
    /**
     * The jump singularity (owner-specced 4-stage sequence): main.js drives
     * mode/intensity, this renderer owns the visuals — in-falling particles,
     * the growing black sphere with its photon ring, the spinning accretion
     * disk, and the starfield bending around the mass.
     * mode: null | 'infall' | 'hole' | 'consume'
     */
    this.warpFx = { mode: null, holeR: 0, bend: 0, intensity: 0 };
    // 900 particles across three roles (see _initWarpParticles): radial in-fall,
    // disk orbit in the tilted plane, and polar jet ejecta. The old 240 were all
    // one behaviour, which is why the singularity read as a flat sprite stack.
    this._wpN = 900;
    this.warpParts = this._buildDynamicPoints(gl, this._wpN);
    this._wpBuf = new Float32Array(this._wpN * STAR_FLOATS);
    // r, azimuth, polar, speed, orbit angle, role, life
    this._wpState = new Float32Array(this._wpN * 7);
    this._initWarpParticles();
    this.dustVao = this._buildDynamicPoints(gl, FLIGHT.DUST_COUNT);
    this.sphere = this._buildSphere(gl, 28, 14);
    this.billboard = this._buildBillboard(gl);
    // the singularity's accretion disk is REAL GEOMETRY, not a billboard: a
    // warped annulus whose far half is occluded by the horizon sphere
    this.warpDisk = this._buildDisk(gl, 72, 6);
    // All star plasma (prominence arcs + CME threads) batches through here. The
    // eruption's core pass is the biggest single batch now that it is built from
    // oriented streaks: 2 eruptions x 15 strands x 11 segments = 330, and dropping
    // sprites silently at the cap would thin a thread into a dotted line exactly
    // when it is most visible.
    this.sprites = this._buildSpriteBatch(gl, 560);
    this.nebulaMesh = this._buildNebulaSky(gl);

    /** @type {{sun:WebGLTexture, nebula:WebGLTexture[], planets:Object, hull:WebGLTexture, extGlow:WebGLTexture}} */
    this.tex = null;
    /** @type {{mesh:object}|null} exterior hull mesh (other ships only) */
    this.freighter = null;
    /** Player Aethon exterior (third-person view): hull (lit) + glow (emissive). */
    this.aethonHull = null;
    this.aethonGlow = null;
    this._modelM = Mat4.create();
    /**
     * Live deflector impacts: `{ dir, t, scale }` where `dir` is a UNIT vector in
     * SHIP-LOCAL space pointing at the strike. Storing the direction rather than a
     * world point is what welds each ripple to its spot on the field while the
     * ship manoeuvres under it.
     * @type {{dir:number[], t:number, scale:number}[]}
     */
    this._shieldHits = [];
    this._cm0 = Vec3.create();
    this._streakDir = Vec3.create();
    this._streakMid = Vec3.create();
    this._cm1 = Vec3.create();
    this._cm2 = Vec3.create();
    this._sh1 = Vec3.create();
    this._sh2 = Vec3.create();
    this._sh3 = Vec3.create();
    this._sh4 = Vec3.create();
  }

  /**
   * Register a deflector strike. `localDir` need not be normalised; anything
   * degenerate falls back to a hit on the nose, which is where most fire lands.
   * Capped at 6 live ripples — past that a sustained burst just costs draw calls
   * nobody can pick apart, and the oldest is the one you have stopped looking at.
   */
  shieldHit(localDir, scale = 1) {
    const d = Vec3.create();
    const L = localDir ? Math.hypot(localDir[0], localDir[1], localDir[2]) : 0;
    if (L > 1e-4) {
      d[0] = localDir[0] / L; d[1] = localDir[1] / L; d[2] = localDir[2] / L;
    } else { d[0] = 0; d[1] = 0; d[2] = -1; }
    this._shieldHits.push({ dir: d, t: 1, scale });
    if (this._shieldHits.length > 6) this._shieldHits.shift();
  }

  /** Register the player-ship exterior meshes (from ShipExterior.buildAethon). */
  /**
   * Point the sky for a system. `seed` is any stable number derived from the
   * system id; the same id always yields the same sky, so a system looks like
   * itself every time you come back.
   */
  setSky(seed, variants) {
    const h = Math.abs(Math.sin(seed * 12.9898) * 43758.5453);
    const yaw = (h % 1) * Math.PI * 2;
    const pitch = ((h * 7.13) % 1 - 0.5) * 1.4;
    Mat4.rotationY(this.skyRot, yaw);
    Mat4.rotationX(this._b, pitch);
    Mat4.multiply(this.skyRot, this.skyRot, this._b);
    this.nebulaVariant = Math.floor((h * 31.7) % 1 * (variants || 1));
  }

  setAethon(built) {
    this.aethonHull = this._spaceVao(this.renderer.gl, built.hull.vertexData, built.hull.indexData);
    this.aethonGlow = this._spaceVao(this.renderer.gl, built.glow.vertexData, built.glow.indexData);
  }

  // -- geometry builders ------------------------------------------------------

  _spaceVao(gl, vertexData, indexData) {
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.STATIC_DRAW);
    const stride = SPACE_FLOATS * 4;
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 3, gl.FLOAT, false, stride, 12);
    gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(2, 2, gl.FLOAT, false, stride, 24);
    const ibo = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ibo);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexData, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    this.renderer.liveBuffers += 2;
    this.renderer.liveVaos += 1;
    return { vao, vbo, ibo, count: indexData.length };
  }

  _buildStars(gl) {
    const rng = new RNG(0x57a125);
    const n = FLIGHT.STAR_COUNT;
    const data = new Float32Array(n * STAR_FLOATS);
    const colors = PALETTE.STARLIGHT.map(hexToRgbf);
    for (let i = 0; i < n; i++) {
      // uniform direction on the unit sphere
      const z = rng.range(-1, 1);
      const t = rng.range(0, Math.PI * 2);
      const r = Math.sqrt(1 - z * z);
      const o = i * STAR_FLOATS;
      data[o] = r * Math.cos(t);
      data[o + 1] = z;
      data[o + 2] = r * Math.sin(t);
      const c = colors[rng.chance(0.6) ? 1 : rng.chance(0.6) ? 0 : 2];
      const dim = rng.range(0.35, 1);
      data[o + 3] = c[0] * dim;
      data[o + 4] = c[1] * dim;
      data[o + 5] = c[2] * dim;
      data[o + 6] = rng.chance(0.12) ? 2 : 1;
    }
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    this._starAttribs(gl);
    gl.bindVertexArray(null);
    this.renderer.liveBuffers += 1;
    this.renderer.liveVaos += 1;
    return { vao, vbo, count: n };
  }

  /**
   * Hyperspace streaks: line segments on the sky sphere converging on the nose
   * (-z in ship-local sky space) — the classic "stars stretch into lines" jump
   * visual. Drawn through the stars program (v_color + u_alpha) as gl.LINES,
   * only while warpT > 0.
   */
  _buildWarpStreaks(gl) {
    const rng = new RNG(0x3a9b);
    const n = 340;
    const data = new Float32Array(n * 2 * STAR_FLOATS);
    const fwd = [0, 0, -1];
    for (let i = 0; i < n; i++) {
      const z = rng.range(-1, 1);
      const t = rng.range(0, Math.PI * 2);
      const r = Math.sqrt(1 - z * z);
      const d = [r * Math.cos(t), z, r * Math.sin(t)];
      // segment slides along the great circle toward the forward pole
      const pull = rng.range(0.35, 0.85), tail = rng.range(0.06, 0.16);
      const a = [d[0] + fwd[0] * pull, d[1] + fwd[1] * pull, d[2] + fwd[2] * pull];
      const b = [d[0] - fwd[0] * tail, d[1] - fwd[1] * tail, d[2] - fwd[2] * tail];
      for (const [k, p] of [[0, a], [1, b]]) {
        const L = Math.hypot(p[0], p[1], p[2]) || 1;
        const o = (i * 2 + k) * STAR_FLOATS;
        data[o] = p[0] / L; data[o + 1] = p[1] / L; data[o + 2] = p[2] / L;
        const cool = rng.range(0.65, 1); // white-blue streaks, no neon
        data[o + 3] = 0.82 * cool; data[o + 4] = 0.88 * cool; data[o + 5] = 1.0 * cool;
        data[o + 6] = 1;
      }
    }
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    this._starAttribs(gl);
    gl.bindVertexArray(null);
    this.renderer.liveBuffers += 1;
    this.renderer.liveVaos += 1;
    return { vao, vbo, count: n * 2 };
  }

  /**
   * Seed the singularity particles. Three ROLES, because one behaviour cannot
   * describe a black hole:
   *   0 — in-fall: streamers dropping radially from every direction.
   *   1 — disk: matter that has been captured and now orbits IN THE DISK PLANE,
   *       so it rides with the disk mesh rather than crossing it.
   *   2 — jet: plasma flung back out along the spin axis, accelerating away.
   * Colour is re-derived every frame from radius (see updateWarpFx) — matter
   * heats as it falls, and baking a fixed tint threw that away.
   */
  _initWarpParticles() {
    const rng = new RNG(0x5107e);
    for (let i = 0; i < this._wpN; i++) {
      const s = i * 7;
      // 46% in-fall, 40% disk, 14% jet
      const role = i % 50 < 23 ? 0 : i % 50 < 43 ? 1 : 2;
      this._wpState[s] = rng.range(14, 74); // r
      this._wpState[s + 1] = rng.range(0, Math.PI * 2); // azimuth
      this._wpState[s + 2] = Math.acos(rng.range(-1, 1)); // polar
      this._wpState[s + 3] = rng.range(0.7, 1.5); // speed factor
      this._wpState[s + 4] = rng.range(0, Math.PI * 2); // orbit angle
      this._wpState[s + 5] = role;
      this._wpState[s + 6] = rng.range(0, 1); // jet phase / disk radial jitter
      const o = i * STAR_FLOATS;
      this._wpBuf[o + 6] = role === 2 ? 1 : rng.chance(0.28) ? 3 : rng.chance(0.5) ? 2 : 1;
    }
  }

  /**
   * The singularity's spin axis and disk basis, in ship-local space. Fixed (the
   * hole grows out of the ship's spine, it does not tumble) and tilted off every
   * cardinal so the chase camera never catches the disk perfectly edge-on or
   * perfectly flat — either of those makes real geometry read as a sprite.
   */
  _warpBasis() {
    if (!this._wAxis) {
      this._wAxis = Vec3.normalize(Vec3.create(), [0.21, 0.94, 0.27]);
      this._wU = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), this._wAxis, [0, 0, 1]));
      this._wV = Vec3.cross(Vec3.create(), this._wAxis, this._wU);
    }
    return this._wAxis;
  }

  /**
   * Advance the singularity particles (ship-frame, origin = ship centre).
   * infall: streamers fall from all directions toward the spine.
   * hole/consume: they wind into a tilted, spinning accretion disk hugging the
   * photon ring, while stragglers keep falling in.
   */
  updateWarpFx(dt) {
    const fx = this.warpFx;
    if (!fx.mode) return;
    const rimR = Math.max(2.2, fx.holeR * 1.35);
    const diskOut = Math.max(3.2, fx.holeR * 4.5); // matches the disk mesh radius
    this._warpBasis();
    const ax = this._wAxis, u = this._wU, v = this._wV;
    const born = fx.holeR > 0.4; // no disk and no jets before the horizon exists
    for (let i = 0; i < this._wpN; i++) {
      const s = i * 7, o = i * STAR_FLOATS;
      let r = this._wpState[s];
      const role = born ? this._wpState[s + 5] : 0;
      if (role === 1) {
        // -- captured: settles onto the disk annulus and orbits IN ITS PLANE.
        // Keplerian: the inner rings sweep round far faster than the outer ones,
        // which is what shears the particle stream into visible spiral lanes.
        const band = 0.46 + this._wpState[s + 6] * 0.52; // where in the annulus
        const want = diskOut * band;
        r += (want - r) * Math.min(1, dt * 2.4);
        this._wpState[s + 4] += dt * (34 / Math.max(2.2, r)) * this._wpState[s + 3] * 3.4;
        const a = this._wpState[s + 4];
        const ca = Math.cos(a) * r, sa = Math.sin(a) * r;
        // ride the mesh's warp so particles sit ON the disk, not through it
        const warp = Math.sin(a + 0.6) * 0.115 * (0.25 + band) * diskOut;
        this._wpBuf[o] = u[0] * ca + v[0] * sa + ax[0] * warp;
        this._wpBuf[o + 1] = u[1] * ca + v[1] * sa + ax[1] * warp;
        this._wpBuf[o + 2] = u[2] * ca + v[2] * sa + ax[2] * warp;
      } else if (role === 2) {
        // -- jet: launched off the poles, accelerating, spiralling as it climbs
        const up = this._wpState[s + 6] < 0.5 ? 1 : -1;
        r += dt * (16 + 70 * fx.intensity) * (0.4 + r / diskOut) * this._wpState[s + 3];
        if (r > diskOut * 7) r = rimR * 0.8; // relaunch from the base
        this._wpState[s + 4] += dt * 5.2 * this._wpState[s + 3];
        // the beam is collimated: narrow at the throat, slowly opening out
        const spread = rimR * 0.16 + r * 0.055;
        const a = this._wpState[s + 4];
        const cu = Math.cos(a) * spread, cv = Math.sin(a) * spread;
        this._wpBuf[o] = ax[0] * r * up + u[0] * cu + v[0] * cv;
        this._wpBuf[o + 1] = ax[1] * r * up + u[1] * cu + v[1] * cv;
        this._wpBuf[o + 2] = ax[2] * r * up + u[2] * cu + v[2] * cv;
      } else {
        // -- radial in-fall, accelerating as it nears the mass
        const pull = 1 + 26 / Math.max(3, r);
        r -= dt * (7 + 46 * fx.intensity) * this._wpState[s + 3] * pull;
        if (r < rimR * 0.9) r = 55 + (i % 17); // re-spawn out on the sphere
        const th = this._wpState[s + 1], ph = this._wpState[s + 2];
        // frame dragging: the in-fall path is twisted around the spin axis, so
        // streamers curve into the disk instead of arriving on straight spokes
        const drag = (18 / Math.max(4, r)) * (this._flameT ?? 0) * 0.15;
        const c = Math.cos(th + drag), sn = Math.sin(th + drag);
        this._wpBuf[o] = Math.sin(ph) * c * r;
        this._wpBuf[o + 1] = Math.cos(ph) * r;
        this._wpBuf[o + 2] = Math.sin(ph) * sn * r;
      }
      // heat by proximity: ember far out, amber mid, white-hot on the rim. Jets
      // run cooler and bluer — synchrotron light, not thermal.
      const near = Math.max(0, Math.min(1, 1 - (r - rimR) / Math.max(6, diskOut * 1.6)));
      const h = near * near;
      if (role === 2) {
        this._wpBuf[o + 3] = 0.55 + 0.42 * h;
        this._wpBuf[o + 4] = 0.66 + 0.32 * h;
        this._wpBuf[o + 5] = 0.86 + 0.14 * h;
      } else {
        this._wpBuf[o + 3] = 0.62 + 0.38 * h;
        this._wpBuf[o + 4] = 0.30 + 0.62 * h;
        this._wpBuf[o + 5] = 0.16 + 0.66 * h;
      }
      this._wpState[s] = r;
    }
  }

  /**
   * Draw the singularity. This is a REAL 3D BODY, not a stack of stickers:
   *
   *   - the event horizon is a SPHERE mesh, so its silhouette is round from
   *     every angle and it OCCLUDES what passes behind it;
   *   - the accretion disk is a warped ANNULUS mesh lying in the hole's own
   *     tilted plane, drawn with depth test on — so its far half disappears
   *     behind the horizon and its near half sweeps in front of it, which is the
   *     one cue a billboard can never fake;
   *   - three more disk layers (a fast inner ring, a slow outer skirt, a
   *     counter-precessing shear layer) stack at different tilts and rates, so
   *     the structure keeps changing as the camera orbits;
   *   - the lensed secondary image, photon ring and blooms stay camera-facing,
   *     which is correct — a lensing artifact has no orientation of its own.
   *
   * The pass owns its own depth: the buffer is cleared first, so the singularity
   * self-sorts while still painting over the hull it is swallowing.
   */
  _drawWarpFx(chase) {
    const fx = this.warpFx;
    if (!fx.mode) return;
    const gl = this.renderer.gl;
    const t = this._flameT ?? 0;
    const eye = chase.eye;
    const born = fx.holeR > 0.05;
    // the singularity gets a fresh depth range all to itself. depthMask MUST be
    // on for the clear to land — the soft-sprite pass before us left it off.
    gl.depthMask(true);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.BLEND);

    let prog;
    // ---- horizon sphere + disk layers: opaque geometry, depth WRITE on -------
    if (born) {
      prog = this.renderer.use('space');
      gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vp);
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
      gl.uniform1f(prog.uniforms.u_diffRot, 0);
      gl.uniform2f(prog.uniforms.u_limb, 0, 0);
      // no per-plate mirroring: the hull pass leaves this on, and it would flip
      // the disk band's u and undo the doppler side
      gl.uniform1f(prog.uniforms.u_tileVary, 0);
      gl.activeTexture(gl.TEXTURE0);
      gl.uniform1i(prog.uniforms.u_texture, 0);

      const R = fx.holeR;
      const ax = this._warpBasis(), u = this._wU, v = this._wV;

      // wide hot haze FIRST, before anything solid: the glow sprite is bright in
      // the middle, so drawn later it would flood the void with amber
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      this._drawGlow(prog, [0, 0, 0], R * 5.6, this.tex.glowAmber, eye);

      // the horizon next, opaque, so every disk layer after it depth-tests
      // against a solid sphere instead of against transparent fragments
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.enable(gl.CULL_FACE);
      const m = this._m;
      // holeR IS the shadow radius (main.js's WARP_HOLE_R / WARP_CONSUME_R were
      // tuned against the old billboard's drawn disc, which was also ~1.0·holeR)
      const hs = R;
      m[0] = hs; m[1] = 0; m[2] = 0; m[3] = 0;
      m[4] = 0; m[5] = hs; m[6] = 0; m[7] = 0;
      m[8] = 0; m[9] = 0; m[10] = hs; m[11] = 0;
      m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
      gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.horizon ?? this.tex.blackHole);
      this.renderer.drawMesh(this.sphere);
      gl.disable(gl.CULL_FACE); // the disk is two-sided: we see it from below too

      // Disk layers. Each is the same annulus at its own radius, spin rate,
      // precession and tilt offset — four passes of one 5.2k-tri mesh, and the
      // interference between their rates is what makes the disk churn.
      if (this.tex.accretion) {
        gl.depthMask(false); // blended: test against the sphere, don't occlude
        const frames = this.tex.accretion;
        const LAYERS = [
          // [radius x R, spin rate, tilt about u, tilt about v, frame offset]
          [4.6, 0.62, 0.0, 0.0, 0],
          [3.15, 1.34, 0.19, -0.11, 1],
          [5.9, -0.34, -0.13, 0.16, 2],
          [2.35, 2.05, 0.07, 0.24, 1],
        ];
        for (const [k, rate, tu, tv, fo] of LAYERS) {
          const size = R * k;
          const a = t * rate;
          const ca = Math.cos(a), sa = Math.sin(a);
          // tilt the plane's normal slightly per layer, then spin within it
          const nx = ax[0] + u[0] * tu + v[0] * tv;
          const ny = ax[1] + u[1] * tu + v[1] * tv;
          const nz = ax[2] + u[2] * tu + v[2] * tv;
          const nl = Math.hypot(nx, ny, nz) || 1;
          const n0 = nx / nl, n1 = ny / nl, n2 = nz / nl;
          // rebuild an orthonormal pair in the tilted plane, spun by `a`
          let e0 = u[0] * ca + v[0] * sa, e1 = u[1] * ca + v[1] * sa, e2 = u[2] * ca + v[2] * sa;
          // re-orthogonalise against the tilted normal
          const dp = e0 * n0 + e1 * n1 + e2 * n2;
          e0 -= n0 * dp; e1 -= n1 * dp; e2 -= n2 * dp;
          const el = Math.hypot(e0, e1, e2) || 1;
          e0 /= el; e1 /= el; e2 /= el;
          const f0 = n1 * e2 - n2 * e1, f1 = n2 * e0 - n0 * e2, f2 = n0 * e1 - n1 * e0;
          m[0] = e0 * size; m[1] = e1 * size; m[2] = e2 * size; m[3] = 0;
          m[4] = n0 * size; m[5] = n1 * size; m[6] = n2 * size; m[7] = 0;
          m[8] = f0 * size; m[9] = f1 * size; m[10] = f2 * size; m[11] = 0;
          m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
          gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
          gl.bindTexture(gl.TEXTURE_2D,
            frames[(Math.floor(t * 9) + fo) % frames.length]);
          this.renderer.drawMesh(this.warpDisk);
        }
      }

      // Relativistic jets, along the REAL spin axis and still DEPTH-TESTED: the
      // horizon cuts the beam that is heading away from us, so one pole's jet is
      // clipped at the limb and the other is not. Cold-gas frames, not the amber
      // rocket flame — synchrotron light is blue-white, and at rocket width the
      // pair read as one opaque bar skewered through the hole.
      if (this.tex.coldJet) {
        const jl = R * (4.6 + 0.7 * Math.abs(Math.sin(t * 9)));
        const w = R * 0.17;
        const down = [-ax[0], -ax[1], -ax[2]];
        this._drawFlame(prog, [0, 0, 0], ax, jl, w, eye, this.tex.coldJet);
        this._drawFlame(prog, [0, 0, 0], down, jl, w, eye, this.tex.coldJet);
        // a hotter, shorter core inside each beam — the collimated spine
        this._drawFlame(prog, [0, 0, 0], ax, jl * 0.42, w * 0.5, eye, this.tex.flames);
        this._drawFlame(prog, [0, 0, 0], down, jl * 0.42, w * 0.5, eye, this.tex.flames);
      }
    }

    // ---- particles: depth-tested, so the ones behind the hole VANISH ---------
    // (the single strongest 3D cue in the whole effect — half the in-fall stream
    // is hidden at any moment, and which half changes as the camera orbits)
    prog = this.renderer.use('stars');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vp);
    gl.uniform3f(prog.uniforms.u_bend, 0, 0, 0);
    gl.uniform1f(prog.uniforms.u_alpha, Math.min(1, 0.25 + fx.intensity));
    if (born) { gl.enable(gl.DEPTH_TEST); } else { gl.disable(gl.DEPTH_TEST); }
    gl.depthMask(false);
    gl.bindVertexArray(this.warpParts.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.warpParts.vbo);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, this._wpBuf);
    gl.drawArrays(gl.POINTS, 0, this._wpN);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;

    // ---- lensing layers: camera-facing, depth test OFF ----------------------
    if (born) {
      prog = this.renderer.use('space');
      gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vp);
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
      gl.uniform1f(prog.uniforms.u_tileVary, 0);
      gl.activeTexture(gl.TEXTURE0);
      gl.uniform1i(prog.uniforms.u_texture, 0);
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      const d = Vec3.normalize(Vec3.create(), [-eye[0], -eye[1], -eye[2]]);
      const upRef = Math.abs(d[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
      const right = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), upRef, d));
      const up = Vec3.cross(Vec3.create(), d, right);
      const m = this._m;
      const face = (size, spin, tex) => {
        if (!tex) return;
        const c = Math.cos(spin), s = Math.sin(spin);
        const rx = right[0] * c + up[0] * s, ry = right[1] * c + up[1] * s, rz = right[2] * c + up[2] * s;
        const ux = up[0] * c - right[0] * s, uy = up[1] * c - right[1] * s, uz = up[2] * c - right[2] * s;
        m[0] = rx * size; m[1] = ry * size; m[2] = rz * size; m[3] = 0;
        m[4] = ux * size; m[5] = uy * size; m[6] = uz * size; m[7] = 0;
        m[8] = -d[0]; m[9] = -d[1]; m[10] = -d[2]; m[11] = 0;
        m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
        gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
        gl.bindTexture(gl.TEXTURE_2D, tex);
        this.renderer.drawMesh(this.billboard);
      };
      // the far side of the disk, bent up over the top of the shadow and down
      // under its bottom — the crescents that say "this mass lenses light".
      // The arcs start at 0.44 of the quad, so 2.34R puts their inner edge just
      // outside the shadow's limb.
      face(fx.holeR * 2.34, 0, this.tex.lensArc);
      // the photon ring, breathing. Its band sits at 0.62 of the quad, so 1.72R
      // lands it at ~1.07R — hugging the limb, which is where it belongs.
      face(fx.holeR * 1.72 * (1 + 0.05 * Math.sin(t * 26)), 0, this.tex.ring);
      // throat blooms where the jets leave the poles — these DO belong over the
      // top, they are the brightest thing in frame
      {
        const ax = this._warpBasis();
        const th = fx.holeR * 1.15;
        this._drawGlow(prog, [ax[0] * th, ax[1] * th, ax[2] * th], fx.holeR * 0.52, this.tex.glowBlue, eye);
        this._drawGlow(prog, [-ax[0] * th, -ax[1] * th, -ax[2] * th], fx.holeR * 0.52, this.tex.glowBlue, eye);
      }
    }
    gl.disable(gl.BLEND);
    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
  }

  _buildDynamicPoints(gl, count) {
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, count * STAR_FLOATS * 4, gl.DYNAMIC_DRAW);
    this._starAttribs(gl);
    gl.bindVertexArray(null);
    this.renderer.liveBuffers += 1;
    this.renderer.liveVaos += 1;
    return { vao, vbo, count };
  }

  /**
   * Dynamic camera-facing sprite BATCH (space vertex format). All the star's
   * plasma — prominence arcs and CME clouds — goes through one buffer and ONE
   * draw call instead of a billboard draw per blob: a dramatic star close-up was
   * costing ~50 extra draws and blowing the <100 space budget. Non-indexed
   * triangles, 6 verts per sprite.
   */
  _buildSpriteBatch(gl, maxSprites) {
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    const vbo = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
    gl.bufferData(gl.ARRAY_BUFFER, maxSprites * 6 * SPACE_FLOATS * 4, gl.DYNAMIC_DRAW);
    this._spaceAttribs(gl);
    gl.bindVertexArray(null);
    this.renderer.liveBuffers += 1;
    this.renderer.liveVaos += 1;
    return { vao, vbo, maxSprites, data: new Float32Array(maxSprites * 6 * SPACE_FLOATS), n: 0 };
  }

  /** Reset the plasma batch for this frame. */
  _spriteReset() { if (this.sprites) this.sprites.n = 0; }

  /**
   * Append one camera-facing quad. Colour comes from the texture, so the batch
   * carries only geometry + uv; `fade` scales the quad instead of alpha (pixel
   * truth: sprites dissolve by dither, they don't cross-fade).
   */
  _spritePush(posF, size, eye) {
    const b = this.sprites;
    if (!b || b.n >= b.maxSprites || size < 0.04) return;
    const view = this._sv0;
    view[0] = posF[0] - (eye?.[0] ?? 0); view[1] = posF[1] - (eye?.[1] ?? 0); view[2] = posF[2] - (eye?.[2] ?? 0);
    Vec3.normalize(view, view);
    const upRef = Math.abs(view[1]) > 0.9 ? AXIS_X_REF : AXIS_Y_REF;
    const right = Vec3.normalize(this._sv1, Vec3.cross(this._sv1, upRef, view));
    const up = Vec3.cross(this._sv2, view, right);
    const d = b.data;
    let o = b.n * 6 * SPACE_FLOATS;
    // corners (x,y) with uvs; two triangles
    const C = [[-1, -1, 0, 1], [1, -1, 1, 1], [1, 1, 1, 0], [-1, -1, 0, 1], [1, 1, 1, 0], [-1, 1, 0, 0]];
    for (const [cx, cy, u, v] of C) {
      d[o] = posF[0] + (right[0] * cx + up[0] * cy) * size;
      d[o + 1] = posF[1] + (right[1] * cx + up[1] * cy) * size;
      d[o + 2] = posF[2] + (right[2] * cx + up[2] * cy) * size;
      d[o + 3] = -view[0]; d[o + 4] = -view[1]; d[o + 5] = -view[2];
      d[o + 6] = u; d[o + 7] = v;
      o += SPACE_FLOATS;
    }
    b.n++;
  }

  /**
   * Append one ORIENTED quad — a streak whose long axis follows a world direction.
   *
   * This is the capability the sprite batch was missing, and its absence is why the
   * coronal mass ejection could only ever be built from round blobs: `_spritePush`
   * aligns every quad to the screen axes, so nothing drawn through it can point
   * anywhere. A filament has a direction by definition.
   *
   * `dirF` is projected into the view plane and normalised there, so a thread seen
   * end-on collapses to a short stub rather than spinning to face the camera —
   * which is the correct foreshortening for something with a real orientation.
   *
   * @param {number[]} posF centre of the streak, in frame coords
   * @param {number[]} dirF direction its length runs along
   * @param {number} halfLen half its length
   * @param {number} halfWid half its width
   */
  _spriteStreak(posF, dirF, halfLen, halfWid, eye) {
    const b = this.sprites;
    if (!b || b.n >= b.maxSprites || halfLen < 0.03) return;
    const view = this._sv0;
    view[0] = posF[0] - (eye?.[0] ?? 0); view[1] = posF[1] - (eye?.[1] ?? 0); view[2] = posF[2] - (eye?.[2] ?? 0);
    Vec3.normalize(view, view);
    // component of dirF perpendicular to the view ray
    const dp = dirF[0] * view[0] + dirF[1] * view[1] + dirF[2] * view[2];
    const al = this._sv1;
    al[0] = dirF[0] - view[0] * dp; al[1] = dirF[1] - view[1] * dp; al[2] = dirF[2] - view[2] * dp;
    const aLen = Math.hypot(al[0], al[1], al[2]);
    if (aLen < 1e-4) return; // dead end-on: contributes nothing, and would NaN
    al[0] /= aLen; al[1] /= aLen; al[2] /= aLen;
    // foreshorten: a thread pointing away from us is shorter on screen
    const fore = halfLen * aLen;
    const side = Vec3.cross(this._sv2, view, al);
    const d = b.data;
    let o = b.n * 6 * SPACE_FLOATS;
    // uv maps the thread texture's LENGTH to v, which is how filamentTexture paints
    const C = [[-1, -1, 0, 1], [1, -1, 1, 1], [1, 1, 1, 0], [-1, -1, 0, 1], [1, 1, 1, 0], [-1, 1, 0, 0]];
    for (const [cs, cl, u, v] of C) {
      d[o] = posF[0] + side[0] * cs * halfWid + al[0] * cl * fore;
      d[o + 1] = posF[1] + side[1] * cs * halfWid + al[1] * cl * fore;
      d[o + 2] = posF[2] + side[2] * cs * halfWid + al[2] * cl * fore;
      d[o + 3] = -view[0]; d[o + 4] = -view[1]; d[o + 5] = -view[2];
      d[o + 6] = u; d[o + 7] = v;
      o += SPACE_FLOATS;
    }
    b.n++;
  }

  /** Upload + draw the whole plasma batch with one texture, one draw call. */
  _spriteFlush(prog, tex) {
    const b = this.sprites;
    if (!b || b.n === 0 || !tex) return;
    const gl = this.renderer.gl;
    gl.uniform1f(prog.uniforms.u_lit, 0);
    Mat4.identity(this._m);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._m);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.bindVertexArray(b.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, b.vbo);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, b.data.subarray(0, b.n * 6 * SPACE_FLOATS));
    gl.drawArrays(gl.TRIANGLES, 0, b.n * 6);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;
    b.n = 0;
  }

  _spaceAttribs(gl) {
    const stride = SPACE_FLOATS * 4;
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 3, gl.FLOAT, false, stride, 12);
    gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(2, 2, gl.FLOAT, false, stride, 24);
  }

  _starAttribs(gl) {
    const stride = STAR_FLOATS * 4;
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, stride, 0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(1, 3, gl.FLOAT, false, stride, 12);
    gl.enableVertexAttribArray(2);
    gl.vertexAttribPointer(2, 1, gl.FLOAT, false, stride, 24);
  }

  _buildSphere(gl, lonSegs, latSegs) {
    const verts = [];
    const indices = [];
    for (let la = 0; la <= latSegs; la++) {
      const v = la / latSegs;
      const phi = v * Math.PI;
      for (let lo = 0; lo <= lonSegs; lo++) {
        const u = lo / lonSegs;
        const theta = u * Math.PI * 2;
        const x = Math.sin(phi) * Math.cos(theta);
        const y = Math.cos(phi);
        const z = Math.sin(phi) * Math.sin(theta);
        verts.push(x, y, z, x, y, z, u, v);
      }
    }
    const row = lonSegs + 1;
    for (let la = 0; la < latSegs; la++) {
      for (let lo = 0; lo < lonSegs; lo++) {
        const a = la * row + lo;
        // wound CCW as seen from OUTSIDE so standard back-face culling shows the
        // outer surface (the far/inner hemisphere is culled — no overwrite wedges,
        // and the near hemisphere always renders, even on a body's night side)
        indices.push(a, a + 1, a + row, a + 1, a + row + 1, a + row);
      }
    }
    return this._spaceVao(gl, new Float32Array(verts), new Uint32Array(indices));
  }

  /**
   * WARPED ANNULUS in the XZ plane — the accretion disk's real geometry.
   * Inner edge at 0.42 of the outer radius (the photon sphere), outer at 1.
   * uv: u wraps once around (so the accretion band must repeat horizontally),
   * v runs 0 at the inner edge to 1 at the frayed outer edge.
   *
   * The disk is WARPED, not flat: a real accretion disk precesses out of plane
   * (Bardeen-Petterson), and mechanically the warp is what makes the mesh read
   * as a solid body rather than a decal — the near rim rises above the horizon's
   * equator on one side and dips below it on the other, so the sphere's
   * silhouette cuts the disk at a different height all the way round.
   */
  _buildDisk(gl, lonSegs, radSegs) {
    const verts = [];
    const indices = [];
    const IN = 0.42;
    for (let ri = 0; ri <= radSegs; ri++) {
      const v = ri / radSegs;
      const rad = IN + v * (1 - IN);
      for (let lo = 0; lo <= lonSegs; lo++) {
        const u = lo / lonSegs;
        const th = u * Math.PI * 2;
        const x = Math.cos(th) * rad, z = Math.sin(th) * rad;
        // one full warp cycle per revolution, strongest at the outer edge
        const y = Math.sin(th + 0.6) * 0.115 * (0.25 + v);
        verts.push(x, y, z, 0, 1, 0, u, v);
      }
    }
    const row = lonSegs + 1;
    for (let ri = 0; ri < radSegs; ri++) {
      for (let lo = 0; lo < lonSegs; lo++) {
        const a = ri * row + lo;
        indices.push(a, a + 1, a + row, a + 1, a + row + 1, a + row);
      }
    }
    return this._spaceVao(gl, new Float32Array(verts), new Uint32Array(indices));
  }

  _buildBillboard(gl) {
    // unit quad in XY, normal +z, uv 0..1
    const verts = new Float32Array([
      -1, -1, 0, 0, 0, 1, 0, 1,
      1, -1, 0, 0, 0, 1, 1, 1,
      1, 1, 0, 0, 0, 1, 1, 0,
      -1, 1, 0, 0, 0, 1, 0, 0,
    ]);
    return this._spaceVao(gl, verts, new Uint32Array([0, 1, 2, 0, 2, 3]));
  }

  /** Three fixed nebula patches baked onto the unit sky sphere. */
  _buildNebulaSky(gl) {
    const dirs = [
      [[0.42, 0.3, -0.85], 0.95],
      [[-0.75, -0.12, -0.62], 1.25],
      [[0.7, -0.35, 0.62], 1.05],
    ];
    const verts = [];
    const indices = [];
    for (const [d, size] of dirs) {
      const dir = Vec3.normalize(Vec3.create(), d);
      const upRef = Math.abs(dir[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
      const right = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), upRef, dir));
      const up = Vec3.cross(Vec3.create(), dir, right);
      const base = verts.length / SPACE_FLOATS;
      const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
      const uvs = [[0, 1], [1, 1], [1, 0], [0, 0]];
      for (let i = 0; i < 4; i++) {
        const [cx, cy] = corners[i];
        const p = [
          dir[0] + (right[0] * cx + up[0] * cy) * size,
          dir[1] + (right[1] * cx + up[1] * cy) * size,
          dir[2] + (right[2] * cx + up[2] * cy) * size,
        ];
        verts.push(p[0], p[1], p[2], -dir[0], -dir[1], -dir[2], uvs[i][0], uvs[i][1]);
      }
      indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
    return this._spaceVao(gl, new Float32Array(verts), new Uint32Array(indices));
  }

  /** Register the freighter hull mesh (from ShipExterior.buildFreighter). */
  setFreighterMesh(data) {
    this.freighter = this._spaceVao(this.renderer.gl, data.vertexData, data.indexData);
  }

  /**
   * THE GROUND. Upload one landing's terrain patch and hold the site's colours.
   *
   * Called on touchdown and again with null on takeoff, so exactly one terrain
   * mesh exists at a time — a patch is ~8k triangles and there is no reason to
   * keep the last three worlds resident.
   *
   * @param {object|null} terrain from SurfaceGen.buildTerrain
   * @param {object|null} colors  from SurfaceGen.surfaceColors
   */
  setTerrain(terrain, colors) {
    const gl = this.renderer.gl;
    if (this.terrainVao) { this.renderer.deleteMesh?.(this.terrainVao); this.terrainVao = null; }
    if (this.terrainRampTex) { gl.deleteTexture(this.terrainRampTex); this.terrainRampTex = null; }
    this.terrainColors = colors;
    if (!terrain) return;
    this.terrainVao = this._spaceVao(gl, terrain.vertexData, terrain.indexData);
    // THE RAMP. The ground's UVs are not texture coordinates — `u` is a band
    // index by height and slope and `v` is a dither row (see SurfaceGen). The
    // ground used to be drawn with the hull PLATING texture under a flat tint,
    // which is exactly why a whole planet came out one colour with panel lines
    // on it. Clamped, never repeated: wrapping this strip would wrap a cliff
    // face round to a snow cap.
    if (terrain.ramp) this.terrainRampTex = this.renderer.createTexture2D(terrain.ramp);
    // The horizon wash gets its own gradient rather than borrowing the radial
    // glow sprite, whose dithered rings came out as concentric arcs across the
    // sky. Built once and kept: it is the same fade on every world, and the
    // world's own colour comes from `u_tint`.
    if (!this.skyStripTex) this.skyStripTex = this.renderer.createTexture2D(skyStrip());
    // THE HORIZON WASH. An inward-facing cylinder around the camera, brightest
    // at the skyline and fading out overhead — which is what an atmosphere
    // actually looks like from the ground and the only thing that separates a
    // thick sky from a vacuum once the stars are dimmed. Built once per landing
    // beside the terrain it belongs to.
    if (!this.skyBand) {
      const v = [], i = [];
      // R must sit INSIDE the interior far plane: the band is drawn through
      // `camera.projection` with the depth test off, so a radius of 600 against
      // FAR=120 clipped the entire horizon wash out of every frame. It is a
      // rotation-only shell, so the radius is arbitrary as long as it renders.
      const N = 24, R = 70;
      for (let k = 0; k < N; k++) {
        const a0 = (k / N) * Math.PI * 2, a1 = ((k + 1) / N) * Math.PI * 2;
        const x0 = Math.cos(a0) * R, z0 = Math.sin(a0) * R;
        const x1 = Math.cos(a1) * R, z1 = Math.sin(a1) * R;
        const base = v.length / 8;
        // v runs 0 at the skyline to 1 overhead; the glow sheet's own falloff
        // does the fade, so the band needs no gradient of its own.
        // Tall. The band used to stop at 0.46 R, so its top rim cut a hard
        // curved edge across the sky the moment you raised your eyes — a dome
        // seam where an atmosphere should be. It now runs from well below the
        // skyline to well above the top of the frustum, and the glow sheet's
        // own radial falloff does the fade.
        // v runs from the CENTRE of the glow sheet at the skyline out to its
        // edge at the zenith — half the sheet, not all of it. Spanning 0.99 to
        // 0.02 crossed the sheet's dithered rings twice on the way through, and
        // those rings came out as concentric arcs painted across the sky. Half
        // the sheet is monotonic: bright at the horizon, dark overhead, which
        // is what an atmosphere actually does.
        v.push(x0, -R * 0.55, z0, 0, 0, 1, 0.5, 1.0);
        v.push(x1, -R * 0.55, z1, 0, 0, 1, 0.5, 1.0);
        v.push(x1, R * 2.60, z1, 0, 0, 1, 0.5, 0.0);
        v.push(x0, R * 2.60, z0, 0, 0, 1, 0.5, 0.0);
        i.push(base, base + 2, base + 1, base, base + 3, base + 2);
      }
      this.skyBand = this._spaceVao(gl, new Float32Array(v), new Uint32Array(i));
    }
  }

  /**
   * Draw a world from ON it.
   *
   * THE HORIZON IS THE WHOLE TRICK. The terrain patch is flat (see the note in
   * SurfaceGen on why curvature is not worth a hundred times the triangles), so
   * what says "planet" is the sky above it: a dithered vertical wash from the
   * atmosphere's own colour at the horizon up to near-black at the zenith,
   * thicker and brighter the denser the air. On an airless world the wash is
   * nothing and the stars come all the way down to the ground, which is exactly
   * the difference you see standing on the Moon.
   *
   * @param {object} camera the player camera, standing on the surface
   * @param {object} site   {profile, sunDir}
   */
  renderSurface(camera, site, system) {
    const gl = this.renderer.gl;
    const c = this.terrainColors;
    if (!c) return;

    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.disable(gl.CULL_FACE);

    // -- sky ------------------------------------------------------------------
    // Rotation only, taken from the camera's own view matrix by dropping its
    // translation. It used to be rebuilt from `camera.yaw`/`camera.pitch`,
    // which is fine for a walker and useless for a ship: a hull banking through
    // an atmosphere has a full quaternion attitude and no meaningful yaw/pitch
    // pair, and the sky would have stayed level while the world rolled. One
    // matrix copy serves both, and there is no second code path to drift.
    Mat4.copy(this._viewRot, camera.view);
    this._viewRot[12] = 0; this._viewRot[13] = 0; this._viewRot[14] = 0;
    Mat4.multiply(this._viewRot, this._viewRot, this.skyRot);
    Mat4.multiply(this._skyVP, camera.projection, this._viewRot);

    let prog = this.renderer.use('stars');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, this._skyVP);
    gl.uniform3f(prog.uniforms.u_bend, 0, 0, 0);
    // A thick atmosphere drowns the starfield; a trace one barely dims it, and
    // on an airless world the stars come all the way down to the ground — which
    // is exactly the difference you see standing on the Moon.
    gl.uniform1f(prog.uniforms.u_alpha, Math.max(0.05, 1 - c.haze * 1.15));
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.bindVertexArray(this.starMesh.vao);
    gl.drawArrays(gl.POINTS, 0, this.starMesh.count);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;
    gl.disable(gl.BLEND);

    // -- atmospheric wash over the stars --------------------------------------
    // A trace atmosphere is not an atmosphere: below this the band's own rim
    // reads as a dark dome edge over a starfield, which is worse than nothing.
    if (this.skyBand && c.haze > 0.07) {
      prog = this.renderer.use('space');
      gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, this._skyVP);
      gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
      gl.uniform1f(prog.uniforms.u_lit, 0); // emissive: this is sky, not a surface
      gl.uniform3fv(prog.uniforms.u_tint, this._skyTint(c));
      Mat4.identity(this._a);
      gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
      gl.bindTexture(gl.TEXTURE_2D, this.skyStripTex ?? this.tex.glowWhite ?? this.tex.glowAmber);
      this.renderer.drawMesh(this.skyBand);
      gl.disable(gl.BLEND);
      gl.uniform3fv(prog.uniforms.u_tint, WHITE3);
    }

    // -- the ground ----------------------------------------------------------
    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.CULL_FACE);
    prog = this.renderer.use('space');
    // THE GROUND GETS ITS OWN PROJECTION. `camera.viewProjection` carries the
    // interior's 120-unit far plane, which clipped all but a 120-unit disc of a
    // 3200-unit patch — no horizon, no skyline, no relief. Built once, from the
    // camera's own FOV and aspect, and combined with the live view matrix.
    if (!this._surfProj) {
      this._surfProj = Mat4.create();
      Mat4.perspective(this._surfProj, (RENDER.FOV_DEG * Math.PI) / 180,
        RENDER.WIDTH / RENDER.HEIGHT, RENDER.SURFACE_NEAR, RENDER.SURFACE_FAR);
      this._surfVP = Mat4.create();
    }
    Mat4.multiply(this._surfVP, this._surfProj, camera.view);
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, this._surfVP);
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
    // Fill is high because a surface lit only by a low sun is unreadable at
    // 480x270 — the shadowed side of every ridge would be one flat black. 0.62
    // was still too dark: a lava world's own ground ramp starts at #3a2018, and
    // multiplying that by a half-lit term produced a screen of near-black with
    // a horizon line in it.
    // FILL, retuned with the ramp (0.36.0). It was 0.9 because the ground was
    // one dark tinted texture and anything less made a lava world unreadable —
    // but a fill of 0.9 means the lit and shadowed faces of a ridge differ by
    // a tenth, which is why five hundred units of mountain rendered as a
    // silhouette with no form in it. The ramp now carries the world's own
    // brightness, so the light term is free to actually be a light term.
    gl.uniform1f(prog.uniforms.u_fill, 0.40);
    gl.uniform1f(prog.uniforms.u_lit, 1);
    gl.uniform3fv(prog.uniforms.u_lightDir, site.sunDir ?? SURFACE_SUN);
    // WHITE tint and NO tile variation: the ground carries its own colour in
    // the ramp now, so tinting it would multiply a palette by a palette and
    // `u_tileVary` — which mirrors and value-steps each texture tile — would
    // scramble a strip whose columns mean something.
    gl.uniform3fv(prog.uniforms.u_tint, WHITE3);
    Mat4.identity(this._a);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
    gl.bindTexture(gl.TEXTURE_2D, this.terrainRampTex ?? this.tex.hull);
    if (this.terrainVao) this.renderer.drawMesh(this.terrainVao);

    gl.disable(gl.CULL_FACE);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.depthMask(false);
    void system;
    gl.disable(gl.BLEND);
    gl.depthMask(true);
  }

  /**
   * THE HULL, ON A WORLD. Draws the player's ship at its terrain-local position
   * for the third-person landing view.
   *
   * Everything else out here is projected onto a shell around the eye, which is
   * exactly wrong on a surface: the ground is a real mesh at real coordinates
   * and the ship has to be somewhere ON it, at its true size, casting the same
   * silhouette against the same horizon. So this draws through the surface
   * projection with an honest model matrix and nothing clever at all.
   *
   * @param {object} camera the surface chase camera (view + projection)
   * @param {object} ship   the Spaceship, for its attitude
   * @param {number[]} at   hull position in terrain-local coordinates
   * @param {number[]} sun  direction from the star toward the ground
   */
  renderSurfaceHull(camera, ship, at, sun) {
    const gl = this.renderer.gl;
    if (!this.aethonHull || !this._surfProj) return;
    const prog = this.renderer.use('space');
    Mat4.multiply(this._surfVP, this._surfProj, camera.view);
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, this._surfVP);
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
    gl.uniform1f(prog.uniforms.u_lit, 1);
    gl.uniform1f(prog.uniforms.u_fill, 0.55);
    gl.uniform3fv(prog.uniforms.u_lightDir, sun ?? SURFACE_SUN);
    gl.uniform3fv(prog.uniforms.u_tint, this.hullTint ?? WHITE3);
    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
    gl.enable(gl.CULL_FACE);
    Mat4.translation(this._a, at[0], at[1], at[2]);
    Mat4.fromQuat(this._modelM, ship.quat);
    Mat4.multiply(this._a, this._a, this._modelM);
    // Full size, not SHIP_CHASE_SCALE. That factor exists to shrink the hull
    // against a projected sky shell; here it would make the ship a toy sitting
    // on a landscape whose units it genuinely shares.
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
    gl.uniform1f(prog.uniforms.u_tileVary, 1);
    gl.bindTexture(gl.TEXTURE_2D, this.tex.hullAethon ?? this.tex.hull);
    this.renderer.drawMesh(this.aethonHull);
    gl.uniform1f(prog.uniforms.u_tileVary, 0);
    gl.uniform3fv(prog.uniforms.u_tint, WHITE3);
    if (this.aethonGlow) {
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.extGlow ?? this.tex.glowAmber);
      this.renderer.drawMesh(this.aethonGlow);
      gl.uniform1f(prog.uniforms.u_lit, 1);
    }
  }

  /** The wash colour: the sky ramp, scaled by how much air there is to glow. */
  _skyTint(c) {
    this._skyC ??= new Float32Array(3);
    // 3.2 was set when the band was a thin strip along the skyline and half of
    // it never rendered. It is now a full dome, drawn ADDITIVELY, and at that
    // gain a hazy world's wash saturated the entire view — flying into one, the
    // windshield went flat red and the landscape you were descending to could
    // not be seen through it at all. 1.35 leaves a wash you can fly in.
    const k = 0.35 + c.haze * 1.5;
    for (let i = 0; i < 3; i++) this._skyC[i] = c.sky[i] * k * 1.35;
    return this._skyC;
  }

  /**
   * Register the structure library (world/Structures.js `buildAllStructures`).
   *
   * Every one of these was previously the freighter mesh at a different scale,
   * so a trade post, a shipyard and a wreck were the same object three times.
   * Keyed by the `structure` field on a `ships[]` record; anything without one
   * still falls through to the freighter, which is what keeps old saves and any
   * un-typed lore record rendering.
   *
   * @param {Record<string,{hull:object, glow:object|null}>} lib
   */
  setStructureMeshes(lib) {
    const gl = this.renderer.gl;
    this.structures = {};
    for (const [k, m] of Object.entries(lib)) {
      this.structures[k] = {
        hull: this._spaceVao(gl, m.hull.vertexData, m.hull.indexData),
        glow: m.glow ? this._spaceVao(gl, m.glow.vertexData, m.glow.indexData) : null,
        // The mesh's own bounding radius in MODEL units. Needed because the
        // shell projection has a hard geometric limit — see `_drawNpcHull`.
        radius: meshRadius(m.hull.vertexData),
      };
    }
  }

  /**
   * The star is a real 3D sphere now (owner task): spectral-class surface
   * texture spinning slowly, the old billboard demoted to a corona halo behind
   * it, and CME prominences — warm particles rising and falling off the limb.
   */
  tickStellar(dt, system) {
    // Slow spin so granulation drifts across the disc, not just pulses in place.
    // 0.03 rad/s ~ a 3.5 min rotation: visible at a close approach, invisible
    // from across the system, which is roughly how a real photosphere reads.
    this._starAngle = (this._starAngle ?? 0) + dt * 0.03;
    this._flameT = (this._flameT ?? 0) + dt;
    if (this.shieldT > 0) this.shieldT = Math.max(0, this.shieldT - dt * 2.2);
    // deflector ripples run out in ~0.55s — a wavefront crossing a 70m field
    for (let i = this._shieldHits.length - 1; i >= 0; i--) {
      this._shieldHits[i].t -= dt * 1.8;
      if (this._shieldHits[i].t <= 0) this._shieldHits.splice(i, 1);
    }
    // hull-damage smoke: drift aft-ish in ship-local space and thin out
    for (let i = this._dmgPuffs.length - 1; i >= 0; i--) {
      const s = this._dmgPuffs[i];
      s.ttl -= dt;
      s.pos[1] += dt * 0.9; s.pos[2] += dt * 2.6; // rises + streams behind
      if (s.ttl <= 0) this._dmgPuffs.splice(i, 1);
    }
    if (!this._proms) {
      // 5 prominence loops: magnetic arcs that grow off the limb, hang, and
      // collapse — each on its own slow clock (the CME animation)
      this._proms = [];
      const rng = new RNG(0xce11);
      for (let i = 0; i < 5; i++) {
        this._proms.push({
          lon: rng.range(0, Math.PI * 2), tilt: rng.range(-0.5, 0.5),
          width: rng.range(0.25, 0.5), p: rng.range(0, 1), sp: rng.range(0.028, 0.055),
        });
      }
      this._promRng = rng;
      /** erupting mass ejections: plasma clouds that tear off and fly clear */
      this._cmes = [];
      this._cmeCool = 5;
      /**
       * FLARES — brief, bright, LOCALISED brightenings on the photosphere. The
       * disc already churns (four granulation frames plus differential rotation)
       * and already throws prominences and eruptions, but all of that happens on a
       * timescale of many seconds. A flare is the fast event: a magnetic
       * reconnection lights a patch a few percent of the disc across for under a
       * second, and it is what makes a star read as ACTIVE rather than merely
       * animated. Cheap — two or three sprites each.
       */
      this._flares = [];
      this._flareCool = 2.5;
    }
    for (const c of this._proms) {
      c.p += dt * c.sp;
      if (c.p >= 1) {
        c.p = 0;
        c.lon = this._promRng.range(0, Math.PI * 2);
        c.tilt = this._promRng.range(-0.5, 0.5);
        c.width = this._promRng.range(0.25, 0.5);
      }
    }
    // -- CORONAL MASS EJECTIONS -----------------------------------------------
    // REBUILT FROM NOTHING (owner, session 17c). The previous version was three
    // shells of round cloudy sprites and it read as smoke, which is a fair
    // description of what it was. A coronagraph image of a real CME has no clouds
    // and no circles in it at all — it is structure:
    //
    //   * a taut, thin, BRIGHT LEADING ARC, drawn tangentially, that expands
    //     self-similarly and stays narrow;
    //   * long thin THREADS of plasma streaming behind it along field lines,
    //     fanning slightly, each one meandering;
    //   * a dark evacuated CAVITY, which is the ABSENCE of threads at middle radii
    //     rather than anything drawn;
    //   * a twisted helical FLUX ROPE of intertwined strands at the core, anchored
    //     at two footpoints on the limb.
    //
    // So an eruption is now a set of STRANDS, each a chain of points along an
    // expanding arch with a helical twist about the rope axis, plus an arc of
    // tangential segments at the front. Every piece is drawn with _spriteStreak,
    // which orients it along the local tangent — that orientation is the whole
    // difference, and it is why the old sprite batch could not have done this.
    this._cmeCool -= dt;
    if (this._cmeCool <= 0 && this._cmes.length < 2) {
      const rng = this._promRng;
      this._cmeCool = rng.range(7, 16);
      // The rope's own geometry: where it is anchored, how wide it opens, how hard
      // it twists. One eruption, one rope — not a bag of independent blobs.
      const strands = [];
      const N = 26;
      for (let i = 0; i < N; i++) {
        const across = N > 1 ? (i / (N - 1) - 0.5) * 2 : 0; // -1..1 across the rope
        const core = Math.abs(across) < 0.38;
        strands.push({
          across,
          // phase around the rope's cross-section drives the helix, so strands
          // visibly wind over and under each other as they climb
          phase: rng.range(0, Math.PI * 2),
          twist: rng.range(1.5, 2.6) * (rng.chance(0.5) ? 1 : -1),
          // core strands ride the middle and are the bright ones; the outliers are
          // thin wisps peeling off the flanks
          core,
          speed: rng.range(0.82, 1.18),
          wobble: rng.range(0, Math.PI * 2),
          // THE THREE-PART STRUCTURE, which is what a coronagraph actually shows
          // and what a uniform spray cannot. The bright twisted CORE sits LOW,
          // just above the footpoints, and stops there — that truncation is what
          // leaves the dark evacuated CAVITY above it. The flank threads are the
          // LEGS: they run the full height, pinch in near the surface, and feed
          // the leading arc. Giving every strand the same length is exactly what
          // made the last version read as one undifferentiated jet.
          len: core ? rng.range(0.30, 0.54) : rng.range(0.86, 1.0),
        });
      }
      this._cmes.push({
        lon: rng.range(0, Math.PI * 2), lat: rng.range(-0.5, 0.5),
        t: 0, life: rng.range(7, 11),
        // Angular half-width of the rope at the limb. A real halo CME subtends
        // forty to seventy degrees, so this is now 0.19-0.31 rad of HALF-width.
        // The earlier tightening to 0.065 was a fix for the wrong problem: a wide
        // fan only reads as separate wires when there are fifteen threads in it,
        // and there are twenty-six now.
        open: rng.range(0.19, 0.31),
        // How far the front runs, in stellar radii.
        reach: rng.range(1.0, 1.6),
        tilt: rng.range(-0.5, 0.5), // the rope leans out of the equatorial plane
        strands,
      });
    }
    for (let i = this._cmes.length - 1; i >= 0; i--) {
      this._cmes[i].t += dt;
      if (this._cmes[i].t >= this._cmes[i].life) this._cmes.splice(i, 1);
    }
    // -- flares: fast, local, frequent ----------------------------------------
    this._flareCool -= dt;
    if (this._flareCool <= 0 && this._flares.length < 5) {
      const rng = this._promRng;
      this._flareCool = rng.range(0.7, 3.4);
      this._flares.push({
        lon: rng.range(0, Math.PI * 2), lat: rng.range(-0.8, 0.8),
        t: 0, life: rng.range(0.35, 0.9), sz: rng.range(0.05, 0.13),
        // a two-ribbon flare brightens on either side of the neutral line
        ribbon: rng.range(0.5, 1.4),
      });
    }
    for (let i = this._flares.length - 1; i >= 0; i--) {
      this._flares[i].t += dt;
      if (this._flares[i].t >= this._flares[i].life) this._flares.splice(i, 1);
    }
  }

  _drawStar(prog, system, eye, toFrame, vp) {
    const gl = this.renderer.gl;
    const star = system.star;
    // Spectral surfaces are built on demand (main.js installs the hook) — at
    // 512x256 x 4 frames, generating all eleven classes at boot would cost
    // several seconds for eight sets no system in the game ever shows. Cheap
    // no-op once the class is cached; the real work happens at system load.
    this.ensureStarTex?.(star.classKey);
    const local = toFrame(this._L, star.pos);
    const k = this._shellProject(local, eye, star.radius);
    const r = star.radius * k;
    const dir = Vec3.create();
    dir[0] = local[0] - (eye?.[0] ?? 0); dir[1] = local[1] - (eye?.[1] ?? 0); dir[2] = local[2] - (eye?.[2] ?? 0);
    Vec3.normalize(dir, dir);
    // corona halo — tight, rayed, class-tinted; sits behind the sphere
    const upRef = Math.abs(dir[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
    const right = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), upRef, dir));
    const up = Vec3.cross(Vec3.create(), dir, right);
    const size = r * 1.75;
    const m = this._m;
    m[0] = right[0] * size; m[1] = right[1] * size; m[2] = right[2] * size; m[3] = 0;
    m[4] = up[0] * size; m[5] = up[1] * size; m[6] = up[2] * size; m[7] = 0;
    m[8] = -dir[0]; m[9] = -dir[1]; m[10] = -dir[2]; m[11] = 0;
    m[12] = local[0]; m[13] = local[1]; m[14] = local[2]; m[15] = 1;
    gl.uniform1f(prog.uniforms.u_lit, 0);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
    const corona = this.tex.coronas?.[star.classKey] ?? this.tex.sun;
    gl.bindTexture(gl.TEXTURE_2D, corona);
    this.renderer.drawMesh(this.billboard);
    // photosphere: the class-textured sphere, LIT FROM THE VIEWER so the disc
    // shows real limb darkening (bright centre, warm dim limb) + a rim glow.
    // The surface is an ANIMATED set — cycling the frames boils the granulation
    // (each frame is a step around a closed noise loop, so it never snaps).
    const surfSet = this.tex.stars?.[star.classKey] ?? this.tex.stars?.G;
    const surf = Array.isArray(surfSet)
      ? surfSet[Math.floor((this._flameT ?? 0) * STAR_FPS) % surfSet.length]
      : surfSet;
    if (surf) {
      Mat4.translation(this._a, local[0], local[1], local[2]);
      Mat4.rotationY(this._b, this._starAngle ?? 0);
      Mat4.multiply(this._a, this._a, this._b);
      Mat4.scaling(this._b, r, r, r);
      Mat4.multiply(this._a, this._a, this._b);
      gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
      gl.uniform1f(prog.uniforms.u_lit, 1);
      gl.uniform1f(prog.uniforms.u_fill, 0.30); // the limb-darkening law carries the falloff now
      gl.uniform3fv(prog.uniforms.u_lightDir, dir); // "light" arrives from the eye
      // Per-class limb darkening. The coefficients are real: cool stars have
      // deep convective atmospheres and darken hard toward the limb (the Sun is
      // u1 ~0.93, u2 ~-0.23 in visible light), while hot radiative atmospheres
      // barely darken at all. This is why an M dwarf reads as a fat glowing
      // cushion and an O star as a flat brilliant disc.
      const ld = LIMB[star.classKey] ?? LIMB.G;
      gl.uniform2f(prog.uniforms.u_limb, ld[0], ld[1]);
      // the equator laps the poles — accumulated as a fraction of a turn, so it
      // wraps naturally against the repeat-wrapped surface
      gl.uniform1f(prog.uniforms.u_diffRot, (this._starAngle ?? 0) * DIFF_ROT_RATE);
      gl.uniform3f(prog.uniforms.u_atmo, 0.9, 0.55, 0.25); // chromosphere rim
      gl.enable(gl.CULL_FACE);
      gl.bindTexture(gl.TEXTURE_2D, surf);
      this.renderer.drawMesh(this.sphere);
      gl.disable(gl.CULL_FACE);
      gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
      gl.uniform1f(prog.uniforms.u_fill, 0.8);
      gl.uniform2f(prog.uniforms.u_limb, 0, 0); // planets are Lambertian again
      gl.uniform1f(prog.uniforms.u_diffRot, 0); // and they turn as solid bodies
    }
    // -- prominences + coronal mass ejections ---------------------------------
    // Both are drawn as chains of PLASMA SPRITES (not 1px lines): thick, ragged,
    // filamentary billboards that carry real weight at star scale. Every point
    // is built as a star-centred offset, mapped into the render frame, then
    // scaled by the SAME shell factor `k` as the photosphere — so the plasma
    // always hugs the projected disc instead of smearing across the sky when the
    // ship flies close.
    if (this._proms && this.tex.plasma) {
      const cF = toFrame(this._L2, star.pos); // unprojected frame-space centre
      // the eruption is made of the STAR'S own light — per-class tinted plasma
      const pset = this.tex.plasma[star.classKey] ?? this.tex.plasma.G ?? this.tex.plasma;
      const frames = Array.isArray(pset) ? pset : [pset];
      // star-surface point -> render-frame point on the projected shell
      const place = (lon, latOff, rr, out) => {
        const wx = star.pos[0] + Math.cos(lon) * rr;
        const wz = star.pos[2] + Math.sin(lon) * rr;
        const wy = star.pos[1] + latOff;
        const pf = toFrame(this._L3, [wx, wy, wz]);
        out[0] = local[0] + (pf[0] - cF[0]) * k;
        out[1] = local[1] + (pf[1] - cF[1]) * k;
        out[2] = local[2] + (pf[2] - cF[2]) * k;
        return out;
      };
      // NOTE: must not alias _L2 (that holds cF, which place() reads) or _L3
      // (place's own scratch) — plasma points get their own vector.
      const p = this._L4;
      const t = this._flameT ?? 0;
      // LOD: a star that's a few pixels wide needs no filaments at all. dist is
      // eye→star in shell units; ratio is roughly its angular size.
      const dx = local[0] - (eye?.[0] ?? 0), dy = local[1] - (eye?.[1] ?? 0), dz = local[2] - (eye?.[2] ?? 0);
      const ratio = r / Math.max(1, Math.hypot(dx, dy, dz));
      if (ratio > 0.015) {
        const SEG = ratio > 0.12 ? 9 : 5; // more filaments when it fills the glass
        this._spriteReset();
        // magnetic loops: sprites along the arch, fattest at the crown
        for (const c of this._proms) {
          const lift = Math.sin(Math.min(1, c.p * 1.15) * Math.PI); // grow + collapse
          if (lift <= 0.02) continue;
          for (let sgm = 0; sgm <= SEG; sgm++) {
            const tt = sgm / SEG;
            const lon = c.lon + (tt - 0.5) * c.width;
            const arch = Math.sin(tt * Math.PI) * 0.4 * lift;
            const rr = star.radius * (1.0 + arch);
            const latOff = Math.sin(c.tilt) * star.radius * (tt - 0.5) * 0.8;
            place(lon, latOff, rr, p);
            const fat = (0.09 + 0.15 * Math.sin(tt * Math.PI)) * lift;
            const flick = 0.85 + 0.3 * Math.abs(Math.sin(t * 9 + sgm * 1.7 + c.lon * 3));
            this._spritePush(p, r * fat * flick, eye);
          }
        }
        // one texture for the whole batch — the filaments crawl together
        this._spriteFlush(prog, frames[Math.floor(t * 5) % frames.length]);

        // -- ERUPTIONS: a flux rope of threads, not a cloud of blobs ---------
        // Built from oriented STREAKS (see _spriteStreak). Two passes, in this
        // order, because the order is what produces the depth: the wisps peeling
        // off the flanks go down first and the bright core rope over the top, so
        // the rope reads as being INSIDE a fanning envelope. The dark cavity is
        // not drawn at all — it is the gap the strand parametrisation leaves
        // between the trailing core and the leading arc, which is how the real
        // thing works too.
        const fset = this.tex.filament?.[star.classKey] ?? this.tex.filament?.G;
        // Streak sizes scale with the projected star radius, which is unbounded as
        // the ship closes on the limb — same clamp as everything else on this disc.
        const blobK = ratio > 0.25 ? 0.25 / ratio : 1;
        if (fset) {
          const SEGS = ratio > 0.12 ? 11 : 7; // points per strand
          const q = this._L5 ?? (this._L5 = Vec3.create());
          for (const pass of ['wisp', 'core']) {
            const sheet = fset[pass];
            if (!sheet) continue;
            this._spriteReset();
            for (const c of this._cmes ?? []) {
              const prog01 = c.t / c.life;
              // Fast launch, long coast: a CME accelerates hard in the first
              // fifth of its life and then climbs almost ballistically. A linear
              // ramp made it look like it was being extruded at constant speed.
              const climb = prog01 < 0.2
                ? (prog01 / 0.2) * (prog01 / 0.2) * 0.28
                : 0.28 + (prog01 - 0.2) / 0.8 * 0.72;
              const fade = prog01 < 0.08 ? prog01 / 0.08 : 1 - ((prog01 - 0.08) / 0.92) ** 2;
              if (fade <= 0.02) continue;
              for (const st of c.strands) {
                if ((pass === 'core') !== st.core) continue;
                // Walk the strand and emit a streak between consecutive points, so
                // every segment is oriented along the LOCAL TANGENT of the thread.
                let px = 0, py = 0, pz = 0, have = false;
                const reach = climb * st.speed * st.len;
                for (let k = 0; k <= SEGS; k++) {
                  const f = k / SEGS;                    // 0 at the footpoint, 1 at the tip
                  // Height above the surface. The rope's own arch: it does not
                  // start radial, it leans over as it leaves the limb.
                  const rr = star.radius * (1.0 + c.reach * reach * f);
                  // Longitude fans out with height, and the strand HELIXES about
                  // the rope axis — the winding is what makes strands cross.
                  const helix = st.phase + st.twist * f * 3.6; // enough turn to cross
                  // Hard pinch at the footpoint (0.10 rather than 0.35): the legs
                  // have to converge to a NECK where the rope leaves the surface.
                  // That neck is what turns a fan into the light-bulb silhouette.
                  const fan = c.open * (0.10 + 1.05 * f);
                  const lon = c.lon + st.across * fan + Math.sin(helix) * fan * 0.28;
                  // Latitude scales with rr, NOT with star.radius. place() is
                  // cylindrical — a fixed Y offset — so with the old form an
                  // eruption at 45 degrees of latitude still travelled dead
                  // horizontally as it climbed, and only an equatorial one looked
                  // right. Scaling by rr makes the climb genuinely RADIAL, which is
                  // what a CME does, and lets a high-latitude rope arch up off the
                  // limb the way the real ones photograph.
                  const latF = c.lat + c.tilt * f * 0.5 + Math.cos(helix) * fan * 0.34
                    + Math.sin(t * 0.9 + st.wobble) * 0.012;
                  place(lon, latF * rr, rr, q);
                  if (have) {
                    const dx = q[0] - px, dy = q[1] - py, dz = q[2] - pz;
                    const seg = Math.hypot(dx, dy, dz);
                    if (seg > 1e-4) {
                      // brighter and slightly fatter toward the leading tip, and
                      // flickering per segment so a thread never reads as a stroke
                      const flick = 0.78 + 0.34 * Math.abs(Math.sin(t * 6 + k * 2.1 + st.phase));
                      // Widened from 0.030/0.019. A filament has to have BODY —
                      // at the old width fifteen of them were fifteen hairlines,
                      // and the eye read wire, not plasma.
                      const wid = r * blobK * (pass === 'core' ? 0.064 : 0.030)
                        * (0.6 + 0.8 * f) * fade * flick;
                      this._streakDir[0] = dx / seg; this._streakDir[1] = dy / seg;
                      this._streakDir[2] = dz / seg;
                      this._streakMid[0] = (q[0] + px) * 0.5;
                      this._streakMid[1] = (q[1] + py) * 0.5;
                      this._streakMid[2] = (q[2] + pz) * 0.5;
                      // half-length is half the segment plus a hair, so consecutive
                      // streaks overlap and the thread has no gaps at the joins
                      this._spriteStreak(this._streakMid, this._streakDir,
                        seg * 0.62, wid, eye);
                    }
                  }
                  px = q[0]; py = q[1]; pz = q[2]; have = true;
                }
              }
            }
            this._spriteFlush(prog, sheet[Math.floor(t * 8) % sheet.length]);
          }

          // THE LEADING ARC. Drawn last and TANGENTIALLY — each segment lies across
          // the direction of travel, which is what makes it a taut bright rim
          // instead of a row of dots. This is the single most recognisable feature
          // of a real CME and the old version had nothing like it.
          this._spriteReset();
          for (const c of this._cmes ?? []) {
            const prog01 = c.t / c.life;
            const climb = prog01 < 0.2
              ? (prog01 / 0.2) * (prog01 / 0.2) * 0.28
              : 0.28 + (prog01 - 0.2) / 0.8 * 0.72;
            const fade = prog01 < 0.08 ? prog01 / 0.08 : 1 - ((prog01 - 0.08) / 0.92) ** 2;
            if (fade <= 0.02) continue;
            const ARC = 27;
            const fan = c.open * 1.12;
            // TWO rims, not one. A real front is a swept-up SHELL with thickness —
            // a bright outer shock and, a little behind it, the denser pile-up of
            // material it is ploughing through. One stroke reads as a wire drawn
            // over the star; two, offset in radius and unequal in weight, read as
            // a shell seen edge-on. This plus the truncated core is what produces
            // the front / cavity / core banding the real photographs show.
            for (const shell of [[1.0, 0.030, 1.0], [0.885, 0.046, 0.78]]) {
              const rr = star.radius * (1.0 + c.reach * climb * shell[0]);
              let px = 0, py = 0, pz = 0, have = false;
              for (let k = 0; k <= ARC; k++) {
                const a2 = (k / ARC - 0.5) * 2;            // -1..1 across the front
                // the front is an ARCH: highest in the middle, curving back at the
                // flanks, which is the shape the rope's own geometry implies
                const bow = 1 - a2 * a2 * 0.44;
                const lon = c.lon + a2 * fan;
                // same radial correction as the strands above
                const latF = c.lat + c.tilt * 0.5 + Math.sin(a2 * 2.3) * 0.02;
                place(lon, latF * rr * bow, rr * bow, q);
                if (have) {
                  const dx = q[0] - px, dy = q[1] - py, dz = q[2] - pz;
                  const seg = Math.hypot(dx, dy, dz);
                  if (seg > 1e-4) {
                    this._streakDir[0] = dx / seg; this._streakDir[1] = dy / seg;
                    this._streakDir[2] = dz / seg;
                    this._streakMid[0] = (q[0] + px) * 0.5;
                    this._streakMid[1] = (q[1] + py) * 0.5;
                    this._streakMid[2] = (q[2] + pz) * 0.5;
                    // Clumpy along its length and heaviest at the nose. A front is
                    // not an even stroke — it is denser where the rope is pushing
                    // hardest and it frays toward the flanks.
                    const nose = 1 - Math.abs(a2) * 0.55;
                    const clump = 0.72 + 0.5 * Math.abs(
                      Math.sin(a2 * 5.1 + c.lon * 3.1 + t * 1.7));
                    // Thin ACROSS the arc, long ALONG it: a rim, not a bead.
                    this._spriteStreak(this._streakMid, this._streakDir,
                      seg * 0.62,
                      r * blobK * shell[1] * nose * clump * fade * shell[2], eye);
                  }
                }
                px = q[0]; py = q[1]; pz = q[2]; have = true;
              }
            }
          }
          this._spriteFlush(prog, fset.core[(Math.floor(t * 8) + 1) % fset.core.length]);
        }

        // -- FLARES: the fast events ------------------------------------------
        // Everything else on this star moves over many seconds; a flare is over
        // in well under one, and that contrast in TIMESCALE is what reads as an
        // active star rather than a looping animation. Two ribbons brightening
        // either side of a neutral line, which is the shape a real two-ribbon
        // flare takes, in the star's own plasma colour for the same reason the
        // footprint above is — a white bloom punches a hole in the disc.
        if (this._flares?.length) {
          this._spriteReset();
          for (const fl of this._flares) {
            const fp = fl.t / fl.life;
            // fast rise, slow decay: the light curve of an actual flare
            const bright = fp < 0.18 ? fp / 0.18 : 1 - (fp - 0.18) / 0.82;
            if (bright <= 0.02) continue;
            for (const side of [-1, 1]) {
              place(fl.lon + side * fl.ribbon * 0.045,
                (fl.lat + side * fl.ribbon * 0.02) * star.radius, star.radius * 1.005, p);
              this._spritePush(p, r * blobK * fl.sz * bright, eye);
            }
          }
          this._spriteFlush(prog, frames[Math.floor(t * 11) % frames.length]);
        }
      }
    }
  }

  /** Camera-facing glow billboard (soft light bloom layer). */
  _drawGlow(prog, posF, size, tex, eye) {
    if (!tex || size < 0.05) return;
    const gl = this.renderer.gl;
    const view = Vec3.create();
    view[0] = posF[0] - (eye?.[0] ?? 0); view[1] = posF[1] - (eye?.[1] ?? 0); view[2] = posF[2] - (eye?.[2] ?? 0);
    Vec3.normalize(view, view);
    const upRef = Math.abs(view[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
    const right = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), upRef, view));
    const up = Vec3.cross(Vec3.create(), view, right);
    const m = this._m;
    m[0] = right[0] * size; m[1] = right[1] * size; m[2] = right[2] * size; m[3] = 0;
    m[4] = up[0] * size; m[5] = up[1] * size; m[6] = up[2] * size; m[7] = 0;
    m[8] = view[0]; m[9] = view[1]; m[10] = view[2]; m[11] = 0;
    m[12] = posF[0]; m[13] = posF[1]; m[14] = posF[2]; m[15] = 1;
    gl.uniform1f(prog.uniforms.u_lit, 0);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    this.renderer.drawMesh(this.billboard);
  }

  /**
   * Axis-aligned flame plume: throat pinned at `posF`, tail streaming along
   * `axisF` (frame coords). Drawn as a CROSSED PAIR of quads about the axis so
   * the plume keeps volume from every angle, cycling the pixel-art flame
   * frames ~12/s. Seen dead-astern (down the nozzle) the quads go edge-on, so
   * a round exhaust bloom fades in to keep the burn readable from behind.
   *
   * `frames` overrides the sprite set — RCS passes the pale cold-gas puffs so
   * attitude thrusters don't read as rockets burning out of the ship's flanks.
   */
  _drawFlame(prog, posF, axisF, len, width, eye, frames = null) {
    const set = frames ?? this.tex.flames;
    if (!set || len < 0.05) return;
    const gl = this.renderer.gl;
    const axis = Vec3.normalize(Vec3.create(), axisF);
    const view = Vec3.create();
    view[0] = posF[0] - (eye?.[0] ?? 0); view[1] = posF[1] - (eye?.[1] ?? 0); view[2] = posF[2] - (eye?.[2] ?? 0);
    Vec3.normalize(view, view);
    const align = Math.abs(axis[0] * view[0] + axis[1] * view[1] + axis[2] * view[2]);
    const frame = Math.floor((this._flameT ?? 0) * 12) % set.length;
    const right = Vec3.cross(Vec3.create(), axis, view);
    if (Vec3.length(right) > 0.03) {
      Vec3.normalize(right, right);
      const right2 = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), axis, right));
      const m = this._m;
      const cxp = posF[0] + axis[0] * len * 0.5, cyp = posF[1] + axis[1] * len * 0.5, czp = posF[2] + axis[2] * len * 0.5;
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.bindTexture(gl.TEXTURE_2D, set[frame]);
      for (const rgt of [right, right2]) {
        m[0] = rgt[0] * width; m[1] = rgt[1] * width; m[2] = rgt[2] * width; m[3] = 0;
        m[4] = -axis[0] * len * 0.5; m[5] = -axis[1] * len * 0.5; m[6] = -axis[2] * len * 0.5; m[7] = 0;
        m[8] = view[0]; m[9] = view[1]; m[10] = view[2]; m[11] = 0;
        m[12] = cxp; m[13] = cyp; m[14] = czp; m[15] = 1;
        gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
        this.renderer.drawMesh(this.billboard);
      }
    }
    // seen dead-astern the crossed quads go edge-on: fade in a round bloom so
    // the burn stays readable from behind (cold jets get a blue one, not amber)
    const cold = frames && frames !== this.tex.flames;
    const bloom = cold ? this.tex.glowBlue : this.tex.glowAmber;
    if (align > 0.55 && bloom) {
      const k = (align - 0.55) / 0.45;
      const tip = [posF[0] + axis[0] * len * 0.18, posF[1] + axis[1] * len * 0.18, posF[2] + axis[2] * len * 0.18];
      this._drawGlow(prog, tip, len * 0.55 * k, bloom, eye);
      if (!cold && this.tex.glowWhite) this._drawGlow(prog, tip, len * 0.26 * k, this.tex.glowWhite, eye);
    }
  }

  /** Register hostile hull meshes (Phase 6): { keth, drift } vertex data. */
  setCombatMeshes(meshes) {
    const gl = this.renderer.gl;
    this.enemyMeshes = {
      keth: this._spaceVao(gl, meshes.keth.vertexData, meshes.keth.indexData),
      drift: this._spaceVao(gl, meshes.drift.vertexData, meshes.drift.indexData),
    };
    // The corvette shares the Keth hull texture — same faction, same yard, and a
    // second 256px texture for one hull would cost boot time for nothing.
    if (meshes.keth_corvette) {
      this.enemyMeshes.keth_corvette = this._spaceVao(gl,
        meshes.keth_corvette.vertexData, meshes.keth_corvette.indexData);
    }
    // New hostile TYPES share existing hulls, deliberately. A lancer is a small
    // fast Keth fighter and a lance is a heavy Drift drone — same yards, same
    // construction, different loadout and different orders, which is how real
    // variants work and costs no boot time. What makes them read differently in
    // play is scale plus their behaviour profile, not a new mesh.
    this.enemyMeshes.keth_lancer = this.enemyMeshes.keth;
    this.enemyMeshes.drift_picket = this.enemyMeshes.drift;
    this.enemyMeshes.drift_lance = this.enemyMeshes.drift;
    this.combatPts = this._buildDynamicPoints(gl, 220);
    // Raised from 220: the layered weapon FX (cooling ejecta, debris, embers,
    // tracer streaks) routinely put 300-500 points on screen in a firefight,
    // and the old cap silently dropped whichever ones came last — which was
    // always the sparks, because bolts are written first.
    this._cpBuf = new Float32Array(900 * STAR_FLOATS);
    this._tp = [0, 0, 0]; // scratch world position for tracer tail samples
  }

  /**
   * Draw combat state: hostile hulls, laser bolts, explosion sparks. Works in
   * either frame — `toFrame(out, worldPos)` maps into the current render frame
   * and `eye` centres the projection shell. Call with the 'space' program
   * bound and the frame's VP uploaded; leaves 'stars' bound.
   */
  renderCombat(combat, vp, eye, toFrame, lightFromOrigin) {
    if (!combat || !this.enemyMeshes) return;
    const gl = this.renderer.gl;
    // hostile hulls (space program is current)
    let prog = this.renderer.use('space');
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
    gl.uniform1f(prog.uniforms.u_fill, 0.55);
    for (const e of combat.enemies) {
      // Livery tint is a PER-DRAW uniform and the player hull sets it. Without
      // resetting it here, every hostile in the system would come out painted in
      // whatever the player chose at commission. It also earns its keep: the
      // variant hulls share their parent's mesh and texture, so a shift in the
      // albedo is what tells a lancer from a fighter at 3km on a 480x270 grid.
      gl.uniform3fv(prog.uniforms.u_tint, HOSTILE_TINT[e.type] ?? WHITE3);
      const local = toFrame(this._L, e.pos);
      // 12u suits a fighter; a corvette is ~34u long and would be culled or
      // projected wrong at the fighter's radius.
      const k = this._shellProject(local, eye, (e.type === 'keth_corvette' ? 30 : 12) * e.scale);
      Vec3.normalize(this._lightDir, e.pos);
      if (lightFromOrigin) lightFromOrigin(this._lightDir);
      Mat4.translation(this._a, local[0], local[1], local[2]);
      Mat4.rotationY(this._b, e.yaw);
      Mat4.multiply(this._a, this._a, this._b);
      const s = k * e.scale;
      Mat4.scaling(this._b, s, s, s);
      Mat4.multiply(this._a, this._a, this._b);
      gl.uniform1f(prog.uniforms.u_lit, 1);
      // A CRIPPLED HULL IS A DARK HULL. Its reactor is out, so the ambient fill
      // that stands in for its own running lights goes with it: what is left is
      // the star on one side and nothing on the other, which is how you pick a
      // boardable wreck out of a formation at two kilometres.
      gl.uniform1f(prog.uniforms.u_fill, e.crippled ? 0.16 : 0.55);
      gl.uniform3fv(prog.uniforms.u_lightDir, this._lightDir);
      gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
      gl.bindTexture(gl.TEXTURE_2D, e.type.startsWith('keth') ? this.tex.keth : this.tex.drift);
      gl.uniform1f(prog.uniforms.u_tileVary, 1);
      this.renderer.drawMesh(this.enemyMeshes[e.type]);
      gl.uniform1f(prog.uniforms.u_tileVary, 0);
    }
    // burning drive plumes behind moving hostiles (frame-space axis from two
    // transformed points so it works in both render frames)
    for (const e of combat.enemies) {
      // No drive, no plume. A crippled hull coasting at three hundred units a
      // second with a burning torch behind it would read as under power.
      if (e.crippled) continue;
      const spd = Math.hypot(e.vel[0], e.vel[1], e.vel[2]);
      if (spd < 40) continue;
      const inv = 1 / spd;
      const p1 = toFrame(Vec3.create(), e.pos);
      const k1 = this._shellProject(p1, eye, 12 * e.scale);
      const behind = [e.pos[0] - e.vel[0] * inv, e.pos[1] - e.vel[1] * inv, e.pos[2] - e.vel[2] * inv];
      const p2 = toFrame(Vec3.create(), behind);
      this._shellProject(p2, eye, 0);
      const axis = [p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]];
      const throat = [p1[0] + axis[0] * 7 * k1 * e.scale, p1[1] + axis[1] * 7 * k1 * e.scale, p1[2] + axis[2] * 7 * k1 * e.scale];
      const drive = Math.min(1.4, spd / e.speed + 0.4);
      this._drawGlow(prog, throat, 7 * k1 * e.scale * drive, this.tex.glowAmber, eye);
      this._drawFlame(prog, throat, axis, 22 * k1 * e.scale * drive, 4.6 * k1 * e.scale, eye);
    }
    // -- impact flashes: layered bloom (expanding halo + white-hot core) ---------
    for (const f of combat.flashes ?? []) {
      const local = toFrame(this._L, f.pos);
      const k = this._shellProject(local, eye, 0);
      const halo = f.blue ? this.tex.glowBlue : this.tex.glowAmber;
      this._drawGlow(prog, local, (5 + 12 * (1 - f.t)) * f.t * k, halo, eye);
      this._drawGlow(prog, local, 4 * f.t * k, this.tex.glowWhite ?? this.tex.glowAmber, eye);
    }
    // -- lingering battle smoke: ragged dark puffs that drift and thin -----------
    if (this.tex.smoke) {
      for (const s of combat.smoke ?? []) {
        const local = toFrame(this._L, s.pos);
        const k = this._shellProject(local, eye, 0);
        const grow = 3 + (1.6 - s.ttl) * 3.4; // puffs swell as they age
        const fr = this.tex.smoke[Math.floor((this._flameT ?? 0) * 5 + (s.ttl * 3)) % this.tex.smoke.length];
        this._drawGlow(prog, local, grow * Math.min(1, s.ttl * 1.5) * k, fr, eye);
      }
    }
    gl.uniform1f(prog.uniforms.u_fill, 0.8);
    // bolts + sparks as shell-projected points
    let n = 0;
    const put = (worldPos, r, g, b, size) => {
      if (n >= 900) return;
      const local = toFrame(this._L, worldPos);
      this._shellProject(local, eye, 0);
      const o = n * STAR_FLOATS;
      this._cpBuf[o] = local[0]; this._cpBuf[o + 1] = local[1]; this._cpBuf[o + 2] = local[2];
      this._cpBuf[o + 3] = r; this._cpBuf[o + 4] = g; this._cpBuf[o + 5] = b;
      this._cpBuf[o + 6] = size;
      n++;
    };
    for (const bolt of combat.bolts) {
      // A round is drawn as a STREAK: its recorded flight path, fading and
      // thinning back from the head. At 900-2600 units a second it covers more
      // than its own length between frames, so a single point reads as a dot
      // teleporting across the sky; the tail is what makes it a tracer.
      const spec = bolt.spec;
      const head = bolt.hostile
        ? (bolt.kind === 'drift' ? [0.9, 0.93, 1.0] : [0.85, 0.2, 0.14])
        : (spec?.tracer ?? [1.0, 0.8, 0.45]);
      const hSize = Math.max(2, spec?.tracerSize ?? 2);
      const hist = bolt.hist;
      if (hist && hist.length >= 3) {
        const segs = hist.length / 3;
        for (let k = 0; k < segs; k++) {
          const t = (k + 1) / segs;      // 0 at the oldest sample, 1 at the head
          const f = t * t;                // fade fast — the tail is a suggestion
          this._tp[0] = hist[k * 3]; this._tp[1] = hist[k * 3 + 1]; this._tp[2] = hist[k * 3 + 2];
          put(this._tp, head[0] * f, head[1] * f, head[2] * f,
            Math.max(1, Math.round(hSize * (0.35 + 0.65 * t))));
        }
      }
      // the head itself, blown out toward white so it reads as the hot end
      put(bolt.pos, Math.min(1, head[0] + 0.25), Math.min(1, head[1] + 0.25),
        Math.min(1, head[2] + 0.25), hSize + 1);
    }
    for (const s of combat.sparks) {
      // Colour and size are driven by how much LIFE is left, not by a flat fade:
      // ejecta cools from its hot colour toward its cool one and shrinks as it
      // goes. Particles without the new fields (older call sites, enemy fire)
      // fall back to the previous behaviour.
      const c = s.col ?? [1, 0.6, 0.2];
      if (s.life) {
        const t = Math.max(0, Math.min(1, s.ttl / s.life)); // 1 fresh → 0 dead
        const cc = s.colCool ?? [c[0] * 0.3, c[1] * 0.12, c[2] * 0.06];
        const g = t * t * (3 - 2 * t); // ease so the last instant does not pop
        const s1 = s.size1 ?? 1;
        put(s.pos,
          cc[0] + (c[0] - cc[0]) * g,
          cc[1] + (c[1] - cc[1]) * g,
          cc[2] + (c[2] - cc[2]) * g,
          Math.max(1, Math.round(s1 + ((s.size ?? 1) - s1) * g)));
      } else {
        const f = Math.min(1, s.ttl + 0.25);
        put(s.pos, c[0] * f, c[1] * f, c[2] * f, s.size ?? 1);
      }
    }
    // ROUND BLOOM, before the points so the hard pixels sit on top of their own
    // glow. A tracer built only from points is a chain of hard dots: the bloom is
    // what makes a round read as a lump of burning plasma with air around it, and
    // it is where the depth in a firefight comes from — overlapping halos in front
    // of and behind each other. Batched by texture (2-3 draw calls for the lot)
    // and capped, because a corvette salvo plus point defence can put fifty
    // rounds in the air and the far ones contribute nothing.
    if (this.tex.glowAmber) {
      const BLOOM_CAP = 40;
      for (const tex of [this.tex.glowRed ?? this.tex.glowAmber, this.tex.glowBlue, this.tex.glowAmber]) {
        let any = false, drawn = 0;
        this._spriteReset();
        for (const bolt of combat.bolts) {
          if (drawn >= BLOOM_CAP) break;
          const want = bolt.hostile
            ? (bolt.kind === 'drift' ? this.tex.glowBlue : (this.tex.glowRed ?? this.tex.glowAmber))
            : this.tex.glowAmber;
          if (want !== tex) continue;
          const local = toFrame(this._L, bolt.pos);
          const k = this._shellProject(local, eye, 0);
          const sz = Math.max(2, (bolt.spec?.tracerSize ?? 2)) * 1.7 * k;
          this._spritePush(local, sz, eye);
          any = true; drawn++;
        }
        if (any) {
          prog = this.renderer.use('space');
          gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, vp);
          gl.uniform1f(prog.uniforms.u_lit, 0);
          gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
          gl.uniform1f(prog.uniforms.u_tileVary, 0);
          gl.activeTexture(gl.TEXTURE0);
          gl.uniform1i(prog.uniforms.u_texture, 0);
          this._spriteFlush(prog, tex);
        }
      }
    }
    if (n > 0) {
      prog = this.renderer.use('stars');
      gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, vp);
      gl.uniform3f(prog.uniforms.u_bend, 0, 0, 0);
      gl.uniform1f(prog.uniforms.u_alpha, 1);
      gl.bindVertexArray(this.combatPts.vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.combatPts.vbo);
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, this._cpBuf.subarray(0, n * STAR_FLOATS));
      gl.drawArrays(gl.POINTS, 0, n);
      gl.bindVertexArray(null);
      this.renderer.drawCalls++;
    }
  }

  // -- rendering ------------------------------------------------------------------

  /**
   * @param {import('../player/PlayerCamera.js').PlayerCamera} camera
   * @param {import('../ship/Spaceship.js').Spaceship} ship
   * @param {import('../world/StarSystem.js').StarSystem} system
   * @param {import('../ship/ThrusterFX.js').ThrusterFX} thrusterFX
   */
  render(camera, ship, system, thrusterFX) {
    const gl = this.renderer.gl;
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.disable(gl.CULL_FACE);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    // sky view-projection: camera rotation × inverse ship orientation
    Mat4.fpsView(this._viewRot, [0, 0, 0], camera.yaw, camera.pitch, this._a, this._b);
    Mat4.fromQuat(this._m, ship.qConj);
    Mat4.multiply(this._viewRot, this._viewRot, this._m);
    Mat4.multiply(this._viewRot, this._viewRot, this.skyRot); // per-system sky
    Mat4.multiply(this._skyVP, camera.projection, this._viewRot);

    // -- stars ---------------------------------------------------------------
    let prog = this.renderer.use('stars');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, this._skyVP);
    gl.uniform3f(prog.uniforms.u_bend, 0, 0, 0); // no lensing in the cockpit view
    gl.uniform1f(prog.uniforms.u_alpha, 1);
    gl.bindVertexArray(this.starMesh.vao);
    gl.drawArrays(gl.POINTS, 0, this.starMesh.count);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;

    // -- warp streaks (jump sequence only) --------------------------------------
    if (this.warpT > 0) {
      gl.uniform1f(prog.uniforms.u_alpha, this.warpT);
      gl.bindVertexArray(this.warpMesh.vao);
      gl.drawArrays(gl.LINES, 0, this.warpMesh.count);
      gl.bindVertexArray(null);
      this.renderer.drawCalls++;
      gl.uniform1f(prog.uniforms.u_alpha, 1);
    }

    // -- nebulae (sky-fixed) ----------------------------------------------------
    prog = this.renderer.use('space');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, this._skyVP);
    gl.uniform1f(prog.uniforms.u_lit, 0);
    gl.uniform1f(prog.uniforms.u_lightLevels, 14);
    // Factory white by default. An unset vec3 uniform reads as (0,0,0), so
    // without this every mesh in the pass would render black the moment the
    // livery uniform was added — the tint block on the player hull sets and
    // restores it, but only after the first draws have already gone out.
    gl.uniform3f(prog.uniforms.u_tint, 1, 1, 1);
    gl.uniform1f(prog.uniforms.u_fill, 0.06);
    Mat4.identity(this._m);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._m);
    gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(prog.uniforms.u_texture, 0);
    gl.bindTexture(gl.TEXTURE_2D, this.tex.nebula[this.nebulaVariant % this.tex.nebula.length]);
    this.renderer.drawMesh(this.nebulaMesh);

    // positioned objects use the real camera VP (eye offset is negligible at sky range)
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, camera.viewProjection);
    gl.uniform3fv(prog.uniforms.u_camPos, camera.eye); // for the atmosphere rim
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);

    // -- the star: 3D spectral-class photosphere + corona + prominences --------
    this._drawStar(prog, system, camera.eye, (out, p) => ship.toLocal(out, p), camera.viewProjection);
    prog = this.renderer.use('space');

    // -- planets, far to near ------------------------------------------------------
    // Cull back faces: this pass has no depth test, so without culling a sphere's
    // far (dark) hemisphere overwrites its near face in index order and the
    // terminator breaks into shifting geometric wedges as the view rotates.
    const sorted = [...system.bodies].sort((p, q) => {
      const dp = Vec3.distance(ship.pos, p.pos);
      const dq = Vec3.distance(ship.pos, q.pos);
      return dq - dp;
    });
    gl.enable(gl.CULL_FACE);
    // Sorted far→near, so slicing off the FRONT of the list keeps the nearest —
    // see BODY_DRAW_CAP.
    for (const body of sorted.slice(-BODY_DRAW_CAP)) {
      this._drawPlanet(prog, ship, body, camera.eye);
    }
    gl.disable(gl.CULL_FACE);

    // -- stations, structures, wrecks and traffic ------------------------------------
    if (this.freighter || this.structures) {
      for (const npc of system.ships) {
        this._drawHull(prog, npc, camera.eye,
          (out, p) => ship.toLocal(out, p), (dir) => ship.dirToLocal(dir, dir));
      }
    }

    // -- combat: hostiles, bolts, sparks ----------------------------------------------
    this.renderCombat(this.combat, camera.viewProjection, camera.eye,
      (out, p) => ship.toLocal(out, p),
      (dir) => ship.dirToLocal(dir, dir));

    // -- dust motes ------------------------------------------------------------------------
    prog = this.renderer.use('stars');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, camera.viewProjection);
    gl.uniform1f(prog.uniforms.u_alpha, thrusterFX.alphaFor(ship));
    gl.bindVertexArray(this.dustVao.vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.dustVao.vbo);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, thrusterFX.buffer);
    gl.drawArrays(gl.POINTS, 0, thrusterFX.count);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;

    gl.disable(gl.BLEND);
    gl.enable(gl.CULL_FACE);
    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
  }

  /**
   * Third-person chase render: the whole ship exterior against space, from an
   * external camera. Works in a ship-centred world frame (ship at origin,
   * oriented by ship.quat; camera at chase.eye looking toward origin).
   * @param {{vp:Float32Array, vpRot:Float32Array, eye:number[]}} chase
   */
  /**
   * @param {object} chase   camera: {vp, vpRot, eye}
   * @param {object} ship
   * @param {object} system
   * @param {{hullScale?:number, holds?:Array}} [opts]
   *   `hullScale` — the chase cam draws the Aethon at 0.55 so the worlds it
   *   flies past read as huge beside it. From a SUIT that is wrong: you are
   *   four metres off the plating and the ship is the size the ship is. EVA
   *   passes 1.
   */
  renderExterior(chase, ship, system, opts = null) {
    const gl = this.renderer.gl;
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.disable(gl.CULL_FACE);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);

    // stars (skybox — rotation only). During the jump sequence the field bends
    // around the singularity at the ship's centre (projected to NDC).
    let prog = this.renderer.use('stars');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vpRot);
    if (this.warpFx.mode && this.warpFx.bend > 0 && chase.vp[15] > 0.0001) {
      // vp * (0,0,0,1) is column 3 (column-major): the ship centre in clip space
      const cw = chase.vp[15];
      gl.uniform3f(prog.uniforms.u_bend, chase.vp[12] / cw, chase.vp[13] / cw, this.warpFx.bend);
    } else {
      gl.uniform3f(prog.uniforms.u_bend, 0, 0, 0);
    }
    gl.uniform1f(prog.uniforms.u_alpha, 1);
    gl.bindVertexArray(this.starMesh.vao);
    gl.drawArrays(gl.POINTS, 0, this.starMesh.count);
    gl.bindVertexArray(null);
    this.renderer.drawCalls++;

    prog = this.renderer.use('space');
    gl.uniform1f(prog.uniforms.u_lightLevels, 14);
    // Factory white by default. An unset vec3 uniform reads as (0,0,0), so
    // without this every mesh in the pass would render black the moment the
    // livery uniform was added — the tint block on the player hull sets and
    // restores it, but only after the first draws have already gone out.
    gl.uniform3f(prog.uniforms.u_tint, 1, 1, 1);
    gl.uniform1f(prog.uniforms.u_fill, 0.06);
    gl.uniform3fv(prog.uniforms.u_camPos, chase.eye); // atmosphere rim
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
    gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(prog.uniforms.u_texture, 0);
    // nebulae (rotation only)
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vpRot);
    gl.uniform1f(prog.uniforms.u_lit, 0);
    Mat4.identity(this._m);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._m);
    gl.bindTexture(gl.TEXTURE_2D, this.tex.nebula[this.nebulaVariant % this.tex.nebula.length]);
    this.renderer.drawMesh(this.nebulaMesh);

    // positioned bodies use the full chase VP; positions are relative to ship
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vp);

    // sun + planets, relative to the ship (origin), projected onto a shell
    // centred on the CHASE EYE — the eye sits tens of units off the ship, and a
    // ship-centred shell made bodies warp/"magnify" whenever the view turned.
    this._drawStar(prog, system, chase.eye, (out, p) => Vec3.sub(out, p, ship.pos), chase.vp);
    prog = this.renderer.use('space');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vp);
    const sorted = [...system.bodies].sort((p, q) =>
      Vec3.distance(ship.pos, q.pos) - Vec3.distance(ship.pos, p.pos));
    gl.enable(gl.CULL_FACE); // cull back faces (see render(): no depth test here)
    for (const body of sorted.slice(-BODY_DRAW_CAP)) { // nearest N — see the constant
      this.ensureBodyTex?.(body.kind);
      Vec3.sub(this._L, body.pos, ship.pos);
      const k = this._shellProject(this._L, chase.eye, body.radius);
      const r = body.radius * k; // camera-centred shell: always < SKY_RADIUS/1.06
      if (this._subPixel(this._L, r, chase.eye)) continue;
      Vec3.normalize(this._lightDir, body.pos); // sunlight ~ from origin(star) toward body
      // far ring arc first — the sphere below occludes it (see _drawRingHalf).
      // This frame is world-translated, so the ecliptic pole is just world up.
      if (body.rings) {
        this._ringPole[0] = 0; this._ringPole[1] = 1; this._ringPole[2] = 0;
        this._drawRingHalf(prog, 'far', this._L, r, body, chase.eye, this._ringPole);
      }
      Mat4.translation(this._a, this._L[0], this._L[1], this._L[2]);
      Mat4.rotationY(this._b, body.angle); Mat4.multiply(this._a, this._a, this._b);
      // Shards tumble here too. This loop is a deliberate duplicate of
      // _drawPlanet (different frame, no ship-local transform), so anything added
      // to one has to be added to the other or the hull cam quietly shows a
      // different solar system than the windshield does.
      if (body.shard) {
        const h = this._shardHash(body.id);
        const tt = this._flameT ?? 0;
        Mat4.rotationX(this._b, tt * body.spin * 1.7 + h * 6.3);
        Mat4.multiply(this._a, this._a, this._b);
        Mat4.scaling(this._b, r * (0.72 + h * 0.5), r * (0.62 + ((h * 7.1) % 1) * 0.55),
          r * (0.78 + ((h * 3.7) % 1) * 0.45));
      } else {
        Mat4.scaling(this._b, r, r, r);
      }
      Mat4.multiply(this._a, this._a, this._b);
      gl.uniform1f(prog.uniforms.u_lit, 1);
      gl.uniform1f(prog.uniforms.u_fill, PLANET_FILL);
      gl.uniform3fv(prog.uniforms.u_lightDir, this._lightDir);
      const atmo = ATMO[body.kind] ?? [0, 0, 0];
      gl.uniform3f(prog.uniforms.u_atmo, atmo[0], atmo[1], atmo[2]);
      gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.planets[body.kind]);
      this.renderer.drawMesh(this.sphere);
      // the hull cam gets the living atmosphere too — a churning cloud deck on
      // a faster-spinning shell (bare spheres here looked painted next to the
      // first-person view, which has had weather since 0.8.1)
      const cset = this.tex.clouds?.[body.kind];
      if (cset) {
        const set = Array.isArray(cset) ? cset : [cset];
        const fr = set[Math.floor((this._flameT ?? 0) * CLOUD_FPS + (body.angle ?? 0) * 3) % set.length];
        Mat4.translation(this._a, this._L[0], this._L[1], this._L[2]);
        Mat4.rotationY(this._b, body.angle * 1.7 + 0.9);
        Mat4.multiply(this._a, this._a, this._b);
        const cr = r * 1.03;
        Mat4.scaling(this._b, cr, cr, cr);
        Mat4.multiply(this._a, this._a, this._b);
        gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
        gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
        gl.bindTexture(gl.TEXTURE_2D, fr);
        this.renderer.drawMesh(this.sphere);
      }
      // near ring arc last, crossing the disc
      if (body.rings) this._drawRingHalf(prog, 'near', this._L, r, body, chase.eye, this._ringPole);
      // coma + twin tails. `ship` here supplies dirToLocal, but this frame is
      // world-axis (only translated), so the tail directions need no rotation —
      // an identity stand-in keeps _drawComet's one contract without a branch.
      if (body.comet) this._drawComet(prog, IDENTITY_FRAME, body, this._L, r, chase.eye);
    }
    gl.disable(gl.CULL_FACE);
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0); // no atmosphere on the hull

    // Stations, wrecks and traffic in the chase frame. They were missing here
    // entirely: switching to the hull cam beside a trade post made the station
    // vanish, which is the one view where its size is worth seeing.
    if (this.freighter || this.structures) {
      for (const npc of system.ships) {
        this._drawHull(prog, npc, chase.eye, (out, p) => Vec3.sub(out, p, ship.pos), null);
      }
    }

    // combat draws in the chase frame too (world axes, ship at origin)
    this.renderCombat(this.combat, chase.vp, chase.eye,
      (out, p) => Vec3.sub(out, p, ship.pos), null);
    prog = this.renderer.use('space');
    gl.uniformMatrix4fv(prog.uniforms.u_viewProjection, false, chase.vp);

    // -- the Aethon itself: hull (sun-lit) + glow (emissive) -------------------
    gl.enable(gl.DEPTH_TEST); // real depth among the ship's own parts
    gl.depthMask(true);
    gl.clear(gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.CULL_FACE);
    Mat4.fromQuat(this._modelM, ship.quat);
    const hs = opts?.hullScale ?? SHIP_CHASE_SCALE;
    Mat4.scaling(this._b, hs, hs, hs);
    Mat4.multiply(this._modelM, this._modelM, this._b);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._modelM);
    // sunlight direction toward the hull, world space (star at origin)
    Vec3.normalize(this._lightDir, ship.pos);
    gl.uniform1f(prog.uniforms.u_fill, 0.8); // strong fill: shadowed hull stays a readable grey, never black
    if (this.aethonHull) {
      gl.uniform1f(prog.uniforms.u_lit, 1);
      gl.uniform3fv(prog.uniforms.u_lightDir, this._lightDir);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.hullAethon ?? this.tex.hull);
      gl.uniform1f(prog.uniforms.u_tileVary, 1); // mirror + value-step each plate
      // Livery. Set for the player hull only and reset immediately after, since
      // every other mesh drawn through this program — planets, stations,
      // hostiles — shares the uniform and must stay at factory white.
      if (this.hullTint) gl.uniform3fv(prog.uniforms.u_tint, this.hullTint);
      this.renderer.drawMesh(this.aethonHull);
      if (this.hullTint) gl.uniform3f(prog.uniforms.u_tint, 1, 1, 1);
      gl.uniform1f(prog.uniforms.u_tileVary, 0);
    }
    if (this.aethonGlow) {
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.extGlow);
      this.renderer.drawMesh(this.aethonGlow);
    }

    // -- exterior effect layers ------------------------------------------------
    // Everything from here is light: it depth-TESTS against the hull (plumes
    // hide behind the ship correctly) but never WRITES depth, so stacked
    // transparent layers can't punch holes in each other — and every billboard
    // is double-sided, so no layer vanishes to back-face culling.
    gl.depthMask(false);
    gl.disable(gl.CULL_FACE);
    const q = ship.quat;
    const rot = (v) => {
      const ux = 2 * (q[1] * v[2] - q[2] * v[1]);
      const uy = 2 * (q[2] * v[0] - q[0] * v[2]);
      const uz = 2 * (q[0] * v[1] - q[1] * v[0]);
      return [v[0] + q[3] * ux + (q[1] * uz - q[2] * uy),
        v[1] + q[3] * uy + (q[2] * ux - q[0] * uz),
        v[2] + q[3] * uz + (q[0] * uy - q[1] * ux)];
    };

    const FX = AETHON_FX;
    const t = this._flameT ?? 0;
    /** hull-model point → chase-frame world point (rotate with the ship, scale) */
    const at = (p) => {
      const r = rot(p);
      return [r[0] * SHIP_CHASE_SCALE, r[1] * SHIP_CHASE_SCALE, r[2] * SHIP_CHASE_SCALE];
    };

    // Every soft light layer goes through the sprite BATCH: one draw call per
    // TEXTURE for all of them, in a fixed cold→hot order. A three-bell cluster
    // with shock beads, RCS haze and a smoke trail is ~60 billboards — drawn
    // individually that alone is over half the <100 draw-call space budget.
    const soft = []; // flattened [tex, pos, size, …]
    const push = (tex, p, size) => { if (tex && size > 0.05) soft.push(tex, p, size); };
    const flushSoft = () => {
      for (const tex of [this.tex.smoke?.[0], this.tex.smoke?.[1], this.tex.glowBlue,
        this.tex.glowAmber, this.tex.glowWhite]) {
        if (!tex) continue;
        let any = false;
        this._spriteReset();
        for (let i = 0; i < soft.length; i += 3) {
          if (soft[i] === tex) { this._spritePush(soft[i + 1], soft[i + 2], chase.eye); any = true; }
        }
        if (any) this._spriteFlush(prog, tex);
      }
      soft.length = 0;
    };

    // Main drive: six stacked layers per bell, all anchored to AETHON_FX so the
    // burn starts in the actual nozzle mouth. It used to emit from model z=16.8 —
    // amidships, 14 world units ahead of the bells — which buried every throat
    // core and bloom inside the hull, and is why the engines read as a few loose
    // dots instead of a burn. Sizes are WORLD units against the 480×270 buffer.
    const thr = ship.thrust ?? 0;
    const fwdThr = Math.min(1, Math.max(0, thr)); // 0..1; boost carries thrust to 5
    if (fwdThr > 0.05 && this.tex.flames) {
      const back = rot([0, 0, 1]);
      const boost = !!ship.boosting;
      const bf = boost ? 2.4 : 1; // plume stretch at full burn
      const wf = boost ? 1.5 : 1; // and girth
      const nozR = FX.nozzleR * SHIP_CHASE_SCALE; // bell mouth radius, world units
      const len = 28 * (0.3 + 0.7 * fwdThr) * bf;
      const flick = 0.86 + 0.28 * Math.abs(Math.sin(t * 31));
      const flick2 = 0.72 + 0.46 * Math.abs(Math.sin(t * 47 + 1.3));
      for (const n of FX.nozzles) {
        const p = at(n);
        push(this.tex.glowAmber, p, nozR * (3.2 + (boost ? 4.2 : 0)) * fwdThr); // bell wash
        push(this.tex.glowWhite, p, nozR * 1.5 * fwdThr * wf);                  // throat core
        this._drawFlame(prog, p, back, len * flick, nozR * 1.15 * wf, chase.eye);
        this._drawFlame(prog, p, back, len * 0.52 * flick2, nozR * 0.58 * wf, chase.eye);
        // shock diamonds: the standing bead pattern of an overexpanded bell
        for (let i = 1; i <= 3; i++) {
          const f = i * 0.17 * len;
          push(this.tex.glowWhite, [p[0] + back[0] * f, p[1] + back[1] * f, p[2] + back[2] * f],
            nozR * (0.9 - i * 0.19) * fwdThr * flick2);
        }
      }
      // one wide wash behind the whole cluster, tying the three plumes together
      const cn = FX.nozzles[1];
      push(this.tex.glowAmber, at([cn[0], cn[1], cn[2] + (len * 0.6) / SHIP_CHASE_SCALE]),
        nozR * (5.4 + (boost ? 6 : 0)) * fwdThr);
      // verniers trickle whenever the mains are lit
      for (const v of FX.verniers) {
        const p = at(v);
        push(this.tex.glowAmber, p, FX.vernierR * SHIP_CHASE_SCALE * 3.4 * fwdThr);
        this._drawFlame(prog, p, back, len * 0.3 * flick2, FX.vernierR * SHIP_CHASE_SCALE * 1.3, chase.eye);
      }
    }

    // -- DEFLECTOR -------------------------------------------------------------
    // A hull-hugging ellipsoid, but the point of interest is the LOCAL response:
    // the whole bubble flashing at once told you nothing about where you had been
    // hit. So the field now has two parts.
    //
    //   1. the field itself — THREE faceted shells at different radii breathing
    //      at three unrelated rates, so their interference crawls instead of
    //      pulsing in lockstep, plus a cold rim bloom;
    //   2. per-hit ripples — each round that the deflector eats leaves a
    //      shockwave that expands across the surface from the point of impact,
    //      with a white-hot core at the strike, a discharge arc lashing back
    //      along the field, and a scatter of surface motes.
    const hits = this._shieldHits ?? [];
    if (((this.shieldT ?? 0) > 0 || hits.length) && this.tex.shield) {
      const st = Math.max(this.shieldT ?? 0, hits.length ? 0.35 : 0);
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.shield);
      // the hull is NOT origin-centred — the bubble sits at its true midpoint
      const c = at(FX.center);
      const [hx, hy, hz] = FX.shieldHalf;
      for (const [k, rate, ph] of [[1.0, 40, 0], [0.94, 33, 2.1], [0.86, 26, 4.4]]) {
        const pulse = k * (1 + 0.05 * Math.sin(t * rate + ph)) * (0.92 + 0.08 * st);
        Mat4.translation(this._a, c[0], c[1], c[2]);
        Mat4.fromQuat(this._b, ship.quat);
        Mat4.multiply(this._a, this._a, this._b);
        const g = SHIP_CHASE_SCALE * pulse;
        Mat4.scaling(this._b, hx * g, hy * g, hz * g);
        Mat4.multiply(this._a, this._a, this._b);
        gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
        this.renderer.drawMesh(this.sphere);
      }
      push(this.tex.glowBlue, c, 16 * SHIP_CHASE_SCALE * st);

      // the ripples. `h.dir` is a unit direction in SHIP-LOCAL space, so the
      // strike stays welded to its spot on the field however the ship manoeuvres.
      for (const h of hits) {
        // ship-local direction -> where that lands on the ellipsoid, in model
        // units, then out to the chase frame through the same at() the hull uses
        const lp = this._sh1;
        lp[0] = FX.center[0] + h.dir[0] * hx;
        lp[1] = FX.center[1] + h.dir[1] * hy;
        lp[2] = FX.center[2] + h.dir[2] * hz;
        const surf = at(lp);
        const age = 1 - h.t; // 0 at the strike, 1 as it dies
        // the expanding wavefront, growing and thinning
        if (this.tex.shieldRipple) {
          const rr = (2.5 + 16 * age) * SHIP_CHASE_SCALE * (h.scale ?? 1);
          this._drawGlow(prog, surf, rr, this.tex.shieldRipple, chase.eye);
          // a second, smaller wave a beat behind the first
          if (age > 0.22) {
            this._drawGlow(prog, surf, (2.0 + 10 * (age - 0.22)) * SHIP_CHASE_SCALE,
              this.tex.shieldRipple, chase.eye);
          }
        }
        // white-hot strike point, collapsing fast
        push(this.tex.glowWhite ?? this.tex.glowBlue, surf, 5.5 * SHIP_CHASE_SCALE * h.t * h.t);
        push(this.tex.glowBlue, surf, 11 * SHIP_CHASE_SCALE * h.t);
        // discharge arc: energy lashing back along the field from the strike,
        // pointing along the surface (the component of the hull's own axis
        // perpendicular to the impact normal), so it lies ON the bubble
        if (this.tex.coldJet && h.t > 0.25) {
          const d0 = h.dir;
          const ax2 = Math.abs(d0[1]) > 0.9 ? AXIS_X_REF : AXIS_Y_REF;
          const tg = Vec3.normalize(this._sh2, Vec3.cross(this._sh2, d0, ax2));
          const tg2 = Vec3.cross(this._sh3, d0, tg);
          for (const [tv, sgn] of [[tg, 1], [tg, -1], [tg2, 1], [tg2, -1]]) {
            const dv = this._sh4;
            dv[0] = tv[0] * sgn; dv[1] = tv[1] * sgn; dv[2] = tv[2] * sgn;
            this._drawFlame(prog, surf, rot(dv), 13 * SHIP_CHASE_SCALE * h.t,
              1.5 * SHIP_CHASE_SCALE * h.t, chase.eye, this.tex.coldJet);
          }
        }
      }
    }

    // RCS: cold-gas puffs from the SAME port table the hull blisters are stamped
    // from, so a jet always leaves a visible nozzle. Attitude jets are driven by
    // the hull's angular velocity, so they keep firing while momentum is being
    // arrested — what a real attitude-control burn looks like.
    if (this.rcs && this.tex.flames) {
      const r = this.rcs;
      const fire = (ports, gain, len, width, rate, ph) => {
        if (!ports || gain < 0.04) return;
        const j = 0.8 + 0.34 * Math.abs(Math.sin(t * rate + ph));
        for (const { p, ax } of ports) {
          const wp = at(p);
          push(this.tex.glowBlue, wp, width * 2.3 * gain);
          this._drawFlame(prog, wp, rot(ax), len * gain * j, width * gain, chase.eye, this.tex.coldJet);
        }
      };
      const mag = (v) => Math.min(1, Math.abs(v ?? 0) / 0.9);
      if (Math.abs(r.roll ?? 0) > 0.05) {
        fire(r.roll > 0 ? FX.rcs.rollPos : FX.rcs.rollNeg, mag(r.roll), 5.0, 1.0, 53, 0);
      }
      if (Math.abs(r.yaw ?? 0) > 0.05) {
        fire([FX.rcs.yaw[r.yaw > 0 ? 1 : 0]], mag(r.yaw), 4.2, 0.85, 61, 0.7);
      }
      if (Math.abs(r.pitch ?? 0) > 0.05) {
        fire(r.pitch > 0 ? FX.rcs.noseUp : FX.rcs.noseDown, mag(r.pitch), 4.2, 0.85, 59, 1.9);
      }
      const st = r.strafe;
      if (st) { // a jet pushes away from its own side: strafing fires the far cluster
        if (st[0]) fire(st[0] > 0 ? FX.rcs.latPort : FX.rcs.latStar, 1, 4.4, 0.9, 67, 2.0);
        if (st[1]) fire(st[1] > 0 ? FX.rcs.vertDown : FX.rcs.vertUp, 1, 4.0, 0.85, 71, 0.4);
      }
      // reverse thrust brakes on the forward-facing pylon clusters
      if (thr < -0.05) fire(FX.rcs.retro, Math.min(1, -thr), 7.5, 1.15, 43, 1.1);
    }

    // nav strobes: a hard double-blink at every beacon lens, ~1.1 Hz. Cheap, and
    // it's what makes the hull read as a crewed vehicle at distance.
    {
      const ph = (t * 1.1) % 1;
      if (ph < 0.06 || (ph > 0.13 && ph < 0.18)) {
        for (const b of FX.beacons) push(this.tex.glowWhite, at(b), 0.8);
      }
      push(this.tex.glowAmber, at([0, 2.7, -36.5]), 2.0); // lit cockpit on the nose
    }

    // hull damage: below ~65% integrity the ship trails ragged smoke and a
    // guttering ember glow from two wound points — worse as integrity falls
    const dmg = Math.max(0, Math.min(1, this.damage ?? 0));
    if (dmg > 0.35 && this.tex.smoke) {
      // spawn: renderExterior runs per frame; keep a modest cap
      if (this._dmgPuffs.length < 6 + dmg * 18 && Math.random() < dmg * 0.55) {
        const w = FX.wounds[(Math.random() * FX.wounds.length) | 0];
        this._dmgPuffs.push({
          pos: [w[0] + (Math.random() - 0.5) * 0.8, w[1], w[2] + (Math.random() - 0.5) * 0.8],
          ttl: 1.4 + Math.random() * 0.8,
        });
      }
      for (const s of this._dmgPuffs) {
        const grow = 1.6 + (2.2 - s.ttl) * 2.1;
        const fr = this.tex.smoke[Math.floor(t * 4 + s.ttl * 2) % this.tex.smoke.length];
        push(fr, at(s.pos), grow * Math.min(1, s.ttl) * dmg * 1.7);
      }
      const gut = Math.abs(Math.sin(t * 23)) * Math.abs(Math.sin(t * 7.3));
      for (const w of FX.wounds) push(this.tex.glowAmber, at(w), (1.7 + 2.4 * gut) * dmg);
    }

    // -- BREACH VENTING --------------------------------------------------------
    // A holed section blows its atmosphere, and it does not blow it as a soft
    // puff — it is a hard, narrow, supersonic jet at the lip that flares and
    // goes cold as it expands into vacuum. Three layers per vent:
    //
    //   1. a WHITE-HOT ROOT at the lip, tiny and violently flickering, which is
    //      the choked flow through the hole;
    //   2. an ORIENTED JET along the section's outward normal, built from
    //      _spriteStreak so it actually points the way it is travelling —
    //      _spritePush is screen-axis-aligned and physically cannot do this,
    //      which is why the old wound smoke had to be a stack of round puffs;
    //   3. a COLD FLARE further out, where the jet has expanded and dimmed to
    //      condensing crystals.
    //
    // Keyed per section, so this reads as the SAME damage the HUD's plan shows
    // and the same one REPAIR is going to patch — not a generic "ship is hurt"
    // smoke plume from a fixed point amidships.
    const secs = this._hullSections;
    if (secs && FX.sectionVents && this.tex.flames) {
      // ONE sprite batch and ONE frame for all six vents. Flushing per vent cost
      // up to six draw calls out of a <100 space budget for an effect that is at
      // most six short streaks; the per-vent frame offset that forced the split
      // bought nothing, because the flicker term below already desynchronises
      // them far more visibly than a texture frame does.
      this._spriteReset();
      let anyJet = false;
      for (const [key, [p, n]] of Object.entries(FX.sectionVents)) {
        const v = secs[key];
        if (v == null || v >= 58) continue;
        // 58 -> 0 maps to 0 -> 1 of severity; a breach (<=25) is over half
        const sev = Math.min(1, (58 - v) / 58);
        const root = at(p);
        const dir = rot(n);
        // choked-flow flicker: two unrelated fast rates so it never pulses
        const fl = 0.55 + 0.75 * Math.abs(Math.sin(t * 31 + p[2])) * Math.abs(Math.sin(t * 11.7));
        push(this.tex.glowWhite, root, (0.5 + 1.1 * sev) * fl);
        push(this.tex.glowAmber, root, (0.9 + 2.0 * sev) * fl);
        // the jet: five oriented segments, widening and cooling outward
        const reach = (4.5 + 19 * sev) * SHIP_CHASE_SCALE;
        anyJet = true;
        for (let k = 0; k < 5; k++) {
          const f0 = k / 5, f1 = (k + 1) / 5;
          const m = (f0 + f1) * 0.5;
          this._streakMid[0] = root[0] + dir[0] * reach * m;
          this._streakMid[1] = root[1] + dir[1] * reach * m;
          this._streakMid[2] = root[2] + dir[2] * reach * m;
          this._streakDir[0] = dir[0]; this._streakDir[1] = dir[1]; this._streakDir[2] = dir[2];
          this._spriteStreak(this._streakMid, this._streakDir,
            reach * 0.13, (0.22 + 0.95 * m) * sev * fl * SHIP_CHASE_SCALE * 1.6, chase.eye);
        }
        // cold flare at the far end — expanded gas, condensing. Kept SMALL: at
        // the first size it was a round blue blob big enough to out-read the jet
        // it was supposed to be terminating, which put a soap bubble on the end
        // of every breach.
        if (this.tex.glowBlue) {
          push(this.tex.glowBlue, [root[0] + dir[0] * reach, root[1] + dir[1] * reach,
            root[2] + dir[2] * reach], (0.8 + 1.5 * sev) * (0.7 + 0.4 * fl));
        }
      }
      if (anyJet) {
        const frames = this.tex.flames;
        this._spriteFlush(prog, frames[Math.floor(t * 12) % frames.length]);
      }
    }

    flushSoft();

    // the jump singularity draws over everything — it is consuming the ship
    this._drawWarpFx(chase);

    gl.disable(gl.BLEND);
    gl.enable(gl.CULL_FACE);
    gl.enable(gl.DEPTH_TEST);
    gl.depthMask(true);
  }

  /**
   * Project a position onto a shell of radius SKY_RADIUS centred on the CAMERA
   * EYE (not the ship). Because the shell follows the eye, the apparent angular
   * size and direction of a body are exact from wherever the camera actually is
   * — the chase cam sits tens of units off the ship, and centring on the ship
   * made every body warp/"magnify" as the view turned. Radius scales by the
   * same k, so a body can never reach the eye: max drawn radius is
   * SKY/1.06 < SKY (collision keeps |eye→body| ≥ 1.06·radius), i.e. the camera
   * is always outside the sphere — the black-round engulfing is impossible.
   * @returns {number} k scale factor for the body radius
   */
  _shellProject(local, eye, bodyRadius = 0) {
    const ex = eye?.[0] ?? 0, ey = eye?.[1] ?? 0, ez = eye?.[2] ?? 0;
    const dx = local[0] - ex, dy = local[1] - ey, dz = local[2] - ez;
    // floor the distance at 1.06 body radii: ship collision keeps the SHIP out,
    // but the chase eye rides ~58u off it and could still dip inside a small
    // moon — this keeps the drawn sphere from ever swallowing the camera.
    const d = Math.max(Math.hypot(dx, dy, dz) || 1, bodyRadius * 1.06);
    const k = FLIGHT.SKY_RADIUS / d;
    local[0] = ex + dx * k; local[1] = ey + dy * k; local[2] = ez + dz * k;
    return k;
  }

  _drawBillboard(prog, local, worldRadius, texture, eye) {
    const gl = this.renderer.gl;
    const k = this._shellProject(local, eye);
    const size = worldRadius * k * 1.9; // corona bleeds past the disc
    // orient the quad to face the camera eye
    const dir = Vec3.create();
    dir[0] = local[0] - (eye?.[0] ?? 0); dir[1] = local[1] - (eye?.[1] ?? 0); dir[2] = local[2] - (eye?.[2] ?? 0);
    Vec3.normalize(dir, dir);
    const upRef = Math.abs(dir[1]) > 0.9 ? [1, 0, 0] : [0, 1, 0];
    const right = Vec3.normalize(Vec3.create(), Vec3.cross(Vec3.create(), upRef, dir));
    const up = Vec3.cross(Vec3.create(), dir, right);
    const m = this._m;
    m[0] = right[0] * size; m[1] = right[1] * size; m[2] = right[2] * size; m[3] = 0;
    m[4] = up[0] * size; m[5] = up[1] * size; m[6] = up[2] * size; m[7] = 0;
    m[8] = -dir[0]; m[9] = -dir[1]; m[10] = -dir[2]; m[11] = 0;
    m[12] = local[0]; m[13] = local[1]; m[14] = local[2]; m[15] = 1;
    gl.uniform1f(prog.uniforms.u_lit, 0);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    this.renderer.drawMesh(this.billboard);
  }

  _drawPlanet(prog, ship, body, eye) {
    const gl = this.renderer.gl;
    // Surfaces are built on demand (main.js installs the hook) so the body-type
    // roster can grow without paying for every kind at boot — same contract as
    // ensureStarTex. Cheap no-op once the kind is cached.
    this.ensureBodyTex?.(body.kind);
    const local = ship.toLocal(this._L, body.pos);
    const k = this._shellProject(local, eye, body.radius);
    const r = body.radius * k; // camera-centred shell: always < SKY_RADIUS/1.06
    if (this._subPixel(local, r, eye)) return;

    // sunlight direction at the planet, in ship-local space
    Vec3.normalize(this._lightDir, body.pos); // from star (origin) toward body
    ship.dirToLocal(this._lightDir, this._lightDir);

    // the far arc goes down BEFORE the sphere so the planet occludes it
    if (body.rings) {
      this._ringPole[0] = 0; this._ringPole[1] = 1; this._ringPole[2] = 0;
      ship.dirToLocal(this._ringPole, this._ringPole); // ecliptic pole, ship-local
      this._drawRingHalf(prog, 'far', local, r, body, eye, this._ringPole);
      gl.uniform3fv(prog.uniforms.u_lightDir, this._lightDir);
    }

    Mat4.translation(this._a, local[0], local[1], local[2]);
    Mat4.rotationY(this._b, body.angle);
    Mat4.multiply(this._a, this._a, this._b);
    // IRREGULAR SHARDS. A belt asteroid is rubble, not a world, and rendering it
    // as a perfect sphere made a 300km shard read as a tiny planet — same
    // silhouette as Redfall, just smaller. `spin` already exists on belt bodies
    // (the generator tumbles them fast); this gives them a body to tumble. Gated
    // on `shard`, NOT on `spin`: every body spins, so keying off that turned every
    // planet in the system into a lumpy ellipsoid. The
    // axis ratios are derived from the id hash, so a given shard is always the
    // same lumpy shape, and the tumble is about TWO axes because a real rubble
    // pile has no reason to be spin-stabilised.
    if (body.shard) {
      const h = this._shardHash(body.id);
      const t = this._flameT ?? 0;
      Mat4.rotationX(this._b, t * body.spin * 1.7 + h * 6.3);
      Mat4.multiply(this._a, this._a, this._b);
      const sx = r * (0.72 + h * 0.5);
      const sy = r * (0.62 + ((h * 7.1) % 1) * 0.55);
      const sz = r * (0.78 + ((h * 3.7) % 1) * 0.45);
      Mat4.scaling(this._b, sx, sy, sz);
    } else {
      Mat4.scaling(this._b, r, r, r);
    }
    Mat4.multiply(this._a, this._a, this._b);

    gl.uniform1f(prog.uniforms.u_lit, 1);
    gl.uniform1f(prog.uniforms.u_fill, PLANET_FILL);
    gl.uniform3fv(prog.uniforms.u_lightDir, this._lightDir);
    const atmo = ATMO[body.kind] ?? [0, 0, 0];
    gl.uniform3f(prog.uniforms.u_atmo, atmo[0], atmo[1], atmo[2]);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
    gl.bindTexture(gl.TEXTURE_2D, this.tex.planets[body.kind]);
    this.renderer.drawMesh(this.sphere);
    // living atmosphere: a cloud shell spinning ~1.7× the surface rate so the
    // weather slides over the ground, AND cycling through its animation frames
    // so the deck itself churns and billows (the repeating atmosphere sprite).
    // Gas giants get a second, counter-sheared high haze layer for depth.
    const cloudSet = this.tex.clouds?.[body.kind];
    if (cloudSet) {
      const set = Array.isArray(cloudSet) ? cloudSet : [cloudSet];
      // per-body phase offset so two worlds never churn in lockstep
      const phase = (body.angle ?? 0) * 3;
      const drawShell = (spin, scale, frameOff, alphaTex) => {
        Mat4.translation(this._a, local[0], local[1], local[2]);
        Mat4.rotationY(this._b, spin);
        Mat4.multiply(this._a, this._a, this._b);
        const cr = r * scale;
        Mat4.scaling(this._b, cr, cr, cr);
        Mat4.multiply(this._a, this._a, this._b);
        gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
        gl.bindTexture(gl.TEXTURE_2D, alphaTex ?? set[frameOff % set.length]);
        this.renderer.drawMesh(this.sphere);
      };
      gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
      // slow: weather drifts, it doesn't boil. A full 4-frame cycle takes ~9s,
      // so the deck reshapes gently under the faster differential rotation.
      const base = Math.floor(((this._flameT ?? 0) * CLOUD_FPS + phase));
      drawShell(body.angle * 1.7 + 0.9, 1.03, base);
      if (body.kind === 'gas') {
        // upper haze: slower spin, offset frame — the two decks slide against
        // each other and read as banded depth instead of one painted sphere
        drawShell(body.angle * 1.25 - 0.4, 1.062, base + 2);
      }
    }
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0); // clear for following draws
    // the near arc goes down AFTER, so it crosses the planet's disc
    if (body.rings) this._drawRingHalf(prog, 'near', local, r, body, eye, this._ringPole);
    // a comet is mostly the part that is not the nucleus
    if (body.comet) this._drawComet(prog, ship, body, local, r, eye);
  }

  /** Stable 0..1 hash from a body id — a shard's shape must not flicker. */
  _shardHash(id) {
    let h = 2166136261;
    const s = String(id ?? '');
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = (h * 16777619) >>> 0; }
    return (h % 10007) / 10007;
  }

  /**
   * COMET COMA + TAILS. The one body type whose appearance is dominated by
   * something a lit sphere cannot show: a comet's nucleus is a few kilometres of
   * dirty ice, and everything you actually see is the gas and dust coming off it.
   * Drawn as a bright coma around the nucleus plus TWO tails, because a real comet
   * has two and they point in different directions:
   *
   *   - the ION tail is gas swept by the solar wind. It points DIRECTLY away from
   *     the star, dead straight, and it is the bluer, fainter one.
   *   - the DUST tail is heavier grains that keep their orbital momentum, so they
   *     lag behind along the track and the tail CURVES. Warmer and broader.
   *
   * Both scale with proximity to the star, which is the whole drama of a comet:
   * out past the belt it is an inert snowball, and near perihelion it grows a tail
   * longer than the planet it just passed.
   */
  _drawComet(prog, ship, body, local, r, eye) {
    if (!this.tex.plasma && !this.tex.smoke) return;
    const gl = this.renderer.gl;
    // Activity by distance from the star, which sits at the world origin. A comet
    // is inert beyond ~4 AU and blazing inside ~1.
    const d = Math.hypot(body.pos[0], body.pos[1], body.pos[2]) || 1;
    const act = Math.max(0, Math.min(1, (4.2 - d / UNITS_PER_AU) / 3.4));
    if (act <= 0.02) return;

    // AWAY FROM THE STAR, in ship-local space — the ion tail's direction.
    const away = this._cm0;
    away[0] = body.pos[0] / d; away[1] = body.pos[1] / d; away[2] = body.pos[2] / d;
    ship.dirToLocal(away, away);
    // The dust tail lags along the orbit track, so bend `away` toward the body's
    // own velocity heading. Without a velocity we fall back to the ecliptic
    // tangent, which for a near-planar orbit is the same answer.
    const lag = this._cm1;
    const vx = -body.pos[2], vz = body.pos[0]; // tangent to a circular orbit
    const vl = Math.hypot(vx, vz) || 1;
    lag[0] = vx / vl; lag[1] = 0; lag[2] = vz / vl;
    ship.dirToLocal(lag, lag);
    const sense = (body.orbit?.dir ?? 1) < 0 ? -0.42 : 0.42;
    for (let i = 0; i < 3; i++) lag[i] = away[i] * 0.72 + lag[i] * sense;
    Vec3.normalize(lag, lag);

    const t = this._flameT ?? 0;
    const ion = this.tex.glowBlue, dust = this.tex.smoke?.[0] ?? this.tex.glowAmber;
    const comaTex = this.tex.glowWhite ?? this.tex.glowBlue;
    // The body pass runs with BACK-FACE CULLING ON (planets are solid spheres), and
    // a camera-facing sprite quad is single-sided — with culling on, all 23 of these
    // were built, uploaded, drawn and then discarded by the rasteriser. The star's
    // plasma escapes this only because _drawStar happens before the cull is enabled.
    const culling = gl.isEnabled(gl.CULL_FACE);
    if (culling) gl.disable(gl.CULL_FACE);
    const blending = gl.isEnabled(gl.BLEND);
    if (!blending) gl.enable(gl.BLEND);
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
    this._spriteReset();
    // COMA: a bright envelope, several times the nucleus, breathing slightly
    const coma = r * (2.4 + 3.6 * act) * (0.94 + 0.06 * Math.sin(t * 2.3));
    this._spritePush(local, coma, eye);
    this._spriteFlush(prog, comaTex);

    // TAILS: chains of sprites that grow and thin along their axis. Length is in
    // NUCLEUS radii so a big comet gets a big tail, capped so it cannot reach
    // across the whole shell projection.
    const seg = act > 0.55 ? 11 : 7;
    const drawTail = (dir, len, wid, tex, curve) => {
      this._spriteReset();
      for (let i = 1; i <= seg; i++) {
        const f = i / seg;
        const p = this._cm2;
        // `curve` bends the chain sideways as it goes — the dust tail's arc
        for (let a = 0; a < 3; a++) p[a] = local[a] + dir[a] * len * f + away[a] * curve * f * f * len;
        // fatter and fainter with distance from the nucleus; the flicker keeps
        // the streamers from reading as one solid cone
        const flick = 0.82 + 0.3 * Math.abs(Math.sin(t * 3 + i * 1.9 + d * 1e-4));
        this._spritePush(p, r * wid * (0.5 + f * 1.9) * flick, eye);
      }
      this._spriteFlush(prog, tex);
    };
    const L = Math.min(r * 46, r * (6 + 34 * act));
    drawTail(away, L, 1.5 * act + 0.5, ion, 0);
    drawTail(lag, L * 0.72, 2.6 * act + 0.7, dust, 0.16);
    if (culling) gl.enable(gl.CULL_FACE);
    if (!blending) gl.disable(gl.BLEND);
  }

  /**
   * True when a body at `local` with projected radius `r` covers less than about
   * half a pixel — see BODY_MIN_RATIO. Cheap enough to run per body per frame.
   */
  _subPixel(local, r, eye) {
    const dx = local[0] - (eye?.[0] ?? 0);
    const dy = local[1] - (eye?.[1] ?? 0);
    const dz = local[2] - (eye?.[2] ?? 0);
    return r / Math.max(1, Math.hypot(dx, dy, dz)) < BODY_MIN_RATIO;
  }

  /**
   * One half of a planetary ring system, as a camera-facing billboard.
   *
   * `half` must be drawn 'far' BEFORE the planet sphere and 'near' AFTER it —
   * that ordering is the entire occlusion model, since the space pass runs with
   * no depth test. See TextureFactory.planetRingTexture for why this is a
   * billboard and not an annulus.
   *
   * `upRef` is the ring plane's pole IN THE CURRENT RENDER FRAME (ship-local for
   * the cockpit view, world for the chase cam). It must not be the camera's own
   * up, or the ring would roll with the ship instead of staying fixed against
   * the ecliptic.
   */
  _drawRingHalf(prog, half, local, r, body, eye, upRef) {
    // this body's OWN sheet if its rings were solved from its moons; the shared
    // default only covers bodies that predate the dynamics
    this.ensureRingTex?.(body);
    const tex = this.tex.rings?.[body.id]?.[half] ?? this.tex.planetRing?.[half];
    if (!tex) return;
    const gl = this.renderer.gl;
    const dir = this._L5;
    dir[0] = local[0] - (eye?.[0] ?? 0);
    dir[1] = local[1] - (eye?.[1] ?? 0);
    dir[2] = local[2] - (eye?.[2] ?? 0);
    Vec3.normalize(dir, dir);
    // degenerate case: looking straight down the ring pole — fall back to any
    // perpendicular so `right` doesn't come out zero-length
    const ref = Math.abs(Vec3.dot(dir, upRef)) > 0.985 ? [dir[2], dir[0], dir[1]] : upRef;
    const right = Vec3.normalize(this._L6, Vec3.cross(this._L6, ref, dir));
    const up = Vec3.cross(this._L7, dir, right);
    const size = r * (body.rings.outerMul ?? body.rings.outer ?? 2.2);
    const m = this._m;
    m[0] = right[0] * size; m[1] = right[1] * size; m[2] = right[2] * size; m[3] = 0;
    m[4] = up[0] * size; m[5] = up[1] * size; m[6] = up[2] * size; m[7] = 0;
    m[8] = -dir[0]; m[9] = -dir[1]; m[10] = -dir[2]; m[11] = 0;
    m[12] = local[0]; m[13] = local[1]; m[14] = local[2]; m[15] = 1;
    // Unlit, like the corona and the nebula sheets: ring particles are dirty ice
    // with a high albedo, and the sheet's own dithered banding carries the form.
    // A camera-facing quad has one normal, so lighting it would only flatten it
    // into a uniform dimming anyway.
    gl.uniform1f(prog.uniforms.u_lit, 0);
    gl.uniform3f(prog.uniforms.u_atmo, 0, 0, 0);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, m);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    const culling = gl.isEnabled(gl.CULL_FACE);
    if (culling) gl.disable(gl.CULL_FACE); // the quad's back face shows from behind
    this.renderer.drawMesh(this.billboard);
    if (culling) gl.enable(gl.CULL_FACE);
    gl.uniform1f(prog.uniforms.u_lit, 1);
  }

  /**
   * Draw one non-combat object: station, shipyard, wreck, mine, or a passing
   * hauler. All of them ride the same `system.ships` list and the same transform;
   * what differs is which mesh comes out of the structure library.
   *
   * The GLOW pass is the reason this is worth doing at all. A structure's second
   * mesh — window bands, approach strobes, a refinery flare, a cutter arc — is
   * drawn with `u_lit = 0` against the amber glow texture, so it holds its
   * brightness whatever the star is doing. At the range where you first pick a
   * station out of the dark, the plating detail is a couple of pixels and the
   * lights are the entire silhouette. A wreck and a monolith have no glow mesh,
   * which is precisely how you tell them apart from a station at that range.
   */
  _drawHull(prog, npc, eye, toFrame, dirToFrame) {
    const gl = this.renderer.gl;
    const local = toFrame(this._L, npc.pos);
    // Structures are much bigger than the fighter the default radius assumes; a
    // 60-unit shipyard projected at a 12-unit radius pops in and out at the
    // shell boundary. `bodyR` lets a record state its own size.
    const k = this._shellProject(local, eye, npc.bodyR ?? 12);

    Vec3.normalize(this._lightDir, npc.pos);
    // The chase frame is world-axis (translated only), so it passes no rotation
    // — the same contract `renderCombat` uses, and the reason this one function
    // can serve both the cockpit and the hull cam.
    if (dirToFrame) dirToFrame(this._lightDir);

    Mat4.translation(this._a, local[0], local[1], local[2]);
    Mat4.rotationY(this._b, npc.yaw);
    Mat4.multiply(this._a, this._a, this._b);
    // Structures also PITCH and ROLL. A wreck that only spins about y reads as a
    // carousel; a tumble needs all three, and a station holding attitude needs
    // to be able to sit at a deliberate angle to the plane.
    if (npc.pitch) { Mat4.rotationX(this._b, npc.pitch); Mat4.multiply(this._a, this._a, this._b); }
    if (npc.roll) { Mat4.rotationZ(this._b, npc.roll); Mat4.multiply(this._a, this._a, this._b); }
    const rec = this.structures?.[npc.structure
      ? (npc.variant != null ? `${npc.structure}_${npc.variant}` : npc.structure)
      : null];
    /**
     * THE SHELL PROJECTION HAS A HARD CEILING, and structures big enough to be
     * worth flying to are the things that hit it.
     *
     * Everything out here is drawn by moving it onto a sphere of radius
     * `SKY_RADIUS` around the eye and scaling it to keep its angular size. That
     * only works while the drawn object is SMALL compared to the shell. A trade
     * post at four times its old size, met at its docking stand-off, came out
     * with a drawn radius bigger than the ninety units between it and the
     * camera — so half its geometry was behind the eye and the station rendered
     * as a field of torn fragments. That is what "the station models are
     * broken" was: not the mesh, the projection.
     *
     * Capping the drawn radius at a fraction of the shell is the fix, and it
     * costs nothing real: at 0.75 a structure can still fill 73 degrees of the
     * view, which is as close as a shell renderer can honestly show anything.
     */
    const meshR = rec?.radius ?? 30;
    const s = Math.min(k * (npc.scale ?? 1), (FLIGHT.SKY_RADIUS * 0.75) / meshR);
    Mat4.scaling(this._b, s, s, s);
    Mat4.multiply(this._a, this._a, this._b);
    const mesh = rec?.hull ?? this.freighter;
    if (!mesh) return;

    gl.uniform1f(prog.uniforms.u_lit, 1);
    gl.uniform3fv(prog.uniforms.u_lightDir, this._lightDir);
    gl.uniformMatrix4fv(prog.uniforms.u_model, false, this._a);
    gl.uniform3fv(prog.uniforms.u_tint, STRUCTURE_TINT[npc.structure] ?? WHITE3);
    gl.bindTexture(gl.TEXTURE_2D, this.tex.hull);
    gl.uniform1f(prog.uniforms.u_tileVary, 1);
    this.renderer.drawMesh(mesh);
    gl.uniform1f(prog.uniforms.u_tileVary, 0);
    gl.uniform3fv(prog.uniforms.u_tint, WHITE3);

    // Lit windows and running lights, if this thing is powered. Same transform,
    // unlit, on the glow sheet — and skipped entirely once a structure is
    // `dark` (a station that lost its reactor, a derelict that never had one).
    if (rec?.glow && !npc.dark) {
      gl.uniform1f(prog.uniforms.u_lit, 0);
      gl.bindTexture(gl.TEXTURE_2D, this.tex.glowAmber);
      this.renderer.drawMesh(rec.glow);
      gl.uniform1f(prog.uniforms.u_lit, 1);
    }
  }
}
