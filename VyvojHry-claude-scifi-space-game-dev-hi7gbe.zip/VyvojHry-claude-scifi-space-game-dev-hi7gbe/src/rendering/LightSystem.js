/**
 * LightSystem — point/tube lights with the flicker patterns from context/02 §6.
 * Lights belong to zones; each zone draw gets its own (max 8) light set, keeping
 * the per-draw uniform budget honest. Shadow maps are a later-phase item; depth
 * here comes from baked AO + the dither-quantized falloff in the shader.
 */
import { LIGHTING, RENDER } from '../core/Constants.js';
import { RNG } from '../utils/RNG.js';

let nextLightId = 1;

export class Light {
  /**
   * @param {object} def one of LIGHTING.TYPES (or custom {color,intensity,radius})
   * @param {number[]} position [x,y,z]
   * @param {'none'|'slow_pulse'|'rapid'|'occasional_cut'} flickerType
   */
  constructor(def, position, flickerType = 'none') {
    this.id = nextLightId++;
    this.position = position;
    this.color = def.color;
    this.intensity = def.intensity;
    this.radius = def.radius;
    this.flickerType = flickerType;
    this.currentIntensity = def.intensity;
    this.phase = (this.id * 1.7) % (Math.PI * 2);
    // occasional_cut state
    this.lastCut = 0;
    this.cutEnd = 0;
    this.isCut = false;
    this.cutInterval = LIGHTING.FLICKER.CUT_INTERVAL_MIN;
    this.enabled = true;
  }
}

export class LightSystem {
  constructor() {
    /** @type {Map<string, Light[]>} zoneId -> lights */
    this.zoneLights = new Map();
    this.rng = new RNG(0xf11c3e);
    // Scratch uniform arrays reused every draw (no per-frame allocation)
    const n = RENDER.MAX_LIGHTS_PER_DRAW;
    this.uPositions = new Float32Array(n * 3);
    this.uColors = new Float32Array(n * 3);
    this.uIntensities = new Float32Array(n);
    this.uRadii = new Float32Array(n);
  }

  /** @returns {Light} */
  add(zoneId, def, position, flickerType = 'none') {
    const light = new Light(def, position, flickerType);
    light.baseFlicker = flickerType; // remembered so damage can restore it
    if (!this.zoneLights.has(zoneId)) this.zoneLights.set(zoneId, []);
    this.zoneLights.get(zoneId).push(light);
    return light;
  }

  /** All lights, flattened (built lazily; call after the ship is dressed). */
  _allLights() {
    if (!this._flat) {
      this._flat = [];
      for (const ls of this.zoneLights.values()) this._flat.push(...ls);
    }
    return this._flat;
  }

  /**
   * Hull-damage light failure. level 0 = all nominal, 1 = ~70% of ceiling
   * lights dead or stuttering. Deterministic (seeded) so the same damage
   * produces the same outage pattern. Emergency/reactor/screen lights are
   * left alone — those run on separate buses.
   * @param {number} level 0..1 hull damage severity
   */
  setDamageLevel(level) {
    level = Math.max(0, Math.min(1, level));
    const lights = this._allLights();
    const rng = new RNG(0xda3a6e);
    for (const l of lights) {
      // only mains flicker/fail — keep dread lights and glows steady
      const isMain = l.radius >= 4.0 && l.color[2] < 0.7; // warm ceiling tubes
      if (!isMain) continue;
      const roll = rng.next();
      if (roll < level * 0.45) {
        l.enabled = false; // dead
      } else if (roll < level * 0.8) {
        l.enabled = true;
        l.flickerType = 'occasional_cut'; // stuttering
      } else {
        l.enabled = true;
        l.flickerType = l.baseFlicker;
      }
    }
  }

  /** Flicker update — the exact patterns from context/02 §6. */
  update(time) {
    const F = LIGHTING.FLICKER;
    for (const lights of this.zoneLights.values()) {
      for (const light of lights) {
        if (!light.enabled) { light.currentIntensity = 0; continue; }
        switch (light.flickerType) {
          case 'slow_pulse':
            light.currentIntensity = light.intensity *
              (F.SLOW_PULSE_BASE + F.SLOW_PULSE_AMP * Math.sin(time * F.SLOW_PULSE_RATE + light.phase));
            break;
          case 'rapid':
            light.currentIntensity = light.intensity *
              (this.rng.next() > F.RAPID_DROP_CHANCE ? 1.0 : F.RAPID_DROP_LEVEL);
            break;
          case 'occasional_cut':
            if (time - light.lastCut > light.cutInterval) {
              light.isCut = true;
              light.cutEnd = time + F.CUT_DURATION;
              light.lastCut = time;
              light.cutInterval = F.CUT_INTERVAL_MIN + this.rng.next() * F.CUT_INTERVAL_RAND;
            }
            if (light.isCut && time > light.cutEnd) light.isCut = false;
            light.currentIntensity = light.isCut ? 0 : light.intensity;
            break;
          default:
            light.currentIntensity = light.intensity;
        }
      }
    }
  }

  /**
   * Fill the scratch uniform arrays with a zone's lights (plus its neighbours'
   * spill if there is room), strongest first.
   * @returns {number} light count written
   */
  gatherForZone(zoneId, neighbourIds = []) {
    const pool = [];
    const own = this.zoneLights.get(zoneId);
    if (own) pool.push(...own);
    for (const nid of neighbourIds) {
      const nl = this.zoneLights.get(nid);
      if (nl) pool.push(...nl);
    }
    pool.sort((a, b) => b.currentIntensity * b.radius - a.currentIntensity * a.radius);
    const count = Math.min(pool.length, RENDER.MAX_LIGHTS_PER_DRAW);
    for (let i = 0; i < count; i++) {
      const l = pool[i];
      this.uPositions[i * 3] = l.position[0];
      this.uPositions[i * 3 + 1] = l.position[1];
      this.uPositions[i * 3 + 2] = l.position[2];
      this.uColors[i * 3] = l.color[0];
      this.uColors[i * 3 + 1] = l.color[1];
      this.uColors[i * 3 + 2] = l.color[2];
      this.uIntensities[i] = l.currentIntensity;
      this.uRadii[i] = l.radius;
    }
    return count;
  }
}
