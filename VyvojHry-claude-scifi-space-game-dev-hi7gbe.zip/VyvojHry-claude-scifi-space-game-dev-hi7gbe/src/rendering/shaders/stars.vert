#version 300 es
// Star points + dust motes. Positions are direction vectors (skybox stars,
// rendered with a rotation-only view) or ship-local points (dust).
//
// u_bend: gravitational-lens swirl for the warp sequence — (center NDC x,
// center NDC y, strength). Post-projection, each vertex is rotated around the
// bend centre by an angle that grows toward it, so the starfield visibly
// deforms around the collapsing jump singularity. Strength 0 = identity.

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_color;
layout(location = 2) in float a_size;

uniform mat4 u_viewProjection;
uniform vec3 u_bend;

out vec3 v_color;

void main() {
  vec4 p = u_viewProjection * vec4(a_position, 1.0);
  if (u_bend.z > 0.0001 && p.w > 0.0001) {
    vec2 ndc = p.xy / p.w;
    vec2 d = ndc - u_bend.xy;
    float r2 = dot(d, d);
    float ang = u_bend.z / (0.35 + r2 * 2.2); // strongest near the hole
    float c = cos(ang), s = sin(ang);
    vec2 rd = vec2(d.x * c - d.y * s, d.x * s + d.y * c);
    // swirl + a slight inward pull — light dragged around and toward the mass
    vec2 bent = u_bend.xy + rd * (1.0 - 0.35 * u_bend.z / (0.6 + r2 * 3.0));
    p.xy = bent * p.w;
  }
  gl_Position = p;
  gl_PointSize = a_size;
  v_color = a_color;
}
