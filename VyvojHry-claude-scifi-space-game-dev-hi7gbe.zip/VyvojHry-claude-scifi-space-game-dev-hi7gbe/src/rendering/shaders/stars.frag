#version 300 es
// Hard square star/dust points — no glow, no falloff (pixel truth).
precision highp float;

in vec3 v_color;

uniform float u_alpha;

out vec4 fragColor;

void main() {
  fragColor = vec4(v_color, u_alpha);
}
