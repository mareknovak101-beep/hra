#version 300 es
// 2D HUD/UI pass — pixel-space quads (0,0 top-left at 480×270), integer-snapped
// on the CPU side (context/07: pixel alignment rule).

layout(location = 0) in vec2 a_position; // logical pixels
layout(location = 1) in vec2 a_uv;
layout(location = 2) in vec4 a_color;

uniform vec2 u_resolution;

out vec2 v_uv;
out vec4 v_color;

void main() {
  vec2 clip = (a_position / u_resolution) * 2.0 - 1.0;
  gl_Position = vec4(clip.x, -clip.y, 0.0, 1.0);
  v_uv = a_uv;
  v_color = a_color;
}
