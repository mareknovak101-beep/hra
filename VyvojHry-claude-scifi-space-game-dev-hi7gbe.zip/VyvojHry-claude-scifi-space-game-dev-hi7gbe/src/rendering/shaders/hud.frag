#version 300 es
// 2D HUD/UI pass. Samples a single atlas (font glyphs + white block + overlay
// textures); vertex color carries tint and opacity.
precision highp float;

in vec2 v_uv;
in vec4 v_color;

uniform sampler2D u_texture;

out vec4 fragColor;

void main() {
  vec4 tex = texture(u_texture, v_uv);
  fragColor = tex * v_color;
  if (fragColor.a < 0.004) discard;
}
