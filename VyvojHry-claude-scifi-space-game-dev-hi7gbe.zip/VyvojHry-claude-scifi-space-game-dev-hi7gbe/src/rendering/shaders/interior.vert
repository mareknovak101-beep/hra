#version 300 es
// Interior geometry pass — shared by rooms, corridors, props and doors.
// Attribute/uniform contract: context/02 §4 (+ tangent for normal mapping).

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec2 a_uv;
layout(location = 3) in float a_layer;    // texture-array layer index
layout(location = 4) in float a_ao;       // baked per-vertex ambient occlusion
layout(location = 5) in float a_emissive; // 1 = self-lit surface (screens, glow slits)
layout(location = 6) in vec3 a_tangent;   // surface tangent (u direction)

uniform mat4 u_viewProjection;
uniform mat4 u_model;

out vec3 v_worldPos;
out vec3 v_normal;
out vec3 v_tangent;
out vec3 v_bitangent;
out vec2 v_uv;
flat out float v_layer;
out float v_ao;
out float v_emissive;

void main() {
  vec4 wp = u_model * vec4(a_position, 1.0);
  v_worldPos = wp.xyz;
  mat3 nm = mat3(u_model);
  v_normal = nm * a_normal;
  v_tangent = nm * a_tangent;
  v_bitangent = cross(v_normal, v_tangent);
  v_uv = a_uv;
  v_layer = a_layer;
  v_ao = a_ao;
  v_emissive = a_emissive;
  gl_Position = u_viewProjection * wp;
}
