#version 300 es
// Interior lighting pass. Per-texel normal mapping gives painted surfaces real
// relief; a quantized specular term adds the "plastic" pop the flat lighting
// lacked. All light falloff is still quantized through the 4×4 Bayer matrix
// (context/01 §3) so shading reads as ordered dithering, never a smooth
// gradient (pillar 3). Rendered at the true 480×270 target.
precision highp float;
precision highp sampler2DArray;

in vec3 v_worldPos;
in vec3 v_normal;
in vec3 v_tangent;
in vec3 v_bitangent;
in vec2 v_uv;
flat in float v_layer;
in float v_ao;
in float v_emissive;

uniform sampler2DArray u_atlas;
uniform sampler2DArray u_normalAtlas;
uniform float u_time;
uniform vec3 u_ambient;
uniform int u_lightCount;
uniform vec3 u_lightPositions[8];
uniform vec3 u_lightColors[8];
uniform float u_lightIntensities[8];
uniform float u_lightRadii[8];

// Helmet flashlight (spot). Params: x=intensity, y=range, z=cos(inner), w=cos(outer)
uniform vec3 u_playerLightPos;
uniform vec3 u_playerLightDir;
uniform vec3 u_playerLightColor;
uniform vec4 u_playerLightParams;
uniform float u_playerLightOn;

// Dither controls: x=light levels, y=darken range (m), z=darken floor
uniform vec3 u_ditherParams;
// Relief controls: x=spec power, y=spec strength
uniform vec2 u_reliefParams;
// Player brightness setting (Settings slider); 1.0 = default
uniform float u_brightness;
// Diegetic CRT pass: x = first screen atlas layer, y = last (inclusive),
// z = master enable (0/1, follows the CRT SCREEN setting). Screens registered
// consecutively in TextureFactory, so a contiguous range identifies them.
uniform vec3 u_screenCrt;

out vec4 fragColor;

// 4×4 Bayer matrix — same standard pattern as context/01 §3 / Constants.BAYER_4X4.
const float BAYER[16] = float[16](
   0.0,  8.0,  2.0, 10.0,
  12.0,  4.0, 14.0,  6.0,
   3.0, 11.0,  1.0,  9.0,
  15.0,  7.0, 13.0,  5.0
);

float bayerThreshold(vec2 fragCoord) {
  int x = int(mod(fragCoord.x, 4.0));
  int y = int(mod(fragCoord.y, 4.0));
  return (BAYER[y * 4 + x] + 0.5) / 16.0 - 0.5; // centered on 0
}

// -- de-tiling ---------------------------------------------------------------
// Interior surfaces repeat one 2m texture tile across a whole wall, so however
// good the tile is, the wall reads as a regular grid of identical squares. Two
// cheap variations break that, and both are folded into `light` BEFORE the level
// quantizer below, so they come out as discrete shade bands rather than the
// smooth gradients pillar 3 bans.
float h21(vec2 p) {
  p = fract(p * vec2(127.1, 311.7));
  p += dot(p, p + 34.23);
  return fract(p.x * p.y);
}

/** Value noise. Smooth by itself; the light quantizer steps it afterwards. */
float vnoise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  float a = h21(i), b = h21(i + vec2(1.0, 0.0));
  float c = h21(i + vec2(0.0, 1.0)), d = h21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

void main() {
  vec3 albedo = texture(u_atlas, vec3(v_uv, v_layer)).rgb;

  // tangent-space normal -> world space
  vec3 nTex = texture(u_normalAtlas, vec3(v_uv, v_layer)).xyz * 2.0 - 1.0;
  vec3 T = normalize(v_tangent);
  vec3 B = normalize(v_bitangent);
  vec3 Ngeo = normalize(v_normal);
  vec3 n = normalize(T * nTex.x + B * nTex.y + Ngeo * nTex.z);

  vec3 viewDir = normalize(u_playerLightPos - v_worldPos);

  vec3 light = u_ambient;
  float spec = 0.0;

  for (int i = 0; i < 8; i++) {
    if (i >= u_lightCount) break;
    vec3 L = u_lightPositions[i] - v_worldPos;
    float d = length(L);
    vec3 Ld = L / max(d, 1e-4);
    float att = clamp(1.0 - d / u_lightRadii[i], 0.0, 1.0);
    att *= att;
    float ndl = max(dot(n, Ld), 0.0);
    light += u_lightColors[i] * (u_lightIntensities[i] * att * ndl);
    if (ndl > 0.0) {
      vec3 h = normalize(Ld + viewDir);
      spec += u_lightIntensities[i] * att * pow(max(dot(n, h), 0.0), u_reliefParams.x);
    }
  }

  if (u_playerLightOn > 0.5) {
    vec3 L = u_playerLightPos - v_worldPos;
    float d = length(L);
    vec3 Ld = L / max(d, 1e-4);
    float att = clamp(1.0 - d / u_playerLightParams.y, 0.0, 1.0);
    att *= att;
    float cosA = dot(-Ld, normalize(u_playerLightDir));
    float spot = smoothstep(u_playerLightParams.w, u_playerLightParams.z, cosA);
    float ndl = max(dot(n, Ld), 0.0);
    light += u_playerLightColor * (u_playerLightParams.x * att * spot * ndl);
    if (ndl > 0.0) {
      vec3 h = normalize(Ld + viewDir);
      spec += u_playerLightParams.x * att * spot * pow(max(dot(n, h), 0.0), u_reliefParams.x);
    }
  }

  light *= v_ao;

  // Distance falloff toward (not below) a floor factor — depth cue, mood.
  float viewDist = length(u_playerLightPos - v_worldPos);
  float darken = max(1.0 - viewDist / u_ditherParams.y, u_ditherParams.z);
  light *= darken;

  // -- break the tile grid ----------------------------------------------------
  // Both terms below multiply into `light` so the quantizer downstream turns
  // them into discrete shade bands. Nothing here touches the albedo, so no
  // stencil, serial or screen glyph is ever mirrored or recoloured.
  //
  // 1. A per-tile step. Each 2m tile of a surface picks one of four brightness
  //    levels from a hash of its integer UV cell, so adjacent copies of the same
  //    texture no longer match — the single strongest cue that a wall is one
  //    image repeated.
  float tileStep = floor(h21(floor(v_uv) + v_layer * 3.77) * 4.0) / 3.0;
  light *= 0.92 + 0.16 * tileStep;

  // 2. Irregular staining in WORLD space, deliberately uncorrelated with the
  //    tile grid: two octaves at ~5m and ~1.6m across whichever plane the
  //    surface faces. This is what stops the eye finding a lattice at all —
  //    a large organic light/dark drift runs straight across tile boundaries.
  vec3 an = abs(Ngeo);
  vec2 wp = an.y > max(an.x, an.z) ? v_worldPos.xz
          : an.x > an.z            ? v_worldPos.zy
                                   : v_worldPos.xy;
  float grime = vnoise(wp * 0.21) * 0.62 + vnoise(wp * 0.63) * 0.38;
  // Centred on 1.0 (value noise averages 0.5), so this redistributes light
  // instead of removing it — the first attempt used 0.80 + 0.30·grime, which
  // means 0.95, and visibly dimmed every wall in the ship.
  light *= 0.84 + 0.32 * grime;

  // Smooth banded lighting (owner request: no grainy dither dots). Many, evenly
  // stepped levels with NO Bayer threshold read as a smooth shade gradient over
  // the flat-colour texels rather than a checkerboard.
  float levels = u_ditherParams.x;
  light = clamp(light, 0.0, 1.35);
  light = floor(light * levels + 0.5) / levels;
  light = max(light, 0.0);

  vec3 lit = albedo * light;

  // Specular (off by default now — SPEC_STRENGTH 0) but kept for completeness.
  float sq = clamp(spec * u_reliefParams.y * v_ao * darken, 0.0, 1.0);
  sq = floor(sq * levels + 0.5) / levels;
  lit += vec3(sq) * (0.6 + 0.4 * albedo);

  lit *= u_brightness; // player Settings brightness
  lit = mix(lit, albedo * max(u_brightness, 1.0), v_emissive); // emissive ignores lighting

  // -- diegetic CRT terminals -------------------------------------------------
  // A real monitor in the room, not a filter over the camera: everything here
  // works in the screen's own UV space, so the scanlines and the refresh roll
  // are painted ON the glass and stay put as the player walks past. Only the
  // console/terminal atlas layers get it — lamps and light strips are emissive
  // too and must stay clean.
  if (u_screenCrt.z > 0.5 && v_layer >= u_screenCrt.x - 0.5 && v_layer <= u_screenCrt.y + 0.5) {
    // per-screen phase so a bank of monitors doesn't pulse in lockstep
    float id = floor(v_worldPos.x * 3.1) + floor(v_worldPos.z * 2.7) + v_layer * 7.0;

    // Interior v_uv is a PLANAR WORLD-SPACE projection scaled per surface, not a
    // normalized 0..1 rect — it runs to whatever the geometry's extent happens
    // to be. Everything below therefore works on the wrapped coordinate. Using
    // raw v_uv for the vignette drove `1.0 - dot(v_uv - 0.5, ...)` far negative
    // on every off-origin screen, and the negative multiply turned each one into
    // a pure black rectangle — the big dead slabs in the cockpit, med bay,
    // computer core and engine room.
    vec2 suv = fract(v_uv);

    // aperture-grille scanlines along the glass (32 lines)
    float scan = mod(floor(suv.y * 32.0), 2.0) < 1.0 ? 1.0 : 0.74;

    // vertical refresh bar rolling down the tube — wide and bright enough to
    // actually read as a sweeping band on a tired monitor
    float roll = fract(suv.y - u_time * 0.35 + id * 0.13);
    float bar = smoothstep(0.72, 1.0, roll) * 0.9;

    // mains flicker: slow enough to perceive (a fast wobble averages out to a
    // steady glow), plus the odd dropped frame from tired hardware
    float flick = 0.86 + 0.14 * sin(u_time * 3.7 + id);
    float glitch = step(0.985, fract(sin(floor(u_time * 5.0) + id) * 43758.5453)) * 0.55;

    // tube vignette: the corners of the glass fall off. dot() maxes at 0.5 on a
    // wrapped coordinate, so this can never go negative.
    vec2 sc = suv - 0.5;
    float vig = 1.0 - dot(sc, sc) * 0.85;

    // Phosphor drive FIRST. The scanline/flicker/vignette terms all multiply
    // downward, which left screens ~25% dimmer than before — backwards for a
    // tube that's supposed to emit. Pre-boosting means the lit rows come out
    // brighter than the flat texture and the dark rows carry the scanline
    // contrast, so the glass glows instead of going grey.
    lit *= 1.55;
    lit *= scan * flick * vig;
    lit += lit * bar;          // the refresh band brightens what it crosses
    lit *= (1.0 - glitch);     // brief dropout
  }

  fragColor = vec4(lit, 1.0);
}
