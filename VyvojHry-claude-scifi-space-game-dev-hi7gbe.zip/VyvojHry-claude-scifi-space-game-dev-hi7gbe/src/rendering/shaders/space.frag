#version 300 es
// Space-object shading. Lit objects (planets, hulls) get a single sun
// direction with Bayer-quantized falloff — the hard pixel terminator from
// context/01 §9. Unlit objects (sun, nebulae) show their texture straight.
precision highp float;

in vec3 v_normal;
in vec2 v_uv;
in vec3 v_worldPos;

uniform sampler2D u_texture;
uniform float u_lit;       // 0 = emissive/billboard, 1 = sun-lit
/**
 * Hull livery. Multiplied into the albedo BEFORE lighting, so a repaint reads
 * as paint on the plating rather than as a coloured light shining on it — the
 * wear, the panel edges and the value-stepped tiles all survive and simply come
 * through in the new colour. (1,1,1) is the factory finish and is what every
 * other object drawn through this shader passes.
 */
uniform vec3 u_tint;
uniform vec3 u_lightDir;   // direction TOWARD the surface (from the sun)
uniform float u_lightLevels;
uniform float u_fill;      // minimum light on the shadowed side (fill)
// Quadratic limb-darkening coefficients (u1, u2). Zero disables the law and the
// surface falls back to plain Lambert, which is what planets want.
uniform vec2 u_limb;
/**
 * DIFFERENTIAL ROTATION, in radians of accumulated equatorial rotation.
 *
 * A star is a fluid and does not turn as a solid body: the Sun's equator comes
 * round in about 25 days against 34 at the poles, omega(lat) = A - B*sin^2(lat),
 * and that shear is what winds the magnetic field up in the first place. Applied
 * here as a latitude-dependent shift of the sampling longitude, which needs the
 * texture to REPEAT in u (main.js builds star surfaces with repeat:true) and has
 * no seam because an equirectangular sheet is periodic in longitude anyway.
 *
 * Zero for planets, which really are close enough to rigid.
 */
uniform float u_diffRot;
uniform vec3 u_camPos;     // camera position (same frame as v_worldPos)
uniform vec3 u_atmo;       // atmosphere rim colour; (0,0,0) disables the rim
uniform float u_tileVary;  // >0.5: break up tiled hull plating (see below)

out vec4 fragColor;

const float BAYER[16] = float[16](
   0.0,  8.0,  2.0, 10.0,
  12.0,  4.0, 14.0,  6.0,
   3.0, 11.0,  1.0,  9.0,
  15.0,  7.0, 13.0,  5.0
);

float bayerThreshold(vec2 fragCoord) {
  int x = int(mod(fragCoord.x, 4.0));
  int y = int(mod(fragCoord.y, 4.0));
  return (BAYER[y * 4 + x] + 0.5) / 16.0 - 0.5;
}

/** Cheap 2D value hash — stable per integer cell, no texture lookup. */
float cellHash(vec2 c, float k) {
  return fract(sin(dot(c, vec2(127.1, 311.7)) + k) * 43758.5453);
}

void main() {
  // Hull plating is a 128px tile addressed by planar model UVs, so a 90-unit
  // ship shows it a dozen times over and the eye locks onto the grid. Per TILE
  // we mirror the panel content on a coin flip and step its value: the seam
  // lines stay on the grid — that IS what plating looks like — while no two
  // adjacent panels carry the same wear, streaks or stencil.
  vec2 uv = v_uv;
  float plate = 1.0;
  if (u_tileVary > 0.5) {
    vec2 cell = floor(uv);
    vec2 f = fract(uv);
    if (cellHash(cell, 0.0) > 0.5) f.x = 1.0 - f.x;
    if (cellHash(cell, 7.3) > 0.5) f.y = 1.0 - f.y;
    uv = f;
    plate = 0.82 + 0.34 * cellHash(cell, 19.1);
  }
  if (abs(u_diffRot) > 0.0001) {
    // v runs 0 (north pole) .. 1 (south); sin(pi*v) peaks at the equator, so
    // this is 1.0 there and falls to 0.65 at the poles — the equator leads
    float band = sin(uv.y * 3.14159265);
    uv.x += u_diffRot * (0.65 + 0.35 * band * band);
  }
  vec4 tex = texture(u_texture, uv);
  if (tex.a < 0.004) discard;
  tex.rgb *= plate;
  tex.rgb *= u_tint;

  if (u_lit > 0.5) {
    vec3 n = normalize(v_normal);
    float ndl = max(dot(n, -u_lightDir), 0.0);
    // Smooth banded day/night (no Bayer grain): a clean terminator that tracks
    // the star. As a body spins, its surface rotates through this star-fixed
    // shadow — realistic dynamic day/night.
    float light;
    if (u_limb.x > 0.001) {
      // LIMB DARKENING. A star is not a Lambertian ball: looking at the centre
      // of the disc you see straight down into hot, deep gas, while at the limb
      // your line of sight grazes through cooler upper layers, so the edge is
      // genuinely dimmer AND redder. The standard model is quadratic in the
      // cosine of the viewing angle,
      //     I(mu)/I(1) = 1 - u1*(1-mu) - u2*(1-mu)^2
      // and since the star is lit FROM THE EYE (see SpaceRenderer._drawStar),
      // ndl is exactly that cosine. Plain Lambert falls off far too fast and
      // made every star read as a shaded sphere rather than a self-luminous one.
      float m1 = 1.0 - ndl;
      float ld = 1.0 - u_limb.x * m1 - u_limb.y * m1 * m1;
      light = floor(max(ld, 0.0) * u_lightLevels + 0.5) / u_lightLevels;
    } else {
      light = floor(ndl * u_lightLevels + 0.5) / u_lightLevels;
    }
    light = max(light, u_fill); // fill so the shadowed side still reads
    vec3 col = tex.rgb * light;
    // atmosphere: a rim glow on the limb, stronger on the sunlit side, so a
    // planet reads as a lit sphere instead of a flat disc. When the body sits
    // BETWEEN the camera and the star (an eclipse silhouette — night side facing
    // us against the bright corona) the limb gets a strong forward-scattered
    // backlight ring, so it reads as a world eclipsing the sun, never a black
    // hole punched in the view.
    if (u_atmo.r + u_atmo.g + u_atmo.b > 0.001) {
      vec3 vd = normalize(u_camPos - v_worldPos);
      float rim = pow(1.0 - max(dot(n, vd), 0.0), 3.0);
      float dayBias = 0.35 + 0.65 * ndl;
      float backlit = clamp(dot(vd, u_lightDir), 0.0, 1.0); // 1 = sun dead behind
      float glow = rim * dayBias + rim * rim * backlit * 1.7;
      float rq = floor(glow * u_lightLevels + 0.5) / u_lightLevels;
      col += u_atmo * rq;
    }
    fragColor = vec4(col, tex.a);
  } else {
    fragColor = tex;
  }
}
