/**
 * TextureFactory — every texture in the game, generated at startup.
 *
 * Rules enforced here (context/01 §3–4):
 * - no flat single-color surfaces: every generator layers ≥3–4 shades
 * - shading via 4×4 Bayer ordered dithering only, never smooth gradients
 * - each material family gets its own dither *pattern* (banding, blotch,
 *   cross-hatch, checkerboard, mottling)
 * - wear obeys gravity: rust streaks run downward from their source
 * - every prop surface carries 2–3 of: bolts, seams, labels, scratches, grime
 */
import { PALETTE, BAYER_4X4, RENDER, COMPANY_NAME } from '../core/Constants.js';
import { hexToRgb, shade, warmShade, mixRgb } from '../utils/ColorUtils.js';
import { RNG } from '../utils/RNG.js';
import { fbm2, valueNoise2 } from '../utils/NoiseUtils.js';
import { FONT_FACES } from './PixelFont.js';
import { planetSurface, PLANET_SPEC, BIOME, GW, GH } from '../data/Planetology.js';

/**
 * TWO grids, and the distinction runs through this whole file.
 *
 * `S` is the DESIGN grid (64). Every coordinate in every generator below is on
 * it: seam pitches, bolt rows, `insetPanel` rects, stencil positions. It has not
 * changed and must not — the numbers are hand-tuned against it.
 *
 * `OUT` is what the GPU receives (128). `TX` output texels are written per design
 * texel, so a seam authored at design y=15 lands at the same place on the wall and
 * covers the same physical width as before.
 *
 * The gain is that everything CONTINUOUS — noise fills, grain, speckle, scratches,
 * rust, edge AO — is evaluated at the OUTPUT rate instead of the design rate.
 * fbm and value noise are continuous functions, so sampling them at TX× density
 * over the same region resolves genuinely more structure rather than interpolating
 * the coarse version. Same move as the celestial surfaces at 512×256.
 */
const S = RENDER.TEXTURE_DESIGN;
const OUT = RENDER.TEXTURE_SIZE;
const TX = Math.max(1, Math.round(OUT / S));

// Clean single-colour texels (no Bayer grain, no highlighted borders) drawn across
// MANY ramp shades so surfaces read as detailed, smoothly-graded pixel art rather
// than flat 3-colour blocks. The "chunky pixel" block size is now TX by
// construction — one design texel — so the old PIXEL_BLOCK knob is gone.
const RAMP_STEPS = 14;

/** Bayer threshold in (0,1) for ordered dithering. */
const bayerT = (x, y) => (BAYER_4X4[(y & 3) * 4 + (x & 3)] + 0.5) / 16;

/** Interpolate a colour ramp (dark→light) up to `steps` smooth shades. */
function expandRamp(ramp, steps = RAMP_STEPS) {
  if (ramp.length >= steps) return ramp;
  const segs = ramp.length - 1;
  const out = [];
  for (let i = 0; i < steps; i++) {
    const t = (i / (steps - 1)) * segs;
    const lo = Math.min(Math.floor(t), segs - 1);
    out.push(mixRgb(ramp[lo], ramp[lo + 1], t - lo));
  }
  return out;
}

/** Small paint surface wrapping an RGBA buffer + an explicit relief channel. */
/**
 * Painter — draws in DESIGN-grid coordinates, writes OUT×OUT texels.
 *
 * Two families of method, and picking the wrong one is the mistake to watch for:
 *
 * - **Structural** (`px`, `addH`, `get`, `rect`, `outline`, `insetPanel`,
 *   `raisedTrim`, `bolt`, `text`) take design coordinates. `px` fills a whole
 *   TX×TX block, so a feature keeps the physical size it had at 64².
 * - **Fine** (`fpx`, `faddH`, `fget`, and the wear methods built on them —
 *   `speckle`, `scratch`, `rustStreak`, `darkenEdges`) work in output texels.
 *   These are where the extra resolution actually shows up.
 *
 * `ditherFill`/`ditherOver` bridge the two: their rect arguments are design
 * coordinates (so existing calls are unchanged) but they iterate output texels and
 * hand `fn` FRACTIONAL design coordinates. Every generator's noise frequency
 * constant therefore keeps producing the same feature size while resolving TX×
 * finer.
 */
class Painter {
  constructor(rng) {
    this.rng = rng;
    this.size = OUT;
    this.data = new Uint8Array(OUT * OUT * 4);
    // explicit surface height painted by structural features (bolts up,
    // seams/grout down); combined with a luminance assist into normal maps
    this.height = new Float32Array(OUT * OUT);
  }

  // -- output-texel primitives (fine detail) ---------------------------------

  /** Single OUTPUT texel. */
  fpx(fx, fy, rgb) {
    if (fx < 0 || fy < 0 || fx >= OUT || fy >= OUT) return;
    const i = (fy * OUT + fx) * 4;
    this.data[i] = rgb[0]; this.data[i + 1] = rgb[1]; this.data[i + 2] = rgb[2]; this.data[i + 3] = 255;
  }

  /** Relief at one OUTPUT texel (positive = raised, negative = recessed). */
  faddH(fx, fy, dh) {
    if (fx < 0 || fy < 0 || fx >= OUT || fy >= OUT) return;
    this.height[fy * OUT + fx] += dh;
  }

  /** Read one OUTPUT texel, wrapping (surfaces tile). */
  fget(fx, fy) {
    const i = (((fy % OUT) + OUT) % OUT * OUT + ((fx % OUT) + OUT) % OUT) * 4;
    return [this.data[i], this.data[i + 1], this.data[i + 2]];
  }

  // -- design-grid primitives (structure) ------------------------------------

  /** One DESIGN texel = a TX×TX block of output texels. */
  px(x, y, rgb) {
    if (x < 0 || y < 0 || x >= S || y >= S) return;
    const bx = x * TX, by = y * TX;
    for (let oy = 0; oy < TX; oy++) {
      for (let ox = 0; ox < TX; ox++) {
        const i = ((by + oy) * OUT + bx + ox) * 4;
        this.data[i] = rgb[0]; this.data[i + 1] = rgb[1]; this.data[i + 2] = rgb[2]; this.data[i + 3] = 255;
      }
    }
  }

  /** Add relief across a design texel's whole block. */
  addH(x, y, dh) {
    if (x < 0 || y < 0 || x >= S || y >= S) return;
    const bx = x * TX, by = y * TX;
    for (let oy = 0; oy < TX; oy++) {
      for (let ox = 0; ox < TX; ox++) this.height[(by + oy) * OUT + bx + ox] += dh;
    }
  }

  get(x, y) {
    return this.fget((((x % S) + S) % S) * TX, (((y % S) + S) % S) * TX);
  }

  /** Stamp bitmap text at design coordinates, scaled to the output grid. */
  text(font, x, y, str, rgb, face) {
    font.stamp(this.data, OUT, OUT, x * TX, y * TX, str, rgb, face, TX);
  }

  /**
   * Flat fill: fn(x,y) → [0,1] is evaluated per OUTPUT texel at fractional
   * DESIGN coordinates and snapped to the nearest shade of an expanded ramp. The
   * surface still reads as flat-colour pixel art with smooth shade steps; there
   * is simply TX× more of it. Rect args are design coordinates.
   * @param {number[][]} ramp array of [r,g,b], dark → light
   */
  ditherFill(ramp, fn, x0 = 0, y0 = 0, w = S, h = S) {
    const smooth = expandRamp(ramp);
    const n = smooth.length - 1;
    const fx0 = x0 * TX, fy0 = y0 * TX, fw = w * TX, fh = h * TX;
    for (let fy = fy0; fy < fy0 + fh; fy++) {
      const dy = fy / TX;
      for (let fx = fx0; fx < fx0 + fw; fx++) {
        const v = Math.min(1, Math.max(0, fn(fx / TX, dy)));
        this.fpx(fx, fy, smooth[Math.min(n, Math.round(v * n))]);
      }
    }
  }

  /** Coverage overlay: fn>0.5 paints a solid output texel. Design-coord rect. */
  ditherOver(rgb, fn, x0 = 0, y0 = 0, w = S, h = S) {
    const fx0 = x0 * TX, fy0 = y0 * TX, fw = w * TX, fh = h * TX;
    for (let fy = fy0; fy < fy0 + fh; fy++) {
      const dy = fy / TX;
      for (let fx = fx0; fx < fx0 + fw; fx++) {
        if (fn(fx / TX, dy) <= 0.5) continue;
        this.fpx(fx, fy, rgb);
      }
    }
  }

  rect(x0, y0, w, h, rgb) {
    for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) this.px(x, y, rgb);
  }

  outline(x0, y0, w, h, rgb) {
    for (let x = x0; x < x0 + w; x++) {
      this.px(x, y0, rgb); this.px(x, y0 + h - 1, rgb);
      this.addH(x, y0, -0.2); this.addH(x, y0 + h - 1, -0.2);
    }
    for (let y = y0; y < y0 + h; y++) {
      this.px(x0, y, rgb); this.px(x0 + w - 1, y, rgb);
      this.addH(x0, y, -0.2); this.addH(x0 + w - 1, y, -0.2);
    }
  }

  /**
   * Bolt head, 2 design texels across — so 2·TX output texels, which at TX=2 is
   * room for a real fastener instead of a 2×2 checker: a lit crown, a mid ring
   * and a hard drop shadow on the lower right.
   */
  bolt(x, y) {
    const base = this.get(x, y);
    const crown = shade(base, 1.55), mid = shade(base, 1.05);
    const lip = shade(base, 0.72), shadow = shade(base, 0.42);
    const n = 2 * TX; // side length in output texels
    const bx = x * TX, by = y * TX;
    const c = (n - 1) / 2;
    for (let oy = 0; oy < n; oy++) {
      for (let ox = 0; ox < n; ox++) {
        // radial position picks the ring; the diagonal picks which side is lit
        const d = Math.max(Math.abs(ox - c), Math.abs(oy - c)) / (c + 0.001);
        const lit = ox + oy < n - 1;
        const rgb = d > 0.82 ? (lit ? lip : shadow) : lit ? crown : mid;
        this.fpx(bx + ox, by + oy, rgb);
        this.faddH(bx + ox, by + oy, d > 0.82 ? 0.28 : 0.55);
      }
    }
  }

  /**
   * Rust streak trailing DOWNWARD from (x,y) — gravity matters. Runs at OUTPUT
   * resolution, so the corrosion is a finer, more ragged trail than the 3-texel
   * smear it was on the design grid; args stay in design coordinates.
   */
  rustStreak(x, y, len, strength = 0.8) {
    const rust = [hexToRgb(PALETTE.RUST[0]), hexToRgb(PALETTE.RUST[1])];
    const half = Math.max(1, TX); // trail half-width in output texels
    let cx = x * TX;
    const fy0 = y * TX, flen = len * TX;
    for (let dy = 0; dy < flen; dy++) {
      const fall = strength * (1 - dy / flen);
      const yy = fy0 + dy;
      for (let dx = -half; dx <= half; dx++) {
        const cover = fall * (dx === 0 ? 1 : 0.45 * (1 - (Math.abs(dx) - 1) / half));
        if (cover > bayerT(cx + dx, yy)) {
          this.fpx(cx + dx, yy, rust[(cx + dx + yy) & 1]);
          this.faddH(cx + dx, yy, -0.08); // corrosion eats into the surface
        }
      }
      if (this.rng.chance(0.2 / TX)) cx += this.rng.chance(0.5) ? 1 : -1;
    }
  }

  /** Hairline diagonal scratch, one OUTPUT texel wide. Design-coord args. */
  scratch(x0, y0, len, dir = 1) {
    const fx0 = x0 * TX, fy0 = y0 * TX, flen = len * TX;
    for (let i = 0; i < flen; i++) {
      const fx = fx0 + i;
      const fy = fy0 + Math.round(i * 0.4) * dir;
      this.fpx(fx, fy, shade(this.fget(fx, fy), 1.6));
    }
  }

  /**
   * A machined recessed sub-panel: the field sinks, a beveled rim catches the
   * light on the top/left and shadows the bottom/right, and optional corner
   * bolts sit proud. This is the workhorse for "depth per part" — it turns a
   * flat plate into a real inset surface under the normal-mapped lamp.
   */
  insetPanel(x0, y0, w, h, opts = {}) {
    const depth = opts.depth ?? 0.7;
    const fieldMul = opts.fieldMul ?? 0.86; // recessed field reads darker
    const bolts = opts.bolts ?? true;
    for (let y = y0; y < y0 + h; y++) {
      for (let x = x0; x < x0 + w; x++) {
        const edge = x === x0 || x === x0 + w - 1 || y === y0 || y === y0 + h - 1;
        const inner = x === x0 + 1 || x === x0 + w - 2 || y === y0 + 1 || y === y0 + h - 2;
        if (edge) {
          // top/left rim raised & lit, bottom/right rim shadowed (chamfer)
          const lit = x === x0 || y === y0;
          this.px(x, y, shade(this.get(x, y), lit ? 1.32 : 0.5));
          this.addH(x, y, lit ? depth : -depth);
        } else {
          this.px(x, y, shade(this.get(x, y), inner ? 0.72 : fieldMul));
          this.addH(x, y, -depth * (inner ? 0.9 : 0.55)); // field sits recessed
        }
      }
    }
    if (bolts) {
      this.bolt(x0 + 2, y0 + 2); this.bolt(x0 + w - 4, y0 + 2);
      this.bolt(x0 + 2, y0 + h - 4); this.bolt(x0 + w - 4, y0 + h - 4);
    }
  }

  /** A thin proud frame standing off the surface (panel dividers, trim). */
  raisedTrim(x0, y0, w, h, rgb, dh = 0.55) {
    for (let x = x0; x < x0 + w; x++) {
      this.px(x, y0, shade(rgb, 1.25)); this.px(x, y0 + h - 1, shade(rgb, 0.7));
      this.addH(x, y0, dh); this.addH(x, y0 + h - 1, dh);
    }
    for (let y = y0; y < y0 + h; y++) {
      this.px(x0, y, shade(rgb, 1.25)); this.px(x0 + w - 1, y, shade(rgb, 0.7));
      this.addH(x0, y, dh); this.addH(x0 + w - 1, y, dh);
    }
  }

  /**
   * Sparse single-colour micro-wear: nudges existing texels darker/lighter with
   * NO contrasting borders, so surfaces gain material grain and read as heavily
   * pixelated without the "field of dots" the owner rejected.
   */
  /**
   * Sparse micro-wear at OUTPUT resolution: nudges existing texels darker/lighter
   * with NO contrasting borders. The per-texel probability is unchanged, so total
   * coverage per unit area holds while each fleck is TX× smaller — which is the
   * whole point. This is the layer that reads as "material", and it is now grain
   * rather than dots.
   */
  speckle(density = 0.06, seed = 0) {
    const r = this.rng;
    for (let fy = 0; fy < OUT; fy++) {
      for (let fx = 0; fx < OUT; fx++) {
        if (r.next() > density) continue;
        const dark = ((fx * 7 + fy * 13 + seed) & 3) !== 0;
        this.fpx(fx, fy, shade(this.fget(fx, fy), dark ? 0.82 : 1.16));
        this.faddH(fx, fy, dark ? -0.12 : 0.1);
      }
    }
  }

  /**
   * Darken a border ring — baked pseudo-AO (context/01 §3 rule 4). Beveled.
   * `px` is a DESIGN-texel width so callers keep their numbers; the falloff is
   * evaluated per output texel, so the bevel gains intermediate steps.
   */
  darkenEdges(px = 2, factor = 0.72) {
    const fpx = px * TX;
    for (let fy = 0; fy < OUT; fy++) {
      for (let fx = 0; fx < OUT; fx++) {
        const d = Math.min(fx, fy, OUT - 1 - fx, OUT - 1 - fy);
        if (d < fpx) {
          const f = factor + (1 - factor) * (d / fpx);
          if (1 - f > bayerT(fx, fy) * 0.5) this.fpx(fx, fy, shade(this.fget(fx, fy), f));
          this.faddH(fx, fy, -0.25 * (1 - d / fpx));
        }
      }
    }
  }

  // -- fine detail layers ------------------------------------------------------
  //
  // THE RULE THESE ENCODE, learned the hard way across two sessions:
  //
  //   Detail does not cause a visible repeat. FEW, LARGE, HIGH-CONTRAST details
  //   cause a visible repeat.
  //
  // A tiling texture that carries one bright outlined hatch, one stencil and one
  // bold scratch turns a wall into wallpaper, because the eye finds those three
  // marks and counts them. The same texture carrying two hundred rivets, weld
  // spatter, chipped paint and hairline scoring reads as *material* — no single
  // mark is findable, so there is nothing to count. Stripping detail to kill the
  // repeat (which is what the previous pass did) fixes the pattern and empties
  // the ship; the answer is to go the other way and make the detail dense, small
  // and low-contrast.
  //
  // Everything below therefore works in OUTPUT texels, where at TEXTURE_SIZE 256
  // over a 2m tile one texel is ~8mm — small enough that hundreds of marks read
  // as surface rather than as features. All of them write the height field too,
  // because depth is what the normal-mapped lighting turns into real shading.

  /**
   * Rolled/cast grain over the whole surface — the base material layer.
   * Anisotropic by default (`ax` > `ay` stretches it horizontally) because
   * rolled plate has a grain direction, and a directionless mottle reads as
   * noise rather than metal.
   */
  microGrain(amount = 0.06, seed = 0, ax = 1.4, ay = 0.35) {
    for (let fy = 0; fy < OUT; fy++) {
      for (let fx = 0; fx < OUT; fx++) {
        const v = valueNoise2(fx * 0.5 * ax, fy * 0.5 * ay, seed)
          + 0.5 * valueNoise2(fx * 1.3 * ax, fy * 1.3 * ay, seed + 7);
        const k = 1 + (v / 1.5 - 0.5) * 2 * amount;
        this.fpx(fx, fy, shade(this.fget(fx, fy), k));
        this.faddH(fx, fy, (v / 1.5 - 0.5) * 0.14);
      }
    }
  }

  /**
   * Raised weld bead along a line, with an output-scale wobble and a heat-affected
   * darkening either side. Welds are the cheapest possible "this was fabricated,
   * not printed" cue and they follow structure the eye already accepts.
   * Design coordinates in, output-resolution bead out.
   */
  weldBead(x0, y0, x1, y1, seed = 0, w = 1.2) {
    const fx0 = x0 * TX, fy0 = y0 * TX, fx1 = x1 * TX, fy1 = y1 * TX;
    const steps = Math.max(Math.abs(fx1 - fx0), Math.abs(fy1 - fy0));
    if (steps <= 0) return;
    const nx = -(fy1 - fy0) / steps, ny = (fx1 - fx0) / steps; // unit normal
    const fw = w * TX;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const cx = fx0 + (fx1 - fx0) * t, cy = fy0 + (fy1 - fy0) * t;
      // the bead wanders and its width pulses — a straight even bead is a ruler
      const wob = (valueNoise2(i * 0.35, seed * 0.7, seed) - 0.5) * fw * 0.9;
      const half = fw * (0.55 + 0.45 * valueNoise2(i * 0.22, seed * 1.3, seed + 3));
      for (let o = -half; o <= half; o += 1) {
        const fx = Math.round(cx + nx * (o + wob)), fy = Math.round(cy + ny * (o + wob));
        const r = Math.abs(o) / (half + 0.01);
        const base = this.fget(fx, fy);
        // crest lit, flanks dark — a rounded bead, not a painted stripe
        this.fpx(fx, fy, shade(base, r < 0.45 ? 1.18 : r < 0.8 ? 1.02 : 0.86));
        this.faddH(fx, fy, 0.5 * (1 - r * r));
      }
      // heat scorch either side of the bead
      for (const s of [-1, 1]) {
        for (let o = half + 1; o < half + fw * 1.1; o += 1) {
          const fx = Math.round(cx + nx * (o * s + wob)), fy = Math.round(cy + ny * (o * s + wob));
          if (valueNoise2(fx * 0.3, fy * 0.3, seed + 11) > 0.55) {
            this.fpx(fx, fy, shade(this.fget(fx, fy), 0.9));
          }
        }
      }
    }
  }

  /** A small fastener, 3 output texels — a quarter the size of `bolt`, so it is
   * hardware you scatter by the dozen rather than a landmark. */
  microRivet(fx, fy) {
    const base = this.fget(fx, fy);
    const crown = shade(base, 1.42), lip = shade(base, 0.68);
    this.fpx(fx, fy, crown); this.fpx(fx + 1, fy, shade(base, 1.12));
    this.fpx(fx, fy + 1, shade(base, 1.0)); this.fpx(fx + 1, fy + 1, lip);
    this.faddH(fx, fy, 0.5); this.faddH(fx + 1, fy, 0.42);
    this.faddH(fx, fy + 1, 0.42); this.faddH(fx + 1, fy + 1, 0.3);
  }

  /** A run of microRivets with a jittered pitch. Design coords, output rivets. */
  rivetRun(x0, y0, x1, y1, pitch = 3, seed = 0) {
    const fx0 = x0 * TX, fy0 = y0 * TX, fx1 = x1 * TX, fy1 = y1 * TX;
    const len = Math.max(Math.abs(fx1 - fx0), Math.abs(fy1 - fy0));
    const fp = pitch * TX;
    for (let d = 0; d <= len; d += fp + ((d * 7 + seed) % 3) - 1) {
      const t = d / len;
      this.microRivet(Math.round(fx0 + (fx1 - fx0) * t), Math.round(fy0 + (fy1 - fy0) * t));
    }
  }

  /**
   * Paint chipped off exposed edges, derived from the HEIGHT FIELD rather than
   * from a hand-placed list — so it automatically follows whatever structure the
   * generator painted, and no two surfaces wear in the same places.
   *
   * This is the layer that does most of the work. Real worn metal is bright on
   * the raised edges (paint rubbed to bare metal) and dark in the recesses (dirt
   * packed in), and getting that for free from the relief means every plate lip,
   * weld crest and rivet head reads as three-dimensional under the lighting.
   */
  edgeWear(seed = 0, amount = 0.5) {
    const h = this.height;
    const out = new Float32Array(OUT * OUT);
    for (let fy = 0; fy < OUT; fy++) {
      for (let fx = 0; fx < OUT; fx++) {
        const l = h[fy * OUT + ((fx - 1 + OUT) % OUT)];
        const r = h[fy * OUT + ((fx + 1) % OUT)];
        const u = h[((fy - 1 + OUT) % OUT) * OUT + fx];
        const d = h[((fy + 1) % OUT) * OUT + fx];
        out[fy * OUT + fx] = (Math.abs(r - l) + Math.abs(d - u)) * 0.5;
      }
    }
    for (let fy = 0; fy < OUT; fy++) {
      for (let fx = 0; fx < OUT; fx++) {
        const g = out[fy * OUT + fx];
        if (g < 0.08) continue;
        // noisy coverage: wear is patchy, not a uniform outline round every edge
        const n = valueNoise2(fx * 0.22, fy * 0.22, seed)
          + 0.5 * valueNoise2(fx * 0.7, fy * 0.7, seed + 5);
        if (n / 1.5 < 0.42) continue;
        const raised = h[fy * OUT + fx] > 0;
        const k = raised ? 1 + Math.min(0.5, g) * amount : 1 - Math.min(0.5, g) * amount * 0.8;
        this.fpx(fx, fy, shade(this.fget(fx, fy), k));
      }
    }
  }

  /**
   * Flaked coating: small patches of a different (usually darker, primer-ish)
   * tone with a bright rim on the lit side. Many and small — a dozen 3-6 texel
   * chips read as a worn coat, where one 20-texel patch reads as a stain you can
   * recognise in the next tile along.
   */
  paintChips(rgb, count = 26, seed = 0, maxR = 3) {
    const r = this.rng;
    for (let i = 0; i < count; i++) {
      const cx = r.int(0, OUT - 1), cy = r.int(0, OUT - 1);
      const rad = r.range(1.2, maxR);
      for (let fy = Math.floor(cy - rad - 1); fy <= cy + rad + 1; fy++) {
        for (let fx = Math.floor(cx - rad - 1); fx <= cx + rad + 1; fx++) {
          const dx = fx - cx, dy = fy - cy;
          // irregular outline — a round chip is a recognisable dot
          const wob = 0.65 + 0.7 * valueNoise2(fx * 0.8, fy * 0.8, seed + i);
          const dist = Math.hypot(dx, dy) / (rad * wob);
          const wx = ((fx % OUT) + OUT) % OUT, wy = ((fy % OUT) + OUT) % OUT;
          if (dist < 0.82) {
            this.fpx(wx, wy, rgb);
            this.faddH(wx, wy, -0.22);
          } else if (dist < 1.0) {
            this.fpx(wx, wy, shade(this.fget(wx, wy), 1.2)); // exposed rim
            this.faddH(wx, wy, 0.16);
          }
        }
      }
    }
  }

  /** Very fine scoring — 1 output texel wide, so at 8mm it is a true hairline
   * rather than the 4-texel gouge `scratch` draws. Scatter dozens. */
  hairlines(count = 22, seed = 0, bright = 1.22) {
    const r = this.rng;
    for (let i = 0; i < count; i++) {
      let fx = r.int(0, OUT - 1), fy = r.int(0, OUT - 1);
      const len = r.int(4, 26);
      const ang = r.range(0, Math.PI * 2);
      const sx = Math.cos(ang), sy = Math.sin(ang) * 0.5; // flatter than 45°
      const k = r.chance(0.5) ? bright : 0.82;
      for (let d = 0; d < len; d++) {
        const wx = Math.round(((fx + sx * d) % OUT + OUT)) % OUT;
        const wy = Math.round(((fy + sy * d) % OUT + OUT)) % OUT;
        if (valueNoise2(wx * 0.6, wy * 0.6, seed + i) < 0.32) continue; // broken, not solid
        this.fpx(wx, wy, shade(this.fget(wx, wy), k));
        this.faddH(wx, wy, k > 1 ? 0.1 : -0.12);
      }
    }
  }

  /**
   * Shallow impact dents with a raised lip. Small and many; each one is a real
   * depression in the height field, so the lighting shades it rather than it
   * being a painted-on smudge.
   */
  dents(count = 12, seed = 0, maxR = 4) {
    const r = this.rng;
    for (let i = 0; i < count; i++) {
      const cx = r.int(0, OUT - 1), cy = r.int(0, OUT - 1);
      const rad = r.range(1.8, maxR);
      for (let fy = Math.floor(cy - rad - 1); fy <= cy + rad + 1; fy++) {
        for (let fx = Math.floor(cx - rad - 1); fx <= cx + rad + 1; fx++) {
          const wob = 0.7 + 0.6 * valueNoise2(fx * 0.9, fy * 0.9, seed + i * 3);
          const dist = Math.hypot(fx - cx, fy - cy) / (rad * wob);
          if (dist > 1.15) continue;
          const wx = ((fx % OUT) + OUT) % OUT, wy = ((fy % OUT) + OUT) % OUT;
          if (dist < 0.85) {
            this.faddH(wx, wy, -0.55 * (1 - dist));
            this.fpx(wx, wy, shade(this.fget(wx, wy), 0.93));
          } else {
            this.faddH(wx, wy, 0.25); // upset lip round the rim
            this.fpx(wx, wy, shade(this.fget(wx, wy), 1.1));
          }
        }
      }
    }
  }

  /**
   * Shallow scored sub-division inside a plate — a line that is a change of
   * plane, not an outlined box. Gives large plates internal structure without
   * drawing a cell round anything.
   */
  scoreLine(x0, y0, x1, y1, depth = 0.22) {
    const fx0 = x0 * TX, fy0 = y0 * TX, fx1 = x1 * TX, fy1 = y1 * TX;
    const steps = Math.max(Math.abs(fx1 - fx0), Math.abs(fy1 - fy0));
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const fx = Math.round(fx0 + (fx1 - fx0) * t), fy = Math.round(fy0 + (fy1 - fy0) * t);
      this.fpx(fx, fy, shade(this.fget(fx, fy), 0.9));
      this.faddH(fx, fy, -depth);
      this.fpx(fx + 1, fy + 1, shade(this.fget(fx + 1, fy + 1), 1.08));
      this.faddH(fx + 1, fy + 1, depth * 0.4);
    }
  }

  /**
   * Gravity-fed grime running down from a point, at output resolution: a wide
   * faint fan that narrows into a few dark rivulets. Unlike `rustStreak` this
   * varies in width along its length, which is what makes a run read as liquid.
   */
  stainRun(fx, fy, len, rgb, seed = 0, spread = 3) {
    for (let d = 0; d < len; d++) {
      const t = d / len;
      const w = spread * (1 - t * 0.55);
      for (let o = -w; o <= w; o += 1) {
        const wobble = (valueNoise2(d * 0.4, o * 0.9, seed) - 0.5) * 2;
        const a = (1 - Math.abs(o) / (w + 0.01)) * (1 - t * 0.7) + wobble * 0.25;
        if (a < 0.35) continue;
        const wx = ((Math.round(fx + o) % OUT) + OUT) % OUT;
        const wy = ((fy + d) % OUT + OUT) % OUT;
        this.fpx(wx, wy, mixRgb(this.fget(wx, wy), rgb, Math.min(0.75, a * 0.8)));
      }
    }
  }

  // -- plasticity layers -------------------------------------------------------
  //
  // Everything above this line paints MARKS. What follows sculpts: it reads the
  // height field the marks already wrote and turns it into shading, so a surface
  // stops being a picture of relief and starts looking moulded.
  //
  // Why this is worth doing when the normal map already exists: the normal map
  // only responds to the ONE dynamic light nearest the surface, at whatever angle
  // it happens to be. A corridor lit from behind, or a face turned away from
  // every fixture, gets a flat wash and all the sculpted structure disappears.
  // Cavity and contact shading are baked into the albedo, so they hold at every
  // light angle and in the dark — which is most of this ship.

  /**
   * CAVITY SHADING. Darken concave texels, brighten convex ones, using a
   * Laplacian of the height field.
   *
   * View- and light-independent by construction: it responds to how PINCHED the
   * surface is, not to which way it faces, so it cannot fight the dynamic light
   * the way a baked directional term would. Every seam gains a dark line at its
   * floor, every rivet gains a bright crown, and a bolt stops being a disc of
   * lighter paint and becomes a thing standing off the plate.
   *
   * @param {number} strength peak albedo swing, as a fraction
   * @param {number} radius   sample distance in output texels; larger reads as a
   *                          softer, broader hollow
   */
  cavity(strength = 0.2, radius = 1) {
    const N = OUT, h = this.height;
    const at = (x, y) => h[(((y % N) + N) % N) * N + (((x % N) + N) % N)];
    // Snapshot first: shading must read the ORIGINAL field everywhere, and
    // writing colour does not touch height, so one pass over a live read is
    // safe — but the second-derivative estimate is not, once neighbours have
    // been used to write themselves. Hence the explicit copy.
    const out = new Float32Array(N * N);
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const c = at(x, y);
        const lap = (at(x - radius, y) + at(x + radius, y)
          + at(x, y - radius) + at(x, y + radius)
          + (at(x - radius, y - radius) + at(x + radius, y + radius)
            + at(x - radius, y + radius) + at(x + radius, y - radius)) * 0.5) / 6 - c;
        out[y * N + x] = lap;
      }
    }
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        // lap > 0 means the neighbourhood is higher than here: a hollow.
        const k = 1 - clampf(out[y * N + x] * 1.6, -1, 1) * strength;
        if (Math.abs(k - 1) < 0.004) continue;
        this.fpx(x, y, shade(this.fget(x, y), k));
      }
    }
  }

  /**
   * CONTACT SHADOW. March a short ray across the height field toward a fixed key
   * direction; where something along it stands higher than the horizon from
   * here, darken.
   *
   * This is the layer that gives a rivet a shadow on the plate beside it, which
   * is the single strongest cue that a thing is ON a surface rather than IN it.
   * The direction is constant across every texture in the ship, so all the baked
   * shadows agree with each other — a wall and the crate against it are lit as
   * though by the same overhead fixture, which is what the ship actually has.
   *
   * @param {number} strength deepest darkening, as a fraction
   * @param {number} steps    ray length in output texels
   */
  contactShadow(strength = 0.24, steps = 5) {
    const N = OUT, h = this.height;
    const at = (x, y) => h[(((y % N) + N) % N) * N + (((x % N) + N) % N)];
    // up-left key, matching the ceiling-tube lighting the interior is built on
    const dx = -0.78, dy = -0.62;
    const occ = new Float32Array(N * N);
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const c = at(x, y);
        let best = 0;
        for (let s = 1; s <= steps; s++) {
          // A ray "sees" an occluder when the neighbour rises faster than the
          // slope tolerance — the divide by s is what keeps a long gentle ramp
          // from shadowing itself along its whole length.
          const d = (at(Math.round(x + dx * s), Math.round(y + dy * s)) - c) / s;
          if (d > best) best = d;
        }
        occ[y * N + x] = best;
      }
    }
    for (let y = 0; y < N; y++) {
      for (let x = 0; x < N; x++) {
        const k = 1 - Math.min(1, occ[y * N + x] * 1.5) * strength;
        if (k > 0.996) continue;
        this.fpx(x, y, shade(this.fget(x, y), k));
      }
    }
  }

  // -- decorative hardware -----------------------------------------------------
  //
  // Small, three-dimensional fittings. The rule from the last two sessions still
  // binds: these must stay SMALL and LOW-CONTRAST, because a big bright fitting
  // repeated every two metres is what turns a wall into wallpaper. They earn
  // their place by being round — the interior is otherwise built almost entirely
  // out of straight lines, and a curved highlight is the cheapest way to make a
  // flat surface read as moulded rather than drawn.

  /**
   * A hemispherical boss: a real half-round in the height field with a lit crown
   * and a shaded lower-right skirt. Output coordinates, output radius.
   */
  roundBoss(fx, fy, r = 3, dh = 0.9, tint = null) {
    for (let oy = -r; oy <= r; oy++) {
      for (let ox = -r; ox <= r; ox++) {
        const d2 = ox * ox + oy * oy;
        if (d2 > r * r) continue;
        const z = Math.sqrt(1 - d2 / (r * r)); // unit hemisphere
        // key from up-left, same direction the contact shadow uses
        const lit = clampf((-ox * 0.6 - oy * 0.55) / r + z * 0.5, -1, 1);
        const base = tint ?? this.fget(fx + ox, fy + oy);
        this.fpx(fx + ox, fy + oy, shade(base, 1 + lit * 0.3));
        this.faddH(fx + ox, fy + oy, z * dh);
      }
    }
  }

  /**
   * A fastener head with a driven slot cut across it. Three kinds, because a ship
   * assembled with one fastener everywhere looks printed: `slot` (single),
   * `cross`, `hex` (a recessed socket).
   */
  screwHead(fx, fy, kind = 'slot', r = 3, seed = 0) {
    this.roundBoss(fx, fy, r, 0.55);
    // rim shadow, so the head sits in a countersink rather than floating
    for (let a = 0; a < 32; a++) {
      const t = (a / 32) * Math.PI * 2;
      const px = Math.round(fx + Math.cos(t) * (r + 1)), py = Math.round(fy + Math.sin(t) * (r + 1));
      this.fpx(px, py, shade(this.fget(px, py), 0.84));
      this.faddH(px, py, -0.2);
    }
    const ang = ((seed * 2654435761) % 360) * Math.PI / 180;
    const cut = (a) => {
      const cx = Math.cos(a), sy = Math.sin(a);
      for (let d = -r + 1; d <= r - 1; d++) {
        const px = Math.round(fx + cx * d), py = Math.round(fy + sy * d);
        this.fpx(px, py, shade(this.fget(px, py), 0.6));
        this.faddH(px, py, -0.5);
      }
    };
    if (kind === 'hex') {
      // a recessed socket: a dark well with a bright leading lip
      for (let oy = -r + 1; oy <= r - 1; oy++) {
        for (let ox = -r + 1; ox <= r - 1; ox++) {
          if (Math.abs(ox) + Math.abs(oy) * 0.6 > r - 1) continue;
          this.fpx(fx + ox, fy + oy, shade(this.fget(fx + ox, fy + oy), 0.58));
          this.faddH(fx + ox, fy + oy, -0.55);
        }
      }
    } else {
      cut(ang);
      if (kind === 'cross') cut(ang + Math.PI / 2);
    }
  }

  /**
   * A corrugated band: a run of half-round ribs with a true cosine cross-section,
   * so the highlight rolls across each rib instead of stepping. Vertical ribs by
   * default; `horizontal` lays them the other way.
   *
   * Design coordinates in — this is structure, not wear.
   */
  ribbedBand(x0, y0, w, h, pitch = 4, dh = 0.5, horizontal = false) {
    const fx0 = x0 * TX, fy0 = y0 * TX, fw = w * TX, fh = h * TX, fp = Math.max(2, pitch * TX);
    for (let fy = fy0; fy < fy0 + fh; fy++) {
      for (let fx = fx0; fx < fx0 + fw; fx++) {
        const u = ((horizontal ? fy : fx) % fp) / fp;
        const z = Math.sin(u * Math.PI);            // 0 at the valley, 1 at the crest
        const slope = Math.cos(u * Math.PI);        // signed: which way the face turns
        this.fpx(fx, fy, shade(this.fget(fx, fy), 1 + slope * 0.16 + z * 0.06));
        this.faddH(fx, fy, z * dh);
      }
    }
  }

  /**
   * Cross-hatched knurling — a grip surface. Two opposed diagonal ridge families
   * whose crossing points stand proud, which is exactly what knurling is and
   * what makes a handle read as something a hand has held.
   */
  knurl(x0, y0, w, h, pitch = 3, dh = 0.34) {
    const fx0 = x0 * TX, fy0 = y0 * TX, fw = w * TX, fh = h * TX;
    const fp = Math.max(2, pitch * TX);
    for (let fy = fy0; fy < fy0 + fh; fy++) {
      for (let fx = fx0; fx < fx0 + fw; fx++) {
        const a = Math.sin(((fx + fy) % fp) / fp * Math.PI);
        const b = Math.sin(((fx - fy + fp * 64) % fp) / fp * Math.PI);
        const z = a * b;
        this.fpx(fx, fy, shade(this.fget(fx, fy), 0.94 + z * 0.26));
        this.faddH(fx, fy, (z - 0.35) * dh);
      }
    }
  }

  /**
   * Cast pitting: shallow blind holes with a bright windward lip, scattered by
   * a clustered field so they gather in drifts rather than spreading evenly.
   * This is what separates a cast or sand-blasted part from a rolled one.
   */
  castPitting(count = 40, seed = 0, maxR = 2) {
    const r = this.rng;
    for (let i = 0; i < count; i++) {
      const fx = r.int(0, OUT - 1), fy = r.int(0, OUT - 1);
      // clustered rejection: pits gather where the field is high
      if (valueNoise2(fx * 0.05, fy * 0.05, seed) < 0.42) continue;
      const rad = r.int(1, maxR);
      for (let oy = -rad; oy <= rad; oy++) {
        for (let ox = -rad; ox <= rad; ox++) {
          if (ox * ox + oy * oy > rad * rad) continue;
          this.fpx(fx + ox, fy + oy, shade(this.fget(fx + ox, fy + oy), 0.8));
          this.faddH(fx + ox, fy + oy, -0.36);
        }
      }
      // the raised lip on the up-left side, where the metal pushed out
      this.fpx(fx - rad, fy - rad, shade(this.fget(fx - rad, fy - rad), 1.16));
      this.faddH(fx - rad, fy - rad, 0.24);
    }
  }

  /**
   * Oxidation blooms: soft irregular patches that sit ON the paint with a raised
   * crusty core, rather than the flat colour wash `ditherOver` gives. Blooms are
   * placed by a low-frequency field so they gather in the damp corners of a tile
   * instead of dusting it uniformly.
   */
  patina(rgb, count = 6, seed = 0, maxR = 9) {
    const r = this.rng;
    for (let i = 0; i < count; i++) {
      const cx = r.int(0, OUT - 1), cy = r.int(0, OUT - 1);
      const rad = r.int(Math.max(3, maxR >> 1), maxR);
      for (let oy = -rad; oy <= rad; oy++) {
        for (let ox = -rad; ox <= rad; ox++) {
          const d = Math.hypot(ox, oy) / rad;
          if (d > 1) continue;
          // ragged edge: the noise decides where the bloom actually ends
          const edge = fbm2((cx + ox) * 0.22, (cy + oy) * 0.22, seed + i * 31, 2);
          const a = (1 - d) * 0.9 + (edge - 0.5) * 0.7;
          if (a < 0.24) continue;
          const fx = cx + ox, fy = cy + oy;
          this.fpx(fx, fy, mixRgb(this.fget(fx, fy), rgb, Math.min(0.6, a * 0.55)));
          this.faddH(fx, fy, a * 0.2); // crust stands proud
        }
      }
    }
  }
}

const clampf = (v, a, b) => (v < a ? a : v > b ? b : v);

const rampOf = (hexes) => hexes.map(hexToRgb);
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

/**
 * Colour ramp per biome, dark -> light. The texture pass picks an index from
 * detail noise and relief slope, so each biome is a family of shades rather than
 * a flat fill — three or four entries is enough for that at 384x192.
 *
 * Palette discipline (context/01): every green here is a muted earth pigment.
 * The brightest vegetation tone in the table is [78,126,72], nowhere near the
 * banned #00ff00 family, and the volcanic and metallic ramps stay inside the
 * amber/steel families the rest of the game uses.
 */
const BIOME_RAMP = {
  [BIOME.OCEAN_DEEP]: [[16, 34, 66], [22, 46, 84], [28, 58, 102]],
  [BIOME.OCEAN_SHELF]: [[34, 78, 132], [52, 108, 168], [78, 138, 188]],
  [BIOME.SEA_ICE]: [[172, 190, 206], [204, 216, 228], [232, 240, 248]],
  [BIOME.ICE_SHEET]: [[196, 206, 220], [222, 230, 240], [244, 248, 252]],
  [BIOME.TUNDRA]: [[80, 82, 70], [106, 106, 88], [134, 130, 106]],
  [BIOME.TAIGA]: [[30, 52, 38], [42, 70, 48], [58, 90, 60]],
  [BIOME.TEMPERATE_FOREST]: [[38, 76, 44], [52, 98, 54], [70, 118, 68]],
  [BIOME.GRASSLAND]: [[92, 106, 60], [118, 132, 76], [146, 154, 98]],
  [BIOME.SHRUBLAND]: [[100, 96, 64], [126, 118, 78], [152, 142, 102]],
  [BIOME.DESERT]: [[146, 120, 78], [174, 148, 100], [200, 178, 130]],
  [BIOME.SAVANNA]: [[122, 114, 62], [148, 138, 82], [174, 162, 108]],
  [BIOME.RAINFOREST]: [[24, 60, 34], [36, 80, 42], [50, 100, 52]],
  [BIOME.ALPINE]: [[116, 116, 120], [150, 150, 154], [196, 198, 204]],
  [BIOME.BEACH]: [[148, 136, 96], [174, 162, 118], [196, 186, 146]],
  [BIOME.RIVER]: [[42, 82, 120], [58, 106, 148]],
  [BIOME.LAKE]: [[34, 72, 112], [48, 94, 138]],
  [BIOME.BARE_ROCK]: [[70, 64, 56], [100, 92, 80], [132, 122, 106]],
  [BIOME.REGOLITH]: [[58, 55, 52], [88, 84, 78], [124, 119, 110], [166, 160, 148]],
  [BIOME.LAVA_FIELD]: [[42, 24, 18], [66, 36, 22], [92, 48, 28]],
  [BIOME.LAVA_FLOW]: [[120, 52, 24], [186, 92, 32], [230, 148, 54]],
  [BIOME.BASALT]: [[34, 33, 35], [52, 50, 52], [74, 72, 74]],
  [BIOME.SULFUR_PLAIN]: [[128, 104, 44], [168, 142, 66], [204, 184, 118]],
  [BIOME.SULFUR_VENT]: [[88, 48, 30], [150, 74, 40], [186, 92, 48]],
  [BIOME.CARBON_CRUST]: [[20, 21, 24], [42, 44, 49], [72, 75, 82]],
  [BIOME.DIAMOND_SEAM]: [[112, 116, 126], [164, 168, 178], [204, 208, 218]],
  [BIOME.TAR_SEA]: [[11, 11, 13], [20, 20, 24], [32, 32, 36]],
  [BIOME.METAL_PLAIN]: [[48, 51, 58], [80, 85, 94], [118, 125, 136]],
  [BIOME.METAL_FRESH]: [[146, 154, 166], [184, 192, 204], [214, 220, 230]],
  [BIOME.ICE_CRUST]: [[128, 152, 174], [172, 194, 210], [212, 226, 236]],
  [BIOME.ICE_FRACTURE]: [[54, 74, 96], [80, 102, 126]],
  [BIOME.DUST_MARE]: [[42, 40, 38], [62, 59, 55], [84, 80, 74]],
  [BIOME.HIGHLAND]: [[120, 115, 106], [148, 142, 130], [176, 169, 154]],
};

/**
 * Each biome ramp expanded to a fixed number of shades, once at module load.
 *
 * Three authored entries meant a world built from three biomes had exactly nine
 * colours in it — measured, and it read as flat poster paint. Interpolating to
 * seven steps gives the within-biome noise something to resolve into while
 * keeping the steps HARD and countable, which is the same trick `ditherFill`
 * uses on the interior materials. Still pixel art; just not three-tone.
 */
const BIOME_SHADES = 7;
const BIOME_RAMP_X = {};
for (const k of Object.keys(BIOME_RAMP)) BIOME_RAMP_X[k] = expandRamp(BIOME_RAMP[k], BIOME_SHADES);

/**
 * Fallback ring spec, for the shared default sheet and any body whose rings were
 * not solved. Roughly Saturn: Roche-limit inner edge, a 2:1 division.
 */
const DEFAULT_RINGS = {
  inner: 1.64, outer: 2.30, tiltDeg: 26.7,
  gaps: [{ r: 2.02, width: 0.055, depth: 0.15, ratio: '2:1' }],
};

/** Incandescent crack colours, only used where volcanism is high. */
const LAVA_GLOW = [[190, 96, 30], [224, 140, 46], [246, 186, 88]];

/**
 * Default per-kind surface seed. A body can pass its own (so two ice moons in
 * the same system are different worlds), but the shared texture cache in main.js
 * keys on kind alone, so these keep the default sheets stable and distinct.
 */
const SURFACE_SEED = {
  oceanic: 0x0cea, rocky: 0x70c5, ice: 0x1ce9, lava: 0x1a7a, jungle: 0x1e17,
  moon: 0x33aa, comet: 0xc0e7, toxic: 0x70a1, carbon: 0xca7b, metal: 0x4e7a,
  tundra: 0x7d7a, sulfur: 0x5f7a,
};

/**
 * Derive a tangent-space normal map from a painter's explicit relief plus a
 * luminance assist (bright texels read as slightly raised). Wrapping sobel so
 * tiled surfaces stay seamless. Encoded RGB, +Y = texture-v direction.
 */
function buildNormalMap(p) {
  const N = OUT;
  const h = new Float32Array(N * N);
  let meanLum = 0;
  for (let i = 0; i < N * N; i++) {
    meanLum += (p.data[i * 4] + p.data[i * 4 + 1] + p.data[i * 4 + 2]) / 765;
  }
  meanLum /= N * N;
  // luminance assist gain: see the note on K below — the finer the grid, the
  // smaller each albedo step is per sample, so this term takes the TX correction
  const lumW = RENDER.NORMAL_LUM_WEIGHT * TX;
  for (let i = 0; i < N * N; i++) {
    const lum = (p.data[i * 4] + p.data[i * 4 + 1] + p.data[i * 4 + 2]) / 765;
    h[i] = p.height[i] + lumW * (lum - meanLum);
  }
  const out = new Uint8Array(N * N * 4);
  // NOT scaled by TX, deliberately. `addH` block-fills a design texel, so a
  // structural edge still steps its full height across two adjacent samples —
  // same steepness, just a thinner band. Only the luminance assist genuinely
  // weakens (finer albedo steps are smaller per-sample differences), and that is
  // compensated below rather than by inflating the whole gain, which would
  // over-steepen every bolt and seam by TX×. Verified by measuring mean normal
  // deviation against the 64² build.
  const K = RENDER.NORMAL_STRENGTH;
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      const xm = (x - 1 + N) % N, xp = (x + 1) % N;
      const ym = (y - 1 + N) % N, yp = (y + 1) % N;
      const dhdx = (h[y * N + xp] - h[y * N + xm]) * K;
      const dhdy = (h[yp * N + x] - h[ym * N + x]) * K;
      const inv = 1 / Math.hypot(dhdx, dhdy, 1);
      const i = (y * N + x) * 4;
      out[i] = Math.round((-dhdx * inv * 0.5 + 0.5) * 255);
      out[i + 1] = Math.round((-dhdy * inv * 0.5 + 0.5) * 255);
      out[i + 2] = Math.round((inv * 0.5 + 0.5) * 255);
      out[i + 3] = 255;
    }
  }
  return out;
}

export class TextureFactory {
  /**
   * @param {import('./TextureAtlas.js').TextureAtlas} atlas
   * @param {import('./PixelFont.js').PixelFont} font
   */
  constructor(atlas, font) {
    this.atlas = atlas;
    this.font = font;
    this.rng = new RNG(0x57a17f7); // fixed seed — deterministic ship
    this.seedCounter = 1;
  }

  _painter() {
    return new Painter(this.rng.fork(this.seedCounter++));
  }

  /**
   * The standard industrial finish, applied to every tiling surface AFTER its
   * structural layout is painted. Seven layers, and the order is load-bearing.
   *
   * This exists because the previous pass solved a repeating-pattern problem by
   * deleting detail, which fixed the pattern and left the ship feeling empty.
   * The finish puts density back — hundreds of marks per tile instead of three —
   * while keeping every individual mark small and low-contrast, so there is
   * still nothing for the eye to lock onto and count across a wall.
   *
   * `edgeWear` must run after all structure and dents (it reads the height field
   * and has nothing to follow otherwise) and before the grime (dirt settles on
   * top of worn metal, not under it).
   *
   * @param {Painter} p
   * @param {number[][]} ramp the surface's own ramp, dark → light
   */
  _finish(p, ramp, seed, opts = {}) {
    const {
      grain = 0.07, chips = 24, hair = 20, dent = 10, wear = 0.5,
      grime = 1, rust = 1, runs = 2, grainAx = 1.4, grainAy = 0.35,
      // Plasticity controls. Defaults are tuned for painted plate; a soft
      // surface (cloth, foam, a phosphor screen) passes them down or off.
      pits = 26, bloom = 4, cavity = 0.2, contact = 0.22,
    } = opts;
    p.microGrain(grain, seed + 101, grainAx, grainAy);
    // Casting pits go in EARLY, under the paint chips and grime, because that is
    // the order it happens: the part is cast, then painted, then it weathers.
    if (pits) p.castPitting(pits, seed + 131, 2);
    if (chips) p.paintChips(shade(ramp[0], 0.82), chips, seed + 211);
    if (hair) p.hairlines(hair, seed + 307);
    if (dent) p.dents(dent, seed + 401);
    p.edgeWear(seed + 503, wear);
    // Two grime fields on deliberately uncorrelated axes and frequencies, so
    // neither lines up with the structure or with each other.
    if (grime) {
      p.ditherOver(shade(ramp[0], 0.78), (x, y) =>
        Math.max(0, fbm2(x * 0.037 + 13, y * 0.061, seed + 601, 3) - 0.5) * 1.35 * grime);
      p.ditherOver(shade(ramp[2], 1.06), (x, y) =>
        Math.max(0, fbm2(x * 0.029 + 71, y * 0.044, seed + 701, 2) - 0.56) * 1.0 * grime);
    }
    if (rust) {
      p.ditherOver(hexToRgb(PALETTE.RUST[0]), (x, y) =>
        Math.max(0, fbm2(x * 0.058 + 41, y * 0.032, seed + 809, 3) - 0.64) * 1.2 * rust);
    }
    if (bloom) {
      // Oxidation blooms with real crust, on top of the flat rust wash above.
      // The wash gives the tint, this gives the lump.
      p.patina(hexToRgb(PALETTE.RUST[1]), bloom, seed + 853, 8);
    }
    for (let i = 0; i < runs; i++) {
      p.stainRun(p.rng.int(0, OUT - 1), p.rng.int(0, OUT - 1), p.rng.int(14, 46),
        hexToRgb(PALETTE.RUST[i % 2]), seed + 900 + i, p.rng.range(1.5, 3.5));
    }
    p.speckle(0.05, seed + 997);
    // LAST, and in this order. Both read the finished height field, so every
    // structural seam, rivet, weld, dent and pit written above this point is
    // sculpted by them — and nothing written after could be, which is why there
    // is nothing after. Cavity first (it describes the shape), then contact
    // shadow (it describes where the light cannot reach).
    if (cavity) p.cavity(cavity, 1);
    if (contact) p.contactShadow(contact, 5);
  }

  /**
   * The prop-sized version of `_finish`'s last two lines.
   *
   * Props are NOT tiling stock: they are seen once each, from close range, often
   * with a helmet lamp on them, and they do not repeat, so the whole
   * anti-pattern discipline `_finish` exists to enforce does not apply. What
   * they do share is the need to look moulded rather than drawn — so they get
   * the sculpting layers and skip the wear.
   *
   * @param {Painter} p
   * @param {object} opts pits/bloom/cavity/contact, same meanings as `_finish`
   */
  _sculpt(p, seed, opts = {}) {
    const { pits = 0, bloom = 0, cavity = 0.2, contact = 0.24 } = opts;
    if (pits) p.castPitting(pits, seed + 61, 2);
    if (bloom) p.patina(hexToRgb(PALETTE.RUST[1]), bloom, seed + 137, 7);
    if (cavity) p.cavity(cavity, 1);
    if (contact) p.contactShadow(contact, 5);
  }

  _stencil(p, x, y, text, hex, face = FONT_FACES.TERM7) {
    // Slightly imprecise hand-masked spray: drop ~8% of texels afterwards. The
    // mask runs at OUTPUT resolution now, so the spray breaks up the glyph edge
    // in flecks rather than eating whole design texels out of a letter.
    p.text(this.font, x, y, text, hexToRgb(hex), face);
    const r = p.rng;
    const fx0 = x * TX, fy0 = y * TX;
    for (let fy = fy0; fy < fy0 + 8 * TX; fy++) {
      for (let fx = fx0; fx < fx0 + text.length * 6 * TX; fx++) {
        if (r.chance(0.08) && r.chance(0.5)) p.fpx(fx, fy, shade(p.fget(fx, fy), 0.9));
      }
    }
  }

  /**
   * Generate and register every layer, yielding to the renderer every few
   * textures so the loading screen keeps painting. Returns the atlas.
   */
  async generateAll(onProgress = () => {}) {
    const gens = [
      ['wall_military', () => this.wallMilitary()],
      ['wall_steel', () => this.wallSteel()],
      ['wall_tile', () => this.wallTile()],
      ['wall_cargo', () => this.wallCargo()],
      ['wall_engine', () => this.wallEngine()],
      ['wall_reactor', () => this.wallReactor()],
      ['floor_plate', () => this.floorPlate()],
      ['floor_grate', () => this.floorGrate()],
      ['floor_hazard', () => this.floorHazard()],
      ['floor_cargo', () => this.floorCargo()],
      ['ceiling_panel', () => this.ceilingPanel()],
      ['ceiling_pipes', () => this.ceilingPipes()],
      ['door_panel', () => this.doorPanel()],
      ['door_frame', () => this.doorFrame()],
      ['crate_tech', () => this.crateTech()],
      ['crate_hazard', () => this.crateHazard()],
      ['crate_cryo', () => this.crateCryo()],
      ['console_base', () => this.consoleBase()],
      ['screen_amber', () => this.screenAmber()],
      ['screen_phosphor', () => this.screenPhosphor()],
      ['screen_nav', () => this.screenNav()],
      ['screen_off', () => this.screenOff()],
      ['locker', () => this.locker()],
      ['mattress', () => this.mattress()],
      ['seat_leather', () => this.seatLeather()],
      ['table_top', () => this.tableTop()],
      ['bookshelf', () => this.bookshelf()],
      ['workbench', () => this.workbench()],
      ['med_panel', () => this.medPanel()],
      ['reactor_core', () => this.reactorCore()],
      ['machinery', () => this.machinery()],
      ['pipe', () => this.pipe()],
      ['vent', () => this.vent()],
      ['poster_schematic', () => this.posterSchematic()],
      ['window_starfield', () => this.windowStarfield()],
      ['suit_rack', () => this.suitRack()],
      ['fixture_white', () => this.fixtureWhite()],
      ['shelf_storage', () => this.shelfStorage()],
      ['crane_metal', () => this.craneMetal()],
      ['panel_wall', () => this.panelWall()],
      ['light_tube', () => this.lightTube()],
      ['light_tube_red', () => this.lightTubeRed()],
      ['canister_red', () => this.canisterRed()],
      ['sign_plate', () => this.signPlate()],
      ['door_lamp', () => this.doorLamp()],
      // the things aboard a dead hull — see the block above alienChitin()
      ['alien_chitin', () => this.alienChitin()],
      ['alien_armour', () => this.alienArmour()],
      ['alien_crystal', () => this.alienCrystal()],
    ];
    for (let i = 0; i < gens.length; i++) {
      const [name, gen] = gens[i];
      onProgress(`GENERATING TEXTURE: ${name.toUpperCase()}`, i / gens.length);
      const p = gen();
      this.atlas.register(name, p.data, buildNormalMap(p));
      if (i % 6 === 5) await new Promise((r) => requestAnimationFrame(r));
    }
    return this.atlas;
  }

  // -- walls ----------------------------------------------------------------

  /** Brushed/painted military metal: horizontal banding, 2px grain. */
  wallMilitary() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.35 + 0.3 * valueNoise2(x * 0.08, Math.floor(y / 2) * 0.5, seed) +
      0.25 * fbm2(x * 0.05, y * 0.05, seed + 7, 3));
    // Horizontal plate seams at UNEVEN heights, and no continuous vertical seam.
    // Evenly-pitched seams both ways made this a lattice; the old 32px vertical
    // pair in particular ran the full height and boxed every plate in.
    const seam = shade(ramp[1], 0.9); // mid-ramp, barely darker than the plate
    const lines = [11, 27, 42, 58];
    for (const y of lines) {
      for (let x = 0; x < S; x++) {
        if (valueNoise2(x * 0.26, y * 0.5, seed + 13) > 0.2) { p.px(x, y, seam); p.addH(x, y, -0.32); }
      }
    }
    // ONE short vertical butt joint per course, and only in alternate courses.
    // Four courses each carrying three or four verticals plus a bolt every 13
    // texels closed every plate into a box, and boxes tiled two ways are a
    // lattice no matter how the spacing is jittered. Sparse staggered joints read
    // as plating; dense ones read as ruled paper.
    for (let i = 0; i < lines.length - 1; i += 2) {
      const yA = lines[i], yB = lines[i + 1];
      const x = (i * 23 + seed) % (S - 8) + 4;
      for (let y = yA + 1; y < yB; y++) { p.px(x, y, seam); p.addH(x, y, -0.3); }
    }
    // A rivet run along every seam plus two proper bolts per course, and a weld
    // bead under each. Two lone bolts per seam (the previous pass) left the
    // bulkhead bare; a continuous run of small fasteners is what a riveted seam
    // looks like and, being dense, is unfindable as a repeated mark.
    for (const y of lines) {
      p.rivetRun(2, y - 3, S - 2, y - 3, 4, seed + y);
      const a = 5 + (y * 3) % 17, b = a + 21 + (y % 13);
      for (const x of [a, b]) if (x < S - 2) p.bolt(x, y - 3);
      p.weldBead(0, y + 1, S, y + 1, seed + y * 3, 0.9);
    }
    // Shallow scoring in the wide courses, and a vertical stiffener rib with its
    // own fixings — the wall had no vertical structure at all.
    p.scoreLine(0, 19, S, 19, 0.16);
    p.scoreLine(0, 50, S, 50, 0.16);
    for (let y = 0; y < S; y++) {
      for (let o = 0; o < 3; o++) {
        p.px(24 + o, y, shade(p.get(24 + o, y), o === 1 ? 1.1 : 0.95));
        p.addH(24 + o, y, o === 1 ? 0.45 : 0.2);
      }
    }
    p.rivetRun(25, 1, 25, S - 1, 6, seed + 71);
    // ONE small recessed sub-panel, shallow, tucked against a seam.
    //
    // There were three of them — two 22×24 rects plus a data plate — and the
    // dumped 3×3 repeat showed the result plainly: three big outlined squares per
    // tile, tiling both ways, which is a lattice regardless of what the seams do.
    // A single shallow panel still gives the plate a machined read without
    // becoming the thing the eye locks onto.
    //
    // The data plate also used to carry a stencilled 'K-7'. Legible text on stock
    // that repeats every 2m announces the tiling louder than any seam — the same
    // serial appeared three times across one cockpit wall. Diegetic labelling
    // belongs on props and decals, not on tiling material.
    // Shade change, not an inset frame. insetPanel draws a lit top-left lip, and
    // a bright outline is the single most recognisable thing you can put on a
    // tiling texture — one per 2m became a row of identical bright rectangles
    // marching down the wall.
    for (let y = 33; y < 50; y++) for (let x = 37; x < 57; x++) {
      p.px(x, y, shade(p.get(x, y), 0.93));
      p.addH(x, y, -0.16);
    }
    // ...but it still gets hardware and scoring, so it reads as a fitted plate
    // rather than a flat rectangle of slightly darker wall.
    p.rivetRun(38, 34, 56, 34, 5, seed + 17);
    p.rivetRun(38, 48, 56, 48, 5, seed + 23);
    p.scoreLine(37, 41, 57, 41, 0.14);
    this._finish(p, ramp, seed, { chips: 28, hair: 24, dent: 11, runs: 3 });
    return p;
  }

  wallSteel() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.PANEL_STEEL);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.3 + 0.35 * valueNoise2(x * 0.06, Math.floor(y / 2) * 0.4, seed) +
      0.2 * fbm2(x * 0.09, y * 0.03, seed + 3, 3));
    // Two seams at uneven heights rather than an even 22px pitch, each broken by
    // wear, with the bolt spacing varied along the run — an unbroken line with
    // evenly-spaced bolts is what turns a wall into ruled paper.
    const seam = shade(ramp[0], 0.68);
    for (const y of [17, 44]) {
      for (let x = 0; x < S; x++) {
        if (valueNoise2(x * 0.22, y * 0.7, seed + 11) > 0.18) { p.px(x, y, seam); p.addH(x, y, -0.48); }
      }
      p.rivetRun(2, y - 4, S - 2, y - 4, 4, seed + y * 3);
      for (let x = 5 + (y % 7); x < S; x += 10 + (x % 6)) p.bolt(x, y - 4);
      p.weldBead(0, y + 2, S, y + 2, seed + y, 1.0);
    }
    // three stiffener ribs at uneven spacing — vertical structure so the wall is
    // not just two horizontal lines and a field
    for (const rx of [11, 33, 52]) {
      for (let y = 0; y < S; y++) {
        for (let o = 0; o < 3; o++) {
          p.px(rx + o, y, shade(p.get(rx + o, y), o === 1 ? 1.09 : 0.94));
          p.addH(rx + o, y, o === 1 ? 0.4 : 0.18);
        }
      }
      p.rivetRun(rx + 1, 1, rx + 1, S - 1, 7, seed + rx);
    }
    // Inspection hatch as a shade change with a handle, NOT an inset frame.
    // insetPanel draws a lit lip all round, and a bright outline is the most
    // recognisable mark you can put on a tiling texture — one per 2m became a
    // grid of identical outlined boxes down the med bay and computer core.
    for (let y = 24; y < 50; y++) for (let x = 22; x < 52; x++) {
      p.px(x, y, shade(p.get(x, y), 0.9));
      p.addH(x, y, -0.18);
    }
    p.raisedTrim(32, 34, 10, 2, ramp[1], 0.4);
    p.rivetRun(23, 25, 51, 25, 4, seed + 31);
    p.rivetRun(23, 48, 51, 48, 4, seed + 37);
    p.scoreLine(22, 37, 52, 37, 0.15);
    this._finish(p, ramp, seed, { chips: 26, hair: 22, dent: 10, runs: 2 });
    return p;
  }

  /** Heavily tiled wall, rust bleeding through the grout (bunks/lab/bath). */
  /**
   * Bolted wall plating in RUNNING BOND — the old bathroom-tile version was an
   * 8px grout grid, which at 64 design texels meant an 8×8 lattice of identical
   * squares repeating every 2 model metres. That read as graph paper on every
   * wall of the ship (owner: "I don't want any patterns or this visible squared
   * grid"), and it was the single most pattern-like surface in the interior.
   *
   * What replaces it, and why each part earns its place:
   *
   * - Four IRREGULAR courses (13/17/16/18 texels tall) instead of eight even
   *   ones. Uneven heights alone stop the eye locking onto a pitch.
   * - Each course is offset horizontally, so vertical joints never line up into
   *   continuous columns. Aligned joints are what makes a grid a grid; broken
   *   ones read as masonry, which is a structure, not a pattern.
   * - Plate widths vary 17–29 texels, so no course even has a constant pitch.
   * - Joints are shallow and low-contrast (0.82 of the base, not 0.55), because
   *   a dark outline around every cell is what draws the lattice in the first
   *   place. The depth in the normal map carries the seam instead of colour.
   * - Per-plate value steps, off-axis wear, and rust that crosses joints rather
   *   than following them.
   *
   * Rows are laid from y=0 with the last course absorbing the remainder, so the
   * top and bottom edges still meet when the texture wraps.
   */
  wallTile() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK).map((c) => shade(c, 1.25));
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.42 + 0.22 * valueNoise2(x * 0.09, y * 0.09, seed)
      + 0.16 * fbm2(x * 0.045, y * 0.045, seed + 5, 3));

    // Joint colour comes off the MIDDLE of the ramp, not the darkest entry.
    // shade(ramp[0], 0.82) plus the normal-map depth read as a black outline
    // around every plate, and an outlined cell is exactly what makes a lattice.
    const joint = shade(ramp[1], 0.88);
    const courses = [13, 17, 16, 18]; // sums to 64 — wraps cleanly
    let y0 = 0;
    for (let c = 0; c < courses.length; c++) {
      const y1 = y0 + courses[c];
      // horizontal joint at the top of the course, broken by wear
      for (let x = 0; x < S; x++) {
        if (valueNoise2(x * 0.3, c * 4.1, seed + 17) > 0.22) {
          p.px(x, y0, joint); p.addH(x, y0, -0.3);
        }
      }
      // running bond: each course starts at its own offset, so the vertical
      // joints of neighbouring courses can never stack into a column
      let x0 = (c * 11 + (seed % 7)) % 23;
      while (x0 < S) {
        const w = 17 + ((x0 * 3 + c * 5 + seed) % 13); // 17..29
        for (let y = y0 + 1; y < y1 && y < S; y++) {
          p.px(x0 % S, y, joint); p.addH(x0 % S, y, -0.26);
        }
        // Per-plate value step, kept NARROW. A 19% spread (0.90..1.075) made one
        // conspicuously light plate per course, and a conspicuous anything on a
        // 2m tile is a landmark you then count across the wall. The shader's
        // per-tile step carries the wider variation instead — that one is keyed
        // to world position, so it does not repeat with the texture.
        const k = 0.955 + ((x0 * 7 + c * 3 + seed) % 6) * 0.017;
        for (let y = y0 + 1; y < y1 && y < S; y++) {
          for (let x = x0 + 1; x < x0 + w && x < S + x0; x++) {
            const xx = x % S;
            p.px(xx, y, shade(p.get(xx, y), k));
          }
        }
        // ONE rivet, on roughly three plates in five, placed off-axis inside the
        // plate. Two per plate at fixed corners (the first attempt) put ~24 marks
        // on a 64px tile in a near-regular arrangement, which reassembled into a
        // loose lattice of its own once the tile repeated across the wall.
        // Dense small hardware, not one landmark fastener. The previous pass cut
        // this to a single `bolt` on some plates, which emptied the wall; a run of
        // 3-output-texel rivets down the butt joint is what a bolted plate
        // actually looks like, and no individual rivet is findable.
        p.rivetRun(x0 + 1, y0 + 2, x0 + 1, y1 - 2, 4 + (c % 2), seed + x0);
        if (((x0 * 3 + c) % 4) === 0) p.rivetRun(x0 + 2, y0 + 2, x0 + w - 2, y0 + 2, 5, seed + c);
        const r = (x0 * 13 + c * 29 + seed) % 5;
        if (r < 2 && c % 2 === 1 && y1 - y0 > 10) {
          p.bolt((x0 + 3 + r * 4) % S, y0 + 3 + ((x0 + c) % Math.max(1, y1 - y0 - 6)));
        }
        // internal scoring, so a wide plate has structure without being a boxed cell
        if (w > 22 && ((x0 + c * 5) % 3) === 0) {
          const my = y0 + Math.floor((y1 - y0) * 0.55);
          p.scoreLine(x0 + 4, my, x0 + w - 4, my, 0.18);
        }
        x0 += w;
      }
      y0 = y1;
    }

    // Weld beads along two of the four course joints — fabricated, not printed.
    p.weldBead(0, courses[0], S, courses[0], seed + 5, 1.1);
    p.weldBead(0, courses[0] + courses[1] + courses[2], S,
      courses[0] + courses[1] + courses[2], seed + 9, 1.0);
    this._finish(p, ramp, seed, { chips: 30, hair: 26, dent: 12, runs: 3 });
    return p;
  }

  /** Cargo bay: steel cross-braced lattice over dark plate. */
  wallCargo() {
    const p = this._painter();
    // Hull plate BEHIND the frame, not void. The backing was a near-black ramp,
    // which made the lattice a bright graphic on empty space — and empty space is
    // wrong anyway, there is pressure hull behind a cargo-bay truss. Lifting it
    // to dark grime tones also lets the wear layers below actually show, and drops
    // the frame-to-field contrast that made the truss read as a printed pattern.
    const back = rampOf([PALETTE.FLOOR_GRIME[0], PALETTE.FLOOR_GRIME[1], PALETTE.FLOOR_GRIME[2]]);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(back, (x, y) =>
      0.3 + 0.3 * fbm2(x * 0.06, y * 0.06, seed, 3)
      + 0.18 * valueNoise2(x * 0.11, y * 0.03, seed + 21));
    const green = rampOf(PALETTE.METAL_DARK); // structural steel ramp
    // frame + X cross-braces
    const beam = (x0, y0, x1, y1, w) => {
      const dx = x1 - x0, dy = y1 - y0;
      const len = Math.max(Math.abs(dx), Math.abs(dy));
      for (let i = 0; i <= len; i++) {
        const x = Math.round(x0 + (dx * i) / len), y = Math.round(y0 + (dy * i) / len);
        for (let o = 0; o < w; o++) {
          const v = 0.35 + 0.4 * valueNoise2((x + o) * 0.3, y * 0.3, seed + 5);
          const t = v * (green.length - 1);
          let idx = Math.floor(t);
          if (t - idx > bayerT(x + o, y)) idx++;
          p.px(x + o, y, green[Math.min(idx, green.length - 1)]);
          p.addH(x + o, y, 0.55); // lattice beams stand proud of the plate
        }
      }
    };
    // TWO UNEQUAL BAYS per tile, braced asymmetrically.
    //
    // This was one square bay per tile, framed on all four sides with a full X
    // across it — so a cargo wall came out as a perfect grid of identical
    // X-braced squares, the most lattice-like surface in the ship. The concept
    // art does call for an exposed structural lattice here, and a truss is
    // inherently repetitive, but a truss on a real hull has unequal bays and is
    // only braced where the load needs it.
    //
    // Widths 27/37 and a single diagonal in the narrow bay only, so across the
    // wall the rhythm alternates wide/narrow and braced/open instead of
    // presenting the same cell over and over.
    const MID = 27;
    beam(0, 0, S - 1, 0, 4); beam(0, S - 4, S - 1, S - 4, 4); // top/bottom rails
    beam(0, 0, 0, S - 1, 4); beam(MID, 0, MID, S - 1, 3);     // stanchions
    beam(2, 3, MID - 2, S - 6, 3);                            // one diagonal, narrow bay
    // a mid-height tie across the wide bay — horizontal, so it reads as a rail
    beam(MID + 2, 34, S - 1, 34, 3);
    for (const [bx, by] of [[1, 1], [MID, 1], [1, S - 6], [MID, S - 6], [S - 8, 32]]) p.bolt(bx + 1, by + 2);
    // Wear and shadow across the frame — this is what stops the remaining
    // regularity reading as a printed pattern rather than as built steel.
    p.ditherOver(hexToRgb(PALETTE.RUST[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.05 + 17, y * 0.045, seed + 27, 3) - 0.55) * 1.5);
    p.ditherOver(hexToRgb(PALETTE.SHADOW_BLACK[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.033, y * 0.07 + 41, seed + 43, 2) - 0.48) * 1.3);
    // Gusset plates, bolt clusters and weld beads at every node — a truss without
    // connection hardware is a line drawing, and the joints are where the eye
    // expects engineering.
    for (const [gx, gy] of [[0, 0], [MID, 0], [0, S - 6], [MID, S - 6], [MID, 32]]) {
      for (let y = gy; y < gy + 6 && y < S; y++) {
        for (let x = gx; x < gx + 6 && x < S; x++) {
          p.px(x % S, y, shade(p.get(x % S, y), 1.06));
          p.addH(x % S, y, 0.28);
        }
      }
      p.microRivet((gx + 1) * TX, (gy + 1) * TX);
      p.microRivet((gx + 4) * TX, (gy + 1) * TX);
      p.microRivet((gx + 1) * TX, (gy + 4) * TX);
      p.microRivet((gx + 4) * TX, (gy + 4) * TX);
    }
    p.weldBead(0, 3, S, 3, seed + 3, 1.0);
    p.weldBead(0, S - 5, S, S - 5, seed + 7, 1.0);
    p.rivetRun(1, 1, 1, S - 1, 5, seed + 11);   // down the port stanchion
    p.rivetRun(MID + 1, 1, MID + 1, S - 1, 5, seed + 13);
    this._finish(p, green, seed, {
      chips: 22, hair: 20, dent: 14, wear: 0.6, rust: 1.6, runs: 4,
    });
    return p;
  }

  wallEngine() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.35 * fbm2(x * 0.07, y * 0.07, seed, 4));
    // horizontal conduit runs
    const steel = rampOf(PALETTE.PANEL_STEEL);
    for (const py of [10, 22, 46]) {
      for (let x = 0; x < S; x++) {
        p.px(x, py, steel[2]); p.px(x, py + 1, steel[1]);
        p.px(x, py + 2, steel[0]); p.px(x, py + 3, shade(steel[0], 0.6));
        p.addH(x, py, 0.6); p.addH(x, py + 1, 0.5); p.addH(x, py + 2, 0.3);
      }
      for (let x = 6; x < S; x += 16) { // pipe clamps ride over the conduit
        for (let y = py - 1; y < py + 5; y++) { p.px(x, y, shade(steel[0], 0.8)); p.addH(x, y, 0.35); }
      }
    }
    // warning stripe band
    for (let x = 0; x < S; x++) {
      for (let y = 56; y < 62; y++) {
        const on = ((x + y) & 7) < 4;
        p.px(x, y, on ? hexToRgb(PALETTE.AMBER_MACHINE[1]) : hexToRgb(PALETTE.SHADOW_BLACK[0]));
      }
    }
    // No junction box here any more. A recessed frame with an amber gauge and a
    // steel gauge inside it is a bright, instantly recognisable landmark, and on
    // a texture that repeats every 2m the engine room grew a row of identical
    // fake instruments. Real junction boxes are already dressed in as greeble
    // geometry (Greebles.js), where they sit at believable intervals instead of
    // every two metres exactly.
    //
    // What's left is linear: three conduit runs and one continuous hazard band.
    // Both read as lines running the length of the wall, which is what they are,
    // and a line cannot repeat into a grid.
    // Branch conduits dropping off the main runs, cable ties, and a bracket row.
    // The horizontal runs alone were correct but sparse — an engine room wall is
    // the busiest surface on a ship and it was reading as three stripes.
    for (const [bx, y0, y1] of [[14, 13, 22], [37, 13, 22], [22, 25, 46], [52, 25, 46]]) {
      for (let y = y0; y < y1; y++) {
        for (let o = 0; o < 2; o++) {
          p.px(bx + o, y, shade(p.get(bx + o, y), o === 0 ? 1.12 : 0.88));
          p.addH(bx + o, y, o === 0 ? 0.45 : 0.2);
        }
      }
      for (let y = y0 + 2; y < y1; y += 5 + (bx % 3)) { // cable ties
        for (let o = -1; o < 3; o++) p.px(bx + o, y, shade(p.get(bx + o, y), 0.8));
      }
    }
    for (const py of [10, 22, 46]) p.rivetRun(2, py + 4, S - 2, py + 4, 5, seed + py);
    p.scoreLine(0, 34, S, 34, 0.15);
    this._finish(p, ramp, seed, { chips: 30, hair: 26, dent: 13, rust: 1.4, runs: 4 });
    return p;
  }

  wallReactor() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.PANEL_STEEL.slice(0, 2)).concat([hexToRgb(PALETTE.METAL_DARK[1])]);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.35 + 0.3 * fbm2(x * 0.08, y * 0.05, seed, 3));
    // Vent rows at UNEVEN heights with varied slot lengths and gaps. An even
    // 24px pitch with a slot every 10px was a regular field of dashes, which
    // tiles into a dot grid; uneven rows of unequal slots read as punched
    // louvres. Rows are laid so they still wrap at y=64.
    for (const y of [7, 26, 51]) {
      let vx = 3 + (y % 5);
      while (vx < S - 6) {
        const len = 5 + ((vx + y) % 5); // 5..9
        for (let sx = 0; sx < len && vx + sx < S; sx++) {
          p.px(vx + sx, y, hexToRgb(PALETTE.SHADOW_BLACK[0]));
          p.px(vx + sx, y + 1, hexToRgb(PALETTE.SHADOW_BLACK[1]));
          p.px(vx + sx, y + 2, shade(ramp[1], 1.2));
          p.addH(vx + sx, y, -0.6); p.addH(vx + sx, y + 1, -0.6); p.addH(vx + sx, y + 2, 0.25);
        }
        vx += len + 3 + ((vx * 3 + y) % 4);
      }
    }
    // Shielded access panel as a shade change, and NO stencil. 'RAD-3' is
    // legible text on stock that repeats every 2m — it appeared four times across
    // one reactor-room wall, which announces the tiling louder than any seam.
    // Radiation placarding belongs on sign_plate props, which are placed once.
    for (let y = 32; y < 54; y++) for (let x = 38; x < 60; x++) {
      p.px(x, y, shade(p.get(x, y), 0.88));
      p.addH(x, y, -0.2);
    }
    // Shielding-panel frame hardware: rivet rows above each louvre bank, a
    // stiffener rib, and weld beads where the shield plates butt together.
    for (const y of [7, 26, 51]) {
      p.rivetRun(2, y - 3, S - 2, y - 3, 5, seed + y * 7);
      p.weldBead(0, y + 4, S, y + 4, seed + y, 0.9);
    }
    for (let y = 0; y < S; y++) {
      for (let o = 0; o < 3; o++) {
        p.px(31 + o, y, shade(p.get(31 + o, y), o === 1 ? 1.1 : 0.93));
        p.addH(31 + o, y, o === 1 ? 0.42 : 0.18);
      }
    }
    p.rivetRun(32, 1, 32, S - 1, 6, seed + 41);
    p.rivetRun(39, 33, 59, 33, 4, seed + 47);
    p.rivetRun(39, 52, 59, 52, 4, seed + 53);
    this._finish(p, ramp, seed, { chips: 24, hair: 22, dent: 12, rust: 1.3, runs: 3 });
    return p;
  }

  // -- floors / ceilings ------------------------------------------------------

  floorPlate() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.FLOOR_GRIME);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.35 + 0.4 * fbm2(x * 0.09, y * 0.09, seed, 4));
    // diamond tread pattern — raised nubs you can feel in the lamp light
    for (let y = 0; y < S; y += 8) {
      for (let x = 0; x < S; x += 8) {
        const ox = ((y >> 3) & 1) * 4;
        p.px(x + ox + 2, y + 3, shade(p.get(x + ox + 2, y + 3), 1.5));
        p.px(x + ox + 3, y + 4, shade(p.get(x + ox + 3, y + 4), 0.6));
        p.addH(x + ox + 2, y + 3, 0.55);
        p.addH(x + ox + 3, y + 3, 0.4);
        p.addH(x + ox + 2, y + 4, 0.4);
      }
    }
    // Deck-plate joints: one crossing pair at 31/31 gave a 2×2 grid of squares
    // per tile, which under a 2m repeat became a continuous chequerboard down
    // every corridor. Offset and softened, with the vertical joint dog-legged so
    // it never lines up with its own copy in the next tile along.
    const seam = shade(ramp[0], 0.7);
    for (let x = 0; x < S; x++) {
      const y = 27 + (((x >> 4) & 1) ? 2 : 0);
      p.px(x, y, seam); p.addH(x, y, -0.45);
    }
    for (let y = 0; y < S; y++) {
      const x = 19 + (y > 27 ? 26 : 0); // steps sideways past the horizontal joint
      p.px(x, y, seam); p.addH(x, y, -0.45);
    }
    p.ditherOver(hexToRgb(PALETTE.RUST[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.05 + 40, y * 0.05, seed + 11, 3) - 0.62) * 1.6);
    // Access plate as a shade change with four corner bolts, not an inset frame.
    // The lit lip of insetPanel made one bright-outlined square per tile, so a
    // corridor floor read as a chequerboard of them — and floor_cargo and
    // floor_hazard both derive from this, so all three inherited it.
    for (let y = 20; y < 44; y++) for (let x = 20; x < 44; x++) {
      p.px(x, y, shade(p.get(x, y), 0.92));
      p.addH(x, y, -0.2);
    }
    for (const [bx, by] of [[22, 22], [41, 22], [22, 41], [41, 41]]) p.bolt(bx, by);
    p.rivetRun(21, 21, 42, 21, 5, seed + 13);
    p.rivetRun(21, 42, 42, 42, 5, seed + 19);
    // A deck takes the worst wear on the ship: heavy scuffing, more dents, no
    // gravity runs (nothing drips onto a floor from above in the same way).
    this._finish(p, ramp, seed, {
      chips: 34, hair: 34, dent: 16, wear: 0.55, runs: 0, grainAx: 0.9, grainAy: 0.9,
      // Boots polish a deck flat: the crust gets walked off and the relief that
      // survives is worn shallow, so the blooms drop and the shadows soften.
      pits: 18, bloom: 1, contact: 0.16,
    });
    return p;
  }

  floorGrate() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.FLOOR_GRIME);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.4 + 0.3 * valueNoise2(x * 0.15, y * 0.15, seed));
    const hole = hexToRgb(PALETTE.SHADOW_BLACK[2]);
    for (let y = 2; y < S; y += 6) {
      for (let x = 0; x < S; x++) {
        if ((x % 12) < 8) {
          p.px(x, y, hole); p.px(x, y + 1, hole);
          p.addH(x, y, -0.7); p.addH(x, y + 1, -0.7); // open grating slots
        }
      }
      for (let x = 0; x < S; x++) { p.px(x, y + 2, shade(p.get(x, y + 2), 1.3)); p.addH(x, y + 2, 0.3); }
    }
    // The bearing bars between the slots are a rolled section, not a flat strip:
    // the walking face crowns and the sides fall away. This surface measured TEN
    // colours before — the flattest thing in the ship, on the one material the
    // player is closest to for the whole game.
    for (let y = 0; y < S; y++) {
      const inSlot = (y % 6) < 2;
      if (inSlot) continue;
      const t = ((y % 6) - 2) / 4;
      const crown = Math.sin(t * Math.PI);
      for (let x = 0; x < S; x++) {
        p.px(x, y, shade(p.get(x, y), 0.94 + crown * 0.2));
        p.addH(x, y, crown * 0.45);
      }
    }
    // Cross-bars welded under the grating, visible down the open slots, and a
    // serrated anti-slip nib along the walking edge of each bar.
    for (let x = 4; x < S; x += 16) {
      for (let y = 0; y < S; y++) {
        if ((y % 6) >= 2) continue;
        p.px(x, y, shade(p.get(x, y), 1.9)); p.px(x + 1, y, shade(p.get(x + 1, y), 1.5));
        p.addH(x, y, 0.35);
      }
    }
    for (let y = 4; y < S; y += 6) {
      for (let x = 0; x < S; x++) if ((x & 3) === 0) { p.px(x, y, shade(p.get(x, y), 1.24)); p.addH(x, y, 0.22); }
    }
    // Deck grating is walked on, dropped on and bled through: it takes the
    // heaviest grime load of any surface aboard.
    this._finish(p, ramp, seed, {
      grain: 0.06, chips: 12, hair: 26, dent: 6, wear: 0.45, runs: 0, rust: 1.3,
      pits: 22, bloom: 3, cavity: 0.26, contact: 0.3,
    });
    return p;
  }

  floorHazard() {
    const p = this.floorPlate();
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const black = hexToRgb(PALETTE.SHADOW_BLACK[0]);
    for (let y = 0; y < 10; y++) {
      for (let x = 0; x < S; x++) {
        const on = ((x + y) & 15) < 8;
        const worn = fbm2(x * 0.2, y * 0.2, 77, 2) > 0.72; // paint flaked off
        if (!worn) p.px(x, y, on ? amber : black);
      }
    }
    return p;
  }

  floorCargo() {
    const p = this.floorPlate();
    // heavier rust — this deck has been dragged over for a decade
    const seed = p.rng.int(0, 9999);
    p.ditherOver(hexToRgb(PALETTE.RUST[1]), (x, y) =>
      Math.max(0, fbm2(x * 0.06, y * 0.06, seed, 4) - 0.52) * 1.5);
    p.ditherOver(hexToRgb(PALETTE.RUST[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.11 + 9, y * 0.11, seed + 2, 3) - 0.6) * 1.4);
    return p;
  }

  /**
   * LINEAR ribbed ceiling with cable runs — no cells at all.
   *
   * Two earlier versions of this were a grid: first an even 16px lattice with a
   * recessed panel and a fastener dead-centre of every cell, then the same thing
   * with uneven pitches. The second was no better, and the dumped 3×3 repeat
   * shows why — varying the cell SIZES does nothing when every cell is still an
   * outlined inset box. An outlined box tiled in two directions is a lattice by
   * construction, however irregular the spacing.
   *
   * A one-dimensional pattern cannot read as a squared grid, so the fix is to
   * drop the cross seams entirely and run everything one way: ribs of varying
   * width, a couple of conduit runs, one flush access strip. It is also the more
   * accurate reference — the ceilings this ship is drawing from are cable trays
   * and strip runs, not suspended office tiles. The transverse rhythm comes from
   * the real geometry beams Room.addCeilingBeams already puts under here.
   */
  ceilingPanel() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK).map((c) => shade(c, 0.8));
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.34 + 0.22 * fbm2(x * 0.06, y * 0.055, seed, 3)
      + 0.14 * valueNoise2(x * 0.13, y * 0.02, seed + 9));
    const groove = shade(ramp[1], 0.84);
    const crest = shade(ramp[2], 1.05);
    // ribs of varying width, laid across x; widths sum to 64 so the sheet wraps
    const ribs = [9, 6, 11, 7, 10, 8, 13];
    let x0 = 0;
    for (let i = 0; i < ribs.length; i++) {
      const w = ribs[i], x1 = x0 + w;
      const k = 0.93 + ((i * 5 + seed) % 4) * 0.035;
      for (let y = 0; y < S; y++) {
        // groove at the rib edge, crest highlight one texel in — the relief is
        // carried by the height field, so the colour step can stay gentle
        p.px(x0, y, groove); p.addH(x0, y, -0.5);
        p.px(x1 - 1 < S ? x1 - 1 : S - 1, y, shade(p.get(Math.min(x1 - 1, S - 1), y), 0.94));
        for (let x = x0 + 1; x < x1 && x < S; x++) {
          p.px(x, y, shade(p.get(x, y), k));
          // rounded rib section: crest high in the middle, falling to the grooves
          p.addH(x, y, 0.45 * (1 - Math.abs(x - (x0 + x1) / 2) / (w / 2 + 0.01)));
        }
        if (x0 + 1 < S) p.px(x0 + 1, y, crest);
      }
      x0 = x1;
    }
    // conduit runs along two of the grooves, with clamps at uneven intervals
    for (const gi of [1, 4]) {
      const gx = ribs.slice(0, gi).reduce((a, b) => a + b, 0);
      const pipe = rampOf(PALETTE.PANEL_STEEL);
      for (let y = 0; y < S; y++) {
        for (let o = 0; o < 3; o++) {
          const x = (gx + o) % S;
          p.px(x, y, pipe[o === 0 ? 2 : o === 2 ? 0 : 1]);
          p.addH(x, y, o === 1 ? 0.6 : 0.3);
        }
      }
      for (let y = 3 + (gx % 11); y < S; y += 14 + (y % 5)) {
        for (let o = -1; o < 4; o++) p.px((gx + o + S) % S, y, shade(ramp[0], 0.8));
      }
    }
    // one flush access strip, no outline — a shade change and a pair of catches
    const ay = 22 + (seed % 9);
    for (let y = ay; y < ay + 7 && y < S; y++) {
      for (let x = 0; x < S; x++) p.px(x, y, shade(p.get(x, y), 0.9));
    }
    p.bolt(6 + (seed % 5), ay + 3);
    p.bolt(S - 9 - (seed % 4), ay + 3);
    // cross-braces at uneven intervals — the ribs alone were readable but bare
    for (const by of [9, 31, 52]) {
      for (let x = 0; x < S; x++) {
        for (let o = 0; o < 2; o++) {
          p.px(x, by + o, shade(p.get(x, by + o), o === 0 ? 1.06 : 0.9));
          p.addH(x, by + o, o === 0 ? 0.3 : 0.12);
        }
      }
      p.rivetRun(2, by, S - 2, by, 6, seed + by);
    }
    // grain runs ALONG the ribs here, not across — the ribs are vertical in this
    // texture, so the anisotropy has to be swapped or it fights the structure
    this._finish(p, ramp, seed, {
      chips: 20, hair: 18, dent: 8, runs: 3, grainAx: 0.35, grainAy: 1.4,
    });
    return p;
  }

  ceilingPipes() {
    const p = this._painter();
    const base = rampOf(PALETTE.SHADOW_BLACK.slice(0, 2)).concat([hexToRgb(PALETTE.FLOOR_GRIME[1])]);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(base, (x, y) => 0.3 + 0.3 * valueNoise2(x * 0.1, y * 0.1, seed));
    const grime = rampOf(PALETTE.FLOOR_GRIME);
    const steel = rampOf(PALETTE.PANEL_STEEL);
    let y = 2;
    let lane = 0;
    while (y < S - 6) {
      const w = p.rng.int(3, 6);
      const ramp = lane % 3 === 2 ? steel : grime;
      for (let x = 0; x < S; x++) {
        for (let o = 0; o < w; o++) {
          const t = o === 0 ? 2 : o === w - 1 ? 0 : 1; // top highlight line
          p.px(x, y + o, ramp[t]);
          // rounded pipe cross-section: crest high, edges falling away
          p.addH(x, y + o, 0.6 * (1 - Math.abs(o - (w - 1) / 2) / ((w - 1) / 2 + 0.01)));
        }
      }
      // Shade the cross-section as well as raising it. The height field already
      // rounded these; the ALBEDO did not, so the run measured eleven colours and
      // read as flat coloured bands in every light the normal map did not favour.
      for (let x = 0; x < S; x++) {
        for (let o = 0; o < w; o++) {
          const u = (o + 0.5) / w;
          p.px(x, y + o, shade(p.get(x, y + o), 0.82 + Math.sin(u * Math.PI) * 0.42));
        }
      }
      for (let x = p.rng.int(4, 10); x < S; x += 16) { // clamps sit on top
        for (let o = -1; o <= w; o++) { p.px(x, y + o, shade(steel[0], 0.7)); p.addH(x, y + o, 0.5); }
        // the bolt through each clamp's lug
        p.screwHead(x * TX, (y + w) * TX, 'hex', 1.6 * TX, seed + x + y);
      }
      // A painted service band on every third run, and a lagged section on
      // another — a ceiling of identical bare tubes is what made this read as
      // corduroy rather than as plumbing.
      if (lane % 3 === 1) {
        const band = p.rng.int(6, 40);
        for (let x = band; x < band + 5 && x < S; x++) {
          for (let o = 0; o < w; o++) p.px(x, y + o, hexToRgb(PALETTE.AMBER_MACHINE[0]));
        }
      } else if (lane % 4 === 3) {
        p.ribbedBand(0, y, S, w, 2, 0.3);
      }
      y += w + p.rng.int(1, 3);
      lane++;
    }
    // Condensation and rust gather on overhead runs, and drip off them.
    p.patina(hexToRgb(PALETTE.RUST[1]), 5, seed + 71, 7);
    p.castPitting(18, seed + 91, 2);
    p.cavity(0.24, 1);
    p.contactShadow(0.3, 5);
    return p;
  }

  // -- doors ------------------------------------------------------------------

  doorPanel() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.PANEL_STEEL);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.3 + 0.3 * valueNoise2(x * 0.05, Math.floor(y / 2) * 0.4, seed) +
      0.15 * fbm2(x * 0.1, y * 0.1, seed + 4, 2));
    p.outline(0, 0, S, S, shade(ramp[0], 0.5));
    p.outline(1, 1, S - 2, S - 2, shade(ramp[2], 1.15));
    // horizontal reinforcement ribs — heavy raised bands
    for (const ry of [16, 48]) {
      for (let x = 3; x < S - 3; x++) {
        p.px(x, ry, shade(ramp[2], 1.2)); p.px(x, ry + 1, ramp[1]); p.px(x, ry + 2, shade(ramp[0], 0.7));
        p.addH(x, ry, 0.55); p.addH(x, ry + 1, 0.5); p.addH(x, ry + 2, 0.1);
      }
    }
    // hazard chevrons mid-band
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const black = hexToRgb(PALETTE.SHADOW_BLACK[0]);
    for (let y = 26; y < 38; y++) {
      for (let x = 3; x < S - 3; x++) {
        const on = ((x + y) & 15) < 8;
        if (fbm2(x * 0.15, y * 0.15, 31, 2) < 0.7) p.px(x, y, on ? amber : black);
      }
    }
    // recessed viewport slot near the top + a recessed kick-plate below
    p.insetPanel(6, 5, 20, 9, { depth: 0.6, fieldMul: 0.7, bolts: false });
    p.insetPanel(6, 42, S - 12, 8, { depth: 0.55, bolts: false });
    this._stencil(p, 8, 54, 'KESTREL', PALETTE.AMBER_MACHINE[0]);
    for (const [bx, by] of [[4, 4], [S - 8, 4], [4, S - 8], [S - 8, S - 8]]) p.bolt(bx, by);
    // Locking dogs down the leading edge and the handwheel boss beside them —
    // the two fittings that say this is a pressure door and not a cupboard.
    for (const dy of [10, 22, 40, 52]) p.roundBoss((S - 5) * TX, dy * TX, 2.4 * TX, 0.9);
    p.roundBoss(52 * TX, 20 * TX, 5 * TX, 1.2);
    p.knurl(48, 16, 9, 9, 2, 0.3);
    for (const [sx, sy] of [[4, 4], [S - 8, 4], [4, S - 8], [S - 8, S - 8]]) {
      p.screwHead(sx * TX, sy * TX, 'cross', 2 * TX, seed + sx * 5 + sy);
    }
    p.rustStreak(p.rng.int(8, 56), 18, 8, 0.5);
    p.speckle(0.045, seed);
    this._sculpt(p, seed, { pits: 26, bloom: 3, cavity: 0.22, contact: 0.28 });
    return p;
  }

  doorFrame() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.3 * fbm2(x * 0.1, y * 0.1, seed, 3));
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const black = hexToRgb(PALETTE.SHADOW_BLACK[0]);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < 6; x++) {
        const on = ((x + y) & 7) < 4;
        p.px(x, y, on ? amber : black);
        p.addH(x, y, 0.25); // the hazard band is applied tape, standing proud
      }
    }
    // A pressure-door frame is the heaviest structure on the deck and this one
    // was a flat rectangle with a stripe: 38 colours, no relief worth the name.
    // What it needs is the section a real frame has — a proud outer flange, a
    // recessed seal channel, and the dogs that pull the door into it.
    for (let y = 0; y < S; y++) {
      for (let x = 6; x < S; x++) {
        const d = x - 6;
        // flange 0..5, channel 6..11, land 12+
        const prof = d < 6 ? 0.9 : d < 12 ? -0.85 : 0.15;
        p.px(x, y, shade(p.get(x, y), d < 6 ? 1.16 : d < 12 ? 0.72 : 1.0));
        p.addH(x, y, prof);
      }
    }
    // Inflatable seal in the channel: a soft half-round, darker than the metal.
    for (let y = 0; y < S; y++) {
      for (let d = 7; d < 11; d++) {
        const u = (d - 7) / 4;
        p.px(6 + d, y, mixRgb(p.get(6 + d, y), hexToRgb(PALETTE.SHADOW_BLACK[1]), 0.45));
        p.addH(6 + d, y, Math.sin(u * Math.PI) * 0.5);
      }
    }
    p.rivetRun(2, 1, 2, S - 1, 6, seed + 13);
    for (let y = 6; y < S; y += 18) p.screwHead(20 * TX, y * TX, 'hex', 2.4 * TX, seed + y);
    p.weldBead(18, 0, 18, S, seed + 29, 1.1);
    this._finish(p, ramp, seed, {
      chips: 20, hair: 18, dent: 8, wear: 0.55, runs: 2,
      pits: 24, bloom: 3, cavity: 0.24, contact: 0.28,
    });
    p.darkenEdges(2, 0.7);
    return p;
  }

  // -- crates -------------------------------------------------------------------

  _crateBase(rampHexes) {
    const p = this._painter();
    const ramp = rampOf(rampHexes);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.35 + 0.3 * fbm2(x * 0.08, y * 0.08, seed, 3));
    p.outline(0, 0, S, S, shade(ramp[0], 0.5));
    p.outline(1, 1, S - 2, S - 2, shade(ramp[2], 1.2));
    // corner reinforcements — plates riveted proud of the shell
    for (const [cx, cy] of [[2, 2], [S - 12, 2], [2, S - 12], [S - 12, S - 12]]) {
      p.rect(cx, cy, 10, 10, shade(ramp[1], 0.85));
      for (let py = 0; py < 10; py++) for (let px = 0; px < 10; px++) p.addH(cx + px, cy + py, 0.4);
      p.outline(cx, cy, 10, 10, shade(ramp[0], 0.6));
      p.bolt(cx + 3, cy + 3);
      p.screwHead((cx + 3) * TX, (cy + 3) * TX, 'hex', 2 * TX, seed + cx * cy);
      p.screwHead((cx + 7) * TX, (cy + 7) * TX, 'hex', 2 * TX, seed + cx + cy);
    }
    // Pressed ribs across the shell. A shipping case is stamped, not folded flat
    // — the ribs are what stop the panel oil-canning, and they are the reason a
    // real crate reads as sheet metal rather than a painted box.
    p.ribbedBand(14, 6, S - 28, S - 12, 9, 0.42);
    return { p, ramp, seed };
  }

  crateTech() {
    const { p, seed } = this._crateBase(PALETTE.PANEL_STEEL);
    // small LCD status panel
    p.rect(24, 24, 16, 10, hexToRgb(PALETTE.PHOSPHOR_BG[0]));
    p.outline(23, 23, 18, 12, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    p.text(this.font, 26, 26, 'OK', hexToRgb(PALETTE.PHOSPHOR_TEXT[0]));
    this._stencil(p, 16, 44, 'KSV-114', PALETTE.AMBER_MACHINE[0]);
    // the status panel is set INTO the shell, and its bezel stands proud
    for (let y = 23; y < 35; y++) for (let x = 23; x < 41; x++) p.addH(x, y, -0.6);
    for (let y = 22; y < 36; y++) { p.addH(22, y, 0.7); p.addH(41, y, 0.7); }
    this._sculpt(p, seed, { pits: 14, bloom: 2 });
    return p;
  }

  crateHazard() {
    const { p, seed } = this._crateBase([PALETTE.RUST[0], PALETTE.RUST[1], PALETTE.AMBER_MACHINE[0]]);
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const black = hexToRgb(PALETTE.SHADOW_BLACK[0]);
    for (let y = 14; y < 20; y++) {
      for (let x = 4; x < S - 4; x++) {
        const on = ((x + y) & 15) < 8;
        p.px(x, y, on ? amber : black);
      }
    }
    // radiation trefoil suggestion (three dark wedge dots on amber disc)
    p.rect(27, 28, 10, 10, amber);
    p.px(31, 31, black); p.px(32, 31, black);
    p.px(29, 34, black); p.px(30, 34, black);
    p.px(33, 34, black); p.px(34, 34, black);
    this._stencil(p, 14, 46, 'CAUTION', PALETTE.WARNING_RED[1]);
    // the hazard band is applied tape, not paint: it stands off the shell
    for (let y = 14; y < 20; y++) for (let x = 4; x < S - 4; x++) p.addH(x, y, 0.3);
    this._sculpt(p, seed, { pits: 16, bloom: 4 });
    return p;
  }

  crateCryo() {
    const { p, seed } = this._crateBase(PALETTE.PLANET_ICE);
    p.rect(20, 22, 24, 14, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    p.rect(21, 23, 22, 12, hexToRgb(PALETTE.PHOSPHOR_BG[1]));
    p.text(this.font, 23, 25, '-41', hexToRgb(PALETTE.PHOSPHOR_TEXT[1]));
    p.text(this.font, 23, 25 + 8, 'C', hexToRgb(PALETTE.PHOSPHOR_MID[1]));
    this._stencil(p, 16, 46, 'CRYO', PALETTE.PLANET_ICE[2]);
    // the readout is recessed behind a proud bezel, and frost has crusted along
    // the cold face — the one place on the ship where a bloom is ice, not rust
    for (let y = 22; y < 36; y++) for (let x = 20; x < 44; x++) p.addH(x, y, -0.55);
    for (let y = 21; y < 37; y++) { p.addH(19, y, 0.8); p.addH(44, y, 0.8); }
    p.patina(hexToRgb(PALETTE.PLANET_ICE[2]), 5, seed + 401, 8);
    this._sculpt(p, seed, { pits: 8, bloom: 0, cavity: 0.22 });
    return p;
  }

  // -- consoles & screens ---------------------------------------------------------

  consoleBase() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.25 * fbm2(x * 0.07, y * 0.07, seed, 3));
    // recessed instrument bank — the keys below sit proud inside this well
    p.insetPanel(3, 3, S - 6, 40, { depth: 0.7, fieldMul: 0.82, bolts: false });
    // button grid — chunky raised amber/red keys with lit tops
    for (let gy = 6; gy < 40; gy += 8) {
      for (let gx = 6; gx < S - 8; gx += 8) {
        const warm = p.rng.chance(0.8);
        const c = warm ? hexToRgb(PALETTE.AMBER_MACHINE[p.rng.int(0, 2)]) : hexToRgb(PALETTE.WARNING_RED[1]);
        p.rect(gx, gy, 4, 4, c);
        p.px(gx, gy, shade(c, 1.4));
        p.px(gx + 3, gy + 3, shade(c, 0.5));
        for (let by = 0; by < 4; by++) for (let bx = 0; bx < 4; bx++) p.addH(gx + bx, gy + by, 0.5);
      }
    }
    // toggle switch row — recessed slots, proud levers
    for (let gx = 6; gx < S - 8; gx += 10) {
      p.rect(gx, 46, 6, 10, shade(ramp[0], 0.6));
      for (let sy = 46; sy < 56; sy++) for (let sx = gx; sx < gx + 6; sx++) p.addH(sx, sy, -0.3);
      const up = p.rng.chance(0.5);
      p.rect(gx + 2, up ? 47 : 52, 2, 4, hexToRgb(PALETTE.PANEL_STEEL[2]));
      for (let sy = 0; sy < 4; sy++) { p.addH(gx + 2, (up ? 47 : 52) + sy, 0.7); p.addH(gx + 3, (up ? 47 : 52) + sy, 0.7); }
    }
    // A rotary knob between the switch banks, and the fixings that hold the
    // fascia on. The console was built entirely out of rectangles — one round
    // thing on it does more for the sense of a moulded object than another
    // dozen square keys would.
    for (const kx of [10, 34, 56]) p.roundBoss(kx * TX, 61 * TX, 3.2 * TX, 1.1);
    for (const [sx, sy] of [[2, 60], [S - 3, 60], [2, 2], [S - 3, 2]]) {
      p.screwHead(sx * TX, sy * TX, 'cross', 2.2 * TX, seed + sx * 7 + sy);
    }
    p.darkenEdges(2, 0.7);
    // Sculpt: the keys stop being coloured squares and become keys you could
    // press, because each one now has a shadow on the fascia beside it.
    p.cavity(0.22, 1);
    p.contactShadow(0.26, 5);
    return p;
  }

  _screenBase(bgHexes) {
    const p = this._painter();
    const ramp = rampOf(bgHexes);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.25 * valueNoise2(x * 0.1, y * 0.1, seed));
    // checkerboard scanline dither (glass/CRT material rule)
    for (let y = 0; y < S; y += 2) {
      for (let x = (y >> 1) & 1; x < S; x += 2) {
        p.px(x, y, shade(p.get(x, y), 0.8));
      }
    }
    p.outline(0, 0, S, S, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    return p;
  }

  screenAmber() {
    const p = this._screenBase(PALETTE.HUD_PANEL_BG);
    const a0 = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const a1 = hexToRgb(PALETTE.AMBER_MACHINE[0]);
    p.text(this.font, 4, 4, 'KESTREL OS', a0);
    p.text(this.font, 4, 14, 'PWR 87%', a1);
    p.text(this.font, 4, 22, 'O2  94%', a1);
    p.text(this.font, 4, 30, 'HUL 91%', a1);
    // Design grid fits floor((64 - x) / 6) glyphs — 'SYS NOMINAL' at x=4 is 11
    // and rendered as "SYS NOMINA" with the L off the edge.
    p.text(this.font, 3, 42, 'SYSTEMS OK', a1);
    for (let x = 4; x < 60; x += 2) p.px(x, 52, a1); // divider
    p.text(this.font, 4, 55, 'CREW 1/6', a1);
    return p;
  }

  screenPhosphor() {
    const p = this._screenBase(PALETTE.PHOSPHOR_BG);
    const g0 = hexToRgb(PALETTE.PHOSPHOR_TEXT[0]);
    const g1 = hexToRgb(PALETTE.PHOSPHOR_MID[1]);
    p.text(this.font, 3, 4, 'AETHON/SYS', g0); // 11 glyphs did not fit — see screenAmber
    p.text(this.font, 4, 14, '> ARCHIVE', g1);
    p.text(this.font, 4, 22, '> SYS LOG', g1);
    p.text(this.font, 4, 30, '> COMMS', g1);
    p.text(this.font, 4, 42, 'ACCESS REQ', g0);
    p.rect(4, 52, 4, 7, g0); // block cursor
    return p;
  }

  screenNav() {
    const p = this._screenBase(PALETTE.HUD_PANEL_BG);
    // warm orange nebula map — dithered blobs + route dots
    const seed = p.rng.int(0, 9999);
    p.ditherOver(hexToRgb(PALETTE.AMBER_MACHINE[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.06, y * 0.06, seed, 3) - 0.5) * 1.3);
    p.ditherOver(hexToRgb(PALETTE.RUST[2]), (x, y) =>
      Math.max(0, fbm2(x * 0.09 + 5, y * 0.09, seed + 1, 3) - 0.62) * 1.4);
    const r = p.rng;
    for (let i = 0; i < 14; i++) {
      p.px(r.int(4, 60), r.int(4, 60), hexToRgb(PALETTE.AMBER_MACHINE[2]));
    }
    // plotted route
    let x = 8, y = 52;
    while (x < 56 && y > 10) {
      p.px(x, y, hexToRgb(PALETTE.AMBER_MACHINE[2]));
      x += 3; y -= r.int(1, 3);
    }
    p.text(this.font, 4, 4, 'NAV', hexToRgb(PALETTE.AMBER_MACHINE[1]));
    return p;
  }

  screenOff() {
    const p = this._screenBase(PALETTE.SHADOW_BLACK.slice(0, 2));
    // faint diagonal glass glint
    for (let i = 0; i < 20; i++) {
      const x = 10 + i, y = 40 - i;
      if ((i & 3) < 2) p.px(x, y, hexToRgb(PALETTE.PANEL_STEEL[0]));
    }
    return p;
  }

  // -- furniture & fittings ------------------------------------------------------

  locker() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.35 + 0.3 * valueNoise2(x * 0.06, Math.floor(y / 2) * 0.5, seed));
    // two doors with vent slits + handles
    for (let y = 0; y < S; y++) p.px(31, y, shade(ramp[0], 0.5)); // center gap
    for (const ox of [6, 38]) {
      for (let sy = 8; sy < 20; sy += 4) {
        for (let sx = 0; sx < 18; sx++) {
          p.px(ox + sx, sy, hexToRgb(PALETTE.SHADOW_BLACK[0]));
          p.px(ox + sx, sy + 1, shade(ramp[2], 1.2));
          p.addH(ox + sx, sy, -0.55); p.addH(ox + sx, sy + 1, 0.2); // louvres
        }
      }
      p.rect(ox + 8, 34, 2, 6, hexToRgb(PALETTE.PANEL_STEEL[2])); // handle
      for (let hy = 34; hy < 40; hy++) { p.addH(ox + 8, hy, 0.55); p.addH(ox + 9, hy, 0.55); }
    }
    // dents — dark blotches
    for (let i = 0; i < 3; i++) {
      const dx = p.rng.int(6, 54), dy = p.rng.int(24, 58);
      p.ditherOver(shade(ramp[0], 0.7), (x, y) => {
        const d = Math.hypot(x - dx, y - dy);
        return Math.max(0, 1 - d / 4) * 0.8;
      });
    }
    // name tape on one door — someone else's name, still there
    p.rect(36, 44, 24, 9, shade(hexToRgb(PALETTE.AMBER_MACHINE[2]), 1.15));
    p.text(this.font, 37, 45, 'MERC', hexToRgb(PALETTE.SHADOW_BLACK[0]));
    p.rustStreak(p.rng.int(4, 58), 4, 10, 0.5);
    // Hinge fixings down both stiles and a knurled grip on each handle. A locker
    // door with no visible hinges is a picture of a locker door.
    for (const hx of [3, 60]) {
      for (const hy of [10, 30, 54]) p.screwHead(hx * TX, hy * TX, 'slot', 2 * TX, seed + hx * hy);
    }
    for (const ox of [6, 38]) p.knurl(ox + 8, 35, 2, 4, 2, 0.3);
    this._sculpt(p, seed, { pits: 14, bloom: 2 });
    return p;
  }

  /** Worn olive mattress — cloth cross-hatch dither, darker seam rows. */
  mattress() {
    const p = this._painter();
    const base = hexToRgb(PALETTE.METAL_DARK[1]);
    const olive = [shade(base, 0.9), mixRgb(base, hexToRgb(PALETTE.AMBER_MACHINE[0]), 0.35),
      mixRgb(base, hexToRgb(PALETTE.AMBER_MACHINE[1]), 0.4)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(olive, (x, y) => {
      const hatch = ((x + y) & 3) === 0 || ((x - y) & 3) === 0 ? 0.15 : 0; // cross-hatch
      return 0.35 + hatch + 0.25 * fbm2(x * 0.08, y * 0.08, seed, 3);
    });
    for (let y = 15; y < S; y += 16) for (let x = 0; x < S; x++) p.px(x, y, shade(p.get(x, y), 0.65));
    // stains
    p.ditherOver(shade(olive[0], 0.75), (x, y) =>
      Math.max(0, fbm2(x * 0.07 + 3, y * 0.07, seed + 2, 3) - 0.6) * 1.2);
    // Quilting: the seam rows are pushed in and the panels between them bulge,
    // so the cavity pass has something to round off. This is what turns a
    // cross-hatched rectangle into a mattress with stuffing in it.
    for (let y = 15; y < S; y += 16) for (let x = 0; x < S; x++) p.addH(x, y, -0.8);
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const t = ((y % 16) / 16) * Math.PI;
        p.addH(x, y, Math.sin(t) * 0.34);
      }
    }
    this._sculpt(p, seed, { cavity: 0.17, contact: 0.14 });
    return p;
  }

  /** Deeply cracked brown leather (cockpit chair) — blotch dither + crack lines. */
  seatLeather() {
    const p = this._painter();
    const brown = [shade(hexToRgb(PALETTE.RUST[0]), 0.55), shade(hexToRgb(PALETTE.RUST[0]), 0.8),
      hexToRgb(PALETTE.RUST[1])];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(brown, (x, y) => 0.4 + 0.35 * fbm2(x * 0.1, y * 0.1, seed, 4));
    // cracks — dark meandering single-pixel lines
    const r = p.rng;
    for (let i = 0; i < 7; i++) {
      let x = r.int(2, 61), y = r.int(2, 61);
      const len = r.int(8, 22);
      for (let s = 0; s < len; s++) {
        p.px(x, y, shade(brown[0], 0.5));
        p.addH(x, y, -0.7); // the crack is a split, not a dark line
        x += r.int(-1, 1); y += r.chance(0.7) ? 1 : r.int(-1, 0);
        if (x < 0 || y < 0 || x >= S || y >= S) break;
      }
    }
    // Slack padding: a broad low swell so the hide reads as stretched over
    // something soft rather than glued to a board.
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        p.addH(x, y, (0.5 + 0.5 * Math.cos((x / S - 0.5) * Math.PI * 2))
          * (0.5 + 0.5 * Math.cos((y / S - 0.5) * Math.PI * 2)) * 0.5);
      }
    }
    p.darkenEdges(3, 0.75);
    this._sculpt(p, seed, { cavity: 0.24, contact: 0.18 });
    return p;
  }

  tableTop() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.PANEL_STEEL);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.35 + 0.3 * valueNoise2(x * 0.07, y * 0.2, seed));
    for (let i = 0; i < 6; i++) p.scratch(p.rng.int(2, 40), p.rng.int(4, 58), p.rng.int(8, 20));
    // ring stains — someone's cup, many times
    for (let i = 0; i < 2; i++) {
      const cx = p.rng.int(12, 52), cy = p.rng.int(12, 52);
      p.ditherOver(shade(ramp[0], 0.7), (x, y) => {
        const d = Math.abs(Math.hypot(x - cx, y - cy) - 5);
        return Math.max(0, 1 - d) * 0.6;
      });
    }
    // A rolled steel edge and the countersunk fixings that hold the top down.
    p.ribbedBand(0, 0, S, 2, 4, 0.35, true);
    p.ribbedBand(0, S - 2, S, 2, 4, 0.35, true);
    for (const [sx, sy] of [[4, 4], [S - 5, 4], [4, S - 5], [S - 5, S - 5]]) {
      p.screwHead(sx * TX, sy * TX, 'hex', 2.2 * TX, seed + sx + sy);
    }
    p.darkenEdges(2, 0.7);
    this._sculpt(p, seed, { pits: 12 });
    return p;
  }

  bookshelf() {
    const p = this._painter();
    const dark = rampOf(PALETTE.SHADOW_BLACK.slice(0, 2)).concat([hexToRgb(PALETTE.FLOOR_GRIME[1])]);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(dark, (x, y) => 0.3 + 0.2 * valueNoise2(x * 0.1, y * 0.1, seed));
    const spineFams = [PALETTE.RUST, PALETTE.AMBER_MACHINE, PALETTE.PANEL_STEEL, PALETTE.METAL_DARK];
    const r = p.rng;
    for (let shelfY = 4; shelfY < S - 10; shelfY += 20) {
      let x = 3;
      while (x < S - 6) {
        const w = r.int(3, 6);
        const h = r.int(12, 16);
        const fam = rampOf(r.pick(spineFams));
        for (let bx = 0; bx < w; bx++) {
          for (let by = 0; by < h; by++) {
            const t = bx === 0 ? 2 : bx === w - 1 ? 0 : 1;
            p.px(x + bx, shelfY + (16 - h) + by, fam[t]);
          }
        }
        if (r.chance(0.4)) p.px(x + 1, shelfY + (16 - h) + 3, shade(fam[2], 1.3)); // label dot
        x += w + (r.chance(0.15) ? 3 : 0); // occasional gap — books removed
      }
      for (let sx = 0; sx < S; sx++) { // shelf board
        p.px(sx, shelfY + 17, hexToRgb(PALETTE.FLOOR_GRIME[2]));
        p.px(sx, shelfY + 18, hexToRgb(PALETTE.FLOOR_GRIME[0]));
        // the board's front edge stands off the books it carries
        p.addH(sx, shelfY + 17, 0.7); p.addH(sx, shelfY + 18, 0.35);
        for (let by = 0; by < 16; by++) p.addH(sx, shelfY + by, -0.12);
      }
    }
    this._sculpt(p, seed, { cavity: 0.22, contact: 0.28 });
    return p;
  }

  workbench() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.35 + 0.3 * fbm2(x * 0.09, y * 0.09, seed, 3));
    // oil stains
    p.ditherOver(hexToRgb(PALETTE.SHADOW_BLACK[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.08, y * 0.08, seed + 5, 3) - 0.55) * 1.4);
    // scattered tool silhouettes
    const steel = hexToRgb(PALETTE.PANEL_STEEL[2]);
    p.rect(8, 10, 14, 3, steel); p.rect(20, 8, 3, 7, steel); // wrench-ish
    p.rect(36, 30, 3, 16, steel); p.rect(33, 44, 9, 3, steel); // driver
    p.rect(46, 12, 8, 8, shade(steel, 0.7)); // part block
    // The tools were flat silhouettes lying in the same plane as the bench.
    // Lifting them into the height field is what lets the contact shadow put
    // them ON it — a two-line change that does more than any amount of colour.
    for (const [rx, ry, rw, rh] of [[8, 10, 14, 3], [20, 8, 3, 7], [36, 30, 3, 16],
      [33, 44, 9, 3], [46, 12, 8, 8]]) {
      for (let y = ry; y < ry + rh; y++) for (let x = rx; x < rx + rw; x++) p.addH(x, y, 0.85);
    }
    // A bench vice on the near corner: knurled jaw, round handle boss.
    p.rect(4, 50, 16, 10, shade(steel, 0.85));
    for (let y = 50; y < 60; y++) for (let x = 4; x < 20; x++) p.addH(x, y, 1.1);
    p.knurl(5, 51, 14, 3, 2, 0.4);
    p.roundBoss(12 * TX, 57 * TX, 3 * TX, 1.2);
    for (let i = 0; i < 4; i++) p.scratch(p.rng.int(2, 40), p.rng.int(4, 58), p.rng.int(6, 16));
    p.darkenEdges(2, 0.7);
    this._sculpt(p, seed, { pits: 16, bloom: 2, contact: 0.3 });
    return p;
  }

  medPanel() {
    const p = this._painter();
    const ramp = [hexToRgb(PALETTE.PANEL_STEEL[1]), hexToRgb(PALETTE.PANEL_STEEL[2]),
      shade(hexToRgb(PALETTE.PANEL_STEEL[2]), 1.3)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.4 + 0.3 * valueNoise2(x * 0.08, y * 0.08, seed));
    // faded red cross
    const red = hexToRgb(PALETTE.WARNING_RED[0]);
    p.ditherOver(red, (x, y) => {
      const inCross = (x >= 26 && x < 38 && y >= 14 && y < 50) || (y >= 26 && y < 38 && x >= 14 && x < 50);
      return inCross ? 0.55 + 0.2 * valueNoise2(x * 0.3, y * 0.3, seed + 1) : 0;
    });
    for (let y = 0; y < S; y += 16) for (let x = 0; x < S; x++) p.px(x, y, shade(p.get(x, y), 0.75));
    p.rustStreak(p.rng.int(8, 56), 0, 8, 0.4);
    // Latch boss and the four fixings that hold the enamelled panel to the frame.
    p.roundBoss(52 * TX, 54 * TX, 3 * TX, 1.0);
    for (const [sx, sy] of [[4, 4], [S - 5, 4], [4, S - 5], [S - 5, S - 5]]) {
      p.screwHead(sx * TX, sy * TX, 'cross', 2 * TX, seed + sx * 3 + sy);
    }
    p.darkenEdges(2, 0.75);
    this._sculpt(p, seed, { pits: 6, cavity: 0.22 });
    return p;
  }

  /** Reactor column — dark housing with amber glow slits (rendered emissive). */
  reactorCore() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK).map((c) => shade(c, 0.8));
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.3 * valueNoise2(x * 0.06, y * 0.15, seed));
    const glow = rampOf(PALETTE.AMBER_MACHINE);
    for (let y = 6; y < S; y += 12) {
      for (let x = 4; x < S - 4; x++) {
        const flick = valueNoise2(x * 0.2, y, seed + 9);
        p.px(x, y, glow[2]);
        p.px(x, y + 1, flick > 0.4 ? glow[1] : glow[0]);
        p.px(x, y + 2, shade(glow[0], 0.7));
      }
    }
    for (let x = 0; x < S; x += 16) for (let y = 0; y < S; y++) {
      p.px(x, y, shade(p.get(x, y), 0.6));
      p.addH(x, y, -0.5); // the vertical splits between housing segments
    }
    // The glow slits are CUT into the housing, and the metal between them is a
    // half-round rib. Previously both were flat, so the column read as a
    // painted cylinder rather than a machine with light escaping out of it.
    for (let y = 6; y < S; y += 12) {
      for (let x = 4; x < S - 4; x++) { p.addH(x, y, -0.9); p.addH(x, y + 1, -0.9); p.addH(x, y + 2, -0.4); }
    }
    p.ribbedBand(0, 0, S, S, 12, 0.55, true);
    for (let y = 3; y < S; y += 12) p.rivetRun(3, y, S - 3, y, 6, seed + y);
    this._sculpt(p, seed, { pits: 22, cavity: 0.24, contact: 0.28 });
    return p;
  }

  machinery() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.3 * fbm2(x * 0.08, y * 0.08, seed, 3));
    const steel = rampOf(PALETTE.PANEL_STEEL);
    const r = p.rng;
    // gauge dials
    for (let i = 0; i < 3; i++) {
      const gx = 8 + i * 18, gy = 8;
      p.rect(gx, gy, 12, 12, steel[0]);
      p.outline(gx, gy, 12, 12, shade(steel[0], 0.6));
      p.rect(gx + 2, gy + 2, 8, 8, shade(hexToRgb(PALETTE.AMBER_MACHINE[2]), 1.1));
      // needle
      p.px(gx + 6, gy + 6, hexToRgb(PALETTE.SHADOW_BLACK[0]));
      p.px(gx + 5 + r.int(0, 2), gy + 4, hexToRgb(PALETTE.SHADOW_BLACK[0]));
      // A raised bezel with a domed cover glass: the dial face is recessed, the
      // rim stands proud, and the glass bulges. Three heights where there was
      // one, which is the whole difference between a gauge and a drawing of one.
      for (let by = gy; by < gy + 12; by++) {
        for (let bx = gx; bx < gx + 12; bx++) {
          const rim = bx === gx || bx === gx + 11 || by === gy || by === gy + 11;
          p.addH(bx, by, rim ? 0.9 : -0.45);
        }
      }
      p.roundBoss((gx + 6) * TX, (gy + 6) * TX, 4 * TX, 0.5);
      for (const [cx2, cy2] of [[gx, gy], [gx + 11, gy], [gx, gy + 11], [gx + 11, gy + 11]]) {
        p.screwHead(cx2 * TX, cy2 * TX, 'slot', 1.6 * TX, seed + cx2 * cy2);
      }
    }
    // cable bundle hanging loose
    for (let i = 0; i < 4; i++) {
      let x = r.int(8, 56);
      for (let y = 26; y < 60; y++) {
        // Three texels wide with a lit crown and a shaded underside: a cable is
        // a cylinder, and a one-texel line is a pen stroke.
        const base = hexToRgb(PALETTE.FLOOR_GRIME[i & 1 ? 0 : 2]);
        p.px(x - 1, y, shade(base, 1.22)); p.addH(x - 1, y, 0.45);
        p.px(x, y, base); p.addH(x, y, 0.7);
        p.px(x + 1, y, shade(base, 0.68)); p.addH(x + 1, y, 0.3);
        if (r.chance(0.25)) x += r.int(-1, 1);
      }
    }
    for (let y = 40; y < 44; y++) for (let x = 0; x < S; x++) {
      if (((x + y) & 7) < 4) p.px(x, y, hexToRgb(PALETTE.AMBER_MACHINE[0]));
    }
    this._sculpt(p, seed, { pits: 20, bloom: 3, contact: 0.3 });
    return p;
  }

  pipe() {
    const p = this._painter();
    // rubber/cable insulation: smooth low-contrast dither, 1px top highlight
    const ramp = [hexToRgb(PALETTE.FLOOR_GRIME[0]), hexToRgb(PALETTE.FLOOR_GRIME[1]),
      hexToRgb(PALETTE.FLOOR_GRIME[2])];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.4 + 0.15 * valueNoise2(x * 0.05, y * 0.3, seed));
    // CYLINDRICAL SHADING. The pipe texture wraps a tube, so v runs around the
    // circumference: a cosine term across y is the actual cross-section, not an
    // approximation of one. The old single highlight line left the rest of the
    // tube flat and it read as a painted stripe on a flat band.
    for (let y = 0; y < S; y++) {
      const t = (y / S) * Math.PI * 2;
      const lit = Math.cos(t - 0.9); // key from up-left, as everywhere else
      for (let x = 0; x < S; x++) {
        p.px(x, y, shade(p.get(x, y), 1 + lit * 0.3));
        p.addH(x, y, Math.cos(t) * 0.5);
      }
    }
    for (let x = 0; x < S; x++) p.px(x, 1, shade(ramp[2], 1.5)); // specular line along the crown
    for (let x = 0; x < S; x += 20) { // joint collars, standing proud of the run
      for (let y = 0; y < S; y++) {
        p.px(x, y, shade(ramp[0], 0.7)); p.px(x + 1, y, shade(ramp[2], 1.2));
        p.addH(x, y, 0.5); p.addH(x + 1, y, 0.8);
      }
      // union nuts on the collar
      for (const cy of [10, 32, 54]) p.screwHead((x + 1) * TX, cy * TX, 'hex', 2 * TX, seed + x + cy);
    }
    this._sculpt(p, seed, { pits: 10, bloom: 2, cavity: 0.16, contact: 0.18 });
    return p;
  }

  vent() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.35 + 0.25 * valueNoise2(x * 0.1, y * 0.1, seed));
    for (let y = 6; y < S - 4; y += 6) {
      for (let x = 4; x < S - 4; x++) {
        p.px(x, y, hexToRgb(PALETTE.SHADOW_BLACK[1]));
        p.px(x, y + 1, hexToRgb(PALETTE.SHADOW_BLACK[0]));
        p.px(x, y + 2, shade(ramp[2], 1.2));
        p.addH(x, y, -0.6); p.addH(x, y + 1, -0.6); p.addH(x, y + 2, 0.25); // slats
      }
    }
    p.outline(0, 0, S, S, shade(ramp[0], 0.6));
    for (const [bx, by] of [[2, 2], [S - 4, 2], [2, S - 4], [S - 4, S - 4]]) p.bolt(bx, by);
    // Wire mesh behind the louvres — visible in the gaps, which is what makes a
    // grille read as something with a duct behind it rather than a striped plate.
    for (let y = 4; y < S - 4; y++) {
      for (let x = 4; x < S - 4; x++) {
        if ((y - 6) % 6 < 3) continue;      // hidden behind a slat
        if (((x + y) & 3) && ((x - y) & 3)) continue;
        p.px(x, y, shade(p.get(x, y), 1.2));
        p.addH(x, y, -0.15);
      }
    }
    this._sculpt(p, seed, { pits: 8, bloom: 2, cavity: 0.26, contact: 0.3 });
    return p;
  }

  /** In-fiction sepia schematic poster of the Aethon (context/01 §7). */
  posterSchematic() {
    const p = this._painter();
    // aged paper: warm dark sepia derived from the amber family
    const paper = [shade(hexToRgb(PALETTE.AMBER_MACHINE[0]), 0.45),
      shade(hexToRgb(PALETTE.AMBER_MACHINE[0]), 0.7),
      shade(hexToRgb(PALETTE.AMBER_MACHINE[1]), 0.75)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(paper, (x, y) => {
      const cx = (x - 32) / 32, cy = (y - 32) / 32;
      const vign = 1 - 0.5 * (cx * cx + cy * cy); // vignette toward edges
      return (0.45 + 0.25 * fbm2(x * 0.1, y * 0.1, seed, 3)) * vign + 0.1;
    });
    const ink = shade(hexToRgb(PALETTE.SHADOW_BLACK[0]), 1.4);
    // cruciform deck outline — fore at top
    p.outline(26, 4, 12, 8, ink); // cockpit
    p.outline(24, 13, 16, 10, ink); // quarters block
    p.outline(22, 24, 20, 8, ink); // med/galley block
    p.outline(24, 33, 16, 7, ink); // lab/core
    p.outline(18, 41, 28, 12, ink); // cargo (widest)
    p.outline(24, 54, 16, 6, ink); // workshop/reactor
    for (let y = 12; y < 54; y++) p.px(32, y, ink); // spine
    // wing branches (cruciform)
    for (let x = 10; x < 54; x++) p.px(x, 46, ink);
    p.outline(6, 42, 6, 8, ink); p.outline(52, 42, 6, 8, ink);
    // greeked labels — dashes suggesting stenciled text
    for (const [lx, ly, lw] of [[8, 6, 12], [44, 8, 14], [8, 20, 10], [44, 26, 12], [8, 56, 14]]) {
      for (let x = 0; x < lw; x++) if ((x & 3) !== 3) p.px(lx + x, ly, ink);
    }
    // was (8, 58): ran off the right edge AND had its lower rows cut by the
    // bottom edge (a glyph is 7 rows, so y must be <= 57)
    p.text(this.font, 2, 55, 'HSV AETHON', shade(hexToRgb(PALETTE.SHADOW_BLACK[0]), 1.2));
    p.darkenEdges(3, 0.6);
    return p;
  }

  /** Starfield seen through the cockpit windshield — emissive. */
  windowStarfield() {
    const p = this._painter();
    const space = rampOf(PALETTE.DEEP_SPACE);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(space, (x, y) => 0.3 + 0.3 * valueNoise2(x * 0.05, y * 0.05, seed));
    // faint nebula wash, dithered
    p.ditherOver(hexToRgb(PALETTE.NEBULA[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.04, y * 0.04, seed + 3, 3) - 0.55) * 0.9);
    p.ditherOver(hexToRgb(PALETTE.NEBULA[2]), (x, y) =>
      Math.max(0, fbm2(x * 0.05 + 7, y * 0.05, seed + 4, 3) - 0.62) * 0.8);
    const r = p.rng;
    for (let i = 0; i < 60; i++) {
      const x = r.int(0, 63), y = r.int(0, 63);
      const bright = r.chance(0.2);
      p.px(x, y, bright ? [232, 232, 240] : [150, 150, 165]);
      if (bright && r.chance(0.5)) { p.px(x + 1, y, [120, 120, 135]); }
    }
    return p;
  }

  suitRack() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.25 * fbm2(x * 0.08, y * 0.08, seed, 3));
    // one hung EVA suit, worn off-white
    const suit = [shade(hexToRgb(PALETTE.PANEL_STEEL[2]), 1.1), shade(hexToRgb(PALETTE.PANEL_STEEL[2]), 1.35),
      shade(hexToRgb(PALETTE.PANEL_STEEL[1]), 0.9)];
    const body = (x, y) => {
      const helmet = Math.hypot(x - 32, y - 12) < 7;
      const torso = x > 22 && x < 42 && y > 18 && y < 42;
      const legs = ((x > 24 && x < 30) || (x > 34 && x < 40)) && y >= 42 && y < 58;
      const arms = ((x > 15 && x <= 22) || (x >= 42 && x < 49)) && y > 20 && y < 38;
      return helmet || torso || legs || arms;
    };
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        if (!body(x, y)) continue;
        const v = 0.45 + 0.3 * fbm2(x * 0.12, y * 0.12, seed + 2, 2);
        const t = v * 2;
        let idx = Math.floor(t);
        if (t - idx > bayerT(x, y)) idx++;
        p.px(x, y, suit[Math.min(idx, 2)]);
      }
    }
    // visor — amber glint
    p.rect(28, 9, 8, 5, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    p.px(30, 10, hexToRgb(PALETTE.AMBER_MACHINE[2]));
    // chest patch + mount bar
    p.rect(29, 22, 6, 4, hexToRgb(PALETTE.AMBER_MACHINE[0]));
    for (let x = 20; x < 44; x++) { p.px(x, 4, shade(ramp[2], 1.3)); p.addH(x, 4, 0.9); }
    // The suit stands off the rack behind it, and its own limbs are rounded:
    // height falls away from the centre line of each part, so the contact pass
    // puts a shadow on the bulkhead and the cavity pass rolls the torso.
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        if (!body(x, y)) continue;
        const roll = Math.max(0, 1 - Math.abs(x - 32) / 12);
        p.addH(x, y, 0.8 + roll * 0.6);
      }
    }
    // Ribbed joint bellows at the elbows and knees, and a domed helmet crown.
    for (const [jx, jy] of [[17, 28], [45, 28], [26, 48], [36, 48]]) p.ribbedBand(jx, jy, 5, 6, 2, 0.3, true);
    p.roundBoss(32 * TX, 12 * TX, 7 * TX, 1.1);
    p.rect(28, 9, 8, 5, hexToRgb(PALETTE.SHADOW_BLACK[0])); // re-lay the visor over the dome
    p.px(30, 10, hexToRgb(PALETTE.AMBER_MACHINE[2]));
    this._sculpt(p, seed, { pits: 8, bloom: 2, cavity: 0.2, contact: 0.3 });
    return p;
  }

  /**
   * Washroom ceramic in RUNNING BOND. This one keeps its material — a washroom
   * really is tiled, and replacing that with plating would be wrong for the room
   * — but it does not keep the graph paper. It was an 8px grid both ways, i.e.
   * an 8×8 block of identical squares repeating every 2m.
   *
   * Courses of uneven height, each offset by half a tile or so, low-contrast
   * grout, per-tile glaze variation, and a handful of tiles that are cracked,
   * discoloured or clearly replacement stock. Subway tile in running bond is
   * both the more accurate reference and not a lattice.
   */
  fixtureWhite() {
    const p = this._painter();
    const ramp = [hexToRgb(PALETTE.PANEL_STEEL[1]), hexToRgb(PALETTE.PANEL_STEEL[2]),
      shade(hexToRgb(PALETTE.PANEL_STEEL[2]), 1.35)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.45 + 0.22 * valueNoise2(x * 0.15, y * 0.15, seed)
      + 0.14 * fbm2(x * 0.05, y * 0.05, seed + 3, 3));
    // Grout barely darker than the glaze — a dark line round every tile is what
    // turns tiling into a drawn grid. 0.86 was still enough contrast to outline
    // every unit, which combined with the wide glaze spread below to make the
    // washroom read as breeze block rather than ceramic.
    const grout = shade(ramp[0], 0.94);
    const courses = [7, 9, 8, 10, 7, 9, 7, 7]; // 64
    let y0 = 0;
    for (let c = 0; c < courses.length; c++) {
      const y1 = y0 + courses[c];
      // Shallow relief. NORMAL_STRENGTH is 2.05, so a -0.34 step becomes a
      // pronounced bevel and every unit read as a block with depth rather than a
      // flush glazed tile. -0.18 still catches the light along a joint.
      for (let x = 0; x < S; x++) { p.px(x, y0, grout); p.addH(x, y0, -0.18); }
      let x0 = (c * 5 + (seed % 4)) % 9; // half-tile stagger per course
      while (x0 < S) {
        const w = 8 + ((x0 + c * 3 + seed) % 3); // 8..10
        for (let y = y0 + 1; y < y1 && y < S; y++) {
          p.px(x0 % S, y, grout); p.addH(x0 % S, y, -0.16);
        }
        // Per-tile glaze, NARROW. The first pass ran 0.86..1.09 with two outlier
        // shades, which is a 27% spread — every unit read as a distinct block and
        // the room came out as masonry instead of tiling. Matching ceramic wants
        // barely-there variation; the dirt below supplies the character.
        const r = (x0 * 11 + c * 7 + seed) % 11;
        const k = r === 0 ? 0.955 : 0.985 + (r % 4) * 0.009;
        for (let y = y0 + 1; y < y1 && y < S; y++) {
          for (let x = x0 + 1; x < x0 + w; x++) p.px(x % S, y, shade(p.get(x % S, y), k));
        }
        // No cracks. A crack is a shape you recognise, and `r` is deterministic in
        // x0 and course, so the SAME tiles cracked in every copy of the tile — the
        // washroom grew a row of identical stair-step marks marching along the
        // wall, which is precisely the failure this whole pass exists to remove.
        // Nothing localised and legible survives on a texture that repeats.
        x0 += w;
      }
      y0 = y1;
    }
    // A stainless trim band where the tiling meets the bulkhead, with its own
    // fixing screws — tiling that runs edge to edge with no termination detail is
    // the thing that made this room read as bare.
    const trim = shade(hexToRgb(PALETTE.PANEL_STEEL[2]), 1.15);
    for (let y = 30; y < 33; y++) {
      for (let x = 0; x < S; x++) {
        p.px(x, y, shade(trim, y === 30 ? 1.1 : y === 32 ? 0.86 : 1.0));
        p.addH(x, y, y === 31 ? 0.4 : 0.2);
      }
    }
    p.rivetRun(2, 31, S - 2, 31, 8, seed + 61);
    // Ceramic wears differently from steel: no rust, little denting, but heavy
    // limescale and a chipped glaze at the edges.
    this._finish(p, ramp, seed, {
      grain: 0.045, chips: 18, hair: 14, dent: 4, wear: 0.4, rust: 0.35, runs: 3,
      grainAx: 0.8, grainAy: 0.8,
      // Glaze is poured, not cast, and rust cannot bloom under it — but a
      // ceramic edge chips deeply, so the cavity term goes UP, not down.
      pits: 5, bloom: 1, cavity: 0.24,
    });
    return p;
  }

  shelfStorage() {
    const p = this._painter();
    const dark = rampOf(PALETTE.SHADOW_BLACK.slice(0, 2)).concat([hexToRgb(PALETTE.FLOOR_GRIME[1])]);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(dark, (x, y) => 0.3 + 0.2 * valueNoise2(x * 0.1, y * 0.1, seed));
    const r = p.rng;
    for (let shelfY = 2; shelfY < S - 8; shelfY += 16) {
      // boxes/canisters on shelf
      let x = 2;
      while (x < S - 8) {
        const w = r.int(6, 12), h = r.int(7, 11);
        const fam = rampOf(r.pick([PALETTE.PANEL_STEEL, PALETTE.METAL_DARK, PALETTE.RUST]));
        for (let bx = 0; bx < w; bx++) for (let by = 0; by < h; by++) {
          const t = by === 0 ? 2 : bx === w - 1 ? 0 : 1;
          p.px(x + bx, shelfY + (12 - h) + by, fam[t]);
        }
        if (r.chance(0.5)) p.text(this.font, x + 1, shelfY + 12 - h + 2, String(r.int(1, 9)), hexToRgb(PALETTE.AMBER_MACHINE[0]));
        x += w + r.int(1, 4);
      }
      for (let sx = 0; sx < S; sx++) {
        p.px(sx, shelfY + 13, hexToRgb(PALETTE.PANEL_STEEL[1]));
        p.px(sx, shelfY + 14, hexToRgb(PALETTE.SHADOW_BLACK[0]));
        p.addH(sx, shelfY + 13, 0.8); p.addH(sx, shelfY + 14, 0.3);
        for (let by = 1; by < 13; by++) p.addH(sx, shelfY + by, 0.55); // the stock itself
      }
    }
    this._sculpt(p, seed, { pits: 10, bloom: 2, contact: 0.3 });
    return p;
  }

  craneMetal() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.AMBER_MACHINE).map((c) => shade(c, 0.85));
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.35 + 0.3 * valueNoise2(x * 0.06, Math.floor(y / 2) * 0.4, seed));
    const black = hexToRgb(PALETTE.SHADOW_BLACK[0]);
    for (let y = 0; y < 8; y++) for (let x = 0; x < S; x++) {
      if (((x + y) & 15) < 8) p.px(x, y, black);
    }
    for (let y = S - 8; y < S; y++) for (let x = 0; x < S; x++) {
      if (((x + y) & 15) < 8) p.px(x, y, black);
    }
    // An I-beam section: two proud flanges at the hazard bands and a recessed
    // web between them. The gantry was a flat painted strip; this makes it
    // structure that could actually carry the two and a half tonnes stencilled
    // on it.
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const flange = y < 10 || y >= S - 10;
        p.addH(x, y, flange ? 0.75 : -0.45);
      }
    }
    p.ribbedBand(0, 10, S, S - 20, 8, 0.25, true);
    for (let x = 8; x < S; x += 16) p.bolt(x, 30);
    for (let x = 4; x < S; x += 12) {
      p.screwHead(x * TX, 5 * TX, 'hex', 2 * TX, seed + x);
      p.screwHead(x * TX, (S - 6) * TX, 'hex', 2 * TX, seed + x * 3);
    }
    p.rustStreak(p.rng.int(6, 58), 8, 12, 0.7);
    this._stencil(p, 12, 34, 'MAX 2.5T', PALETTE.SHADOW_BLACK[0]);
    this._sculpt(p, seed, { pits: 18, bloom: 3, contact: 0.28 });
    return p;
  }

  panelWall() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.3 + 0.25 * fbm2(x * 0.08, y * 0.08, seed, 3));
    p.outline(2, 2, S - 4, S - 4, shade(ramp[0], 0.6));
    // breaker rows
    for (let gy = 8; gy < 40; gy += 10) {
      for (let gx = 8; gx < S - 10; gx += 9) {
        p.rect(gx, gy, 5, 7, shade(ramp[0], 0.7));
        const on = p.rng.chance(0.7);
        p.rect(gx + 1, on ? gy + 1 : gy + 4, 3, 2,
          on ? hexToRgb(PALETTE.AMBER_MACHINE[1]) : hexToRgb(PALETTE.WARNING_RED[0]));
      }
    }
    this._stencil(p, 6, 48, 'BUS 12/A', PALETTE.AMBER_MACHINE[0]);
    // hand-written note over the stencil — more honest than the branding
    p.rect(30, 46, 26, 11, shade(hexToRgb(PALETTE.AMBER_MACHINE[2]), 1.2));
    p.text(this.font, 32, 48, 'DONT', hexToRgb(PALETTE.SHADOW_BLACK[0]));
    for (const [bx, by] of [[4, 4], [S - 6, 4], [4, S - 6], [S - 6, S - 6]]) p.bolt(bx, by);
    // The breakers stand off the fascia and the recess they sit in is cut into
    // it, so each one throws a shadow onto the panel instead of being a coloured
    // rectangle printed on it.
    for (let gy = 8; gy < 40; gy += 10) {
      for (let gx = 8; gx < S - 10; gx += 9) {
        for (let by = gy; by < gy + 7; by++) for (let bx = gx; bx < gx + 5; bx++) p.addH(bx, by, -0.5);
        for (let by = gy + 1; by < gy + 6; by++) for (let bx = gx + 1; bx < gx + 4; bx++) p.addH(bx, by, 1.1);
      }
    }
    // A din-rail lip under each breaker row and the fixings holding the fascia.
    for (const ry of [7, 17, 27, 37]) p.ribbedBand(4, ry, S - 8, 1, 3, 0.4, true);
    for (const [sx, sy] of [[4, 4], [S - 6, 4], [4, S - 6], [S - 6, S - 6]]) {
      p.screwHead(sx * TX, sy * TX, 'slot', 2 * TX, seed + sx * sy);
    }
    this._sculpt(p, seed, { pits: 12, bloom: 2, cavity: 0.24, contact: 0.3 });
    return p;
  }

  /** Lit fluorescent tube lens — warm amber-white, dithered hot core. */
  lightTube() {
    const p = this._painter();
    const warm = [hexToRgb(PALETTE.AMBER_MACHINE[1]), hexToRgb(PALETTE.AMBER_MACHINE[2]),
      mixRgb(hexToRgb(PALETTE.AMBER_MACHINE[2]), [255, 250, 235], 0.7)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(warm, (x, y) => {
      const core = 1 - Math.abs(y - S / 2) / (S / 2);
      return core * (0.75 + 0.25 * valueNoise2(x * 0.05, y * 0.1, seed));
    });
    // end caps
    p.rect(0, 0, 3, S, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    p.rect(S - 3, 0, 3, S, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    return p;
  }

  /** Emergency lens — deep red, dimmer. */
  lightTubeRed() {
    const p = this._painter();
    const red = rampOf(PALETTE.WARNING_RED);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(red, (x, y) => {
      const core = 1 - Math.abs(y - S / 2) / (S / 2);
      return core * (0.6 + 0.3 * valueNoise2(x * 0.08, y * 0.1, seed));
    });
    p.rect(0, 0, 3, S, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    p.rect(S - 3, 0, 3, S, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    return p;
  }

  // -- space textures (standalone 2D textures, context/01 §9) ----------------------

  /** G-type star: granulated warm disc, dither-stepped corona (Sol Prime). */
  sunTexture(size = 512) {
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x501);
    const seed = rng.int(0, 9999);
    const core = hexToRgb('#e8e8f0'); // starlight white (context/01 §2 space table)
    const hot = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const mid = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const rim = hexToRgb(PALETTE.PLANET_LAVA[1]);
    const half = size / 2;
    const discR = size * 0.30;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - half, dy = y - half;
        const d = Math.hypot(dx, dy);
        const i = (y * size + x) * 4;
        if (d < discR) {
          // granulated surface: fbm mottling, warmer toward the rim
          const g = fbm2(x * 0.15, y * 0.15, seed, 3);
          const t = d / discR;
          let rgb;
          if (t < 0.45) rgb = g > 0.55 ? core : hot;
          else if (t < 0.8) rgb = g > 0.6 ? hot : mid;
          else rgb = g > 0.55 ? mid : rim;
          data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = 255;
        } else {
          // corona: ordered-dithered alpha steps, never a smooth ramp
          const fall = Math.max(0, 1 - (d - discR) / (half - discR));
          const steps = 5;
          const tq = fall * fall * steps;
          let lvl = Math.floor(tq);
          if (tq - lvl > bayerT(x, y)) lvl++;
          if (lvl > 0) {
            data[i] = mid[0]; data[i + 1] = mid[1]; data[i + 2] = mid[2];
            data[i + 3] = Math.min(200, lvl * 44);
          }
        }
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * The warp singularity: a hard black disc with a thin white-hot photon ring
   * and a dithered warm glow just outside it. Rendered as a billboard that
   * grows out of the ship's spine during the jump sequence.
   */
  blackHoleTexture(size = 512) {
    const data = new Uint8Array(size * size * 4);
    const ringIn = hexToRgb('#e8e8f0'); // starlight white — never neon
    const ringOut = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const glow = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const half = size / 2;
    const discR = size * 0.34; // event horizon
    // ring thickness has to scale with `size`, or raising the resolution just
    // makes the photon ring proportionally thinner until it disappears
    const ringW = size / 58;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const d = Math.hypot(x - half, y - half);
        const i = (y * size + x) * 4;
        if (d < discR) {
          data[i] = 2; data[i + 1] = 2; data[i + 2] = 4; data[i + 3] = 255; // the void
        } else if (d < discR + ringW) {
          const c = d < discR + ringW * 0.5 ? ringIn : ringOut; // photon ring
          data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2]; data[i + 3] = 255;
        } else {
          // dither-stepped warm glow falling off outside the ring
          const fall = Math.max(0, 1 - (d - discR) / (half - discR));
          const steps = 4;
          const tq = fall * fall * steps;
          let lvl = Math.floor(tq);
          if (tq - lvl > bayerT(x, y)) lvl++;
          if (lvl > 0) {
            data[i] = glow[0]; data[i + 1] = glow[1]; data[i + 2] = glow[2];
            data[i + 3] = Math.min(170, lvl * 40);
          }
        }
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * Equirect 3D star surface by spectral class (real stellar classification:
   * hotter = smoother + bluer, cooler = convective granulation + starspots).
   * Emissive — the space shader draws it unlit. 256×128 like planets.
   */
  starSurfaceTexture(classKey = 'G', frame = 0, frames = 1, w = 768, h = 384) {
    // Per-class photosphere. Base tints are the REAL blackbody colours (they
    // match STAR_TYPES in data/CelestialGen.js): the Sun's surface is very near
    // white, not egg-yolk yellow — the warmth comes from the cooler granulation
    // lanes and the limb, not from oversaturating the whole disc. `gran` is the
    // convection-cell scale (hot stars have shallow, fine cells; cool stars have
    // huge boiling ones), `spots` is magnetic activity.
    // `gran` is the convection-cell FREQUENCY around the equator — a real
    // photosphere is a dense carpet of small cells, so this has to be high or
    // the disc reads as a few huge smooth blobs. Hot stars have shallow
    // convection (finer, fainter cells); cool stars have deep, coarse ones.
    // ART DIRECTION over physics. Blackbody says a G star's photosphere is
    // near-white — and rendering that literally gave a washed-out cream disc
    // with no readable structure. The concept art is unambiguous: a SATURATED
    // orange-red sphere mottled with bright yellow granules and dark rust
    // patches. So each class keeps its spectral *identity* (blue-white O, deep
    // red M) but the palette is pushed hot and saturated, and the ramp spans a
    // hard 5-step range so every cell edge lands on a visible colour boundary.
    //   `c`   mid-tone body        `hot`  bright granule cores
    //   `deep`/`dark` cool lanes   `con`  ramp spread (contrast)
    const CLASSES = {
      O: { c: '#7f9cff', gran: 2.0, spots: 0.00, hot: '#dfe8ff', cool: '#3a4c9e', churn: 0.35, con: 1.0 },
      B: { c: '#8fabff', gran: 3.0, spots: 0.00, hot: '#e6ecff', cool: '#42569e', churn: 0.4, con: 1.0 },
      A: { c: '#bcd0ff', gran: 4.0, spots: 0.01, hot: '#ffffff', cool: '#6274b8', churn: 0.5, con: 1.0 },
      F: { c: '#ffe9b0', gran: 6.0, spots: 0.02, hot: '#fffbe8', cool: '#c07a35', churn: 0.6, con: 1.05 },
      // the Sun, styled to the concept: yellow-white cores, orange body, rust lanes
      G: { c: '#ff9d2e', gran: 9.0, spots: 0.06, hot: '#ffe97a', cool: '#a8280f', churn: 0.8, con: 1.15 },
      K: { c: '#ff7f22', gran: 11.0, spots: 0.09, hot: '#ffd455', cool: '#8f1f0c', churn: 0.9, con: 1.2 },
      M: { c: '#f2551a', gran: 13.0, spots: 0.15, hot: '#ffab3d', cool: '#6d1607', churn: 1.15, con: 1.3 },
      RG: { c: '#e8451a', gran: 5.0, spots: 0.12, hot: '#ff9a35', cool: '#5e1206', churn: 1.3, con: 1.35 },
      WD: { c: '#cfe0ff', gran: 1.5, spots: 0.00, hot: '#ffffff', cool: '#7c8fc4', churn: 0.25, con: 0.8 },
      KD: { c: '#d97a2a', gran: 10.0, spots: 0.18, hot: '#ffc061', cool: '#63190a', churn: 1.0, con: 1.25 },
      KM: { c: '#ff8f2a', gran: 10.0, spots: 0.10, hot: '#ffd970', cool: '#8a2410', churn: 0.95, con: 1.2 },
      // A star that never lit. No fusion, so no granulation — what you see is
      // weather: banded methane cloud over a dull maroon glow. Coarse cells,
      // heavy spotting, slow churn. Reads closer to a gas giant than to a sun,
      // which is the point.
      BD: { c: '#8a3320', gran: 4.5, spots: 0.24, hot: '#c86a34', cool: '#33100a', churn: 0.7, con: 1.4 },
      // Neutron star. Nothing about it is resolvable at any real scale, so this
      // is frankly a stylisation: a near-white surface with hard magnetic banding
      // and two blazing polar caps where the beams leave.
      NS: { c: '#cdd8ff', gran: 16.0, spots: 0.00, hot: '#ffffff', cool: '#4a5aa0', churn: 0.5, con: 1.1, caps: 0.11 },
    };
    const spec = CLASSES[classKey] ?? CLASSES.G;
    const base = hexToRgb(spec.c), hot = hexToRgb(spec.hot);
    // Explicit cool end (not a shade() of the body) so the intergranular lanes
    // are a genuinely different, deeper hue — that colour *break* is what makes
    // the granulation read as chunky blocks instead of a soft gradient.
    const coolC = hexToRgb(spec.cool);
    const mid = mixRgb(base, coolC, 0.28 * spec.con);
    const dark = mixRgb(base, coolC, 0.62 * spec.con);
    const deep = mixRgb(base, coolC, 0.92 * spec.con);
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0x57a2 + classKey.charCodeAt(0));
    const seed = rng.int(0, 9999);
    const core = shade(hot, 1.06);
    // Animation: walk the noise field around a CIRCLE in sample space, so the
    // last frame joins the first — the surface boils chaotically and loops
    // seamlessly instead of snapping back. Amplitude = how violently it churns.
    const ph = frames > 1 ? (frame / frames) * Math.PI * 2 : 0;
    // Churn amplitude scaled up: with more frames in the loop each step is a
    // smaller move through noise space, so without this the extra frames just
    // interpolate the same picture and the surface looks calmer, not livelier.
    const amp = spec.churn * 1.45;
    const ax = Math.cos(ph) * amp, ay = Math.sin(ph) * amp;
    // Sample EVERY texel at 512x256. The old 256x128 grid quantized to 2x2
    // blocks, which made granules read as coarse squares — at the disc sizes the
    // hull cam and a close approach produce, that came out as a handful of huge
    // pixels rather than a photosphere. Four times the texels, sampled one to
    // one, gives the same cell structure resolved finely enough to hold up when
    // the star fills the windshield. Cost is paid back by generating star
    // surfaces per-class on demand (main.js) instead of all eleven at boot.
    const CH = 1;
    for (let y = 0; y < h; y++) {
      const qy = Math.floor(y / CH) * CH;
      const lat = qy / h;
      const sinLat = Math.max(0.18, Math.sin((y / h) * Math.PI)); // pole-safe stretch
      for (let x = 0; x < w; x++) {
        const qx = Math.floor(x / CH) * CH;
        const th = (qx / w) * Math.PI * 2;
        // sample on the parallel circle, frequency scaled by sin(lat) so cells
        // stay round at the poles instead of pinching into a pinwheel
        const nx = Math.cos(th) * spec.gran * sinLat, ny = Math.sin(th) * spec.gran * sinLat;
        /**
         * The churn phase is UNIFORM across latitude, and it has to be.
         *
         * Differential rotation was tried here first — advancing the noise phase
         * by a latitude-dependent amount so the equator would slide ahead of the
         * poles. It does not work, and the reason is worth recording: the whole
         * animation depends on walking a CLOSED CIRCLE in noise space so the last
         * frame rejoins the first. Scaling the phase by latitude means only the
         * bands at full scale complete the circle; everywhere else the loop ends
         * somewhere other than where it started and snaps on repeat.
         *
         * Differential rotation is a multi-day phenomenon and a 2.4-second loop
         * cannot carry it. It belongs in the renderer, as a latitude-dependent
         * shift of the sampling longitude — see u_diffRot in space.frag, which
         * has no loop to close because it is a continuous shear on a texture that
         * is periodic in longitude.
         */
        const g = fbm2(nx + 9 + ax, ny + lat * spec.gran * 2.2 + ay, seed, 4);
        // micro-granulation: a finer cell carpet inside the big cells, so the
        // surface still has structure when the star fills the windshield
        const micro = fbm2(nx * 2.7 + 31 + ax * 1.5, ny * 2.7 + lat * 5 + ay * 1.5, seed + 61, 3);
        // fine faculae churn at ~2x the cell rate (hotter, faster structure)
        const fine = fbm2(nx * 3.2 + ax * 2, ny * 3.2 + lat * 8 + ay * 2, seed + 5, 2);
        // supergranulation lanes: a larger, slower network of dark channels
        const lane = fbm2(nx * 0.55 + 77 + ax * 0.4, ny * 0.55 + lat * 2 + ay * 0.4, seed + 23, 2);
        // Intergranular filigree — only worth computing at the 512x256 grid: at
        // 2x2-block sampling this was smaller than one block and averaged away.
        // It's what gives the disc texture between the cells instead of flats.
        const grain = fbm2(nx * 6.1 + 13 + ax * 2.6, ny * 6.1 + lat * 13 + ay * 2.6, seed + 97, 2);
        let rgb = g > 0.66 ? core : g > 0.55 ? hot : g > 0.44 ? base : g > 0.34 ? mid : dark;
        // micro cells nudge each patch one step up/down the ramp — this is what
        // turns smooth blobs into a boiling carpet
        if (micro > 0.63) rgb = shade(rgb, 1.07);
        else if (micro < 0.37) rgb = warmShade(rgb, 0.88);
        if (lane < 0.34) rgb = warmShade(rgb, 0.72); // convection lane shadows
        // MAGNETIC NETWORK: flux is swept to the edges of supergranulation cells
        // and concentrates there, so the cell BOUNDARIES are threaded with bright
        // points while the interiors are quiet. Keyed to the same `lane` field
        // that draws the cell shadows, one step outside them — the bright network
        // and the dark lane are the same structure seen at different field
        // strengths, so deriving both from one field is the honest way to do it.
        else if (lane > 0.34 && lane < 0.42 && spec.spots > 0.02) rgb = shade(rgb, 1.13);
        if (grain > 0.70) rgb = shade(rgb, 1.05);
        else if (grain < 0.30) rgb = warmShade(rgb, 0.93);
        if (fine > 0.8) rgb = core; // faculae sparks
        if (spec.spots > 0) {
          /**
           * ACTIVE REGIONS, with the structure a real one has.
           *
           * The old version was one threshold on one noise field, painting a
           * flat dark blob. A sunspot is not a blob: it is a dark UMBRA where
           * the magnetic field is vertical and strong enough to choke convection
           * outright, ringed by a lighter filamentary PENUMBRA where the field
           * is inclined and convection is only partly suppressed, and surrounded
           * by bright FACULAE — plage, where the same flux tubes are small
           * enough that the walls of the depression are seen instead of the
           * floor, so the region is *brighter* than the quiet photosphere.
           *
           * Spots also sit in ACTIVITY BELTS either side of the equator (the
           * butterfly diagram), never at the pole or on the equator itself, and
           * they live for weeks — far longer than the granulation — so they are
           * sampled WITHOUT the churn phase and stay put across the loop.
           */
          const belt = Math.abs(lat - 0.5);
          const inBelt = belt > 0.08 && belt < 0.38;
          if (inBelt) {
            const sp = fbm2(nx * 1.4 + 41, ny * 1.4 + lat * 4, seed + 11, 3);
            // one field, three thresholds — that is what makes the concentric
            // umbra/penumbra/faculae structure instead of a single dark patch
            const tUm = 1 - spec.spots * 1.15;
            const tPen = 1 - spec.spots * 2.3;
            const tFac = 1 - spec.spots * 3.1;
            if (sp > tUm) {
              rgb = warmShade(deep, 0.55); // umbra: convection stopped dead
            } else if (sp > tPen) {
              // penumbra: radial filaments, alternating bright and dark, which
              // is the actual visual signature of an inclined field
              const fil = fbm2(nx * 9.5 + 71, ny * 9.5 + lat * 17, seed + 19, 2);
              rgb = fil > 0.5 ? warmShade(base, 0.62) : warmShade(deep, 0.85);
            } else if (sp > tFac) {
              // faculae: BRIGHTER than the quiet sun, and the effect is
              // strongest near the limb, which the renderer's limb darkening
              // then partly cancels — as it does in reality
              const net = fbm2(nx * 6.2 + 13, ny * 6.2 + lat * 11, seed + 31, 2);
              if (net > 0.52) rgb = shade(rgb, 1.16);
            }
          }
        }
        if (spec.caps) {
          // magnetic polar caps — where a pulsar's beams leave the surface. Not
          // churned with the granulation: the field geometry is fixed.
          const pole = Math.min(lat, 1 - lat);
          if (pole < spec.caps) rgb = pole < spec.caps * 0.55 ? core : hot;
        }
        const i = (y * w + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = 255;
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * Cloud shell for atmospheric bodies — RGBA with real alpha, drawn as a
   * second sphere spinning faster than the surface (the repeating atmosphere
   * animation the owner asked for). Coverage/character per kind.
   */
  cloudTexture(kind = 'oceanic', frame = 0, frames = 1, w = 768, h = 384) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0xc10d + kind.length);
    const seed = rng.int(0, 9999);
    // per-kind weather: coverage, how hard the bands shear, churn violence and
    // the cloud-deck tint (ammonia gold on giants, water white on temperate)
    const SPEC = {
      oceanic: { cover: 0.55, shear: 2.2, churn: 0.55, hi: [238, 242, 248], lo: [198, 208, 222] },
      jungle: { cover: 0.5, shear: 2.6, churn: 0.6, hi: [232, 238, 236], lo: [188, 202, 200] },
      gas: { cover: 0.62, shear: 7, churn: 0.9, hi: [242, 228, 198], lo: [196, 168, 128] },
      // Near-total coverage: a Venus-analog is a featureless ochre ball from
      // orbit, and that opacity IS the read. Hard shear so the deck streaks.
      toxic: { cover: 0.98, shear: 4.6, churn: 0.7, hi: [212, 184, 128], lo: [170, 140, 88] },
      // thinner, colder weather than an ocean world — more gaps, less churn
      tundra: { cover: 0.44, shear: 1.9, churn: 0.45, hi: [234, 240, 246], lo: [190, 202, 216] },
    };
    const spec = SPEC[kind] ?? SPEC.oceanic;
    const { cover } = spec;
    // circular walk through noise space: the last frame joins the first, so the
    // deck churns and billows forever with no visible snap (the repeating
    // atmosphere animation) — see starSurfaceTexture for the same trick
    const ph = frames > 1 ? (frame / frames) * Math.PI * 2 : 0;
    const ax = Math.cos(ph) * spec.churn, ay = Math.sin(ph) * spec.churn;
    for (let y = 0; y < h; y++) {
      const lat = y / h;
      for (let x = 0; x < w; x++) {
        const th = (x / w) * Math.PI * 2;
        const shear = lat * spec.shear; // giants shear hard into zonal bands
        const nx = Math.cos(th) * 3.1, ny = Math.sin(th) * 3.1;
        const n = fbm2(nx + shear + ax, ny + lat * 6 + ay, seed, 4);
        const i = (y * w + x) * 4;
        if (n > 1 - cover * 0.85) {
          const thick = n > 1 - cover * 0.5;
          let c = thick ? spec.hi : spec.lo;
          let a = thick ? 235 : 150;
          if (kind === 'gas') {
            // storm curls: a second, faster-churning layer of turbulent eddies
            // riding the bands — this is what makes a giant look alive
            const eddy = fbm2(nx * 2.4 + shear * 1.6 + ax * 1.8, ny * 2.4 + ay * 1.8, seed + 31, 3);
            if (eddy > 0.74) { c = [252, 240, 214]; a = 245; } // bright ammonia upwelling
            else if (eddy < 0.3) { c = warmShade(spec.lo, 0.74); a = 190; } // dark belt trough
          }
          data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2]; data[i + 3] = a;
        }
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * Prominence / CME plasma blob — the building block of the coronal mass
   * ejection effect. A ragged, filamentary lump of hot plasma: white-hot core,
   * amber body, deep-red skirts, torn edges. Several of these chained along an
   * arc read as a real magnetic loop; a cluster flung outward reads as an
   * eruption. 2 frames so the filaments crawl.
   */
  plasmaTexture(frame = 0, tintHex = '#ffd9a0', size = 64) {
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x91a5 + frame);
    const seed = rng.int(0, 9999);
    const half = size / 2;
    // Ramp built FROM THE STAR'S OWN COLOUR, not a fixed amber/red: erupting
    // plasma is the photosphere thrown outward, so a blue-white giant must
    // throw blue-white filaments. A hard red skirt on every star read as a
    // foreign object stuck to the limb instead of part of the star.
    // Same saturation treatment as cmeTexture, and for the same reason: fed the
    // pale CORONA tint and then mixed three-quarters to white, a prominence
    // rendered as a grey-tan smudge sitting on the disc — it read as smoke on the
    // star rather than as the star's own plasma standing off the limb.
    const raw = hexToRgb(tintHex);
    const mx = Math.max(raw[0], raw[1], raw[2]);
    const tint = raw.map((c) => Math.max(0, Math.min(255, Math.round(mx - (mx - c) * 1.55))));
    const core = mixRgb(tint, [255, 250, 235], 0.3); // hot heart, not white-out
    const body = tint;
    const cool = warmShade(tint, 0.66); // cooling as it climbs
    const edge = warmShade(tint, 0.42); // thin, dim outer wisps
    // Density field first, ramp thresholds from its own percentiles second — see
    // cmeTexture for why. Hand-picked thresholds against this formula put every
    // texel inside d<0.3 on the brightest step, which is what made a prominence
    // read as one pale mass with a ramp only in its skirt.
    const field = new Float32Array(size * size);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = (x - half) / half, dy = (y - half) / half;
        const d = Math.hypot(dx, dy);
        if (d > 1) continue;
        // filamentary structure: stretched noise so the blob has strands, not
        // a smooth falloff — plasma follows magnetic field lines
        const fil = fbm2(x * 0.34 + frame * 11, y * 0.16, seed, 3);
        const v = (1 - d) * (0.55 + 0.75 * fil);
        if (v > 0) field[y * size + x] = v;
      }
    }
    const live = Array.from(field).filter((v) => v > 0).sort((a, b) => a - b);
    if (live.length < 8) return { width: size, height: size, data };
    const pct = (q) => live[Math.min(live.length - 1, Math.floor(live.length * q))];
    // a prominence is hotter in its middle than a CME cloud is: a wider hot core
    const tHot = pct(0.84), tBody = pct(0.58), tCool = pct(0.30), tFloor = pct(0.10);
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const v = field[y * size + x];
        if (v <= tFloor) continue; // tighter: less sprawl, hugs the arch
        let rgb, a;
        if (v > tHot) { rgb = core; a = 235; }
        else if (v > tBody) { rgb = body; a = 202; }
        else if (v > tCool) { rgb = cool; a = 154; }
        else { rgb = edge; a = 100; } // was a loud ember red at 120
        // dither the outer skirt so it dissolves in pixels, not a soft gradient
        const q = (v / tHot) * 6;
        if (v < tBody && (q - Math.floor(q)) < bayerT(x, y) * 0.8) a -= 54;
        if (a <= 0) continue;
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * DEFLECTOR IMPACT RIPPLE — the shockwave that crawls outward across the
   * shield from the point a round struck it.
   *
   * Drawn on a quad tangent to the bubble at the hit, scaled up over the ripple's
   * short life, so a hit is a LOCAL event on a surface rather than the whole
   * bubble flashing at once. The band carries the same hex facet grid as
   * shieldTexture so the ripple reads as energy running through the field's own
   * cells: hot seams where it crosses a facet edge, dimmer panes between.
   * Transparent core so the hull and the shell layers read through it.
   */
  shieldRippleTexture(size = 192) {
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x5217);
    const seed = rng.int(0, 9999);
    const hot = [206, 232, 255];
    const seam = [150, 198, 250];
    const pane = [72, 122, 200];
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - half, dy = y - half;
        const r = Math.hypot(dx, dy) / half;
        if (r > 0.98) continue;
        // the wavefront: a band at 0.66 with a short leading edge and a long
        // trailing wake, which is what makes it read as moving outward
        const front = r > 0.66 ? 1 - (r - 0.66) / 0.32 : 1 - (0.66 - r) / 0.62;
        if (front <= 0) continue;
        // hex facet cells, matching shieldTexture's 32x16 offset-row grid
        const row = Math.floor(y / 16);
        const gx = (x + (row % 2) * 16) % 32, gy = y % 16;
        const onSeam = gx < 3 || gy < 3;
        const shimmer = fbm2(x * 0.17, y * 0.17, seed, 2);
        let v = front * front * (onSeam ? 1.0 : 0.42) * (0.6 + 0.7 * shimmer);
        // radial spokes: the wave discharges along the facet lattice
        const ang = Math.atan2(dy, dx);
        const spoke = Math.abs(((ang / (Math.PI / 3)) % 1 + 1) % 1 - 0.5) * 2;
        v *= 0.78 + 0.5 * (1 - spoke) * front;
        if (v < 0.14) continue;
        let rgb, a;
        if (v > 0.66) { rgb = hot; a = 236; }
        else if (v > 0.4) { rgb = seam; a = 190; }
        else { rgb = pane; a = 120; }
        const q = v * 5;
        if (q - Math.floor(q) < bayerT(x, y) * 0.85) a -= 66;
        if (a <= 6) continue;
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * PLASMA THREAD — the single primitive the coronal mass ejection is built from,
   * and a deliberate replacement for the blob sprite that came before it.
   *
   * The old CME was three shells of round, cloudy sprites. The owner's verdict was
   * that it looked nothing like the real thing, and that is right: a coronagraph
   * image of a CME is not cloud. It is STRUCTURE — a taut bright leading arc with
   * long thin threads of plasma streaming behind it along magnetic field lines,
   * a dark evacuated cavity, and a twisted rope of intertwined strands at the core.
   * Nothing in it is a circle. Building it out of round sprites guarantees it reads
   * as smoke however they are arranged, which is exactly what happened.
   *
   * So this sprite is a THREAD: tall, narrow, brightest along a single off-centre
   * spine, frayed at both ends, with fine cross-cut breaks so a long chain of them
   * reads as one filament rather than as a dotted line. The renderer stretches and
   * ORIENTS it along the local field direction (see SpaceRenderer._spriteStreak),
   * which is the capability the old axis-aligned sprite batch simply did not have.
   *
   * Deliberately coarse: 16 wide by 64 tall, and every sample snaps to a 2-texel
   * block, so the thread is 8x32 of actual art. At the sizes these are drawn the
   * pixels stay fat.
   *
   * @param {number} frame animation frame — the spine wanders between frames
   * @param {string} tintHex the star's own colour, saturated by the caller
   * @param {'core'|'wisp'} weight core threads are brighter and wider
   */
  filamentTexture(frame = 0, tintHex = '#ffd9a0', weight = 'core', w = 16, h = 64) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0xf11a + frame * 13 + (weight === 'core' ? 0 : 977));
    const seed = rng.int(0, 9999);
    const blk = 2;
    // Saturate away from the pale corona tint, same reasoning as the prominences:
    // erupting plasma is photosphere thrown outward, not halo light.
    const raw = hexToRgb(tintHex);
    const mx = Math.max(raw[0], raw[1], raw[2]);
    const tint = raw.map((c) => Math.max(0, Math.min(255, Math.round(mx - (mx - c) * 1.55))));
    const hot = mixRgb(tint, [255, 250, 238], 0.42);
    const body = tint;
    const cool = warmShade(tint, 0.6);
    const edge = warmShade(tint, 0.34);
    const wide = weight === 'core' ? 0.30 : 0.19; // fraction of width the spine fills

    for (let y = 0; y < h; y++) {
      const by = Math.floor(y / blk) * blk + blk * 0.5;
      const v = by / h;                       // 0 at the anchored end, 1 at the tip
      // The spine WANDERS. A straight bright line is a laser, not plasma; a real
      // filament meanders because it is following a field line.
      const wander = (fbm2(by * 0.13, frame * 31, seed, 3) - 0.5) * 0.42;
      // Taper: thin where it is anchored, thinnest at the tip, fattest a third up.
      const taper = Math.sin(Math.min(1, v * 1.15) * Math.PI) * 0.75 + 0.25;
      // Breaks: short gaps along the thread so it reads as a strand of separate
      // knots rather than a drawn stroke.
      const brk = fbm2(by * 0.42 + frame * 7, 11.5, seed + 313, 2);
      for (let x = 0; x < w; x++) {
        const bx = Math.floor(x / blk) * blk + blk * 0.5;
        const u = bx / w - 0.5 + wander;      // signed distance from the spine
        const half = wide * taper;
        const d = Math.abs(u) / Math.max(0.02, half);
        if (d > 1) continue;
        let val = (1 - d * d) * (0.55 + 0.7 * brk);
        // fray the very ends so the chain does not terminate on a flat edge
        if (v > 0.86) val *= (1 - v) / 0.14;
        if (v < 0.06) val *= v / 0.06;
        if (val < 0.16) continue;
        let rgb, a;
        if (val > 0.74) { rgb = hot; a = 240; }
        else if (val > 0.52) { rgb = body; a = 206; }
        else if (val > 0.32) { rgb = cool; a = 158; }
        else { rgb = edge; a = 104; }
        // dither on the BLOCK grid so the dissolve is as chunky as the thread
        const q = val * 5;
        if (q - Math.floor(q) < bayerT(Math.floor(x / blk), Math.floor(y / blk)) * 0.8) a -= 58;
        if (a <= 6) continue;
        const i = (y * w + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: w, height: h, data };
  }

  /** Spectral tint per class — shared by the corona and the CME plasma. */
  static starTint(classKey) {
    const TINT = { O: '#9bb0ff', B: '#aabfff', A: '#dbe4ff', F: '#f8f7ff', G: '#ffd9a0',
      K: '#ffc27a', M: '#ff9d55', RG: '#ff9955', WD: '#dfe8ff', KD: '#d89a66', KM: '#ffc890',
      BD: '#a04a28', NS: '#c8d6ff' };
    return TINT[classKey] ?? TINT.G;
  }

  /**
   * Per-class corona halo: a tight, rayed glow tinted by the photosphere —
   * replaces the old blotchy generic sun billboard around the 3D star.
   */
  coronaTexture(classKey = 'G', size = 384) {
    const tint = hexToRgb(TextureFactory.starTint(classKey));
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0xc0a + classKey.charCodeAt(0));
    const seed = rng.int(0, 9999);
    const half = size / 2, discR = size * 0.30;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - half, dy = y - half;
        const d = Math.hypot(dx, dy);
        const i = (y * size + x) * 4;
        if (d <= discR) continue; // the 3D sphere covers the disc
        const ang = Math.atan2(dy, dx);
        // streamer rays: brightness varies with angle, like a real corona
        const ray = 0.7 + 0.3 * fbm2(Math.cos(ang) * 2.4 + 9, Math.sin(ang) * 2.4, seed, 3);
        const fall = Math.max(0, 1 - (d - discR) / (half - discR));
        // Tighter falloff + a bright inner COLLAR hugging the limb. The concept
        // art's corona is a definite dithered ring of hot colour around the
        // disc, not a soft haze that fades to nothing — so the first ~25% of
        // the falloff stays near full strength before it breaks up.
        const collar = Math.max(0, 1 - (d - discR) / (discR * 0.42));
        const v = Math.min(1, Math.pow(fall, 3.2) * ray + collar * collar * 0.85 * ray);
        const steps = 6; // fewer, harder steps = chunkier dithered banding
        let lvl = Math.floor(v * steps);
        if (v * steps - lvl > bayerT(x, y)) lvl++;
        if (lvl <= 0) continue;
        // the ring runs hot near the limb and cools outward into deep ember
        const t = Math.min(1, lvl / steps);
        const c = mixRgb(warmShade(tint, 0.55), tint, t);
        data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2];
        data[i + 3] = Math.min(225, lvl * 42);
      }
    }
    return { width: size, height: size, data };
  }

  /** Dithered nebula wash billboard. variant selects the palette tone. */
  nebulaTexture(variant = 0, size = 640) {
    // 320, not 128: each nebula billboard covers a big slice of the sky, so a
    // 128px sheet stretched across it resolved into a handful of enormous
    // blocks. The cloud frequencies below scale with `size` so the structure
    // stays the same shape — there is just far more of it.
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x11e + variant);
    const seed = rng.int(0, 9999);
    const tone = hexToRgb(PALETTE.NEBULA[variant % PALETTE.NEBULA.length]);
    const deep = hexToRgb(PALETTE.DEEP_SPACE[1]);
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const d = Math.hypot(x - half, y - half) / half;
        const mask = Math.max(0, 1 - d); // soft radial cutoff, then dithered
        const F = 128 / size; // keep the cloud the same size on screen at any res
        const cloud = Math.max(0, fbm2(x * 0.045 * F, y * 0.045 * F, seed, 5) - 0.42) * 1.8;
        const v = cloud * mask;
        const steps = 4;
        const tq = v * steps;
        let lvl = Math.floor(tq);
        if (tq - lvl > bayerT(x, y)) lvl++;
        if (lvl <= 0) continue;
        const rgb = lvl >= 3 ? tone : mixRgb(deep, tone, lvl / 3);
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2];
        data[i + 3] = Math.min(150, lvl * 38);
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * Equirect planet surface. kind ∈ {oceanic, rocky, ice, lava, gas, jungle}.
   * Now rendered at 256×128 with layered detail (continents + coastlines +
   * cloud decks; banded giants with domain-warped turbulence + storm ovals;
   * cratered rock; glowing lava fissure networks) for a realistic look now that
   * bodies fill the view. Noise is sampled on a longitude circle so it wraps
   * seamlessly; shade steps stay chunky (no smooth gradients).
   */
  /**
   * Equirectangular planet surface, coloured from the PHYSICAL MODEL in
   * data/Planetology.js rather than a per-kind noise recipe.
   *
   * The old version was a chain of if-blocks — one hand-tuned formula per body
   * kind — and every feature in it was decorative: mountains sat wherever the
   * noise peaked, deserts wherever it dipped, ice wherever the latitude band said
   * so. Nothing had a cause and nothing agreed with anything else.
   *
   * Now a `PlanetSurface` runs plate tectonics, orography, a moisture cycle and
   * flow accumulation on a 144x72 grid, and this function's only job is to LOOK
   * UP each texel's biome and paint it. That means the mountain ranges lie along
   * convergent plate boundaries, the deserts lie downwind of those ranges, the
   * rivers run downhill into the sea, and the ice reaches as far as the
   * temperature field says it does — on every body kind, including the ones that
   * have no water at all, because their geology comes out of the same tectonics.
   *
   * Three layers of detail sit on top of the grid lookup:
   *   1. a domain WARP on the sample coordinate, so a 144-cell grid does not
   *      show as 2.7-texel blocky biome edges — the boundaries dissolve into
   *      organic coastlines at texture resolution
   *   2. within-biome variation, so a forest is many greens and not one
   *   3. relief shading from the bilinear elevation slope, lit from the
   *      north-west, which is what makes the ranges read as ranges
   *
   * @param {string} kind body kind (see Planetology.PLANET_SPEC)
   * @param {number} w texture width
   * @param {number} h texture height
   * @param {number} seed per-body seed, so two ice moons are not identical
   */
  planetTexture(kind, w = 768, h = 384, seed = 0) {
    // A gas giant has no crust, so there is nothing for the planetology model to
    // simulate — no plates, no hydrology, no biomes. It gets its own generator
    // built on the physics that actually shapes it: zonal jets.
    if (kind === 'gas') return this._gasGiantTexture(w, h, seed);
    const K = PLANET_SPEC[kind] ? kind : 'rocky';
    const surf = planetSurface(K, (seed || SURFACE_SEED[K] || 0x51a2) >>> 0);
    const spec = surf.spec;
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0x9e11 + K.length * 31 + (seed & 0xffff));
    const nseed = rng.int(0, 9999);
    const B = BIOME;

    // How hard to warp the biome lookup. Enough to break the grid, not so much
    // that a continent's outline stops matching its elevation field.
    const WARP = 0.9 / GW;

    for (let y = 0; y < h; y++) {
      const v = (y + 0.5) / h;
      // the sphere pinches at the poles, so the longitude warp has to pinch too
      // or the north pole tears into a pinwheel
      const pinch = Math.max(0.15, Math.sin(v * Math.PI));
      for (let x = 0; x < w; x++) {
        const u = (x + 0.5) / w;
        const i = (y * w + x) * 4;

        // -- domain warp, sampled on the longitude circle so it wraps ---------
        const th = u * Math.PI * 2;
        const cx = Math.cos(th) * 3.4, cy = Math.sin(th) * 3.4;
        const wx = fbm2(cx + 3, cy + v * 7.1, nseed, 4) - 0.5;
        const wy = fbm2(cx + 41, cy + v * 7.1 + 19, nseed + 7, 4) - 0.5;
        const su = u + (wx * WARP * 5.5) / pinch;
        const sv = clamp01(v + wy * WARP * 3.0);

        const cell = surf.cellAt(su - Math.floor(su), sv);
        const biome = surf.biome[cell];
        const ramp = BIOME_RAMP_X[biome] ?? BIOME_RAMP_X[B.BARE_ROCK];

        // -- within-biome variation -------------------------------------------
        // two octaves at different scales so the surface has both patches and
        // grain; the ramp index is quantized, keeping hard pixel-art steps
        const coarse = fbm2(cx * 2.1 + 61, cy * 2.1 + v * 9, nseed + 13, 3);
        const fine = fbm2(cx * 7.5 + 11, cy * 7.5 + v * 23, nseed + 29, 2);
        let t = coarse * 0.62 + fine * 0.38;

        // -- relief shading ----------------------------------------------------
        // bilinear elevation either side of the texel, lit from the north-west.
        // This is the single thing that makes a mountain belt look like terrain
        // rather than a colour change.
        const e = surf.elevationAt(su - Math.floor(su), sv);
        const eL = surf.elevationAt(su - Math.floor(su) - 1.4 / GW, sv);
        const eU = surf.elevationAt(su - Math.floor(su), clamp01(sv - 1.4 / GH));
        const slope = (e - eL) * 0.6 + (e - eU) * 0.4;
        // Gain kept low deliberately: a crater rim steps ~0.5 of elevation in a
        // single cell, so at the first value (4.2) this term pinned its own clamp
        // on every rim and then double-counted with the ring shading below —
        // regolith came out as black holes in a blown-out field.
        t += clamp(slope * 2.2, -0.28, 0.28);

        // altitude bleaching: high ground is paler (thinner air, exposed rock,
        // snow) on anything with an atmosphere
        if (spec.pressure > 0.02 && e > 0) t += Math.min(0.3, e * 0.55);

        let rgb = ramp[clamp(Math.round(clamp01(t) * (ramp.length - 1)), 0, ramp.length - 1)];

        // -- features the grid is too coarse to carry --------------------------
        // Craters are drawn at TEXTURE resolution from the model's own impact
        // list, so the rim/floor structure resolves finely while still sitting
        // exactly where the elevation field put the basin.
        if (spec.cratering > 0.2) {
          const cr = this._craterRings(u, v, surf, nseed);
          if (cr === 1) rgb = shade(rgb, 0.70); // shadowed floor
          else if (cr === 2) rgb = shade(rgb, 1.26); // sunlit rim
          else if (cr === 3) rgb = shade(rgb, 1.09); // ejecta apron
        }

        // active volcanism: incandescent cracks, only in the hot biomes
        if ((biome === B.LAVA_FIELD || biome === B.LAVA_FLOW) && spec.volcanism > 0.5) {
          const crack = fbm2(cx * 5.5 + 9, cy * 5.5 + v * 13, nseed + 41, 3);
          if (crack > 0.70) rgb = LAVA_GLOW[crack > 0.84 ? 2 : crack > 0.77 ? 1 : 0];
        }
        // ice worlds fracture in long parallel sets, which noise alone won't do
        if (biome === B.ICE_CRUST || biome === B.ICE_FRACTURE) {
          const band = Math.sin((cx * 2.2 + cy * 1.4 + v * 5) * 3.1);
          const fis = fbm2(cx * 3.2 + 77, cy * 3.2 + v * 8, nseed + 53, 2);
          if (Math.abs(band) > 0.93 && fis > 0.42) rgb = shade(BIOME_RAMP_X[B.ICE_FRACTURE][0], 0.85);
        }
        // metallic sheen: a stepped specular band, so a stripped core reads as
        // metal and not as grey rock
        if (biome === B.METAL_PLAIN || biome === B.METAL_FRESH) {
          const sheen = fbm2(cx * 4.1 + 5, cy * 4.1 + v * 11, nseed + 67, 2);
          if (sheen > 0.72) rgb = shade(rgb, 1.22);
          else if (sheen < 0.28) rgb = shade(rgb, 0.84);
        }

        /**
         * WEATHER, on anything with enough air to have any (0.43.0).
         *
         * Everything above this line is the CRUST, and it is thoroughly
         * simulated — but a world with ninety bars of atmosphere showed you its
         * bedrock geology in perfect detail, which is exactly backwards: at that
         * pressure you would see cloud and nothing else. The absence was also
         * costing the sky-worlds their only source of large-scale contrast,
         * which is why a toxic world read as a smooth tan marble.
         *
         * Organised into LATITUDE BELTS rather than sprayed on, because that is
         * what circulation does to cloud: a band at the equator where air rises,
         * clear subtropics where it sinks, and mid-latitude storm tracks. The
         * cover is quantised into three steps and Bayer-thresholded, so it comes
         * in as dithered stipple and never as a soft alpha wash.
         */
        if (spec.pressure > 0.25) {
          const lat = (v - 0.5) * Math.PI;
          // Rising air at the equator and in the storm tracks, sinking between.
          const belt = 0.42 + 0.34 * Math.cos(lat * 6.0) + 0.30 * Math.cos(lat);
          // Sheared along longitude — cloud is stretched by the zonal wind.
          const deck = fbm2(cx * 1.9 + 131, cy * 1.9 + v * 5.5, nseed + 83, 4);
          const curl = fbm2(cx * 5.2 + 17, cy * 5.2 + v * 15, nseed + 97, 2);
          const cover = clamp01((deck * 0.72 + curl * 0.28) * belt * 2.0
            + Math.min(0.40, spec.pressure * 0.035) - 0.46);
          const step = Math.floor(cover * 3 + bayerT(x, y) * 0.999);
          if (step > 0) {
            // Cloud takes the world's own light, not a borrowed white: a
            // sulphuric deck is yellow-grey and an ammonia one is bone.
            const base = [
              Math.min(255, 172 + rgb[0] * 0.28),
              Math.min(255, 168 + rgb[1] * 0.28),
              Math.min(255, 156 + rgb[2] * 0.28),
            ];
            rgb = shade(base, 0.72 + step * 0.14);
          }
        }

        /**
         * AND THE GRAIN. The last step on every world, and the one that makes it
         * pixel art rather than a rendered ball.
         *
         * The biome ramps are short by design — four or five colours — so a
         * region that lands on one index comes out as a solid field of that
         * colour, and at 768x384 on a body filling half the frame those fields
         * are hundreds of screen pixels of flat colour. An ordered 4x4 threshold
         * against a per-texel hash steps each one up or down a value, and the
         * whole surface breaks into the stipple the rest of the game's textures
         * are made of.
         *
         * A HASH, not another octave of fbm. This runs on every texel of every
         * body in the system — four hundred thousand of them at boot — and two
         * more noise octaves there cost a measurable second of load. Hashed on
         * 2x2 blocks so the grain is chunky rather than television static, which
         * is also what the rest of the palette work does.
         */
        const hx = (x >> 1), hy = (y >> 1);
        const gh = ((Math.imul(hx * 73856093 ^ hy * 19349663 ^ nseed, 0x9e3779b1)
          >>> 8) & 0xffff) / 0xffff;
        const gt = gh - bayerT(x, y);
        if (gt > 0.16) rgb = shade(rgb, 1.16);
        else if (gt < -0.16) rgb = shade(rgb, 0.86);

        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = 255;
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * Banded gas giant, built from ZONAL JETS rather than a stack of stripes.
   *
   * The physics that matters: a giant's atmosphere organises into alternating
   * east-west jets, and the visible banding is those jets — bright ammonia
   * ZONES where gas is rising, dark BELTS where it is sinking. Adjacent jets run
   * in opposite directions, so the strongest shear is at their boundaries, and
   * that is exactly where the long-lived vortices sit (the Great Red Spot rides
   * a jet boundary). Modelling the jets and deriving everything from them gives
   * the shear, the festoon curls and the storm placement for free.
   *
   * Bands are narrower toward the poles because the Coriolis parameter rises
   * with latitude — that latitude-dependent width is a big part of why Jupiter
   * reads as Jupiter.
   */
  _gasGiantTexture(w = 768, h = 384, seed = 0) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0x6a5f + (seed & 0xffff));
    const nseed = rng.int(0, 9999);

    // Real Jovian colour: bright ammonia-cream zones against rust-brown belts.
    // The old table was all mid-browns and read as one muddy sphere.
    const ZONE = [[214, 198, 166], [232, 219, 190], [246, 236, 212]];
    const BELT = [[112, 74, 50], [148, 100, 66], [176, 124, 84]];
    const POLAR = [[92, 88, 96], [124, 118, 124], [152, 146, 150]]; // hazy, greyer

    // Jet structure: how many alternating bands from equator to pole, and which
    // way each one runs. An odd count keeps a broad prograde equatorial jet.
    const jets = 11 + rng.int(0, 5) * 2;

    // Long-lived vortices, placed ON jet boundaries where the shear is
    const storms = [];
    for (let k = 0, n = rng.int(2, 5); k < n; k++) {
      const jb = rng.int(1, jets - 1); // which boundary
      storms.push({
        lat: jb / jets, // 0 equator .. 1 pole, sign chosen below
        south: rng.chance(0.5),
        lon: rng.next(),
        rx: rng.range(0.035, 0.10),
        ry: rng.range(0.012, 0.032),
        dark: rng.chance(0.45),
      });
    }

    for (let y = 0; y < h; y++) {
      const v = (y + 0.5) / h;
      const lat = (0.5 - v) * 2; // -1 south .. +1 north
      const alat = Math.abs(lat);
      for (let x = 0; x < w; x++) {
        const u = (x + 0.5) / w;
        const th = u * Math.PI * 2;
        const cx = Math.cos(th), cy = Math.sin(th);
        const i = (y * w + x) * 4;

        // -- turbulent domain warp of the latitude coordinate -----------------
        // This is what shears the bands into wavy, interleaved streaks instead
        // of ruler-straight stripes. Warp strength scales with the local jet
        // shear, so the boundaries churn and the band centres stay laminar.
        const warpA = fbm2(cx * 2.6 + 5, cy * 2.6 + lat * 4.0, nseed, 4) - 0.5;
        const warpB = fbm2(cx * 6.2 + 31, cy * 6.2 + lat * 9.0, nseed + 11, 3) - 0.5;

        // band index: narrower toward the poles (Coriolis rises with latitude)
        const compress = 1 + alat * alat * 1.35;
        const bandF = lat * jets * 0.5 * compress + warpA * 1.25 + warpB * 0.45;
        const bi = Math.floor(bandF);
        const frac = bandF - bi; // 0..1 across the band
        const isZone = ((bi % 2) + 2) % 2 === 0;

        // -- colour: zone or belt, shaded across the band ----------------------
        // brightest at the band centre, darker at the sheared edges
        const centre = 1 - Math.abs(frac - 0.5) * 2;
        const grain = fbm2(cx * 9 + 61, cy * 9 + lat * 15, nseed + 23, 2);
        let t = centre * 0.62 + grain * 0.38;
        let ramp = isZone ? ZONE : BELT;
        // polar hoods: above ~70° the banding breaks down into haze
        if (alat > 0.84) {
          // ragged edge, but it must start above ~65 degrees or the hood eats a
          // quarter of the disc and the banding stops being the read
          const mix = clamp((alat - 0.84) / 0.16, 0, 1);
          if (mix > 0.4 + grain * 0.45) ramp = POLAR;
        }
        let rgb = ramp[clamp(Math.round(clamp01(t) * (ramp.length - 1)), 0, ramp.length - 1)];

        // -- festoon curls at the jet boundaries -------------------------------
        // where shear is highest, the two air masses interleave in hooks
        const edge = 1 - Math.abs(frac - 0.5) * 2;
        if (edge < 0.22) {
          const curl = fbm2(cx * 14 + 7, cy * 14 + lat * 21, nseed + 37, 3);
          if (curl > 0.68) rgb = shade(isZone ? BELT[2] : ZONE[0], 1.0);
          else if (curl < 0.3) rgb = shade(rgb, 0.86);
        }

        // -- storms: elliptical vortices riding the boundaries ------------------
        for (const st of storms) {
          const sLat = st.south ? -st.lat : st.lat;
          let dl = u - st.lon; dl -= Math.round(dl); // wrap to -0.5..0.5
          const dy2 = (lat - sLat) / st.ry, dx2 = dl / st.rx;
          const d = Math.hypot(dx2, dy2);
          if (d > 1.25) continue;
          if (d < 0.55) {
            rgb = st.dark ? shade(BELT[0], 0.8) : shade([196, 132, 96], 1.0); // core
          } else if (d < 1.0) {
            // the collar spirals — sampled on the angle so it reads as rotation
            const ang = Math.atan2(dy2, dx2);
            const sw = fbm2(Math.cos(ang) * 3 + d * 6, Math.sin(ang) * 3, nseed + 53, 2);
            rgb = sw > 0.5 ? shade(rgb, 1.16) : shade(rgb, 0.88);
          } else {
            rgb = shade(rgb, 1.08); // the wake it drags along the jet
          }
        }

        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = 255;
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * Crater rings at texture resolution, driven by the model's impact list so
   * every ring sits on the basin the elevation field already dug.
   * @returns 0 none, 1 shadowed floor, 2 sunlit rim, 3 ejecta
   */
  _craterRings(u, v, surf, seed) {
    const lon = u * Math.PI * 2;
    const lat = (0.5 - v) * Math.PI;
    const cl = Math.cos(lat);
    const dx = cl * Math.cos(lon), dy = Math.sin(lat), dz = cl * Math.sin(lon);
    let hit = 0;
    for (const im of surf.impacts) {
      const dot = dx * im.dir[0] + dy * im.dir[1] + dz * im.dir[2];
      const ang = Math.acos(Math.max(-1, Math.min(1, dot))) / Math.PI;
      if (ang > im.r * 1.4) continue;
      // a ragged rim, so craters are not perfect circles
      const wob = 1 + 0.10 * (fbm2(dx * 24, dz * 24 + dy * 18, seed + 91, 2) - 0.5);
      const rr = im.r * wob;
      if (ang < rr * 0.80) hit = Math.max(hit, 1);
      else if (ang < rr * 1.0) hit = 2;
      else if (ang < rr * 1.28) hit = Math.max(hit, 3);
    }
    return hit;
  }


  /**
   * Engine flame billboard, 3 flicker frames: a pixel-art teardrop cone —
   * white-hot throat, amber body, red fringe — with real alpha. Frame index
   * cycles ~12/s so the plume visibly burns instead of blinking dots.
   */
  flameTexture(frame = 0, w = 64, h = 144) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0xf1a + frame);
    const seed = rng.int(0, 9999);
    const white = [255, 250, 232], blue = [190, 214, 255];
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const deepA = hexToRgb(PALETTE.AMBER_MACHINE[1]), red = hexToRgb(PALETTE.WARNING_RED[2]);
    for (let y = 0; y < h; y++) {
      const t2 = y / h; // 0 throat, 1 tail
      // bell profile: bulges just past the throat, then tapers — a real plume
      const bulge = Math.sin(Math.min(1, t2 * 2.2) * Math.PI * 0.5);
      const wob = 1 + 0.22 * fbm2(frame * 7 + 3, y * 0.22, seed, 2);
      const width = (0.16 + 0.34 * bulge) * (1 - t2 * 0.72) * w * wob;
      for (let x = 0; x < w; x++) {
        const dx = Math.abs(x - w / 2);
        if (dx > width) continue;
        const edge = dx / Math.max(1, width);
        const flick = fbm2(x * 0.45 + frame * 13, y * 0.3, seed + 3, 2);
        // shock diamonds: bright chevrons pulsing down the core
        const diamond = Math.abs(Math.sin(t2 * 9.4 + frame * 0.7)) > 0.86 && edge < 0.3 && t2 > 0.1 && t2 < 0.75;
        let rgb, a;
        if (diamond) { rgb = white; a = 255; }
        else if (t2 < 0.14 && edge < 0.55) { rgb = blue; a = 250; } // Mach core at the throat
        else if (edge < 0.35 && t2 < 0.55) { rgb = white; a = 240; }
        else if (edge < 0.6 && t2 < 0.7) { rgb = amber; a = 225; }
        else if (edge < 0.85) { rgb = deepA; a = 185; }
        else { rgb = red; a = 120; }
        if (flick > 0.74 && t2 > 0.35) a = Math.max(0, a - 130); // ragged tongues
        if (t2 > 0.8 && flick < 0.55 - (1 - t2)) continue; // torn tail
        const i = (y * w + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * Cold-gas RCS puff. Same plume geometry as flameTexture but pale blue-white
   * and short: attitude thrusters vent stored gas, they don't burn, so reusing
   * the hot amber flame for them made every manoeuvre look like a rocket firing
   * out of the ship's side.
   */
  coldJetTexture(frame = 0, w = 64, h = 80) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0xc01d + frame);
    const seed = rng.int(0, 9999);
    const core = [236, 244, 255], mid = [186, 206, 236], edgeC = [128, 152, 188];
    for (let y = 0; y < h; y++) {
      const t2 = y / h;
      // cold gas spreads fast and thins out — a cone, not a bell
      const wob = 1 + 0.3 * fbm2(frame * 11 + 2, y * 0.28, seed, 2);
      const width = (0.1 + 0.44 * t2) * w * wob;
      for (let x = 0; x < w; x++) {
        const dx = Math.abs(x - w / 2);
        if (dx > width) continue;
        const edge = dx / Math.max(1, width);
        const puff = fbm2(x * 0.5 + frame * 17, y * 0.34, seed + 5, 2);
        let rgb, a;
        if (edge < 0.32 && t2 < 0.45) { rgb = core; a = 225; }
        else if (edge < 0.62) { rgb = mid; a = 175; }
        else { rgb = edgeC; a = 110; }
        a = Math.max(0, a - t2 * 130); // fades out along its length
        if (puff > 0.66 && t2 > 0.25) a = Math.max(0, a - 90); // wispy, broken
        if (a < 12) continue;
        const i = (y * w + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: w, height: h, data };
  }

  /** Soft radial glow sprite (dither-stepped) for layered light blooms. */
  glowTexture(hex = PALETTE.AMBER_MACHINE[2], size = 128) {
    const c = hexToRgb(hex);
    const data = new Uint8Array(size * size * 4);
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const d = Math.hypot(x - half, y - half) / half;
        const v = Math.max(0, 1 - d);
        const steps = 6;
        let lvl = Math.floor(v * v * steps);
        if (v * v * steps - lvl > bayerT(x, y)) lvl++;
        if (lvl <= 0) continue;
        const i = (y * size + x) * 4;
        data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2];
        data[i + 3] = Math.min(210, lvl * 38);
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * Deflector shell: faceted energy panes with bright seams, real alpha.
   * Facets are deliberately CHUNKY — the bubble renders ~100px wide on the
   * 480×270 buffer, so fine cells would nearest-sample into noise.
   */
  shieldTexture(w = 256, h = 128) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0x5e1d);
    const seed = rng.int(0, 9999);
    const seam = [160, 208, 255], pane = [80, 130, 210];
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        // hex-ish facet grid: offset rows of big cells with glowing borders
        const row = Math.floor(y / 16);
        const gx = (x + (row % 2) * 16) % 32, gy = y % 16;
        const onSeam = gx < 3 || gy < 3;
        const shimmer = fbm2(x * 0.15, y * 0.15, seed, 2);
        const i = (y * w + x) * 4;
        if (onSeam) {
          data[i] = seam[0]; data[i + 1] = seam[1]; data[i + 2] = seam[2];
          data[i + 3] = 200 + (shimmer > 0.55 ? 55 : 0);
        } else if (shimmer > 0.5) {
          data[i] = pane[0]; data[i + 1] = pane[1]; data[i + 2] = pane[2];
          data[i + 3] = 90;
        }
      }
    }
    return { width: w, height: h, data };
  }

  /** Ragged dark smoke puff, 2 frames — battle damage that lingers. */
  smokeTexture(frame = 0, size = 64) {
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x50e + frame);
    const seed = rng.int(0, 9999);
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const d = Math.hypot(x - half, y - half) / half;
        const n = fbm2(x * 0.28 + frame * 9, y * 0.28, seed, 3);
        if (d > 0.55 + n * 0.4) continue;
        const i = (y * size + x) * 4;
        const dark = n > 0.5 ? 26 : 16;
        data[i] = dark + 6; data[i + 1] = dark + 4; data[i + 2] = dark + 8;
        data[i + 3] = Math.max(0, 170 - d * 160);
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * Accretion-disk swirl for the jump singularity: logarithmic spiral arms of
   * in-falling matter — white-hot at the inner edge, amber mid, deep ember red
   * out — dither-broken, transparent centre so the void reads through.
   */
  swirlTexture(size = 256) {
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x5a11);
    const seed = rng.int(0, 9999);
    const white = [255, 246, 224];
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const deepA = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const ember = hexToRgb(PALETTE.WARNING_RED[1]);
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - half, dy = y - half;
        const r = Math.hypot(dx, dy) / half;
        if (r < 0.15 || r > 0.98) continue; // hole for the void, round edge
        const ang = Math.atan2(dy, dx);
        // two trailing spiral arms; wrap phase in [0,1)
        const swirl = (ang + Math.log(r + 0.12) * 5.2) / Math.PI;
        const arm = Math.abs(((swirl % 1) + 1) % 1 - 0.5) * 2; // 0 on-arm, 1 between
        const turb = fbm2(x * 0.16, y * 0.16, seed, 3);
        const heat = (1 - arm) * (1 - r) * (0.65 + 0.55 * turb);
        if (heat < 0.14) continue;
        // doppler boost: the approaching side of the disk burns brighter
        const dop = dx > 0 ? 1.15 : 0.78;
        let rgb, a;
        if (heat * dop > 0.62) { rgb = white; a = 240; }
        else if (heat * dop > 0.44) { rgb = amber; a = 215; }
        else if (heat * dop > 0.27) { rgb = deepA; a = 165; }
        else { rgb = ember; a = 110; }
        if ((heat * 5 - Math.floor(heat * 5)) < bayerT(x, y) * 0.7 && heat < 0.5) a -= 70;
        if (a <= 0) continue;
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: size, height: size, data };
  }

  /** Photon ring: a thin, blazing circle with dithered falloff + doppler side. */
  ringTexture(size = 512) {
    const data = new Uint8Array(size * size * 4);
    const white = [255, 250, 235];
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = x - half, dy = y - half;
        const r = Math.hypot(dx, dy) / half;
        const band = Math.abs(r - 0.62);
        if (band > 0.13) continue;
        const v = 1 - band / 0.13;
        const dop = 0.75 + 0.45 * (dx / (half * 2) + 0.5); // one side brighter
        const lvl = v * v * dop;
        if (lvl * 5 < 1 + bayerT(x, y) * 2.4) continue;
        const hot = lvl > 0.55;
        const rgb = hot ? white : amber;
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2];
        data[i + 3] = Math.min(250, 90 + lvl * 170);
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * ACCRETION BAND — the texture for the singularity's real 3D disk mesh, not a
   * billboard. Laid out as a strip: u wraps once around the disk (so it must
   * tile horizontally), v runs from the inner edge (v=0, hard against the photon
   * sphere, white-hot) to the outer edge (v=1, cold ember and mostly gaps).
   *
   * Deliberately COARSE: 224x40 across a disk many hundreds of pixels wide, so
   * every texel is a fat visible block — this is the "heavily pixelated" read.
   * Structure, inner to outer:
   *   - shear lanes: matter closer in orbits faster, so the filaments smear into
   *     ever-tighter spirals; the lane phase is a log of v, which is what makes
   *     the winding look differential rather than like painted stripes.
   *   - clump noise: knots of denser gas riding the lanes, so no two revolutions
   *     of the disk present the same silhouette.
   *   - doppler: the half swinging toward the camera runs brighter. Baked into u
   *     because the disk mesh always spins the same way about its own axis.
   *   - torn outer skirt: alpha dithered out to nothing so the disk frays into
   *     individual pixels instead of ending on a clean circle.
   * @param {number} frame animation frame (the knots crawl between frames)
   */
  accretionTexture(frame = 0, w = 224, h = 40) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0xacc7 + frame);
    const seed = rng.int(0, 9999);
    const white = [255, 248, 232];
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const hot = mixRgb(amber, white, 0.55); // the step between white-hot and amber
    const deep = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const ember = hexToRgb(PALETTE.WARNING_RED[1]);
    for (let y = 0; y < h; y++) {
      const v = y / (h - 1);
      // orbital radius across the annulus: inner edge sits at 0.42 of the outer
      const rr = 0.42 + v * 0.58;
      // Keplerian-ish winding: log spiral, tighter the further in
      const wind = Math.log(rr + 0.06) * 7.4;
      for (let x = 0; x < w; x++) {
        const u = x / w;
        const ang = u * Math.PI * 2;
        const lane = ((ang * 2 + wind) / Math.PI) % 1;
        const laneW = (((lane % 1) + 1) % 1 - 0.5) * 2;
        const onLane = 1 - Math.abs(laneW); // 1 mid-filament, 0 in the gap
        // knots: stretched along u (they get sheared out by the orbit)
        const knot = fbm2(x * 0.09 + frame * 7, y * 0.42, seed, 3);
        const fine = fbm2(x * 0.31, y * 0.9 + frame * 3, seed + 91, 2);
        // heat: inner edge is the hottest place in the picture
        let heat = (1 - v) * (0.42 + 0.72 * onLane) * (0.55 + 0.75 * knot);
        heat *= 0.82 + 0.34 * fine;
        // doppler: approaching limb (u~0.25) hot, receding (u~0.75) dim
        heat *= 0.66 + 0.5 * (0.5 + 0.5 * Math.sin(ang));
        if (heat < 0.12) continue;
        let rgb, a;
        if (heat > 0.78) { rgb = white; a = 250; }
        else if (heat > 0.58) { rgb = hot; a = 232; }
        else if (heat > 0.40) { rgb = amber; a = 205; }
        else if (heat > 0.24) { rgb = deep; a = 160; }
        else { rgb = ember; a = 104; }
        // torn skirt + gap dissolve, dithered so it breaks into pixels
        const q = heat * 6;
        if (q - Math.floor(q) < bayerT(x, y) * (0.55 + 0.9 * v)) a -= 74;
        if (v > 0.72 && bayerT(x + 2, y + 1) > 1.45 - v) a -= 60;
        if (a <= 6) continue;
        const i = (y * w + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * EVENT HORIZON — equirect skin for the singularity's sphere mesh. Almost
   * entirely void: the whole point of drawing the horizon as real geometry is
   * that its round silhouette occludes the disk mesh behind it, so the texture's
   * only job is to not be a flat fill (banned) and to carry a faint smear of
   * photons skimming the shadow's edge.
   */
  horizonTexture(w = 128, h = 64) {
    const data = new Uint8Array(w * h * 4);
    const rng = this.rng.fork(0xe0d1);
    const seed = rng.int(0, 9999);
    const skim = [110, 128, 168]; // cold starlight dragged around the shadow
    for (let y = 0; y < h; y++) {
      // the equator of the sphere faces the camera edge-on, so the faint skim
      // belongs at the poles of the UV sphere as seen from the disk plane
      const v = y / (h - 1);
      const band = Math.abs(v - 0.5) * 2; // 0 equator, 1 poles
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const n = fbm2(x * 0.22, y * 0.34, seed, 3);
        // three near-black steps so the void is never one flat colour
        const step = n > 0.62 ? 2 : n > 0.38 ? 1 : 0;
        data[i] = 2 + step * 3; data[i + 1] = 2 + step * 3; data[i + 2] = 5 + step * 4;
        data[i + 3] = 255;
        // Photon skim: a HINT, nothing more. This has to stay near-black — the
        // shadow reads as a void only while it is a void, and at any strength you
        // can comfortably see it reads as a lit blue-grey ball with a disk
        // behind it instead of a hole. Confined to the last 15% of the polar cap,
        // dithered out, and capped well under a third of the skim colour.
        const lift = Math.max(0, band - 0.85) / 0.15 * (n * 1.5 - 0.55);
        if (lift > 0.1 && lift * 3 > bayerT(x, y) * 2.6) {
          const k = Math.min(1, lift) * 0.28;
          data[i] = 4 + skim[0] * k;
          data[i + 1] = 4 + skim[1] * k;
          data[i + 2] = 7 + skim[2] * k;
        }
      }
    }
    return { width: w, height: h, data };
  }

  /**
   * LENSED SECONDARY IMAGE — the crescents of disk light bent up over the top of
   * the shadow and down under its bottom. Physically this is an image of the FAR
   * side of the disk, wrapped around the horizon, so it belongs on a
   * camera-facing quad (a lensing artifact has no orientation of its own) even
   * though the disk itself is real geometry. Transparent across the middle so
   * the horizon sphere and the near half of the disk read through it.
   */
  lensArcTexture(size = 256) {
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x1e45);
    const seed = rng.int(0, 9999);
    const white = [255, 246, 226];
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    const deep = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const half = size / 2;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const dx = (x - half) / half, dy = (y - half) / half;
        const r = Math.hypot(dx, dy);
        if (r < 0.44 || r > 0.94) continue;
        // vertical falloff: light only where the arc climbs over/under the void
        const climb = Math.abs(dy) / Math.max(0.08, r);
        if (climb < 0.34) continue; // leave the flanks to the real disk mesh
        const band = 1 - Math.abs(r - 0.62) / 0.32;
        const turb = fbm2(x * 0.2, y * 0.2, seed, 3);
        let v = band * band * (climb - 0.24) * 1.5 * (0.6 + 0.8 * turb);
        // the upper arc is the brighter one (approaching side gets lensed higher)
        v *= dy < 0 ? 1.18 : 0.78;
        if (v < 0.12) continue;
        let rgb, a;
        if (v > 0.62) { rgb = white; a = 226; }
        else if (v > 0.4) { rgb = amber; a = 190; }
        else { rgb = deep; a = 128; }
        const q = v * 5;
        if (q - Math.floor(q) < bayerT(x, y)) a -= 70;
        if (a <= 6) continue;
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2]; data[i + 3] = a;
      }
    }
    return { width: size, height: size, data };
  }

  /**
   * PLANETARY ring system, drawn from a SOLVED ring spec (CelestialGen.buildRings)
   * rather than an invented band pattern.
   *
   * What the spec brings that the old version could not have: the inner edge is
   * the host's Roche limit, the outer edge is set by its innermost shepherd moon,
   * and every gap is a mean-motion resonance with one of those moons at the
   * radius the third law puts it. Two giants with different moon systems now get
   * visibly different discs — the previous version drew one hardcoded division
   * two-thirds of the way out on every ringed body in the game.
   *
   * Still an ELLIPSE on a camera-facing billboard rather than a 3D annulus, for
   * the two reasons recorded when rings were first added: orbits here are
   * near-coplanar so a physically-oriented ring would be edge-on almost always,
   * and the space pass has no depth test, so `far` (above centre, drawn BEFORE
   * the planet sphere) and `near` (below, drawn after) is what makes the disc
   * pass behind and in front. The spec's own `tiltDeg` now sets how open the
   * ellipse is, so a heavily tilted system reads as heavily tilted.
   *
   * @param {'far'|'near'} half which arc this sheet carries
   * @param {object} spec body.rings — { inner, outer, gaps[], tiltDeg }
   */
  planetRingTexture(half = 'far', spec = null, size = 512) {
    const s = spec ?? DEFAULT_RINGS;
    const data = new Uint8Array(size * size * 4);
    const rng = this.rng.fork(0x21a6 + Math.round((s.tiltDeg ?? 20) * 37) + s.gaps.length * 11);
    const seed = rng.int(0, 9999);
    const half2 = size / 2;
    // The apparent minor/major ratio IS sin(tilt): a ring seen from within its
    // own plane is a line, from directly above it is a circle. Clamped so the
    // extremes stay drawable at this resolution.
    const openness = clamp(Math.sin(((s.tiltDeg ?? 20) * Math.PI) / 180), 0.16, 0.62);
    const rx = half2 * 0.985, ry = half2 * openness;
    // the sheet is scaled by `outer` at draw time, so the inner edge in texture
    // space is the ratio of the two solved radii
    const INNER = clamp(s.inner / s.outer, 0.25, 0.85);

    // Ice-and-rubble tones: ring particles are dirty water ice with a high
    // albedo, so this runs bright — but stepped, never a gradient.
    const bands = [[92, 88, 80], [134, 129, 118], [172, 167, 154], [202, 198, 184]];

    for (let y = 0; y < size; y++) {
      const dy = y - half2;
      // the split that makes the occlusion work — see the doc comment
      if (half === 'far' ? dy > 0 : dy <= 0) continue;
      for (let x = 0; x < size; x++) {
        const dx = x - half2;
        const e = Math.hypot(dx / rx, dy / ry); // 0 centre, 1 outer edge
        if (e < INNER || e > 1) continue;
        // radius in units of the host's radius, so the gap radii from the
        // dynamics can be compared directly
        const rHost = e * s.outer;
        const t = (e - INNER) / (1 - INNER); // 0 inner edge → 1 outer edge

        // -- ringlet structure --------------------------------------------------
        // A dense stack of narrow ringlets: real rings are hundreds of them, and
        // the self-gravity wakes that produce the fine structure are what makes
        // a ring look like a ring rather than a painted band.
        const ringlet = fbm2(t * 30, 3.5, seed, 3);
        const fine = fbm2(t * 74, 8.5, seed + 13, 2);
        // azimuthal clumping, so the arc is not uniform all the way round
        const ang = Math.atan2(dy / ry, dx / rx);
        const clump = fbm2(Math.cos(ang) * 2.2, Math.sin(ang) * 2.2, seed + 29, 3);

        let dens = 0.35 + 0.65 * ringlet;
        dens *= 0.74 + 0.48 * clump;
        if (fine > 0.72) dens *= 1.24;
        else if (fine < 0.3) dens *= 0.66;

        // -- RESONANCE GAPS -----------------------------------------------------
        // Each one is a real mean-motion resonance with a shepherd moon. `depth`
        // is how thoroughly the resonance swept it: the 2:1 clears almost
        // completely, a 7:3 only thins the material.
        for (const g of s.gaps) {
          const d = Math.abs(rHost - g.r);
          if (d > g.width * 0.5) continue;
          const inGap = 1 - d / (g.width * 0.5);
          // smooth shoulders — a resonance thins the edges before it empties
          dens *= g.depth + (1 - g.depth) * (1 - inGap * inGap);
        }

        // fade both rims: the disc ends by thinning out, not on a hard edge
        dens *= Math.min(1, t / 0.07) * Math.min(1, (1 - t) / 0.06);

        const steps = 5;
        let lvl = Math.floor(dens * steps);
        if (dens * steps - lvl > bayerT(x, y)) lvl++;
        if (lvl <= 0) continue;
        const rgb = bands[Math.min(bands.length - 1, lvl - 1)];
        const i = (y * size + x) * 4;
        data[i] = rgb[0]; data[i + 1] = rgb[1]; data[i + 2] = rgb[2];
        data[i + 3] = Math.min(238, 60 + lvl * 46);
      }
    }
    return { width: size, height: size, data };
  }

  /** Warm emissive strip for exterior windows / running lights / nozzle cores. */
  extGlowTexture() {
    const p = this._painter();
    const warm = [hexToRgb(PALETTE.AMBER_MACHINE[1]), hexToRgb(PALETTE.AMBER_MACHINE[2]),
      mixRgb(hexToRgb(PALETTE.AMBER_MACHINE[2]), [255, 245, 225], 0.75)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(warm, (x, y) => 0.6 + 0.4 * valueNoise2(x * 0.2, y * 0.2, seed));
    // brighter core band
    for (let y = 24; y < 40; y++) for (let x = 0; x < S; x++) p.px(x, y, warm[2]);
    return { width: p.size, height: p.size, data: p.data };
  }

  /** Exterior hull plating for other ships (never the player's own mid-play). */
  hullTexture(size = 64) {
    const p = this._painter();
    // brighter than interior steel so the hull still reads on its shadowed side
    // (it's the player's ship in the chase cam — must never go pure black)
    const ramp = rampOf(PALETTE.PANEL_STEEL).map((c) => shade(c, 1.5));
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.3 + 0.3 * valueNoise2(Math.floor(x / 4) * 0.8, Math.floor(y / 4) * 0.8, seed) +
      0.15 * fbm2(x * 0.1, y * 0.1, seed + 2, 2));
    // Hull plating in running bond, same reasoning as the interior walls: an even
    // 16×21 crossing grid made every NPC hull a chequerboard of identical cells.
    // Courses of uneven height, staggered butt joints, mid-ramp seam colour.
    const seam = shade(ramp[1], 0.82);
    const courses = [15, 19, 16, 14]; // 64
    let y0 = 0;
    for (let c = 0; c < courses.length; c++) {
      const y1 = y0 + courses[c];
      for (let x = 0; x < S; x++) { p.px(x, y0, seam); p.addH(x, y0, -0.3); }
      let x0 = (c * 13 + (seed % 9)) % 25;
      while (x0 < S) {
        const w = 19 + ((x0 * 5 + c + seed) % 11); // 19..29
        for (let y = y0 + 1; y < y1 && y < S; y++) { p.px(x0 % S, y, seam); p.addH(x0 % S, y, -0.26); }
        const k = 0.955 + ((x0 * 3 + c * 7 + seed) % 6) * 0.018;
        for (let y = y0 + 1; y < y1 && y < S; y++) {
          for (let x = x0 + 1; x < x0 + w; x++) p.px(x % S, y, shade(p.get(x % S, y), k));
        }
        x0 += w;
      }
      y0 = y1;
    }
    // No 'KSV' stencil. At uvScale 1 tile per hull section that serial repeated
    // across every enemy hull in the system; ship names and registries belong on
    // the ONE-OFF decal pass in ShipExterior, not on tiling plate stock.
    // Seam welds and fastener rows down the courses, plus micrometeorite pitting.
    for (const cy of [0, courses[0], courses[0] + courses[1]]) {
      p.weldBead(0, cy + 1, S, cy + 1, seed + cy, 0.9);
      p.rivetRun(2, cy + 3, S - 2, cy + 3, 5, seed + cy * 3);
    }
    p.ditherOver(hexToRgb(PALETTE.SHADOW_BLACK[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.09 + 3, y * 0.02, seed + 8, 2) - 0.62) * 1.2);
    this._finish(p, ramp, seed, {
      chips: 26, hair: 24, dent: 18, wear: 0.55, rust: 0.5, runs: 1,
      // Cast, not rolled. Keth hulls are poured in a hurry and it shows.
      pits: 44, bloom: 2, cavity: 0.24, contact: 0.26,
    });
    return { width: p.size, height: p.size, data: p.data };
  }

  /**
   * The Aethon's own plating. Separate from hullTexture (which dresses distant
   * NPC hulls) because the chase cam puts this ship across a third of the
   * screen — but a 64px tile still minifies hard at that distance, so every
   * feature here is deliberately LOW frequency: big value-stepped plate blocks,
   * deep seam channels, a wide hazard band. Fine speckle would only alias into
   * noise, and the geometry now carries the small detail anyway.
   */
  aethonHullTexture() {
    const p = this._painter();
    // dark military metal (context/01 signature) lifted enough that the
    // shadowed side of the player's own ship still reads instead of going black
    const steel = rampOf(PALETTE.PANEL_STEEL).map((c) => shade(mixRgb(c, hexToRgb('#2e3a2e'), 0.45), 1.34));
    const seed = p.rng.int(0, 9999);
    p.ditherFill(steel, (x, y) =>
      0.34 + 0.26 * valueNoise2(Math.floor(x / 8) * 1.1, Math.floor(y / 8) * 1.1, seed) +
      0.14 * fbm2(x * 0.08, y * 0.08, seed + 2, 2));
    // Hull plating in RUNNING BOND.
    //
    // This was a 4×4 grid of equal blocks with 2px seam channels crossing both
    // ways and bolt rows down every second seam — the most explicit squared grid
    // in the game, and the one on screen whenever the chase cam is up. Session
    // 16t leaned on the shader's per-plate mirroring (u_tileVary) to hide the
    // repeat, but mirroring only varies which copy you see; it cannot help when
    // the cell itself is an outlined square, because a mirrored square is the
    // same square.
    //
    // Four courses of unequal height with staggered butt joints, so vertical
    // seams never stack into a column; mid-ramp seam colour, since a near-black
    // channel (the old 0.42) outlines every cell and the outline is what draws
    // the grid; sparse bolts on alternate courses only.
    const seam = shade(steel[1], 0.8);
    const courses = [14, 18, 15, 17]; // 64
    let cy0 = 0;
    for (let c = 0; c < courses.length; c++) {
      const cy1 = cy0 + courses[c];
      // horizontal joint, broken by wear so it is not a drawn ruler line
      for (let x = 0; x < S; x++) {
        if (valueNoise2(x * 0.24, c * 3.3, seed + 13) > 0.19) {
          p.px(x, cy0, seam); p.addH(x, cy0, -0.34);
          if (cy0 + 1 < S) { p.px(x, cy0 + 1, seam); p.addH(x, cy0 + 1, -0.28); }
        }
      }
      let x0 = (c * 15 + (seed % 11)) % 27;
      while (x0 < S) {
        const w = 21 + ((x0 * 7 + c * 3 + seed) % 13); // 21..33
        for (let y = cy0 + 2; y < cy1 && y < S; y++) {
          p.px(x0 % S, y, seam); p.addH(x0 % S, y, -0.3);
        }
        // per-plate value step, narrow — the shader varies plates far more, and
        // that variation is keyed to the model, so it does not repeat
        const k = 0.955 + ((x0 * 5 + c * 11 + seed) % 6) * 0.019;
        for (let y = cy0 + 2; y < cy1 && y < S; y++) {
          for (let x = x0 + 1; x < x0 + w; x++) p.px(x % S, y, shade(p.get(x % S, y), k));
        }
        if (c % 2 === 1 && ((x0 + c) % 3) === 0) p.bolt((x0 + 4) % S, cy0 + 4);
        x0 += w;
      }
      cy0 = cy1;
    }
    // hazard band: diagonal chevrons, the one high-contrast marking that still
    // reads when the tile is a dozen pixels across. Kept NARROW and knocked
    // halfway back toward the steel — at 8px of a 64px tile the stripe repeats
    // every 6 model units and the whole ship turned orange.
    const amber = mixRgb(hexToRgb(PALETTE.AMBER_MACHINE[0]), steel[1], 0.45);
    const dark = shade(steel[0], 0.55);
    for (let y = 46; y < 50; y++) {
      for (let x = 0; x < S; x++) p.px(x, y, ((x + y) >> 2) % 2 ? amber : dark);
    }
    // Wear: rust blooms, scorch, micrometeorite pitting — all broad and OFF-AXIS.
    //
    // This used to be a strong corner-anchored gradient, on the reasoning that the
    // shader mirrors the tile per plate (space.frag u_tileVary) so one corner
    // bias yields four different-looking panels. That was the right trick for a
    // grid-cell texture, but it does not survive the plating rewrite: dumped as a
    // repeat it is a bright diagonal wedge per tile, and four mirrored wedges meet
    // in a huge X across the hull. It was also the closest thing left in the
    // interior set to a banned smooth gradient.
    //
    // The de-repeat job now belongs to the running-bond layout and the shader's
    // per-plate value step, which frees the wear to be what wear is: quiet, broad
    // and anchored to nothing.
    p.ditherOver(shade(steel[0], 0.68), (x, y) =>
      Math.max(0, fbm2(x * 0.042 + 19, y * 0.055, seed + 31, 3) - 0.5) * 1.4);
    p.ditherOver(hexToRgb(PALETTE.RUST[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.065 + 83, y * 0.033, seed + 67, 2) - 0.63) * 1.15);
    for (const [rx, ry] of [[9, 14], [52, 30]]) p.rustStreak(rx, ry, 10, 0.5);
    p.ditherOver(hexToRgb(PALETTE.SHADOW_BLACK[0]), (x, y) =>
      Math.max(0, fbm2(x * 0.08 + 5, y * 0.02, seed + 8, 2) - 0.58) * 1.3);
    // Seam welds and fastener runs down every course, plus a longitudinal
    // stringer — the structural language of a real hull section, and dense enough
    // that no single element is a mark you can find again two metres along.
    let wy = 0;
    for (const ch of courses) {
      p.weldBead(0, wy + 1, S, wy + 1, seed + wy * 5, 1.0);
      p.rivetRun(2, wy + 3, S - 2, wy + 3, 4, seed + wy * 7);
      wy += ch;
    }
    for (let y = 0; y < S; y++) {
      for (let o = 0; o < 3; o++) {
        p.px(19 + o, y, shade(p.get(19 + o, y), o === 1 ? 1.08 : 0.93));
        p.addH(19 + o, y, o === 1 ? 0.4 : 0.18);
      }
    }
    p.rivetRun(20, 1, 20, S - 1, 6, seed + 91);
    // The 'KSV-114' and 'AETHON' stencils are gone. This texture tiles across the
    // whole hull, so the ship's own name marched down its flank a dozen times —
    // legible text is the loudest possible announcement that a surface is one
    // image repeated, and reading the registry twice in one silhouette breaks the
    // illusion that it is a real hull. Registry markings want a single decal
    // quad on one hull section, which is a ShipExterior job, not tiling stock.
    //
    // Vacuum wear: heavy pitting and abraded edges, almost no rust (there is no
    // moisture out here) and no gravity runs.
    this._finish(p, steel, seed, {
      chips: 30, hair: 28, dent: 22, wear: 0.6, rust: 0.25, runs: 0,
      // Micrometeorite pitting is the defining wear out here; oxidation is not,
      // because there is nothing to oxidise with.
      pits: 52, bloom: 0, cavity: 0.24, contact: 0.26,
    });
    return { width: p.size, height: p.size, data: p.data };
  }

  /** Keth fighter plating — matte black panels, sharp muted-red strike lines. */
  kethTexture() {
    const p = this._painter();
    const black = [hexToRgb(PALETTE.SHADOW_BLACK[0]), hexToRgb(PALETTE.SHADOW_BLACK[1]),
      shade(hexToRgb(PALETTE.SHADOW_BLACK[2]), 1.4)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(black, (x, y) => 0.35 + 0.3 * valueNoise2(x * 0.07, y * 0.07, seed));
    const red = hexToRgb(PALETTE.WARNING_RED[1]);
    for (const ry of [10, 34, 52]) { // angular strike lines, never curves
      for (let x = 0; x < S; x++) {
        const y = ry + ((x >> 3) & 1) * 2;
        p.px(x, y, red); p.addH(x, y, 0.3);
      }
    }
    for (let y = 20; y < S; y += 22) for (let x = 4; x < S; x += 14) p.bolt(x, y);
    return { width: p.size, height: p.size, data: p.data };
  }

  /** Drift drone lattice — cold grey chassis, near-white fractal veining. */
  driftTexture() {
    const p = this._painter();
    const grey = [hexToRgb('#2a2a30'), hexToRgb('#3a3a42'), shade(hexToRgb('#3a3a42'), 1.35)];
    const seed = p.rng.int(0, 9999);
    p.ditherFill(grey, (x, y) => 0.35 + 0.3 * fbm2(x * 0.09, y * 0.09, seed, 3));
    const white = hexToRgb('#e8e8f0');
    // fractal veining: recursive H-branches
    const vein = (x, y, len, dir, depth) => {
      for (let i = 0; i < len; i++) {
        const vx = x + (dir === 0 ? i : dir === 1 ? -i : 0);
        const vy = y + (dir === 2 ? i : dir === 3 ? -i : 0);
        p.px(vx & (S - 1), vy & (S - 1), white);
      }
      if (depth > 0) {
        const ex = x + (dir === 0 ? len : dir === 1 ? -len : 0);
        const ey = y + (dir === 2 ? len : dir === 3 ? -len : 0);
        vein(ex, ey, len >> 1, dir < 2 ? 2 : 0, depth - 1);
        vein(ex, ey, len >> 1, dir < 2 ? 3 : 1, depth - 1);
      }
    };
    vein(8, 12, 16, 0, 3);
    vein(50, 40, 14, 3, 3);
    vein(20, 52, 12, 0, 2);
    return { width: p.size, height: p.size, data: p.data };
  }

  /** Fire-suppression canister — dull warning red, banded, stenciled. */
  canisterRed() {
    const p = this._painter();
    const red = rampOf(PALETTE.WARNING_RED);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(red, (x, y) =>
      0.35 + 0.3 * valueNoise2(x * 0.07, Math.floor(y / 2) * 0.4, seed) +
      // cylindrical shading: bright crest down the middle, dark edges
      0.3 * (1 - Math.abs(x - S / 2) / (S / 2)));
    // collar + base bands
    for (const by of [4, 54]) {
      for (let y = by; y < by + 4; y++) for (let x = 0; x < S; x++) {
        p.px(x, y, hexToRgb(PALETTE.PANEL_STEEL[1])); p.addH(x, y, 0.4);
      }
    }
    // instruction label — worn white square, greeked text
    p.rect(20, 22, 24, 16, shade(hexToRgb(PALETTE.PANEL_STEEL[2]), 1.25));
    for (let ly = 25; ly < 36; ly += 3) {
      for (let lx = 22; lx < 42; lx++) if ((lx & 3) !== 3) p.px(lx, ly, hexToRgb(PALETTE.SHADOW_BLACK[0]));
    }
    // The colour already fakes a cylinder; the HEIGHT did not, so the normal map
    // read the bottle as flat and the dynamic light never rolled across it. A
    // cosine across u is the actual cross-section of the tube this wraps.
    for (let x = 0; x < S; x++) {
      const t = (x / S) * Math.PI * 2;
      for (let y = 0; y < S; y++) p.addH(x, y, Math.cos(t) * 0.5);
    }
    // Rolled reinforcing hoops where a real bottle is thickest, and the valve
    // gland on the collar.
    p.ribbedBand(0, 4, S, 4, 3, 0.45, true);
    p.ribbedBand(0, 54, S, 4, 3, 0.45, true);
    p.roundBoss(32 * TX, 6 * TX, 3.5 * TX, 1.2);
    this._sculpt(p, seed, { pits: 12, bloom: 3, cavity: 0.18, contact: 0.2 });
    this._stencil(p, 14, 44, 'FIRE', PALETTE.PANEL_STEEL[2]);
    return p;
  }

  /** Deck signage plate — stenciled directions on worn metal. */
  signPlate() {
    const p = this._painter();
    const ramp = rampOf(PALETTE.METAL_DARK);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) => 0.4 + 0.25 * valueNoise2(x * 0.09, y * 0.09, seed));
    p.outline(1, 1, S - 2, S - 2, shade(ramp[2], 1.25));
    this._stencil(p, 8, 8, 'DECK A', PALETTE.AMBER_MACHINE[1]);
    this._stencil(p, 8, 20, 'FRAME', PALETTE.AMBER_MACHINE[0]);
    this._stencil(p, 8, 32, '12-40', PALETTE.AMBER_MACHINE[0]);
    // direction chevron
    for (let i = 0; i < 8; i++) {
      p.px(30 + i, 50 - i, hexToRgb(PALETTE.AMBER_MACHINE[1]));
      p.px(30 + i, 50 + i, hexToRgb(PALETTE.AMBER_MACHINE[1]));
      p.px(31 + i, 50 - i, hexToRgb(PALETTE.AMBER_MACHINE[1]));
      p.px(31 + i, 50 + i, hexToRgb(PALETTE.AMBER_MACHINE[1]));
    }
    for (const [bx, by] of [[3, 3], [S - 5, 3], [3, S - 5], [S - 5, S - 5]]) p.bolt(bx, by);
    p.rustStreak(p.rng.int(8, 56), 2, 8, 0.5);
    // The whole plate stands off the bulkhead, with a rolled edge and countersunk
    // fixings — a sign screwed to a wall, not printed on it.
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const edge = x < 2 || y < 2 || x >= S - 2 || y >= S - 2;
        p.addH(x, y, edge ? 0.5 : 0.95);
      }
    }
    for (const [sx, sy] of [[3, 3], [S - 5, 3], [3, S - 5], [S - 5, S - 5]]) {
      p.screwHead(sx * TX, sy * TX, 'cross', 1.8 * TX, seed + sx + sy * 5);
    }
    this._sculpt(p, seed, { pits: 8, bloom: 2, cavity: 0.22, contact: 0.32 });
    return p;
  }

  /** Door lintel status strip — dim amber bars behind a slotted bezel. */
  doorLamp() {
    const p = this._painter();
    const dark = hexToRgb(PALETTE.SHADOW_BLACK[0]);
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) p.px(x, y, dark);
    const amber = hexToRgb(PALETTE.AMBER_MACHINE[1]);
    const amberHi = hexToRgb(PALETTE.AMBER_MACHINE[2]);
    // three lit segments with dark divider slots
    for (let seg = 0; seg < 3; seg++) {
      const x0 = 6 + seg * 18;
      for (let y = 20; y < 44; y++) {
        for (let x = x0; x < x0 + 14; x++) {
          const core = y > 26 && y < 38;
          p.px(x, y, core ? amberHi : amber);
        }
      }
    }
    // Bezel: a real housing with a raised rim and the lens set down inside it,
    // so the lit segments read as glass in a fitting rather than glowing paint.
    p.outline(2, 2, S - 4, S - 4, shade(hexToRgb(PALETTE.METAL_DARK[1]), 0.8));
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) {
        const rim = x < 5 || y < 5 || x >= S - 5 || y >= S - 5;
        p.addH(x, y, rim ? 0.9 : -0.35);
      }
    }
    for (let seg = 1; seg < 3; seg++) {
      for (let y = 18; y < 46; y++) { p.addH(5 + seg * 18 - 1, y, -0.7); p.addH(5 + seg * 18, y, -0.7); }
    }
    for (const [sx, sy] of [[4, 4], [S - 6, 4], [4, S - 6], [S - 6, S - 6]]) {
      p.screwHead(sx * TX, sy * TX, 'slot', 1.6 * TX, sx * 13 + sy);
    }
    // No cavity pass: this is an emissive lens, and darkening the seams between
    // lit segments would read as the lamp being dirty rather than as depth.
    p.contactShadow(0.3, 4);
    return p;
  }

  // -- the things aboard a dead hull ---------------------------------------------
  //
  // Three hostile materials, and the reason each looks the way it does is the
  // faction note in `context/03` §5 rather than a colour that happened to be
  // free. They are the only textures in the atlas that are not architecture, so
  // they have to read as ALIVE (or as machinery that should not be) at nine
  // metres in helmet light and nothing else — which means silhouette contrast
  // and wet specular highlights, not detail a lamp will never reach.

  /**
   * CARRION HIDE. The scavenger organism that gets into a hull once the crew
   * stop maintaining it. Segmented chitin plates over darker soft tissue, and
   * the plates are what your rounds have to get through.
   *
   * Bruised grey-green, deliberately desaturated: a bright creature would read
   * as a cartoon against the ship's blue-greys, and the whole register of
   * `CLAUDE.md` is that nothing in this game is bright.
   */
  alienChitin() {
    const p = this._painter();
    const ramp = rampOf(['#232a24', '#333d32', '#465142', '#5a6753']);
    const seed = p.rng.int(0, 9999);
    // Base hide: coarse organic mottling, no repeating cell — an animal is not
    // a tiled surface and any regular pitch here would give it away instantly.
    p.ditherFill(ramp, (x, y) =>
      0.3 + 0.34 * fbm2(x * 0.055, y * 0.055, seed, 4)
      + 0.22 * valueNoise2(x * 0.14, y * 0.11, seed + 61));
    // Chitin segments: overlapping bands across the body, each with a hard
    // leading lip and a shadowed trailing gutter. This is the read at distance.
    const lip = shade(ramp[3], 1.12);
    const gut = shade(ramp[0], 0.7);
    for (let b = 0; b < 5; b++) {
      const y0 = 3 + b * 13 + ((seed >> b) & 3);
      for (let x = 0; x < S; x++) {
        // The band is not a straight line; it sags across the body.
        const sag = Math.round(2.4 * Math.sin((x / S) * Math.PI * 1.3 + b));
        const y = y0 + sag;
        if (y < 1 || y > S - 3) continue;
        p.px(x, y, lip); p.addH(x, y, 0.85);
        p.px(x, y + 1, shade(ramp[2], 1.0)); p.addH(x, y + 1, 0.35);
        p.px(x, y + 2, gut); p.addH(x, y + 2, -0.8);
      }
    }
    // Tubercles — the raised nodules along each plate. Placed off the band
    // pitch so the two structures never line up into a grid.
    for (let i = 0; i < 34; i++) {
      const x = p.rng.int(2, S - 3), y = p.rng.int(2, S - 3);
      p.roundBoss(x * TX, y * TX, 1.3 * TX, 0.7, shade(ramp[3], 1.06));
    }
    // Wet: pinprick highlights where the hide is still damp. A carrion thing
    // that came off a warm body should not look like dry stone.
    for (let i = 0; i < 26; i++) {
      const x = p.rng.int(1, S - 2), y = p.rng.int(1, S - 2);
      p.px(x, y, mixRgb(p.get(x, y), [210, 220, 200], 0.34));
    }
    p.microGrain(0.09, seed + 17, 0.8, 0.8);
    p.castPitting(30, seed + 23, 2);
    // Soft body, so a gentle cavity and a strong contact shadow: the light has
    // to fall INTO the gutters between plates or the whole thing reads flat.
    p.cavity(0.34, 2);
    p.contactShadow(0.36, 6);
    return p;
  }

  /**
   * KETH BOARDING ARMOUR. `context/03` §5: "angular black/red, sharp
   * protrusions, no curves." Scorched plate over a dull red underlayer, with
   * the seams glowing the way a suit's thermal loop does — WARM, at
   * AMBER_MACHINE brightness, never a bright emissive line, because a glowing
   * outline on an enemy is a video-game health bar by another name.
   */
  alienArmour() {
    const p = this._painter();
    const ramp = rampOf(['#141318', '#20202a', '#2e2c34', '#3d3a44']);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.34 + 0.26 * valueNoise2(x * 0.09, Math.floor(y / 2) * 0.42, seed)
      + 0.24 * fbm2(x * 0.045, y * 0.045, seed + 9, 3));
    // Angular facets: straight bevels at hard diagonals, which is the whole
    // Keth silhouette language. Drawn as raised chevrons, not panel lines.
    const edge = shade(ramp[3], 1.25);
    const deep = shade(ramp[0], 0.72);
    for (let f = 0; f < 4; f++) {
      const x0 = 4 + f * 15, y0 = 6 + ((seed >> f) & 7);
      for (let i = 0; i < 26; i++) {
        const x = x0 + i, y = y0 + Math.floor(i * 0.62);
        if (x >= S - 1 || y >= S - 1) break;
        p.px(x, y, edge); p.addH(x, y, 0.9);
        p.px(x, y + 1, deep); p.addH(x, y + 1, -0.75);
      }
    }
    // Heat seams: the red the faction is described by. Muted — WARNING_RED's
    // mid, not its top — and broken, so it reads as glow through a gap.
    const hot = hexToRgb(PALETTE.WARNING_RED[1]);
    const hotter = hexToRgb(PALETTE.AMBER_MACHINE[0]);
    for (const sy of [17, 39, 55]) {
      for (let x = 2; x < S - 2; x++) {
        if (valueNoise2(x * 0.31, sy * 0.5, seed + 41) < 0.35) continue;
        p.px(x, sy, valueNoise2(x * 0.7, sy, seed + 77) > 0.6 ? hotter : hot);
        p.addH(x, sy, -0.5);
      }
    }
    // Battle damage: this armour has been shot at, and by more than you.
    for (let i = 0; i < 14; i++) {
      const x = p.rng.int(3, S - 4), y = p.rng.int(3, S - 4);
      p.scratch(x, y, p.rng.int(4, 11), p.rng.int(0, 1) ? 1 : -1);
    }
    p.microGrain(0.08, seed + 103, 1.2, 0.5);
    p.paintChips(shade(ramp[0], 0.8), 20, seed + 211);
    p.edgeWear(seed + 307, 0.62);
    p.castPitting(22, seed + 401, 2);
    p.cavity(0.26, 1);
    p.contactShadow(0.3, 5);
    return p;
  }

  /**
   * DRIFT CHASSIS. `context/03` §5 gives the exact colours — chassis `#2a2a30`
   * / `#3a3a42`, fractal detailing in near-white `#e8e8f0` — and calls the
   * register "cold and mechanical, deliberately the opposite of the Hollow."
   *
   * The fractal is drawn as a real recursive branch rather than noise, because
   * the one thing that makes a machine race read as machine is that its markings
   * are EXACT: every branch splits at the same angle at every scale.
   */
  alienCrystal() {
    const p = this._painter();
    const ramp = rampOf(['#1e1e24', '#2a2a30', '#3a3a42', '#4a4a54']);
    const seed = p.rng.int(0, 9999);
    p.ditherFill(ramp, (x, y) =>
      0.36 + 0.2 * valueNoise2(x * 0.11, y * 0.11, seed)
      + 0.2 * fbm2(x * 0.06, y * 0.06, seed + 5, 3));
    // Facets. A crystalline hull is planes meeting at angles, so the shading is
    // piecewise-constant per facet with a hard bright edge between.
    const face = shade(ramp[2], 1.1);
    for (let i = 0; i < 7; i++) {
      const cx = p.rng.int(6, S - 6), cy = p.rng.int(6, S - 6), r = p.rng.int(5, 12);
      for (let y = cy - r; y <= cy + r; y++) {
        for (let x = cx - r; x <= cx + r; x++) {
          if (x < 0 || y < 0 || x >= S || y >= S) continue;
          // diamond, not circle — no curves on a Drift hull
          if (Math.abs(x - cx) + Math.abs(y - cy) > r) continue;
          p.px(x, y, face); p.addH(x, y, 0.28);
        }
      }
    }
    // The fractal. Near-white, thin, exact.
    const fract = hexToRgb('#e8e8f0');
    const draw = (x0, y0, len, dir, depth) => {
      if (depth <= 0 || len < 2) return;
      const dx = [1, 0, -1, 0][dir], dy = [0, 1, 0, -1][dir];
      let x = x0, y = y0;
      for (let i = 0; i < len; i++) {
        x += dx; y += dy;
        if (x < 0 || y < 0 || x >= S || y >= S) return;
        p.px(x, y, fract); p.addH(x, y, 0.55);
      }
      draw(x, y, len >> 1, (dir + 1) & 3, depth - 1);
      draw(x, y, len >> 1, (dir + 3) & 3, depth - 1);
    };
    draw(6, 30, 18, 0, 4);
    draw(52, 12, 14, 1, 3);
    draw(30, 58, 12, 3, 3);
    p.microGrain(0.05, seed + 61, 1, 1);
    // No rust, no grime, no paint chips: nothing about the Drift weathers. That
    // absence IS the characterisation — every other surface in the game wears.
    p.cavity(0.2, 1);
    p.contactShadow(0.24, 4);
    return p;
  }

  // -- HUD overlay (2D, not part of the interior atlas) ---------------------------

  /**
   * Helmet-glass overlay at the full SCENE buffer: Bayer-dithered edge vignette
   * plus 3–4 faint fixed scratches (context/05 §1). Returned as {width,height,data}.
   *
   * Generated at scene resolution, not UI resolution, and drawn stretched across
   * the whole UI rect — so its texels land 1:1 on scene pixels at every preset.
   * The vignette is normalized and scales for free; the scratches are absolute
   * geometry and get multiplied by the scale so they keep their apparent length
   * while thinning to a true hairline at the high presets, which is what a
   * scratch on real visor glass looks like.
   */
  helmetOverlay() {
    const W = RENDER.WIDTH, H = RENDER.HEIGHT;
    const K = RENDER.SCALE; // scene pixels per UI pixel
    const data = new Uint8Array(W * H * 4);
    const rng = this.rng.fork(0xbead);
    const setA = (x, y, a) => {
      if (x < 0 || y < 0 || x >= W || y >= H) return;
      const i = (y * W + x) * 4;
      data[i] = 5; data[i + 1] = 5; data[i + 2] = 8; // near-black glass shade
      data[i + 3] = Math.max(data[i + 3], a);
    };
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const dx = Math.min(x, W - 1 - x) / (W * 0.5);
        const dy = Math.min(y, H - 1 - y) / (H * 0.5);
        const edge = 1 - Math.min(1, Math.min(dx, dy) * 6); // ~10% edge band
        if (edge <= 0) continue;
        // dithered vignette, quantized to 3 alpha steps
        const t = edge * 3;
        let lvl = Math.floor(t);
        if (t - lvl > bayerT(x, y)) lvl++;
        if (lvl > 0) setA(x, y, lvl * 42);
      }
    }
    // fixed diagonal scratches (fixed seed, never animated)
    for (let s = 0; s < 4; s++) {
      let x = rng.int(30 * K, W - 60 * K), y = rng.int(20 * K, H - 60 * K);
      const len = rng.int(30 * K, 70 * K), slope = rng.range(0.3, 0.8);
      for (let i = 0; i < len; i++) {
        const xx = Math.round(x + i), yy = Math.round(y + i * slope);
        const idx = (yy * W + xx) * 4;
        if (xx < 0 || yy < 0 || xx >= W || yy >= H) break;
        data[idx] = 200; data[idx + 1] = 200; data[idx + 2] = 210;
        data[idx + 3] = 13; // ~5% opacity
      }
    }
    return { width: W, height: H, data };
  }
}
