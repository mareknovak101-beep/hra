/**
 * MeshBuilder — accumulates interior geometry into the interleaved vertex
 * format (pos, normal, uv, atlas layer, baked AO, emissive). Everything in the
 * ship is quads and boxes; normals come from winding (CCW = front face).
 *
 * Baked per-vertex AO here is the "AmbientOcclusion" pass of the architecture
 * doc: corners and floor lines are darkened at build time, then dithered by the
 * lighting quantizer in the fragment shader.
 */
import { INTERIOR_FLOATS_PER_VERTEX } from '../core/Renderer.js';

const DEFAULT_UV_SCALE = 0.5; // 1 texture tile per 2m — chunky texels at 480×270

export class MeshBuilder {
  constructor() {
    /** @type {number[]} */
    this.verts = [];
    /** @type {number[]} */
    this.indices = [];
  }

  /**
   * Push one quad. p0..p3 CCW as seen from the front (normal) side.
   * opts: { uvScale, uvs (4×[u,v]), ao (4 floats), emissive, layer required }
   */
  quad(p0, p1, p2, p3, layer, opts = {}) {
    const e1 = [p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]];
    const e2 = [p3[0] - p0[0], p3[1] - p0[1], p3[2] - p0[2]];
    let nx = e1[1] * e2[2] - e1[2] * e2[1];
    let ny = e1[2] * e2[0] - e1[0] * e2[2];
    let nz = e1[0] * e2[1] - e1[1] * e2[0];
    const nl = Math.hypot(nx, ny, nz) || 1;
    nx /= nl; ny /= nl; nz /= nl;

    const uvScale = opts.uvScale ?? DEFAULT_UV_SCALE;
    let uvs = opts.uvs;
    if (!uvs) {
      // planar projection on the two axes least aligned with the normal
      const ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
      let ui, vi;
      if (ax >= ay && ax >= az) { ui = 2; vi = 1; } // X wall: uv from z,y
      else if (ay >= ax && ay >= az) { ui = 0; vi = 2; } // floor/ceiling: x,z
      else { ui = 0; vi = 1; } // Z wall: x,y
      // Flip U on faces whose planar U axis runs opposite to the viewer's right
      // (normal -z or +x), so baked text/stencils on screens read correctly
      // instead of mirrored. Noise textures are unaffected (symmetric).
      const flipU = nz < -0.5 || nx > 0.5 ? -1 : 1;
      uvs = [p0, p1, p2, p3].map((p) => [p[ui] * uvScale * flipU, -p[vi] * uvScale]);
    }
    const ao = opts.ao ?? [1, 1, 1, 1];
    const emissive = opts.emissive ?? 0;

    // Tangent (u direction) via edge/UV solve, orthonormalized against normal.
    const [tx, ty, tz] = this._tangent(p0, p1, p3, uvs[0], uvs[1], uvs[3], nx, ny, nz);

    const base = this.verts.length / INTERIOR_FLOATS_PER_VERTEX;
    const pts = [p0, p1, p2, p3];
    for (let i = 0; i < 4; i++) {
      const p = pts[i];
      this.verts.push(
        p[0], p[1], p[2],
        nx, ny, nz,
        uvs[i][0], uvs[i][1],
        layer,
        ao[i],
        emissive,
        tx, ty, tz,
      );
    }
    this.indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }

  /** Tangent from two edges and their UV deltas (Lengyel), Gram-Schmidt'd. */
  _tangent(p0, p1, p3, uv0, uv1, uv3, nx, ny, nz) {
    const e1x = p1[0] - p0[0], e1y = p1[1] - p0[1], e1z = p1[2] - p0[2];
    const e2x = p3[0] - p0[0], e2y = p3[1] - p0[1], e2z = p3[2] - p0[2];
    const du1 = uv1[0] - uv0[0], dv1 = uv1[1] - uv0[1];
    const du2 = uv3[0] - uv0[0], dv2 = uv3[1] - uv0[1];
    const det = du1 * dv2 - du2 * dv1;
    let tx, ty, tz;
    if (Math.abs(det) < 1e-8) {
      // degenerate uv — pick any axis perpendicular to the normal
      if (Math.abs(nx) < 0.9) { tx = 1; ty = 0; tz = 0; } else { tx = 0; ty = 1; tz = 0; }
    } else {
      const r = 1 / det;
      tx = (dv2 * e1x - dv1 * e2x) * r;
      ty = (dv2 * e1y - dv1 * e2y) * r;
      tz = (dv2 * e1z - dv1 * e2z) * r;
    }
    // orthonormalize against normal
    const d = tx * nx + ty * ny + tz * nz;
    tx -= nx * d; ty -= ny * d; tz -= nz * d;
    const l = Math.hypot(tx, ty, tz) || 1;
    return [tx / l, ty / l, tz / l];
  }

  /**
   * Axis-aligned box from min/max corners, outward-facing quads.
   * @param {number[]} min [x,y,z]
   * @param {number[]} max [x,y,z]
   * @param {number|object} layers single layer or {px,nx,py,ny,pz,nz}
   * @param {object} opts { ao, uvScale, emissive: number|{face:val}, skip: string[] }
   */
  box(min, max, layers, opts = {}) {
    const [x0, y0, z0] = min;
    const [x1, y1, z1] = max;
    const L = (face) => (typeof layers === 'number' ? layers : layers[face] ?? layers.all);
    const E = (face) =>
      typeof opts.emissive === 'object' ? (opts.emissive[face] ?? 0) : (opts.emissive ?? 0);
    const skip = new Set(opts.skip ?? []);
    const o = { uvScale: opts.uvScale, ao: opts.ao };

    if (!skip.has('py')) // top (+y)
      this.quad([x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], L('py'), { ...o, emissive: E('py') });
    if (!skip.has('ny')) // bottom (-y)
      this.quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], L('ny'), { ...o, emissive: E('ny') });
    if (!skip.has('pz')) // south (+z)
      this.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], L('pz'), { ...o, emissive: E('pz') });
    if (!skip.has('nz')) // north (-z)
      this.quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], L('nz'), { ...o, emissive: E('nz') });
    if (!skip.has('px')) // east (+x)
      this.quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], L('px'), { ...o, emissive: E('px') });
    if (!skip.has('nx')) // west (-x)
      this.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], L('nx'), { ...o, emissive: E('nx') });
  }

  /**
   * Vertical N-sided prism (columns, tanks, canisters) — rounds off cylindrical
   * props so they don't read as blunt boxes. `sides` 6–12; a flat faces -z.
   * opts: { layer overrides top/side, uvScale, ao, emissive, skipCaps }.
   */
  prism(cx, cz, radius, y0, y1, sides, layer, opts = {}) {
    const o = { uvScale: opts.uvScale ?? 1, ao: opts.ao, emissive: opts.emissive };
    const ang = (i) => (i / sides) * Math.PI * 2 + Math.PI / sides;
    const pts = [];
    for (let i = 0; i < sides; i++) pts.push([cx + Math.cos(ang(i)) * radius, cz + Math.sin(ang(i)) * radius]);
    // side faces (CCW so the outward normal points away from the axis)
    for (let i = 0; i < sides; i++) {
      const a = pts[i], b = pts[(i + 1) % sides];
      this.quad([b[0], y0, b[1]], [a[0], y0, a[1]], [a[0], y1, a[1]], [b[0], y1, b[1]], layer, o);
    }
    if (opts.skipCaps) return;
    // caps as triangle fans (quad with a repeated vertex = triangle)
    for (let i = 1; i < sides - 1; i++) {
      const a = pts[0], b = pts[i], c = pts[i + 1];
      this.quad([a[0], y1, a[1]], [b[0], y1, b[1]], [c[0], y1, c[1]], [c[0], y1, c[1]], layer, o); // top (+y)
      this.quad([a[0], y0, a[1]], [c[0], y0, c[1]], [b[0], y0, b[1]], [b[0], y0, b[1]], layer, o); // bottom (-y)
    }
  }

  get isEmpty() {
    return this.indices.length === 0;
  }

  /** @returns {{vertexData: Float32Array, indexData: Uint32Array}} */
  finish() {
    return {
      vertexData: new Float32Array(this.verts),
      indexData: new Uint32Array(this.indices),
    };
  }
}
