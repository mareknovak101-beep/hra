/**
 * main — bootstrap: build every procedural asset, assemble the ship and the
 * star system, hand the loop to Engine. No external anything (pillar 4).
 *
 * Phase 3 wiring: space renders behind the interior every frame, and the
 * pilot seat swaps the state machine into FLIGHT — the same first-person
 * camera lerps into the seat; it never leaves the player's head.
 */
import { RENDER, FLIGHT, GAME_VERSION, PALETTE, PLAYER, LIGHTING, isMobile } from './core/Constants.js';
import { Engine } from './core/Engine.js';
import { Renderer } from './core/Renderer.js';
import { AssetManager } from './core/AssetManager.js';
import { InputManager } from './core/InputManager.js';
import { StateManager, STATES } from './core/StateManager.js';
import { EventBus } from './core/EventBus.js';
import { AudioEngine } from './core/AudioEngine.js';
import { Debug } from './utils/Debug.js';
import { clamp, Vec3, Quat, Mat4 } from './utils/MathUtils.js';
import { PixelFont } from './rendering/PixelFont.js';
import { TextureAtlas } from './rendering/TextureAtlas.js';
import { TextureFactory } from './rendering/TextureFactory.js';
import { LightSystem } from './rendering/LightSystem.js';
import { PixelRenderer } from './rendering/PixelRenderer.js';
import { SpaceRenderer } from './rendering/SpaceRenderer.js';
import { PostProcess } from './rendering/PostProcess.js';
import { ShipMap, SPAWN } from './interior/ShipMap.js';
import { STATION_ZONES, STATION_CONNECTIONS, STATION_SPAWN } from './data/StationPlan.js';
import { STATION_DRESSERS } from './interior/rooms/Station.js';
import { WRECK_ZONES, WRECK_CONNECTIONS, WRECK_SPAWN, WRECK_DEPTH } from './data/WreckPlan.js';
import { WRECK_DRESSERS } from './interior/rooms/Wreck.js';
import { InteriorRenderer } from './interior/InteriorRenderer.js';
import { Player } from './player/Player.js';
import { HUD } from './ui/HUD.js';
import { Crosshair } from './ui/Crosshair.js';
import { NotificationSystem } from './ui/NotificationSystem.js';
import { TouchControls } from './ui/TouchControls.js';
import { SettingsMenu } from './ui/SettingsMenu.js';
import { CelestialInfo } from './ui/CelestialInfo.js';
import { WarpPanel } from './ui/WarpPanel.js';
import { InventoryUI } from './ui/InventoryUI.js';
import { TradingSystem } from './gameplay/TradingSystem.js';
import { QuestSystem } from './gameplay/QuestSystem.js';
import { FactionSystem } from './gameplay/FactionSystem.js';
import { TradingUI } from './ui/TradingUI.js';
import { Fabrication } from './gameplay/Fabrication.js';
import { ShipStations } from './gameplay/ShipStations.js';
import { Crew } from './entities/Crew.js';
import { Dialogue, crewName } from './gameplay/Dialogue.js';
import { DialogueUI } from './ui/DialogueUI.js';
import { FabricatorUI } from './ui/FabricatorUI.js';
import { JournalUI } from './ui/JournalUI.js';
import { HackingMinigame } from './ui/HackingMinigame.js';
import { CharacterCreation } from './ui/CharacterCreation.js';
import { LORE } from './data/LoreEntries.js';
import { Settings } from './core/Settings.js';
import { SaveSystem } from './core/SaveSystem.js';
import { StarSystem } from './world/StarSystem.js';
import { SYSTEMS as AUTHORED } from './data/StarSystemsData.js';
import { generateGalaxy } from './data/GalaxyGen.js';

/**
 * THE CHART. One seed per save: the ten authored systems keep their ids and
 * their lore and are placed as anchors, and eighteen procedural systems fill in
 * around them, so every commission gets the same story in a different galaxy.
 *
 * The seed is read here at module scope because `SYSTEMS[0]` is needed to build
 * the starting StarSystem before anything else exists. A fresh game with no
 * stored seed mints one and writes it back immediately, so the chart is stable
 * from the very first frame rather than being regenerated on the next boot.
 */
const GALAXY_KEY = 'starrift.galaxySeed';
function galaxySeed() {
  try {
    const raw = globalThis.localStorage?.getItem(GALAXY_KEY);
    const n = raw != null ? Number(raw) : NaN;
    if (Number.isFinite(n) && n > 0) return n >>> 0;
    const mint = (Math.floor(Math.random() * 0xffffffff) >>> 0) || 0x51a2c3;
    globalThis.localStorage?.setItem(GALAXY_KEY, String(mint));
    return mint;
  } catch { return 0x51a2c3; }
}
const galaxy = generateGalaxy(galaxySeed(), AUTHORED);
const SYSTEMS = galaxy.systems;
import { STAR_TYPES } from './data/CelestialGen.js';
import { ITEMS } from './data/ItemRegistry.js';
import { Inventory } from './gameplay/Inventory.js';
import { rollContainer } from './gameplay/Loot.js';
import { Progression } from './gameplay/Progression.js';
import { ProximityScanner } from './gameplay/ProximityScanner.js';
import { NoiseSystem } from './gameplay/NoiseSystem.js';
import { TensionDirector } from './gameplay/TensionDirector.js';
import { Spaceship } from './ship/Spaceship.js';
import { ShipSystems } from './ship/ShipSystems.js';
import { FlightController } from './ship/FlightController.js';
import { ThrusterFX } from './ship/ThrusterFX.js';
import { buildFreighter, buildAethon, buildKethFighter, buildDriftDrone,
  buildKethCorvette, buildPlayerHull } from './ship/ShipExterior.js';
import { buildAllStructures } from './world/Structures.js';
import { Boarding } from './gameplay/Boarding.js';
import { SpaceWalk } from './player/SpaceWalk.js';
import { Landing } from './gameplay/Landing.js';
import { LandingUI } from './ui/LandingUI.js';
import { EntryVeil } from './ui/EntryVeil.js';
import { ShipyardUI } from './ui/ShipyardUI.js';
import { surfaceColors } from './data/SurfaceGen.js';
import { BoardingUI } from './ui/BoardingUI.js';
import { SpaceCombat } from './combat/SpaceCombat.js';
import { PersonalCombat } from './combat/PersonalCombat.js';
import { Boarders } from './entities/Boarders.js';
import { shipClass, applyShipClass, livery } from './data/ShipClasses.js';
import { plasticButton, plasticPanel, hazardBar, applyBootChrome, applyLoadingChrome,
  framePanel, frameBackdrop, showScrim, bookmarkBar } from './ui/Chrome.js';

/**
 * Animation frames per celestial surface (star photospheres, cloud decks). Each
 * set walks a closed circle through noise space, so the cycle loops seamlessly
 * — 4 frames is enough to read as chaotic boiling without ballooning either
 * boot time (they're generated, not loaded) or texture memory.
 */
// 6, not 4. Four frames at STAR_FPS 3.2 is a 1.25 s cycle, short enough that the
// eye locks onto the repeat and the photosphere reads as a looping GIF rather
// than a boiling surface. Six at a slower rate is a 2.4 s cycle. Affordable now
// that star surfaces are built per class on demand instead of all eleven.
const CEL_FRAMES = 6;
const CEL_FRAME_IDX = Array.from({ length: CEL_FRAMES }, (_, i) => i);

const canvas = document.getElementById('game');
const loadingEl = document.getElementById('loading');
const loadingStatus = document.getElementById('loading-status');
const loadingFill = document.getElementById('loading-fill');
const gateEl = document.getElementById('gate');
const pauseEl = document.getElementById('pause');

/**
 * Automatic screen-size adjustment (owner task): fill the player's display.
 * Pure integer scaling left huge dead bars on phones (a 2.4× fit rendered at
 * 2×, wasting ~40% of the screen). Now: integer scale when it covers ≥88% of
 * the limiting axis, half-integer steps when those get close, and a plain
 * best-fit fractional scale otherwise — always nearest-neighbour, so pixels
 * stay square and crisp at every size. Re-fits on resize, rotation and
 * visual-viewport changes (mobile browser chrome collapsing).
 */
function fitCanvas() {
  const vw = window.visualViewport?.width ?? window.innerWidth;
  const vh = window.visualViewport?.height ?? window.innerHeight;
  const scale = Math.min(vw / RENDER.WIDTH, vh / RENDER.HEIGHT);
  let s;
  if (scale < 1) {
    s = scale; // tiny screens: fill what we have
  } else if (Math.floor(scale) / scale >= 0.88) {
    s = Math.floor(scale); // integer fit is close enough — pixel-perfect
  } else if (Math.floor(scale * 2) / 2 / scale >= 0.92) {
    s = Math.floor(scale * 2) / 2; // half-integer keeps pixels near-square
  } else {
    s = scale; // fill the screen; CSS nearest-neighbour keeps it crisp
  }
  canvas.style.width = `${Math.round(RENDER.WIDTH * s)}px`;
  canvas.style.height = `${Math.round(RENDER.HEIGHT * s)}px`;
}
window.addEventListener('resize', fitCanvas);
window.addEventListener('orientationchange', fitCanvas);
window.visualViewport?.addEventListener('resize', fitCanvas);
fitCanvas();

// Build stamp — a stale cached build is immediately visible on-screen, and
// logged so it can be confirmed from remote consoles.
const stampEl = document.getElementById('build-stamp');
if (stampEl) stampEl.textContent = `BUILD ${GAME_VERSION}`;
console.log(`STARRIFT build ${GAME_VERSION}`);

async function boot() {
  const debug = new Debug();
  const events = new EventBus();
  const state = new StateManager(events);
  const input = new InputManager(events);
  const renderer = new Renderer(canvas);
  const assets = new AssetManager(renderer);
  // full-frame CRT pass (Phase 8): scene → offscreen → analog-monitor blit
  const post = new PostProcess(renderer);
  post.setEnabled(Settings.get('crt'));

  // -- adaptive input: the DEVICE decides, not a UA sniff ---------------------
  // Any genuine touch anywhere flips the session to touch controls (a touch
  // fires before its synthesized click, so the boarding tap itself is enough).
  // UA detection only pre-seeds the flag so the first frame is already right.
  let touchActive = isMobile() || new URLSearchParams(location.search).has('touch');
  window.addEventListener('touchstart', () => { touchActive = true; }, { passive: true });

  const progress = (msg, pct) => {
    loadingStatus.textContent = msg;
    if (pct !== undefined) loadingFill.style.width = `${Math.round(pct * 100)}%`;
  };

  // shaders
  await assets.loadPrograms([
    ['interior', 'src/rendering/shaders/interior'],
    ['hud', 'src/rendering/shaders/hud'],
    ['space', 'src/rendering/shaders/space'],
    ['stars', 'src/rendering/shaders/stars'],
  ], progress);

  // fonts + textures — all generated, nothing loaded
  applyLoadingChrome(); // boot screen gets the bulkhead surround before any work
  progress('RASTERIZING TYPEFACES');
  const font = new PixelFont();
  const fontTexture = renderer.createTexture2D({
    width: font.atlasW, height: font.atlasH, data: font.data,
  });

  const atlas = new TextureAtlas();
  const factory = new TextureFactory(atlas, font);
  await factory.generateAll(progress);
  const atlasTextures = atlas.upload(renderer); // { albedo, normal }

  progress('COATING HELMET GLASS', 0.86);
  const overlayTexture = renderer.createTexture2D(factory.helmetOverlay());

  // the universe outside the glass — five systems, one loaded at a time
  progress('CHARTING SOL PRIME', 0.9);
  let system = new StarSystem(SYSTEMS[0]);
  const shipState = new Spaceship(SYSTEMS[0].shipStart.pos);
  shipState.updateConjugate();
  const space = new SpaceRenderer(renderer);
  space.tex = {
    sun: renderer.createTexture2D(factory.sunTexture()),
    // Four nebula sheets, not one. Every system shared a single cloud, so the
    // background looked identical wherever you jumped — see SpaceRenderer.setSky.
    nebula: [0, 1, 2, 3].map((v) => renderer.createTexture2D(factory.nebulaTexture(v))),
    // Planet surfaces are built ENTIRELY on demand now (ensureBodyTex +
    // primeSystemTex). This block used to eagerly generate eight kinds at boot,
    // which was redundant with priming the starting system and, once the sheets
    // went to 768x384, cost about a second and a half of the loading screen for
    // worlds the player might never fly to.
    planets: {},
    // hull plating TILES — these must repeat (see Renderer.createTexture2D):
    // exterior meshes derive planar UVs from model space and run far outside
    // 0..1, so clamped they all sampled one edge column and read as flat colour
    hull: renderer.createTexture2D(factory.hullTexture(), { repeat: true }),
    hullAethon: renderer.createTexture2D(factory.aethonHullTexture(), { repeat: true }),
    extGlow: renderer.createTexture2D(factory.extGlowTexture(), { repeat: true }),
    blackHole: renderer.createTexture2D(factory.blackHoleTexture()),
    keth: renderer.createTexture2D(factory.kethTexture(), { repeat: true }),
    drift: renderer.createTexture2D(factory.driftTexture(), { repeat: true }),
    // living atmospheres: each deck is CEL_FRAMES frames of churning cloud that
    // loop seamlessly, cycled by the renderer on top of differential rotation
    clouds: {}, // built with their planet, see ensureBodyTex
    // 3D star surfaces + coronas per spectral class (O B A F G K M, red giant,
    // white dwarf, K-subdwarf, K+M binary). Filled LAZILY by ensureStarTex —
    // at 512x256 x CEL_FRAMES a full eleven-class set costs several seconds of
    // boot for eight sets no system in the game ever shows. Surfaces are
    // animated: each frame is a step around a closed loop in noise space, so the
    // granulation churns chaotically and never snaps back.
    stars: {},
    coronas: {},
    // CME / prominence plasma, tinted PER SPECTRAL CLASS so an eruption is made
    // of the star's own light (2 crawling frames each; 32px, so this is cheap)
    plasma: {},
    // and the eruption's own oriented thread sprites, per class (see below)
    filament: {},
    flames: [0, 1, 2, 3].map((f) => renderer.createTexture2D(factory.flameTexture(f))),
    coldJet: [0, 1, 2].map((f) => renderer.createTexture2D(factory.coldJetTexture(f))),
    glowAmber: renderer.createTexture2D(factory.glowTexture(PALETTE.AMBER_MACHINE[2])),
    glowBlue: renderer.createTexture2D(factory.glowTexture('#6aa0e0')),
    glowWhite: renderer.createTexture2D(factory.glowTexture('#fff0d6')),
    // Keth rounds bloom red. WARNING_RED, not a saturated primary — the ban on
    // neon applies to weapon fire as much as to a wall panel.
    glowRed: renderer.createTexture2D(factory.glowTexture(PALETTE.WARNING_RED[2])),
    shield: renderer.createTexture2D(factory.shieldTexture()),
    // the shockwave a round leaves running across the deflector from its impact
    shieldRipple: renderer.createTexture2D(factory.shieldRippleTexture()),
    smoke: [0, 1].map((f) => renderer.createTexture2D(factory.smokeTexture(f))),
    swirl: renderer.createTexture2D(factory.swirlTexture()),
    ring: renderer.createTexture2D(factory.ringTexture()),
    // the jump singularity as a real 3D body: an equirect skin for the horizon
    // SPHERE, a repeating band for the accretion DISK MESH (u wraps once around
    // the annulus, so this one has to tile), and the camera-facing lensed
    // crescents that bend the far side of the disk over the shadow
    horizon: renderer.createTexture2D(factory.horizonTexture()),
    accretion: [0, 1, 2].map((f) =>
      renderer.createTexture2D(factory.accretionTexture(f), { repeat: true })),
    lensArc: renderer.createTexture2D(factory.lensArcTexture()),
    // PLANETARY rings (not the warp singularity's photon ring above). Two halves
    // of one ellipse: 'far' is drawn before the planet sphere and 'near' after,
    // which is how the ring passes behind and in front with no depth buffer.
    planetRing: {
      far: renderer.createTexture2D(factory.planetRingTexture('far')),
      near: renderer.createTexture2D(factory.planetRingTexture('near')),
    },
    // PER-BODY ring sheets, keyed by body id. Each ringed giant's gaps are
    // resonances with its OWN moons (CelestialGen.buildRings), so they cannot
    // share one texture — the whole point is that two giants look different.
    // Built on demand; there are only a handful of ringed bodies on the chart.
    rings: {},
  };
  /**
   * Put the ship where a system expects it AND point it at the place.
   *
   * Position alone was not enough: the jump left whatever attitude the sequence
   * ended on, which is usually empty sky, so you arrived staring at black with
   * the star and the home world behind you. That is what made a working jump
   * look like it had done nothing. `shipStart.look` (from CelestialGen) is the
   * direction with the home world and its star dead ahead.
   */
  const arriveAt = (def) => {
    const st = def.shipStart;
    Vec3.set(shipState.pos, st.pos[0], st.pos[1], st.pos[2]);
    Vec3.set(shipState.vel, 0, 0, 0);
    if (shipState.angVel) { shipState.angVel[0] = 0; shipState.angVel[1] = 0; shipState.angVel[2] = 0; }
    if (st.look) {
      Quat.lookYaw(shipState.quat, st.look);
      shipState.snapHistory(); // hard cut — never lerp across a system entry
      shipState.updateConjugate(); // qConj feeds the sky + local transforms
    }
    // and a sky that belongs to this system, not the one we just left
    space.setSky(hashId(def.id), space.tex?.nebula?.length ?? 1);
  };

  /** Stable small integer from a system id — seeds that system's sky. */
  const hashId = (id) => {
    let h = 2166136261;
    for (let i = 0; i < id.length; i++) { h ^= id.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0) % 100000;
  };

  /**
   * Build (once) the photosphere frames, corona and plasma tint for a spectral
   * class. Called at boot for the starting system and on every warp arrival, so
   * the work lands during a loading beat rather than mid-frame; SpaceRenderer
   * also calls it defensively from _drawStar in case a code path adds a star
   * without going through a system load.
   */
  const ensureStarTex = (classKey) => {
    const k = STAR_TYPES[classKey] ? classKey : 'G';
    if (space.tex.stars[k]) return;
    // repeat:true because the shader shifts the sampling longitude per latitude
    // for differential rotation (space.frag u_diffRot) — clamped, that shear
    // would smear the seam column across the whole disc
    space.tex.stars[k] = CEL_FRAME_IDX.map((f) =>
      renderer.createTexture2D(factory.starSurfaceTexture(k, f, CEL_FRAMES), { repeat: true }));
    space.tex.coronas[k] = renderer.createTexture2D(factory.coronaTexture(k));
    space.tex.plasma[k] = [0, 1].map((f) =>
      renderer.createTexture2D(factory.plasmaTexture(f, TextureFactory.starTint(k))));
    // The eruption is built from oriented THREADS now, not blobs (see
    // TextureFactory.filamentTexture). Two weights x 3 frames, 16x64 each — far
    // cheaper than the three 48px shells it replaces.
    space.tex.filament[k] = {
      core: [0, 1, 2].map((f) =>
        renderer.createTexture2D(factory.filamentTexture(f, TextureFactory.starTint(k), 'core'))),
      wisp: [0, 1, 2].map((f) =>
        renderer.createTexture2D(factory.filamentTexture(f, TextureFactory.starTint(k), 'wisp'))),
    };
  };
  space.ensureStarTex = ensureStarTex;
  ensureStarTex('G'); // fallback set: every lookup falls back to G if a key misses
  ensureStarTex(system.star.classKey); // and whichever star we actually start under

  /**
   * Same contract as ensureStarTex, for planet surfaces: build a body kind's
   * sheet (and its cloud deck, if the kind has weather) the first time anything
   * asks to draw it. Half the roster only appears on the off-route spurs, and
   * generating all of it at boot would charge every player for worlds they may
   * never visit — a 384x192 surface plus CEL_FRAMES cloud frames is not free.
   * SpaceRenderer calls this from both body draw paths.
   */
  const CLOUDED = new Set(['oceanic', 'jungle', 'gas', 'toxic', 'tundra']);
  const ensureBodyTex = (kind) => {
    if (!kind || space.tex.planets[kind]) return;
    space.tex.planets[kind] = renderer.createTexture2D(factory.planetTexture(kind));
    if (CLOUDED.has(kind)) {
      space.tex.clouds[kind] = CEL_FRAME_IDX.map((f) =>
        renderer.createTexture2D(factory.cloudTexture(kind, f, CEL_FRAMES)));
    }
  };
  space.ensureBodyTex = ensureBodyTex;
  /**
   * Build a ringed body's own far/near sheets the first time it is drawn.
   * Two 256² textures per ringed body — cheap, and there are at most a couple
   * per system.
   */
  const ensureRingTex = (body) => {
    if (!body?.rings || space.tex.rings[body.id]) return;
    space.tex.rings[body.id] = {
      far: renderer.createTexture2D(factory.planetRingTexture('far', body.rings)),
      near: renderer.createTexture2D(factory.planetRingTexture('near', body.rings)),
    };
  };
  space.ensureRingTex = ensureRingTex;
  /** Pre-build every kind a system contains, during its loading beat. */
  const primeSystemTex = (def) => {
    ensureStarTex(def.star.classKey);
    for (const b of def.bodies) {
      ensureBodyTex(b.kind);
      for (const m of b.moons ?? []) ensureBodyTex(m.kind);
    }
  };
  primeSystemTex(SYSTEMS[0]);
  space.setSky(hashId(system.def.id), space.tex.nebula.length);

  space.setFreighterMesh(buildFreighter());
  // Stations, shipyards, refineries, relays, wrecks, mines and civilian traffic.
  // Fourteen meshes for ~22k vertices, built once — every one of these used to
  // be the freighter at a different scale.
  space.setStructureMeshes(buildAllStructures());
  space.setAethon(buildAethon()); // player exterior; re-built per hull at commission
  space.setCombatMeshes({ keth: buildKethFighter(), drift: buildDriftDrone(),
    keth_corvette: buildKethCorvette() });
  const flightCtl = new FlightController(shipState, input, events);
  const thruster = new ThrusterFX();
  const systems = new ShipSystems(); // live fuel/power/O2/heat/rad/shield/hull

  // the ship you walk
  progress('ASSEMBLING HSV AETHON', 0.95);
  const lights = new LightSystem();
  const shipMap = new ShipMap(events);
  shipMap.build({ atlas, lights, renderer });

  const player = new Player(input, shipMap, events, SPAWN);
  const interior = new InteriorRenderer(renderer, shipMap, lights, atlasTextures);
  // Diegetic CRT terminals: the console glass gets its own scanlines, refresh
  // roll and phosphor bloom, painted in the screen's UV space so it reads as a
  // monitor in the room. Screens are registered consecutively, so the atlas
  // range identifies them. Shares the one CRT SCREEN setting with PostProcess.
  const screenLo = atlas.layer('screen_amber');
  const screenHi = atlas.layer('screen_off');
  const applyCrt = () => {
    const on = Settings.get('crt');
    const k = Settings.get('crtStrength') ?? 1;
    post.setEnabled(on);
    post.setStrength(k);
    // The diegetic screens inside the world carry the same figure, so turning
    // the tube down does not leave the terminals scanlined while the frame
    // around them is clean.
    interior.screenCrt = [screenLo, screenHi, on ? k : 0];
  };
  applyCrt();
  Settings.onChange((key) => {
    if (key === null || key === 'crt' || key === 'crtStrength') applyCrt();
  });
  const pix = new PixelRenderer(renderer);
  pix.whiteUV = font.whiteUV;
  const notifications = new NotificationSystem();
  const crosshair = new Crosshair();
  // Floor for the HUD gutter while the touch layer is up, in UI px. The touch
  // clusters are sized as percentages of the canvas box, so unlike the chip
  // column they cannot be measured off one element — 44 leaves 392 px of usable
  // HUD width between the gutters, which is what the panels are laid out for.
  // Gutter the HUD must keep clear of, in UI pixels of the 480-wide grid. Raised
  // 44 -> 58 (session 17c): the owner's screenshot shows VITALS, DRIVE and SHIP
  // growing under the touch keys, and 44 UI px is only about 117 CSS px on a
  // 1280-wide canvas — narrower than a 68px FIRE key plus its 1.5% margin plus the
  // panel's own border. Every flight button now lives in one of these two gutters,
  // so this single number is what keeps the two layers apart.
  const HUD_TOUCH_INSET = 58;
  const hud = new HUD(pix, font, fontTexture, overlayTexture);
  const audio = new AudioEngine(events);
  /**
   * THE STATION DECK — a second ShipMap, built the first time you dock and kept.
   *
   * Kept rather than rebuilt because building a deck is the expensive part
   * (shells, props, colliders, one mesh per zone) and every station in the game
   * shares this plan: what differs between a trade post and a shipyard is which
   * counters ANSWER, not where the walls are. `stationHooks` is how that
   * difference is expressed, and it is rewritten per visit.
   */
  let stationMap = null;
  /** The record we are docked at, or null. Also what UNDOCK returns you to. */
  let dockedAt = null;
  /** Where the player was standing before boarding, to put them back. */
  let preDockPose = null;

  const stationPlan = {
    zones: STATION_ZONES, connections: STATION_CONNECTIONS,
    dressers: STATION_DRESSERS, spawn: STATION_SPAWN, leaves: new Set(),
  };

  /**
   * THE DERELICT DECK. Same story as the station: one plan, built on first use
   * and kept, because what differs between one wreck and the next is what is
   * still aboard rather than where the bulkheads are.
   */
  let wreckMap = null;
  let boardedWreck = null;
  let preBoardPose = null;
  const wreckPlan = {
    zones: WRECK_ZONES, connections: WRECK_CONNECTIONS,
    dressers: WRECK_DRESSERS, spawn: WRECK_SPAWN, leaves: new Set(),
  };

  /** Swap the walked deck. Everything that holds a map reference moves at once. */
  const useDeck = (map) => {
    // Every holder of a deck reference, moved in one place. `player.shipMap`
    // and `player.controller.shipMap` are the two that matter — collision,
    // interact raycasts and zone lookups all go through them — and the third,
    // the renderer's, is what actually draws the walls you are standing in.
    player.shipMap = map;
    player.controller.shipMap = map;
    interior.shipMap = map;
    game.shipMap = map;
    game.collision = map.collision;
  };

  /** Walk aboard whatever we just clamped onto. */
  const goAboard = (body) => {
    if (!stationMap) {
      stationMap = new ShipMap(events, [], 'station', stationPlan);
      stationMap.build({ atlas, lights, renderer });
    }
    dockedAt = body;
    // WHICH COUNTERS ANSWER. A building slip has a broker and no chandler; a
    // refinery has neither. The deck is the same deck either way — the hooks
    // are what make a shipyard a shipyard.
    stationMap.stationHooks = {
      undock: () => leaveStation(),
      trade: () => { input.exitPointerLock?.(); tradingUI.open(body); },
      outfit: () => { input.exitPointerLock?.(); tradingUI.open(body); },
      broker: body.shipyard
        ? () => { input.exitPointerLock?.(); shipyardUI.open(body); }
        : null,
      bar: () => notifications.push(`${body.name}: THE TAP RUNS. NOBODY ASKS WHERE YOU HAVE BEEN.`),
      /**
       * THE CLINIC. Health and radiation, for money — the one thing a station
       * can sell you that nothing in the hold can match.
       *
       * Priced off what is actually wrong with you rather than a flat fee, so
       * walking in scratched costs almost nothing and walking in half dead
       * costs what it should. Radiation is the expensive half: it is the only
       * survival stat with no field remedy that fully clears it.
       */
      medical: () => {
        const hurt = 100 - systems.health;
        const rads = systems.radiation;
        if (hurt < 2 && rads < 2) {
          notifications.push('THE MEDIC LOOKS YOU OVER AND SENDS YOU AWAY. NOTHING WRONG WITH YOU.');
          return;
        }
        const price = Math.max(8, Math.round(hurt * 2.4 + rads * 3.1));
        if (trading.credits < price) {
          notifications.push(`TREATMENT IS ${price} CR AND YOU HAVE ${Math.floor(trading.credits)}. `
            + 'THE MEDIC HAS HEARD IT BEFORE.');
          return;
        }
        trading.credits -= price;
        systems.health = 100;
        systems.radiation = 0;
        saveSys.save('clinic');
        notifications.push(`PATCHED UP AND FLUSHED OUT — ${price} CR. `
          + 'THE MEDIC DOES NOT ASK HOW YOU GOT ANY OF IT.');
      },
      log: () => journalUI.toggle(),
    };
    preDockPose = { pos: [...player.position], yaw: player.camera.yaw, pitch: player.camera.pitch };
    // The people. `stationMap.npcs` is authored by the room dressers when the
    // deck is built (once), so this is a re-seat rather than a rebuild — and
    // the NAMES come off the station's own id, so the chandler at Meridian is
    // not the chandler at Halvane.
    stationCrew.build(atlas, renderer);
    stationCrew.place(stationMap.npcs);
    interior.actors = stationCrew;
    useDeck(stationMap);
    Vec3.set(player.position, STATION_SPAWN.pos[0], STATION_SPAWN.pos[1], STATION_SPAWN.pos[2]);
    player.camera.yaw = STATION_SPAWN.yaw;
    player.camera.pitch = 0;
    player.controller.interactTarget = null;
    resumeState = STATES.PLAYING;
    state.transition(STATES.PLAYING);
    touch?.setMode('walk');
    input.requestPointerLock?.(canvas);
    notifications.push(`ABOARD ${body.name} — CONCOURSE THROUGH THE ACCESS LOCK`);
  };

  /** Back down the arm to your own hull. */
  const leaveStation = () => {
    if (!dockedAt) return;
    stationCrew.clear();
    interior.actors = null;
    useDeck(shipMap);
    const p = preDockPose ?? { pos: [...SPAWN.pos], yaw: SPAWN.yaw, pitch: 0 };
    Vec3.set(player.position, p.pos[0], p.pos[1], p.pos[2]);
    player.camera.yaw = p.yaw; player.camera.pitch = p.pitch ?? 0;
    player.controller.interactTarget = null;
    notifications.push(`CLAMPS RELEASED — BACK ABOARD THE ${shipClass(pilot.shipClass).hullName}`);
    dockedAt = null;
    resumeState = STATES.PLAYING;
    state.transition(STATES.PLAYING);
    input.requestPointerLock?.(canvas);
  };

  /**
   * Cross to a wreck and go IN.
   *
   * `boarding.begin` still owns the run — the oxygen model, the hazard rolls
   * and the loot table are untouched. What changed is that going one
   * compartment deeper is now walking one compartment deeper, and the salvage
   * point in each is what calls `advance`.
   */
  /**
   * Standing room for whatever is aboard, derived from the deck plan rather
   * than hand-listed, so a compartment added to `WreckPlan` gets populated
   * without touching this file.
   *
   * THE BREACH IS ALWAYS EMPTY. Depth 0 is the hole you came in by and the hole
   * you leave by; putting a hostile in it means being attacked before you have
   * finished arriving and cut off from the exit at the same time, which is not
   * tension, it is an ambush with no counterplay.
   */
  const wreckSpots = () => {
    const out = [];
    for (let d = 1; d < WRECK_DEPTH.length; d++) {
      const z = WRECK_ZONES.find((q) => q.id === WRECK_DEPTH[d]);
      if (!z?.rect) continue;
      const { x0, x1, z0, z1 } = z.rect;
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      // Two candidate spots per compartment, off the centreline, so a room that
      // takes two of them does not stack them in one place.
      out.push({ pos: [cx + (x1 - x0) * 0.22, 0, cz - (z1 - z0) * 0.2], zone: z.id, depth: d });
      out.push({ pos: [cx - (x1 - x0) * 0.24, 0, cz + (z1 - z0) * 0.22], zone: z.id, depth: d });
    }
    return out;
  };

  const boardWreck = (body) => {
    boarding.begin(body);
    if (!boarding.active) return;
    if (!wreckMap) {
      wreckMap = new ShipMap(events, [], 'wreck', wreckPlan);
      wreckMap.build({ atlas, lights, renderer });
    }
    boardedWreck = body;
    wreckMap.wreckHooks = {
      // Walking into a compartment is not looting it; reaching the salvage
      // point is. The zone id decides how deep this counts as, so a player who
      // sprints to the drive section pays for every compartment between.
      salvage: (zoneId) => {
        const want = WRECK_DEPTH.indexOf(zoneId);
        const st = boarding.status();
        if (!st) return;
        if (want <= st.at - 1) { notifications.push('ALREADY STRIPPED THIS ONE.'); return; }
        for (let i = st.at; i <= want && boarding.active; i++) boarding.advance();
      },
      leave: () => leaveWreck(),
    };
    preBoardPose = { pos: [...player.position], yaw: player.camera.yaw, pitch: player.camera.pitch };
    /**
     * WHO ELSE IS HERE. Rolled off the hull's own id, so this derelict has the
     * same thing aboard every time and the one parked beside it has something
     * else — and a hull you have already cleared stays cleared, because
     * `boarders.cleared` rides in the save.
     *
     * `danger` comes off the body, so a wreck in the Pale is worse than a wreck
     * over Sol Prime without a table that says so twice.
     */
    boarders.build(atlas, renderer);
    /**
     * WHOSE HULL IS THIS. A derelict rolls for whatever moved in after the crew
     * stopped answering; a hostile you crippled yourself is full of the people
     * you were just shooting at, so the species is forced and the deck is
     * considerably more dangerous than a found wreck.
     */
    const own = body.crippled ? (body.faction === 'drift' ? 'drift' : 'keth') : null;
    const aboard = boarders.spawnFor(body.id, wreckSpots(), {
      danger: body.crippled ? 0.95 : (body.danger ?? 0.5),
      species: own,
      collision: wreckMap.collision,
    });
    interior.actors = boarders;
    if (body.crippled) {
      // The faction notices. Cutting into a hull whose crew is still aboard is
      // not salvage, and the ledger should say so.
      events.emit('boarding:hostile', { faction: body.faction, id: body.id });
      notifications.push('YOU ARE CUTTING INTO A CREWED HULL. THEY KNOW YOU ARE COMING.');
    } else if (aboard) {
      notifications.push('MOVEMENT ON THE DECK — YOU ARE NOT ALONE IN HERE');
    }
    useDeck(wreckMap);
    // DARK. The one deck in the game with no working light on it, so the helmet
    // lamp stops being a convenience and starts being the reason you can see.
    interior.ambient = LIGHTING.AMBIENT * 0.18;
    interior.brightness = 0.55;
    Vec3.set(player.position, WRECK_SPAWN.pos[0], WRECK_SPAWN.pos[1], WRECK_SPAWN.pos[2]);
    player.camera.yaw = WRECK_SPAWN.yaw;
    player.camera.pitch = 0;
    player.controller.interactTarget = null;
    player.light.on = true;
    resumeState = STATES.PLAYING;
    state.transition(STATES.PLAYING);
    touch?.setMode('walk');
    input.requestPointerLock?.(canvas);
  };

  /** Back out through the hole you cut. */
  const leaveWreck = () => {
    if (!boardedWreck) return;
    if (boarding.active) boarding.finish(false);
    if (boarders.checkCleared()) {
      notifications.push('NOTHING LEFT MOVING ABOARD. THE HULL IS YOURS.');
      progression?.award?.('salvage', 'clearHull');
    }
    boarders.clear();
    interior.actors = null;
    useDeck(shipMap);
    interior.ambient = LIGHTING.AMBIENT;
    interior.brightness = 1.0;
    const p = preBoardPose ?? { pos: [...SPAWN.pos], yaw: SPAWN.yaw, pitch: 0 };
    Vec3.set(player.position, p.pos[0], p.pos[1], p.pos[2]);
    player.camera.yaw = p.yaw; player.camera.pitch = p.pitch ?? 0;
    player.controller.interactTarget = null;
    boardedWreck = null;
    resumeState = STATES.PLAYING;
    state.transition(STATES.PLAYING);
    input.requestPointerLock?.(canvas);
  };

  const celestial = new CelestialInfo((body) => {
    if (body.station) {
      if (body.refuel) {
        systems.fuel = 100;
        systems.warpFuel = 100;
        // Ordnance too: magazines are the reason to come back to a station now
        // that there are nine hardpoints to keep fed.
        combat.loadout?.resupplyAll(0.5);
        notifications.push(`DOCKED AT ${body.name} — FUEL, AIR AND ORDNANCE REPLENISHED`);
        events.emit('ship:docked', body.id);
        // AND THEN YOU GET OUT AND WALK. Docking used to open a DOM panel over
        // the cockpit — the one thing left in this game that was a menu where
        // it should have been a place. The counters are still the same
        // counters (see interior/rooms/Station.js); you have to go and stand
        // at them. Which of them answer is set per visit, so a building slip
        // has a broker and a trade post has a chandler without needing a
        // second deck.
        goAboard(body);
      } else {
        notifications.push(`${body.name}: NO DOCKING CLAMPS ANSWER. THE DOORS ARE OPEN ANYWAY.`);
      }
    } else if (body.traffic) {
      // Civilian traffic. Hailing one is the only interaction in the game that
      // is not docking, looting or shooting — and the ore tenders and haulers
      // run a counter off the manifest, which is what makes a lane worth
      // flying down rather than just worth looking at.
      notifications.push(`${body.name}: ${body.hail ?? 'NO RESPONSE'}`);
      events.emit('traffic:hailed', body.id);
      if (body.trade) {
        input.exitPointerLock?.();
        tradingUI.open(body);
      }
    } else if (body.boardable || body.derelict) {
      // ABOARD, ON FOOT. The compartment list is gone: you cross over, you are
      // standing in the breach, and everything past it you have to walk to.
      boardWreck(body);
    } else if (body.anomaly) {
      notifications.push(`${body.name}: SCAN RETURNS MASS AND SHAPE. NO MATERIAL. NO ANSWER.`);
      events.emit('anomaly:scanned', body.id);
    } else if (landing.survey(body)) {
      // COMMIT TO THE DESCENT. From here the ship flies it — see Landing._entry
      // for why entry is not a cutscene.
      // The mesh goes up when it is finished, a second or so from now — see the
      // `landing:terrain` handler. Building it at breakout instead meant a
      // hitch and a jump-cut in the middle of a descent the player was flying.
      //
      // The hull's position goes with it, because a body is a whole sphere now
      // and a descent has to pick a point on it: you come down under wherever
      // you were in orbit, so two approaches to the same world put you on
      // different ground.
      landing.begin(body, shipState.pos);
    } else {
      // Gas giants and stars: there is nothing to put a ship down on, and
      // saying so is more honest than a LAND button that logs a site.
      notifications.push(`${body.name}: NO SURFACE. ATMOSPHERIC SCAN COMPLETE — `
        + 'CLOUD DECK COMPOSITION LOGGED.');
      events.emit('body:scanned', body.id);
    }
  });

  /**
   * Strip a body. The richest tier in `LootTables` — an alien carries what it
   * was carrying, and nobody has been through it before you.
   *
   * Declared up here with the other loot verbs (and hoisted as a `function`, so
   * the walking branch a thousand lines down can call it) because it IS a loot
   * verb: same roll, same inventory path, same "hold full" failure. The only
   * difference is what you had to do to earn the search.
   */
  function stripRemains(body) {
    if (!body || body.stripped) return false;
    body.stripped = true;
    const roll = rollContainer(`${body.K.name} REMAINS`, body.id.length + 7, {
      tier: 'alien',
      find: progression.bonus('findChance'),
      rare: progression.bonus('rareBias'),
    });
    progression.award('salvage', 'remains');
    if (!roll.items.length) {
      notifications.push(`${body.K.name} — NOTHING ON IT WORTH THE AIR`);
      return true;
    }
    const got = [];
    for (const { id, qty } of roll.items) {
      const added = inventory.add(id, qty);
      if (added > 0) got.push(`${ITEMS[id].name}${added > 1 ? ` ×${added}` : ''}`);
      if (added < qty) { notifications.push('HOLD FULL — LEFT THE REST'); break; }
    }
    notifications.push(got.length
      ? `OFF THE ${body.K.name}: ${got.join(', ').toUpperCase()}`
      : 'HOLD FULL');
    return true;
  }

  // -- interstellar warp (Phase 4) --------------------------------------------
  /** @type {{phase:null|'infall'|'hole'|'consume'|'streak', t:number, target:object|null, swapped:boolean}} */
  const warp = { phase: null, t: 0, target: null, swapped: false };
  const warpPanel = new WarpPanel(SYSTEMS, (def) => {
    if (warp.phase) return;
    if (systems.warpFuel < FLIGHT.WARP_COST) {
      notifications.push('WARP FUEL LOW — DOCK AT A STATION TO REFUEL');
      return;
    }
    warp.phase = 'infall'; warp.t = 0; warp.target = def; warp.swapped = false;
    notifications.push(`WARP DRIVE SPUN UP — TARGET ${def.name}`);
  }, galaxy);
  // white-out flash for the moment of the jump — a DOM overlay, not a shader
  const flashEl = document.createElement('div');
  flashEl.style.cssText = 'position:fixed;inset:0;background:#e8e8f0;opacity:0;pointer-events:none;z-index:40;transition:opacity 0.55s;';
  document.body.appendChild(flashEl);
  const warpFlash = () => {
    flashEl.style.transition = 'opacity 0.12s';
    flashEl.style.opacity = '0.92';
    setTimeout(() => { flashEl.style.transition = 'opacity 0.7s'; flashEl.style.opacity = '0'; }, 160);
  };

  // -- inventory, loot, item use (Phase 5) ------------------------------------
  const inventory = new Inventory(events);
  /** containers already emptied this playthrough, by stable key */
  const searched = new Set();
  const containerKey = (rec) => {
    const label = typeof rec.label === 'function' ? rec.label() : rec.label;
    return `${label}@${rec.min.map((v) => v.toFixed(1)).join(',')}`;
  };
  const CONTAINER_RE = /CRATE|CARGO|LOCKER|CABINET|RACK|SHELF|STORAGE|SUPPLY|PANTRY/i;
  const tryLoot = (rec) => {
    const label = typeof rec.label === 'function' ? rec.label() : rec.label;
    // bunks: sleep restores rest (a light time-skip that costs food and water)
    if (/BUNK|BED/i.test(label ?? '')) {
      if (systems.fatigue >= 95) return false; // not tired — prop flavor runs
      systems.fatigue = 100;
      systems.hunger = Math.max(5, systems.hunger - 8);
      systems.thirst = Math.max(5, systems.thirst - 6);
      saveSys.save('sleep');
      notifications.push('YOU SLEEP. THE SHIP HUMS ON WITHOUT YOU. — REST 100');
      return true;
    }
    if (!CONTAINER_RE.test(label ?? '')) return false;
    const key = containerKey(rec);
    if (searched.has(key)) return false; // already emptied — prop flavor runs
    searched.add(key);
    /**
     * WHERE this container is decides how full it is, and WHO is opening it
     * decides what is at the bottom of it. See gameplay/Loot.js — the salvage
     * level goes into the seed, so a locker you found nothing in at salvage 0
     * is genuinely a different locker at salvage 6.
     */
    const tier = boarding.active ? 'derelict'
      : state.is(STATES.SURFACE) ? 'surface'
        : shipMap.builtAs === 'station' ? 'station' : 'ship';
    const roll = rollContainer(label, key.length, {
      tier,
      find: progression.bonus('findChance'),
      rare: progression.bonus('rareBias'),
    });
    const drops = roll.items;
    events.emit('loot:searched', { label, tier, rare: roll.rare });
    if (!drops.length) { notifications.push('EMPTY. SOMEBODY GOT HERE FIRST.'); return true; }
    const got = [];
    for (const { id, qty } of drops) {
      const added = inventory.add(id, qty);
      if (added > 0) got.push(`${ITEMS[id].name}${added > 1 ? ` ×${added}` : ''}`);
      if (added < qty) { notifications.push('HOLD FULL — LEFT THE REST'); break; }
    }
    notifications.push(got.length
      ? `${roll.rare ? 'UNDER THE FALSE BOTTOM: ' : 'FOUND: '}${got.join(', ').toUpperCase()}`
      : 'HOLD FULL');
    return true;
  };
  const USE_VERB = {
    eat: 'EATEN', drink: 'DRUNK', med: 'ADMINISTERED', breathe: 'VALVE OPEN',
    refuel_ship: 'CELL SLOTTED', refuel_warp: 'CONDENSATE LOADED',
    ship_shield: 'CELL DISCHARGED', ship_hull: 'PLATE FIXED', ship_power: 'CELL SLOTTED',
  };
  const inventoryUI = new InventoryUI(inventory, (id) => {
    const def = ITEMS[id];
    if (!def?.onUse) return;
    if (def.onUse === 'noisemaker') {
      // only worth throwing when something is listening
      if (tension.distract()) inventory.remove(id, 1);
      else notifications.push('YOU WEIGH THE CHARGE IN YOUR HAND. NOTHING IS LISTENING. YET.');
      return;
    }
    if (inventory.remove(id, 1) < 1) return;
    audio.playConsume?.(def.onUse === 'drink' ? 'drink'
      : def.onUse === 'med' ? 'med' : 'eat');
    const report = systems.applyItem(def.effect ?? {});
    notifications.push(`${def.name.toUpperCase()}: ${USE_VERB[def.onUse] ?? 'USED'}${report ? ' — ' + report : ''}`);
  }, (t) => notifications.push(t), {
    // The hold is a full-screen overlay with a text field in it; hand the mouse
    // over so the field is clickable, and take it back on the way out.
    onOpen: () => input.exitPointerLock?.(),
    onClose: () => {
      if (state.is(STATES.PLAYING) || state.is(STATES.FLIGHT)
        || state.is(STATES.EVA) || state.is(STATES.SURFACE)) {
        input.requestPointerLock?.(canvas);
      }
    },
  });

  // -- boarding: going aboard wrecks in a suit ---------------------------------
  // Constructed here, ABOVE the trading block, because `celestial`'s dock
  // callback (declared earlier) closes over it — the callback does not run until
  // a pointer press, so the ordering is legal, but it has to exist by then.
  // `let`, not `const`, and declared first: the notify closure below reads it,
  // and a `const` in the temporal dead zone throws through optional chaining
  // rather than short-circuiting. Nothing calls notify during construction
  // today, but the failure mode if anything ever does is a blank screen.
  let boardingUI = null;
  const boarding = new Boarding({
    inventory, systems, events,
    notify: (t) => { notifications.push(t); boardingUI?.push(t); },
    audio,
  });
  boardingUI = new BoardingUI(boarding, () => {
    if (state.is(STATES.FLIGHT)) input.requestPointerLock?.(canvas);
  });

  /**
   * WHAT THE PILOT GETS BETTER AT. Reads the event bus and nothing else, so no
   * other system had to learn it exists — see gameplay/Progression.js.
   */
  const progression = new Progression({ events, notify: (t) => notifications.push(t) });

  // -- landing: atmosphere, surface, and getting off again ---------------------
  let landingUI = null;
  const landing = new Landing({
    inventory, systems, events, audio, progression,
    notify: (t) => { notifications.push(t); landingUI?.push(t); },
  });
  landingUI = new LandingUI(landing, () => {
    if (state.is(STATES.SURFACE)) input.requestPointerLock?.(canvas);
  });
  // The ionisation envelope the descent hides inside. See ui/EntryVeil.js —
  // it is what makes the star system and the landscape two halves of one
  // continuous flight rather than two scenes with a cut between them.
  const entryVeil = new EntryVeil();
  /**
   * THE WORLD ARRIVES. Landing builds the heightfield a slice at a time behind
   * the closing envelope and fires this when the last slice lands; the upload
   * is the only part that has to happen on the main thread in one go, and it
   * happens while nothing can be seen through the plasma.
   */
  events.on('landing:terrain', (t) => space.setTerrain(t, surfaceColors(landing.profile)));
  /**
   * THE CAP MOVED. Every position expressed in the old cap's coordinates has to
   * move with it — and there is exactly one this file owns, the walker's.
   *
   * Nothing visible happens: the new cap holds the identical ground, so
   * subtracting the same offset from the boots and from the mesh leaves the
   * player standing on the same rock they were standing on. See
   * Landing._swapCap.
   */
  events.on('landing:recentre', ({ du, dv }) => {
    if (!surfacePos) return;
    surfacePos[0] -= du;
    surfacePos[2] -= dv;
  });

  // -- EVA: outside the hull, in a suit, on cold gas ---------------------------
  const eva = new SpaceWalk({ systems, events, audio, notify: (t) => notifications.push(t) });
  /**
   * The EVA camera, expressed the way `renderExterior` wants it: a ship-centred
   * world frame with the eye offset from the hull.
   *
   * Reusing the chase path rather than writing a third renderer is the whole
   * reason this was affordable. That path already draws the sky, the worlds, the
   * player's own hull, every structure and all of combat in exactly the frame an
   * EVA needs — a world-axis frame with the ship at the origin. The only
   * difference is where the eye is and what it is looking at, and both of those
   * are two matrices.
   */
  const evaCam = {
    vp: Mat4.create(), vpRot: Mat4.create(), eye: Vec3.create(),
    /**
     * ITS OWN PROJECTION, and this is the fix for the second half of the
     * "space walk is stuck" report.
     *
     * The suit was borrowing `player.camera.projection`, whose far plane is 120
     * units — and the Aethon is 97 long. Push a hundred metres off your own
     * ship to look at it and the hull crossed the far plane and vanished: an
     * empty starfield with your own vessel clipped out of it. Outside the hull
     * you are looking at things hundreds of units away, so the frustum has to
     * reach that far. See RENDER.EVA_FAR.
     */
    projection: Mat4.create(),
  };
  Mat4.perspective(evaCam.projection, RENDER.FOV_DEG * (Math.PI / 180),
    RENDER.WIDTH / RENDER.HEIGHT, RENDER.EVA_NEAR, RENDER.EVA_FAR);
  const _evaView = Mat4.create();
  const _evaRot = Mat4.create();
  const _evaTgt = Vec3.create();
  const updateEvaCam = () => {
    Vec3.copy(evaCam.eye, eva.pos);
    Vec3.add(_evaTgt, eva.pos, player.camera.forward);
    Mat4.lookAt(_evaView, evaCam.eye, _evaTgt, [0, 1, 0]);
    Mat4.multiply(evaCam.vp, evaCam.projection, _evaView);
    Mat4.copy(_evaRot, _evaView); _evaRot[12] = 0; _evaRot[13] = 0; _evaRot[14] = 0;
    Mat4.multiply(evaCam.vpRot, evaCam.projection, _evaRot);
  };

  // -- trading, work orders, factions, recovered logs (Phase 7) -----------------
  const trading = new TradingSystem(inventory, events);
  const tradingUI = new TradingUI(trading, inventory, (t) => notifications.push(t),
    () => { if (state.is(STATES.FLIGHT)) input.requestPointerLock?.(canvas); });
  // The hull broker. Only a shipyard opens it, and it is the one purchase in
  // the game that cannot be undone.
  const shipyardUI = new ShipyardUI({
    currentClass: () => pilot.shipClass,
    systems: () => systems,
    trading,
    notify: (t) => notifications.push(t),
    onBuy: (clsId, liveryId) => {
      commissionHull(clsId, liveryId);
      showPilotOnGate();
      events.emit('ship:refit', clsId);
      saveSys.save('refit');
    },
    onClose: () => { if (state.is(STATES.FLIGHT)) input.requestPointerLock?.(canvas); },
  });

  // The workshop bench. Scrap into hull plate, ore into stock, kit back into
  // scrap — the only economy aboard that runs with no station in range.
  const fabrication = new Fabrication({
    inventory, progression, events, notify: (t) => notifications.push(t),
  });
  const fabricatorUI = new FabricatorUI(fabrication, inventory, (t) => notifications.push(t),
    // the bench is worked on foot, so hand the mouse back to the head when the
    // card is put down — otherwise you step away from it unable to look around
    () => { if (state.is(STATES.PLAYING)) input.requestPointerLock?.(canvas); });

  // The fittings aboard that do work rather than print a line: the galley
  // dispenser, the water loop, the med bed and the assay bench, each drawing
  // on a store that runs down. See gameplay/ShipStations.js.
  const shipStations = new ShipStations({
    systems, inventory, trading, progression, events,
    notify: (t) => notifications.push(t),
  });

  const quests = new QuestSystem(events, {
    inventory, trading, notify: (t) => notifications.push(t),
  });
  // how the four powers regard you — fed by combat/trade/quests, prices at
  // Vrenn counters flex with your standing
  const factions = new FactionSystem(events, (t) => notifications.push(t));
  trading.priceMod = (station) => factions.priceModifier(station);

  /**
   * THE PEOPLE ON A STATION, and the conversations they will have. `Crew` is
   * the bodies (entities/Crew.js, built on the boarder part-mesh machinery so
   * they are lit by the compartment they stand in); `Dialogue` is the topic
   * table, every line of which is generated from live state rather than a
   * script. See gameplay/Dialogue.js.
   */
  const stationCrew = new Crew();
  const dialogue = new Dialogue({
    inventory, trading, systems, factions, quests, progression,
    stations: shipStations,
    system: () => system,
    notify: (t) => notifications.push(t),
    openFabricator: () => { dialogueUI.hide(); fabricatorUI.open(); },
  });
  const dialogueUI = new DialogueUI(dialogue,
    () => { if (state.is(STATES.PLAYING)) input.requestPointerLock?.(canvas); });
  // who you are: named + a service background chosen once on a fresh save
  const pilot = { name: 'SURVEYOR', callsign: '', background: 'lifer', shipClass: 'aethon', livery: 'company' };
  const charGen = new CharacterCreation();
  let freshStart = false; // set below when there's no save to restore
  /** lore ids the pilot has recovered */
  const loreUnlocked = new Set();
  const journalUI = new JournalUI(quests, loreUnlocked, factions, progression, audio);
  // terminal intrusion: secured consoles yield a data chip + credits on a crack
  const hacking = new HackingMinigame((t) => notifications.push(t));
  /** secured terminals already cracked (or emptied), by stable key */
  const hacked = new Set();
  const SECURED_RE = /MAINFRAME|SECURE|VAULT|ARCHIVE|DATA|SAFE|ENCRYPT/i;
  const tryHack = (rec) => {
    const label = typeof rec.label === 'function' ? rec.label() : rec.label;
    if (!SECURED_RE.test(label ?? '')) return false;
    const key = `${label}@${rec.min.map((v) => v.toFixed(1)).join(',')}`;
    if (hacked.has(key)) return false; // already cracked — flavour runs
    if (hacking.visible) return true;
    input.exitPointerLock?.();
    notifications.push('SECURED TERMINAL — ICE ACTIVE. BREAKING IN…');
    const diff = /VAULT|ARCHIVE|ENCRYPT/i.test(label) ? 3 : 2;
    hacking.start((ok) => {
      if (ok) {
        hacked.add(key);
        events.emit('hack:solved', { label });
        const chip = `datachip_${String(1 + ((key.length * 7) % 12)).padStart(2, '0')}`;
        const gotChip = inventory.add(chip, 1) > 0;
        trading.credits += 120;
        notifications.push(`ICE BROKEN — +120 CR${gotChip ? ` + ${ITEMS[chip]?.name?.toUpperCase() ?? 'DATA CHIP'}` : ''}`);
        // a crack sometimes spills a crew log too
        unlockLore((tr) => tr.type === 'zone' && player.zone && tr.id === player.zone.id);
      } else {
        notifications.push('INTRUSION FAILED — TERMINAL LOCKED. TRY AGAIN LATER.');
      }
      input.requestPointerLock?.(canvas);
    }, diff, progression.bonus('hackClock'));
    return true;
  };
  const unlockLore = (pred) => {
    for (const e of LORE) {
      if (loreUnlocked.has(e.id) || !pred(e.trigger)) continue;
      loreUnlocked.add(e.id);
      notifications.push(`LOG RECOVERED: ${e.title} — SEE JOURNAL`);
    }
  };
  events.on('player:interact', () => {
    const z = player.zone;
    if (z) unlockLore((t) => t.type === 'zone' && t.id === z.id);
  });
  events.on('ship:docked', (id) => unlockLore((t) => t.type === 'dock' && t.id === id));
  events.on('system:arrived', (id) => unlockLore((t) => t.type === 'visit' && t.id === id));

  // -- saving (Phase 5): the terminal ritual + a quiet autosave ---------------
  const saveSys = new SaveSystem(
    () => ({
      systemId: system.def.id,
      ship: { pos: [...shipState.pos], quat: [...shipState.quat], vel: [...shipState.vel] },
      playerPos: [...player.position],
      playerYaw: player.camera.yaw,
      systems: systems.toJSON(),
      inventory: inventory.toJSON(),
      searched: [...searched],
      trading: trading.toJSON(),
      quests: quests.toJSON(),
      factions: factions.toJSON(),
      progression: progression.toJSON(),
      lore: [...loreUnlocked],
      boarding: boarding.toJSON(),
      boarders: boarders.toJSON(),
      landing: landing.toJSON(),
      stores: shipStations.toJSON(),
      dialogue: dialogue.toJSON(),
      pilot,
    }),
    (body) => {
      const def = SYSTEMS.find((s) => s.id === body.systemId);
      if (def && def.id !== system.def.id) system = new StarSystem(def);
      primeSystemTex(system.def); // a loaded save may land in any system
      if (body.ship) {
        Vec3.set(shipState.pos, ...body.ship.pos);
        Vec3.set(shipState.vel, ...body.ship.vel);
        shipState.quat.set(body.ship.quat);
        shipState.snapHistory(); // loaded state is a cut, not a motion
        shipState.updateConjugate();
      }
      if (body.playerPos) Vec3.set(player.position, ...body.playerPos);
      if (body.playerYaw != null) player.camera.yaw = body.playerYaw;
      systems.fromJSON(body.systems);
      inventory.fromJSON(body.inventory);
      searched.clear();
      for (const k of body.searched ?? []) searched.add(k);
      trading.fromJSON(body.trading);
      quests.fromJSON(body.quests);
      factions.fromJSON(body.factions);
      progression.fromJSON(body.progression);
      loreUnlocked.clear();
      for (const id of body.lore ?? []) loreUnlocked.add(id);
      boarding.fromJSON(body.boarding);
      boarders.fromJSON(body.boarders);
      landing.fromJSON(body.landing);
      shipStations.fromJSON(body.stores);
      dialogue.fromJSON(body.dialogue);
      if (body.pilot) {
        pilot.name = body.pilot.name ?? pilot.name;
        pilot.callsign = body.pilot.callsign ?? pilot.callsign;
        pilot.background = body.pilot.background ?? pilot.background;
        pilot.shipClass = body.pilot.shipClass ?? pilot.shipClass;
        pilot.livery = body.pilot.livery ?? pilot.livery;
      }
    },
  );
  /**
   * How often the quiet autosave writes. `0` disables it entirely, which is a
   * real preference: this is a survival game, and a player who wants a bad
   * decision to actually cost them cannot have that while a background writer
   * is committing the consequences every sixty seconds. The terminal ritual
   * still works either way — turning autosave off makes saving a THING YOU DO
   * rather than removing it.
   */
  const autosaveSeconds = () => {
    const v = Settings.get('autosave');
    return v === 0 ? Number.POSITIVE_INFINITY : (v ?? 60);
  };

  events.on('save:ritual', () => {
    const ok = saveSys.save('terminal');
    audio.playSaveChunk?.();
    notifications.push(ok ? 'PROGRESS RECORDED' : 'RECORD FAILED — STORAGE UNAVAILABLE');
  });
  if (saveSys.hasSave()) {
    saveSys.load();
    notifications.push('SURVEY LOG RESTORED — WELCOME BACK');
  } else {
    // fresh save: the pilot commission screen seeds the opening (name, kit,
    // credits, standing). It's shown after boot; until BEGIN, the gate is
    // covered and boarding is blocked. See the boot tail below.
    freshStart = true;
  }

  // -- proximity scanner + noise/hiding (Phase 5, context/04 §5-6) -------------
  const scanner = new ProximityScanner(events, audio);
  const noise = new NoiseSystem(events, player);
  // -- personal combat (Phase 6's last unchecked line) -------------------------
  const handgun = new PersonalCombat({
    events, inventory, collision: shipMap.collision, shipMap,
    notify: (t) => notifications.push(t),
  });
  /**
   * WHAT IS STILL ABOARD. Owner ask: *"enemy aliens which player needs to
   * kill."*
   *
   * Constructed here, next to the weapon, because the two only make sense
   * together — a gun with nothing to shoot is a prop, and a hostile you cannot
   * shoot is the Hollow, which we already have and which is deliberately the
   * other thing entirely.
   */
  const boarders = new Boarders({
    events,
    notify: (t) => notifications.push(t),
    hurtPlayer: (dmg, from, at) => {
      systems.health = Math.max(0, systems.health - dmg);
      shakeT = Math.max(shakeT, 0.35);
      audio.playBoarderStrike?.();
      // WHICH WAY TO TURN. A hitscan bolt out of an unlit corridor is a number
      // going down and nothing else; the visor arc is the only thing that makes
      // being shot from behind survivable rather than arbitrary.
      if (at) {
        hud.hitFrom([at[0] - player.position[0], 0, at[2] - player.position[2]]);
      }
      if (systems.health <= 0 && !death.active) {
        die(`${from} KILLS YOU`, 'Nobody logs where the suit ended up. Nobody was looking.');
      }
    },
  });
  // A body a ray can actually hit — see PersonalCombat.hostiles, and note that
  // this is the exact opposite arrangement to hollowHere below.
  handgun.hostiles = boarders;
  boarders.onPing = (x, z) => scanner.blips.push({ x, z, age: 0 });
  events.on('boarder:down', () => {
    progression.award('marksmanship', 'kill.boarder');
    // Clearing the last one is worth saying out loud even if you then walk out
    // without stripping anything — it is the end of a fight, and the deck goes
    // quiet in a way the player should be told about rather than have to infer.
    if (!boarders.alive) notifications.push('THAT WAS THE LAST OF THEM. THE DECK IS QUIET.');
  });
  // A predicate, not a position: the entity has no collider and no world
  // transform anywhere in this codebase, so there is nothing for a ray to hit.
  // Firing in its compartment is enough to report that a round went through it,
  // and it still takes no damage. See PersonalCombat.hollowHere.
  handgun.hollowHere = () => !!tension?.inZone(player.zone?.id);
  // any powered console tops the scanner cell back up
  events.on('player:interact', (rec) => {
    const label = typeof rec.label === 'function' ? rec.label() : rec.label;
    if (/CONSOLE|MAINFRAME|TERMINAL|SYS|BUS|PANEL/i.test(label ?? '') && scanner.charge()) {
      notifications.push('SCANNER CELL CHARGED');
    }
  });
  // touch button for the scanner, third in the left-edge column (WARP, BAG, SCAN)
  const scanBtn = document.createElement('div');
  scanBtn.textContent = 'SCAN';
  scanBtn.style.cssText = 'position:fixed;left:1.5%;top:8px;z-index:26;display:none;' + plasticButton();
  const scanTap = (e) => {
    e.preventDefault(); e.stopPropagation();
    if (state.is(STATES.PLAYING) && !scanner.toggle()) notifications.push('SCANNER CELL DEAD — CHARGE AT ANY CONSOLE');
  };
  scanBtn.addEventListener('click', scanTap);
  scanBtn.addEventListener('touchend', scanTap, { passive: false });
  document.body.appendChild(scanBtn);

  // -- ship combat (Phase 6) ---------------------------------------------------
  let shakeT = 0; // camera shake envelope, decays each frame
  const combat = new SpaceCombat({
    notify: (text) => notifications.push(text),
    // Trigger time pays back here — see gameplay/Progression.js. Read through
    // a closure rather than passed as a number, so a level earned mid-fight is
    // live on the next shot.
    damageMult: () => progression.bonus('damage'),
    ammoSaved: () => progression.bonus('ammoSaved'),
    reward: (itemId, headline) => {
      if (itemId) {
        const added = inventory.add(itemId, 1);
        notifications.push(`${headline}${added ? ` — SCOOPED ${ITEMS[itemId].name.toUpperCase()}` : ''}`);
      } else {
        notifications.push(headline);
      }
    },
    shake: (s) => { shakeT = Math.min(1.2, shakeT + s); },
    playLaser: () => audio.playLaser?.(),
    playBoom: () => audio.playBoom?.(),
    playHit: () => audio.playHitTaken?.(),
    /**
     * A round STOPPED is a different event from a round LANDED, and until now
     * both played the same metallic knock — so the moment the deflector failed
     * was audibly identical to the moment before it, which is the one
     * transition in a fight that has to be unmistakable.
     */
    playShieldHit: () => audio.playShieldHit?.(),
    playShieldDown: () => audio.playShieldDown?.(),
    // `localDir` is the strike point in SHIP-LOCAL space, so the renderer can put
    // the ripple where the round actually hit instead of flashing the whole bubble
    shieldFx: (localDir, scale) => { space.shieldT = 1; space.shieldHit(localDir, scale); },
    killed: (type) => events.emit('combat:kill', type),
    /**
     * A hull left adrift instead of destroyed. Worth marksmanship XP in its own
     * right — putting a ship down without breaking it up is a harder shot than
     * putting it down, and the payoff is a boardable hull rather than a debris
     * field. See SpaceCombat._shouldCripple.
     */
    crippled: (e) => {
      progression.award('marksmanship', 'cripple');
      events.emit('combat:crippled', e.type);
      notifications.push('SUIT UP AND CROSS TO IT IF YOU WANT WHAT IS INSIDE.');
    },
    // shooting first at a faction that was tolerating you costs standing hard
    provoked: (type) => events.emit('combat:provoked', type),
    hullFx: () => {
      dmgEl.style.transition = 'opacity 0.05s';
      dmgEl.style.opacity = '0.55';
      setTimeout(() => { dmgEl.style.transition = 'opacity 0.5s'; dmgEl.style.opacity = '0'; }, 80);
    },
  });
  // red damage vignette — the cockpit tells you it hurt
  const dmgEl = document.createElement('div');
  dmgEl.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:24;opacity:0;' +
    'background:radial-gradient(ellipse at center, transparent 42%, #aa202088 100%);';
  document.body.appendChild(dmgEl);
  combat.setSystem(system.def);
  space.combat = combat;
  // reputation drives who shoots at you: patrols read their own standing.
  // (assigned here, not at the FactionSystem construction site — `combat` is
  // declared further down and would still be in its temporal dead zone there)
  combat.standingOf = (type) => factions.standing(type);

  // -- death & respawn (Phase 6) -----------------------------------------------
  const death = { active: false };
  const deathEl = document.createElement('div');
  deathEl.style.cssText = [
    'position:fixed', 'inset:0', 'z-index:50', 'display:none', 'background:#000000f2',
    'color:#aa2020', 'font:14px monospace', 'letter-spacing:0.12em', 'text-align:center',
    'padding-top:26vh', 'user-select:none', '-webkit-user-select:none',
  ].join(';');
  const deathText = document.createElement('div');
  deathText.style.cssText = 'font-size:18px;margin-bottom:14px;';
  const deathSub = document.createElement('div');
  deathSub.style.cssText = 'color:#7a5a40;font-size:11px;line-height:1.6;margin-bottom:26px;';
  const deathBtn = document.createElement('div');
  deathBtn.textContent = '[ RECOVER LAST RECORD ]';
  deathBtn.style.cssText = 'display:inline-block;border:1px solid #7a5a40;border-radius:8px;padding:12px 18px;color:#c09050;cursor:pointer;min-height:20px;';
  deathEl.append(deathText, deathSub, deathBtn);
  document.body.appendChild(deathEl);
  frameBackdrop(deathEl, { skySeed: 71 }); // the dark you woke up in, framed
  const die = (reason, sub) => {
    if (death.active) return;
    death.active = true;
    deathText.textContent = reason;
    deathSub.textContent = sub;
    deathEl.style.display = 'block';
    audio.setEngineThrust(0);
    input.exitPointerLock?.();
  };
  const respawn = (e) => {
    e?.preventDefault?.();
    if (!death.active) return;
    if (saveSys.hasSave()) {
      saveSys.load();
    } else {
      Vec3.set(player.position, SPAWN.pos[0], SPAWN.pos[1], SPAWN.pos[2]);
    }
    // whatever the record said, you wake breathing and the ship holds air
    systems.health = Math.max(systems.health, 40);
    // Sections are the authoritative hull state now, so the respawn floor has to
    // be applied to them — writing `hull` alone would be overwritten by the next
    // sectionMean(). Wounds are cleared too: you are flying a patched ship, not
    // one still venting from six holes.
    if (systems.sectionMean() < 45) systems.setSections(45);
    combat.breaches.length = 0;
    systems.shieldDown = false;
    systems.shieldHold = 0;
    systems.oxygen = Math.max(systems.oxygen, 60);
    Vec3.set(shipState.vel, 0, 0, 0);
    combat.setSystem(system.def);
    tension.setSystem(system.def.id); // the dark lets go too
    death.active = false;
    deathEl.style.display = 'none';
    state.transition(STATES.PLAYING);
    touch?.setMode('walk');
    notifications.push('YOU WAKE IN THE MED BAY OF YOUR MEMORY. THE RECORD HELD.');
  };
  deathBtn.addEventListener('click', respawn);
  deathBtn.addEventListener('touchend', respawn, { passive: false });

  // -- in-game menu (owner task): save / load / settings / quit ---------------
  const gameMenu = { visible: false };
  const menuRoot = document.createElement('div');
  menuRoot.style.cssText = plasticPanel(
    'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:34;display:none;width:min(300px,80vw);padding:16px 18px;text-align:center;' +
    'pointer-events:auto;user-select:none;-webkit-user-select:none;letter-spacing:0.08em;');
  const menuTitle = document.createElement('div');
  menuTitle.textContent = 'SHIP SYSTEMS — STANDBY';
  menuTitle.style.cssText = 'font-size:14px;letter-spacing:0.2em;color:#d0a060;margin-bottom:4px;';
  const menuSub = document.createElement('div');
  menuSub.style.cssText = 'font-size:10px;color:#8a6030;margin-bottom:12px;';
  menuRoot.append(menuTitle, hazardBar('70%'), menuSub);
  const menuBtn2 = (label, fn, danger = false) => {
    const b = document.createElement('div');
    b.textContent = label;
    b.style.cssText = plasticButton('display:block;margin:7px auto;width:82%;padding:9px 0;font-size:11px;' + (danger ? 'color:#bb4030;' : ''));
    const h = (e) => { e.preventDefault(); e.stopPropagation(); fn(); };
    b.addEventListener('click', h);
    b.addEventListener('touchend', h, { passive: false });
    menuRoot.appendChild(b);
    return b;
  };
  const closeGameMenu = () => {
    if (gameMenu.visible) showScrim(false);
    gameMenu.visible = false;
    menuRoot.style.display = 'none';
  };
  const openGameMenu = () => {
    if (!gameMenu.visible) showScrim(true);
    gameMenu.visible = true;
    const at = saveSys.lastSaveAt ? new Date(saveSys.lastSaveAt).toLocaleTimeString() : 'NONE THIS SESSION';
    menuSub.textContent = `SYSTEM: ${system.name} — LAST RECORD: ${at}`;
    menuRoot.style.display = 'block';
    input.exitPointerLock?.();
  };
  menuBtn2('RESUME', () => closeGameMenu());
  menuBtn2('RECORD PROGRESS', () => {
    const ok = saveSys.save('menu');
    audio.playSaveChunk?.();
    menuSub.textContent = ok ? 'PROGRESS RECORDED.' : 'RECORD FAILED — STORAGE UNAVAILABLE';
  });
  menuBtn2('RECOVER LAST RECORD', () => {
    if (saveSys.hasSave()) {
      saveSys.load();
      combat.setSystem(system.def);
      tension.setSystem(system.def.id);
      Vec3.set(shipState.vel, 0, 0, 0);
      closeGameMenu();
      state.transition(STATES.PLAYING);
      touch?.setMode('walk');
      notifications.push('SURVEY LOG RESTORED');
    } else {
      menuSub.textContent = 'NO RECORD TO RECOVER.';
    }
  });
  menuBtn2('SETTINGS', () => { closeGameMenu(); openSettings(); });
  menuBtn2('ABANDON SURVEY', () => {
    if (menuSub.textContent !== 'PRESS AGAIN TO WIPE THE RECORD AND RESTART.') {
      menuSub.textContent = 'PRESS AGAIN TO WIPE THE RECORD AND RESTART.';
      return;
    }
    saveSys.clear();
    location.reload();
  }, true);
  document.body.appendChild(menuRoot);
  framePanel(menuRoot, { seed: 47 });
  // the MENU chip, fourth in the left column
  const menuBtn = document.createElement('div');
  menuBtn.textContent = 'MENU';
  menuBtn.style.cssText = 'position:fixed;left:1.5%;top:8px;z-index:26;display:none;' + plasticButton();
  const menuTap = (e) => { e.preventDefault(); e.stopPropagation(); gameMenu.visible ? closeGameMenu() : openGameMenu(); };
  menuBtn.addEventListener('click', menuTap);
  menuBtn.addEventListener('touchend', menuTap, { passive: false });
  document.body.appendChild(menuBtn);

  /**
   * BAG and LOG merged into ONE chip, per the owner's note. They were two
   * permanent targets for two panels that are never open together, and the pair
   * ate two slots of a five-deep column.
   *
   * One tap opens the hold; a second swaps to the survey journal; a third closes.
   * The cycle is discoverable because each panel names itself in its own header,
   * and either can still be closed with its X or with Escape.
   */
  const holdBtn = document.createElement('div');
  holdBtn.textContent = 'BAG/LOG';
  holdBtn.title = 'HOLD · JOURNAL';
  holdBtn.style.cssText = 'position:fixed;left:1.5%;top:8px;z-index:26;display:none;' + plasticButton();
  const holdTap = (e) => {
    e.preventDefault(); e.stopPropagation();
    // Tapping it CLOSES if anything is open, otherwise opens the hold — and the
    // bookmark bar (below) is what gets you from there to the journal. The old
    // behaviour cycled hold -> journal -> closed, which the owner correctly called
    // wrong: nothing on screen told you the journal existed.
    if (inventoryUI.visible || journalUI.visible) { inventoryUI.hide(); journalUI.hide(); }
    else inventoryUI.show();
    bookmarks.sync();
  };
  holdBtn.addEventListener('click', holdTap);
  holdBtn.addEventListener('touchend', holdTap, { passive: false });
  document.body.appendChild(holdBtn);
  // the two panels' own chips are retired — this one stands in for both
  inventoryUI.button.remove();
  journalUI.button.remove();

  /**
   * The bookmark strip across the top. It is the answer to "BAG/LOG opens just the
   * bag": with two panels behind one chip, the second one has to be VISIBLE, not
   * one more tap into a cycle nobody can see. The bar appears whenever either panel
   * is open, marks which one you are in, and puts the other one direct.
   */
  const bookmarks = bookmarkBar([
    { label: 'HOLD', isOpen: () => inventoryUI.visible,
      open: () => { journalUI.hide(); inventoryUI.show(); } },
    { label: 'JOURNAL', isOpen: () => journalUI.visible,
      open: () => { inventoryUI.hide(); journalUI.show(); } },
  ]);
  // The panels can also be closed by their own ✕ or by Escape, neither of which
  // routes through holdTap — so the bar has to re-check itself on a clock rather
  // than trust that every closer remembered to tell it.
  setInterval(() => bookmarks.sync(), 180);

  // -- the Hollow (Phase 6): evasion-only, paced by the director ---------------
  const tension = new TensionDirector({
    shipMap, noise, scanner, lights, audio,
    notify: (text) => notifications.push(text),
    die,
    getPlayerZoneId: () => player.zone?.id ?? null,
  });
  tension.setSystem(system.def.id);

  // apply brightness live to the interior renderer
  interior.brightness = Settings.get('brightness');
  Settings.onChange((key) => {
    if (key === 'brightness' || key === null) interior.brightness = Settings.get('brightness');
  });

  /** @type {TouchControls|null} created lazily the moment touch is real */
  let touch = null;
  const enableTouch = () => {
    if (!touch) touch = new TouchControls(input);
    touch.setMode(state.is(STATES.FLIGHT) ? 'flight' : 'walk');
    touch.show();
    // Reserve the button gutters in the canvas HUD, and confine the clusters to
    // the canvas rect — the layer is built lazily, so it misses the boot layout.
    layoutOverlay();
  };

  // -- seat transition (context/02 §3: lerp INTO the seat, never a pull-back) --
  /** @type {null | {t:number, from:object, to:object, onDone:Function}} */
  let seatLerp = null;
  let standingPose = null;
  /** Where the pilot is standing on the current world's terrain patch. */
  let surfacePos = [0, 0, 0];

  const lerpAngle = (a, b, t) => {
    let d = (b - a) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    return a + d * t;
  };

  const startSeatLerp = (to, onDone) => {
    const cam = player.camera;
    seatLerp = {
      t: 0,
      from: { eye: [...cam.eye], yaw: cam.yaw, pitch: cam.pitch },
      to,
      onDone,
    };
  };

  // -- third-person pilot view (chase camera) --------------------------------
  // view.t: 0 = seated first-person, 1 = full exterior chase. Toggled with V
  // (or the touch VIEW button) while piloting; the exterior renders whenever
  // t > 0, lerping the chase camera out from the hull (the zoom-out reveal).
  const view = { third: false, t: 0 };
  const chase = { vp: Mat4.create(), vpRot: Mat4.create(), eye: Vec3.create() };
  const _off = Vec3.create();
  const _eyeRel = Vec3.create();
  const _up = Vec3.create();
  const _viewM = Mat4.create();
  const _rotM = Mat4.create();
  // free look + zoom for the hull cam (owner task): the mouse / look-stick
  // orbits the camera around the ship instead of steering, and the wheel (or
  // pinch buttons later) dollies in and out. Reset on every toggle.
  /**
   * STATION-KEEPING LOCK. The body or structure the hull is riding along with,
   * and where it was last frame — the delta between those two is what gets
   * added to the ship's position, which is the whole mechanic.
   */
  let holdTarget = null;
  const holdPrev = [0, 0, 0];
  /**
   * Carry the hull along with whatever it is holding station on.
   *
   * A FUNCTION, AND CALLED FROM THREE PLACES, because of a bug that only shows
   * up once you can board a wreck from a suit. This lived inline in the FLIGHT
   * branch, so the lock ran only while you were in the seat — step out of the
   * chair or out of the airlock and the ship quietly stopped keeping station.
   *
   * That is invisible while you are walking around inside your own hull, and
   * fatal the moment you are outside it: the EVA frame IS the ship's frame, and
   * a derelict rides its host world's orbit at tens of units a second. Park
   * beside a wreck, cycle the lock, and the wreck sails away from you at
   * orbital speed while you burn the whole pack chasing it — which is exactly
   * what the first crossing test measured: 147 m out, 3.2 km after ninety
   * seconds of perfect pursuit.
   *
   * Station-keeping is also precisely the fiction: you set the hull to hold on
   * the thing you are about to cut into, THEN you go out.
   */
  /**
   * The nearest thing worth holding station on.
   *
   * `system.approach` only knows about the chart — worlds, stations, the
   * derelicts that were there when the system loaded. A hull you crippled
   * yourself is none of those, and it is the one that most needs a hold: it
   * keeps the velocity it had when its drive died, so an unheld one is
   * kilometres away by the time you have your suit on.
   */
  const holdCandidate = (pos) => {
    const ap = system.approach(pos);
    let best = ap?.body ?? null;
    let bd = best ? Vec3.distance(pos, best.pos) : Infinity;
    for (const e of combat.enemies) {
      if (!e.crippled) continue;
      const d = Vec3.distance(pos, e.pos);
      if (d < bd && d < (e.reach ?? 1200)) { bd = d; best = e; }
    }
    return best;
  };

  const keepStation = () => {
    if (!holdTarget) return;
    // Out of range, gone, or a descent started: drop the lock rather than
    // dragging the hull across the system after it.
    const t = holdTarget;
    const dx = shipState.pos[0] - t.pos[0], dy = shipState.pos[1] - t.pos[1];
    const dz = shipState.pos[2] - t.pos[2];
    const reach = (t.reach ?? (t.radius ? t.radius * 2.6 + 400 : 900)) * 1.6;
    if (landing.active || Math.hypot(dx, dy, dz) > reach) {
      holdTarget = null;
      notifications.push('STATION-KEEPING LOST — OUT OF RANGE');
      return;
    }
    // Carry the ship by the target's own step. Position only: the velocity
    // stays the pilot's, so you can still fly around inside the hold and the
    // drift you had is the drift you keep.
    shipState.pos[0] += t.pos[0] - holdPrev[0];
    shipState.pos[1] += t.pos[1] - holdPrev[1];
    shipState.pos[2] += t.pos[2] - holdPrev[2];
    holdPrev[0] = t.pos[0]; holdPrev[1] = t.pos[1]; holdPrev[2] = t.pos[2];
    shipState.snapHistory?.();
  };
  const _landQ = Quat.create();

  const ZOOM_MIN = 0.45, ZOOM_MAX = 3.2;
  const orbit = { yaw: 0, pitch: 0, zoom: 1, min: ZOOM_MIN, max: ZOOM_MAX };
  /**
   * Dolly the hull cam. MULTIPLICATIVE, not additive: the offset it scales is
   * itself a distance, so a fixed step would crawl at the far end of the range
   * and jump at the near end. A constant ratio moves the same apparent amount
   * wherever you are in the travel.
   *
   * @param {number} dir  -1 = closer, +1 = further
   * @param {number} amt  fraction of a full step (1 = one keypress / one tap)
   */
  const zoomChase = (dir, amt = 1) => {
    orbit.zoom = clamp(orbit.zoom * Math.exp(dir * 0.22 * amt), ZOOM_MIN, ZOOM_MAX);
  };
  window.addEventListener('wheel', (e) => {
    if (state.is(STATES.FLIGHT) && view.third) {
      orbit.zoom = clamp(orbit.zoom * (1 + e.deltaY * 0.0012), ZOOM_MIN, ZOOM_MAX);
      e.preventDefault();
    }
  }, { passive: false });
  const updateChase = () => {
    const s = view.t * view.t * (3 - 2 * view.t);
    for (let i = 0; i < 3; i++) _off[i] = (FLIGHT.CHASE_NEAR[i] + (FLIGHT.CHASE_FAR[i] - FLIGHT.CHASE_NEAR[i]) * s) * orbit.zoom;
    // orbit the offset around the ship: yaw about local Y, pitch about local X
    const cy = Math.cos(orbit.yaw), sy = Math.sin(orbit.yaw);
    const cp = Math.cos(orbit.pitch), sp = Math.sin(orbit.pitch);
    let ox = _off[0] * cy + _off[2] * sy;
    let oz = -_off[0] * sy + _off[2] * cy;
    let oy = _off[1] * cp - oz * sp;
    oz = _off[1] * sp + oz * cp;
    _off[0] = ox; _off[1] = oy; _off[2] = oz;
    Quat.rotateVec3(_eyeRel, shipState.quat, _off); // world offset from ship
    Quat.rotateVec3(_up, shipState.quat, [0, 1, 0]);
    Mat4.lookAt(_viewM, _eyeRel, [0, 0, 0], _up); // ship at frame origin
    Mat4.multiply(chase.vp, player.camera.projection, _viewM);
    Mat4.copy(_rotM, _viewM); _rotM[12] = 0; _rotM[13] = 0; _rotM[14] = 0;
    Mat4.multiply(chase.vpRot, player.camera.projection, _rotM);
    Vec3.copy(chase.eye, _eyeRel);
  };
  /**
   * THE COCKPIT CAMERA, INSIDE AN ATMOSPHERE.
   *
   * Space is rendered with the ship at the frame origin and the universe moved
   * around it (see SpaceRenderer's shell projection), which is exactly wrong for
   * a terrain patch: the ground is a real mesh at real coordinates and the ship
   * has to be somewhere ON it. So atmospheric flight gets its own view matrix,
   * built from the hull's own attitude and its position over the heightfield.
   *
   * Still first person, still from the seat — pillar one — and the interior
   * draws on top of it exactly as it does over space.
   */
  const surfCam = {
    projection: player.camera.projection,
    view: Mat4.create(), viewProjection: Mat4.create(), eye: Vec3.create(),
  };
  const _sfF = Vec3.create(), _sfU = Vec3.create(), _sfT = Vec3.create();
  const updateSurfaceCam = () => {
    const L = landing.local;
    if (!L) return;
    Quat.rotateVec3(_sfF, shipState.quat, [0, 0, -1]);
    Quat.rotateVec3(_sfU, shipState.quat, [0, 1, 0]);
    // The eye rides a little above the hull datum: the datum is the gear line,
    // and a pilot who sees from it is looking out of the ship's feet.
    surfCam.eye[0] = L[0] + _sfU[0] * 2.4;
    surfCam.eye[1] = L[1] + _sfU[1] * 2.4;
    surfCam.eye[2] = L[2] + _sfU[2] * 2.4;
    _sfT[0] = surfCam.eye[0] + _sfF[0];
    _sfT[1] = surfCam.eye[1] + _sfF[1];
    _sfT[2] = surfCam.eye[2] + _sfF[2];
    Mat4.lookAt(surfCam.view, surfCam.eye, _sfT, _sfU);
    Mat4.multiply(surfCam.viewProjection, surfCam.projection, surfCam.view);
  };

  /**
   * THE LANDING CHASE CAMERA. Same idea as `surfCam` but outside the hull, and
   * the reason it exists is that you cannot judge a touchdown from the seat.
   *
   * From the cockpit the ground is behind the console bank in the last twenty
   * units of a descent — exactly the twenty units that decide whether the gear
   * takes it. From behind and above you can see the hull, its shadow side, the
   * slope you are settling onto and how much of it is between you and a rock.
   * It uses the same orbit yaw/pitch/zoom the space hull cam does, so the look
   * controls are the ones already in your hands.
   */
  const surfChase = {
    projection: player.camera.projection,
    view: Mat4.create(), viewProjection: Mat4.create(), eye: Vec3.create(),
  };
  const _scEye = Vec3.create(), _scUp = Vec3.create();
  const updateSurfaceChase = () => {
    const L = landing.local;
    if (!L) return;
    // Behind and above, in WORLD axes rather than hull axes: a chase that rolled
    // with the ship would hide the horizon, and the horizon is the instrument
    // you are actually landing on.
    // Far enough back to see the SHIP AND THE GROUND UNDER IT. 34 units on a
    // 62-unit hull put the camera inside the forward fuselage — the nose filled
    // the top half of the frame and the landing site was behind it. The whole
    // job of this view is the gap between the gear and the rock, so the hull has
    // to be small enough that you can see the gap.
    const dist = 132 * orbit.zoom, high = 44 * orbit.zoom;
    Quat.rotateVec3(_scUp, shipState.quat, [0, 0, -1]);
    const yaw = Math.atan2(_scUp[0], -_scUp[2]) + orbit.yaw;
    _scEye[0] = L[0] + Math.sin(yaw) * dist;
    _scEye[1] = L[1] + high;
    _scEye[2] = L[2] - Math.cos(yaw) * -dist;
    Vec3.copy(surfChase.eye, _scEye);
    Mat4.lookAt(surfChase.view, _scEye, L, [0, 1, 0]);
    Mat4.multiply(surfChase.viewProjection, surfChase.projection, surfChase.view);
  };

  const toggleView = () => {
    orbit.yaw = 0; orbit.pitch = 0; orbit.zoom = 1;
    view.third = !view.third;
    notifications.push(view.third ? 'EXTERNAL HULL CAM' : 'COCKPIT VIEW');
  };

  // facade handed to interaction callbacks
  const game = {
    notify: (text) => notifications.push(text),
    // Boarding a station, exposed so a probe can exercise the real entry path
    // rather than a reimplementation of it.
    goAboard: (body) => goAboard(body),
    leaveStation: () => leaveStation(),
    boardWreck: (body) => boardWreck(body),
    leaveWreck: () => leaveWreck(),
    audio,
    events,
    player,
    ship: shipState,
    inventory,
    // secured terminals crack first (hacking minigame); everything else loots
    tryLoot: (rec) => tryHack(rec) || tryLoot(rec),
    /**
     * The workshop bench. Releases the pointer, because the panel is a mouse
     * panel — the same contract every other modal here uses, and the reason
     * the pointerlock handler has to know it is open.
     */
    openFabricator: () => {
      input.exitPointerLock?.();
      fabricatorUI.open();
    },
    /**
     * The working fittings — galley, water loop, med bed, assay bench. Handed
     * to the props whole rather than as four separate closures, so a room file
     * calls `g.stations?.treat()` and stays a set list.
     */
    stations: shipStations,
    /**
     * Walk up to somebody and talk. The prompt names the POST; the panel is
     * where you find out who they are.
     */
    talkTo: (kind, id, role) => {
      if (!dockedAt) return;
      // One modal at a time. The armourer's bench topic opens the fabricator
      // over the conversation, so walking to somebody else afterwards must put
      // the card down or you end up talking through it.
      fabricatorUI.hide();
      input.exitPointerLock?.();
      dialogueUI.open(dockedAt, kind, crewName(dockedAt.id, id), role);
    },
    scanner,
    /**
     * Cycle the outer door and go outside. Called by the airlock prop.
     *
     * Refuses under way, and refuses parked: an EVA out of a hull doing 300 u/s
     * is a suit left behind at 300 u/s, and there is nothing to walk to while
     * the ship is sitting in a dock. Both refusals name the reason — the old
     * door said "certification required" forever, which is the failure mode
     * this whole feature exists to end.
     */
    startEva: () => {
      if (!state.is(STATES.PLAYING)) return;
      const sp = shipState.speed ?? 0;
      if (sp > 12) {
        audio.playDenyBuzz?.();
        notifications.push(`OUTER DOOR: WAY ON — ${Math.round(sp)} U/S. ALL STOP FIRST.`);
        return;
      }
      if (!eva.begin()) return;
      /**
       * TAKE THE HOLD BEFORE YOU OPEN THE DOOR.
       *
       * "All stop" is not station-keeping. A wreck rides its host world's
       * orbit, so a hull stopped dead in space beside one is already falling
       * behind it before the outer door finishes cycling — and the pilot has no
       * way to know that from inside. If there is something in range and the
       * lock is not already set, set it: this is a checklist item a real crew
       * would not be allowed to skip, so the ship does it for you and says so.
       */
      if (!holdTarget) {
        const t = holdCandidate(shipState.pos);
        if (t) {
          holdTarget = t;
          holdPrev[0] = t.pos[0];
          holdPrev[1] = t.pos[1];
          holdPrev[2] = t.pos[2];
          notifications.push(`STATION-KEEPING ON ${t.name} BEFORE THE DOOR CYCLES`);
        }
      }
      // Park the body at the hatch; the suit's own frame takes over from here.
      standingPose = { pos: [...player.position], yaw: player.camera.yaw, pitch: player.camera.pitch };
      state.transition(STATES.EVA);
      // Drop the stale interact target. `player.update` does not run out here,
      // so whatever the raycast last hit inside the airlock would otherwise
      // keep printing "[E] OPEN DOOR" across the starfield for the whole walk.
      player.controller.interactTarget = null;
      // RESUME STATE FIRST, THEN THE LOCK REQUEST. Granting pointer lock fires
      // `input:pointerlock`, whose handler transitions to `resumeState` — so
      // requesting the lock without updating it snapped straight back to
      // PLAYING one frame after stepping outside, and the symptom was an EVA
      // that transitioned, drew its HUD and then silently was not one.
      resumeState = STATES.EVA;
      touch?.setMode('flight'); // the six-axis cluster is the right one out here
      input.requestPointerLock?.(canvas);
      audio.playAirlock?.();
    },
    enterFlight: () => {
      if (!state.is(STATES.PLAYING) || seatLerp) return;
      holdTarget = null;
      standingPose = {
        pos: [...player.position],
        yaw: player.camera.yaw,
        pitch: player.camera.pitch,
      };
      audio.playSeatLatch();
      startSeatLerp(
        { eye: FLIGHT.SEAT_EYE, yaw: 0, pitch: 0 },
        () => {
          state.transition(STATES.FLIGHT);
          touch?.setMode('flight');
          warpPanel.setFlightMode(true);
          relayoutChips(); // WARP joins the chip column; reflow the stack
          scanner.raised = false; // both hands on the yoke
          notifications.push('FLIGHT CONTROL ENGAGED - DRIVES LIVE');
        },
      );
    },
    exitFlight: () => {
      if (!state.is(STATES.FLIGHT) || seatLerp) return;
      if (warp.phase) { notifications.push('WARP SEQUENCE RUNNING — STAY SEATED'); return; }
      warpPanel.setFlightMode(false);
      relayoutChips(); // ...and leaves it again on standing up
      audio.playSeatLatch();
      audio.setEngineThrust(0);
      celestial.hide();
      const pose = standingPose ?? { pos: FLIGHT.EXIT_POS, yaw: Math.PI, pitch: 0 };
      startSeatLerp(
        { eye: [pose.pos[0], pose.pos[1] + player.controller.eyeHeight, pose.pos[2]], yaw: pose.yaw, pitch: pose.pitch },
        () => {
          Vec3.set(player.position, pose.pos[0], pose.pos[1], pose.pos[2]);
          player.camera.yaw = pose.yaw;
          player.camera.pitch = pose.pitch;
          state.transition(STATES.PLAYING);
          touch?.setMode('walk');
          if (shipState.speed > 0.5) {
            notifications.push('SHIP COASTING - DRIVES UNATTENDED');
          }
        },
      );
    },
  };

  // -- state wiring -----------------------------------------------------------
  state.register(STATES.GATE, {
    enter: () => gateEl.classList.remove('hidden'),
    exit: () => gateEl.classList.add('hidden'),
  });
  state.register(STATES.PAUSED, {
    enter: () => { pauseEl.classList.remove('hidden'); audio.setEngineThrust(0); },
    exit: () => pauseEl.classList.add('hidden'),
  });

  // -- settings menu ----------------------------------------------------------
  const settingsMenu = new SettingsMenu(() => {
    // on close: if we were mid-game, drop to the pause screen to re-enter
    if (state.is(STATES.PLAYING) || state.is(STATES.FLIGHT)) {
      resumeState = state.current;
      state.transition(STATES.PAUSED);
    }
  });
  const openSettings = () => {
    input.exitPointerLock();
    settingsMenu.show();
  };

  let resumeState = STATES.PLAYING; // where boarding/resuming returns us
  const startTouchSession = () => {
    enableTouch();
    state.transition(resumeState);
  };
  const board = () => {
    // Idempotent: several handlers may fire for one tap; only the first acts.
    if (state.is(STATES.PLAYING) || state.is(STATES.FLIGHT)) return;
    if (charGen.visible) return; // pick a commission before the ship is yours
    // Audio must never block boarding — iOS can throw on AudioContext create.
    try { audio.resume(); } catch { /* keep going; sound is optional */ }
    inventoryUI.setInGame(true); // BAG button lives while aboard
    journalUI.setInGame(true); // LOG clipboard rides along
    // 'flex', not 'block': plasticButton centres its label with flexbox, and a
    // later display:block silently drops that centring in a 44px-tall key.
    scanBtn.style.display = 'flex';
    menuBtn.style.display = 'flex';
    holdBtn.style.display = 'flex'; // the merged hold/journal chip
    relayoutChips();
    if (touchActive) {
      startTouchSession();
      return;
    }
    // Desktop path: pointer lock. If the browser refuses (or the API is
    // missing — some tablets in desktop mode), fall back to a lock-free start
    // rather than leaving the player stuck at the menu.
    const req = input.requestPointerLock(canvas);
    req?.catch?.(() => {});
    setTimeout(() => {
      if (!input.pointerLocked && (state.is(STATES.GATE) || state.is(STATES.PAUSED))) {
        startTouchSession();
      }
    }, 700);
  };

  // Board on the FIRST user gesture, however it arrives. pointerdown is the
  // most reliable cross-device signal: it fires immediately on touch (no
  // click synthesis, no 300ms delay) and its pointerType tells us touch vs
  // mouse directly. click + touchend stay as fallbacks for old engines; all
  // three funnel through the idempotent board().
  const boardFrom = (e) => {
    if (e && (e.pointerType === 'touch' || e.pointerType === 'pen')) touchActive = true;
    if (e && e.type === 'touchend') { touchActive = true; e.preventDefault?.(); }
    board();
  };
  for (const el of [gateEl, pauseEl]) {
    el.addEventListener('pointerdown', boardFrom);
    el.addEventListener('click', boardFrom);
    el.addEventListener('touchend', boardFrom, { passive: false });
  }
  // Ultimate fallback: a gesture anywhere on the page while a menu is up
  // boards too, in case the overlay element itself somehow misses the event.
  const anywhereBoard = (e) => {
    if (state.is(STATES.GATE) || state.is(STATES.PAUSED)) boardFrom(e);
  };
  window.addEventListener('pointerdown', anywhereBoard);
  window.addEventListener('touchend', anywhereBoard, { passive: false });

  // settings openers — stop the tap from bubbling to the board handlers
  const stop = (e) => e.stopPropagation();
  const pauseSettingsBtn = document.getElementById('pause-settings');
  // The last button in the game with hand-rolled chrome. Its inline styles are the
  // pre-module fallback; now that the module is running, give it the same machined
  // plate every other key has.
  pauseSettingsBtn.style.cssText = plasticButton(
    "margin-top:16px;font-family:'Courier New',monospace;font-size:11px;"
    + 'letter-spacing:0.22em;padding:10px 22px;');
  for (const ev of ['click', 'pointerdown', 'touchend']) {
    pauseSettingsBtn.addEventListener(ev, stop);
  }
  pauseSettingsBtn.addEventListener('click', () => { pauseEl.classList.add('hidden'); settingsMenu.show(); });
  // keyboard: Escape or P opens settings on desktop
  document.addEventListener('keydown', (e) => {
    if ((e.code === 'Escape' || e.code === 'KeyP') &&
        (state.is(STATES.PLAYING) || state.is(STATES.FLIGHT)) && !settingsMenu.visible) {
      openSettings();
    }
  });

  events.on('input:pointerlock', (locked) => {
    if (locked) {
      state.transition(resumeState);
    } else if ((state.is(STATES.PLAYING) || state.is(STATES.FLIGHT) || state.is(STATES.EVA)
                || state.is(STATES.SURFACE))
               && !hacking.visible && !tradingUI.visible && !boardingUI?.visible
               && !landingUI?.visible && !shipyardUI?.visible && !fabricatorUI.visible
               && !inventoryUI.visible && !dialogueUI.visible) {
      // a Phase 7 modal releases the pointer on purpose — don't treat that as
      // a pause; the modal's own guard freezes the sim and re-locks on close
      resumeState = state.current;
      state.transition(STATES.PAUSED);
    }
  });
  events.on('input:debug', () => debug.toggle());
  events.on('state:change', ({ to }) => {
    if (to === STATES.PLAYING || to === STATES.FLIGHT) resumeState = to;
    relayoutChips();
  });

  /**
   * Screen chips, laid out to the owner's markup (session 17a).
   *
   * Was a five-deep column down the LEFT gutter — WARP · BAG · SCAN · MENU · LOG —
   * which reserved a permanent strip of the HUD, put five taps in the one place a
   * left thumb also holds the throttle, and stacked two panels (BAG and LOG) that
   * are never open at once.
   *
   * Now:
   *   - BAG and LOG are ONE chip that cycles hold → journal → closed, so two
   *     panels cost one target;
   *   - MENU sits in the TOP-RIGHT corner the settings gear used to own (the gear
   *     is gone entirely; settings live inside the game menu);
   *   - WARP · SCAN · BAG/LOG run as a horizontal row along the BOTTOM, left of
   *     centre, out of both thumb gutters.
   * Because nothing occupies the left gutter any more, the HUD's reserved inset
   * comes only from the touch clusters.
   */
  function relayoutChips() {
    const pad = Math.round(canvasBox.width * 0.015);
    // top-right: MENU, in the corner the gear vacated
    if (menuBtn.style.display !== 'none') {
      menuBtn.style.left = 'auto';
      menuBtn.style.right = `${Math.round(window.innerWidth - (canvasBox.left + canvasBox.width) + pad)}px`;
      menuBtn.style.top = `${Math.round(canvasBox.top + 8)}px`;
    }
    // bottom row, left of centre. Laid out left-to-right from a fixed origin so a
    // hidden chip (WARP disappears when you leave the seat) closes the gap.
    //
    // WARP and SCAN are SUPPRESSED while the touch layer is up: the touch tap row
    // carries its own WARP · SCAN · LOCK · WPN, and showing both put two identical
    // buttons on screen 200px apart. BAG/LOG and MENU have no touch twin, so they
    // stay in both modes.
    // WARP, SCAN and BAG/LOG are GONE from the DOM. All three now live in the
    // HUD's own command bar (HUD._commandBar), drawn in the HUD's chrome on the
    // 480x270 grid, in both input modes, each printing its keybind. Keeping DOM
    // twins would have put the same five actions on screen in two places in two
    // visual languages, which is exactly the crowding this change removes.
    for (const el of [warpPanel.button, scanBtn, holdBtn]) {
      if (el) el.style.display = 'none';
    }
    // MENU is the only chip left on the canvas. Everything else reserves no HUD
    // width; the touch clusters still do, and applyHudInset takes the max.
    chipColumnW = 0;
    applyHudInset();
  }

  /**
   * Screen furniture lives in CSS pixels; the HUD lives in UI pixels. This is
   * the one place that converts between them.
   *
   * `canvasBox` is the canvas's real on-screen rectangle. It is NOT the viewport:
   * fitCanvas letterboxes at some scales and fills at others, so a chip pinned to
   * the viewport edge sits in the black border at one size and on top of the
   * SENSORS panel at the next. Everything overlaying the game therefore anchors
   * to this box, and the HUD's gutter is derived from the column's MEASURED width
   * converted into UI pixels — the old fixed 44 was tuned for one phone and was
   * both too wide on desktop and, when the canvas filled the screen, applied only
   * in touch mode so the chips covered the panels outright.
   */
  let canvasBox = { left: 0, top: 0, width: RENDER.UI_WIDTH, height: RENDER.UI_HEIGHT };
  let chipColumnW = 0;

  function applyHudInset() {
    // CSS px per UI px — the canvas draws UI_WIDTH logical columns across its
    // whole on-screen width, whatever the scene buffer underneath it is.
    const perUi = canvasBox.width / RENDER.UI_WIDTH;
    const chips = perUi > 0 ? Math.ceil((chipColumnW + 6) / perUi) : 0;
    // The touch clusters own the opposite gutter and are sized in % of the box,
    // so they need a floor the chip column alone would not reach.
    const pads = touch?.visible ? HUD_TOUCH_INSET : 0;
    hud.inset = Math.min(72, Math.max(chips, pads));
  }

  /**
   * Contacts for the tactical radar, in SHIP-LOCAL space — the display is nose-up,
   * so it needs bearings relative to the hull, not world positions.
   *
   * Hostiles first and celestial bodies second, both capped: the dial is 42px
   * across and there is no reading a hundred blips on it, so bodies are limited to
   * the handful nearest the ship. Bodies are included at all because the owner's
   * ask was "know where he is OR where the enemy is" — with only hostiles plotted,
   * an empty system shows an empty dial and tells you nothing about your position.
   */
  /**
   * FIELD REPAIR — weld a hull plate onto the worst section, from the seat.
   *
   * Repair already existed, but only as "use a hull plate from the hold", which
   * meant opening the manifest mid-fight; and the item path raised the ship-wide
   * `hull` figure directly, which the next hit silently undid because `hull` is
   * the mean of the six sections (fixed in ShipSystems.applyItem). This is the
   * same operation bound to a key and a button, with a cooldown so it reads as
   * work rather than a heal button.
   */
  let repairCd = 0;
  /**
   * The nearest un-emptied piece of wreckage within arm's reach of the boots.
   *
   * Six metres, which from standing height is close enough that the thing fills
   * a good part of the frame — you have to actually walk to it, and there is no
   * ambiguity about which one you meant.
   */
  /**
   * What the suit's hand is on or near, as a prompt. Same affordance as a
   * locker aboard: the label appears when the thing is in reach, and `[E]`
   * takes it — which is the point of putting rails on a hull at all.
   */
  function evaReach() {
    if (!eva.active || eva.exiting) return null;
    if (eva.held) return `LET GO — ${eva.held.label}`;
    const h = eva.nearHold();
    if (h) return h.label;
    // A hull you have crossed to beats your own airlock, because if both are in
    // reach you are at the wreck and the lock is behind you.
    const t = eva.nearTarget();
    if (t) return `CUT INTO ${t.label}`;
    if (eva.canEnter) return 'CYCLE AIRLOCK';
    return null;
  }

  /**
   * WHAT IS OUT THERE TO CROSS TO, in the suit's own frame.
   *
   * Rebuilt every frame rather than cached at `eva.begin`: the Aethon is
   * coasting the whole time you are outside (see the Newtonian note in the
   * walking branch), so a wreck's position relative to the suit is a live
   * quantity, and a boarding prompt computed once at the airlock would be wrong
   * by the time you got there.
   *
   * Only derelicts. A station you dock with — that is what the clamps are for
   * — and a live hull you would be boarding under fire, which is a different
   * feature and not one the owner asked for.
   */
  const refreshEvaTargets = () => {
    eva.targets.length = 0;
    const add = (sh) => {
      eva.targets.push({
        pos: [sh.pos[0] - shipState.pos[0], sh.pos[1] - shipState.pos[1],
          sh.pos[2] - shipState.pos[2]],
        r: sh.bodyR ?? 30,
        label: sh.name,
        ref: sh,
      });
    };
    for (const sh of system.ships) if (sh.boardable) add(sh);
    /**
     * ...and anything you shot the fight out of five minutes ago.
     *
     * A crippled hostile is a boardable hull that was not on the chart when the
     * system loaded — you made it — so it comes from the combat list rather
     * than the system's own. See SpaceCombat._cripple.
     */
    for (const e of combat.enemies) if (e.crippled && e.boardable) add(e);
  };

  function nearestCache(pos) {
    const T = landing.terrain;
    if (!T || !pos) return null;
    let best = null, bd = 6 * 6;
    for (const p of T.props) {
      if (!p.cache || searched.has(p.key)) continue;
      const dx = pos[0] - p.x, dz = pos[2] - p.z;
      const d2 = dx * dx + dz * dz;
      if (d2 < bd) { bd = d2; best = p; }
    }
    return best;
  }

  /**
   * Search it. Surface tier, so it is fuller than the Aethon's own fittings and
   * thinner than a derelict's — this is what the weather left of somebody's bad
   * day, not an intact hold.
   */
  function lootCache(p) {
    searched.add(p.key);
    const roll = rollContainer(p.label, p.key.length, {
      tier: 'surface',
      find: progression.bonus('findChance'),
      rare: progression.bonus('rareBias'),
    });
    events.emit('loot:searched', { label: p.label, tier: 'surface', rare: roll.rare });
    progression.award('salvage', 'surface.cache');
    if (!roll.items.length) {
      notifications.push(`${p.label} — PICKED OVER. NOTHING LEFT.`);
      return;
    }
    const got = [];
    for (const { id, qty } of roll.items) {
      const added = inventory.add(id, qty);
      if (added > 0) got.push(`${ITEMS[id].name}${added > 1 ? ` \u00d7${added}` : ''}`);
      if (added < qty) { notifications.push('HOLD FULL — LEFT THE REST'); break; }
    }
    notifications.push(got.length
      ? `${roll.rare ? 'IN THE WRECKAGE: ' : 'RECOVERED: '}${got.join(', ').toUpperCase()}`
      : 'HOLD FULL');
    audio.playSaveChunk?.();
  }

  function fieldRepair() {
    if (repairCd > 0) {
      notifications.push(`WELD CYCLING — ${repairCd.toFixed(1)}s`);
      return;
    }
    if (systems.hull >= 99.9) { notifications.push('HULL SOUND — NOTHING TO PATCH'); return; }
    if (inventory.count(FLIGHT.REPAIR_ITEM) < 1) {
      notifications.push('NO HULL PLATE ABOARD');
      return;
    }
    // A better engineer gets more out of the same plate.
    const rep = systems.repairSection(FLIGHT.REPAIR_SECTION_PCT * progression.bonus('repairAmount'));
    if (!rep) { notifications.push('HULL SOUND — NOTHING TO PATCH'); return; }
    inventory.remove(FLIGHT.REPAIR_ITEM, 1);
    events.emit('ship:repaired', { section: rep.name, to: rep.to });
    repairCd = FLIGHT.REPAIR_COOLDOWN;
    audio.playSaveChunk?.();
    notifications.push(`PLATE WELDED — ${rep.label} ${rep.from}→${rep.to}%`);
    // a patched section stops venting: clear the breach that section carried
    combat.clearBreaches?.(rep.name);
  }

  const _rl = [0, 0, 0];
  function radarContacts() {
    const out = [];
    const locked = combat.lock?.locked ? combat.lock.target : null;
    for (const e of combat.enemies) {
      if (e.hp <= 0) continue;
      shipState.toLocal(_rl, e.pos);
      out.push({ x: _rl[0], y: _rl[1], z: _rl[2], hostile: true, locked: e === locked, body: false });
      if (out.length >= 14) break;
    }
    const bodies = system.bodies ?? [];
    const near = [];
    for (const b of bodies) {
      if (!b?.pos) continue;
      const dx = b.pos[0] - shipState.pos[0], dy = b.pos[1] - shipState.pos[1], dz = b.pos[2] - shipState.pos[2];
      near.push({ d: dx * dx + dy * dy + dz * dz, b });
    }
    near.sort((a, z) => a.d - z.d);
    for (const { b } of near.slice(0, 4)) {
      shipState.toLocal(_rl, b.pos);
      out.push({ x: _rl[0], y: _rl[1], z: _rl[2], hostile: false, locked: false, body: true });
    }
    return out;
  }

  /**
   * The nearest celestial body and its slant range, for the HUD's NAV strip.
   * Shares nothing with radarContacts on purpose — that one wants everything
   * rotated into ship-local space for a bearing, this one only wants a name and
   * a scalar, and building both from one pass made both harder to read.
   */
  function nearestBody() {
    let best = null, bd = Infinity;
    for (const b of system.bodies ?? []) {
      if (!b?.pos) continue;
      const dx = b.pos[0] - shipState.pos[0], dy = b.pos[1] - shipState.pos[1],
        dz = b.pos[2] - shipState.pos[2];
      const d = dx * dx + dy * dy + dz * dz;
      if (d < bd) { bd = d; best = b; }
    }
    return best ? { name: best.name ?? 'BODY', dist: Math.sqrt(bd) } : null;
  }

  /**
   * THE COMMAND BAR's other half: what each key does, and whether it is lit.
   *
   * The bar itself is pure drawing — HUD.js knows nothing about the systems
   * behind these actions. This is the dispatch table, and it deliberately routes
   * through `input.virtualPress` wherever an action already has a keybind, so a
   * tap on the bar and a press of the key take EXACTLY the same path through the
   * update loop. Two code paths for one action is how they drift apart.
   */
  function runCommand(id) {
    hud.flashButton(id);
    switch (id) {
      case 'warp': input.virtualPress('warp'); break;
      case 'lock': input.virtualPress('lockTarget'); break;
      case 'wpn': input.virtualPress('cycleWeapon'); break;
      case 'repair': input.virtualPress('repair'); break;
      case 'lamp': input.virtualPress('flashlight'); break;
      case 'gun': input.virtualPress('drawWeapon'); break;
      case 'scan':
        if (state.is(STATES.PLAYING) && !scanner.toggle()) {
          notifications.push('SCANNER CELL DEAD — CHARGE AT ANY CONSOLE');
        }
        break;
      // The two panel openers are not keybinds-with-a-twin: they toggle DOM
      // overlays, and the bookmark strip has to be resynced either way.
      case 'hold':
        if (inventoryUI.visible) inventoryUI.hide();
        else { journalUI.hide(); inventoryUI.show(); }
        bookmarks.sync();
        break;
      case 'log':
        if (journalUI.visible) journalUI.hide();
        else { inventoryUI.hide(); journalUI.show(); }
        bookmarks.sync();
        break;
      // The zoom pad is HELD, not tapped: `heldBarButton` keeps the dolly running
      // in the flight update for as long as the pointer stays down. A tap still
      // does something — one frame of travel is a nudge — but the gesture the
      // control is built around is press-and-hold, the same as the keys.
      case 'zoomin': case 'zoomout': zoomChase(id === 'zoomin' ? -1 : 1, 0.5); break;
      default: break;
    }
  }

  /**
   * Which command-bar key the pointer is currently holding down, or null.
   *
   * Only the zoom pad reads it. Everything else on the bar is a one-shot action
   * and fires on pointerdown; wiring those to a held state would make a slow tap
   * open and close the hold six times.
   */
  let heldBarButton = null;
  const releaseBarButton = () => { heldBarButton = null; };
  window.addEventListener('pointerup', releaseBarButton);
  window.addEventListener('pointercancel', releaseBarButton);

  // Which keys show as ACTIVE. The bar cannot work this out — the state is
  // spread across five systems — so it asks through this hook.
  hud._litButton = (id) => (
    id === 'scan' ? scanner.raised
      : id === 'hold' ? inventoryUI.visible
        : id === 'log' ? journalUI.visible
          : id === 'warp' ? warpPanel.visible
            : id === 'gun' ? handgun.drawn
              : id === 'lock' ? !!combat.lock?.locked
                : false);

  /**
   * Pointer -> command bar.
   *
   * `canvasBox` is the canvas's real on-screen rectangle and the HUD is authored
   * on a fixed 480x270 grid, so the conversion is one divide each way. Runs on
   * POINTERDOWN and swallows the event when it lands on a key, so tapping WARP
   * cannot also pull the trigger — `fire` is bound to Mouse0.
   *
   * While the pointer is LOCKED there is no cursor to hit-test with, which is
   * why every key on the bar prints its keybind: on a desktop the bar is the
   * legend and the keyboard is the input. Unlock (Esc, or any menu) and the keys
   * are clickable again.
   *
   * BOUND ON WINDOW, NOT ON THE CANVAS. The touch layer lays two full-width
   * look/steer panes over the top 215 rows of the frame, and a listener on the
   * canvas never sees a press that lands on one — the canvas is not in that
   * event's path at all. The command bar happens to sit BELOW the panes and so
   * worked by luck; anything the HUD draws higher up (the hull-cam zoom pad) did
   * not, and pressing it did nothing at all on a phone. Capturing on window
   * gives HUD buttons first refusal wherever they are drawn.
   *
   * The target test is what keeps that from stealing presses: only the canvas
   * itself and the touch overlay are eligible. Every DOM panel — menus, the
   * hold, the warp chart, the settings sheet — keeps priority over a HUD button
   * rect it happens to cover.
   */
  function barPointer(e) {
    if (!state.is(STATES.PLAYING) && !state.is(STATES.FLIGHT)) return false;
    if (input.pointerLocked) return false;
    if (!canvasBox?.width) return false;
    const t = e.target;
    if (t !== canvas && !t?.closest?.('#touch-ui')) return false;
    const ux = ((e.clientX - canvasBox.left) / canvasBox.width) * RENDER.UI_WIDTH;
    const uy = ((e.clientY - canvasBox.top) / canvasBox.height) * RENDER.UI_HEIGHT;
    const id = hud.hitTest(ux, uy);
    if (!id) return false;
    e.preventDefault(); e.stopPropagation();
    if (id === 'zoomin' || id === 'zoomout') heldBarButton = id;
    runCommand(id);
    return true;
  }
  window.addEventListener('pointerdown', barPointer, { capture: true });

  /**
   * THE THROTTLE QUADRANT, as a control rather than a readout.
   *
   * Replaces the deleted THR+/THR- touch keys. Dragging anywhere in the gauge
   * LATCHES a throttle setting — it does not act like a held key — which is what
   * a throttle quadrant actually is and is strictly better than two buttons you
   * have to keep a thumb on. The latched value is re-published into the virtual
   * move axis every tick (see the flight branch of update), so the drive holds
   * it after you let go.
   *
   * Centre of the gauge is zero, top is full ahead, bottom is full reverse, and
   * a short dead band around the middle makes "off" easy to find by feel.
   */
  let touchThrottle = 0;
  let throttleDrag = false;
  function throttleAt(e) {
    const r = hud.throttleRect;
    if (!r || !canvasBox?.width) return null;
    const ux = ((e.clientX - canvasBox.left) / canvasBox.width) * RENDER.UI_WIDTH;
    const uy = ((e.clientY - canvasBox.top) / canvasBox.height) * RENDER.UI_HEIGHT;
    // generous horizontally: a 16px-wide strip is under the 44px touch floor, so
    // the GRAB region is padded well past what is drawn
    if (ux < r.x - 14 || ux > r.x + r.w + 14 || uy < r.y - 8 || uy > r.y + r.h + 8) return null;
    const mid = r.gy + r.gh / 2;
    let v = (mid - uy) / (r.gh / 2);
    if (Math.abs(v) < 0.12) v = 0; // dead band, so idle is findable by feel
    return Math.max(-1, Math.min(1, v));
  }
  canvas.addEventListener('pointerdown', (e) => {
    if (!state.is(STATES.FLIGHT) || input.pointerLocked) return;
    const v = throttleAt(e);
    if (v === null) return;
    throttleDrag = true; touchThrottle = v;
    e.preventDefault(); e.stopPropagation();
  }, { capture: true });
  canvas.addEventListener('pointermove', (e) => {
    if (!throttleDrag) return;
    const v = throttleAt(e);
    if (v !== null) touchThrottle = v;
    e.preventDefault();
  }, { passive: false });
  for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) {
    canvas.addEventListener(ev, () => { throttleDrag = false; });
  }

  function layoutOverlay() {
    const r = canvas.getBoundingClientRect();
    canvasBox = { left: r.left, top: r.top, width: r.width, height: r.height };
    touch?.setBounds(canvasBox);
    relayoutChips();
  }
  // fitCanvas resizes the element; the box has to be re-read after it settles.
  window.addEventListener('resize', () => requestAnimationFrame(layoutOverlay));
  window.addEventListener('orientationchange', () => setTimeout(layoutOverlay, 120));
  window.visualViewport?.addEventListener('resize', () => requestAnimationFrame(layoutOverlay));
  layoutOverlay();

  // -- loop ----------------------------------------------------------------------
  const engine = new Engine({
    update(dt) {
      // settings overlay pauses gameplay (opaque, covers the view)
      if (settingsMenu.visible) { input.endFrame(); return; }
      if (gameMenu.visible) { input.endFrame(); return; }
      // Phase 7 modals: the intrusion clock and the trade counter freeze the
      // sim while they're up (they need the mouse, so pointer lock is released)
      if (hacking.visible || tradingUI.visible || fabricatorUI.visible
        || dialogueUI.visible) { input.endFrame(); return; }
      // The boarding panel is the same kind of modal: it needs the mouse, and
      // the wreck is not going anywhere while you decide.
      if (boardingUI?.visible) { input.endFrame(); return; }
      if (landingUI?.visible) { input.endFrame(); return; }
      if (shipyardUI?.visible) { input.endFrame(); return; }
      // death holds the world still until the record is recovered
      if (death.active) { input.endFrame(); return; }
      // EVA counts as running. It was omitted on the first pass and the symptom
      // was subtle rather than obvious: the state transitioned, the suit HUD
      // drew, oxygen even drained — because the survival tick lives elsewhere —
      // but the cold-gas jet did nothing at all, because the branch that
      // integrates the suit's velocity sits behind this flag.
      const running = state.is(STATES.PLAYING) || state.is(STATES.FLIGHT)
        || state.is(STATES.EVA) || state.is(STATES.SURFACE);
      touch?.update();
      // The LATCHED throttle is republished every tick, after touch?.update()
      // (which would otherwise zero the move axis the moment the move stick is
      // released) and only in the seat. On foot the axis belongs to walking.
      if (state.is(STATES.FLIGHT) && touchThrottle !== 0) {
        input.setVirtualAxis(input.moveAxis?.[0] ?? 0, touchThrottle);
      }
      // Snapshot the eye and the hull attitude before anything moves them, so
      // render() can draw part-way between this step and the last instead of
      // snapping. beginStep also rewinds any interpolation the renderer left
      // behind, so the sim always integrates from its own last result.
      player.camera.beginStep();
      shipState.beginStep();

      if (running || seatLerp) {
        lights.update(engine.time);
        shipMap.update(dt);
        notifications.update(dt);
        system.update(dt);
        space.tickStellar(dt, system); // star spin + CME prominences
        thruster.update(dt, shipState);
        // The water loop reclaims and the med bed's cycle counts down whether
        // you are standing at them or three systems away in the seat.
        shipStations.update(dt);
        /**
         * THE HULL TALKING TO ITSELF. Strain scales both the loudness and the
         * frequency of the groan, so the plating figure on the HUD becomes
         * something you can hear without looking at it — and a boarded derelict
         * is pinned near the top of the scale because a dead hull is the one
         * place the sound belongs unconditionally.
         */
        audio.setHullStrain?.(boardedWreck ? 0.75
          : Math.max(0, 1 - (systems.hull ?? 100) / 100));
        // Breathing, weight-shifting, and turning to look at you. Only aboard a
        // station: `place()` empties the roster everywhere else, so this is a
        // no-op loop over nothing rather than a branch.
        stationCrew.update(dt, player.camera.eye);
        const zone = player.zone;
        systems.update(dt, {
          thrust: shipState.thrust,
          boosting: shipState.boosting,
          inFlight: state.is(STATES.FLIGHT),
          zoneId: zone ? zone.id : null,
          speed: shipState.speed,
        });
        // live sensor contacts: hulls within scope range (audit fix — was always 0)
        let contacts = 0;
        for (const s of system.ships) {
          if (Vec3.distance(shipState.pos, s.pos) < 9000) contacts++;
        }
        systems.contacts = contacts + combat.enemies.length;

        // combat simulation runs whether you're in the seat or not — the
        // patrols don't care where aboard you are
        combat.update(dt, shipState, systems);
        shakeT = Math.max(0, shakeT - dt * 1.6);

        // death (Phase 6): the hull breaking up or the body giving out
        if (!death.active) {
          if (systems.hull <= 0) {
            // Same six-stage break-up the enemies get, at ship scale and at the
            // Aethon's own position, so your death looks like the deaths you have
            // been handing out. Fired before die() because die() freezes the sim.
            combat.destroyShip(shipState.pos, shipState.vel, 2.4);
            shakeT = 10;
            die('THE AETHON BREAKS UP', 'The hull lets go all at once. It is very quiet afterwards.');
          } else if (systems.health <= 0) {
            die('YOU DIE ABOARD THE AETHON', 'The ship keeps flying. Ships do not grieve.');
          }
        }
      }

      if (seatLerp) {
        // camera glides between standing eye and seat eye — first person throughout
        seatLerp.t += dt / FLIGHT.SEAT_TRANSITION_S;
        const t = clamp(seatLerp.t, 0, 1);
        const s = t * t * (3 - 2 * t);
        const { from, to } = seatLerp;
        player.camera.setPose(
          [
            from.eye[0] + (to.eye[0] - from.eye[0]) * s,
            from.eye[1] + (to.eye[1] - from.eye[1]) * s,
            from.eye[2] + (to.eye[2] - from.eye[2]) * s,
          ],
          lerpAngle(from.yaw, to.yaw, s),
          lerpAngle(from.pitch, to.pitch, s),
        );
        input.consumeMouseDelta(); // discard look input mid-transition
        if (t >= 1) {
          const done = seatLerp.onDone;
          seatLerp = null;
          done();
        }
      } else if (state.is(STATES.SURFACE)) {
        // ON THE GROUND. Walking, with the terrain's own height field as the
        // floor — there is no CollisionMap out here and there does not need to
        // be: a heightfield IS the collision, sampled directly.
        const T = landing.terrain;
        const spd = 5.2 / Math.max(0.5, landing.profile?.gravity ?? 1);
        const f = (input.isDown('forward') ? 1 : 0) - (input.isDown('back') ? 1 : 0);
        const r = (input.isDown('right') ? 1 : 0) - (input.isDown('left') ? 1 : 0);
        if (f || r) {
          // Heading only: you walk where you are facing, not where you are
          // looking. Pitching down should not drive you into the ground.
          const cy = Math.cos(player.camera.yaw), sy = Math.sin(player.camera.yaw);
          const fx = sy, fz = -cy;
          surfacePos[0] += (fx * f + cy * r) * spd * dt;
          surfacePos[2] += (fz * f + sy * r) * spd * dt;
          // NO WALL. There used to be one here — the patch was the world and you
          // slid along its edge. The ground is a whole sphere now and the cap
          // follows you across it, so walking in one direction for an hour is a
          // thing you can do and the terrain in front of you is terrain nobody
          // has generated before.
          // Walk AROUND the boulders, not through them. The heightfield is the
          // floor and it knows nothing about what is standing on it, so the
          // scatter props (SurfaceGen.scatterRocks) carry their own collision
          // cylinders and the walker is pushed radially out of any it is
          // inside. Cheap: a hundred distance tests only while you are moving.
          for (const p of T?.props ?? []) {
            const dx = surfacePos[0] - p.x, dz = surfacePos[2] - p.z;
            const rr = p.r + 0.55;
            const d2 = dx * dx + dz * dz;
            if (d2 >= rr * rr || d2 < 1e-6) continue;
            const d = Math.sqrt(d2);
            surfacePos[0] = p.x + (dx / d) * rr;
            surfacePos[2] = p.z + (dz / d) * rr;
          }
        }
        surfacePos[1] = (T ? T.heightAt(surfacePos[0], surfacePos[2]) : 0) + PLAYER.HEIGHT;
        player.camera.setPose(surfacePos, player.camera.yaw, player.camera.pitch);
        // Reopen the board from anywhere on the surface, and the pad is where
        // the ship is — walking back to it is what the range readout is for.
        /**
         * INTERACT ON A WORLD. Two things it can mean, and the nearer one wins.
         *
         * Standing beside wreckage, it searches the wreckage — that is the
         * whole of surface looting, and it is deliberately the same verb and
         * the same key as opening a locker aboard, because it is the same act.
         * Standing anywhere else it reopens the surface board.
         */
        if (input.wasPressed('interact')) {
          const near = nearestCache(surfacePos);
          if (near) lootCache(near);
          else { input.exitPointerLock?.(); landingUI.show(); }
        }
        if (input.wasPressed('inventory')) inventoryUI.toggle();
        if (input.wasPressed('flashlight')) player.light.toggle();
        // Breathable air means the suit is not the clock; everywhere else it is.
        if (!landing.profile?.breathable) {
          systems.oxygen = Math.max(0, systems.oxygen - 0.16 * dt);
        }
        systems.update(dt, { walking: !!(f || r), surface: true });
        // Move the world with the boots. On foot the anchor is the walker, not
        // the parked ship — see Landing.trackFrame.
        landing.trackFrame(surfacePos[0], surfacePos[2], 0);
        // The envelope keeps clearing down here too. Touch down inside a couple
        // of seconds of breaking cloud and the plasma is still on the glass —
        // and a veil that only decayed in FLIGHT would freeze there for the
        // whole surface visit.
        landing.tickVeil(dt);
        if (landing.phase === 'fly') {
          // OFF THE PAD, still in the atmosphere. Lift-off used to jump
          // straight to the ascent cinematic, which made leaving a world every
          // bit as much of a cut as arriving at one used to be. You now come
          // off the ground with the controls live and fly out — see
          // Landing.launch — so this hands back to FLIGHT and nothing else.
          resumeState = STATES.FLIGHT;
          state.transition(STATES.FLIGHT);
          touch?.setMode('flight');
          input.requestPointerLock?.(canvas);
        } else if (landing.phase === 'ascent' || landing.phase === null) {
          // MADE ORBIT — and the hull has to be PUT SOMEWHERE FIRST. Through
          // the whole surface phase the ship's world position was wherever the
          // descent left it, which is inside the body's collision sphere; drop
          // straight back into flight from there and `collide` shoves you out
          // at speed, which is the same bounce this session set out to remove,
          // just one phase later. Park it in a clear orbit instead, moving, and
          // pointed away from the world it just left.
          const b = landing.body;
          if (b) {
            const r = b.radius * 2.2 + 600;
            // Straight up from the world, on the sunward flank so the arrival
            // frame is lit rather than a black disc.
            const L = Math.hypot(b.pos[0], b.pos[2]) || 1;
            const ux = b.pos[0] / L, uz = b.pos[2] / L;
            Vec3.set(shipState.pos, b.pos[0] + ux * r, b.pos[1] + b.radius * 0.5, b.pos[2] + uz * r);
            Vec3.set(shipState.vel, 0, 0, 0);
            shipState.snapHistory();
          }
          space.setTerrain(null, null);
          resumeState = STATES.FLIGHT;
          state.transition(STATES.FLIGHT);
          touch?.setMode('flight');
          input.requestPointerLock?.(canvas);
        }
        saveSys.tick(dt, autosaveSeconds());
      } else if (state.is(STATES.EVA)) {
        // OUTSIDE. No floor, no friction, no controller: every input is an
        // impulse and cancelling it costs the same gas as making it. The look
        // axis is still the player camera, which is what keeps this first
        // person and keeps the thrust basis the helmet's own.
        // UNCLIP. Same key as station-keeping in the seat, and the same idea:
        // stop being held to the thing you left. Forty-four metres of braid
        // cannot get you round a sixty-unit hull, so flying around your own
        // ship means coming off the line — and then the jet is the only way
        // back, which is a budget rather than a boundary.
        if (input.wasPressed('hold')) eva.toggleFreeFlight();
        // The hull holds its station while you are outside it — see keepStation
        // for why this is the difference between a crossing and a stranding.
        // Before refreshEvaTargets, so the ranges are computed after the carry.
        keepStation();
        // Where the wrecks are, this frame. The ship is still coasting under
        // you, so this is live data — see refreshEvaTargets.
        refreshEvaTargets();
        eva.update(dt, player.camera, {
          fwd: (input.isDown('forward') ? 1 : 0) - (input.isDown('back') ? 1 : 0),
          right: (input.isDown('right') ? 1 : 0) - (input.isDown('left') ? 1 : 0),
          up: (input.isDown('strafeUp') ? 1 : 0) - (input.isDown('strafeDown') ? 1 : 0),
          brake: input.isDown('crouch') || input.isDown('flightAssist'),
        });
        // Anything worth reaching in a suit is reached by BEING NEXT TO IT.
        // There is no interact ray out here — the hulls are hundreds of units
        // long and a 3m ray off the helmet would never touch one.
        /**
         * ONE KEY, THREE MEANINGS, NEAREST FIRST — the same rule the surface
         * uses. Hand on a rail beats cycling the lock beats saying no, because
         * that is the order of what is actually in front of you.
         */
        if (input.wasPressed('interact') && !eva.exiting) {
          const hold = eva.held ? null : eva.nearHold();
          const tgt = eva.held ? null : eva.nearTarget();
          if (eva.held) eva.release(player.camera);
          else if (hold) eva.grab(hold);
          else if (tgt) {
            /**
             * GOING ABOARD FROM THE SUIT — the owner's ask, and the reason the
             * boarding sequence is worth anything now. You crossed to this hull
             * on the pack, so the run is already paid for in gas and air before
             * you have seen a single compartment.
             *
             * The walk ENDS here rather than being suspended: you are inside a
             * pressure hull now, and `leaveWreck` puts you back in the Aethon's
             * own airlock, which is where a salvor who cut into a wreck and came
             * back out would be.
             */
            eva.end(false);
            boardWreck(tgt.ref);
          } else if (eva.canEnter) {
            eva.end(false);
            resumeState = STATES.PLAYING;
            state.transition(STATES.PLAYING);
            touch?.setMode('walk');
            input.requestPointerLock?.(canvas);
          } else {
            // Say how far the nearest interesting thing is, not just the lock —
            // out here "nothing in reach" without a number is not information.
            const t = eva.targets.length
              ? eva.targets.reduce((a, q) =>
                (eva.targetRange(q) < eva.targetRange(a) ? q : a))
              : null;
            notifications.push(t
              ? `NOTHING IN REACH — AIRLOCK ${Math.round(eva.range)}m, `
                + `${t.label} ${Math.round(eva.targetRange(t))}m`
              : `NOTHING IN REACH — AIRLOCK ${Math.round(eva.range)}m`);
          }
        }
        if (input.wasPressed('flashlight')) player.light.toggle();
        // The suit ended the walk itself (out of air): come back aboard on foot,
        // which is where you were when you cycled the lock.
        if (!eva.active) {
          resumeState = STATES.PLAYING;
          state.transition(STATES.PLAYING);
          touch?.setMode('walk');
        }
        // The suit's own physiology still runs: heat, radiation, the lot.
        systems.update(dt, { walking: false, eva: true });
        saveSys.tick(dt, autosaveSeconds());
      } else if (state.is(STATES.PLAYING)) {
        player.update(dt, game);
        /**
         * GOING THROUGH WHAT YOU KILLED.
         *
         * Handled here rather than as an interactable, because a body is not
         * part of the deck: it appears mid-visit, moves until it stops, and the
         * ship's interact raycast is built from the map's static volume list.
         * Guarded on there being no raycast target so a locker you are standing
         * in front of still wins the key — the nearer, more specific thing
         * always does.
         */
        if (boardedWreck && input.wasPressed('interact') && !player.controller.interactTarget) {
          const body = boarders.nearRemains(player.position);
          if (body) stripRemains(body);
        }
        if (input.wasPressed('inventory')) inventoryUI.toggle();
        if (input.wasPressed('journal')) journalUI.toggle();
        if (input.wasPressed('scanner') && !scanner.toggle()) {
          notifications.push('SCANNER CELL DEAD — CHARGE AT ANY CONSOLE');
        }
        // -- hand weapons ------------------------------------------------------
        // Drawn only while walking. The scanner and a weapon are mutually
        // exclusive: both occupy the hands, and raising the scanner while
        // holding a carbine would need a third arm.
        if (input.wasPressed('drawWeapon')) {
          if (scanner.raised) scanner.toggle();
          handgun.cycle();
        }
        if (handgun.drawn) {
          if (scanner.raised) handgun.holster();
          if (input.wasPressed('reload')) handgun.reload();
          // `fire` is Mouse0/X — the same binding the ship gun uses in the seat.
          // `held` is passed so a semi-automatic cannot be made automatic by
          // leaning on the button.
          if (input.isDown('fire')) {
            handgun.tryFire(player.camera, !input.wasPressed('fire'), systems);
          }
          // The kick is applied to the camera HERE rather than inside the
          // weapon, because pitch belongs to the camera and clamping it is the
          // camera's job. Consumed once per shot, not integrated per frame.
          const k = handgun.consumeKick();
          if (k) player.camera.kickPitch(k);
        }
        handgun.update(dt, player);
        scanner.update(dt);
        noise.update(dt);
        tension.update(dt); // the Hollow stalks only while you walk the ship
        /**
         * And the things that CAN be fought, which only exist on a boarded
         * hull. Fed the crouch and the lamp because both change how far away
         * you can be noticed from: creeping in the dark genuinely works, and
         * walking in with the helmet lamp on genuinely does not.
         */
        if (boardedWreck) {
          boarders.update(dt, player.camera.eye, {
            noise: noise.level,
            crouched: !!player.controller?.crouched,
            lampOn: !!player.light?.on,
          });
        }
        saveSys.tick(dt, autosaveSeconds()); // quiet autosave safety net
        // a ship left coasting keeps coasting (Newtonian, even unattended)
        if (shipState.speed > 0) {
          Vec3.scaleAndAdd(shipState.pos, shipState.pos, shipState.vel, dt);
        }
        // ...and a ship left holding station keeps holding it. Leaving the seat
        // is not cancelling the burn.
        keepStation();
      } else if (state.is(STATES.FLIGHT)) {
        if (warp.phase) {
          // the drive holds the ship — no steering, no seat exit, mid-jump.
          // Stages 1-3 play on the external cinematic camera (allowed by the
          // camera rule for warp); the streak stage cuts back to the glass.
          warp.t += dt;
          Vec3.set(shipState.vel, 0, 0, 0);
          const fx = space.warpFx;
          if (warp.phase === 'infall') {
            // stage 1: space starts bending, matter streams into the spine
            if (!view.third) view.third = true;
            const p = warp.t / FLIGHT.WARP_INFALL_S;
            fx.mode = 'infall'; fx.holeR = 0; fx.bend = 0.4 * p; fx.intensity = p * 0.6;
            audio.setEngineThrust(0.3 + 0.4 * p);
            if (warp.t >= FLIGHT.WARP_INFALL_S) { warp.phase = 'hole'; warp.t = 0; }
          } else if (warp.phase === 'hole') {
            // stage 2: the black sphere appears and grows; the accretion disk
            // spins up around it; the lensing strengthens
            const p = warp.t / FLIGHT.WARP_HOLE_S;
            fx.mode = 'hole';
            fx.holeR = FLIGHT.WARP_HOLE_R * p * p;
            fx.bend = 0.4 + 0.55 * p;
            fx.intensity = 0.6 + 0.4 * p;
            audio.setEngineThrust(0.7 + 0.3 * p);
            if (warp.t >= FLIGHT.WARP_HOLE_S) { warp.phase = 'consume'; warp.t = 0; }
          } else if (warp.phase === 'consume') {
            // stage 3: the hole swallows the ship whole
            const p = warp.t / FLIGHT.WARP_CONSUME_S;
            fx.mode = 'consume';
            fx.holeR = FLIGHT.WARP_HOLE_R + (FLIGHT.WARP_CONSUME_R - FLIGHT.WARP_HOLE_R) * p;
            fx.bend = 0.95 + 0.5 * p;
            fx.intensity = 1;
            audio.setEngineThrust(1);
            if (warp.t >= FLIGHT.WARP_CONSUME_S) {
              warp.phase = 'streak'; warp.t = 0;
              fx.mode = null; fx.holeR = 0; fx.bend = 0; fx.intensity = 0;
              view.third = false; view.t = 0; // hard cut to the glass, behind the flash
              warpFlash();
            }
          } else {
            // stage 4: hyperspace streaks; the system swaps behind the flash
            const T = FLIGHT.WARP_STREAK_S;
            space.warpT = warp.t < T * 0.55
              ? Math.min(1, warp.t / 0.4)
              : Math.max(0, 1 - (warp.t - T * 0.55) / (T * 0.4));
            audio.setEngineThrust(1);
            if (!warp.swapped) {
              warp.swapped = true;
              systems.warpFuel = Math.max(0, systems.warpFuel - FLIGHT.WARP_COST);
              system = new StarSystem(warp.target);
              // build the arrival system's star AND every body surface it needs,
              // now, during the jump flash — not on the first frame after it
              primeSystemTex(warp.target);
              arriveAt(warp.target);
              celestial.hide();
              combat.setSystem(warp.target); // fresh patrols for the new system
              tension.setSystem(warp.target.id); // and whatever else lives here
              events.emit('system:arrived', warp.target.id);
              notifications.push(`ARRIVAL: ${warp.target.name} — ${warp.target.danger} RISK ZONE`);
            }
            if (warp.t >= T) { warp.phase = null; warp.target = null; space.warpT = 0; audio.setEngineThrust(0); }
          }
          space.updateWarpFx(dt);
        } else {
          // HULL CAM ORBIT is now a HELD gesture, not the default use of look.
          // It used to swallow the look delta whenever the chase cam was out,
          // which left flightCtl.update() nothing to steer with — the ship simply
          // could not be turned in third person. Steering is the primary job of
          // that input in both views; orbiting is the exception you ask for by
          // holding ORBIT (right mouse / the touch ORBIT button).
          if (view.third && view.t > 0.5 && input.isDown('orbit')) {
            const [mdx, mdy] = input.consumeMouseDelta();
            orbit.yaw = orbit.yaw + mdx * 0.004;
            orbit.pitch = clamp(orbit.pitch + mdy * 0.004, -1.2, 1.2);
          }
          // Hull-cam dolly. HELD rather than tapped — a zoom you have to press
          // eleven times is not a zoom — and rate-limited by dt so the travel
          // takes the same wall-clock time at 30fps as at 60. Only while the
          // camera is actually out; in the seat there is nothing to dolly.
          if (view.third) {
            // 2.2 steps/s over a 0.22 log-step: the full 0.45..3.2 travel takes
            // about four seconds end to end, which is slow enough to frame the
            // hull deliberately rather than overshooting the stop every time.
            if (input.isDown('zoomIn') || heldBarButton === 'zoomin') zoomChase(-1, dt * 2.2);
            if (input.isDown('zoomOut') || heldBarButton === 'zoomout') zoomChase(1, dt * 2.2);
            // keep the key visibly sunk for as long as it is held, rather than
            // for the 0.16s a one-shot press flashes
            if (heldBarButton) hud.flashButton(heldBarButton);
          }
          flightCtl.update(dt); // mouse steers the SHIP; the head stays forward
          // FLYING INTO A WORLD IS HOW YOU LAND ON IT.
          //
          // `collide` pushes the hull back out to the body's surface sphere and
          // kills the inward velocity, which is correct for a star, a gas giant
          // and anything you have no business touching — and was catastrophic
          // for everything else: aiming at a planet and holding the throttle
          // down made the ship BOUNCE off it, over and over, with no way through
          // and no hint that the LAND button in the approach panel was the only
          // route to the surface. The transition existed and was unreachable by
          // the one action every player tries first.
          //
          // So the contact is now the commit. Hit something landable and the
          // entry begins; hit a star or a gas giant and you still get shoved
          // off, because there is nothing down there to arrive at.
          if (!landing.active) {
            const hit = system.collide(shipState.pos, shipState.vel);
            if (hit && !hit.isStar && landing.survey(hit)) landing.begin(hit);
          }
          // UNSWEPT ORDNANCE. The only hazard in the game that punishes flying
          // in a straight line at speed: a field has no approach prompt, no
          // transponder and no lights worth seeing, so the proximity scanner
          // and the radar are the whole warning. Shield first, then hull.
          const mine = system.armedMine(shipState.pos);
          if (mine) {
            // `applyHit` is the ONE damage entry point: it runs the shield, the
            // armour term and the per-section bookkeeping the HUD damage plan
            // reads. Subtracting from `hull` directly here would have produced a
            // ship that was hurt everywhere and damaged nowhere.
            const r = systems.applyHit(mine.damage ?? 22, 'fore');
            combat.destroyShip?.(mine.pos, [0, 0, 0], 0.55);
            audio.playBoom?.();
            shakeT = Math.min(1.2, shakeT + 0.8);
            notifications.push(r?.breached || (r?.hullDamage ?? 0) > 0
              ? 'MINE DETONATION — HULL BREACHED'
              : 'MINE DETONATION — DEFLECTOR HELD');
            events.emit('mine:hit', mine.id);
          }
          // -- STATION-KEEPING ---------------------------------------------
          // Everything out here MOVES. A world runs its orbit, a station rides
          // with its host, a hauler runs its lane — so a ship left at rest is a
          // ship being left behind, and lining up on something meant chasing it
          // the whole time. HOLD locks the hull to whatever it is nearest and
          // carries it along, which is what a real station-keeping burn does.
          if (input.wasPressed('hold')) {
            if (holdTarget) {
              holdTarget = null;
              notifications.push('STATION-KEEPING RELEASED');
            } else {
              const t = holdCandidate(shipState.pos);
              if (t) {
                holdTarget = t;
                // Mutate, never reassign: `holdPrev` is a const scratch and
                // rebinding it threw on the first press every time.
                holdPrev[0] = t.pos[0];
                holdPrev[1] = t.pos[1];
                holdPrev[2] = t.pos[2];
                notifications.push(`STATION-KEEPING ON ${t.name} — MATCHING ITS MOTION`);
              } else {
                notifications.push('NOTHING IN RANGE TO HOLD STATION ON');
              }
            }
          }
          keepStation();
          if (input.wasPressed('view')) toggleView();
          if (input.wasPressed('warp')) {
            warpPanel.refresh(system.def.id, systems.warpFuel);
            warpPanel.toggle();
          }
          if (input.wasPressed('inventory')) inventoryUI.toggle();
          if (input.wasPressed('cycleWeapon')) combat.cycleWeapon(1);
          // `_lockFwd` is the hull forward vector combat.update already built
          // this step — recomputing it here would be a second quaternion
          // rotation for the same answer.
          if (input.wasPressed('lockTarget')) {
            combat.cycleLock(shipState, combat._lockFwd ?? [0, 0, -1]);
          }
          // ATMOSPHERIC ENTRY. Flown, not watched: heat builds with speed
          // against the air and the hull pays for coming in fast, so the whole
          // descent is a live trade between fuel and plating.
          // NO COLLISION DURING A DESCENT. You are supposed to be going down;
          // the surface sphere pushing back is the thing this whole fix exists
          // to stop, and leaving it armed would have the hull fighting the
          // entry all the way to touchdown.
          // The envelope runs on its own clock, every frame, phase or none: the
          // tail of a clear outlives the descent that made it.
          const wasGround = landing.showGround;
          landing.tickVeil(dt);
          // INTO THE DESCENT ATTITUDE, under the plasma. Breaking cloud with the
          // hull level put the whole windshield on sky — you arrived over a
          // landscape you could not see, which is the "the surface isn't there
          // when I land" report — but snapping the nose down in the open, on the
          // frame the LAND button was pressed, is a hand grabbing the stick out
          // of yours. Done here it happens on the same covered frame as the
          // world swap: the envelope closes level and opens looking down.
          if (!wasGround && landing.showGround && landing.phase === 'entry') {
            Quat.lookYaw(shipState.quat, [0, 0, -1]);
            Quat.setAxisAngle(_landQ, [1, 0, 0], -0.62);
            Quat.multiply(shipState.quat, shipState.quat, _landQ);
            shipState.updateConjugate?.();
            shipState.snapHistory();
          }
          if (landing.phase === 'entry' || landing.phase === 'fly' || landing.phase === 'ascent') {
            const tele = landing.update(dt, shipState);
            if (tele) shakeT = Math.min(1.2, Math.max(shakeT, tele.buffet * 0.9));
            if (landing.onGround) {
              // Down, WHERE YOU PUT IT. The walk-out point is the hull's own
              // touchdown coordinate, not the centre of the patch: the whole
              // reason the descent is flown is that you chose the spot.
              resumeState = STATES.SURFACE;
              state.transition(STATES.SURFACE);
              touch?.setMode('walk');
              surfacePos = [landing.local[0],
                landing.terrain.heightAt(landing.local[0], landing.local[2]) + PLAYER.HEIGHT,
                landing.local[2]];
              player.camera.pitch = 0;
              // Same stale-target trap as the EVA: `player.update` does not run
              // down here, so the last thing the interior raycast hit would
              // keep printing across the landscape.
              player.controller.interactTarget = null;
              input.exitPointerLock?.();
              landingUI.show();
            }
          }
          // BACK OUT THROUGH THE TOP. The moment the envelope takes the ground
          // away is the moment the hull has to exist in system space again —
          // and it cannot be left where the descent parked it, which is inside
          // the world's collision sphere. Doing it HERE rather than when the
          // ascent timer expires means the reposition happens under solid
          // plasma, so what used to be a jump-cut to orbit is now just the
          // envelope thinning onto a starfield.
          if (wasGround && !landing.showGround) {
            const b = landing.body;
            if (b) {
              const r = b.radius * 2.2 + 600;
              const L = Math.hypot(b.pos[0], b.pos[2]) || 1;
              Vec3.set(shipState.pos, b.pos[0] + (b.pos[0] / L) * r,
                b.pos[1] + b.radius * 0.5, b.pos[2] + (b.pos[2] / L) * r);
              Vec3.set(shipState.vel, 0, 0, 0);
              shipState.snapHistory();
            }
            space.setTerrain(null, null);
          }
          if (input.wasPressed('repair')) fieldRepair();
          repairCd = Math.max(0, repairCd - dt);
          if (input.isDown('fire')) combat.tryFire(shipState, systems, dt);
          // RCS visual state for the exterior view: roll keys, steering rate,
          // and the translational thrusters (Q/E/R/F) firing their jets
          space.damage = 1 - systems.hull / 100; // drives smoke/ember trail
          // Per-section integrity for the breach-venting pass. The mean above
          // can only say "hurt"; this says WHERE, so the jet comes out of the
          // section the HUD's damage plan is flagging.
          space._hullSections = systems.sections;
          // driven by the hull's actual ANGULAR VELOCITY now, not the raw key /
          // mouse input: the thrusters keep firing while momentum is being
          // arrested, which is what you'd see on a real attitude-control burn
          // Signed per-axis rates, not one lumped "steer" magnitude: the renderer
          // fires the specific port that would produce each torque, so pitch,
          // yaw and roll each light their own nozzle instead of all three
          // firing the same pair of nose jets.
          const av = shipState.angVel ?? [0, 0, 0];
          space.rcs = {
            pitch: av[0], yaw: av[1], roll: av[2],
            strafe: [shipState.strafe[0], shipState.strafe[1]],
          };
          // main-drive plume: exhaust pixels streaming off the nozzles
          if (Math.abs(shipState.thrust) > 0.15 && Math.random() < 0.6) {
            const back = [0, 0, 1];
            const q = shipState.quat;
            const bx = 2 * (q[1] * back[2] - q[2] * back[1]);
            const by = 2 * (q[2] * back[0] - q[0] * back[2]);
            const bz = 2 * (q[0] * back[1] - q[1] * back[0]);
            const wx = back[0] + q[3] * bx + (q[1] * bz - q[2] * by);
            const wy = back[1] + q[3] * by + (q[2] * bx - q[0] * bz);
            const wz = back[2] + q[3] * bz + (q[0] * by - q[1] * bx);
            combat.sparks.push({
              pos: [shipState.pos[0] + wx * 17, shipState.pos[1] + wy * 17, shipState.pos[2] + wz * 17],
              vel: [wx * 60 + shipState.vel[0] * 0.3, wy * 60 + shipState.vel[1] * 0.3, wz * 60 + shipState.vel[2] * 0.3],
              ttl: 0.35, col: shipState.boosting ? [1, 0.85, 0.55] : [0.95, 0.7, 0.35], size: 1,
            });
          }
          // stand up from the seat with crouch (C/Ctrl) — E now strafes right
          if (input.wasPressed('crouch') && view.t < 0.5) game.exitFlight();
          saveSys.tick(dt, autosaveSeconds());
        }
        // seat pose, rattled by nearby impacts
        const sx = shakeT > 0 ? (Math.random() - 0.5) * 0.14 * shakeT : 0;
        const sy2 = shakeT > 0 ? (Math.random() - 0.5) * 0.1 * shakeT : 0;
        player.camera.setPose([FLIGHT.SEAT_EYE[0] + sx, FLIGHT.SEAT_EYE[1] + sy2, FLIGHT.SEAT_EYE[2]], 0, 0);
        if (!warp.phase) audio.setEngineThrust(Math.abs(shipState.thrust));
        // animate the first↔third-person transition
        const dir = view.third ? 1 : -1;
        view.t = clamp(view.t + (dir * dt) / FLIGHT.VIEW_TOGGLE_S, 0, 1);
        // (the chase basis itself is rebuilt in render, off the resolved attitude)
        if (input.wasPressed('flashlight')) player.light.toggle();
        celestial.update(warp.phase ? null : system.approach(shipState.pos)); // landing / scan prompt
      }

      shipState.endStep(); // commit this step's attitude as the interp target
      input.endFrame();
    },
    /**
     * Once per rendered frame, after every fixed step and before render.
     *
     * Look lives here, not in update(): the fixed accumulator runs 0, 1 or 2
     * steps per frame, so aiming from inside it was quantised to whichever
     * frames happened to carry a step. Only walking — in the seat the mouse is
     * torque on the hull, which is physics and belongs on the fixed clock, and
     * mid-transition the delta is deliberately discarded.
     */
    frame(frameDt) {
      hud.tick(frameDt);
      if (settingsMenu.visible || gameMenu.visible || hacking.visible
        || tradingUI.visible || fabricatorUI.visible || dialogueUI.visible
        || death.active || seatLerp) return;
      // Look, on the frame clock. EVA gets it too: outside, aiming the helmet
      // IS the control — it decides which way the jet pushes — so quantising it
      // to the fixed step would make every burn a fraction off where you looked.
      if (state.is(STATES.PLAYING) || state.is(STATES.EVA) || state.is(STATES.SURFACE)) {
        player.controller.applyLook();
      }
    },
    render(alpha) {
      // Resolve the drawn eye between the last two simulated positions. Skipped
      // during the seat lerp and while piloting, both of which set the pose
      // explicitly every step — there is no physics history to smooth there.
      if (state.is(STATES.PLAYING) && !seatLerp) player.camera.resolve(alpha);
      // The hull's attitude swings the whole view through the glass, so it gets
      // the same treatment; the chase basis is then rebuilt from the resolved
      // attitude rather than the raw step one.
      shipState.resolve(alpha);
      if (state.is(STATES.FLIGHT) && view.t > 0) updateChase();
      post.begin(); // scene renders into the CRT target (or the backbuffer if off)
      renderer.beginFrame();
      if (!state.is(STATES.LOADING) && !state.is(STATES.GATE)) {
        const exterior = state.is(STATES.FLIGHT) && view.t > 0;
        // WHICH WORLD IS OUT THERE. Not derived from the phase — Landing owns
        // it, because the flip has to land on a frame the plasma is covering
        // and that is not the same frame the phase changes on.
        const inAtmo = state.is(STATES.FLIGHT) && landing.showGround;
        if (state.is(STATES.SURFACE)) {
          space.renderSurface(player.camera, { profile: landing.profile }, system);
        } else if (inAtmo && view.t > 0) {
          // THIRD PERSON, ON THE WAY DOWN. The one view mode that is about
          // judging a distance rather than looking at your own ship: from the
          // seat the last twenty units of a descent are behind the console.
          updateSurfaceChase();
          space.renderSurface(surfChase, { profile: landing.profile }, system);
          space.renderSurfaceHull(surfChase, shipState, landing.local);
        } else if (inAtmo) {
          // Flying inside an atmosphere: the world outside the glass is a
          // landscape, not a starfield. Then the cockpit on top of it, as ever.
          updateSurfaceCam();
          space.renderSurface(surfCam, { profile: landing.profile }, system);
          // The two passes use DIFFERENT projections — the ground needs a 7000
          // unit far plane and the interior a 120 unit one — so their depth
          // values are not comparable and near terrain z-fights the console.
          // One clear between them is the whole fix.
          renderer.gl.depthMask(true);
          renderer.gl.clear(renderer.gl.DEPTH_BUFFER_BIT);
          interior.render(player.camera, player.light, engine.time);
        } else if (state.is(STATES.EVA)) {
          // Outside the hull. Same renderer as the chase view, different eye —
          // see updateEvaCam. Still first person: the eye IS the helmet.
          updateEvaCam();
          // Full size. From a suit the ship is the size the ship is — the 0.55
          // chase factor is a framing choice for a camera fifty metres back.
          space.renderExterior(evaCam, shipState, system, { hullScale: 1 });
        } else if (exterior) {
          // third-person: the whole ship against space, no interior
          space.renderExterior(chase, shipState, system);
        } else {
          // Space renders behind the interior only where it can actually be
          // seen: seated flight (windshield) or standing in/next to the cockpit
          // (the one windowed room). Everywhere else the sealed hull covers the
          // view, so skipping it means any stray gap shows dark hull, not a
          // glaring hole to the starfield — and it saves a full space pass.
          const walking = state.is(STATES.PLAYING);
          const z = player.zone;
          const nearWindow = z && (z.id === 'cockpit' || z.neighbours?.includes('cockpit'));
          if ((!walking || nearWindow) && !window.__debug?.hideSpace) {
            space.render(player.camera, shipState, system, thruster);
          }
          interior.render(player.camera, player.light, engine.time);
        }
        renderer.begin2D();
        // THE ENVELOPE, in front of the world and behind the chrome. In front,
        // because it is outside the glass and the world swap happens under it;
        // behind, because an instrument you cannot read during an entry is an
        // instrument that is missing when it matters most.
        if (landing.veil > 0.002) {
          pix.setTexture(fontTexture);
          entryVeil.render(pix, landing.veil, engine.time,
            landing.tele.heat, landing.phase === 'ascent');
        }
        const mode = state.is(STATES.FLIGHT) ? 'flight' : 'walk';
        // The suit panel rides ON TOP of the walk HUD rather than replacing it:
        // health, oxygen, food and water are exactly as relevant outside as in,
        // and an EVA that hid them would hide the one that kills you.
        hud.render(player, crosshair, notifications, mode, shipState, systems,
          { noise: noise.level, hidden: noise.hidden, loadout: combat.loadout,
            lock: combat.lock,
            contacts: mode === 'flight' ? radarContacts() : null,
            // Recomputed every frame rather than cached: a frame of staleness
            // on a firing solution is a frame of shots going somewhere else.
            aim: mode === 'flight' ? combat.aimStatus(shipState) : null,
            radarRange: FLIGHT.RADAR_RANGE * progression.bonus('scanRange'),
            // New HUD readouts (0.22.0): where we are, what's closest, what the
            // suit is breathing, and how long this commission has been running.
            systemName: system.name,
            nearest: mode === 'flight' ? nearestBody() : null,
            env: { pressure: systems.pressure, gravity: systems.gravity },
            // The zoom pad only exists while the hull cam is out — `orbit` carries
            // the live dolly value and its stops, which is everything the pad
            // needs to draw itself and grey out its ends.
            chase: mode === 'flight' && view.third ? orbit : null,
            // The suit panel, only while actually outside.
            eva: state.is(STATES.EVA) ? eva.status() : null,
            place: state.is(STATES.SURFACE) ? (landing.body?.name ?? 'SURFACE')
              : state.is(STATES.EVA) ? 'EXTRAVEHICULAR' : null,
            // What is within arm's reach on a world. There is no raycast out
            // there, so the prompt is fed rather than derived — see HUD.
            reach: state.is(STATES.SURFACE)
              ? (nearestCache(surfacePos)?.label ?? null)
              : state.is(STATES.EVA) ? evaReach()
                // A body on the deck is not an interactable (see stripRemains),
                // so the prompt for one has to be fed the same way the surface
                // and the suit feed theirs.
                : boardedWreck
                  ? (boarders.nearRemains(player.position)
                    ? `SEARCH ${boarders.nearRemains(player.position).K.name}` : null)
                  : null,
            missionTime: engine.time });
        if (mode === 'walk') {
          scanner.draw(pix, font, fontTexture, RENDER.UI_WIDTH, RENDER.UI_HEIGHT, player);
          // after the scanner, so a drawn weapon is in front of the handheld if
          // both somehow end up on screen at once
          // Incoming fire FIRST, so the viewmodel covers it: a bolt that
          // crosses in front of your own weapon passes behind it, not over it.
          if (boardedWreck) {
            boarders.drawFx(pix, player.camera, RENDER.UI_WIDTH, RENDER.UI_HEIGHT);
          }
          handgun.draw(pix, font, fontTexture, RENDER.UI_WIDTH, RENDER.UI_HEIGHT,
            player.camera);
        }
        renderer.end2D();
      }
      const zone = player.zone;
      debug.set({
        DRAW: renderer.drawCalls,
        POS: `${player.position[0].toFixed(1)} ${player.position[2].toFixed(1)}`,
        ZONE: zone ? zone.id : '-',
        SHIP: `${shipState.pos[0].toFixed(0)} ${shipState.pos[1].toFixed(0)} ${shipState.pos[2].toFixed(0)}`,
        SPD: shipState.speed.toFixed(1),
        BUF: renderer.liveBuffers,
      });
      post.end(engine.time); // resolve the CRT tube to the display
    },
  }, debug);

  applyBootChrome(); // reskin the static gate/pause overlays with pixel-art plates
  loadingEl.classList.add('hidden');
  // reflect the pilot's name on the gate once known
  const gateCrew = gateEl.querySelectorAll('.corp')[1]; // the CREW 1 OF 6 line
  const showPilotOnGate = () => {
    if (!gateCrew) return;
    const c = shipClass(pilot.shipClass);
    const who = pilot.callsign || pilot.name;
    gateCrew.textContent = `PILOT ${who} — ${c.hullName} — CREW 1 OF ${c.crew ?? 6}`;
  };

  /**
   * Put a hull class into effect. One function for both the commission and the
   * save restore, so the two can never disagree about what a Petrel is.
   *
   * The deck REBUILD is the expensive half and only runs when the class is not
   * the default the interior was already built as — see ShipMap.reconfigure for
   * why the interior cannot simply be built once with the right layout.
   */
  function commissionHull(cls, liveryId) {
    const c = applyShipClass(cls, systems, inventory);
    pilot.shipClass = c.id;
    if (liveryId) pilot.livery = liveryId;
    // The tint is a plain field on the renderer rather than a setter: it is read
    // once per frame at the ship draw and there is nothing to invalidate.
    space.hullTint = new Float32Array(livery(pilot.livery).tint);
    flightCtl.cls = { ...c.flight };
    // Rebuild whenever the deck standing is not this hull's. Was gated on
    // `c.drop.length`, which was right when a class differed only by which
    // compartments it had; a class now also carries a FIT (see data/ShipFit.js)
    // that repaints the spine and refits a compartment. Gating on the class the
    // deck was BUILT as rather than on "is it the Aethon" is what makes the
    // trade DOWN work too — the first version left a pilot who sold a Harrier
    // back for a cutter standing in the Harrier's magazine.
    if (shipMap.builtAs !== c.id) shipMap.reconfigure(c.drop, { atlas, lights, renderer }, c.id);
    // The silhouette other things see, and the FX anchors that go with it.
    // Async because the three non-Aethon meshes live in their own module and
    // are only paid for by a player who actually flies one — a fresh Aethon
    // never loads them.
    buildPlayerHull(c.id).then((m) => space.setAethon(m));
    return c;
  }

  state.transition(STATES.GATE);
  // fresh save: run the commission before the gate is usable
  if (freshStart) {
    charGen.show(({ name, callsign, background, ship, livery: lv }) => {
      pilot.name = name;
      pilot.callsign = callsign ?? '';
      pilot.background = background.id;
      const c = commissionHull(ship, lv?.id);
      CharacterCreation.apply({ name, background }, { inventory, trading, factions });
      showPilotOnGate();
      notifications.push(`PILOT ${callsign || name} — ${background.name} — ${c.hullName}`);
    });
  } else {
    // A restored save carries its hull; older saves have none and are Aethons.
    // Always re-apply on restore: even an Aethon carries a livery.
    commissionHull(pilot.shipClass, pilot.livery);
    showPilotOnGate();
  }
  engine.start();

  notifications.push(`${shipClass(pilot.shipClass).hullName} - INTERNAL GRAVITY NOMINAL`);

  // Debug hook for automated probing (teleport/aim the camera). Harmless in
  // production — only read by test scripts and the ` debug overlay flows.
  window.__debug = {
    player, interior, shipState, state, STATES, renderer, game, shipMap, inventory, saveSys, combat, tension, space, orbit,
    // `view` so a probe can drive the camera to a KNOWN mode: the jump sequence
    // forces view.third = false at the flash, which silently undoes a blind toggle
    view, celestial,
    trading, tradingUI, quests, journalUI, hacking, loreUnlocked, post, factions, charGen, pilot,
    warpPanel, inventoryUI, settingsMenu, hud, touch: () => touch,
    boarding, boardingUI, eva, landing, landingUI, shipyardUI, progression,
    fabrication, fabricatorUI, shipStations, stationCrew, dialogue, dialogueUI,
    boarders, boardWreck, leaveWreck, stripRemains, goAboard, leaveStation,
    get boardedWreck() { return boardedWreck; },
    get dockedAt() { return dockedAt; },
    // exposed for probes: attitude comes in through input.setVirtualTurn, and
    // the repair / radar paths are otherwise only reachable from a keypress
    input, fieldRepair, radarContacts, forceTouch: () => enableTouch(), handgun,
    get holdTarget() { return holdTarget; },
    get system() { return system; }, // live — warp swaps the instance
    get warp() { return warp; },
    systems,
    warpTo(id) { const def = SYSTEMS.find((s) => s.id === id); if (def) { warp.phase = 'infall'; warp.t = 0; warp.target = def; warp.swapped = false; } },
    enterFlight: () => game.enterFlight(),
    exitFlight: () => game.exitFlight(),
    toggleView,
    // Refit to another hull class without going through the yard UI: the only
    // way a probe can walk all four decks in one run.
    commissionHull,
    factory, // probes measure texture generation cost and value ranges off this
    RENDER, // probes assert the resolved render-scale preset (scene vs UI grid)
    // Simulated seconds. Probes must wait on THIS, not on wall time: under
    // software rendering the frame rate is low enough that Engine's 5-step
    // catch-up cap drops backlog, so the sim clock runs behind the wall clock.
    engineTime: () => engine.time,
    /**
     * The walker's position in the current cap's local frame. A probe needs to
     * both read it (to check the ground under the boots) and step it (to cover
     * kilometres of a planet without waiting for real walking speed).
     */
    get surfacePos() { return surfacePos; },
    surfaceStep(du, dv) { if (surfacePos) { surfacePos[0] += du; surfacePos[2] += dv; } },
    /** Point the hull along a horizontal direction (probe framing helper). */
    lookAlong(dir) { Quat.lookYaw(shipState.quat, dir); shipState.snapHistory(); },
    /**
     * Teleport for automated probes: zero the velocity, then push the body out
     * of any geometry the requested spot happens to sit inside.
     *
     * The depenetrate call is what makes this trustworthy. Without it a landing
     * that clipped a wall or a prop was silently lifted onto the roof by the
     * next gravity tick (see CollisionMap.depenetrate), so probe screenshots
     * were taken from OUTSIDE the hull looking in and read as holes in the ship.
     */
    teleport(x, y, z, yaw, pitch) {
      Vec3.set(player.position, x, (y ?? 0) + 0.02, z);
      if (player.velocity) Vec3.set(player.velocity, 0, 0, 0);
      if (player.controller?.velocity) Vec3.set(player.controller.velocity, 0, 0, 0);
      const h = PLAYER.HEIGHT;
      const c = [player.position[0], player.position[1] + h / 2, player.position[2]];
      shipMap.collision.depenetrate(c, [PLAYER.RADIUS, h / 2, PLAYER.RADIUS]);
      Vec3.set(player.position, c[0], c[1] - h / 2, c[2]);
      if (yaw !== undefined) player.camera.yaw = yaw;
      if (pitch !== undefined) player.camera.pitch = pitch;
    },
  };
}

boot().catch((err) => {
  // Loud, unmissable fault display — a silent hang looks like a dead menu.
  loadingEl.classList.remove('hidden');
  loadingStatus.textContent = `BOOT FAULT: ${err.message}`;
  loadingStatus.style.color = '#bb4030';
  loadingStatus.style.fontSize = '13px';
  console.error(err);
});

// Service worker policy.
//
// The SW only exists for offline PWA support of the *deployed* game. On dev
// hosts (localhost, and Codespaces / github.dev / gitpod preview URLs) it is
// pure downside: a previously-registered worker can pin stale code and make
// every fix invisible — exactly the "stuck at the menu" trap. So on any
// non-production host we DON'T register it and we actively unregister any
// worker a past build left behind, then drop its caches. This self-heals a
// device that cached an old build the moment fresh code runs.
const host = location.hostname;
const isDevHost =
  ['localhost', '127.0.0.1'].includes(host) ||
  /github\.dev$|githubpreview\.dev$|app\.github\.dev$|gitpod\.io$|\.csb\.app$/.test(host);
const isProd = location.protocol === 'https:' && !isDevHost;

if ('serviceWorker' in navigator) {
  if (isProd) {
    navigator.serviceWorker.register('sw.js').then((reg) => reg.update()).catch(() => {});
    let reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (reloaded) return;
      reloaded = true;
      location.reload();
    });
  } else {
    // Dev host: evict any stale worker + caches from an earlier build.
    navigator.serviceWorker.getRegistrations?.().then((regs) => {
      let had = false;
      for (const r of regs) { r.unregister(); had = true; }
      if (had && window.caches) caches.keys().then((ks) => ks.forEach((k) => caches.delete(k)));
    }).catch(() => {});
  }
}
