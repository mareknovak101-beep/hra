/**
 * QuestSystem — the survey's standing work orders (Phase 7). Ten data-driven
 * contracts tracked off the event bus: collect cargo, dock, jump systems,
 * splash hostiles, move goods, keep the record. Every quest is visible from
 * the start (a clipboard, not a plot) and pays out in credits and materiel
 * the moment its condition lands.
 */
import { ITEMS } from '../data/ItemRegistry.js';

export const QUESTS = [
  { id: 'q_provisions', name: 'PROVISION AUDIT', type: 'collect', target: 'ration_protein', n: 3,
    desc: 'Company wants the larder counted. Hold three protein rations at once.',
    reward: { credits: 60 } },
  { id: 'q_meridian', name: 'TOP OFF AT MERIDIAN', type: 'dock', target: 'meridian', n: 1,
    desc: 'Dock at Meridian Station over the colony and take on fuel.',
    reward: { credits: 80, items: [['coffee_pack', 2]] } },
  { id: 'q_vega', name: 'THE LONG HAUL', type: 'visit', target: 'vega_reach', n: 1,
    desc: 'Ride the warp to Vega Reach. The extraction platform is waiting on a survey.',
    reward: { credits: 150 } },
  { id: 'q_keth', name: 'TEETH OF THE REACH', type: 'kill', target: 'keth', n: 3,
    desc: 'Keth fighters are pressing the extraction lanes. Splash three.',
    reward: { credits: 260, items: [['fuel_cell_dense', 1]] } },
  { id: 'q_tithe', name: 'SCRAP TITHE', type: 'sell', target: null, n: 500,
    desc: 'Kestrel takes its cut. Move 500 credits of goods across any station counter.',
    reward: { credits: 200 } },
  { id: 'q_chips', name: 'COLD READING', type: 'collectCat', target: 'data', n: 2,
    desc: 'Recover two data chips from the wrecks. Someone will pay to know what they say.',
    reward: { credits: 180 } },
  { id: 'q_drift', name: 'DRIFT CENSUS', type: 'kill', target: 'drift', n: 2,
    desc: 'The Drift do not negotiate. Reduce their census by two drones.',
    reward: { credits: 300, items: [['medkit_field', 1]] } },
  { id: 'q_pale', name: 'THE PALE ROAD', type: 'visit', target: 'the_pale', n: 1,
    desc: 'Jump to the Pale. The last survey ship that went is still listed MISSING.',
    reward: { credits: 400 } },
  { id: 'q_quartermaster', name: 'QUARTERMASTER', type: 'slots', target: null, n: 20,
    desc: 'Prove the hold earns its mass. Carry twenty slots of cargo at once.',
    reward: { credits: 120 } },
  { id: 'q_record', name: 'DEEP RECORD', type: 'save', target: null, n: 3,
    desc: 'The record is the only afterlife out here. Log progress at a terminal three times.',
    reward: { credits: 90, items: [['ration_curry', 1]] } },
  // -- off-route work, opened up with the second half of the chart --------------
  { id: 'q_odessa', name: 'THE OTHER LANE', type: 'visit', target: 'odessa_chain', n: 1,
    desc: 'Kestrel wants the Odessa Chain re-surveyed before an independent claim gets there first.',
    reward: { credits: 190, items: [['coffee_pack', 1]] } },
  { id: 'q_odessa_dock', name: 'BONDED CARGO', type: 'dock', target: 'odessa_transfer', n: 1,
    desc: 'Put in at Odessa Transfer. Fuel is cheap and the paperwork is optimistic.',
    reward: { credits: 140 } },
  { id: 'q_well', name: 'WATCHING THE WELL', type: 'visit', target: 'amber_well', n: 1,
    desc: 'A red giant that already ate its inner worlds. The observation post has not filed in two rotations.',
    reward: { credits: 260 } },
  { id: 'q_thresher', name: 'SHORT EXPOSURE', type: 'visit', target: 'thresher', n: 1,
    desc: 'Get a hull into Thresher, take the readings, and get out before the dosimeter goes amber.',
    reward: { credits: 340, items: [['medkit_field', 1]] } },
  { id: 'q_harbour', name: 'BREAKING YARD', type: 'kill', target: 'drift', n: 5,
    desc: 'Cold Harbour is stacked with Drift hulls in rows. Reduce the working population by five.',
    reward: { credits: 420, items: [['fuel_cell_dense', 1]] } },
  { id: 'q_drum', name: 'KEEPING TIME', type: 'visit', target: 'the_drum', n: 1,
    desc: 'A neutron star with a structure locked to its beam. Nav sealed the file. Go look anyway.',
    reward: { credits: 500 } },
];

export class QuestSystem {
  /**
   * @param {import('../core/EventBus.js').EventBus} events
   * @param {object} deps { inventory, trading, notify(text) }
   */
  constructor(events, deps) {
    this.events = events;
    this.deps = deps;
    /** progress + done flags by quest id */
    this.state = {};
    for (const q of QUESTS) this.state[q.id] = { p: 0, done: false };

    events.on('inventory:changed', () => this._checkInventory());
    events.on('ship:docked', (id) => this._bump('dock', id));
    events.on('system:arrived', (id) => this._bump('visit', id));
    events.on('combat:kill', (type) => this._bump('kill', type));
    events.on('trade:sold', ({ total }) => this._setProgress('sell', total));
    events.on('save:ritual', () => this._bump('save', null));
  }

  _quests(type, target) {
    return QUESTS.filter((q) => q.type === type && (q.target == null || q.target === target || target == null));
  }

  _bump(type, target) {
    for (const q of QUESTS) {
      if (q.type !== type) continue;
      if (q.target != null && q.target !== target) continue;
      const s = this.state[q.id];
      if (s.done) continue;
      s.p += 1;
      if (s.p >= q.n) this._complete(q);
    }
  }

  _setProgress(type, value) {
    for (const q of QUESTS) {
      if (q.type !== type) continue;
      const s = this.state[q.id];
      if (s.done) continue;
      s.p = value;
      if (s.p >= q.n) this._complete(q);
    }
  }

  /** Inventory-shaped goals re-check from the live hold every change. */
  _checkInventory() {
    const inv = this.deps.inventory;
    for (const q of QUESTS) {
      const s = this.state[q.id];
      if (s.done) continue;
      if (q.type === 'collect') s.p = inv.count(q.target);
      else if (q.type === 'collectCat') {
        s.p = inv.grouped().filter((r) => r.def.category === q.target)
          .reduce((n, r) => n + r.qty, 0);
      } else if (q.type === 'slots') s.p = Math.floor(inv.usedSlots);
      else continue;
      if (s.p >= q.n) this._complete(q);
    }
  }

  _complete(q) {
    const s = this.state[q.id];
    s.done = true;
    s.p = q.n;
    const { trading, inventory, notify } = this.deps;
    if (q.reward.credits) trading.credits += q.reward.credits;
    const extras = [];
    for (const [id, n] of q.reward.items ?? []) {
      if (inventory.add(id, n) > 0) extras.push(ITEMS[id]?.name ?? id);
    }
    notify(`WORK ORDER COMPLETE: ${q.name} — +${q.reward.credits ?? 0} CR` +
      (extras.length ? ` + ${extras.join(', ').toUpperCase()}` : ''));
    this.events.emit('quest:complete', q.id);
  }

  /** Rows for the journal: [{quest, p, done}] — open orders first. */
  rows() {
    return QUESTS.map((q) => ({ quest: q, ...this.state[q.id] }))
      .sort((a, b) => Number(a.done) - Number(b.done));
  }

  get openCount() { return QUESTS.filter((q) => !this.state[q.id].done).length; }

  toJSON() { return this.state; }
  fromJSON(d) {
    if (!d) return;
    for (const q of QUESTS) if (d[q.id]) this.state[q.id] = { p: d[q.id].p ?? 0, done: !!d[q.id].done };
  }
}
