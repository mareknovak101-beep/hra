/**
 * FABRICATION — the workshop bench, which has said "CRAFTING SUITE OFFLINE
 * PENDING PARTS AUDIT" since Phase 2.
 *
 * Owner ask: *"add more interactive content, parts which actually do
 * something."* This is the largest prop in the game that did nothing, and it
 * is the one that most obviously should: there are four hundred and eighty
 * items in the registry, a survey ship carries a bench, and until now the only
 * thing you could do with a crate of scrap was sell it.
 *
 * WHY RECIPES ARE SHORT AND UNGLAMOROUS. Nothing here makes a better version
 * of a thing you can buy — that is a progression treadmill and this game does
 * not have one. Every recipe converts something you have too much of into
 * something you ran out of, in a place where there is no shop: scrap into hull
 * plate, ore into stock, wire into a fuse block, alcohol and cloth into a
 * dressing. The bench is what makes a full hold of junk into a reason not to
 * turn back.
 *
 * RECYCLING IS THE OTHER HALF and it is deliberately lossy. Breaking a thing
 * down returns roughly a third of what building it takes, so stripping your own
 * kit is a decision made in trouble rather than an economy to farm.
 *
 * ENGINEERING PAYS BACK HERE. The skill lowers the failure chance on the
 * awkward recipes and improves recycle yield; see gameplay/Progression.js.
 */
import { ITEMS } from '../data/ItemRegistry.js';

/**
 * @typedef {object} Recipe
 * @property {string} id
 * @property {string} name       what the bench calls the job
 * @property {string} group      the tab it lives under
 * @property {Array<[string, number]>} inputs  item id + quantity consumed
 * @property {string} out        item id produced
 * @property {number} qty        how many come out
 * @property {number} [risk]     0..1 chance of spoiling the inputs
 * @property {string} note       one line, in the voice of somebody who does this
 */

/** @type {Recipe[]} */
export const RECIPES = [
  // -- hull and ship stores ---------------------------------------------------
  {
    id: 'fab_hull_plate', name: 'Cut Hull Patch', group: 'SHIP',
    inputs: [['salvage_plating_scrap', 3], ['alloy_steel_plate', 1]],
    out: 'hull_plate', qty: 1, risk: 0.05,
    note: 'Scrap flattened, trimmed square and drilled. It is not pretty and it holds.',
  },
  {
    id: 'fab_fuse_block', name: 'Rebuild Fuse Block', group: 'SHIP',
    inputs: [['salvage_wire_spool', 2], ['comp_fuse_block', 1]],
    out: 'comp_fuse_block', qty: 2, risk: 0.08,
    note: 'Strip the burnt legs, re-tin, re-seat. Twice the block for the same box.',
  },
  {
    id: 'fab_power_cell', name: 'Repack Power Cell', group: 'SHIP',
    inputs: [['ore_lithium_refined', 1], ['salvage_wire_spool', 1]],
    out: 'power_cell', qty: 2, risk: 0.12,
    note: 'Lithium stock into a cell can. Do it slowly and do it away from the cabin.',
  },
  {
    id: 'fab_fuel_cell', name: 'Charge Fuel Cell', group: 'SHIP',
    inputs: [['gas_deuterium', 1], ['salvage_plating_scrap', 1]],
    out: 'fuel_cell_standard', qty: 2, risk: 0.1,
    note: 'The bench does the lattice; you just hold the line steady.',
  },
  {
    id: 'fab_coolant', name: 'Mix Coolant Charge', group: 'SHIP',
    inputs: [['gas_ammonia', 1], ['water_can', 1]],
    out: 'trade_coolant_bulk', qty: 1, risk: 0.06,
    note: 'Vent the compartment first. Everyone learns that once.',
  },

  // -- suit and EVA -----------------------------------------------------------
  {
    id: 'fab_suit_patch', name: 'Cut Suit Patches', group: 'SUIT',
    inputs: [['trade_fabric', 1], ['suit_seal_grease', 1]],
    out: 'suit_patch', qty: 4, risk: 0.03,
    note: 'Four squares and a tin of grease. The most useful hour you will spend.',
  },
  {
    id: 'fab_o2_canister', name: 'Fill O2 Canister', group: 'SUIT',
    inputs: [['gas_nitrogen', 1], ['spare_o2_scrubber', 1]],
    out: 'o2_canister', qty: 3, risk: 0.07,
    note: 'Scrubbed, dried and pressed into a bottle. Check the gauge twice.',
  },
  {
    id: 'fab_scrubber_cart', name: 'Repack Scrubber Cartridge', group: 'SUIT',
    inputs: [['ore_lithium_refined', 1], ['suit_co2_cartridge', 1]],
    out: 'suit_co2_cartridge', qty: 3, risk: 0.09,
    note: 'Lithium hydroxide, packed by hand. Four more hours outside per can.',
  },
  {
    id: 'fab_heater_pack', name: 'Assemble Heater Packs', group: 'SUIT',
    inputs: [['ore_iron_refined', 1], ['salvage_plating_scrap', 1]],
    out: 'suit_heater_pack', qty: 3, risk: 0.04,
    note: 'Iron filings, salt and a bag. Chemistry a child could do, and it works.',
  },

  // -- ordnance ---------------------------------------------------------------
  {
    id: 'fab_slugs', name: 'Load Slug Magazines', group: 'ORDNANCE',
    inputs: [['ore_copper_refined', 1], ['ore_tungsten_raw', 1]],
    out: 'ammo_slug', qty: 3, risk: 0.11,
    note: 'Cases from copper, cores from tungsten. Loud work, done alone.',
  },
  {
    id: 'fab_cells', name: 'Charge Arc Cells', group: 'ORDNANCE',
    inputs: [['power_cell', 2], ['elec_relay_block', 1]],
    out: 'ammo_cell', qty: 3, risk: 0.1,
    note: 'The cutter is thirsty. This is the only place out here that feeds it.',
  },
  {
    id: 'fab_frangible', name: 'Load Frangible Rounds', group: 'ORDNANCE',
    inputs: [['ammo_slug', 2], ['ore_zinc_raw', 1]],
    out: 'ammo_slug_frang', qty: 2, risk: 0.14,
    note: 'Breaks up on the panel instead of going through it. Your ship thanks you.',
  },

  // -- medical ----------------------------------------------------------------
  {
    id: 'fab_bandage', name: 'Roll Dressings', group: 'MEDICAL',
    inputs: [['trade_fabric', 1]],
    out: 'bandage', qty: 5, risk: 0.02,
    note: 'Cut, rolled, autoclaved in the galley kettle. Nobody has objected yet.',
  },
  {
    id: 'fab_burn_gel', name: 'Compound Burn Gel', group: 'MEDICAL',
    inputs: [['bio_jungle_sap', 1], ['med_eyewash', 1]],
    out: 'burn_gel', qty: 3, risk: 0.08,
    note: 'Verdane sap does most of the work. The rest is keeping it sterile.',
  },
  {
    id: 'fab_chelate', name: 'Compound Chelation Dose', group: 'MEDICAL',
    inputs: [['bio_salt_extremophile', 1], ['water_can', 1]],
    out: 'radaway_dose', qty: 2, risk: 0.16,
    note: 'The halophile culture binds the hot particles. Do not ask how it was found.',
  },
  {
    id: 'fab_stim', name: 'Compound Stim Shots', group: 'MEDICAL',
    inputs: [['bio_lichen_mat', 2], ['med_antinausea', 1]],
    out: 'stim_shot', qty: 2, risk: 0.18,
    note: 'Off the books, off the manifest, and it gets people home.',
  },

  // -- stock and refining ------------------------------------------------------
  {
    id: 'fab_smelt_iron', name: 'Smelt Iron Stock', group: 'STOCK',
    inputs: [['ore_iron_raw', 3]],
    out: 'ore_iron_refined', qty: 1, risk: 0.05,
    note: 'Three of rock into one of metal. The rest goes out with the slag.',
  },
  {
    id: 'fab_smelt_copper', name: 'Smelt Copper Stock', group: 'STOCK',
    inputs: [['ore_copper_raw', 3]],
    out: 'ore_copper_refined', qty: 1, risk: 0.05,
    note: 'Runs cooler than iron and spits more. Stand to the side.',
  },
  {
    id: 'fab_smelt_titanium', name: 'Smelt Titanium Stock', group: 'STOCK',
    inputs: [['ore_titanium_raw', 3]],
    out: 'alloy_titanium_weave', qty: 1, risk: 0.12,
    note: 'Wants an inert cover or it burns. That is what the argon is for.',
  },
  {
    id: 'fab_steel_plate', name: 'Roll Steel Plate', group: 'STOCK',
    inputs: [['ore_iron_refined', 2], ['ore_chromite_raw', 1]],
    out: 'alloy_steel_plate', qty: 2, risk: 0.07,
    note: 'Chromite in the melt is the difference between steel and rust.',
  },
  {
    id: 'fab_wire', name: 'Draw Wire Spool', group: 'STOCK',
    inputs: [['ore_copper_refined', 1]],
    out: 'salvage_wire_spool', qty: 3, risk: 0.03,
    note: 'One bar, a die plate and a long afternoon.',
  },
];

/**
 * Recycling: what a thing breaks down INTO, by subcategory. Lossy on purpose.
 *
 * WHAT IS DELIBERATELY ABSENT MATTERS AS MUCH AS WHAT IS HERE.
 *
 * `salvage` is not in this table, because scrap breaking down into scrap is a
 * loop — and with the SALVAGE bonus rounding 1 up to 2 it is a loop that PAYS,
 * which is an infinite-resource exploit rather than a feature. `ore` and
 * `mineral` are absent because rock goes in the smelter, not the shears.
 * `goods` and `bulk` are absent because trade cargo is a thing you sell: a
 * bale of woven fabric is worth more as fabric than as the two handfuls of
 * scrap that shredding it would produce, and it is an INPUT to half the
 * medical and suit recipes besides.
 *
 * `recycleYield` also refuses any mapping whose output is its own input, so a
 * future entry cannot quietly reintroduce the loop.
 */
const RECYCLE = {
  alloy: ['salvage_plating_scrap', 2],
  spares: ['salvage_wire_spool', 2],
  electronics: ['salvage_optic_bundle', 1],
  ship: ['comp_fuse_block', 1],
  fitting: ['salvage_wire_spool', 2],
  hand: ['salvage_plating_scrap', 2],
  industrial: ['salvage_plating_scrap', 3],
  pistol: ['salvage_plating_scrap', 3],
  rifle: ['salvage_plating_scrap', 4],
  // Brass and steel, not stock. Pulling a magazine down for its CASES would
  // return more refined copper than loading it consumed — the bench pays out
  // scrap instead, which nothing on the ordnance card takes as an input.
  ammo: ['salvage_plating_scrap', 1],
  suit: ['trade_fabric', 1],
};

export class Fabrication {
  /**
   * @param {object} deps
   * @param {import('./Inventory.js').Inventory} deps.inventory
   * @param {import('./Progression.js').Progression} deps.progression
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(t:string)=>void} deps.notify
   */
  constructor({ inventory, progression, events, notify }) {
    this.inv = inventory;
    this.prog = progression;
    this.events = events;
    this.notify = notify ?? (() => {});
  }

  /** Every recipe, each tagged with whether the hold can currently pay for it. */
  list() {
    return RECIPES.map((r) => ({
      ...r,
      have: r.inputs.map(([id, n]) => ({
        id, n, got: this.inv.count(id), name: ITEMS[id]?.name ?? id,
      })),
      can: r.inputs.every(([id, n]) => this.inv.count(id) >= n),
      outName: ITEMS[r.out]?.name ?? r.out,
    }));
  }

  /**
   * Run a job. Consumes the inputs FIRST — a spoiled job costs the materials,
   * which is the only thing that makes the risk figure mean anything.
   */
  craft(recipeId) {
    const r = RECIPES.find((q) => q.id === recipeId);
    if (!r) return false;
    for (const [id, n] of r.inputs) {
      if (this.inv.count(id) < n) {
        this.notify(`SHORT: ${ITEMS[id]?.name ?? id} ×${n - this.inv.count(id)}`);
        return false;
      }
    }
    for (const [id, n] of r.inputs) this.inv.remove(id, n);

    // ENGINEERING cuts the spoil chance. A practised hand does not ruin stock.
    const skill = this.prog?.bonus?.('craftRisk') ?? 1;
    const risk = (r.risk ?? 0) * skill;
    if (Math.random() < risk) {
      this.notify(`${r.name.toUpperCase()} SPOILED — THE STOCK IS GONE. TRY AGAIN.`);
      this.events?.emit('fab:spoiled', r.id);
      return false;
    }
    const added = this.inv.add(r.out, r.qty);
    if (added <= 0) {
      this.notify('HOLD FULL — THE BENCH WILL NOT START A JOB IT CANNOT LAND');
      return false;
    }
    this.prog?.award?.('engineering', 'craft');
    this.events?.emit('fab:crafted', { id: r.id, out: r.out, qty: added });
    this.notify(`${r.name.toUpperCase()} — ${added}× ${ITEMS[r.out]?.name?.toUpperCase() ?? r.out}`);
    return true;
  }

  /** What breaking this item down would return, or null if nothing will. */
  recycleYield(itemId) {
    const it = ITEMS[itemId];
    if (!it) return null;
    const rec = RECYCLE[it.subCategory];
    if (!rec) return null;
    const [out, base] = rec;
    // A thing cannot break down into itself. See the note on RECYCLE — this is
    // the guard, not the comment.
    if (out === itemId) return null;
    // SALVAGE improves the return, because that is what the skill is for.
    const mult = this.prog?.bonus?.('recycleYield') ?? 1;
    return { out, qty: Math.max(1, Math.round(base * mult)), outName: ITEMS[out]?.name ?? out };
  }

  /** Break one down. Refuses on things with nothing useful in them. */
  recycle(itemId) {
    const y = this.recycleYield(itemId);
    if (!y) {
      this.notify('NOTHING IN THAT WORTH THE TIME IT WOULD TAKE.');
      return false;
    }
    if (this.inv.count(itemId) < 1) return false;
    this.inv.remove(itemId, 1);
    const added = this.inv.add(y.out, y.qty);
    this.prog?.award?.('salvage', 'container');
    this.events?.emit('fab:recycled', { from: itemId, to: y.out, qty: added });
    this.notify(`BROKEN DOWN — ${added}× ${y.outName.toUpperCase()}`);
    return true;
  }
}
