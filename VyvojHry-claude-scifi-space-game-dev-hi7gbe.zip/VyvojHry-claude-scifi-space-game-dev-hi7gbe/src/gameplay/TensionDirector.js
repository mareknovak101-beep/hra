/**
 * TensionDirector + HollowEntity — the reason this game exists (context/04 §8,
 * context/03 §6). One rule above all: **this is never a fight.** The Hollow
 * has no health, no hitbox the laser can find, no defeat state. The loop is:
 * enter the lair → the cues escalate → hide, evade, or spend a noisemaker →
 * leave. The director is the single owner of pacing; intensity is a knob.
 *
 * The lair, until derelict boarding lands: the Aethon's own aft wing (engine
 * room / reactor / cargo hold) — but only while the ship rides the haunted
 * systems (Twin Suns, the Pale). Something came aboard with the salvage.
 */
import { RNG } from '../utils/RNG.js';
import { Settings } from '../core/Settings.js';

/**
 * Which systems arm an encounter, and the aft-wing lair zones. Deliberately a
 * SHORT list even now that the chart has ten systems: `context/04` calls for the
 * Hollow to stay rare and scripted, and arming it everywhere would turn the one
 * thing in the game that cannot be fought into ordinary weather.
 */
const HAUNTED = {
  twin_suns: 0.9, the_pale: 1.0,
  cold_harbour: 0.7, // a yard where hulls are opened patiently, one bulkhead at a time
  the_drum: 0.85, // and the system with the fifth hull design in it
};
/**
 * The two `context/04` scripts it into by name. RARE narrows the list to these;
 * everything else in HAUNTED was added later as the chart grew.
 */
const SCRIPTED = new Set(['twin_suns', 'the_pale']);
const LAIR = ['engine_room', 'reactor_room', 'cargo_hold', 'workshop', 'corr_e', 'corr_d'];

const MOVE_MIN = 5, MOVE_MAX = 9; // seconds between Hollow zone moves
const KILL_EXPOSED_S = 3.0; // same zone, not hidden, this long → death
const LINGER_S = 6; // how long it waits over a hidden player before drifting on
const LEAVE_ESCAPE_S = 8; // out of the lair this long → it lets you go

class HollowEntity {
  constructor(zoneId, rng) {
    this.zoneId = zoneId;
    this.rng = rng;
    this.moveT = rng.range(MOVE_MIN, MOVE_MAX);
    this.lingerT = 0;
    this.exposedT = 0;
  }

  /** One step of the stalk. Returns 'kill' | null. */
  update(dt, ctx) {
    const { playerZoneId, noiseLevel, hidden, zoneById } = ctx;
    const same = playerZoneId === this.zoneId;
    if (same) {
      if (hidden) {
        this.lingerT += dt;
        this.exposedT = Math.max(0, this.exposedT - dt * 0.5);
        if (this.lingerT > LINGER_S) { this._drift(zoneById, ctx); this.lingerT = 0; }
      } else {
        this.exposedT += dt;
        if (this.exposedT > KILL_EXPOSED_S) return 'kill';
      }
      return null;
    }
    this.exposedT = Math.max(0, this.exposedT - dt);
    this.moveT -= dt * (1 + noiseLevel); // noise draws it faster
    if (this.moveT <= 0) {
      this.moveT = this.rng.range(MOVE_MIN, MOVE_MAX);
      // move one zone toward the player if they're being loud or close;
      // otherwise drift inside the lair
      const loud = noiseLevel > 0.3;
      const z = zoneById.get(this.zoneId);
      const options = (z?.neighbours ?? []).filter((n) => LAIR.includes(n) || loud);
      if (!options.length) { this._drift(zoneById, ctx); return null; }
      if (loud && ctx.pathStep) {
        const step = ctx.pathStep(this.zoneId, playerZoneId);
        this.zoneId = step ?? options[this.rng.int(0, options.length - 1)];
      } else {
        this.zoneId = options[this.rng.int(0, options.length - 1)];
      }
      return 'moved';
    }
    return null;
  }

  _drift(zoneById, ctx) {
    const z = zoneById.get(this.zoneId);
    const opts = (z?.neighbours ?? []).filter((n) => LAIR.includes(n));
    if (opts.length) this.zoneId = opts[this.rng.int(0, opts.length - 1)];
  }
}

export class TensionDirector {
  /**
   * @param {object} deps { shipMap, noise, scanner, lights, audio,
   *   notify(text), die(title, sub), getPlayerZoneId() }
   */
  constructor(deps) {
    this.d = deps;
    this.rng = new RNG(0x4011);
    this.systemId = 'sol_prime';
    this.state = 'idle'; // idle | armed | active | aftermath
    this.hollow = null;
    this.escapeT = 0;
    this.cueT = 0;
    this.intensity = 0;
    this._doneThisVisit = false;
  }

  /**
   * Call on warp arrival / restore. Re-arms once per system visit.
   *
   * `CLAUDE.md` has carried an open question since session 0 — *"how often
   * should the Hollow actually appear, a once-per-system set-piece or a
   * recurring pressure?"* — and the honest answer is that it depends entirely
   * on what the player came for. So it is a setting rather than a number
   * somebody has to be right about:
   *
   *   OFF    the encounter never arms. A survey game without a monster in it
   *          is a legitimate way to play this and always was.
   *   RARE   only the two systems `context/04` scripts it into.
   *   NORMAL the authored four (default).
   *   OFTEN  every system, at the intensity of the tamest authored one.
   *
   * Nothing else changes: the entity still cannot be fought, still has no
   * health and still resolves by leaving. Frequency is the only dial.
   */
  setSystem(systemId) {
    this.systemId = systemId;
    this._doneThisVisit = false;
    this._end(true);
    const mode = Settings.get('hollow') ?? 'normal';
    let intensity = 0;
    if (mode === 'off') intensity = 0;
    else if (mode === 'often') intensity = HAUNTED[systemId] ?? 0.7;
    else if (mode === 'rare') intensity = SCRIPTED.has(systemId) ? HAUNTED[systemId] : 0;
    else intensity = HAUNTED[systemId] ?? 0;
    if (intensity > 0) { this.state = 'armed'; this.intensity = intensity; }
    else { this.state = 'idle'; this.intensity = 0; }
  }

  /**
   * Is the entity in this compartment right now?
   *
   * `PersonalCombat` asks, because it has to answer "what happens when the
   * player shoots at it" — and the answer has to be "nothing", by construction.
   * A predicate rather than a position on purpose: the Hollow has no world
   * transform and no collider anywhere in this codebase, and handing out a point
   * to raycast against would be the first step toward it having a hitbox and
   * then a health bar. It is in a ZONE, and firing in that zone is enough to
   * know a round went through it.
   */
  inZone(zoneId) {
    return this.state === 'active' && !!this.hollow && this.hollow.zoneId === zoneId;
  }

  /** A noisemaker clatters somewhere aft — it goes to look. */
  distract() {
    if (this.state !== 'active' || !this.hollow) return false;
    const far = LAIR[this.rng.int(0, LAIR.length - 1)];
    this.hollow.zoneId = far;
    this.hollow.exposedT = 0;
    this.d.notify('THE CLATTER ECHOES AFT. SOMETHING GOES TO LOOK.');
    return true;
  }

  update(dt) {
    const d = this.d;
    const playerZoneId = d.getPlayerZoneId();
    if (this.state === 'armed') {
      if (!this._doneThisVisit && playerZoneId && LAIR.includes(playerZoneId)) {
        this.state = 'active';
        this._doneThisVisit = true;
        this.hollow = new HollowEntity('reactor_room', this.rng);
        this.cueT = 0;
        d.notify('THE VENTS GO QUIET.');
        d.audio?.playDistantClank?.();
      }
      return;
    }
    if (this.state !== 'active' || !this.hollow) return;

    // escape check: out of the lair long enough and it lets you go
    if (!LAIR.includes(playerZoneId)) {
      this.escapeT += dt;
      if (this.escapeT > LEAVE_ESCAPE_S) { this._end(); return; }
    } else {
      this.escapeT = 0;
    }

    const result = this.hollow.update(dt, {
      playerZoneId,
      noiseLevel: d.noise.level,
      hidden: d.noise.hidden,
      zoneById: d.shipMap.zoneById,
      pathStep: null, // adjacency drift is enough menace; true pathing later
    });
    if (result === 'kill') {
      this._end(true);
      d.die('IT FINDS YOU IN THE DARK', 'You never see it clearly. That is the only mercy.');
      return;
    }
    if (result === 'moved') {
      // presence cues: a blip where it now is, a sound, the lights sag
      const z = d.shipMap.zoneById.get(this.hollow.zoneId);
      if (z?.rect) {
        d.scanner.blips.push({ x: (z.rect.x0 + z.rect.x1) / 2, z: (z.rect.z0 + z.rect.z1) / 2, age: 0 });
      }
      d.audio?.playDistantClank?.();
    }

    // continuous cues scale with proximity (zone distance approximated by
    // same/adjacent/far) — scanner static is the information you lose
    const z = d.shipMap.zoneById.get(playerZoneId);
    const near = playerZoneId === this.hollow.zoneId ? 1
      : z?.neighbours?.includes(this.hollow.zoneId) ? 0.6 : 0.25;
    d.scanner.staticLevel = near * this.intensity;
    d.lights.setDamageLevel(Math.min(0.85, near * 0.9 * this.intensity));
    this.cueT += dt;
    /**
     * THE STING, and the only place in the codebase allowed to fire it.
     *
     * `context/06` §3 is explicit that this must stay rare enough to be a
     * signal rather than wallpaper, so it is gated three ways: only in the same
     * or an adjacent compartment, only above half intensity, and never more
     * often than every eleven seconds. In the far case it never plays at all,
     * which is what makes it mean something when it does.
     */
    if (near >= 0.6 && this.intensity > 0.5 && this.cueT > 11) {
      this.cueT = 0;
      d.audio?.playHeartbeatSting?.();
    }
  }

  _end(silent = false) {
    if (this.state === 'active' && !silent) this.d.notify('THE SHIP BREATHES AGAIN. WHATEVER IT WAS, IT LET YOU GO.');
    // Re-arming has to read the same gate `setSystem` does, or turning the
    // encounter OFF mid-visit would leave it armed for the rest of the system.
    const mode = Settings.get('hollow') ?? 'normal';
    const canArm = mode !== 'off' && (mode === 'often'
      ? true : mode === 'rare' ? SCRIPTED.has(this.systemId) : !!HAUNTED[this.systemId]);
    this.state = this.hollow && canArm && !this._doneThisVisit ? 'armed' : 'aftermath';
    this.hollow = null;
    this.d.scanner.staticLevel = 0;
    this.d.lights.setDamageLevel(0);
  }
}
