/**
 * Inventory — 120 volume-slots, weight-tracked, stacking (context/04 §3).
 * Stored as stacks: [{ id, qty }]. Volume: sum(def.volume × qty) against
 * CAPACITY_SLOTS; weight is informational (encumbrance lands with Phase 6).
 */
import { ITEMS } from '../data/ItemRegistry.js';

export const CAPACITY_SLOTS = 120;

export class Inventory {
  /** @param {import('../core/EventBus.js').EventBus} [events] */
  constructor(events = null) {
    this.events = events;
    /** @type {Array<{id:string, qty:number}>} */
    this.stacks = [];
    /**
     * Volume this HULL can hold. `CAPACITY_SLOTS` is the survey cutter's figure
     * and stays the default; a class overrides it at commission (see
     * ShipClasses.applyShipClass), which is what makes a courier's hold a real
     * constraint and a hauler's the reason to fly one.
     */
    this.capacitySlots = CAPACITY_SLOTS;
  }

  /** Total occupied volume in slots. */
  get usedSlots() {
    let v = 0;
    for (const s of this.stacks) v += (ITEMS[s.id]?.volume ?? 0.5) * s.qty;
    return v;
  }

  /** Total carried weight in kg. */
  get weightKg() {
    let w = 0;
    for (const s of this.stacks) w += (ITEMS[s.id]?.weight ?? 1) * s.qty;
    return w;
  }

  count(id) {
    let n = 0;
    for (const s of this.stacks) if (s.id === id) n += s.qty;
    return n;
  }

  /**
   * Add qty of an item, splitting across stacks per maxStack. Returns the
   * quantity actually added (0 if the hold is full).
   */
  add(id, qty = 1) {
    const def = ITEMS[id];
    if (!def) return 0;
    let added = 0;
    while (qty > 0) {
      if (this.usedSlots + def.volume > this.capacitySlots) break; // hold full
      let stack = def.stackable
        ? this.stacks.find((s) => s.id === id && s.qty < (def.maxStack ?? 10))
        : null;
      if (!stack) { stack = { id, qty: 0 }; this.stacks.push(stack); }
      stack.qty += 1; qty -= 1; added += 1;
    }
    if (added && this.events) this.events.emit('inventory:changed', { id, delta: added });
    return added;
  }

  /** Remove up to qty of an item; returns the quantity actually removed. */
  remove(id, qty = 1) {
    let removed = 0;
    for (let i = this.stacks.length - 1; i >= 0 && qty > 0; i--) {
      const s = this.stacks[i];
      if (s.id !== id) continue;
      const take = Math.min(s.qty, qty);
      s.qty -= take; qty -= take; removed += take;
      if (s.qty === 0) this.stacks.splice(i, 1);
    }
    if (removed && this.events) this.events.emit('inventory:changed', { id, delta: -removed });
    return removed;
  }

  /** Stacks grouped for the UI: [{id, def, qty}] sorted by category then name. */
  grouped() {
    const byId = new Map();
    for (const s of this.stacks) byId.set(s.id, (byId.get(s.id) ?? 0) + s.qty);
    const rows = [...byId.entries()].map(([id, qty]) => ({ id, qty, def: ITEMS[id] }));
    rows.sort((a, b) => (a.def.category + a.def.name).localeCompare(b.def.category + b.def.name));
    return rows;
  }

  /** Serialize for the save file. */
  toJSON() { return this.stacks.map((s) => ({ id: s.id, qty: s.qty })); }

  /** Restore from a save file. */
  fromJSON(data) {
    this.stacks = [];
    for (const s of data ?? []) if (ITEMS[s.id] && s.qty > 0) this.stacks.push({ id: s.id, qty: s.qty });
  }
}
