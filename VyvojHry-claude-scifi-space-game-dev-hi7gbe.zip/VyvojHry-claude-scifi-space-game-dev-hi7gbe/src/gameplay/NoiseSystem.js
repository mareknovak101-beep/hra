/**
 * NoiseSystem — how loud the player is right now (context/04 §6). Footsteps
 * pulse the level by movement state (crouch < walk < sprint) and surface;
 * doors cycling nearby add their own spike. The level decays fast, so silence
 * is always a choice away. `hidden` is the general stealth read the Phase 6
 * AI (Keth patrols, Drift drones, the Hollow) will consume — built as a
 * general system, not a one-off.
 */

const SURFACE_GAIN = { grate: 1.25, plate: 1.0, hazard: 1.0, cargo: 1.1, default: 1.0 };

export class NoiseSystem {
  /**
   * @param {import('../core/EventBus.js').EventBus} events
   * @param {import('../player/Player.js').Player} player
   */
  constructor(events, player) {
    this.player = player;
    this.level = 0; // 0 silent .. 1 loud
    events.on('player:step', ({ surface, sprint, crouch }) => {
      const base = sprint ? 0.95 : crouch ? 0.2 : 0.5;
      const gain = SURFACE_GAIN[surface] ?? SURFACE_GAIN.default;
      this.level = Math.min(1, Math.max(this.level, base * gain));
    });
    events.on('door:toggle', () => {
      this.level = Math.min(1, this.level + 0.35); // hydraulics carry
    });
    // A gunshot is the loudest thing that happens on this ship. A sprint pins
    // the meter at 0.95 and decays from there; a discharge sets it outright and
    // the arc cutter is the only hand weapon quiet enough to be a choice. This
    // is the whole trade of arming the player: the weapon works, and using it
    // tells everything aboard exactly where you are.
    events.on('weapon:fire', ({ level }) => {
      this.level = Math.min(1, Math.max(this.level, level ?? 1));
    });
    events.on('weapon:dryFire', () => {
      this.level = Math.min(1, this.level + 0.18); // a click still carries
    });
  }

  update(dt) {
    this.level = Math.max(0, this.level - dt * 0.7);
  }

  /** Quiet and small: crouched with the noise floor settled. */
  get hidden() {
    return !!this.player.controller?.crouched && this.level < 0.15;
  }
}
