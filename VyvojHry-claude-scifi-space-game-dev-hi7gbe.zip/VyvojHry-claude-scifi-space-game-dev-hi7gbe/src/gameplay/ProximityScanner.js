/**
 * ProximityScanner — the handheld motion sweep (context/04 §5). Raised with
 * TAB (hold-to-look-down is the cost: movement slows and the device fills the
 * lower half of the view). A radial CRT pings on a fixed interval; anything
 * that MOVES aboard — doors cycling, later the Hollow — leaves a fading blip.
 * Terminal-phosphor green is allowed here: this is a diegetic screen, not the
 * HUD. Battery-limited; any powered console tops it back up.
 */
import { PALETTE } from '../core/Constants.js';
import { hexToRgbf } from '../utils/ColorUtils.js';
import { FONT_FACES } from '../rendering/PixelFont.js';

const PING_INTERVAL = 1.6; // seconds between sweeps (fixed — not continuous)
const RANGE = 16; // metres of corridor the sweep covers
const DRAIN = 0.9; // %/s while raised

export class ProximityScanner {
  /**
   * @param {import('../core/EventBus.js').EventBus} events
   * @param {import('../core/AudioEngine.js').AudioEngine} [audio] the sweep has
   *   a sound, and near the Hollow it is the first thing that goes wrong
   */
  constructor(events, audio = null) {
    this.audio = audio;
    this.raised = false;
    this.battery = 100;
    this.sweep = 0; // 0..1 sweep phase
    /** 0..1 — near the Hollow the display degrades to static (context/03 §6) */
    this.staticLevel = 0;
    /** @type {Array<{x:number,z:number,age:number}>} world-space movement pings */
    this.blips = [];
    this._flicker = 0;
    // door movement is the one thing that moves aboard (until the Hollow)
    events.on('door:toggle', ({ door }) => {
      this.blips.push({ x: door.cx, z: door.cz, age: 0 });
    });
    this._phos = hexToRgbf(PALETTE.PHOSPHOR_TEXT[0]);
    this._phosMid = hexToRgbf(PALETTE.PHOSPHOR_MID[1]);
    this._phosBg = hexToRgbf(PALETTE.PHOSPHOR_BG[1]);
    this._steel = hexToRgbf(PALETTE.PANEL_STEEL[1]);
    this._steelHi = hexToRgbf(PALETTE.PANEL_STEEL[2]);
    this._dark = hexToRgbf(PALETTE.SHADOW_BLACK[0]);
  }

  toggle() {
    if (!this.raised && this.battery <= 1) return false; // dead cell
    this.raised = !this.raised;
    return true;
  }

  charge() {
    const was = this.battery;
    this.battery = 100;
    return was < 99; // true if it actually needed the top-up
  }

  update(dt) {
    for (let i = this.blips.length - 1; i >= 0; i--) {
      this.blips[i].age += dt;
      if (this.blips[i].age > 6) this.blips.splice(i, 1);
    }
    if (!this.raised) return;
    this.battery = Math.max(0, this.battery - DRAIN * dt);
    if (this.battery <= 0) this.raised = false; // dies in your hand
    const was = this.sweep;
    this.sweep = (this.sweep + dt / PING_INTERVAL) % 1;
    // ONE BLIP PER REVOLUTION, at the instant the arm crosses the top. Firing
    // it on a timer instead would drift out of phase with the arm you are
    // watching, and a ping that does not line up with the sweep reads as a
    // second, broken device.
    if (this.sweep < was) {
      // `staticLevel` is what the Hollow does to this device; the ping carries
      // the same figure into the channel the player is actually listening to.
      this.audio?.playScannerPing?.(this.staticLevel ?? 0);
    }
    this._flicker = Math.random();
  }

  /**
   * Draw the raised device onto the 2D layer (call inside begin2D, after the
   * HUD). Player pose orients the display: up = the way you face.
   */
  draw(pix, font, fontTexture, W, H, player) {
    if (!this.raised) return;
    pix.setTexture(fontTexture); // rects sample the atlas' white texel
    const dw = 128, dh = 92;
    const dx = Math.round((W - dw) / 2), dy = H - dh - 2;
    const st = this._steel, hi = this._steelHi, dark = this._dark;
    // device shell — worn steel slab with a grip notch, top edge highlighted
    pix.rect(dx, dy, dw, dh, [st[0] * 0.55, st[1] * 0.55, st[2] * 0.55, 1]);
    pix.rect(dx, dy, dw, 2, [hi[0], hi[1], hi[2], 1]);
    pix.rect(dx, dy, 2, dh, [hi[0] * 0.8, hi[1] * 0.8, hi[2] * 0.8, 1]);
    pix.rect(dx + dw - 2, dy, 2, dh, [dark[0], dark[1], dark[2], 1]);
    // CRT well
    const cx = dx + dw / 2, cy = dy + dh / 2 + 4, r = 36;
    for (let yy = -r; yy <= r; yy++) {
      const half = Math.floor(Math.sqrt(r * r - yy * yy));
      pix.rect(cx - half, cy + yy, half * 2, 1, [this._phosBg[0], this._phosBg[1], this._phosBg[2], 1]);
    }
    // range rings — dim phosphor
    for (const rr of [12, 24, 35]) {
      for (let a = 0; a < 64; a++) {
        const th = (a / 64) * Math.PI * 2;
        pix.rect(Math.round(cx + Math.cos(th) * rr), Math.round(cy + Math.sin(th) * rr), 1, 1,
          [this._phosMid[0], this._phosMid[1], this._phosMid[2], 0.35]);
      }
    }
    // the sweep arm
    const sa = this.sweep * Math.PI * 2 - Math.PI / 2;
    for (let d = 2; d < r - 1; d++) {
      pix.rect(Math.round(cx + Math.cos(sa) * d), Math.round(cy + Math.sin(sa) * d), 1, 1,
        [this._phos[0], this._phos[1], this._phos[2], 0.8]);
    }
    // near the Hollow the tube drowns in static — you lose the read exactly
    // when you want it most (diegetic, not a difficulty fudge)
    if (this.staticLevel > 0.05) {
      const nStatic = Math.round(this.staticLevel * 110);
      for (let i = 0; i < nStatic; i++) {
        const th = Math.random() * Math.PI * 2;
        const rr = Math.sqrt(Math.random()) * (r - 2);
        pix.rect(Math.round(cx + Math.cos(th) * rr), Math.round(cy + Math.sin(th) * rr), 1, 1,
          [this._phos[0], this._phos[1], this._phos[2], 0.25 + Math.random() * 0.5]);
      }
      if (this.staticLevel > 0.5) {
        pix.text(font, FONT_FACES.TERM7, cx - 24, cy - 3, 'SIGNAL??',
          [this._phos[0], this._phos[1], this._phos[2], 0.5 + Math.random() * 0.4]);
        return; // blips unreadable — the static wins
      }
    }
    // blips — world offsets rotated into device space (up = facing)
    const yaw = player.camera.yaw;
    const sy = Math.sin(yaw), cyw = Math.cos(yaw);
    for (const b of this.blips) {
      const ox = b.x - player.position[0], oz = b.z - player.position[2];
      const fwd = ox * -sy + oz * -cyw; // how far ahead
      const side = ox * cyw + oz * -sy; // how far right
      const dist = Math.hypot(ox, oz);
      if (dist > RANGE) continue;
      const px = cx + (side / RANGE) * (r - 4);
      const py = cy - (fwd / RANGE) * (r - 4);
      const fade = Math.max(0, 1 - b.age / 6);
      pix.rect(Math.round(px) - 1, Math.round(py) - 1, 2, 2,
        [this._phos[0], this._phos[1], this._phos[2], 0.4 + 0.6 * fade]);
    }
    // CRT noise — a few random phosphor specks each frame
    for (let i = 0; i < 6; i++) {
      const th = this._flicker * 971 + i * 2.39996;
      const rr2 = ((this._flicker * 7919 + i * 131) % 1) * (r - 3);
      pix.rect(Math.round(cx + Math.cos(th) * rr2), Math.round(cy + Math.sin(th) * rr2), 1, 1,
        [this._phos[0], this._phos[1], this._phos[2], 0.18]);
    }
    // bezel labels + battery (device screen text stays phosphor — diegetic)
    pix.text(font, FONT_FACES.TERM7, dx + 6, dy + 4, 'PROX SWEEP',
      [this._phos[0], this._phos[1], this._phos[2], 0.9]);
    pix.text(font, FONT_FACES.TERM7, dx + dw - 34, dy + 4, `${Math.round(this.battery)}%`,
      [this._phosMid[0], this._phosMid[1], this._phosMid[2], 0.9]);
  }
}
