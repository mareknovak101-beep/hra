/**
 * DIALOGUE — the last unchecked line in Phase 7, and the reason the station
 * crew exist.
 *
 * WHAT A CONVERSATION IS FOR HERE. Not a story delivery mechanism and not a
 * quest board with a face on it. Everything on this deck is already reachable
 * by walking up to a machine; what a person adds is the one thing a machine
 * cannot give you, which is *what they have heard*. So the topics are all
 * information asymmetries: the harbour officer knows which bodies in this
 * system are worth a look, the chandler knows what this counter is paying over
 * and under, the armourer knows what your own hull is short of, the dockhand
 * knows what came in on the last shift and did not leave.
 *
 * NOTHING HERE IS A DIALOGUE TREE. A branching tree is a writing project and a
 * save-format problem; what this is instead is a flat list of topics per
 * archetype, each of which produces a line generated from LIVE STATE — the
 * system you are actually in, the hold you are actually carrying, the standing
 * you have actually earned. A topic that reads the world is worth ten that
 * read a script, because it stays true after the world moves.
 *
 * ONCE-ONLY TOPICS are marked and tracked per station, so a favour asked is a
 * favour spent and you have a reason to talk to the officer on the NEXT
 * station rather than farming this one.
 *
 * NAMES are generated per station id, so the chandler at Meridian is a
 * specific person who is still there when you come back, and is not the same
 * person as the chandler at Halvane.
 */
import { RNG } from '../utils/RNG.js';
import { ITEMS } from '../data/ItemRegistry.js';
import { QUESTS } from './QuestSystem.js';

/** FNV-1a — RNG takes a uint32 and station ids are text. */
function hash(s) {
  let h = 0x811c9dc5;
  const t = String(s);
  for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}

const SURNAMES = [
  'ADEYEMI', 'BRAUN', 'CALLOW', 'DRESK', 'ESPOSITO', 'FANNING', 'GRIEVE',
  'HALLORAN', 'IWATA', 'JAROSZ', 'KEMBLE', 'LINDQVIST', 'MARCH', 'NAVARRO',
  'OYELARAN', 'PETRAKIS', 'QUAYE', 'ROSTOVA', 'SANDOVAL', 'TREHERNE',
  'UDALL', 'VOSKUIL', 'WHELAN', 'YARDLEY', 'ZANETTI',
];
const INITIALS = 'ABCDEHJKLMNORSTVW';

/** A stable person for this post on this station. */
export function crewName(stationId, kind) {
  const r = new RNG(hash(`${stationId}:${kind}`));
  const s = SURNAMES[r.int(0, SURNAMES.length - 1)];
  const i = INITIALS[r.int(0, INITIALS.length - 1)];
  return `${s}, ${i}.`;
}

/**
 * The topic table.
 *
 * Each topic: `{ id, label, once?, line(ctx) -> string, effect?(ctx) }`.
 * `ctx` carries { station, system, inventory, trading, systems, factions,
 * quests, progression, stations, notify, unlockLore, name }.
 *
 * A `line` may return several sentences; the panel wraps them. Keep them in
 * the voice of somebody doing a job they are tired of.
 */
const T = {
  // -- shared ---------------------------------------------------------------
  greet: {
    id: 'greet', label: 'PASS THE TIME',
    line: (c) => {
      const t = c.factions?.tier?.('kestrel')?.name ?? '';
      if (t === 'HOSTILE' || t === 'WARY') {
        return 'You are on a list. I am not going to tell you which one, and I '
          + 'am not going to say anything else either.';
      }
      return `Shift's half done and the recyclers are on the blink again. `
        + `You're off ${c.system?.def?.name ?? 'somewhere'}, then. Long way from a real dock.`;
    },
  },

  // -- harbour officer / customs: the system ---------------------------------
  bodies: {
    id: 'bodies', label: 'WHAT IS WORTH A LOOK OUT THERE',
    line: (c) => {
      const bodies = (c.system?.bodies ?? []).filter((b) => b.type !== 'star');
      if (!bodies.length) return 'Nothing on the chart but the star and us. Enjoy the quiet.';
      const r = new RNG(hash(`${c.station?.id}:bodies`));
      const pick = bodies[r.int(0, bodies.length - 1)];
      const alt = bodies[r.int(0, bodies.length - 1)];
      return `${(pick.name ?? 'the inner body').toUpperCase()} is where the survey `
        + `office keeps sending people. ${pick === alt ? 'That is the whole list.'
          : `Nobody comes back off ${(alt.name ?? 'the far one').toUpperCase()} with anything but dust, whatever the assay says.`}`;
    },
  },
  lanes: {
    id: 'lanes', label: 'WHO IS MOVING IN THIS SYSTEM',
    line: (c) => {
      const f = c.factions;
      if (!f) return 'Traffic is traffic. I stopped counting.';
      const rows = f.rows?.() ?? [];
      const worst = rows.slice().sort((a, b) => (a.value ?? 0) - (b.value ?? 0))[0];
      const best = rows.slice().sort((a, b) => (b.value ?? 0) - (a.value ?? 0))[0];
      return `${(best?.faction?.name ?? 'KESTREL').toUpperCase()} will still take your call. `
        + `${(worst?.faction?.name ?? 'THE KETH').toUpperCase()} will not, and they have hulls in this system. `
        + 'Fly the long way round or do not, it is your plating.';
    },
  },
  writ: {
    id: 'writ', label: 'ASK ABOUT THE PAPERWORK', once: true,
    line: () => 'Berth fee is waived if you sign the salvage indemnity. Everybody signs it. '
      + 'Nobody reads it. Here — I have marked the clause that matters.',
    effect: (c) => {
      c.factions?.grant?.({ kestrel: 4 });
      c.notify('KESTREL STANDING +4 — INDEMNITY FILED');
    },
  },

  // -- chandler: the counter --------------------------------------------------
  prices: {
    id: 'prices', label: 'WHAT IS THIS COUNTER PAYING',
    line: (c) => {
      const mod = c.factions?.priceModifier?.(c.station) ?? 1;
      const pct = Math.round((mod - 1) * 100);
      const bias = pct > 4 ? `We are ${pct}% over the book because somebody upstairs likes you.`
        : pct < -4 ? `We are ${-pct}% under the book. That is what your reputation costs you here.`
          : 'We are on the book, near enough. Nobody is doing anybody a favour.';
      return `${bias} Bring me refined stock and bring it clean — I will not take ore with the rock still on it.`;
    },
  },
  hold: {
    id: 'hold', label: 'LOOK OVER MY HOLD',
    line: (c) => {
      const rows = c.inventory?.grouped?.() ?? [];
      if (!rows.length) return 'You are carrying nothing at all. That is either discipline or a bad month.';
      const best = rows.slice().sort((a, b) => (b.def.value * b.qty) - (a.def.value * a.qty))[0];
      const junk = rows.slice().sort((a, b) => (a.def.value * a.qty) - (b.def.value * b.qty))[0];
      return `The ${best.def.name.toLowerCase()} is the only thing aboard worth the shelf `
        + `— ${best.def.value * best.qty} credits if you are patient. `
        + `The ${junk.def.name.toLowerCase()} you may as well put through a bench.`;
    },
  },
  provisions: {
    id: 'provisions', label: 'A WORD ABOUT PROVISIONS', once: true,
    line: () => 'You have the look of somebody who eats out of the same dispenser every day. '
      + 'Take these. They are past the date and they are better than what you have.',
    effect: (c) => {
      const got = (c.inventory?.add?.('ration_curry', 2) ?? 0) + (c.inventory?.add?.('coffee_pack', 1) ?? 0);
      c.notify(got > 0 ? 'CURRY PACK ×2, COFFEE PACK ×1' : 'HOLD FULL — THEY PUT THEM BACK');
    },
  },

  // -- armourer: your ship ----------------------------------------------------
  shipShort: {
    id: 'shipShort', label: 'WHAT IS MY HULL SHORT OF',
    line: (c) => {
      const s = c.systems;
      if (!s) return 'Bring the hull in and I will tell you.';
      const lows = [
        ['plating', s.hull], ['deflector', s.shield], ['sublight fuel', s.fuel],
        ['reactor output', s.power], ['warp condensate', s.warpFuel],
      ].sort((a, b) => a[1] - b[1]);
      const [what, val] = lows[0];
      if (val > 88) return 'Your hull is in better order than most of what berths here. Do not get comfortable.';
      return `Your ${what} is at ${Math.round(val)}%. `
        + `That is the number that will kill you, not the one you are watching.`;
    },
  },
  ammo: {
    id: 'ammo', label: 'ASK ABOUT LOADS',
    line: (c) => {
      const slug = c.inventory?.count?.('ammo_slug') ?? 0;
      const cell = c.inventory?.count?.('ammo_cell') ?? 0;
      return `You are carrying ${slug} slug and ${cell} cell. `
        + (slug + cell < 4
          ? 'That is not a load-out, that is a souvenir. Load up before you go anywhere quiet.'
          : 'Load frangible for close work inside a hull. Solid will go through the bulkhead and then through you.');
    },
  },
  bench: {
    id: 'bench', label: 'ASK TO USE THE BENCH',
    line: () => 'Rig is yours for an hour. Do not weld anything to my rig.',
    effect: (c) => c.openFabricator?.(),
  },

  // -- broker: hulls ----------------------------------------------------------
  hulls: {
    id: 'hulls', label: 'TALK HULLS',
    line: (c) => {
      const cr = c.trading?.credits ?? 0;
      if (cr < 4000) {
        return `With ${cr} credits you are not buying a hull, you are buying a conversation. `
          + 'Come back when the number has another digit in it and I will show you the yard.';
      }
      return `${cr} credits is a real number. The Drayman takes a beating nothing else on the `
        + 'register survives, and it flies like a warehouse. Decide which of those you care about.';
    },
  },

  // -- dockhand: the deck -----------------------------------------------------
  gossip: {
    id: 'gossip', label: 'WHAT CAME IN THIS SHIFT',
    line: (c) => {
      const r = new RNG(hash(`${c.station?.id}:gossip`));
      const lines = [
        'A cutter came in on one engine and left on none. It is still on pad four. Nobody has claimed it.',
        'Bonded transfer took a sealed pallet off a hull with no registry on it. Customs signed for it anyway.',
        'Somebody in the transit bunks has been talking in their sleep about a derelict off the third body. '
          + 'Same three words, every night.',
        'Two crews went out to the same wreck last month. One crew came back and would not say which one they were.',
        'The recyclers keep flagging organic mass in the return line off the aft passage. There is nothing in the '
          + 'aft passage.',
      ];
      return lines[r.int(0, lines.length - 1)];
    },
  },
  work: {
    id: 'work', label: 'IS THERE WORK GOING',
    line: (c) => {
      const st = c.quests?.state ?? {};
      const open = QUESTS.filter((q) => !st[q.id]?.done);
      if (!open.length) return 'You have cleared the board. That has not happened before.';
      const r = new RNG(hash(`${c.station?.id}:work`));
      const q = open[r.int(0, open.length - 1)];
      const prog = st[q.id]?.p ?? 0;
      const items = (q.reward?.items ?? []).map(([id, n]) => `${n}× ${ITEMS[id]?.name ?? id}`).join(', ');
      return `${q.name}: ${q.desc} Pays ${q.reward?.credits ?? 0} credits`
        + `${items ? ` and ${items}` : ''}. You are ${prog} of ${q.n} on it. It is in your journal.`;
    },
  },

  // -- medic ------------------------------------------------------------------
  health: {
    id: 'health', label: 'ASK FOR A LOOK OVER',
    line: (c) => {
      const s = c.systems;
      const bits = [];
      if ((s?.health ?? 100) < 70) bits.push('you are carrying an injury you have stopped noticing');
      if ((s?.radiation ?? 0) > 25) bits.push('your count is high enough that I have to write it down');
      if ((s?.fatigue ?? 100) < 40) bits.push('you have not slept properly in weeks');
      if (!bits.length) return 'You are in better shape than anybody who berths here. Go away.';
      return `Three seconds with a reader and I can tell you ${bits.join(', and ')}. `
        + 'The clinic bed is through there. It is not free and it is not slow.';
    },
  },
  dose: {
    id: 'dose', label: 'ASK FOR SOMETHING FOR THE ROAD', once: true,
    line: () => 'Off the books, and if anybody asks, you found it. Take water with the chelation, '
      + 'not after — nobody tells anybody that and it is the only part that matters.',
    effect: (c) => {
      const got = (c.inventory?.add?.('radaway_dose', 1) ?? 0) + (c.inventory?.add?.('bandage', 3) ?? 0);
      c.notify(got > 0 ? 'CHELATION DOSE ×1, STERILE BANDAGE ×3' : 'HOLD FULL — THEY KEEP THEM');
    },
  },
  restock: {
    id: 'restock', label: 'BUY A DISPENSARY REFILL',
    line: (c) => {
      const cost = 240;
      if ((c.trading?.credits ?? 0) < cost) return `Two hundred and forty for a full tray. You do not have it.`;
      if ((c.stations?.medDoses ?? 0) >= 8) return 'Your tray is full. I am not selling you shelf space.';
      return 'Eight doses, sealed, signed for. Your bed will run on them and you will not think about it again.';
    },
    effect: (c) => {
      const cost = 240;
      if ((c.trading?.credits ?? 0) < cost || (c.stations?.medDoses ?? 0) >= 8) return;
      c.trading.credits -= cost;
      c.stations.medDoses = 8;
      c.notify('DISPENSARY RESTOCKED — 8 DOSES, 240 CR');
    },
  },
};

/** Which topics each archetype offers, in the order they are shown. */
export const CREW_TOPICS = {
  chandler: [T.prices, T.hold, T.provisions, T.greet],
  armourer: [T.shipShort, T.ammo, T.bench, T.greet],
  broker: [T.hulls, T.lanes, T.greet],
  dockhand: [T.gossip, T.work, T.greet],
  medic: [T.health, T.restock, T.dose, T.greet],
  officer: [T.bodies, T.lanes, T.writ, T.greet],
};

export class Dialogue {
  /** @param {object} deps everything a topic's `ctx` needs */
  constructor(deps) {
    this.deps = deps;
    /** `${stationId}:${kind}:${topicId}` for every once-only topic already spent */
    this.spent = new Set();
  }

  /** The live context a topic reads. Rebuilt per call so nothing goes stale. */
  _ctx(station) {
    return { ...this.deps, station, system: this.deps.system?.() ?? null };
  }

  /** Topics this person will talk about right now, spent ones removed. */
  topics(station, kind) {
    const list = CREW_TOPICS[kind] ?? [];
    return list.filter((t) => !(t.once && this.spent.has(`${station?.id}:${kind}:${t.id}`)));
  }

  /** Ask one. Returns the line; runs the effect exactly once for `once` topics. */
  ask(station, kind, topicId) {
    const t = (CREW_TOPICS[kind] ?? []).find((q) => q.id === topicId);
    if (!t) return null;
    const key = `${station?.id}:${kind}:${t.id}`;
    if (t.once && this.spent.has(key)) return null;
    const ctx = this._ctx(station);
    const line = t.line(ctx);
    if (t.once) this.spent.add(key);
    t.effect?.(ctx);
    return line;
  }

  toJSON() { return [...this.spent]; }
  fromJSON(d) { this.spent = new Set(d ?? []); }
}
