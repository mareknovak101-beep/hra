/**
 * SHIP STATIONS — the fittings aboard your own hull that do work.
 *
 * Owner ask: *"add more interactive content, parts which actually do
 * something."* Half the props on the Aethon printed one good line of flavour
 * and then nothing, which is fine for a wall stencil and wrong for a galley
 * dispenser. This module is the behaviour behind the four fittings a crew
 * would actually use daily, kept out of the room-dressing files so the rooms
 * stay a set list and the rules live in one place.
 *
 * EVERY ONE OF THEM DRAWS ON A FINITE STORE. That is the whole design. A
 * dispenser that hands out infinite rations deletes hunger from the game; a
 * dispenser with two hundred and twelve ration units in it and a counter that
 * goes down turns the galley into a reason to come home, and eventually into a
 * reason not to. The stores replenish only where it is physically honest:
 * water is reclaimed from the ship's own loop and comes back slowly, food and
 * medical supplies do not come back at all and must be bought or found.
 *
 * The bunk, the save terminal and the repair panel already worked; those stay
 * where they are. This adds:
 *   - GALLEY DISPENSER  — draws a meal from ship stores
 *   - WATER RECLAIMER   — fills a canister from the loop, on a slow refill
 *   - MED BED           — treats wounds and radiation from the ship's dispensary
 *   - ASSAY BENCH       — works a sample down to an appraisal and a price
 */
import { ITEMS } from '../data/ItemRegistry.js';

/** What the galley dispenser can serve, roughly in the order it runs out. */
const GALLEY_MENU = [
  'ration_protein', 'ration_grain', 'ration_noodle', 'ration_bar',
  'ration_stew', 'ration_curry', 'ration_fish', 'ration_fruit',
];
/** What the reclaimer bottles. Pouches are cheap; a canister costs more loop. */
const WATER_OUT = ['water_pouch', 'water_can'];

/** Subcategories the assay bench can put a number on. */
const ASSAYABLE = new Set(['biological', 'mineral', 'crystal', 'ancient', 'ore']);

export class ShipStations {
  /**
   * @param {object} deps
   * @param {import('../ship/ShipSystems.js').ShipSystems} deps.systems
   * @param {import('./Inventory.js').Inventory} deps.inventory
   * @param {import('./TradingSystem.js').TradingSystem} deps.trading
   * @param {import('./Progression.js').Progression} deps.progression
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(t:string)=>void} deps.notify
   */
  constructor({ systems, inventory, trading, progression, events, notify }) {
    this.systems = systems;
    this.inv = inventory;
    this.trading = trading;
    this.prog = progression;
    this.events = events;
    this.notify = notify ?? (() => {});

    /**
     * SHIP STORES. The ration figure is the one the galley rack has printed on
     * it since Phase 2 — the prop said 212 and now it means 212.
     */
    this.rations = 212;
    /** Reclaimed water, percent of the loop's holding tank. */
    this.water = 100;
    /** Dispensary doses. Six people's worth for a voyage, and you are one. */
    this.medDoses = 8;
    /** Seconds until the med bed will run another course. */
    this.medCool = 0;
    /** Consecutive assays, so the bench's patter does not repeat forever. */
    this.assays = 0;
  }

  /**
   * The loop reclaims. Deliberately slow — a full tank takes twelve minutes at
   * full power and a canister costs a quarter of it, so a canister is about
   * three minutes of standing around and slower still on a starved reactor.
   * Filling up before a long walk is something you plan, not something you spam.
   */
  update(dt) {
    const powered = (this.systems?.power ?? 0) > 8;
    if (powered) this.water = Math.min(100, this.water + dt * (0.14 * (this.systems.power / 100)));
    this.medCool = Math.max(0, this.medCool - dt);
  }

  /** Shared power gate. Every fitting aboard runs off the same reactor. */
  _powered(name, need = 6) {
    if ((this.systems?.power ?? 0) >= need) return true;
    this.notify(`${name}: NO BUS POWER. THE REACTOR IS THE PROBLEM, NOT THE PANEL.`);
    return false;
  }

  // -- galley ------------------------------------------------------------------

  /** Serve one meal out of ship stores into the hold. */
  dispenseMeal() {
    if (!this._powered('DISPENSER')) return false;
    if (this.rations <= 0) {
      this.notify('DISPENSER: STORES EMPTY. THE HATCH OPENS ON BARE RACK.');
      return false;
    }
    // Deeper into the stores means further down the menu — the good flavours
    // really do go first, which is what the prop has been claiming all along.
    const depth = 1 - this.rations / 212;
    const i = Math.min(GALLEY_MENU.length - 1,
      Math.floor(depth * GALLEY_MENU.length * 0.7 + Math.random() * 2));
    const id = GALLEY_MENU[i];
    if (this.inv.add(id, 1) <= 0) { this.notify('HOLD FULL. NOWHERE TO PUT IT.'); return false; }
    this.rations -= 1;
    this.systems.power = Math.max(0, this.systems.power - 0.4);
    this.notify(`${ITEMS[id].name.toUpperCase()} — ${this.rations} RATION UNITS LEFT`);
    this.events?.emit('station:galley', { id, left: this.rations });
    return true;
  }

  /** Read the rack without taking anything, for the STORES prop. */
  storesLine() {
    if (this.rations <= 0) return 'FOOD STORES: EMPTY. EVERY BIN TURNED OUT AND LEFT OPEN.';
    if (this.rations < 40) return `FOOD STORES: ${this.rations} RATION UNITS. YOU HAVE STARTED COUNTING.`;
    return `FOOD STORES: ${this.rations} RATION UNITS. THE GOOD FLAVORS ARE LONG GONE.`;
  }

  // -- water reclaimer ---------------------------------------------------------

  /** Bottle water from the loop. A canister costs four times a pouch. */
  drawWater() {
    if (!this._powered('RECLAIMER')) return false;
    const big = this.water >= 62;
    const cost = big ? 26 : 7;
    if (this.water < cost) {
      this.notify(`RECLAIMER: TANK AT ${Math.round(this.water)}%. NOT ENOUGH TO BOTTLE. LET IT CYCLE.`);
      return false;
    }
    const id = WATER_OUT[big ? 1 : 0];
    if (this.inv.add(id, 1) <= 0) { this.notify('HOLD FULL. NOWHERE TO PUT IT.'); return false; }
    this.water -= cost;
    this.notify(`${ITEMS[id].name.toUpperCase()} DRAWN — TANK ${Math.round(this.water)}%`);
    this.events?.emit('station:water', { id, tank: this.water });
    return true;
  }

  // -- med bed -----------------------------------------------------------------

  /**
   * A course of treatment. Reads the body first and refuses when there is
   * nothing wrong — the bed is not a healing button, it is a bed with a
   * dispensary attached and a finite number of doses in it.
   */
  treat() {
    const s = this.systems;
    if (!this._powered('MED BED', 10)) return false;
    if (this.medCool > 0) {
      this.notify(`MED BED: CYCLE RUNNING. ${Math.ceil(this.medCool)}s.`);
      return false;
    }
    const hurt = s.health < 99.5;
    const hot = s.radiation > 1;
    if (!hurt && !hot) {
      this.notify('SCAN: MILD FATIGUE, ELEVATED CORTISOL. NO TREATMENT REQUIRED.');
      return false;
    }
    if (this.medDoses <= 0) {
      this.notify('MED BED: DISPENSARY EMPTY. IT WILL READ YOU AND THAT IS ALL IT WILL DO.');
      return false;
    }
    this.medDoses -= 1;
    this.medCool = 40;
    const healed = Math.min(100 - s.health, 34);
    const scrubbed = Math.min(s.radiation, 22);
    s.health = Math.min(100, s.health + healed);
    s.radiation = Math.max(0, s.radiation - scrubbed);
    s.power = Math.max(0, s.power - 2.5);
    const parts = [];
    if (healed > 0.5) parts.push(`+${Math.round(healed)} HP`);
    if (scrubbed > 0.5) parts.push(`-${Math.round(scrubbed)} RAD`);
    this.notify(`COURSE COMPLETE: ${parts.join(', ')} — ${this.medDoses} DOSES LEFT`);
    this.events?.emit('station:treated', { healed, scrubbed, left: this.medDoses });
    return true;
  }

  // -- assay bench -------------------------------------------------------------

  /** The best thing in the hold the bench could put a number on. */
  bestSample() {
    let best = null;
    for (const rec of this.inv.grouped()) {
      if (!ASSAYABLE.has(rec.def.subCategory)) continue;
      if (!best || rec.def.value > best.def.value) best = rec;
    }
    return best;
  }

  /**
   * Crush, burn, weigh. Consumes the sample and pays for the knowledge: a
   * survey fee against the ledger, xenology credit for anything that was ever
   * alive, and salvage credit for anything that was not.
   *
   * The fee is a THIRD of the sample's face value, which is deliberately less
   * than a station would pay for the item itself. Assaying is what you do with
   * the twentieth lichen mat, not the first.
   */
  assay() {
    if (!this._powered('ASSAY BENCH', 8)) return false;
    const rec = this.bestSample();
    if (!rec) {
      this.notify('NOTHING IN THE HOLD THE BENCH CAN PUT A NUMBER ON.');
      return false;
    }
    this.inv.remove(rec.id, 1);
    const fee = Math.max(4, Math.round(rec.def.value * 0.34));
    if (this.trading) this.trading.credits += fee;
    this.systems.power = Math.max(0, this.systems.power - 1.2);
    const living = rec.def.subCategory === 'biological' || rec.def.subCategory === 'ancient';
    this.prog?.award?.(living ? 'xenology' : 'salvage', living ? 'sample.alien' : 'container');
    this.assays += 1;
    // One time in six the burn turns up something the sample was hiding — the
    // only reason to keep feeding the bench once the fee stops being interesting.
    let bonus = '';
    if (Math.random() < 0.17) {
      const extra = living ? 'nav_survey_tape' : 'crystal_quartz_var';
      if (ITEMS[extra] && this.inv.add(extra, 1) > 0) bonus = ` — TRACE: ${ITEMS[extra].name.toUpperCase()}`;
    }
    this.notify(`ASSAY: ${rec.def.name.toUpperCase()} — SURVEY FEE ${fee} CR${bonus}`);
    this.events?.emit('station:assayed', { id: rec.id, fee });
    return true;
  }

  toJSON() {
    return { rations: this.rations, water: this.water, medDoses: this.medDoses, assays: this.assays };
  }

  fromJSON(d) {
    if (!d) return;
    this.rations = d.rations ?? this.rations;
    this.water = d.water ?? this.water;
    this.medDoses = d.medDoses ?? this.medDoses;
    this.assays = d.assays ?? this.assays;
  }
}
