/**
 * TradingSystem — station commerce (Phase 7, context/04 §3). Credits are the
 * survey's operating account; every station quotes its own prices from a
 * seeded bias table, so a mining rig pays well for minerals and a trade hub
 * discounts consumables. Buy marks up, sell marks down — the spread is the
 * station's cut. Deterministic per station id: prices don't wander mid-visit.
 */
import { ITEMS } from '../data/ItemRegistry.js';

const STARTING_CREDITS = 250;

/** Small string hash → uint32, for per-station price seeds. */
function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

export class TradingSystem {
  /**
   * @param {import('./Inventory.js').Inventory} inventory
   * @param {import('../core/EventBus.js').EventBus} events
   */
  constructor(inventory, events) {
    this.inventory = inventory;
    this.events = events;
    this.credits = STARTING_CREDITS;
    this.totalSold = 0; // lifetime credits earned selling (quest hook)
    /** optional (station)=>multiplier from the faction system; 1.0 if unset */
    this.priceMod = null;
  }

  /** Station bias for a category: 0.8..1.3, stable per station. */
  _bias(station, category) {
    const h = hash(`${station.id}:${category}`);
    return 0.8 + (h % 1000) / 2000; // 0.8 .. 1.3
  }

  _fac(station) { return this.priceMod ? this.priceMod(station) : 1; }

  buyPrice(id, station) {
    const def = ITEMS[id];
    if (!def) return 0;
    return Math.max(1, Math.round(def.value * 1.25 * this._bias(station, def.category) * this._fac(station)));
  }

  sellPrice(id, station) {
    const def = ITEMS[id];
    if (!def) return 0;
    // a good standing lifts what they'll PAY, so invert the buy discount
    const fac = 2 - this._fac(station);
    return Math.max(1, Math.round(def.value * 0.6 * this._bias(station, def.category) * fac));
  }

  /**
   * What this station has on the shelf: a stable, seeded pick of trade-tagged
   * items. [{id, def, price}]
   */
  stock(station) {
    const rows = [];
    const ids = Object.keys(ITEMS).filter((id) => {
      const d = ITEMS[id];
      return (d.found ?? []).some((f) => f === 'trade' || f === 'stations');
    });
    const h0 = hash(station.id);
    for (let i = 0; i < ids.length; i++) {
      if (((h0 >>> (i % 24)) ^ hash(ids[i])) % 5 < 2) { // ~40% of the catalogue
        rows.push({ id: ids[i], def: ITEMS[ids[i]], price: this.buyPrice(ids[i], station) });
      }
    }
    rows.sort((a, b) => (a.def.category + a.def.name).localeCompare(b.def.category + b.def.name));
    return rows.slice(0, 18);
  }

  buy(id, station) {
    const price = this.buyPrice(id, station);
    if (this.credits < price) return 'NO CREDITS';
    if (this.inventory.add(id, 1) < 1) return 'HOLD FULL';
    this.credits -= price;
    this.events?.emit('trade:bought', { id, price });
    return true;
  }

  sell(id, station) {
    if (this.inventory.count(id) < 1) return 'NONE HELD';
    const price = this.sellPrice(id, station);
    this.inventory.remove(id, 1);
    this.credits += price;
    this.totalSold += price;
    this.events?.emit('trade:sold', { id, price, total: this.totalSold });
    return true;
  }

  toJSON() { return { credits: this.credits, totalSold: this.totalSold }; }
  fromJSON(d) {
    if (!d) return;
    this.credits = d.credits ?? STARTING_CREDITS;
    this.totalSold = d.totalSold ?? 0;
  }
}
