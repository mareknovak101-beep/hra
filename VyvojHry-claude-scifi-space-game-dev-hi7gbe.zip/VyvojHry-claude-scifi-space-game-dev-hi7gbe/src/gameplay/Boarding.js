/**
 * BOARDING — going aboard something that is not your ship.
 *
 * WHY THIS IS NOT A ROOM YOU WALK INTO. The obvious implementation is to build
 * a second `ShipMap` for the wreck and swap the player into it. That is a whole
 * second interior pipeline — collision, lighting, dressing, save state — for a
 * space you visit for ninety seconds, and every one of those systems already
 * assumes there is exactly one ship and the player is standing in it.
 *
 * So a boarding is a SEQUENCE, played from inside your own suit, on the 480×270
 * grid: you cross to the hull, cut in, and work your way through compartments
 * that are described rather than modelled. What makes it a game rather than a
 * cutscene is that every compartment costs something real — suit oxygen, time,
 * and a risk roll against what is still aboard — and you choose each time
 * whether to push deeper or take what you have and go.
 *
 * THE TENSION IS THE OXYGEN. The suit is finite and the walk back costs what
 * the walk in cost. Going one compartment further is always worth more loot and
 * always leaves less margin, and the moment you notice you have taken one too
 * many is the moment this mechanic exists for.
 *
 * WHAT A WRECK CONTAINS is derived from its id, so a given wreck holds the same
 * thing every time you visit and different things from the wreck beside it. It
 * is emptied permanently once stripped: `looted` rides in the save.
 */
import { RNG } from '../utils/RNG.js';
import { ITEMS } from '../data/ItemRegistry.js';

/**
 * Compartment archetypes. `risk` is the chance the compartment costs you
 * something on entry; `loot` is how many rolls it yields.
 *
 * Ordered roughly by how deep into a hull you have to go to reach one, because
 * the sequence walks this list in order — the good stuff is aft of the reactor,
 * which is the entire argument for pressing on.
 */
const COMPARTMENTS = [
  { id: 'breach', name: 'BREACH', o2: 4, risk: 0.05, loot: 1,
    text: 'The outer door is already open. Somebody left in a hurry, or something came in.' },
  { id: 'w_hold', name: 'CARGO HOLD', o2: 9, risk: 0.16, loot: 3,
    text: 'Most of the manifest is gone. What is left is what was too heavy or too dull to take.' },
  { id: 'w_quarters', name: 'CREW SPACES', o2: 7, risk: 0.10, loot: 2,
    text: 'Six bunks. Four are stripped, two are made. Somebody expected to come back.' },
  { id: 'w_galley', name: 'GALLEY', o2: 6, risk: 0.06, loot: 2,
    text: 'The stores are frozen solid and perfectly good. There is a mug still magnetised to the table.' },
  { id: 'w_medical', name: 'SICK BAY', o2: 7, risk: 0.14, loot: 2,
    text: 'Cabinets forced from the outside. Whoever did it knew exactly what they wanted.' },
  { id: 'w_bridge', name: 'BRIDGE', o2: 8, risk: 0.20, loot: 2,
    text: 'Every board is dark. The flight recorder bay is open and the recorder is still in it.' },
  { id: 'w_shop', name: 'WORKSHOP', o2: 8, risk: 0.18, loot: 2,
    text: 'A job half done on the bench, tools laid out in order beside it.' },
  { id: 'w_engine', name: 'DRIVE SECTION', o2: 9, risk: 0.22, loot: 2,
    text: 'The drive is cold enough that the coolant has frozen solid in the lines.' },
  { id: 'w_reactor', name: 'REACTOR SPACE', o2: 11, risk: 0.34, loot: 3,
    text: 'Cold, and reading hot. The shielding is cracked along one whole face.' },
  { id: 'w_core', name: 'SEALED COMPARTMENT', o2: 13, risk: 0.42, loot: 4,
    text: 'Dogged from the inside. Whatever the crew were keeping out, they were keeping it out of here.' },
];

/** What goes wrong, and what it costs. */
const HAZARDS = [
  { text: 'A plate lets go under your boot and you go through it.', health: 12, o2: 0 },
  { text: 'The suit catches on a torn frame. You hear the hiss before you feel it.', health: 4, o2: 14 },
  { text: 'Something heavy shifts in the dark behind you. Nothing follows.', health: 0, o2: 6 },
  { text: 'Coolant, still liquid, still under pressure. It goes straight through the glove.', health: 16, o2: 0 },
  { text: 'The compartment is hot. Your dosimeter goes from cream to brown in nine seconds.', health: 0, o2: 0, rad: 18 },
  { text: 'A cable run swings loose and takes the lamp off your helmet. You work by feel.', health: 3, o2: 8 },
];

/** Loot pools by compartment, weighted from what would plausibly be in one. */
const POOLS = {
  breach: ['suit_visor_film', 'suit_seal_grease', 'suit_dosimeter_strip', 'o2_canister',
    'suit_patch', 'salvage_plating_scrap'],
  w_hold: ['trade_machine_parts', 'trade_textiles', 'ore_iron_refined', 'ore_titanium_raw',
    'salvage_mag_coil', 'trade_data_cores', 'contra_unlogged_cells', 'hull_plate'],
  w_quarters: ['personal_photo_crew', 'personal_tags_id', 'personal_letter_unsent', 'personal_cassette_mix',
    'personal_calendar_marked', 'ration_bar', 'datachip_04', 'personal_medal_service'],
  w_galley: ['ration_stew', 'ration_curry', 'water_can', 'coffee_pack', 'drink_cocoa',
    'personal_recipe_card', 'ration_fish'],
  w_medical: ['medkit_field', 'trauma_kit', 'radaway_dose', 'antibiotic', 'burn_gel',
    'contra_med_schedule', 'stim_shot'],
  w_bridge: ['nav_black_box', 'nav_lane_chart', 'nav_beacon_codes', 'nav_crew_roster',
    'elec_crypto_module', 'spare_avionics_bus', 'datachip_09'],
  w_shop: ['tool_welder', 'tool_spectro_pen', 'tool_borescope', 'spare_hatch_actuator',
    'spare_fuel_polisher', 'weapon_kit_clean', 'alloy_steel_plate'],
  w_engine: ['salvage_wire_spool', 'salvage_optic_bundle', 'salvage_plating_scrap',
    'comp_fuse_block', 'spare_thruster_nozzle', 'comp_field_coil'],
  w_reactor: ['spare_reactor_rod', 'gas_deuterium', 'comp_heat_exchanger', 'spare_warp_coil_spare',
    'ore_thorium_raw', 'comp_capacitor_bank'],
  w_core: ['artifact_fragment_a', 'artifact_lens_relic', 'fsalvage_drift_wafer', 'contra_drift_sample',
    'crystal_void_opal', 'artifact_song_cylinder', 'nav_manifest_forged'],
};

/**
 * Ships that are not wrecks but ARE boardable — a silent relay, a dead station.
 * They have no compartments to speak of, so they run a short fixed sequence.
 */
const RELAY_SEQ = ['breach', 'w_hold', 'w_bridge'];

export class Boarding {
  /**
   * @param {object} deps
   * @param {import('../gameplay/Inventory.js').Inventory} deps.inventory
   * @param {import('../ship/ShipSystems.js').ShipSystems} deps.systems
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(text:string)=>void} deps.notify
   * @param {object} deps.audio
   */
  constructor({ inventory, systems, events, notify, audio }) {
    this.inv = inventory;
    this.systems = systems;
    this.events = events;
    this.notify = notify ?? (() => {});
    this.audio = audio;
    /** Wrecks already stripped, by id. Persisted. */
    this.looted = new Set();
    /** @type {object|null} the live boarding, or null */
    this.run = null;
    this._build();
  }

  get active() { return !!this.run; }

  /**
   * Start a boarding on a `ships[]` record.
   *
   * Refuses on two grounds and states which: no suit consumables aboard (you can
   * cross to a wreck on the suit's own tank but you cannot work in one), and an
   * already-stripped hull. Both are refusals the player can act on rather than
   * a silent no-op.
   */
  begin(target) {
    if (this.run) return;
    if (this.looted.has(target.id)) {
      this.notify(`${target.name}: ALREADY STRIPPED. NOTHING LEFT WORTH THE AIR.`);
      return;
    }
    if (this.systems.oxygen < 25) {
      this.notify('SUIT OXYGEN TOO LOW TO BOARD — RECHARGE FIRST');
      return;
    }
    const rng = new RNG(hash(target.id));
    /**
     * HOW MUCH OF THIS HULL IS STILL WORTH ANYTHING — not how much of it
     * exists.
     *
     * This used to truncate the compartment list, which was fine while a
     * boarding was a panel with an ADVANCE button and nonsense the moment it
     * became a deck you walk: the wreck has all ten compartments whatever the
     * roll says, so a sequence three long meant walking into a real, dressed,
     * modelled workshop and being told the hull had ended.
     *
     * The sequence is now always the whole deck, in deck order, and the roll
     * decides how far in the salvage runs out. Past `rich` a compartment costs
     * you the same air and rolls the same hazards and yields nothing — which is
     * both what "somebody got here first" looks like and a far better reason to
     * turn back than a wall.
     */
    const rich = target.relay ? RELAY_SEQ.length
      : Math.max(3, Math.min(COMPARTMENTS.length, 3 + Math.floor(rng.next() * 6 + (target.scale ?? 1) * 2)));
    const seq = target.relay
      ? RELAY_SEQ.map((id) => COMPARTMENTS.find((c) => c.id === id))
      : COMPARTMENTS.slice();
    this.run = {
      target, seq, rng, rich, at: -1, taken: [], o2Spent: 0,
      // The walk back out. Charged in full when you leave, and quoted the whole
      // time — the number that makes "one more compartment" a decision.
      exitCost: 0,
    };
    this.notify(`CROSSING TO ${target.name} — SUIT SEALED`);
    this.events?.emit('boarding:begin', target.id);
    this.audio?.playAirlock?.();
    this.advance();
  }

  /**
   * Go one compartment deeper. Charges the oxygen, rolls the hazard, rolls the
   * loot, and reports all three.
   */
  advance() {
    const r = this.run;
    if (!r) return;
    r.at++;
    if (r.at >= r.seq.length) {
      this.notify(`${r.target.name}: THAT IS THE END OF IT. NOTHING FURTHER IS PRESSURISED OR REACHABLE.`);
      this.finish(true);
      return;
    }
    const c = r.seq[r.at];
    // Oxygen: the compartment's own cost, plus the growing walk back out.
    r.exitCost += c.o2 * 0.45;
    const cost = c.o2;
    this.systems.oxygen = Math.max(0, this.systems.oxygen - cost);
    r.o2Spent += cost;
    this.notify(`${c.name} — ${c.text}`);

    // Hazard roll. Deeper compartments are worse, and a hull that has been out
    // here longer is worse again.
    if (r.rng.next() < c.risk) {
      const h = HAZARDS[r.rng.int(0, HAZARDS.length - 1)];
      if (h.health) this.systems.health = Math.max(1, this.systems.health - h.health);
      if (h.o2) this.systems.oxygen = Math.max(0, this.systems.oxygen - h.o2);
      if (h.rad) this.systems.radiation = Math.min(100, this.systems.radiation + h.rad);
      this.notify(`— ${h.text}`);
      this.audio?.playHit?.();
      this.events?.emit('boarding:hazard', c.id);
    }

    /**
     * Loot roll — but only while there is anything left in this hull. Past the
     * `rich` mark the compartment has already been gone through, and it SAYS SO
     * rather than silently rolling nothing, because a player who searches three
     * empty rooms without being told why concludes the game is broken.
     *
     * The air and the hazard above are charged either way. Walking deeper into
     * a stripped wreck costs exactly what walking deeper into a full one costs;
     * that is the whole point of finding out it is stripped.
     */
    if (r.at >= r.rich) {
      this.notify('PICKED CLEAN. SOMEBODY WORKED THIS FAR IN BEFORE YOU.');
    } else {
      const pool = POOLS[c.id] ?? POOLS.breach;
      const got = [];
      for (let k = 0; k < c.loot; k++) {
        if (r.rng.next() > 0.72) continue; // not every locker has something in it
        const id = pool[r.rng.int(0, pool.length - 1)];
        if (!ITEMS[id]) continue;
        const qty = ITEMS[id].stackable ? r.rng.int(1, 2) : 1;
        const added = this.inv.add(id, qty);
        if (added > 0) { got.push(`${ITEMS[id].name}${added > 1 ? ` ×${added}` : ''}`); r.taken.push(id); }
        else { this.notify('HOLD FULL — LEFT IT WHERE IT WAS'); break; }
      }
      if (got.length) this.notify(`RECOVERED: ${got.join(', ').toUpperCase()}`);
    }

    // The suit calls it before you do.
    if (this.systems.oxygen <= r.exitCost + 4) {
      this.notify('SUIT: OXYGEN RESERVE AT THE RETURN MARGIN. GO NOW.');
    }
    if (this.systems.oxygen <= 2) {
      this.notify('SUIT OXYGEN EXHAUSTED — EMERGENCY RETURN, HULL AIR VENTED TO THE SUIT');
      this.systems.oxygen = 6;
      this.systems.health = Math.max(1, this.systems.health - 18);
      this.finish(false);
    }
  }

  /**
   * Come back out. `stripped` marks the hull permanently empty, which only
   * happens if you reached the end of it — leaving early keeps it live so you
   * can come back with more air, which is the whole reason to leave early.
   */
  finish(stripped) {
    const r = this.run;
    if (!r) return;
    this.systems.oxygen = Math.max(0, this.systems.oxygen - r.exitCost);
    if (stripped) this.looted.add(r.target.id);
    const n = r.taken.length;
    this.notify(n
      ? `BACK ABOARD — ${n} ITEM${n === 1 ? '' : 'S'} RECOVERED FROM ${r.target.name}`
      : `BACK ABOARD — ${r.target.name} HAD NOTHING LEFT IN IT`);
    this.events?.emit('boarding:end', { id: r.target.id, count: n, stripped });
    this.run = null;
    this._sync();
  }

  /** Live state for the boarding panel. */
  status() {
    const r = this.run;
    if (!r) return null;
    const c = r.seq[Math.max(0, r.at)];
    return {
      name: r.target.name,
      compartment: c?.name ?? '—',
      at: r.at + 1, of: r.seq.length,
      oxygen: this.systems.oxygen,
      exitCost: r.exitCost,
      taken: r.taken.length,
      atEnd: r.at + 1 >= r.seq.length,
    };
  }

  /** Save/restore: only the stripped set matters between sessions. */
  toJSON() { return { looted: [...this.looted] }; }
  fromJSON(d) { this.looted = new Set(d?.looted ?? []); this._sync(); }

  _sync() { this.events?.emit('boarding:sync', this.looted.size); }
  _build() { /* reserved: per-target generated layouts */ }
}

/** FNV-1a of a string id — a stable seed per wreck. */
function hash(s) {
  let h = 0x811c9dc5;
  const t = String(s);
  for (let i = 0; i < t.length; i++) { h ^= t.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}

export { COMPARTMENTS };
