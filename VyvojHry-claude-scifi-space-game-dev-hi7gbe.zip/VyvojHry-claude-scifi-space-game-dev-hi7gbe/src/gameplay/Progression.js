/**
 * PROGRESSION — the five things a survey pilot gets better at, and what getting
 * better at them actually does.
 *
 * WHY THIS EXISTS. Everything in this game up to now has been the same on hour
 * twenty as on minute one. The ship changes (you buy hulls, you fit them), the
 * inventory changes, the standings change — but YOU do not, so a landing you
 * have flown fifty times is exactly as hard as the first one and there is
 * nothing on the other side of doing a thing well except having done it.
 *
 * WHAT THIS IS NOT. It is not a class, a build, or a skill tree with choices.
 * There is nothing to spend and nothing to pick wrong. You get better at what
 * you actually do, the way a working pilot does: land a lot and your entries
 * get cheaper, open a lot of lockers and you start finding the thing at the
 * bottom, shoot a lot and you stop wasting cells. A survey contract is a job,
 * and this is the part of an RPG that models a job rather than a hero.
 *
 * FIVE PROFICIENCIES, each earned by one clearly-identified activity:
 *
 *   PILOTING      soft touchdowns, docking, warps, atmospheric flight.
 *                 Pays back as entry heat, gear tolerance and fuel.
 *   SALVAGE       containers, wreck compartments, surface sites and caches.
 *                 Pays back as extra rolls and better rarity — the single
 *                 most-felt one, because it changes what the world contains.
 *   XENOLOGY      scanning bodies, anomalies, working alien sites.
 *                 Pays back as scanner range, sample yield and hazard warning.
 *   ENGINEERING   field repairs, intrusions, refits.
 *                 Pays back as repair size, hack clock and power draw.
 *   MARKSMANSHIP  kills, in the seat and on foot.
 *                 Pays back as damage and ammunition economy.
 *
 * TEN LEVELS EACH, on a curve that front-loads. Level 2 arrives fast enough
 * that you notice the system exists at all; level 10 is a long commission's
 * work and is deliberately not required for anything.
 *
 * ALL BONUSES ARE READ, NEVER PUSHED. Nothing here mutates another system's
 * state — the consumers ask `bonus(skill)` when they need it, so a save loaded
 * at a different level is instantly consistent and there is no accumulated
 * multiplier to get out of step.
 */

/** Ordered for display; the ids are what the rest of the game passes around. */
export const SKILLS = [
  {
    id: 'piloting',
    name: 'PILOTING',
    blurb: 'Hours on the stick. Entries, approaches, and the last twenty metres.',
    /** What one level buys, for the panel to quote back. */
    perLevel: 'entry heat −4% · gear tolerance +3% · landing fuel −2%',
  },
  {
    id: 'salvage',
    name: 'SALVAGE',
    blurb: 'Knowing which panel comes off and what is usually behind it.',
    perLevel: 'find rate +3.5% · rare finds +2.5% · site oxygen −2%',
  },
  {
    id: 'xenology',
    name: 'XENOLOGY',
    blurb: 'Survey work proper: what a world is, and what on it will kill you.',
    perLevel: 'scanner range +6% · sample yield +5% · hazard odds −3%',
  },
  {
    id: 'engineering',
    name: 'ENGINEERING',
    blurb: 'Ship husbandry. Patching plate, and talking to locks that say no.',
    perLevel: 'field repair +7% · intrusion clock +5% · power draw −2%',
  },
  {
    id: 'marksmanship',
    name: 'MARKSMANSHIP',
    blurb: 'Trigger time. Guns in the seat, and the one in your hands.',
    perLevel: 'damage +4% · ammunition economy +3%',
  },
];

const SKILL_IDS = SKILLS.map((s) => s.id);
export const MAX_LEVEL = 10;

/**
 * XP required to REACH each level, cumulative.
 *
 * Front-loaded on purpose. The first level costs 60, which is about four
 * lockers or one careful landing — early enough that the system announces
 * itself while you are still learning the ship. Ten costs 6,400, which is a
 * commission's worth of one activity and is meant to be a thing a particular
 * pilot has rather than a thing every pilot ends up with.
 */
const CURVE = [0, 60, 160, 330, 590, 960, 1470, 2150, 3050, 4500, 6400];

export function levelFor(xp) {
  let lv = 0;
  while (lv < MAX_LEVEL && xp >= CURVE[lv + 1]) lv++;
  return lv;
}

/**
 * WHAT EACH ACTIVITY IS WORTH.
 *
 * Deliberately uneven, and the ordering is the design. A soft landing pays four
 * times a hard one because the hard one already cost you hull and the game
 * should not pay you twice for the same mistake. A rare find pays more than a
 * common one because the interesting part of salvage is the tail. Killing pays
 * least per event of anything here, because this is a survey game and rewarding
 * combat at the rate it rewards work would quietly turn it into a different one.
 */
const AWARDS = {
  piloting: {
    'touchdown.soft': 45,
    'touchdown.hard': 11,
    'entry.clean': 18,      // through the atmosphere without losing plating
    'launch': 12,
    'dock': 14,
    'warp': 20,
  },
  salvage: {
    'container': 7,
    'container.rare': 22,
    'wreck.compartment': 26,
    'surface.site': 24,
    'surface.cache': 30,
    // Stripping a body you had to put down first, and walking off a hull with
    // nothing left moving on it. The second is the largest single salvage award
    // in the table because it is the only one that takes a fight to earn.
    'remains': 18,
    'clearHull': 64,
  },
  xenology: {
    'body.scanned': 16,
    'anomaly': 55,
    'sample.alien': 28,
    'world.first': 40,      // first landing on a body nobody has walked
  },
  engineering: {
    'repair': 15,
    'hack': 42,
    'refit': 30,
    'craft': 12,
  },
  marksmanship: {
    'kill.ship': 18,
    'kill.foot': 9,
    // Something that was walking toward you in a dark corridor. Worth more than
    // a shot into a console, less than a hull kill.
    'kill.boarder': 21,
    // Putting a hull down without breaking it up. Harder than killing it, and
    // it leaves you something to board — the largest marksmanship award there
    // is, because it is the only one that is about restraint.
    'cripple': 34,
  },
};

/**
 * THE BONUS TABLE — per level, per skill, keyed by what the consumer asks for.
 *
 * Every one of these is a small number times the level. Nothing here doubles
 * anything at level 10: the ceiling on the strongest term is +50%, and most sit
 * at +20 to +40. A progression system in a survival game that made the late
 * game easy would be removing the game.
 */
const BONUS = {
  /** Multiplier on entry skin heating. Lower is better. */
  entryHeat: (lv) => 1 - lv * 0.04,
  /** Multiplier on the descent rate a landing gear absorbs. Higher is better. */
  gearTolerance: (lv) => 1 + lv * 0.03,
  /** Multiplier on the fuel a descent costs. */
  landingFuel: (lv) => 1 - lv * 0.02,
  /** Added to the container's tier multiplier — see gameplay/Loot.js. */
  findChance: (lv) => lv * 0.035,
  /** Added to the rare shelf's gate. */
  rareBias: (lv) => lv * 0.025,
  /**
   * Multiplier on what breaking a thing down returns. Recycling is lossy by
   * design — a third of what building costs — so this closes the gap a little
   * for somebody who has spent a career stripping hulls, without ever making
   * build-then-break a loop that pays.
   */
  recycleYield: (lv) => 1 + lv * 0.06,
  /** Multiplier on the oxygen a surface site costs. */
  siteOxygen: (lv) => 1 - lv * 0.02,
  /** Multiplier on proximity scanner range. */
  scanRange: (lv) => 1 + lv * 0.06,
  /** Multiplier on how much a worked sample yields. */
  sampleYield: (lv) => 1 + lv * 0.05,
  /** Multiplier on the odds a hazard fires while working. */
  hazardOdds: (lv) => 1 - lv * 0.03,
  /** Multiplier on field repair size. */
  repairAmount: (lv) => 1 + lv * 0.07,
  /** Multiplier on the intrusion countermeasure clock. */
  hackClock: (lv) => 1 + lv * 0.05,
  /** Multiplier on ship power draw. */
  powerDraw: (lv) => 1 - lv * 0.02,
  /**
   * Multiplier on a fabrication job's spoil chance. Lower is better, and it
   * never reaches zero — the worst recipe on the board is 18% and a level ten
   * hand still ruins it one time in eleven. A bench that could not spoil stock
   * would make the risk column decorative.
   */
  craftRisk: (lv) => 1 - lv * 0.05,
  /** Multiplier on weapon damage. */
  damage: (lv) => 1 + lv * 0.04,
  /** Chance a shot does not consume ammunition. */
  ammoSaved: (lv) => lv * 0.03,
};

/** Which skill each bonus reads its level from. */
const BONUS_SKILL = {
  entryHeat: 'piloting', gearTolerance: 'piloting', landingFuel: 'piloting',
  findChance: 'salvage', rareBias: 'salvage', siteOxygen: 'salvage',
  recycleYield: 'salvage',
  scanRange: 'xenology', sampleYield: 'xenology', hazardOdds: 'xenology',
  repairAmount: 'engineering', hackClock: 'engineering', powerDraw: 'engineering',
  craftRisk: 'engineering',
  damage: 'marksmanship', ammoSaved: 'marksmanship',
};

export class Progression {
  /**
   * @param {object} deps
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(t:string)=>void} deps.notify
   */
  constructor({ events, notify } = {}) {
    this.events = events;
    this.notify = notify ?? (() => {});
    /** id → accumulated xp */
    this.xp = {};
    /** id → level, cached so `bonus` is a lookup rather than a search. */
    this.level = {};
    for (const id of SKILL_IDS) { this.xp[id] = 0; this.level[id] = 0; }
    /** Running totals the panel quotes — a service record, not a scoreboard. */
    this.tally = {};
    if (events) this._listen(events);
  }

  /**
   * WIRED TO THE EVENT BUS, not called from the systems it measures.
   *
   * Every one of these events already existed and was already being emitted for
   * something else — the lore unlocks, the quest tracker, the notifications.
   * Reading them here means no other module had to learn that progression
   * exists, and it means an activity cannot be rewarded twice because there is
   * exactly one place that decides what an event is worth.
   */
  _listen(events) {
    events.on('landing:down', (d) => {
      this.award('piloting', d?.hard ? 'touchdown.hard' : 'touchdown.soft');
      // Coming through the plasma without losing plating is its own skill and
      // is separate from putting the gear down gently.
      if ((d?.peakHeat ?? 0) < 1.0) this.award('piloting', 'entry.clean');
      if (d?.first) this.award('xenology', 'world.first');
    });
    events.on('landing:launch', () => this.award('piloting', 'launch'));
    events.on('landing:worked', (d) => {
      this.award('salvage', d?.cache ? 'surface.cache' : 'surface.site');
      if (d?.alien) this.award('xenology', 'sample.alien');
    });
    events.on('ship:docked', () => this.award('piloting', 'dock'));
    events.on('system:arrived', () => this.award('piloting', 'warp'));
    events.on('body:scanned', () => this.award('xenology', 'body.scanned'));
    events.on('anomaly:scanned', () => this.award('xenology', 'anomaly'));
    events.on('boarding:sync', (d) => {
      if (d?.opened) this.award('salvage', 'wreck.compartment');
    });
    events.on('loot:searched', (d) => {
      this.award('salvage', d?.rare ? 'container.rare' : 'container');
    });
    events.on('ship:repaired', () => this.award('engineering', 'repair'));
    events.on('hack:solved', () => this.award('engineering', 'hack'));
    events.on('ship:refit', () => this.award('engineering', 'refit'));
    events.on('combat:kill', (d) => {
      this.award('marksmanship', d?.onFoot ? 'kill.foot' : 'kill.ship');
    });
  }

  /**
   * Credit an activity. Returns the xp actually given, which is zero once a
   * skill is capped — the tally still counts, because the service record is
   * about what you did rather than about what it bought you.
   */
  award(skill, activity, mult = 1) {
    const table = AWARDS[skill];
    if (!table) return 0;
    const base = table[activity] ?? 0;
    this.tally[`${skill}.${activity}`] = (this.tally[`${skill}.${activity}`] ?? 0) + 1;
    if (!base || this.level[skill] >= MAX_LEVEL) return 0;
    const gain = Math.max(1, Math.round(base * mult));
    this.xp[skill] += gain;
    const was = this.level[skill];
    const now = levelFor(this.xp[skill]);
    if (now !== was) {
      this.level[skill] = now;
      const def = SKILLS.find((s) => s.id === skill);
      // Said out loud, once, with the number that changed — a level that only
      // shows up in a panel nobody opens is a level that did not happen.
      this.notify(`${def.name} ${now} — ${def.perLevel}`);
      this.events?.emit('skill:level', { skill, level: now });
    }
    return gain;
  }

  /**
   * The one thing every consumer calls. Named for the EFFECT rather than for
   * the skill, so a caller does not have to know which proficiency governs it —
   * `progression.bonus('entryHeat')` reads correctly at the call site and stays
   * correct if the mapping is ever retuned.
   */
  bonus(key) {
    const skill = BONUS_SKILL[key];
    const fn = BONUS[key];
    if (!skill || !fn) return 1;
    return fn(this.level[skill] ?? 0);
  }

  /** Everything the journal tab draws. */
  status() {
    return SKILLS.map((s) => {
      const lv = this.level[s.id];
      const xp = this.xp[s.id];
      const floor = CURVE[lv];
      const ceil = lv >= MAX_LEVEL ? floor : CURVE[lv + 1];
      return {
        id: s.id,
        name: s.name,
        blurb: s.blurb,
        perLevel: s.perLevel,
        level: lv,
        xp,
        into: xp - floor,
        need: ceil - floor,
        frac: lv >= MAX_LEVEL ? 1 : (xp - floor) / Math.max(1, ceil - floor),
        capped: lv >= MAX_LEVEL,
        // The two or three lines of service record this skill has earned.
        record: Object.entries(this.tally)
          .filter(([k]) => k.startsWith(`${s.id}.`))
          .sort((a, b) => b[1] - a[1])
          .slice(0, 3)
          .map(([k, n]) => [k.slice(s.id.length + 1).replace(/\./g, ' ').toUpperCase(), n]),
      };
    });
  }

  toJSON() { return { xp: { ...this.xp }, tally: { ...this.tally } }; }

  fromJSON(d) {
    for (const id of SKILL_IDS) {
      this.xp[id] = Number(d?.xp?.[id]) || 0;
      this.level[id] = levelFor(this.xp[id]);
    }
    this.tally = { ...(d?.tally ?? {}) };
  }
}
