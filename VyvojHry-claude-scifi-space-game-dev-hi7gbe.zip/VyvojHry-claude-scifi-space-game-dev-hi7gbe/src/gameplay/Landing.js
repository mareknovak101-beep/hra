/**
 * LANDING — atmospheric entry, touchdown, surface operations, and getting off
 * again.
 *
 * The approach panel has offered a LAND button since Phase 4 and it has printed
 * "SURFACE OPS PENDING" every time. This is the surface ops.
 *
 * FOUR PHASES, and the first is the only one that can go wrong:
 *
 *   ENTRY     you fly it. The ship is committed at the top of the atmosphere and
 *             the descent is real: heat builds with speed against the air, the
 *             hull buffets, and coming in fast costs integrity. Throttling back
 *             costs fuel instead. That trade — burn fuel or burn hull — is the
 *             whole of the mechanic and it is decided in about twenty seconds.
 *   DOWN      on the ground. The world is generated (see data/SurfaceGen.js),
 *             the sites are laid out, and the suit clock is what limits the
 *             visit.
 *   WORKING   at a site: sampling, drilling, cutting something out of a wreck.
 *             Costs oxygen and rolls the world's own hazards.
 *   ASCENT    the fuel bill for getting back to orbit, quoted before you commit
 *             so that landing somewhere heavy with a half tank is a decision
 *             rather than a trap.
 *
 * WHY ENTRY IS NOT A CUTSCENE. Every other "transition" in this game is a lerp
 * you watch. An atmosphere is the one place where the ship's own numbers — mass,
 * thrust, hull, fuel — decide the outcome, and making the player fly it is what
 * separates a world you visited from a world you got to.
 */
import { RNG } from '../utils/RNG.js';
import { ITEMS } from '../data/ItemRegistry.js';
import {
  surfaceProfile, surfaceSites, terrainJob, makeFrame, slideFrame, setLandingSite,
} from '../data/SurfaceGen.js';

/** Seconds of descent from entry interface to BREAKOUT at nominal rate. */
const ENTRY_SECONDS = 18;

/**
 * FLOWN APPROACH (0.38.0, owner: "like in No Man's Sky").
 *
 * Entry used to run a timer to 1.0 and then simply declare you landed, wherever
 * the ship happened to be pointing. The heat/fuel trade it modelled was good and
 * survives untouched — but it ended in a cut, and a cut is exactly the thing
 * that makes a world feel like a menu option rather than a place.
 *
 * The timer now only carries you through the ionised part of the descent, where
 * there is genuinely nothing to see and nothing to steer. At `BREAKOUT_ALT` you
 * come out of the plasma over open ground with the terrain built, full attitude
 * and throttle authority, and gravity underneath you. Where you touch down, and
 * how hard, is flown.
 */
/**
 * Where the entry STARTS, in units above the pad datum.
 *
 * The descent used to be positionless: an eighteen-second timer ran while the
 * ship sat wherever it had been in system space, and at the end of it the hull
 * was teleported to the middle of the patch at 330 units. Two visible faults
 * came out of that — a hitch as fifty-five thousand triangles of terrain were
 * generated in one frame, and a jump-cut as the ship appeared somewhere it had
 * not flown to.
 *
 * The entry now happens IN THE TERRAIN FRAME from the moment you commit. The
 * mesh is built at `begin`, the hull is placed at the top of the atmosphere,
 * and altitude falls continuously from here to touchdown. Breakout stops being
 * a transition and becomes what it should always have been: the plasma clearing
 * and the controls coming back, with nothing moving that was not already moving.
 */
const ENTRY_TOP = 2600;
const BREAKOUT_ALT = 330;     // units above the pad datum where control returns
const CEILING_ALT = 1500;     // climb past this and you are leaving
const GEAR_CLEAR = 16;        // hull datum to ground when the feet are down
const SOFT_VS = 46;           // descent rate a landing gear absorbs, u/s
const SOFT_HS = 58;           // ground speed it absorbs, u/s
const GRAV_UNITS = 34;        // u/s² at 1 g — tuned against THRUST_ACCEL, not SI
/**
 * AUTO-HOVER. How hard the ventral jets hold the hull when flight assist is on
 * and you are not commanding a climb or a descent.
 *
 * Landing "always crashed" for two reasons and this is the second. The first
 * was that the vertical thrusters fired along the HULL's up axis (fixed in
 * FlightController), so on a nose-down approach most of your lift went
 * sideways. The second is that there was no hover at all: the moment you
 * stopped thrusting, thirty-four units per second per second of weight took
 * over and the ground came up. A ship with flight assist engaged should sit
 * where you put it — that is what the assist IS — and descending should be
 * something you ask for.
 *
 * 2.6 nulls a seventy-unit descent in a bit under a second, which is fast
 * enough to save a bad entry and slow enough that you feel the hull settle.
 */
const HOVER_GAIN = 2.6;

/**
 * THE VEIL — how fast the ionisation envelope closes and clears, in units of
 * "fully opaque per second". See ui/EntryVeil.js for what it looks like and
 * why the transition is hidden behind it rather than blended.
 *
 * Closing is faster than clearing on purpose. The envelope has to be solid
 * before the world can be swapped underneath it, so a slow close is dead time
 * you cannot use; but coming out of it is the reveal — the first sight of a
 * landscape you committed to twenty seconds ago — and rushing that throws away
 * the only moment in the descent that is worth looking at.
 */
const VEIL_CLOSE = 1 / 0.85;
const VEIL_CLEAR = 1 / 1.9;

/**
 * THE CAP, AND WHY IT MOVES (0.45.0, owner: "create whole celestial bodies
 * surfaces, not just a square area").
 *
 * A world used to be a 3200-metre square with a wall round it. It is now a
 * sphere — the height at any point is a function of the DIRECTION on the body,
 * so there is ground everywhere and it is the same ground every time — and what
 * gets built is a cap of it centred on where you are.
 *
 * `CAP_GROUND` is a bit past the geometric horizon from standing height on an
 * Earth-sized world, which is what you can actually see. `CAP_AIR` scales it up
 * with altitude, because from three kilometres up you can see thirty and a cap
 * the size of the one under your boots would end in mid-air a few seconds after
 * you took off.
 *
 * `RECENTRE_FRAC` is how far across the cap you get before a new one starts
 * building in the background. Not so close to the edge that you could outrun the
 * build, not so close to the middle that it rebuilds constantly.
 */
const CAP_GROUND = 1600;
const CAP_MAX = 11000;
const RECENTRE_FRAC = 0.40;
/** Rebuild for resolution when the wanted cap differs from the built one by this. */
const CAP_STEP = 1.55;

function capExtent(alt) {
  return Math.max(CAP_GROUND, Math.min(CAP_MAX, CAP_GROUND + Math.max(0, alt) * 2.4));
}

/**
 * Interface speed: how fast you hit the top of the atmosphere.
 *
 * Derived from the world rather than from the ship, because orbital velocity is
 * a property of what you are falling toward — a heavy world gives you a faster,
 * hotter entry whatever you were doing beforehand, and that is the fact the
 * whole mechanic turns on.
 */
function ship0Speed(body, profile) {
  return 96 + profile.gravity * 62;
}

export class Landing {
  /**
   * @param {object} deps
   * @param {import('./Inventory.js').Inventory} deps.inventory
   * @param {import('../ship/ShipSystems.js').ShipSystems} deps.systems
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(t:string)=>void} deps.notify
   */
  constructor({ inventory, systems, events, notify, audio, progression }) {
    this.inv = inventory;
    /**
     * The pilot's proficiencies, read never written. Optional so a probe or a
     * test can construct a Landing without the whole game around it.
     */
    this.prog = progression ?? { bonus: () => 1 };
    this.systems = systems;
    this.events = events;
    this.notify = notify ?? (() => {});
    this.audio = audio;
    /** null | 'entry' | 'down' | 'ascent' */
    this.phase = null;
    /** The world we are going to / on. */
    this.body = null;
    this.profile = null;
    this.sites = [];
    this.terrain = null;
    /** 0→1 through entry, 1→0 through ascent. */
    this.t = 0;
    /** Peak skin temperature this descent, for the log. */
    this.peakHeat = 0;
    /** Live entry telemetry the HUD reads. */
    this.tele = { heat: 0, buffet: 0, alt: 0, vspeed: 0 };
    /** 0 clear → 1 fully enveloped in plasma. Drawn by ui/EntryVeil.js. */
    this.veil = 0;
    /**
     * Which world the 3D pass should be drawing: the star system, or the
     * heightfield. Owned HERE rather than inferred from the phase in main.js,
     * because the whole point is that it flips at a moment nobody can see —
     * under a solid veil — and that moment is not the same as the moment the
     * phase changes.
     */
    this.showGround = false;
    /** Worlds visited, for the journal and the save. */
    this.visited = new Set();
    this._rng = new RNG(0x1a2d);
  }

  get active() { return this.phase !== null; }
  get onGround() { return this.phase === 'down'; }
  /** Opaque enough to change the world behind it without anyone seeing. */
  get veiled() { return this.veil > 0.985; }

  /**
   * Can this body be landed on at all, and what would it cost?
   * Returns null for gas giants and stars — they have no surface, and the
   * approach panel says SCAN rather than LAND for exactly that reason.
   */
  survey(body) {
    const p = surfaceProfile(body);
    if (!p) return null;
    return { profile: p, fuel: p.landingFuel };
  }

  /**
   * The direction on the body the ship is currently over — the landing site.
   * Falls back to the world's own default site when there is no hull to ask
   * (a probe, a save being restored).
   */
  _siteUnder(body, shipPos) {
    if (!shipPos || !body?.pos) return null;
    const dx = shipPos[0] - body.pos[0];
    const dy = shipPos[1] - body.pos[1];
    const dz = shipPos[2] - body.pos[2];
    const m = Math.hypot(dx, dy, dz);
    if (!(m > 1e-6)) return null;
    return [dx / m, dy / m, dz / m];
  }

  /**
   * Commit to the descent.
   * @param {object} body
   * @param {number[]} [shipPos] the hull's system-space position, which decides
   *   WHERE on the body you come down — see `_siteUnder`.
   */
  begin(body, shipPos = null) {
    if (this.phase) return false;
    const s = this.survey(body);
    if (!s) {
      this.notify(`${body.name}: NO SURFACE TO PUT A SHIP ON. ATMOSPHERIC SCAN ONLY.`);
      return false;
    }
    // Fuel is checked for the ROUND TRIP, not the descent. Landing with enough
    // to get down and not enough to get up is not a challenge, it is a save file
    // that has quietly ended, and the game should say so at the top of the
    // atmosphere rather than at the bottom of it.
    const round = s.fuel * 2;
    if (this.systems.fuel < round) {
      this.notify(`${body.name}: ${round}% FUEL FOR THE ROUND TRIP AND YOU HAVE `
        + `${Math.round(this.systems.fuel)}%. NOT FROM HERE.`);
      return false;
    }
    this.phase = 'entry';
    this.body = body;
    this.profile = s.profile;
    this.t = 0;
    this.peakHeat = 0;
    // DESCENT SPEED IS THE ENTRY'S OWN. Reading it off `ship.speed` looked
    // right and was not: flight assist nulls the hull's velocity within a
    // second of the commit, so every entry arrived at zero, the heat term
    // vanished and the descent was free whatever you did. The interface speed
    // is captured once, gravity accelerates it, and only a retro burn slows it.
    this.vspeed = Math.max(70, Math.min(240, ship0Speed(body, s.profile)));
    // BUILD IT NOW, at the commit, not at breakout. It is the same work either
    // way; the difference is that here it lands on the frame where a panel
    // closes and a line of text prints — a beat the player already expects to
    // cost something — rather than in the middle of a descent they are flying.
    /**
     * WHERE ON THE WORLD YOU ARE COMING DOWN.
     *
     * A body is a whole sphere now, not a square, so a descent has to choose a
     * point on it — and the honest choice is the one directly under the ship.
     * Two approaches to the same planet from different orbits put you on
     * genuinely different ground, which is what makes a world somewhere you can
     * go back to a second time and find something else.
     */
    const dir = this._siteUnder(body, shipPos) ?? s.profile.padDir;
    setLandingSite(s.profile, dir);
    this.frame = makeFrame(dir);
    // Sized for the altitude it STARTS at, not the one it ends at: from the top
    // of the atmosphere you can see thirty kilometres, and a cap the size of the
    // one under your boots would run out in mid-air.
    this.extent = capExtent(ENTRY_TOP);
    // START BUILDING, a slice a frame. The world is a couple of hundred
    // milliseconds of work and spending it here, on the frame the LAND button
    // was pressed, is a dozen dropped frames in front of the player — the hitch
    // half of the old transition. `tickVeil` pumps it while the envelope
    // closes, so it is finished and uploaded before there is anything to see.
    this._job = terrainJob(s.profile, this.frame, this.extent);
    this._pending = null;
    this.terrain = null;
    this.local = null;
    // The envelope starts open and the star system is still what you are
    // looking at; it closes over the next second and the world changes behind
    // it. See tickVeil.
    this.veil = 0;
    this.showGround = false;
    this._said = new Set();
    this.notify(`ENTRY INTERFACE — ${body.name}. HOLD HER NOSE UP.`);
    this.events?.emit('landing:entry', body.id);
    return true;
  }

  /**
   * MOVE THE WORLD WITH YOU.
   *
   * Called every frame with whatever is currently the anchor — the hull while
   * flying, the walker's boots while on foot — and its height above the ground.
   * Two things can start a rebuild: travelling far enough across the cap that
   * the edge is becoming relevant, or climbing far enough that the cap you have
   * is the wrong SIZE for what you can see.
   *
   * Nothing happens immediately. The new cap is built in the background over the
   * next second or two while the old one is still drawn, and only swapped in
   * when it is complete — see `_swapCap` for why the swap is invisible.
   *
   * @param {number} u anchor's local x
   * @param {number} v anchor's local z
   * @param {number} alt anchor's height above the ground
   */
  trackFrame(u, v, alt) {
    if (!this.terrain || !this.frame || this._job || this._pending) return;
    const want = capExtent(alt);
    const far = Math.hypot(u, v) > this.extent * RECENTRE_FRAC;
    const wrongSize = want > this.extent * CAP_STEP || want * CAP_STEP < this.extent;
    if (!far && !wrongSize) return;
    // The new centre is where the anchor is standing. Parallel transport, so no
    // heading, no velocity and no attitude has to be corrected afterwards.
    const frame = { c: [...this.frame.c], t: [...this.frame.t], b: [...this.frame.b] };
    slideFrame(frame, u, v, this.profile.radiusM);
    this._pending = {
      job: terrainJob(this.profile, frame, want),
      frame,
      extent: want,
      du: u,
      dv: v,
    };
  }

  /**
   * THE SWAP. The one frame on which the world moves, and nobody sees it.
   *
   * The height field is a pure function of direction, so the new cap contains
   * exactly the same ground as the old one did — the same hills, the same rocks,
   * measured at the same places. All that changes is the origin the coordinates
   * are quoted from, so every position in the old frame gets the same offset
   * subtracted and lands on the identical physical point.
   *
   * The anchor that triggered the rebuild ends up at (0,0) by construction.
   * Everything else — the parked ship while you are on foot, the surveyed sites,
   * the walker while you are flying — shifts with it.
   */
  _swapCap(built) {
    const { du, dv, frame, extent } = this._pending;
    this._pending = null;
    this.terrain = built;
    this.frame = frame;
    this.extent = extent;
    if (this.local) { this.local[0] -= du; this.local[2] -= dv; }
    // main.js owns the walker's position; it shifts on this event.
    this.events?.emit('landing:recentre', { du, dv });
    this.events?.emit('landing:terrain', built);
  }

  /**
   * Fly the descent. Called from the flight update with the live ship.
   *
   * @param {number} dt
   * @param {object} ship  the Spaceship — speed and thrust drive the outcome
   * @param {object} out   scratch the caller reads back: {shake, tint}
   */
  update(dt, ship) {
    if (this.phase === 'entry') return this._entry(dt, ship);
    if (this.phase === 'fly') return this._fly(dt, ship);
    if (this.phase === 'ascent') return this._ascent(dt, ship);
    return null;
  }

  /**
   * Run the ionisation envelope, and flip the world underneath it when it is
   * solid. Called EVERY flight frame, phase or no phase — the tail of a clear
   * outlives the descent it belonged to, and a veil that stopped decaying the
   * instant you reached orbit would freeze on the glass.
   */
  tickVeil(dt) {
    // A slice of the world, if one is still being built. Six milliseconds is
    // about a third of a 60fps frame — enough to finish inside the envelope's
    // close, small enough that the frame it lands on still ships on time.
    if (this._job) {
      const built = this._job.step(6);
      if (built) {
        this._job = null;
        this.terrain = built;
        this.local = [0, built.padHeight + ENTRY_TOP, 0];
        // The renderer needs the mesh on the GPU before the envelope thins.
        this.events?.emit('landing:terrain', built);
      }
    }
    // …and a slice of the NEXT cap, if one is being built because you have
    // travelled. Half the budget: this one runs while a perfectly good world is
    // already on screen, so it can afford to take twice as long and must not
    // cost the frame rate of the flight that triggered it.
    if (this._pending) {
      const built = this._pending.job.step(3);
      if (built) this._swapCap(built);
    }
    /**
     * THE SHEATH PEELS BACK. Owner: *"celestial bodies surfaces need to
     * smoothly appear without lags and loadings."*
     *
     * This used to be `want = 1` for the whole entry, which meant the screen
     * was solid orange from the frame you pressed LAND to the frame control
     * came back. Technically it was an ionisation envelope; in practice it was
     * a loading screen with a plasma texture on it, and the world did not
     * "appear" at all — it was revealed all at once at the bottom.
     *
     * Now the envelope is opaque only until there is a world under it — that
     * frame is still the one the star system becomes a heightfield on, and it
     * is still hidden — and then it PEELS OFF over the first stretch of the
     * descent. By about 60% of the way down the glass is clear and you are
     * flying at a landscape you can see coming up, which is both the correct
     * order of events for a re-entry (the sheath is thickest at first contact,
     * when you are fastest) and the thing the owner actually asked for.
     *
     * `showGround` is the gate rather than `terrain` because it is the state
     * that says the swap has HAPPENED. Clearing on `terrain` alone would thin
     * the plasma while the starfield was still on screen and show the player
     * the seam we spent the whole envelope hiding.
     */
    let want = 0;
    if (this.phase === 'entry') {
      want = this.showGround ? Math.max(0, 1 - this.t * 1.7) : 1;
    } else if (this.phase === 'ascent') want = this.t > 0.34 ? 1 : 0;
    const rate = want > this.veil ? VEIL_CLOSE : VEIL_CLEAR;
    const d = want - this.veil;
    this.veil += Math.max(-rate * dt, Math.min(rate * dt, d));
    this.veil = Math.max(0, Math.min(1, this.veil));
    // THE SWAP, and the only place it happens. Behind a solid envelope the
    // starfield becomes a heightfield on the way in and a heightfield becomes a
    // starfield on the way out, and in both directions the frame it happens on
    // is a frame of orange.
    // …and only once there is a world to show. A veil that opened onto an
    // unbuilt heightfield would be the hitch again, wearing a costume.
    if (this.veiled) {
      if (this.phase === 'entry') this.showGround = !!this.terrain;
      else if (this.phase === 'ascent') this.showGround = false;
    }
    if (this.phase === 'fly' || this.phase === 'down') this.showGround = true;
    if (this.phase === null) this.showGround = false;
  }

  /** Height of the hull datum above the ground directly beneath it. */
  get altitude() {
    if (!this.terrain || !this.local) return 0;
    return this.local[1] - this.terrain.heightAt(this.local[0], this.local[2]);
  }

  /**
   * ATMOSPHERIC FLIGHT. The half of a landing that is actually flown.
   *
   * The ship keeps every control it has in space — the flight controller runs
   * untouched and owns attitude and thrust — and this adds the three things a
   * planet adds: weight, ground, and an edge to the surveyed patch.
   *
   * The velocity it integrates is `ship.vel`, the controller's own, so thrust
   * authority, assist damping and inertia are all exactly what they are in
   * orbit. Nothing here re-implements flying; it only decides what flying INTO
   * a hill means.
   */
  _fly(dt, ship) {
    const T = this.terrain;
    const v = ship?.vel;
    if (!T || !v) return this.tele;

    // GROUND MODE, on for as long as there is ground: the vertical jets fire
    // along world up rather than hull up. See FlightController.
    ship.groundMode = true;

    // Weight. Scaled against THRUST_ACCEL rather than against SI, because what
    // matters is that a heavy world takes real throttle to hold altitude on and
    // a light one lets you drift — and the drive is the only thing in the
    // comparison.
    //
    // Unless the assist is holding you up. With flight assist on and no
    // vertical command, the ventral jets null the descent and the hull sits
    // where you left it; press down and you get your weight back plus the jets
    // pushing you into the ground. Assist off is the honest version: weight,
    // all the time, and you fly it.
    const g = GRAV_UNITS * this.profile.gravity;
    const lift = ship.strafe?.[1] ?? 0;
    if (ship.flightAssist && lift === 0) {
      v[1] += (0 - v[1]) * Math.min(1, HOVER_GAIN * dt);
      this._say2('hover', 'HOVER HOLD — [R] CLIMB, [F] DESCEND, ASSIST OFF FOR MANUAL');
    } else {
      v[1] -= g * dt;
    }
    // Thick air drags. A gas-giant moon lets you coast; a pressure world makes
    // you fly it the whole way down.
    const drag = 1 - Math.min(0.6, this.profile.haze * 0.5) * dt;
    v[0] *= drag; v[1] *= drag; v[2] *= drag;

    this.local[0] += v[0] * dt;
    this.local[1] += v[1] * dt;
    this.local[2] += v[2] * dt;

    const ground = T.heightAt(this.local[0], this.local[2]);
    const alt = this.local[1] - ground;
    // NO WALL. The cap follows the hull across the sphere and resizes itself
    // with the altitude, so atmospheric flight has no boundary in any direction
    // and you can fly a world for as long as you have fuel for.
    this.trackFrame(this.local[0], this.local[2], alt);
    const vs = -v[1];
    const hs = Math.hypot(v[0], v[2]);
    this.tele.alt = Math.round(alt);
    this.tele.vspeed = Math.round(vs);
    this.tele.hspeed = Math.round(hs);
    this.tele.heat = 0;
    this.tele.buffet = Math.min(1, this.profile.haze * hs / 700);

    // LEAVING. Climbing out is not a menu item: point the nose up, burn, and
    // when the ground is far enough below you the ascent takes over.
    if (alt > CEILING_ALT && v[1] > 0) {
      ship.groundMode = false;
      this._departFromFlight();
      return this.tele;
    }
    if (alt <= GEAR_CLEAR) {
      this._contact(ground, vs, hs, ship);
    }
    return this.tele;
  }

  /**
   * The gear touches. Whether that is a landing depends entirely on the two
   * numbers a real one depends on: how fast you were going down, and how fast
   * you were going along.
   */
  _contact(ground, vs, hs, ship) {
    const v = ship.vel;
    this.local[1] = ground + GEAR_CLEAR;
    // What the gear will absorb, widened by hours on the stick.
    const tol = this.prog.bonus('gearTolerance');
    const softV = SOFT_VS * tol, softH = SOFT_HS * tol;
    const hard = vs > softV || hs > softH;
    if (hard) {
      // A crash is not a fail state — it is an expensive landing, which is far
      // more interesting and keeps the world you came for reachable.
      const over = Math.max(vs - softV, 0) + Math.max(hs - softH, 0) * 0.6;
      this.systems.applyHit(10 + over * 0.55, vs > hs ? 'ventral' : 'fore');
      this.notify(`HARD CONTACT — ${Math.round(vs)} DOWN, ${Math.round(hs)} ACROSS. THE GEAR TOOK IT, MOSTLY.`);
      this.audio?.playBoom?.();
    } else {
      this.notify(`DOWN ON ${this.body.name} — ${this.profile.name}. ${this.profile.feature.toUpperCase()}.`);
    }
    v[0] = 0; v[1] = 0; v[2] = 0;
    ship.groundMode = false;
    this._settle(hard);
  }

  /** Everything that happens once the hull is at rest on the ground. */
  _settle(hard) {
    this.phase = 'down';
    this.sites = surfaceSites(this.profile).map((s) => ({ ...s, worked: 0 }));
    // Nobody has walked this one before. Worth saying, and worth paying for.
    const first = !this.visited.has(this.body.id);
    this.visited.add(this.body.id);
    this.events?.emit('landing:down', {
      id: this.body.id, hard, peakHeat: this.peakHeat, first,
    });
    if (first) this.notify(`FIRST BOOTS ON ${this.body.name}. LOGGED.`);
    this._said?.clear?.();
  }

  /** Climbed out of the atmosphere under power. */
  _departFromFlight() {
    this.phase = 'ascent';
    this.t = 1;
    this.notify(`CLIMBING OUT OF ${this.body.name}`);
    this.events?.emit('landing:launch', this.body.id);
  }

  _entry(dt, ship) {
    this.ship = ship;
    // PROGRESS IS ALTITUDE, not a clock. The hull descends through the same air
    // that is heating it, so the number the heat model reads and the number the
    // camera sees are one number — and a slow, careful entry genuinely takes
    // longer, which is what makes the fuel-versus-plating trade real.
    const T = this.terrain;
    // Still generating. Nothing has happened yet — the envelope is closing over
    // a star system and the descent has not started. Without this guard the
    // altitude getter returns zero for an unbuilt world, `t` pins to 1 and the
    // entry breaks out on its first frame.
    if (!T || !this.local) return this.tele;
    {
      const L = this.local;
      // AND YOU CAN STEER IT. The lateral half of the controller's velocity is
      // integrated all the way down, so the patch you break cloud over is one
      // you aimed at rather than one you were given. Vertical stays the entry's
      // own: inside the shock layer the drive is pointed retrograde and thrust
      // is a brake, not a lift.
      const v = ship?.vel;
      if (v) { L[0] += v[0] * dt; L[2] += v[2] * dt; }
      // Move the world with you, and resize it as the ground comes up.
      this.trackFrame(L[0], L[2], this.altitude);
      // Floor is the ground UNDER THE HULL, not the pad — you may have steered
      // over a ridge, and breaking out at pad height above a mountain would put
      // you inside it.
      L[1] = Math.max(T.heightAt(L[0], L[2]) + BREAKOUT_ALT, L[1] - this.vspeed * dt);
    }
    this.t = Math.min(1, 1 - (this.altitude - BREAKOUT_ALT) / (ENTRY_TOP - BREAKOUT_ALT));
    // Air density rises through the descent; the profile's own haze figure is
    // how thick this particular sky is.
    const rho = this.profile.haze * 0.9 + 0.1;
    const dens = rho * this.t * this.t;

    // Gravity pulls you down; the drive is the only thing that does not.
    this.vspeed += this.profile.gravity * 26 * dt;
    // RETRO BURN. Any throttle during entry is read as pointing retrograde and
    // burning, which is what an entry burn is. It costs fuel, and that is the
    // other half of the trade — the plating you save is bought with the fuel
    // you will need to leave.
    const burn = Math.min(1, Math.abs(ship?.thrust ?? 0));
    if (burn > 0.02 && this.systems.fuel > 0) {
      this.vspeed = Math.max(28, this.vspeed - burn * 78 * dt);
      this.systems.fuel = Math.max(0, this.systems.fuel - burn * 1.6 * dt);
      this._say('burn', 'RETRO BURN — SHEDDING SPEED, SPENDING FUEL');
    }
    // Aerobraking helps for free, and helps more the thicker the air. This is
    // why a toxic world is survivable at speed and an airless one is not.
    this.vspeed *= Math.max(0, 1 - dens * 0.30 * dt);
    const v = this.vspeed;
    // Skin heating goes as density × v². Real, and it is the term that makes
    // "come in slow" the right answer rather than a stylistic preference.
    // PILOTING pays back here first and most visibly: the same entry costs a
    // practised pilot less plating, because they know how to fly it.
    const heat = dens * (v / 150) * (v / 150) * this.profile.entryHeat
      * this.prog.bonus('entryHeat');
    this.peakHeat = Math.max(this.peakHeat, heat);
    this.tele.heat = heat;
    this.tele.buffet = dens * Math.min(1, v / 200);
    // REAL ALTITUDE, in the units the surface panel and the radalt already use.
    // It used to be a fraction of the progress bar rescaled to look like a
    // number, which meant the readout and the ship disagreed about where the
    // ship was for the whole descent.
    this.tele.alt = Math.round(this.altitude);
    this.tele.vspeed = Math.round(v);

    // Hull cost, if you are hot. Charged continuously so it is a slope rather
    // than a cliff, and reported once at each threshold.
    if (heat > 1.0) {
      this.systems.applyHit(heat * 5.5 * dt, 'fore');
      this._say('hot', 'SKIN TEMPERATURE OVER LIMIT — SHED SPEED OR LOSE PLATING');
    } else if (heat > 0.55) {
      this._say('warm', 'ENTRY HEATING — THE FORWARD PLATING IS GLOWING');
    }
    if (this.t >= 1) this._breakout(v);
    return this.tele;
  }

  /**
   * BREAKOUT — the plasma clears and you are flying.
   *
   * This used to be `_touchdown`: the entry timer ran out and the game simply
   * declared the ship landed, at the centre of the patch, whatever the pilot
   * had been doing. The landing is now flown (see `_fly`), so all this does is
   * build the world, put the hull over it at the speed the entry left it, and
   * give the controls back.
   *
   * The descent fuel is charged HERE rather than at rest, because it paid for
   * the entry burn — and charging it at touchdown would mean a pilot who
   * crashed had flown the descent for free.
   */
  _breakout(v) {
    this.systems.fuel = Math.max(0, this.systems.fuel
      - this.profile.landingFuel * this.prog.bonus('landingFuel'));
    this.phase = 'fly';
    this.sites = [];
    // NOTHING MOVES HERE. The hull is already where it flew to and the terrain
    // has been under it since the commit; all that changes is who is flying.
    // Lateral velocity carries straight through — it is what steered the entry
    // — and only the vertical is handed over, halved, because arriving with two
    // hundred units a second of descent and three hundred units of air is not a
    // landing, it is an impact with a countdown.
    //
    // The velocity change is invisible: at breakout the envelope is still solid
    // and only starts clearing from this frame (tickVeil), so the lurch happens
    // behind the plasma and the ground comes into view already settled.
    if (this.ship) this.ship.vel[1] = -Math.min(v, 140) * 0.5;
    this.notify(`BREAKING CLOUD OVER ${this.body.name} — ${this.profile.name}. `
      + 'YOU HAVE THE SHIP. FIND SOMEWHERE FLAT.');
    this.events?.emit('landing:breakout', this.body.id);
    this._said?.clear?.();
  }

  /**
   * Work a surface site. Same shape as a boarding compartment — oxygen in,
   * hazard roll, loot out — but a planet does not run out, so a site can be
   * worked again and the limit is always the suit.
   */
  workSite(index) {
    const site = this.sites[index];
    if (this.phase !== 'down' || !site) return;
    // Breathable air is the difference between a day's work and a countdown,
    // and it is the single most valuable thing a world can have.
    // SALVAGE makes the same job cheaper in air; the suit is the clock and
    // knowing what you are doing is what buys you time on it.
    const cost = site.o2 * (this.profile.breathable ? 0.25 : 1)
      * this.prog.bonus('siteOxygen');
    if (this.systems.oxygen < cost + 6) {
      this.notify('SUIT OXYGEN TOO LOW TO LEAVE THE SHIP — REST OR RECHARGE');
      return;
    }
    this.systems.oxygen = Math.max(0, this.systems.oxygen - cost);
    site.worked++;
    this.notify(`${site.name} — ${site.text}`);

    // The world's own hazards, not a generic table.
    const hz = this.profile.hazards;
    if (hz.length && this._rng.next() < 0.28 * this.prog.bonus('hazardOdds')) {
      const h = hz[this._rng.int(0, hz.length - 1)];
      if (h.health) this.systems.health = Math.max(1, this.systems.health - h.health);
      if (h.o2) this.systems.oxygen = Math.max(0, this.systems.oxygen - h.o2);
      if (h.rad) this.systems.radiation = Math.min(100, this.systems.radiation + h.rad);
      this.notify(`— ${h.text}`);
      this.events?.emit('landing:hazard', h.id);
    }

    // Yield. A site that has been worked before gives less, which is what
    // stops one outcrop being an infinite mine without making it finite.
    // XENOLOGY: a surveyor gets more out of the same outcrop.
    const n = Math.max(1, Math.round((site.yield - Math.floor(site.worked / 2))
      * this.prog.bonus('sampleYield')));
    const got = [];
    for (let k = 0; k < n; k++) {
      if (this._rng.next() > 0.78) continue;
      const id = site.finds[this._rng.int(0, site.finds.length - 1)];
      if (!ITEMS[id]) continue;
      const qty = ITEMS[id].stackable ? this._rng.int(1, 3) : 1;
      const added = this.inv.add(id, qty);
      if (added > 0) got.push(`${ITEMS[id].name}${added > 1 ? ` ×${added}` : ''}`);
      else { this.notify('HOLD FULL — LEFT IT ON THE GROUND'); break; }
    }
    this.notify(got.length ? `RECOVERED: ${got.join(', ').toUpperCase()}` : 'NOTHING WORTH CARRYING');
    // The event carries enough for progression to tell a rock from a relic.
    this.events?.emit('landing:worked', {
      id: site.id,
      alien: got.some((g) => /SAMPLE|ARTIFACT|SPORE|TISSUE|CHITIN/i.test(g)),
      cache: !!site.cache,
    });
  }

  /**
   * Light the drives and go — back into ATMOSPHERIC FLIGHT, not straight to
   * orbit.
   *
   * Lift-off used to jump from the ground to the ascent cinematic, which made
   * leaving a world exactly as much of a cut as arriving at one used to be. You
   * now come off the ground with the controls live and have to fly out; the
   * ascent only takes over once you are above the ceiling (see `_fly`).
   */
  launch() {
    if (this.phase !== 'down') return false;
    const cost = this.profile.landingFuel;
    if (this.systems.fuel < cost) {
      this.notify(`ASCENT NEEDS ${cost}% AND YOU HAVE ${Math.round(this.systems.fuel)}%. `
        + 'BURN SOMETHING OR SIT HERE.');
      return false;
    }
    this.systems.fuel = Math.max(0, this.systems.fuel - cost);
    this.phase = 'fly';
    // A shove off the pad so the hull is airborne before gravity gets a vote —
    // without it the first frame of flight is another ground contact.
    this.local[1] += GEAR_CLEAR * 0.6;
    if (this.ship) { this.ship.vel[0] = 0; this.ship.vel[1] = 42; this.ship.vel[2] = 0; }
    this.notify(`LIFTING OFF ${this.body.name} — CLIMB ABOVE ${CEILING_ALT} TO MAKE ORBIT`);
    return true;
  }

  _ascent(dt) {
    this.t = Math.max(0, this.t - dt / (ENTRY_SECONDS * 0.6));
    // KEEP CLIMBING. The ascent used to be a bare countdown with the hull
    // parked at whatever altitude it triggered at, so the ground sat frozen
    // underneath while a timer decided you had left. It flies out now: the
    // world genuinely falls away, and the envelope closes over it on the way.
    if (this.local && this.terrain) {
      this.local[1] += (ENTRY_TOP - CEILING_ALT) / (ENTRY_SECONDS * 0.6) * dt;
    }
    this.tele.alt = Math.round(this.altitude);
    this.tele.heat = 0;
    this.tele.buffet = this.profile.haze * this.t * 0.5;
    if (this.t <= 0) {
      this.phase = null;
      this.terrain = null;
      this.frame = null;
      this._pending = null;
      this.extent = CAP_GROUND;
      this.sites = [];
      this.notify(`${this.body.name} FALLS AWAY BELOW. ORBIT RE-ESTABLISHED.`);
      this.events?.emit('landing:orbit', this.body.id);
      this.body = null;
      this.profile = null;
    }
    return this.tele;
  }

  /** Everything the surface panel shows. */
  status() {
    if (!this.phase) return null;
    return {
      phase: this.phase,
      name: this.body?.name ?? '',
      terrain: this.profile?.name ?? '',
      feature: this.profile?.feature ?? '',
      gravity: this.profile?.gravity ?? 1,
      tempC: this.profile?.tempC ?? 0,
      atmosphere: this.profile?.atmosphere ?? 'None',
      breathable: !!this.profile?.breathable,
      fuelToLeave: this.profile?.landingFuel ?? 0,
      oxygen: this.systems.oxygen,
      fuel: this.systems.fuel,
      sites: this.sites.map((s) => ({
        id: s.id, name: s.name, o2: Math.round(s.o2 * (this.profile.breathable ? 0.25 : 1)),
        bearing: s.bearing, range: s.range, worked: s.worked,
      })),
      tele: this.tele,
      t: this.t,
      altitude: Math.round(this.altitude),
      ceiling: CEILING_ALT,
    };
  }

  _say2(key, text) { this._say(key, text); }

  _say(key, text) {
    this._said ??= new Set();
    if (this._said.has(key)) return;
    this._said.add(key);
    this.notify(text);
  }

  toJSON() { return { visited: [...this.visited] }; }
  fromJSON(d) { this.visited = new Set(d?.visited ?? []); }
}
