/**
 * FactionSystem — how the four powers of the survey lanes regard you (Phase 7,
 * context/03 factions). Reputation is a single −100..+100 number per faction,
 * moved by what you do: splashing Keth fighters clears the extraction lanes
 * (Kestrel + Vrenn approve, Keth do not), trading builds standing with the
 * merchants, work orders please the company. Standing tiers gate prices (Vrenn
 * counters read your number) and colour the journal. Persisted in the save.
 */

export const FACTIONS = [
  { id: 'kestrel', name: 'KESTREL EXTRACTION & SALVAGE', start: 20,
    blurb: 'Your employer. The account, the record, the tab with your name on it.' },
  { id: 'vrenn', name: 'VRENN COMBINE', start: 0,
    blurb: 'Warm-blooded traders. Fair, patient, and they remember every gram.' },
  { id: 'keth', name: 'KETH WAR-CLANS', start: -30,
    blurb: 'They press the extraction lanes and take the black boxes. Not the drives.' },
  { id: 'drift', name: 'THE DRIFT', start: -40,
    blurb: 'Machine intelligence that opens hulls like fruit. It does not negotiate.' },
];

const TIERS = [
  { at: -60, name: 'HOSTILE', col: '#aa2020' },
  { at: -20, name: 'WARY', col: '#a06030' },
  { at: 20, name: 'NEUTRAL', col: '#c09050' },
  { at: 60, name: 'FRIENDLY', col: '#8aa060' },
  { at: 101, name: 'ALLIED', col: '#6ab0a0' },
];

export function standingTier(v) {
  for (const t of TIERS) if (v < t.at) return t;
  return TIERS[TIERS.length - 1];
}

/**
 * Which power a hostile hull type belongs to.
 *
 * Enemy types are namespaced by family (`keth`, `keth_corvette`, `keth_lancer`,
 * `drift`, `drift_picket`, `drift_lance`) precisely so that one prefix test
 * covers every present and future variant. Anything unrecognised returns null
 * and scores nothing rather than defaulting into somebody's ledger.
 */
export function factionOf(type) {
  if (typeof type !== 'string') return null;
  for (const f of FACTIONS) if (type === f.id || type.startsWith(`${f.id}_`)) return f.id;
  return null;
}

/** How much a kill is worth, relative to a plain fighter. */
function hullWeight(type) {
  if (type === 'keth_corvette') return 3;
  if (type === 'drift_lance' || type === 'drift_picket') return 1.4;
  return 1;
}

export class FactionSystem {
  /**
   * @param {import('../core/EventBus.js').EventBus} events
   * @param {(text:string)=>void} notify
   */
  constructor(events, notify) {
    this.events = events;
    this.notify = notify;
    this.rep = {};
    for (const f of FACTIONS) this.rep[f.id] = f.start;

    events.on('combat:kill', (type) => {
      // clearing hostiles pleases the powers that share the lanes.
      // Match the FAMILY, not the exact hull: a corvette, a lancer and a picket
      // all belong to somebody, and matching `=== 'keth'` quietly scored every
      // variant as zero — you could break a warship in half for no reaction at all.
      const f = factionOf(type);
      if (f) this._shift({ [f]: -8 * hullWeight(type), kestrel: 3, vrenn: 1 });
    });
    // firing first on a faction that was holding off: a real diplomatic cost,
    // heavier than a kill in a fight they started
    events.on('combat:provoked', (type) => {
      const f = factionOf(type);
      if (f) this._shift({ [f]: -25 });
      // Kestrel logs it too — the company hates paperwork
      this._shift({ kestrel: -4 }, true);
    });
    /**
     * Cutting into a hull whose crew is still aboard.
     *
     * Heavier than a kill and lighter than firing first, and the reasoning is
     * the same one that makes provocation expensive: a fight in open space is a
     * fight, but going through a crippled ship compartment by compartment while
     * the people who were flying it are still in there is the kind of thing a
     * faction tells other factions about. Kestrel does not want it in the log
     * either — the company's objection is liability, not ethics.
     */
    events.on('boarding:hostile', ({ faction }) => {
      if (faction) this._shift({ [faction]: -14 });
      this._shift({ kestrel: -3 }, true);
    });
    events.on('trade:sold', () => this._shift({ vrenn: 0.5, kestrel: 0.2 }, true));
    events.on('trade:bought', () => this._shift({ vrenn: 0.3 }, true));
    events.on('quest:complete', () => this._shift({ kestrel: 6, vrenn: 1 }));
  }

  _shift(deltas, quiet = false) {
    for (const [id, d] of Object.entries(deltas)) {
      if (this.rep[id] == null) continue;
      const before = standingTier(this.rep[id]).name;
      this.rep[id] = Math.max(-100, Math.min(100, this.rep[id] + d));
      const after = standingTier(this.rep[id]).name;
      if (!quiet && after !== before) {
        const f = FACTIONS.find((x) => x.id === id);
        this.notify?.(`STANDING WITH ${f.name}: ${after}`);
        this.events.emit('faction:tier', { id, tier: after });
      }
    }
  }

  /**
   * A deliberate one-off standing change from something the player chose to do
   * — signing a writ at a harbour office, doing a factor a favour. Public,
   * unlike `_shift`, because the caller is a game action rather than an event
   * handler and the announcement is the point.
   */
  grant(deltas) { this._shift(deltas); }

  standing(id) { return this.rep[id] ?? 0; }
  tier(id) { return standingTier(this.rep[id] ?? 0); }

  /**
   * Trade price modifier at a station, driven by who runs it. Vrenn counters
   * discount for friends and surcharge for the wary; 1.0 is neutral.
   * @param {object} station body record (may carry .faction)
   */
  priceModifier(station) {
    const fac = station?.faction ?? (/VRENN|REDFALL/i.test(station?.name ?? '') ? 'vrenn' : 'kestrel');
    const v = this.rep[fac] ?? 0;
    // ±15% across the full standing range, clamped
    return 1 - Math.max(-0.15, Math.min(0.15, v / 100 * 0.15 * 5));
  }

  rows() {
    return FACTIONS.map((f) => ({ faction: f, value: this.rep[f.id], tier: standingTier(this.rep[f.id]) }));
  }

  toJSON() { return { ...this.rep }; }
  fromJSON(d) {
    if (!d) return;
    for (const f of FACTIONS) if (typeof d[f.id] === 'number') this.rep[f.id] = d[f.id];
  }
}
