/**
 * Loot — what searching a container yields.
 *
 * The tables moved to data/LootTables.js; this is the roller, and it is where
 * the three things that make a search interesting are actually applied: the
 * container's CLASS, the rare SHELF, and the PILOT's salvage proficiency.
 *
 * Seeded per container per save, so a searched box stays searched and a reboot
 * does not reshuffle the ship. The seed folds in the pilot's salvage level as
 * well, which is deliberate and worth stating: getting better at looking
 * genuinely changes what is in the box, rather than adding a second roll on top
 * of a fixed answer. A locker you could not open anything out of at salvage 0
 * is not the same locker at salvage 6.
 */
import { RNG } from '../utils/RNG.js';
import { TABLES, GENERIC, TIERS, RARE_GATE, tableFor } from '../data/LootTables.js';

export { TIERS };

/**
 * Roll a container.
 *
 * @param {string} label      what the interactable calls itself
 * @param {number} salt       a stable per-container index
 * @param {object} [opts]
 * @param {string} [opts.tier]  key into TIERS — where this container IS
 * @param {number} [opts.find]  absolute bonus to every common chance (0..1)
 * @param {number} [opts.rare]  absolute bonus to the rare gate (0..1)
 * @returns {{items: Array<{id:string, qty:number}>, rare: boolean, tier: string}}
 */
export function rollContainer(label, salt = 0, opts = {}) {
  const tierKey = opts.tier ?? 'ship';
  const tier = TIERS[tierKey] ?? 1;
  const find = opts.find ?? 0;
  const rareBias = opts.rare ?? 0;

  let h = 0x811c9dc5;
  // The skill goes in the seed, not just in the odds — see the header.
  const s = `${label}|${salt}|${tierKey}|${Math.round(find * 100)}`;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  const rng = new RNG(h >>> 0);

  const table = tableFor(label);
  const out = [];
  for (const [id, lo, hi, chance] of table.common ?? []) {
    // MULTIPLICATIVE, not additive. An absolute bonus makes a 0.08 row and a
    // 0.6 row equally likely at high skill, which flattens every table into
    // "you get one of everything"; scaling keeps the shape of the table and
    // just tilts it your way.
    if (rng.chance(Math.min(0.95, chance * (tier + find)))) out.push({ id, qty: rng.int(lo, hi) });
  }

  /**
   * THE RARE SHELF. One gate for the whole container rather than a chance per
   * rare row: either this box had something good in it or it did not, which is
   * how a search reads, and it stops a lucky roll producing four rare items at
   * once.
   */
  const gate = RARE_GATE * tier + rareBias;
  let rare = false;
  if ((table.rare ?? []).length && rng.chance(Math.min(0.72, gate))) {
    rare = true;
    // Pick ONE row off the shelf, weighted by its own chance.
    const rows = table.rare;
    let total = 0;
    for (const r of rows) total += r[3];
    let pick = rng.next() * total;
    for (const [id, lo, hi, w] of rows) {
      pick -= w;
      if (pick <= 0) { out.push({ id, qty: rng.int(lo, hi) }); break; }
    }
  }

  // Never fully empty on the first search — a lone scrap keeps it worthwhile.
  if (!out.length && rng.chance(0.6)) out.push({ id: 'salvage_plating_scrap', qty: 1 });
  return { items: out, rare, tier: tierKey };
}

/** Back-compatible shorthand: just the items, at ship tier, unskilled. */
export function rollLoot(label, salt = 0, opts = {}) {
  return rollContainer(label, salt, opts).items;
}

/** Exposed so a probe can assert the table set is intact. */
export const TABLE_COUNT = TABLES.length;
export const GENERIC_TABLE = GENERIC;
