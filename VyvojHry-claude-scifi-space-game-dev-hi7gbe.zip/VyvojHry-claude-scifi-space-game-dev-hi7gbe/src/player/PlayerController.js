/**
 * PlayerController — walking-mode movement: WASD relative to view yaw, sprint,
 * crouch (with headroom check), jump, gravity, head bob, footstep events and
 * the interact raycast. All collision goes through CollisionMap.move.
 */
import { PLAYER } from '../core/Constants.js';
import { Vec3, clamp } from '../utils/MathUtils.js';
import { Settings } from '../core/Settings.js';

export class PlayerController {
  /**
   * @param {import('./Player.js').Player} player
   * @param {import('../core/InputManager.js').InputManager} input
   * @param {import('../interior/ShipMap.js').ShipMap} shipMap
   * @param {import('../core/EventBus.js').EventBus} events
   */
  constructor(player, input, shipMap, events) {
    this.player = player;
    this.input = input;
    this.shipMap = shipMap;
    this.events = events;

    this.velocity = Vec3.create();
    this.grounded = true;
    this.crouched = false;
    this.eyeHeight = PLAYER.EYE_HEIGHT;
    this.bobPhase = 0;
    this.bobOffset = 0;
    this.stepDistance = 0;
    /** @type {{rec: object, dist: number}|null} current interact target */
    this.interactTarget = null;
    this._moveResult = { grounded: false, hitY: false };
    this._delta = Vec3.create();
  }

  /**
   * Mouse/touch look, applied ONCE PER RENDERED FRAME rather than per fixed
   * simulation step.
   *
   * It used to live at the top of update(), which quantised aiming to whenever a
   * fixed step happened to land: a frame that ran no step held the delta over to
   * the next one (a frame of latency, then a jump), and a frame that ran two
   * steps applied everything in the first and nothing in the second. Look is raw
   * input with no physics in it, so it belongs on the frame clock — that is also
   * what makes it feel immediate on a 120Hz display, where half the frames
   * advance no simulation at all.
   */
  applyLook() {
    const [mdx, mdy] = this.input.consumeMouseDelta();
    if (mdx || mdy) this.player.camera.applyMouse(mdx, mdy);
  }

  /** @param {object} game facade passed to interact callbacks */
  update(dt, game) {
    const input = this.input;
    const cam = this.player.camera;
    const pos = this.player.position;

    // -- crouch (hold) -------------------------------------------------------
    const wantCrouch = input.isDown('crouch');
    if (wantCrouch !== this.crouched) {
      if (wantCrouch) {
        this.crouched = true;
      } else if (this._headroomToStand(pos)) {
        this.crouched = false;
      }
    }
    const targetEye = this.crouched ? PLAYER.EYE_HEIGHT_CROUCH : PLAYER.EYE_HEIGHT;
    this.eyeHeight += (targetEye - this.eyeHeight) * clamp(dt * PLAYER.CROUCH_LERP_SPEED, 0, 1);

    // -- planar movement -------------------------------------------------------
    let ix = 0, iz = 0;
    if (input.isDown('forward')) iz += 1;
    if (input.isDown('back')) iz -= 1;
    if (input.isDown('right')) ix += 1;
    if (input.isDown('left')) ix -= 1;
    // analog touch joystick adds in; partial deflection = partial speed
    ix += input.moveAxis[0];
    iz += input.moveAxis[1];
    const len = Math.hypot(ix, iz);
    if (len > 1) { ix /= len; iz /= len; }

    const sy = Math.sin(cam.yaw), cy = Math.cos(cam.yaw);
    // forward = (-sin yaw, -cos yaw), right = (cos yaw, -sin yaw)
    const wishX = iz * -sy + ix * cy;
    const wishZ = iz * -cy + ix * -sy;

    let maxSpeed = this.crouched
      ? PLAYER.CROUCH_SPEED
      : input.isDown('sprint') ? PLAYER.SPRINT_SPEED : PLAYER.WALK_SPEED;
    // reading the scanner means eyes down and a careful shuffle (context/04 §5)
    if (game?.scanner?.raised) maxSpeed *= 0.55;

    const hasInput = ix !== 0 || iz !== 0;
    const accel = hasInput ? PLAYER.ACCEL : PLAYER.DECEL;
    const targetVX = wishX * maxSpeed;
    const targetVZ = wishZ * maxSpeed;
    this.velocity[0] += clamp(targetVX - this.velocity[0], -accel * dt, accel * dt);
    this.velocity[2] += clamp(targetVZ - this.velocity[2], -accel * dt, accel * dt);

    // -- vertical -----------------------------------------------------------------
    if (this.grounded && input.wasPressed('jump') && !this.crouched) {
      this.velocity[1] = PLAYER.JUMP_SPEED;
      this.grounded = false;
    }
    this.velocity[1] -= PLAYER.GRAVITY * dt;

    // -- resolve against the world --------------------------------------------------
    const height = this.crouched ? PLAYER.HEIGHT_CROUCH : PLAYER.HEIGHT;
    const half = [PLAYER.RADIUS, height / 2, PLAYER.RADIUS];
    const center = [pos[0], pos[1] + height / 2, pos[2]];
    Vec3.set(this._delta, this.velocity[0] * dt, this.velocity[1] * dt, this.velocity[2] * dt);
    this.shipMap.collision.move(center, half, this._delta, this._moveResult);
    if (this._moveResult.hitY) this.velocity[1] = 0;
    this.grounded = this._moveResult.grounded;
    const prevX = pos[0], prevZ = pos[2];
    Vec3.set(pos, center[0], center[1] - height / 2, center[2]);

    // -- head bob + footsteps (amplitude/frequency per context/02 §3) ---------------
    const planarSpeed = Math.hypot(pos[0] - prevX, pos[2] - prevZ) / dt;
    if (this.grounded && planarSpeed > 0.2) {
      this.bobPhase += dt * PLAYER.HEAD_BOB_FREQ_HZ * (planarSpeed / PLAYER.WALK_SPEED) * Math.PI * 2;
      // Off is a real option, not a nicety: a 1.8 Hz vertical oscillation is
      // one of the two things (with a narrow FOV) that reliably makes people
      // motion-sick in a first-person game, and this game is first-person
      // everywhere by pillar 1 — there is no third-person view to escape to.
      this.bobOffset = Settings.get('headBob') === false ? 0
        : Math.sin(this.bobPhase) * PLAYER.HEAD_BOB_AMPLITUDE;
      this.stepDistance += planarSpeed * dt;
      if (this.stepDistance >= PLAYER.FOOTSTEP_STRIDE) {
        this.stepDistance = 0;
        const zone = this.shipMap.zoneAt(pos[0], pos[2]);
        this.events.emit('player:step', {
          surface: zone?.surface ?? 'metal',
          sprint: planarSpeed > PLAYER.WALK_SPEED + 0.2,
          crouch: this.crouched,
        });
      }
    } else {
      this.bobOffset *= Math.max(0, 1 - dt * 8);
    }

    cam.update(pos, this.eyeHeight, this.bobOffset);

    // -- interaction -------------------------------------------------------------------
    this.interactTarget = this.shipMap.raycastInteract(cam.eye, cam.forward, PLAYER.INTERACT_DISTANCE);
    if (this.interactTarget && input.wasPressed('interact')) {
      const rec = this.interactTarget.rec;
      // containers yield loot on first search (game.tryLoot claims the press);
      // afterwards — and for everything else — the prop's own handler runs
      if (!game.tryLoot?.(rec)) rec.onInteract(game);
      this.events.emit('player:interact', rec);
    }

    if (input.wasPressed('flashlight')) {
      this.player.light.toggle();
    }
  }

  /** Can we stand up here without clipping a lintel or duct? */
  _headroomToStand(pos) {
    const half = [PLAYER.RADIUS, PLAYER.HEIGHT / 2, PLAYER.RADIUS];
    const center = [pos[0], pos[1] + PLAYER.HEIGHT / 2 + 0.02, pos[2]];
    return !this.shipMap.collision.overlaps(
      [center[0] - half[0], center[1] - half[1], center[2] - half[2]],
      [center[0] + half[0], center[1] + half[1], center[2] + half[2]],
    );
  }
}
