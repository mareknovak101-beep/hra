/**
 * PlayerLight — helmet flashlight state. The beam itself is shader-side
 * (dedicated uniforms per context/02 §4); parameters live in
 * Constants.LIGHTING.HELMET_LIGHT.
 */
export class PlayerLight {
  /** @param {import('../core/EventBus.js').EventBus} events */
  constructor(events) {
    this.events = events;
    this.on = true; // you wake up with the lamp lit — the ship is dark
  }

  toggle() {
    this.on = !this.on;
    this.events.emit('player:flashlight', this.on);
  }
}
