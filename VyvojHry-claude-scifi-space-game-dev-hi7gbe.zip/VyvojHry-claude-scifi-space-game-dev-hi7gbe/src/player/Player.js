/**
 * Player — position, camera, helmet light, controller and (for now) a static
 * stat block. Survival.js (Phase 5) will take over the numbers; the HUD reads
 * from here either way, so the swap is invisible to the UI.
 */
import { Vec3 } from '../utils/MathUtils.js';
import { PlayerCamera } from './PlayerCamera.js';
import { PlayerLight } from './PlayerLight.js';
import { PlayerController } from './PlayerController.js';

export class Player {
  /**
   * @param {import('../core/InputManager.js').InputManager} input
   * @param {import('../interior/ShipMap.js').ShipMap} shipMap
   * @param {import('../core/EventBus.js').EventBus} events
   * @param {{pos:number[], yaw:number, pitch:number}} spawn
   */
  constructor(input, shipMap, events, spawn) {
    this.position = Vec3.create(spawn.pos[0], spawn.pos[1], spawn.pos[2]);
    this.camera = new PlayerCamera();
    this.camera.yaw = spawn.yaw;
    this.camera.pitch = spawn.pitch;
    this.light = new PlayerLight(events);
    this.controller = new PlayerController(this, input, shipMap, events);
    this.shipMap = shipMap;

    // Placeholder vitals until Survival.js (Phase 5) — HUD-facing contract.
    this.stats = {
      health: 89, oxygen: 76, shield: 78,
      ammo: '24/60', gravity: '1.0',
      fuel: 87, speed: '0.0 AU/H', temp: '21°', rad: 'LOW',
      o2tank: 94, hull: 91,
    };
  }

  update(dt, game) {
    this.controller.update(dt, game);
  }

  get zone() {
    return this.shipMap.zoneAt(this.position[0], this.position[2]);
  }
}
