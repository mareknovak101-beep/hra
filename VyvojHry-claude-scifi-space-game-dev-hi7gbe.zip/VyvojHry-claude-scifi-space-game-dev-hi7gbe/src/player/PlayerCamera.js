/**
 * PlayerCamera — THE camera (context/02 §3). First person, always; it never
 * leaves the player's head. Piloting (Phase 3) will lerp this same camera into
 * the seat eye position — no pull-back, no exterior reveal, ever.
 */
import { RENDER, PLAYER } from '../core/Constants.js';
import { Settings } from '../core/Settings.js';
import { Mat4, Vec3, clamp, forwardFromAngles, DEG2RAD } from '../utils/MathUtils.js';

export class PlayerCamera {
  constructor() {
    this.yaw = 0;
    this.pitch = 0;
    this.eye = Vec3.create();
    this.forward = Vec3.create(0, 0, -1);
    /**
     * Interpolation snapshots. `stepEye` is where the fixed simulation last put
     * the eye and `prevEye` is where it was the step before; `eye` is what gets
     * drawn, and between steps it sits somewhere along that segment.
     *
     * This is what stops the walk from juddering. The sim runs at a fixed 60Hz
     * while requestAnimationFrame runs at the display's rate, so frames advance
     * the sim twice, once or not at all — and a frame that advanced it zero
     * times draws the eye in exactly the same place as the frame before, which
     * on a first-person camera reads as a stutter even at a solid 60fps.
     */
    this.prevEye = Vec3.create();
    this.stepEye = Vec3.create();
    this._interp = false; // false until a step has actually run

    this.projection = Mat4.create();
    this.view = Mat4.create();
    this.viewProjection = Mat4.create();
    this._tmpA = Mat4.create();
    this._tmpB = Mat4.create();
    this._fov = 0;
    this._updateProjection();
  }

  /** Rebuild the projection when the FOV setting changes (cheap; called/frame). */
  _updateProjection() {
    const fov = Settings.get('fov') ?? RENDER.FOV_DEG;
    if (fov === this._fov) return;
    this._fov = fov;
    Mat4.perspective(this.projection, fov * DEG2RAD, RENDER.WIDTH / RENDER.HEIGHT, RENDER.NEAR, RENDER.FAR);
  }

  applyMouse(dx, dy) {
    const sens = PLAYER.MOUSE_SENSITIVITY * (Settings.get('lookSens') ?? 1);
    const inv = Settings.get('invertY') ? -1 : 1;
    this.yaw -= dx * sens;
    this.pitch -= dy * sens * inv;
    const limit = PLAYER.PITCH_LIMIT_DEG * DEG2RAD;
    this.pitch = clamp(this.pitch, -limit, limit);
  }

  /**
   * Add a pitch impulse in RADIANS, clamped the same way look input is.
   *
   * Recoil goes through here rather than through `applyMouse`, because
   * `applyMouse` scales by the player's look-sensitivity setting — routing a kick
   * through it would make a heavy pistol jump twice as far for a player who likes
   * a fast mouse, which is nonsense. A recoil impulse is a property of the weapon.
   */
  kickPitch(rad) {
    const limit = PLAYER.PITCH_LIMIT_DEG * DEG2RAD;
    this.pitch = clamp(this.pitch + rad, -limit, limit);
  }

  /**
   * Open a fixed simulation step: the eye's current simulated spot becomes the
   * previous one, so whatever this step produces can be interpolated against it.
   * Must be called once per fixed step, before anything moves the player.
   */
  beginStep() {
    Vec3.copy(this.prevEye, this.stepEye);
    this._interp = true;
  }

  /**
   * Resolve the drawn eye for this frame. `alpha` is the accumulator's fraction
   * of a fixed step, so 0 is exactly on the last step and 1 is on the next one.
   *
   * Orientation is NOT interpolated: yaw and pitch come straight from raw look
   * input applied once per rendered frame, so they are already current and
   * lerping them would only add back the latency this is here to remove.
   */
  resolve(alpha) {
    if (!this._interp) return;
    const t = alpha < 0 ? 0 : alpha > 1 ? 1 : alpha;
    Vec3.set(this.eye,
      this.prevEye[0] + (this.stepEye[0] - this.prevEye[0]) * t,
      this.prevEye[1] + (this.stepEye[1] - this.prevEye[1]) * t,
      this.prevEye[2] + (this.stepEye[2] - this.prevEye[2]) * t);
    this._recompute();
  }

  /** Recompute matrices from feet position + current eye height + bob. */
  update(feet, eyeHeight, bobOffset) {
    Vec3.set(this.stepEye, feet[0], feet[1] + eyeHeight + bobOffset, feet[2]);
    // `eye` tracks the exact step position during the step itself — the interact
    // raycast and the helmet light both read it, and they must agree with the
    // collision result, not with a position part-way to it.
    Vec3.copy(this.eye, this.stepEye);
    this._recompute();
  }

  /**
   * Explicit pose — used by the seat transition and while seated. Still the
   * same first-person camera; the pose is always an eye inside the ship.
   */
  setPose(eye, yaw, pitch) {
    Vec3.copy(this.stepEye, eye);
    Vec3.copy(this.eye, eye);
    this.yaw = yaw;
    this.pitch = pitch;
    this._recompute();
  }

  /**
   * Drop the interpolation history — call after a teleport, a seat transition or
   * a warp arrival. Without it the next frame lerps from wherever the eye used
   * to be to wherever it now is, drawing one frame of a smear across the ship.
   */
  snapHistory() {
    Vec3.copy(this.prevEye, this.stepEye);
    Vec3.copy(this.eye, this.stepEye);
    this._recompute();
  }

  _recompute() {
    this._updateProjection();
    forwardFromAngles(this.forward, this.yaw, this.pitch);
    Mat4.fpsView(this.view, this.eye, this.yaw, this.pitch, this._tmpA, this._tmpB);
    Mat4.multiply(this.viewProjection, this.projection, this.view);
  }
}
