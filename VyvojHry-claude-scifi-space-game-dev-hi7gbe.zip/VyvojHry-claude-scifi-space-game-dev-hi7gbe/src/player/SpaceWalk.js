/**
 * SPACE WALK — outside the hull, in a suit, on cold gas.
 *
 * THE ONE RULE THIS DOES NOT BREAK. `CLAUDE.md` pillar 1: walking is always
 * first person, the viewpoint never detaches from the player's own eyes. An EVA
 * is walking, so this is a first-person camera at the suit's helmet and nothing
 * else. The hull cam is a piloting mode and stays one.
 *
 * WHAT MAKES IT DIFFERENT FROM WALKING. There is no floor and no friction, so
 * every input is an impulse you have to cancel yourself, and the thing that
 * kills you is not a fall — it is arithmetic. Three budgets run down at once:
 *
 *   OXYGEN   the clock. Drains whatever you do, faster while working.
 *   JET      the cold-gas pack. This is the one that actually strands people:
 *            burn it accelerating away and you have nothing left to stop with,
 *            and stopping costs exactly what starting cost.
 *   TETHER   forty metres of braid. Inside it you are always recoverable; the
 *            reel will winch you home. Outside it you are on the jet and your
 *            own judgement, and the game says so plainly rather than stopping
 *            you — an EVA that could not go wrong would not be worth doing.
 *
 * MOTION IS RELATIVE TO THE SHIP. The Aethon is doing hundreds of units a
 * second through a star system and the suit has no drive worth the name, so the
 * whole simulation runs in the ship's frame: you and it share its velocity and
 * what you fly is the difference. This is also what makes the tether a fixed
 * length rather than a rope being paid out at orbital speed.
 */
import { Vec3 } from '../utils/MathUtils.js';

const WORLD_UP = [0, 1, 0];

/** Metres of braid. Past this the reel is out and only the jet gets you back. */
export const TETHER_LEN = 44;

/**
 * THE HULL, IN THE SUIT'S OWN FRAME (0.49.0).
 *
 * The Aethon measures 27.5 across and 96.7 long, and the airlock used to be at
 * (9, −1, 4) — which is nine units from the CENTRELINE of a hull whose skin is
 * at 13.8. The suit therefore started INSIDE the ship, with the plating filling
 * the whole frame from a range the HUD read as 3 m, and every report of the
 * space walk being "stuck" is that: you were not stuck, you were embedded.
 *
 * These are the real numbers. Everything the EVA places on the hull — the
 * hatch, the handholds — is derived from them, so a change to the model is one
 * edit rather than a hunt.
 */
const HULL_HALF_W = 13.8;
const HULL_Z_FORE = 45.8;
const HULL_Z_AFT = -50.9;

/**
 * HANDHOLDS. The owner's ask, verbatim: *"there will be places to hold, and
 * interact."*
 *
 * A space walk with nothing but a jet is a flying game with a fuel gauge. What
 * makes an EVA an EVA is that the hull is the ground: you move along it hand
 * over hand, you stop by grabbing something, and the gas is for the gaps. Every
 * hold nulls your velocity when you take it and anchors you until you let go,
 * so working your way to the far end of the ship costs almost nothing — and
 * pushing off across open space to a wreck costs everything.
 *
 * Placed in a double row down each flank plus the spine and the belly, which is
 * where a real hull puts them: along the seams, where there is structure to
 * bolt to.
 */
function buildHolds() {
  const out = [];
  const zs = [-44, -32, -20, -8, 4, 16, 28, 40];
  for (const z of zs) {
    const t = (z - HULL_Z_AFT) / (HULL_Z_FORE - HULL_Z_AFT);
    // The hull tapers fore and aft; the rail follows it in rather than floating
    // off the nose.
    const w = HULL_HALF_W * (0.55 + 0.45 * Math.sin(Math.PI * Math.min(1, Math.max(0, t))));
    out.push({ pos: [w + 1.1, -1.0, z], label: 'STARBOARD RAIL' });
    out.push({ pos: [-w - 1.1, -1.0, z], label: 'PORT RAIL' });
  }
  for (const z of [-36, -12, 12, 34]) {
    out.push({ pos: [0, HULL_HALF_W * 0.62 + 1.1, z], label: 'SPINE RAIL' });
    out.push({ pos: [0, -HULL_HALF_W * 0.62 - 1.1, z], label: 'KEEL RAIL' });
  }
  return out;
}

/** How close a hand has to be to close on a rail. */
const HOLD_REACH = 3.4;
/** Cold-gas thrust, units/s². Deliberately feeble: this is not a jetpack. */
const JET_ACCEL = 3.4;
/** Fractions of the pack spent per second at full throttle. */
const JET_BURN = 5.2;
/** Suit oxygen per second, idle and while thrusting. */
const O2_IDLE = 0.30, O2_WORK = 0.55;
/** How close to the airlock you have to be to get back in. */
const HATCH_REACH = 6.0;
/**
 * How far off ANOTHER hull's skin you can be and still get a hand on it.
 *
 * Larger than the airlock's own reach, and it has to be: your lock is a door
 * you know the position of to the centimetre, and a wreck is a hull you are
 * closing on in the dark looking for somewhere to cut. Ten metres is "close
 * enough to be committed", which is the moment the prompt should appear.
 */
const BOARD_REACH = 10.0;

export class SpaceWalk {
  /**
   * @param {object} deps
   * @param {import('../ship/ShipSystems.js').ShipSystems} deps.systems
   * @param {import('../core/EventBus.js').EventBus} deps.events
   * @param {(t:string)=>void} deps.notify
   */
  constructor({ systems, events, notify, audio = null }) {
    this.systems = systems;
    this.events = events;
    this.notify = notify ?? (() => {});
    this.audio = audio;
    this.active = false;
    /** Position and velocity in the SHIP'S frame — see the header note. */
    this.pos = Vec3.create();
    this.vel = Vec3.create();
    /**
     * Where the airlock hatch sits in that frame; you leave from and return to
     * it. ON THE SKIN — see HULL_HALF_W above for why this number matters.
     */
    this.hatch = Vec3.create(HULL_HALF_W + 1.4, -1.0, 4.0);
    /** Rails you can take hold of. Fixed to the hull, so fixed in this frame. */
    this.holds = buildHolds();
    /** The rail currently in your fist, or null. */
    this.held = null;
    /**
     * OTHER HULLS, in the suit's frame.
     *
     * Owner ask: *"space walk need to be used when boarding enemy ship /
     * shipwreck."* Boarding used to be a button on the approach panel — you
     * pressed INSPECT in the cockpit and arrived inside. That skipped the only
     * part of it that was ever going to be frightening.
     *
     * Now the wreck is out there at its real separation and you have to cross
     * to it on the pack, which means unclipping the tether (44 m of braid does
     * not reach anything), spending gas you will need to get back, and doing
     * the whole arithmetic of an EVA with a hull at the far end of it. The list
     * is refreshed each frame by the caller, because what is near the ship is
     * the caller's business — this module only measures distance to it.
     *
     * @type {Array<{pos:number[], r:number, label:string, ref:object}>}
     */
    this.targets = [];
    /**
     * PUSHING OFF. Seconds of the exit left to run.
     *
     * The walk used to begin with the suit already outside and already moving,
     * which is a cut however short it is. It now starts IN the lock's mouth and
     * slides out under the door's own push, so the first two seconds are the
     * hull going past you at arm's length — and by the time you have control
     * you are clear of the plating and looking at the ship you came out of.
     */
    this.exit = 0;
    /** Cold-gas pack, 0..100. */
    this.jet = 100;
    /** Seconds outside, for the log. */
    this.elapsed = 0;
    /** Latched warnings, so each one is said once rather than every frame. */
    this._said = new Set();
    /** Scratch basis vectors, rebuilt per frame from the helmet's forward. */
    this._r = Vec3.create(1, 0, 0);
    this._u = Vec3.create(0, 1, 0);
    this._d = Vec3.create();
  }

  /** Distance from the hatch — the number the suit HUD leads with. */
  get range() { return Vec3.distance(this.pos, this.hatch); }
  get tethered() { return !this.freeFlight && this.range <= TETHER_LEN; }

  /**
   * UNCLIP. Owner ask: "going out into the open space, I want to fly around the
   * ship."
   *
   * Forty-four metres of braid is enough to inspect a hull plate and not enough
   * to fly around anything — on a ship sixty units long the line runs out before
   * you have cleared the nose. Off the line there is no line: the jet and the
   * suit are the whole budget, and the reel cannot save you, so the number that
   * matters becomes how much gas you have left to get BACK. That is a better
   * constraint than a rope because it is one you spend rather than one you hit.
   *
   * Refused below a reserve, because unclipping with a quarter tank is not a
   * decision, it is the end of the save.
   */
  toggleFreeFlight() {
    if (!this.freeFlight) {
      if (this.jet < 45) {
        this._say('JET TOO LOW TO UNCLIP — YOU WOULD NOT GET BACK');
        return false;
      }
      this.freeFlight = true;
      this._say('TETHER RELEASED — THE JET IS ALL THAT BRINGS YOU HOME');
      return true;
    }
    this.freeFlight = false;
    this._said?.delete?.('tether');
    this._said?.delete?.('reel');
    this._say(this.range > TETHER_LEN
      ? 'TETHER STOWED — TOO FAR OUT TO CLIP ON. FLY BACK.'
      : 'CLIPPED ON');
    return true;
  }

  /** One-off line, no key needed — `_warn` is for repeating conditions. */
  _say(text) { this.notify?.(text); }
  get canEnter() { return this.range <= HATCH_REACH; }
  /** True while the door is still pushing you out and you have no control yet. */
  get exiting() { return this.exit > 0; }

  /**
   * The nearest rail within reach, or null. Read every frame by the HUD so the
   * prompt appears as your hand comes up to one — the same affordance a locker
   * has inside, which is the point: a hull is a place, not a boundary.
   */
  nearHold() {
    let best = null, bd = HOLD_REACH * HOLD_REACH;
    for (const h of this.holds) {
      const dx = this.pos[0] - h.pos[0];
      const dy = this.pos[1] - h.pos[1];
      const dz = this.pos[2] - h.pos[2];
      const d2 = dx * dx + dy * dy + dz * dz;
      if (d2 < bd) { bd = d2; best = h; }
    }
    return best;
  }

  /**
   * The nearest boardable hull whose SKIN is within reach, or null.
   *
   * Distance is measured to the surface (centre minus radius) rather than to
   * the centre, so a 40-unit hulk and a 6-unit shuttle both become boardable
   * when you are the same distance off their plating — which is what a hand
   * reaching for a hull actually cares about.
   */
  nearTarget() {
    let best = null, bd = BOARD_REACH;
    for (const t of this.targets) {
      const d = Vec3.distance(this.pos, t.pos) - (t.r ?? 0);
      if (d < bd) { bd = d; best = t; }
    }
    return best;
  }

  /** Range to a target's skin, for the HUD. Infinity if there is nothing. */
  targetRange(t) {
    if (!t) return Infinity;
    return Math.max(0, Vec3.distance(this.pos, t.pos) - (t.r ?? 0));
  }

  /**
   * Take hold. Kills your velocity — a hand on a rail is the cheapest brake in
   * the game and the only one that costs no gas, which is the whole reason to
   * work along the hull instead of flying over it.
   */
  grab(h) {
    if (!h) return false;
    this.held = h;
    Vec3.copy(this.pos, h.pos);
    Vec3.set(this.vel, 0, 0, 0);
    this._say(`HAND ON ${h.label} — HELD`);
    return true;
  }

  /** Let go, with a gentle shove off the hull so you do not sit on the plate. */
  release(cam = null) {
    if (!this.held) return false;
    const h = this.held;
    this.held = null;
    // Push off along the outward normal from the centreline, or along the
    // helmet's forward if we have one — you go where you were looking.
    if (cam?.forward) {
      Vec3.scale(this.vel, cam.forward, 1.6);
    } else {
      const n = [h.pos[0], h.pos[1], 0];
      const l = Math.hypot(n[0], n[1]) || 1;
      Vec3.set(this.vel, (n[0] / l) * 1.6, (n[1] / l) * 1.6, 0);
    }
    this._say('PUSHED OFF');
    return true;
  }

  /**
   * Step outside. Places the suit just off the hatch with a nudge outward, so
   * the first thing that happens is drifting clear of the hull rather than
   * bouncing off it.
   */
  begin() {
    if (this.active) return false;
    if (this.systems.oxygen < 20) {
      this.notify('SUIT OXYGEN BELOW EVA MINIMUM — RECHARGE BEFORE CYCLING THE LOCK');
      return false;
    }
    this.active = true;
    /**
     * IN THE MOUTH OF THE LOCK, not already outside. The exit is a push, not a
     * placement — see `this.exit`. Starting half a metre inside the hatch and
     * sliding out under the door's own shove is what makes the first two
     * seconds read as leaving a ship rather than appearing beside one.
     */
    Vec3.copy(this.pos, this.hatch);
    this.pos[0] -= 0.6;
    Vec3.set(this.vel, 2.6, 0, 0);
    this.exit = 1.8;
    this.held = null;
    this.jet = 100;
    this.elapsed = 0;
    this._said.clear();
    this.notify('OUTER DOOR CYCLED — YOU ARE OUTSIDE. TETHER RUNNING.');
    this.events?.emit('eva:begin', null);
    return true;
  }

  /** Back through the hatch. */
  end(forced = false) {
    if (!this.active) return;
    this.active = false;
    this.notify(forced
      ? 'EMERGENCY RECOVERY — THE REEL BROUGHT YOU IN'
      : `AIRLOCK CYCLED — ${Math.round(this.elapsed)}s OUTSIDE`);
    this.events?.emit('eva:end', { forced, seconds: this.elapsed });
  }

  /**
   * @param {number} dt
   * @param {object} cam player camera — supplies the basis the thrust is in
   * @param {object} axes {fwd, right, up, brake} each -1..1 / boolean
   */
  update(dt, cam, axes) {
    if (!this.active) return;
    this.elapsed += dt;

    /**
     * STILL COMING OUT. The door's push runs for `exit` seconds and the suit
     * has no controls during it — you are being moved by the ship, and taking
     * the stick off the player for two seconds is what makes it a transition
     * rather than a spawn. The velocity is real, so nothing teleports.
     */
    if (this.exit > 0) {
      this.exit = Math.max(0, this.exit - dt);
      Vec3.scaleAndAdd(this.pos, this.pos, this.vel, dt);
      // Bleed the shove off so you coast to a stop clear of the plating rather
      // than sailing away from your own airlock.
      const k = Math.max(0, 1 - 1.1 * dt);
      Vec3.scale(this.vel, this.vel, k);
      if (this.exit === 0) this._say('CLEAR OF THE HULL — SUIT JETS LIVE');
      return;
    }

    /**
     * A HAND ON A RAIL. Anchored: no drift, no gas, no tether arithmetic. You
     * can look around all you like and the ship holds you.
     */
    if (this.held) {
      Vec3.copy(this.pos, this.held.pos);
      Vec3.set(this.vel, 0, 0, 0);
      // Thrusting lets go for you, because reaching for the stick with a hand
      // on a rail is the one thing a player will try and be annoyed to be
      // refused.
      const wantOff = Math.abs(axes.fwd) + Math.abs(axes.right) + Math.abs(axes.up);
      if (wantOff > 0.01) this.release(cam);
      else return;
    }

    const want = Math.abs(axes.fwd) + Math.abs(axes.right) + Math.abs(axes.up);
    const firing = want > 0.01 && this.jet > 0;
    if (firing) {
      // Thrust in the HELMET's frame, because that is the only frame a person in
      // a suit has: you point yourself and squeeze, and there is no attitude
      // hold to fight you.
      //
      // The right and up vectors are DERIVED here rather than read off the
      // camera: PlayerCamera publishes `forward` and nothing else, and a basis
      // built from a field that does not exist would have thrust silently along
      // one axis. Right = forward × worldUp, up = right × forward.
      const f = cam.forward;
      const r = this._r, u = this._u;
      Vec3.cross(r, f, WORLD_UP);
      const rl = Vec3.length(r);
      // Looking straight up or down degenerates the cross product; fall back to
      // the last good basis rather than dividing by zero.
      if (rl > 1e-4) { Vec3.scale(r, r, 1 / rl); Vec3.cross(u, r, f); Vec3.normalize(u, u); }
      const a = JET_ACCEL * dt;
      for (let i = 0; i < 3; i++) {
        this.vel[i] += (f[i] * axes.fwd + r[i] * axes.right + u[i] * axes.up) * a;
      }
      this.jet = Math.max(0, this.jet - JET_BURN * dt * Math.min(1, want));
    }
    // The brake is a separate control and costs the same gas, because killing
    // your own velocity IS the expensive half of every EVA and hiding it inside
    // the thrust keys would let a player never notice they had spent it.
    if (axes.brake && this.jet > 0) {
      const sp = Vec3.length(this.vel);
      if (sp > 0.01) {
        const k = Math.min(1, (JET_ACCEL * 1.4 * dt) / sp);
        for (let i = 0; i < 3; i++) this.vel[i] -= this.vel[i] * k;
        this.jet = Math.max(0, this.jet - JET_BURN * 0.8 * dt);
      }
    }

    Vec3.scaleAndAdd(this.pos, this.pos, this.vel, dt);

    /**
     * THE JET HAS A SOUND, and it is the only one out here.
     *
     * Everything else in the game is carried to you through a hull; outside
     * there is nothing between your ear and the vacuum except the suit, so the
     * one thing you can hear is gas arriving through the pack against your own
     * back. Held, not triggered — a hiss that starts and stops with the key is
     * the only feedback that the pack is spending.
     */
    this.audio?.setSuitJet?.(this.jet > 0 ? Math.min(1, want + (axes.brake ? 0.8 : 0)) : 0);

    // -- the tether ----------------------------------------------------------
    // Scratch, not a fresh Float32Array per frame: this runs at 60Hz for as
    // long as the player is outside.
    const d = this._d;
    Vec3.sub(d, this.pos, this.hatch);
    const r = Vec3.length(d);
    if (r > TETHER_LEN && !this.freeFlight) {
      if (this.jet > 0.5) {
        // Still under power: the line simply comes taut and stops you going
        // further out. Radial velocity is cancelled, tangential is not, so you
        // swing round the ship on the end of it — which is what a tether does.
        Vec3.scale(d, d, 1 / r);
        Vec3.scaleAndAdd(this.pos, this.hatch, d, TETHER_LEN);
        const vr = Vec3.dot(this.vel, d);
        if (vr > 0) Vec3.scaleAndAdd(this.vel, this.vel, d, -vr);
        this._warn('tether', 'TETHER TAUT — THAT IS AS FAR AS THE LINE GOES');
      } else {
        // Out of gas at the end of the line. The reel takes over, slowly, and
        // it is the least dignified way back aboard.
        Vec3.scale(d, d, 1 / r);
        Vec3.scaleAndAdd(this.pos, this.pos, d, -2.6 * dt);
        Vec3.scale(this.vel, this.vel, 0.94);
        this._warn('reel', 'JET DRY — THE REEL IS WINCHING YOU IN');
      }
    }

    // -- the budgets ---------------------------------------------------------
    this.systems.oxygen = Math.max(0,
      this.systems.oxygen - (firing ? O2_WORK : O2_IDLE) * dt);
    if (this.jet < 25) this._warn('jetlow', 'COLD GAS BELOW A QUARTER — KEEP ENOUGH TO STOP WITH');
    if (this.systems.oxygen < 25) this._warn('o2low', 'SUIT OXYGEN BELOW A QUARTER — COME IN');
    if (this.systems.oxygen <= 0.5) {
      this.systems.health = Math.max(1, this.systems.health - 26 * dt);
      this._warn('o2out', 'SUIT OXYGEN EXHAUSTED');
    }
    // Nobody dies outside on a technicality: at the point where the suit can no
    // longer keep you alive the reel brings you in and the cost is health, not
    // a reload.
    if (this.systems.oxygen <= 0 && this.systems.health < 30) this.end(true);
  }

  _warn(key, text) {
    if (this._said.has(key)) return;
    this._said.add(key);
    this.notify(text);
  }

  /** Everything the suit HUD shows. */
  status() {
    return {
      range: this.range, tether: TETHER_LEN, tethered: this.tethered,
      jet: this.jet, oxygen: this.systems.oxygen,
      speed: Vec3.length(this.vel), elapsed: this.elapsed,
      canEnter: this.canEnter,
    };
  }
}
