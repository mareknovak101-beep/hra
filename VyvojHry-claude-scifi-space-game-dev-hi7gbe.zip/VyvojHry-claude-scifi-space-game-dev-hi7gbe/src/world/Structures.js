/**
 * STRUCTURES — everything in a system that is built rather than born.
 *
 * THE PROBLEM THIS SOLVES. Every non-player object in space — trade post,
 * shipyard, derelict, passing hauler — was drawn with `SpaceRenderer.freighter`,
 * one mesh, at different scales. A system therefore contained exactly one kind
 * of made thing, repeated. You could not tell a station from a wreck at range,
 * and there was no visual reason to fly toward any of them.
 *
 * Each builder below is authored from its own idea, the same discipline
 * `HullModels.js` applies to the player hulls:
 *
 *   TRADE POST   a WHEEL. Spun habitat torus on a spindle, docking arms out the
 *                hub, cargo pods clamped where the freighters actually berth.
 *                The one structure here that is obviously inhabited.
 *   SHIPYARD     a CAGE. An open construction gantry with a half-finished hull
 *                suspended inside it and gantry cranes riding the rails. You can
 *                see through it, which is what says "unfinished" at a glance.
 *   REFINERY     a TANK FARM. Spheres, hoppers, a flare stack, and a conveyor
 *                gallery. Industrial, filthy, and it burns.
 *   RELAY        a MAST. A lattice tower carrying a dish array and nothing else.
 *   WRECK        a BREAK. A hull snapped across its spine with the frames
 *                exposed at the tear and the plating peeled back off them. The
 *                seed decides where it broke and how much is left.
 *   MONOLITH     NOT HUMAN. No right angles at the joints, no plating grid, no
 *                fasteners — built by something that did not weld.
 *   MINE         a SPIKE BALL. Small, matte, and covered in contact horns.
 *   MINER        a JAW. A cutter head bigger than the hull behind it, ore bins
 *                slung underneath, and the whole thing built around the hole it
 *                is making.
 *   TRADER       a RACK. Containers first, ship second: a tug head, a long spine
 *                and eight boxes clamped along it in two stacks.
 *   COURIER      a DART. Small, clean, fast, and unarmed.
 *
 * EVERY BUILDER RETURNS `{ hull, glow }`. `glow` is a separate mesh drawn with
 * `u_lit = 0`, i.e. fully emissive against the amber glow texture — lit windows,
 * running lights, a cutter beam, a flare. It is what makes a structure read as
 * powered at a range where none of the plating detail resolves, and it is the
 * single cheapest way to say "someone is home" (or, by its absence, "nobody
 * is"). A wreck and a monolith return `glow: null` on purpose.
 *
 * Model convention matches the ship hulls: forward is -z, +y is up.
 */
import { box, chamRect, loft, octaTube, lcg } from '../ship/ShipExterior.js';

const UV = 0.075; // one plating tile per ~13 units — stations are big

/**
 * A ring of boxes about the z axis. Used for habitat torus segments, gantry
 * hoops and mine horns. SEGMENTED rather than a smooth torus on purpose: a
 * spun habitat is welded up out of straight cans, and the facets catch the
 * light in a way a smooth tube cannot at this resolution.
 */
function hoop(v, i, r, thick, depth, z, segs = 16, uv = UV, inset = 0) {
  for (let s = 0; s < segs; s++) {
    const a = (s / segs) * Math.PI * 2;
    const ca = Math.cos(a), sa = Math.sin(a);
    // half-width of a segment along the ring, from the chord length
    const half = Math.tan(Math.PI / segs) * r;
    const cx = ca * r, cy = sa * r;
    // Each segment is authored axis-aligned then placed by its centre; at 16
    // sides the error against a true arc is under 2% of the ring radius, and
    // the faceting is wanted.
    const ux = -sa, uy = ca; // along-ring
    const p = (du, dv, dz) => [cx + ux * du + ca * dv, cy + uy * du + sa * dv, z + dz];
    quadBox(v, i, p, half, thick, depth, inset, uv);
  }
}

/** A box specified by a point function, so it can be placed on a ring. */
function quadBox(v, i, p, half, thick, depth, inset, uv) {
  const c = [
    p(-half, -thick / 2 + inset, -depth / 2), p(half, -thick / 2 + inset, -depth / 2),
    p(half, thick / 2 + inset, -depth / 2), p(-half, thick / 2 + inset, -depth / 2),
    p(-half, -thick / 2 + inset, depth / 2), p(half, -thick / 2 + inset, depth / 2),
    p(half, thick / 2 + inset, depth / 2), p(-half, thick / 2 + inset, depth / 2),
  ];
  const F = [
    [[0, 4, 5, 1], [0, -1, 0]], [[3, 2, 6, 7], [0, 1, 0]],
    [[4, 7, 6, 5], [0, 0, 1]], [[0, 1, 2, 3], [0, 0, -1]],
    [[1, 5, 6, 2], [1, 0, 0]], [[0, 3, 7, 4], [-1, 0, 0]],
  ];
  for (const [idx, n] of F) {
    const base = v.length / 8;
    for (const k of idx) {
      const q = c[k];
      v.push(q[0], q[1], q[2], n[0], n[1], n[2], q[0] * uv, q[1] * uv + q[2] * uv);
    }
    i.push(base, base + 1, base + 2, base, base + 2, base + 3);
  }
}

/** Pack the two vertex arrays a builder accumulated. */
function pack(hv, hi, gv, gi) {
  return {
    hull: { vertexData: new Float32Array(hv), indexData: new Uint32Array(hi) },
    glow: gv.length
      ? { vertexData: new Float32Array(gv), indexData: new Uint32Array(gi) }
      : null,
  };
}

// ---------------------------------------------------------------------------
// STATIONS
// ---------------------------------------------------------------------------

/**
 * TRADE POST — the wheel. A spun habitat torus carried on a spindle, four
 * docking arms off the hub, cargo pods where the haulers berth.
 *
 * The ring is what makes it read as a PLACE rather than a machine: it is the
 * only structure in the game with an inside big enough to live in, and the two
 * rows of lit windows around its rim are the only sign of a population anywhere
 * in a system. Everything else here is bolted to that idea.
 */
export function buildTradePost() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, 0.4);
  const rnd = lcg(0x7ade01);

  // -- spindle: the non-rotating core the ring turns around -------------------
  octaTube(hv, hi, 2, 0, 0, -26, 26, 3.4, 3.4, UV, 2);
  octaTube(hv, hi, 2, 0, 0, -30, -26, 2.0, 3.4, UV, 2); // fore taper
  octaTube(hv, hi, 2, 0, 0, 26, 31, 3.4, 2.2, UV, 2);   // aft taper
  // reinforcing collars where the spokes land
  for (const z of [-13, 0, 13]) octaTube(hv, hi, 2, 0, 0, z - 1.2, z + 1.2, 4.6, 4.6, UV, 0);

  // -- habitat ring -----------------------------------------------------------
  const R = 20;
  hoop(hv, hi, R, 5.2, 7.0, 0, 20);             // the torus proper
  hoop(hv, hi, R + 2.9, 0.7, 5.0, 0, 20);       // outer rub rail
  hoop(hv, hi, R - 2.9, 0.7, 5.0, 0, 20);       // inner rail
  // Window bands: two rows around the rim, every other segment lit. Not every
  // segment — a fully lit ring reads as a neon hoop, and half the compartments
  // on any station are storage, machinery or somebody asleep.
  for (let s = 0; s < 20; s++) {
    if (s % 2) continue;
    const a = (s / 20) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    for (const dz of [-1.9, 1.9]) {
      const cx = ca * (R + 2.6), cy = sa * (R + 2.6);
      G([cx - 1.5, cy - 1.5, dz - 0.9], [cx + 1.5, cy + 1.5, dz + 0.9]);
    }
  }
  // -- spokes: six, in mirrored pairs, with a lift trunk down each ------------
  for (let s = 0; s < 6; s++) {
    const a = (s / 6) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    const seg = (r0, r1, t) => {
      const p = (du, dv, dz) => [ca * (r0 + (r1 - r0) * 0.5) + -sa * du + ca * dv,
        sa * (r0 + (r1 - r0) * 0.5) + ca * du + sa * dv, dz];
      quadBox(hv, hi, p, t, (r1 - r0), 2.4, 0, UV);
    };
    seg(3.2, R - 2.4, 1.1);
    // lift trunk: a thinner tube alongside the spar, so the spoke is two parts
    const p2 = (du, dv, dz) => [ca * (R * 0.5) + -sa * du + ca * dv, sa * (R * 0.5) + ca * du + sa * dv, dz + 2.2];
    quadBox(hv, hi, p2, 0.55, R - 6, 1.2, 0, UV);
  }

  // -- docking arms off the hub, with clamps and approach lights --------------
  for (let s = 0; s < 4; s++) {
    const a = (s / 4) * Math.PI * 2 + Math.PI / 4;
    const ca = Math.cos(a), sa = Math.sin(a);
    const z = s < 2 ? -19 : 19;
    const arm = (len, t, dz) => {
      const p = (du, dv, dd) => [ca * (len / 2 + 4) + -sa * du + ca * dv,
        sa * (len / 2 + 4) + ca * du + sa * dv, z + dz + dd];
      quadBox(hv, hi, p, t, len, t * 1.6, 0, UV);
    };
    arm(13, 1.5, 0);
    // clamp yoke at the tip: two jaws with a gap a hull can sit in
    for (const off of [-2.6, 2.6]) {
      const cx = ca * 12 - sa * off, cy = sa * 12 + ca * off;
      B([cx - 1.4, cy - 1.4, z - 3.4], [cx + 1.4, cy + 1.4, z + 3.4]);
    }
    // approach strobes down the arm
    for (let t = 0.35; t < 1.0; t += 0.22) {
      const cx = ca * (4 + 12 * t), cy = sa * (4 + 12 * t);
      G([cx - 0.5, cy - 0.5, z - 0.5], [cx + 0.5, cy + 0.5, z + 0.5]);
    }
  }

  // -- cargo pods clamped to the spindle, and the traffic-control blister -----
  for (let k = 0; k < 7; k++) {
    const a = rnd() * Math.PI * 2, r = 5.4 + rnd() * 1.2;
    const z = -22 + k * 6.4 + rnd() * 1.5;
    const cx = Math.cos(a) * r, cy = Math.sin(a) * r;
    const w = 1.6 + rnd() * 1.1, h = 1.4 + rnd() * 0.9, d = 2.2 + rnd() * 2.0;
    B([cx - w, cy - h, z - d], [cx + w, cy + h, z + d]);
    if (rnd() < 0.4) G([cx - 0.4, cy + h, z - 0.4], [cx + 0.4, cy + h + 0.3, z + 0.4]);
  }
  B([-4.2, 3.0, -30.5], [4.2, 7.2, -24.0]);      // control blister
  G([-3.4, 4.2, -30.8], [3.4, 6.2, -30.2]);      // its window band
  B([-0.5, 7.2, -29.0], [0.5, 11.0, -28.0]);     // mast
  G([-0.9, 10.6, -29.4], [0.9, 11.4, -27.6]);    // beacon

  return pack(hv, hi, gv, gi);
}

/**
 * SHIPYARD — the cage. An open rectangular gantry with a hull under
 * construction slung inside it.
 *
 * It has to be SEE-THROUGH. A closed box would be a warehouse; the whole point
 * of a building slip is that the thing being built is visible inside the frame,
 * unfinished, with the frames showing where the plating has not gone on yet.
 */
export function buildShipyard() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, 0.4);
  const rnd = lcg(0x5417d0);

  const HW = 15, HH = 12, L = 34;
  // -- the cage: four longerons plus transverse hoops -------------------------
  for (const sx of [-1, 1]) {
    for (const sy of [-1, 1]) {
      B([sx * HW - 1.1, sy * HH - 1.1, -L], [sx * HW + 1.1, sy * HH + 1.1, L]);
    }
  }
  for (let z = -L; z <= L; z += L / 3.5) {
    B([-HW - 1.1, HH - 0.9, z - 0.9], [HW + 1.1, HH + 0.9, z + 0.9]);   // top
    B([-HW - 1.1, -HH - 0.9, z - 0.9], [HW + 1.1, -HH + 0.9, z + 0.9]); // bottom
    B([-HW - 0.9, -HH - 1.1, z - 0.9], [-HW + 0.9, HH + 1.1, z + 0.9]); // port
    B([HW - 0.9, -HH - 1.1, z - 0.9], [HW + 0.9, HH + 1.1, z + 0.9]);   // starboard
    // diagonal brace in every other bay, alternating hand — a frame with only
    // square bays has no shear stiffness and, more to the point, reads as a grid
    if (Math.abs(z) < L * 0.8) {
      const s = z > 0 ? 1 : -1;
      B([-HW, HH - 1.2, z], [-HW + 0.7, HH - 0.5, z + s * 6]);
      B([HW - 0.7, -HH + 0.5, z], [HW, -HH + 1.2, z + s * 6]);
    }
  }

  // -- the hull on the slip: a lofted spine with the aft third unplated -------
  const SEC = [
    [-20, 3.0, -2.4, 2.6, 1.0], [-13, 5.2, -4.0, 4.4, 1.6], [-4, 6.0, -4.6, 5.0, 1.8],
    [6, 5.6, -4.3, 4.7, 1.7], [13, 4.4, -3.4, 3.7, 1.3],
  ];
  loft(hv, hi, SEC.map(([z, hw, y0, y1, ch]) => ({ z, pts: chamRect(hw, y0, y1, ch) })),
    UV, { capFore: true, capAft: false });
  // exposed frames aft of the plating: ribs with nothing on them yet
  for (let z = 14; z < 27; z += 2.6) {
    const t = 1 - (z - 14) / 18;
    const r = 4.4 * t + 1.2;
    for (let s = 0; s < 10; s++) {
      const a = (s / 10) * Math.PI * 2;
      const cx = Math.cos(a) * r, cy = Math.sin(a) * r * 0.82;
      B([cx - 0.35, cy - 0.35, z - 0.35], [cx + 0.35, cy + 0.35, z + 0.35]);
    }
    B([-r - 0.4, -0.4, z - 0.4], [r + 0.4, 0.4, z + 0.4]); // keel frame
  }
  // spine stringers running through the open frames
  for (const [sy, sx] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
    B([sx * 4.0 - 0.4, sy * 3.6 - 0.4, 13], [sx * 4.0 + 0.4, sy * 3.6 + 0.4, 27]);
  }

  // -- gantry cranes riding the top rails, with work lamps -------------------
  for (const [cz, reach] of [[-14, 8], [4, 11], [18, 6]]) {
    B([-HW, HH - 2.6, cz - 1.4], [HW, HH - 1.2, cz + 1.4]);         // trolley beam
    const tx = -6 + rnd() * 12;
    B([tx - 1.6, HH - 4.0, cz - 1.8], [tx + 1.6, HH - 1.0, cz + 1.8]); // trolley
    B([tx - 0.5, HH - 4.0 - reach, cz - 0.5], [tx + 0.5, HH - 3.6, cz + 0.5]); // hoist
    B([tx - 1.8, HH - 5.0 - reach, cz - 1.2], [tx + 1.8, HH - 4.0 - reach, cz + 1.2]); // hook block
    G([tx - 1.2, HH - 1.2, cz - 0.6], [tx + 1.2, HH - 0.8, cz + 0.6]); // work lamp
  }
  // welding arcs scattered over the unplated frames — the yard is WORKING
  for (let k = 0; k < 9; k++) {
    const z = 13 + rnd() * 13, a = rnd() * Math.PI * 2, r = 2.0 + rnd() * 3.0;
    const cx = Math.cos(a) * r, cy = Math.sin(a) * r * 0.8;
    G([cx - 0.45, cy - 0.45, z - 0.45], [cx + 0.45, cy + 0.45, z + 0.45]);
  }
  // corner navigation strobes on the cage, so it is findable in the dark
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) {
    G([sx * HW - 1.4, sy * HH - 1.4, sz * L - 1.4], [sx * HW + 1.4, sy * HH + 1.4, sz * L + 1.4]);
  }
  // control house clamped to one corner longeron
  B([-HW - 4.5, HH - 4, -8], [-HW + 1, HH + 2, 2]);
  G([-HW - 4.7, HH - 3, -7], [-HW - 4.3, HH - 0.4, 1]);

  return pack(hv, hi, gv, gi);
}

/**
 * REFINERY — the tank farm. Spheres and hoppers on a truss, a conveyor gallery
 * down one side and a flare stack burning off what it cannot sell.
 *
 * This is where the ore from the belt goes, so it belongs next to a belt and it
 * should look like it produces something: the flare is the tell, and it is the
 * only permanently burning light in a system.
 */
export function buildRefinery() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, 0.4);
  const rnd = lcg(0x8e17a1);

  // -- deck truss -------------------------------------------------------------
  for (const sy of [-1, 1]) {
    B([-22, sy * 6 - 0.9, -8.5], [22, sy * 6 + 0.9, -6.7]);
    B([-22, sy * 6 - 0.9, 6.7], [22, sy * 6 + 0.9, 8.5]);
  }
  for (let x = -22; x <= 22; x += 5.5) {
    B([x - 0.8, -6.9, -8.5], [x + 0.8, 6.9, -6.7]);
    B([x - 0.8, -6.9, 6.7], [x + 0.8, 6.9, 8.5]);
    B([x - 0.7, -0.7, -8.0], [x + 0.7, 0.7, 8.0]); // cross tie
  }

  // -- storage spheres, faceted (a sphere is a lot of triangles; an icosahedral
  //    approximation out of stacked octagonal rings is both cheaper and more in
  //    keeping with the plating language) --------------------------------------
  const sphere = (cx, cy, cz, r) => {
    const N = 5;
    for (let k = 0; k < N; k++) {
      const t0 = (k / N) * Math.PI, t1 = ((k + 1) / N) * Math.PI;
      const r0 = Math.sin(t0) * r, r1 = Math.sin(t1) * r;
      const y0 = cy + Math.cos(t0) * r, y1 = cy + Math.cos(t1) * r;
      octaTube(hv, hi, 1, cz, cx, y0, y1, r0 || 0.2, r1 || 0.2, UV, 0);
    }
  };
  sphere(-14, 0, 0, 6.5);
  sphere(-2, 0, 0, 5.2);
  sphere(9, 1.5, 0, 4.4);
  // banding straps, so the tanks read as fabricated rather than as blobs
  for (const [cx, r] of [[-14, 6.6], [-2, 5.3], [9, 4.5]]) {
    for (const cy of [-2.4, 0, 2.4]) octaTube(hv, hi, 1, 0, cx, cy - 0.35, cy + 0.35, r, r, UV, 0);
  }

  // -- ore hoppers: inverted pyramids feeding a conveyor gallery --------------
  for (const hx of [16, 20.5]) {
    loft(hv, hi, [
      { z: -3.2, pts: chamRect(3.0, 2.0, 8.0, 0.8, hx) },
      { z: 3.2, pts: chamRect(3.0, 2.0, 8.0, 0.8, hx) },
    ], UV, { capFore: true, capAft: true });
    loft(hv, hi, [
      { z: -2.4, pts: chamRect(2.4, -1.0, 2.0, 0.6, hx) },
      { z: 2.4, pts: chamRect(0.8, -3.4, -1.0, 0.3, hx) },
    ], UV, {});
  }
  B([-24, -3.4, -1.2], [24, -2.2, 1.2]);     // conveyor gallery
  for (let x = -23; x < 24; x += 3.2) B([x - 0.4, -4.4, -0.9], [x + 0.4, -3.3, 0.9]); // trestles

  // -- flare stack: the thing you see first ----------------------------------
  octaTube(hv, hi, 1, 0, 4, 6, 22, 1.5, 1.0, UV, 0);
  octaTube(hv, hi, 1, 0, 4, 22, 23.5, 1.8, 1.8, UV, 0); // burner ring
  G([2.6, 23.4, -1.4], [5.4, 27.0, 1.4]);
  G([3.2, 26.6, -0.9], [4.8, 30.5, 0.9]);
  G([3.6, 30.0, -0.5], [4.4, 32.4, 0.5]);
  // process lighting along the deck
  for (let x = -20; x < 22; x += 6.5) G([x - 0.6, 6.2, -0.6], [x + 0.6, 7.0, 0.6]);
  // dock arm for the ore barges
  B([-2, -8.6, -2], [2, -6.2, 2]);
  B([-1.2, -14, -1.2], [1.2, -8.4, 1.2]);
  B([-3.4, -16.5, -3.4], [3.4, -13.8, 3.4]);
  G([-2.6, -16.8, -2.6], [2.6, -16.3, 2.6]);
  void rnd;
  return pack(hv, hi, gv, gi);
}

/**
 * RELAY — the mast. A lattice tower carrying a dish array. No habitat, no
 * docking: nobody lives here, it just listens, and half the ones in the game
 * stopped answering years ago.
 */
export function buildRelay() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, UV);
  const G = (min, max) => box(gv, gi, min, max, 0.4);

  // lattice mast: three legs and a helical brace
  for (let s = 0; s < 3; s++) {
    const a = (s / 3) * Math.PI * 2, ca = Math.cos(a) * 2.4, sa = Math.sin(a) * 2.4;
    B([ca - 0.5, -18, sa - 0.5], [ca + 0.5, 18, sa + 0.5]);
  }
  for (let y = -17; y < 18; y += 3.0) {
    const a = (y / 3.0) * 0.9;
    for (let s = 0; s < 3; s++) {
      const a0 = (s / 3) * Math.PI * 2 + a, a1 = ((s + 1) / 3) * Math.PI * 2 + a;
      const x0 = Math.cos(a0) * 2.4, z0 = Math.sin(a0) * 2.4;
      const x1 = Math.cos(a1) * 2.4, z1 = Math.sin(a1) * 2.4;
      B([Math.min(x0, x1) - 0.28, y - 0.28, Math.min(z0, z1) - 0.28],
        [Math.max(x0, x1) + 0.28, y + 0.28, Math.max(z0, z1) + 0.28]);
    }
  }
  // dishes: shallow faceted bowls on yokes, pointed different ways
  const dish = (cy, r, tilt) => {
    for (let k = 0; k < 4; k++) {
      const rr = r * (1 - k / 5);
      octaTube(hv, hi, 2, 0, cy, -0.6 - k * 0.5 + tilt, -0.2 - k * 0.5 + tilt, rr, rr * 0.86, UV, 0);
    }
    B([-0.4, cy - 0.4, -3.2 + tilt], [0.4, cy + 0.4, 0.4 + tilt]); // feed horn boom
    B([-0.9, cy - 0.9, -3.6 + tilt], [0.9, cy + 0.9, -2.8 + tilt]);
  };
  dish(11, 7.5, -3);
  dish(1, 5.5, 2);
  dish(-9, 6.5, -1);
  // equipment cabinets and the status lamp that is the only thing still on
  B([-2.8, -3.0, 2.6], [2.8, 1.2, 5.4]);
  B([-2.2, -6.0, 2.9], [2.2, -3.2, 5.1]);
  G([-1.6, 0.4, 5.4], [1.6, 0.9, 5.6]);
  G([-0.5, 18.0, -0.5], [0.5, 19.4, 0.5]);
  return pack(hv, hi, gv, gi);
}

// ---------------------------------------------------------------------------
// WRECKS AND UNKNOWNS
// ---------------------------------------------------------------------------

/**
 * WRECK — the break. A hull snapped across its spine, frames showing at the
 * tear, plating peeled back off them.
 *
 * `seed` decides where the break is, which end survived and how badly the rest
 * is chewed, so no two wrecks in a chart are the same object at a different
 * scale. There is deliberately NO glow mesh: a wreck is dark, and that is the
 * whole difference between it and a station at the range you first see it.
 */
export function buildWreck(seed = 1) {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, UV);
  const rnd = lcg((seed * 2654435761) >>> 0 || 7);
  for (let w = 0; w < 8; w++) rnd(); // see buildMonolith: the first draws are seed-correlated

  const len = 34 + rnd() * 22;
  const brk = -len * 0.5 + len * (0.32 + rnd() * 0.36); // where it parted
  const foreLives = rnd() < 0.55;

  // -- the surviving section, lofted and plated ------------------------------
  const hw = 4.0 + rnd() * 2.2;
  const secs = [];
  const z0 = foreLives ? -len / 2 : brk;
  const z1 = foreLives ? brk : len / 2;
  const N = 5;
  for (let k = 0; k <= N; k++) {
    const t = k / N;
    const z = z0 + (z1 - z0) * t;
    // taper toward whichever end is the ship's nose
    const nose = foreLives ? 1 - t : t;
    const w = hw * (0.42 + 0.58 * (1 - Math.abs(nose - 0.35) * 0.9));
    secs.push({ z, pts: chamRect(w, -w * 0.72, w * 0.78, w * 0.3) });
  }
  loft(hv, hi, secs, UV, { capFore: foreLives, capAft: !foreLives });

  // -- the tear: exposed ring frames with the plating gone -------------------
  // Frames get SMALLER and more scattered as they march out of the break, which
  // is what makes a tear read as "this came apart" rather than "this was cut".
  const dir = foreLives ? 1 : -1;
  let fz = brk;
  for (let k = 0; k < 6; k++) {
    fz += dir * (1.6 + rnd() * 1.8);
    const t = 1 - k / 7;
    const r = hw * t * (0.7 + rnd() * 0.5);
    if (r < 0.6) break;
    for (let s = 0; s < 9; s++) {
      if (rnd() < 0.22) continue; // frames snapped out of the ring
      const a = (s / 9) * Math.PI * 2;
      const cx = Math.cos(a) * r, cy = Math.sin(a) * r * 0.8;
      B([cx - 0.32, cy - 0.32, fz - 0.32], [cx + 0.32, cy + 0.32, fz + 0.32]);
    }
    // longitudinal stringers between the frames
    if (k < 5) {
      for (const [sx, sy] of [[1, 0], [-1, 0], [0, 1], [0, -0.8]]) {
        B([sx * r - 0.26, sy * r - 0.26, Math.min(fz, fz - dir * 2.2)],
          [sx * r + 0.26, sy * r + 0.26, Math.max(fz, fz - dir * 2.2)]);
      }
    }
  }

  // -- peeled plating: strips folded back off the tear -----------------------
  for (let k = 0; k < 7; k++) {
    const a = rnd() * Math.PI * 2;
    const r = hw * (0.75 + rnd() * 0.4);
    const cx = Math.cos(a) * r, cy = Math.sin(a) * r * 0.8;
    const l = 2.0 + rnd() * 4.5;
    const pz = brk + dir * rnd() * 3;
    B([cx - 1.3, cy - 0.22, Math.min(pz, pz + dir * l)],
      [cx + 1.3, cy + 0.22, Math.max(pz, pz + dir * l)]);
  }

  // -- surviving fittings: a stub wing, a bell, a mast, a burst tank ---------
  if (rnd() < 0.7) {
    const wz = z0 + (z1 - z0) * (0.4 + rnd() * 0.3);
    const s = rnd() < 0.5 ? 1 : -1; // only ONE wing left, and that is the point
    B([s * hw * 0.9, -0.5, wz - 3.5], [s * (hw * 0.9 + 8 + rnd() * 5), 0.5, wz + 3.5]);
    B([s * (hw + 5), -1.4, wz - 1.0], [s * (hw + 7), 1.4, wz + 1.0]);
  }
  if (!foreLives) {
    octaTube(hv, hi, 2, 0, 0, len / 2 - 3, len / 2 + 1.5, 2.6, 3.4, UV, 0);
    octaTube(hv, hi, 2, 0, 0, len / 2 + 1.4, len / 2 + 2.6, 3.4, 2.2, UV, 2);
  } else {
    B([-1.0, hw * 0.7, z0 + 4], [1.0, hw * 0.7 + 5 + rnd() * 4, z0 + 6]); // snapped mast
  }
  // debris still tethered to the hull by cable runs
  for (let k = 0; k < 5; k++) {
    const a = rnd() * Math.PI * 2, r = hw + 1.5 + rnd() * 7;
    const cx = Math.cos(a) * r, cy = Math.sin(a) * r * 0.8;
    const z = z0 + (z1 - z0) * rnd();
    const sz = 0.5 + rnd() * 1.4;
    B([cx - sz, cy - sz, z - sz], [cx + sz, cy + sz, z + sz]);
  }
  return pack(hv, hi, gv, gi);
}

/**
 * UNKNOWN STRUCTURE — not human work.
 *
 * The design rule is subtractive: everything that says "fabricated" elsewhere in
 * this game is banned here. No plating grid (the uv scale is huge, so the tile
 * never repeats across a face), no fasteners, no right-angle joints, no
 * antennae, no lights. What is left is mass in an arrangement with a logic you
 * cannot read, which is the only way to make a shape unsettling rather than
 * merely unfamiliar.
 */
export function buildMonolith(seed = 1, kind = seed % 3) {
  const hv = [], hi = [], gv = [], gi = [];
  const uv = 0.012; // near-featureless: the plating tile is bigger than the object
  const B = (min, max) => box(hv, hi, min, max, uv);
  const rnd = lcg((seed * 40503) >>> 0 || 3);
  // Warm the generator. `lcg` is a plain LCG, so its FIRST output is strongly
  // correlated with the seed — drawing the shape from it gave all three
  // variants the same kind, which is exactly the failure the variants exist to
  // prevent. Hence also the explicit `kind`: which of the three shapes this is
  // must not be left to a random draw at all.
  for (let w = 0; w < 8; w++) rnd();
  if (kind === 0) {
    // SLAB STACK — plates of decreasing size rotated a fixed irrational angle
    // off each other, so the stack never lines up with itself.
    let y = -26;
    let w = 15, d = 11;
    let a = 0;
    while (y < 26) {
      const h = 1.4 + rnd() * 3.0;
      const ca = Math.cos(a), sa = Math.sin(a);
      const p = (du, dv, dz) => [ca * du - sa * dv, y + dz, sa * du + ca * dv];
      quadBox(hv, hi, p, w, d * 2, h, 0, uv);
      y += h + 0.5 + rnd() * 1.8;
      a += 0.618 * Math.PI; // golden angle: never repeats, never aligns
      w *= 0.90 + rnd() * 0.12;
      d *= 0.90 + rnd() * 0.12;
    }
  } else if (kind === 1) {
    // OPEN RING — a torus of tapering blades standing on edge, with nothing in
    // the middle. Whatever it is for, it is for the hole.
    const R = 22;
    for (let s = 0; s < 13; s++) {
      const a = (s / 13) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      const t = 0.6 + Math.abs(Math.sin(s * 2.4)) * 2.6;
      const p = (du, dv, dz) => [ca * (R + dv) - sa * du, dz, sa * (R + dv) + ca * du];
      quadBox(hv, hi, p, t, 9, 17 + Math.sin(s * 1.7) * 7, 0, uv);
    }
    for (let s = 0; s < 13; s += 3) {
      const a = (s / 13) * Math.PI * 2;
      B([Math.cos(a) * R - 1.2, -1.2, Math.sin(a) * R - 1.2],
        [Math.cos(a) * R + 1.2, 1.2, Math.sin(a) * R + 1.2]);
    }
  } else {
    // BRANCHING SPIRE — a recursive fork. Organic in its branching rule but
    // hard-edged in its parts, which is exactly the register that reads wrong.
    const grow = (x, y, z, len, r, depth, dx, dy, dz) => {
      if (depth > 5 || len < 1.2) return;
      const ex = x + dx * len, ey = y + dy * len, ez = z + dz * len;
      box(hv, hi,
        [Math.min(x, ex) - r, Math.min(y, ey) - r, Math.min(z, ez) - r],
        [Math.max(x, ex) + r, Math.max(y, ey) + r, Math.max(z, ez) + r], uv);
      const n = rnd() < 0.55 ? 2 : 3;
      for (let k = 0; k < n; k++) {
        const t = (k / n) * Math.PI * 2 + rnd();
        const nx = dx * 0.55 + Math.cos(t) * 0.72;
        const ny = dy * 0.62 + (rnd() - 0.35) * 0.5;
        const nz = dz * 0.55 + Math.sin(t) * 0.72;
        const l = Math.hypot(nx, ny, nz) || 1;
        grow(ex, ey, ez, len * (0.6 + rnd() * 0.2), r * 0.72, depth + 1,
          nx / l, ny / l, nz / l);
      }
    };
    grow(0, -22, 0, 13, 2.6, 0, 0, 1, 0);
  }
  return pack(hv, hi, gv, gi);
}

/**
 * PROXIMITY MINE — a spiked ball. Small, matte, and covered in contact horns so
 * the silhouette is unmistakable the moment it resolves, which it needs to be:
 * by the time you can see one clearly you are already inside the field.
 */
export function buildMine() {
  const hv = [], hi = [], gv = [], gi = [];
  const uv = 0.4;
  // body: a stubby faceted drum rather than a sphere — cheaper and it reads as
  // a manufactured casing
  octaTube(hv, hi, 2, 0, 0, -1.5, 1.5, 2.0, 2.0, uv, 0);
  octaTube(hv, hi, 2, 0, 0, -2.4, -1.5, 1.1, 2.0, uv, 2);
  octaTube(hv, hi, 2, 0, 0, 1.5, 2.4, 2.0, 1.1, uv, 2);
  // contact horns on a cube's worth of directions
  const dirs = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
    [0.7, 0.7, 0], [-0.7, 0.7, 0], [0.7, -0.7, 0], [-0.7, -0.7, 0]];
  for (const [dx, dy, dz] of dirs) {
    const ex = dx * 3.6, ey = dy * 3.6, ez = dz * 3.6;
    box(hv, hi,
      [Math.min(dx * 1.6, ex) - 0.3, Math.min(dy * 1.6, ey) - 0.3, Math.min(dz * 1.6, ez) - 0.3],
      [Math.max(dx * 1.6, ex) + 0.3, Math.max(dy * 1.6, ey) + 0.3, Math.max(dz * 1.6, ez) + 0.3], uv);
  }
  // ONE small armed lamp. A mine that could not be seen at all would be a
  // cheap-shot mechanic; a mine with one pinprick of light is a warning you
  // have to be paying attention to catch.
  box(gv, gi, [-0.45, 1.9, -0.45], [0.45, 2.5, 0.45], 0.5);
  return pack(hv, hi, gv, gi);
}

// ---------------------------------------------------------------------------
// CIVILIAN TRAFFIC
// ---------------------------------------------------------------------------

/**
 * MINING BARGE — the jaw. Built around a cutter head wider than the hull that
 * carries it, with the ore bins slung under the spine where the mass belongs.
 */
export function buildMiner() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, 0.16);
  const G = (min, max) => box(gv, gi, min, max, 0.4);
  const M = (x0, x1, y0, y1, z0, z1) => { B([x0, y0, z0], [x1, y1, z1]); B([-x1, y0, z0], [-x0, y1, z1]); };
  const rnd = lcg(0x117e01);

  // -- cutter head: a drum of teeth on a boom, the widest thing on the ship ---
  octaTube(hv, hi, 2, 0, 0, -14.5, -10.5, 5.6, 5.6, 0.16, 0);
  octaTube(hv, hi, 2, 0, 0, -15.4, -14.4, 4.4, 5.6, 0.16, 2);
  for (let s = 0; s < 12; s++) {
    const a = (s / 12) * Math.PI * 2;
    const cx = Math.cos(a) * 5.9, cy = Math.sin(a) * 5.9;
    for (let k = 0; k < 3; k++) {
      const z = -14.0 + k * 1.5;
      B([cx - 0.6, cy - 0.6, z - 0.5], [cx + 0.6, cy + 0.6, z + 0.5]);
    }
  }
  B([-2.2, -2.2, -10.6], [2.2, 2.2, -6.0]);       // cutter shaft housing
  M(2.0, 3.2, -0.9, 0.9, -11.5, -6.5);            // hydraulic rams to the head

  // -- spine and bridge ------------------------------------------------------
  loft(hv, hi, [
    { z: -6.5, pts: chamRect(3.0, -2.4, 2.6, 1.0) },
    { z: 0, pts: chamRect(3.6, -3.0, 3.0, 1.2) },
    { z: 8, pts: chamRect(3.4, -2.8, 2.8, 1.1) },
    { z: 12, pts: chamRect(2.6, -2.2, 2.2, 0.9) },
  ], 0.16, { capFore: true, capAft: true });
  B([-2.4, 2.8, -5.0], [2.4, 5.2, -0.5]);         // bridge box
  G([-2.0, 3.4, -5.2], [2.0, 4.6, -4.9]);         // bridge glass
  // -- ore bins under the keel, visibly full or empty ------------------------
  for (let k = 0; k < 3; k++) {
    const z = -3.5 + k * 5.2;
    B([-4.2, -6.6, z - 2.2], [4.2, -3.0, z + 2.2]);
    B([-4.6, -5.4, z - 0.6], [4.6, -4.2, z + 0.6]); // bin rib
    if (rnd() < 0.6) B([-3.6, -3.0, z - 1.8], [3.6, -2.4, z + 1.8]); // heaped load
  }
  // -- drives, radiators and work lamps --------------------------------------
  M(2.2, 4.4, -1.6, 1.6, 10.5, 15.0);
  octaTube(hv, hi, 2, 3.3, 0, 14.8, 16.2, 1.5, 1.9, 0.16, 2);
  octaTube(hv, hi, 2, -3.3, 0, 14.8, 16.2, 1.5, 1.9, 0.16, 2);
  M(3.4, 3.7, -4.5, 4.5, 3.0, 9.0);               // radiator panels
  for (const [lx, ly, lz] of [[0, 5.4, -4.6], [-3.0, 1.0, -9.5], [3.0, 1.0, -9.5]]) {
    G([lx - 0.7, ly - 0.4, lz - 0.4], [lx + 0.7, ly + 0.4, lz + 0.4]);
  }
  return pack(hv, hi, gv, gi);
}

/**
 * TRADE HAULER — the rack. Containers first, ship second: a tug head, a long
 * open spine and eight boxes clamped along it in two stacks. Nothing here is
 * streamlined because nothing here ever enters an atmosphere.
 */
export function buildTrader() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, 0.13);
  const G = (min, max) => box(gv, gi, min, max, 0.4);
  const rnd = lcg(0x77ade2);

  // -- tug head --------------------------------------------------------------
  loft(hv, hi, [
    { z: -20.0, pts: chamRect(2.6, -1.8, 2.0, 0.9) },
    { z: -16.0, pts: chamRect(4.0, -2.8, 3.2, 1.3) },
    { z: -11.0, pts: chamRect(4.2, -3.0, 3.4, 1.4) },
  ], 0.13, { capFore: true, capAft: true });
  B([-3.0, 3.2, -19.0], [3.0, 5.6, -13.5]);       // bridge
  G([-2.6, 3.9, -19.3], [2.6, 5.0, -18.9]);       // bridge glass
  B([-4.6, -1.0, -17.5], [-4.0, 1.0, -12.0]);     // flank rubbing strakes
  B([4.0, -1.0, -17.5], [4.6, 1.0, -12.0]);

  // -- open spine ------------------------------------------------------------
  for (const [sx, sy] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) {
    B([sx * 2.2 - 0.5, sy * 2.2 - 0.5, -11.5], [sx * 2.2 + 0.5, sy * 2.2 + 0.5, 17]);
  }
  for (let z = -11; z < 17; z += 4.2) {
    B([-2.7, -2.7, z - 0.45], [2.7, 2.7, z + 0.45]); // frame hoop
  }

  // -- containers, two stacks, some missing (a hauler is rarely full) --------
  for (let k = 0; k < 5; k++) {
    const z = -9.5 + k * 5.4;
    for (const s of [-1, 1]) {
      if (rnd() < 0.18) continue;
      B([s * 2.6, -3.2, z - 2.4], [s * 8.4, 3.2, z + 2.4]);
      B([s * 2.4, -3.4, z - 2.6], [s * 8.6, -2.9, z + 2.6]); // bottom rail
      B([s * 2.4, 2.9, z - 2.6], [s * 8.6, 3.4, z + 2.6]);   // top rail
      // clamp yokes to the spine
      B([s * 2.0, -1.0, z - 0.6], [s * 3.0, 1.0, z + 0.6]);
    }
  }
  // -- drive block: four bells in a square, radiators outboard ---------------
  B([-4.0, -4.0, 16.5], [4.0, 4.0, 21.5]);
  for (const [dx, dy] of [[-2.1, -2.1], [2.1, -2.1], [-2.1, 2.1], [2.1, 2.1]]) {
    octaTube(hv, hi, 2, dx, dy, 21.4, 23.4, 1.5, 2.0, 0.13, 2);
    G([dx - 1.1, dy - 1.1, 23.2], [dx + 1.1, dy + 1.1, 23.7]);
  }
  B([-9.5, -0.4, 17.0], [-4.0, 0.4, 21.0]);       // radiator wings
  B([4.0, -0.4, 17.0], [9.5, 0.4, 21.0]);
  // running lights: red port, white starboard, the oldest convention there is
  G([-8.6, -0.5, -14.0], [-7.6, 0.5, -13.0]);
  G([7.6, -0.5, -14.0], [8.6, 0.5, -13.0]);
  return pack(hv, hi, gv, gi);
}

/**
 * COURIER — the dart. Small, clean and unarmed: the one hull in the system that
 * is not carrying, mining, fighting or dying. It exists so that "neutral" has a
 * silhouette and an empty lane occasionally has somebody crossing it.
 */
export function buildCourier() {
  const hv = [], hi = [], gv = [], gi = [];
  const B = (min, max) => box(hv, hi, min, max, 0.22);
  const G = (min, max) => box(gv, gi, min, max, 0.4);
  const M = (x0, x1, y0, y1, z0, z1) => { B([x0, y0, z0], [x1, y1, z1]); B([-x1, y0, z0], [-x0, y1, z1]); };

  loft(hv, hi, [
    { z: -9.0, pts: chamRect(0.5, -0.4, 0.5, 0.2) },
    { z: -6.0, pts: chamRect(1.1, -0.9, 1.1, 0.4) },
    { z: -1.0, pts: chamRect(1.5, -1.2, 1.5, 0.6) },
    { z: 4.5, pts: chamRect(1.4, -1.1, 1.3, 0.5) },
    { z: 7.5, pts: chamRect(1.0, -0.8, 0.9, 0.35) },
  ], 0.22, { capFore: true, capAft: true });
  G([-0.75, 0.55, -6.4], [0.75, 1.25, -3.4]);     // canopy
  M(1.4, 4.2, -0.16, 0.16, -0.5, 2.6);            // shoulder wings
  M(3.6, 4.0, -0.9, 0.9, 0.2, 2.2);               // tip fins
  B([-0.16, 1.4, 3.4], [0.16, 3.6, 6.6]);         // dorsal fin
  octaTube(hv, hi, 2, 0, 0, 7.4, 9.0, 0.9, 1.2, 0.22, 2);
  G([-0.85, -0.85, 8.8], [0.85, 0.85, 9.3]);      // drive glow
  G([-4.1, -0.3, 1.6], [-3.5, 0.3, 2.2]);         // nav lights
  G([3.5, -0.3, 1.6], [4.1, 0.3, 2.2]);
  return pack(hv, hi, gv, gi);
}

/**
 * The registry the renderer builds from, and the systems index by name.
 *
 * Keyed by the `structure` field on a `ships[]` record. Anything without one
 * falls back to the old freighter mesh, so a save from before this existed —
 * or a lore system that has not been given a type yet — still renders.
 */
export const STRUCTURE_BUILDERS = {
  trade_post: buildTradePost,
  shipyard: buildShipyard,
  refinery: buildRefinery,
  relay: buildRelay,
  monolith: buildMonolith,
  mine: buildMine,
  miner: buildMiner,
  trader: buildTrader,
  courier: buildCourier,
  wreck: buildWreck,
};

/**
 * Build every structure mesh once. Wrecks and monoliths take a seed, so three
 * variants of each are baked and a record picks one by `variant` — three
 * distinct wrecks is the difference between a debris field and a debris field
 * made of one repeated object, and it costs three meshes rather than one per
 * wreck in the chart.
 */
export function buildAllStructures() {
  const out = {};
  for (const [k, fn] of Object.entries(STRUCTURE_BUILDERS)) {
    if (k === 'wreck' || k === 'monolith') {
      // The variant index doubles as the monolith's SHAPE selector — see the
      // note there on why that cannot be a random draw.
      for (let v = 0; v < 3; v++) out[`${k}_${v}`] = fn(v * 977 + 13, v);
    } else {
      out[k] = fn();
    }
  }
  return out;
}
