/**
 * StarSystem — runtime state of the current system: celestial bodies (with
 * moons), NPC ships, and their motion. Rendering transforms live in
 * SpaceRenderer; this class only owns positions + orbital state.
 *
 * MOTION IS KEPLERIAN. Bodies used to run on circles — a radius, an angle, and
 * an angular speed of K/r^1.5. The exponent was right, so inner worlds led outer
 * ones, but every orbit was perfectly round and exactly on the ecliptic, so a
 * system read as concentric rings on a flat plane, and a comet on a 150 AU orbit
 * tracked at the same steady rate as a planet at 1 AU. Each body now carries a
 * full element set (see data/Orbits.js) and its position is solved from Kepler's
 * equation against a single system clock. Eccentric worlds visibly accelerate
 * through periapsis; inclined ones ride above and below the plane; and every
 * period follows the third law from its own semi-major axis.
 */
import { orbitPosition, orbitalSpeed, GRAV_MU, MOON_MU } from '../data/Orbits.js';

/**
 * How fast everything that is not an orbit turns, relative to the old rate.
 *
 * Orbits are slowed through `GRAV_MU` (see Orbits.js), which is the honest
 * place for it because the third law then carries the change through every
 * period consistently. Spin and station-keeping have no such law behind them,
 * so they take the same factor here rather than being re-tuned by eye.
 */
const SPIN_SCALE = 1 / 6;

export class StarSystem {
  /** @param {object} def one of StarSystemsData */
  constructor(def) {
    this.def = def;
    this.name = def.name;
    this.star = { ...def.star, kind: 'star', isStar: true };
    /**
     * Seconds since epoch. ONE clock for the whole system rather than a
     * per-body accumulated angle: integrating each body's angle separately lets
     * rounding drift them apart over a long session, and it makes a body's
     * position depend on how many frames have been drawn rather than on the
     * elapsed time. Solving from `t` keeps the system reproducible and lets a
     * save restore it exactly by storing one number.
     */
    this.time = 0;
    /** @type {Array<object>} flattened list: planets then their moons */
    this.bodies = [];
    for (const b of def.bodies) {
      const body = { ...b, pos: [...b.pos], angle: 0 };
      this.bodies.push(body);
      for (const m of b.moons ?? []) {
        this.bodies.push({ ...m, parent: body, isMoon: true, pos: [...m.pos], angle: 0 });
      }
    }
    this.ships = def.ships.map((s) => ({ ...s, pos: [...s.pos], yaw: 0 }));
    this._rel = [0, 0, 0];
    this._byId = new Map(this.bodies.map((b) => [b.id, b]));
    this.update(0); // put everything at epoch before anyone reads a position
  }

  /** Host body for a station or derelict parked in its orbit. */
  _host(id) { return this._byId.get(id) ?? null; }

  update(dt) {
    this.time += dt;
    // Parents are pushed before their moons, so a single forward pass has the
    // planet's new position ready by the time its moons need it as a focus.
    for (const body of this.bodies) {
      // Rotation slowed with the orbits (0.34.0). A world visibly spinning
      // while you fly past it reads as a prop on a turntable; a day should be
      // long enough that you notice it changed, not long enough to watch.
      body.angle += (body.spin ?? 0.01) * dt * SPIN_SCALE;
      if (!body.orbit) continue; // defensive: a body without elements just sits
      const focus = body.parent ? body.parent.pos : this.star.pos;
      orbitPosition(this._rel, body.orbit, this.time);
      body.pos[0] = focus[0] + this._rel[0];
      body.pos[1] = focus[1] + this._rel[1];
      body.pos[2] = focus[2] + this._rel[2];
      // current orbital radius and vis-viva speed, for the NAV read-out — this
      // is the number that makes eccentricity legible to the player
      body.orbitR = Math.hypot(this._rel[0], this._rel[1], this._rel[2]);
      body.orbitV = orbitalSpeed(body.orbit, body.orbitR, body.parent ? MOON_MU : GRAV_MU);
    }
    for (const ship of this.ships) {
      if (ship.route) {
        // CIVILIAN TRAFFIC on a two-point route, bouncing at each end. The
        // route's endpoints were captured at generation and do not move with
        // their worlds — deliberately: a hauler chasing an orbiting station
        // around the star would never arrive, and a lane that stays put is
        // legible in a way a pursuit curve is not.
        ship.t += ship.speed * ship.dir * dt;
        if (ship.t > 1) { ship.t = 1; ship.dir = -1; }
        if (ship.t < 0) { ship.t = 0; ship.dir = 1; }
        const [a, b] = ship.route;
        ship.pos[0] = a[0] + (b[0] - a[0]) * ship.t;
        ship.pos[1] = a[1] + (b[1] - a[1]) * ship.t;
        ship.pos[2] = a[2] + (b[2] - a[2]) * ship.t;
        // Face the way you are going. The mesh's forward is -z, so the heading
        // is atan2 of the leg vector taken in the same sense the hostiles use.
        const lx = (b[0] - a[0]) * ship.dir, lz = (b[2] - a[2]) * ship.dir;
        ship.yaw = Math.atan2(lx, -lz);
        continue;
      }
      if (ship.hostId) {
        // Anything parked over a world rides with it. `hostOffset` is the
        // station-keeping vector, slowly rotated so the station also circles the
        // planet rather than hanging at one fixed bearing — a geostationary
        // waypoint over an orbiting colony still has to go round something.
        const host = this._host(ship.hostId);
        if (host) {
          // Station-keeping phase, slowed to match the bodies. A station that
          // swung round its host while you were lining up on it was the most
          // visible symptom of the whole system running too fast.
          ship.orbitPhase = (ship.orbitPhase ?? 0) + dt * (ship.station ? 0.012 : 0.006) * SPIN_SCALE;
          const c = Math.cos(ship.orbitPhase), s = Math.sin(ship.orbitPhase);
          const ox = ship.hostOffset[0], oz = ship.hostOffset[2];
          ship.pos[0] = host.pos[0] + ox * c - oz * s;
          ship.pos[1] = host.pos[1] + ship.hostOffset[1];
          ship.pos[2] = host.pos[2] + ox * s + oz * c;
          // a derelict's own drift accumulates on top of the station-keeping
          if (ship.derelict) {
            ship.hostOffset[0] += ship.drift[0] * dt;
            ship.hostOffset[2] += ship.drift[2] * dt;
          }
        }
      } else {
        ship.pos[0] += ship.drift[0] * dt;
        ship.pos[1] += ship.drift[1] * dt;
        ship.pos[2] += ship.drift[2] * dt;
      }
      // stations hold attitude (slow majestic roll); traffic/derelicts tumble lazily
      ship.yaw += dt * (ship.station ? 0.004 : 0.01) * SPIN_SCALE;
      // A DEAD thing tumbles on all three axes. Spinning only about y is what a
      // machine under control does — it is the difference between a station
      // holding station and a wreck that nobody is flying.
      if (ship.tumble) {
        ship.pitch = (ship.pitch ?? 0) + ship.tumble[0] * dt;
        ship.roll = (ship.roll ?? 0) + ship.tumble[1] * dt;
      }
    }
  }

  /**
   * The armed mine the ship is inside the trigger radius of, if any.
   *
   * Separate from `approach` on purpose: approach is an invitation and this is
   * a consequence, and conflating them would put a "PRESS E TO DOCK" prompt on
   * a naval mine. One-shot — a mine that has gone off is marked `spent` and is
   * not tested again, so a field cannot chain-detonate on one pass through it.
   *
   * @returns {object|null} the mine record, already marked spent
   */
  armedMine(shipPos) {
    for (const s of this.ships) {
      if (!s.mine || s.spent) continue;
      const d = Math.hypot(shipPos[0] - s.pos[0], shipPos[1] - s.pos[1], shipPos[2] - s.pos[2]);
      if (d < (s.trigger ?? 90)) { s.spent = true; return s; }
    }
    return null;
  }

  /**
   * Keep the ship outside every body's surface — a spherical hull hitbox. Pushes
   * the ship back to the surface and cancels the inward velocity so you slide
   * along a world instead of flying through it (and the sky-projection never gets
   * a body closer than its own radius, which is what smears a dark disc over the
   * whole view). Includes the star. Mutates shipPos/shipVel in place.
   * @returns {object|null} the body collided with, if any
   */
  collide(shipPos, shipVel, margin = 1.06) {
    const targets = [this.star, ...this.bodies];
    for (const body of targets) {
      const dx = shipPos[0] - body.pos[0], dy = shipPos[1] - body.pos[1], dz = shipPos[2] - body.pos[2];
      const d = Math.hypot(dx, dy, dz);
      const minD = body.radius * margin;
      if (d < minD && d > 1e-4) {
        const s = minD / d;
        shipPos[0] = body.pos[0] + dx * s;
        shipPos[1] = body.pos[1] + dy * s;
        shipPos[2] = body.pos[2] + dz * s;
        if (shipVel) {
          const nx = dx / d, ny = dy / d, nz = dz / d;
          const vn = shipVel[0] * nx + shipVel[1] * ny + shipVel[2] * nz;
          if (vn < 0) { shipVel[0] -= vn * nx; shipVel[1] -= vn * ny; shipVel[2] -= vn * nz; }
        }
        return body;
      }
    }
    return null;
  }

  /**
   * The body whose approach sphere the ship is inside, if any, plus distance.
   * Approach sphere = a few body radii — the "you can enter orbit / land" zone.
   * @returns {{body:object, dist:number}|null}
   */
  approach(shipPos) {
    let best = null;
    for (const body of this.bodies) {
      const dx = shipPos[0] - body.pos[0], dy = shipPos[1] - body.pos[1], dz = shipPos[2] - body.pos[2];
      const d = Math.hypot(dx, dy, dz);
      const reach = body.radius * 2.6 + 400; // hitbox / approach radius
      if (d < reach && (!best || d < best.dist)) best = { body, dist: d };
    }
    // Stations, wrecks, relays and anomalies are approachable too — anything
    // with a `reach`. Mines are excluded outright: they have reach 0 and are
    // handled by `armedMine`, because an approach prompt on unexploded ordnance
    // would be an invitation to do the one thing that kills you.
    for (const s of this.ships) {
      if (s.mine || !(s.reach > 0)) continue;
      const d = Math.hypot(shipPos[0] - s.pos[0], shipPos[1] - s.pos[1], shipPos[2] - s.pos[2]);
      if (d < s.reach && (!best || d < best.dist)) best = { body: s, dist: d };
    }
    return best;
  }
}
