/**
 * ObjectPool — reuse allocation-heavy objects (particles, projectiles later).
 * Required by the quality checklist in context/07 for anything spawned per-frame.
 */
export class ObjectPool {
  /**
   * @param {() => object} factory creates a fresh object
   * @param {(obj: object) => void} reset re-initializes an object on acquire
   * @param {number} initial pre-allocated count
   */
  constructor(factory, reset, initial = 0) {
    this.factory = factory;
    this.reset = reset;
    this.free = [];
    for (let i = 0; i < initial; i++) this.free.push(factory());
  }

  acquire() {
    const obj = this.free.length > 0 ? this.free.pop() : this.factory();
    this.reset(obj);
    return obj;
  }

  release(obj) {
    this.free.push(obj);
  }
}
