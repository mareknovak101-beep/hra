/**
 * ColorUtils — hex/rgb conversion and shading helpers for procedural texturing.
 * All game colors are defined in core/Constants.js (PALETTE); this module only
 * transforms them.
 */

/** '#a04e1a' -> [160, 78, 26] (0-255 ints) */
export function hexToRgb(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

/** '#a04e1a' -> [0.627, 0.306, 0.102] (0-1 floats, for shader uniforms) */
export function hexToRgbf(hex) {
  const [r, g, b] = hexToRgb(hex);
  return [r / 255, g / 255, b / 255];
}

/** Multiply an [r,g,b] 0-255 color by factor, clamped. */
export function shade(rgb, factor) {
  return [
    Math.min(255, Math.max(0, Math.round(rgb[0] * factor))),
    Math.min(255, Math.max(0, Math.round(rgb[1] * factor))),
    Math.min(255, Math.max(0, Math.round(rgb[2] * factor))),
  ];
}

/**
 * Darken while shifting WARMER — cooling plasma/metal reddens as it dims
 * (blackbody behaviour), so blue channels fall faster than red. Used for star
 * convection lanes, starspot umbrae and ember glows, where a plain `shade()`
 * reads as dirty grey instead of cooler fire.
 */
export function warmShade(rgb, factor) {
  const f = Math.max(0, factor);
  return [
    Math.min(255, Math.round(rgb[0] * Math.min(1, f * 1.12))),
    Math.min(255, Math.round(rgb[1] * f)),
    Math.min(255, Math.round(rgb[2] * f * 0.82)),
  ];
}

/** Linear mix of two [r,g,b] 0-255 colors. */
export function mixRgb(a, b, t) {
  return [
    Math.round(a[0] + (b[0] - a[0]) * t),
    Math.round(a[1] + (b[1] - a[1]) * t),
    Math.round(a[2] + (b[2] - a[2]) * t),
  ];
}
