/**
 * Debug — dev overlay (FPS, draw calls, player position, current zone).
 * Toggled with backquote (`). DOM-based so it never touches the 480×270 buffer.
 * The only sanctioned global is window.DEBUG (see context/07 code checklist).
 */
import { PALETTE } from '../core/Constants.js';

export class Debug {
  constructor() {
    this.visible = false;
    this.el = document.createElement('div');
    this.el.id = 'debug-overlay';
    this.el.style.cssText = [
      'position:fixed', 'top:8px', 'left:8px', 'z-index:40',
      `color:${PALETTE.HUD_AMBER[1]}`, 'background:rgba(15,15,20,0.8)',
      'font:12px monospace', 'padding:6px 8px', 'white-space:pre',
      'pointer-events:none', 'display:none',
    ].join(';');
    document.body.appendChild(this.el);

    this.frames = 0;
    this.fps = 0;
    this.lastFpsTime = performance.now();
    this.stats = {};
    window.DEBUG = this;
  }

  toggle() {
    this.visible = !this.visible;
    this.el.style.display = this.visible ? 'block' : 'none';
  }

  /** Merge arbitrary key/value stats shown on the overlay. */
  set(stats) {
    Object.assign(this.stats, stats);
  }

  frame() {
    this.frames++;
    const now = performance.now();
    if (now - this.lastFpsTime >= 1000) {
      this.fps = Math.round((this.frames * 1000) / (now - this.lastFpsTime));
      this.frames = 0;
      this.lastFpsTime = now;
    }
    if (!this.visible) return;
    const lines = [`FPS ${this.fps}`];
    for (const [k, v] of Object.entries(this.stats)) lines.push(`${k} ${v}`);
    this.el.textContent = lines.join('\n');
  }
}
