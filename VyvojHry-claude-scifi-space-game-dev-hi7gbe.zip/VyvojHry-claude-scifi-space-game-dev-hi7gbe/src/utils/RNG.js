/**
 * RNG — deterministic seeded random (mulberry32). Used everywhere procedural
 * content must be reproducible between sessions (textures, wear marks, decals).
 */
export class RNG {
  /** @param {number} seed uint32 seed */
  constructor(seed) {
    this.s = seed >>> 0;
  }

  /** @returns {number} float in [0, 1) */
  next() {
    this.s = (this.s + 0x6d2b79f5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /** float in [min, max) */
  range(min, max) { return min + this.next() * (max - min); }

  /** integer in [min, max] inclusive */
  int(min, max) { return min + Math.floor(this.next() * (max - min + 1)); }

  /** true with probability p */
  chance(p) { return this.next() < p; }

  /** random element of an array */
  pick(arr) { return arr[Math.floor(this.next() * arr.length)]; }

  /** child generator with a derived seed (keeps streams independent) */
  fork(salt) { return new RNG((this.s ^ Math.imul(salt, 0x9e3779b9)) >>> 0); }
}
