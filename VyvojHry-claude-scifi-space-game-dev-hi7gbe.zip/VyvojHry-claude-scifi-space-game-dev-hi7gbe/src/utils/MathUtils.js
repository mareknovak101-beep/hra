/**
 * MathUtils — minimal vec3/mat4 toolkit written from scratch (pillar 4: no libraries).
 * Matrices are column-major Float32Array(16), matching WebGL uniformMatrix4fv.
 */

export const Vec3 = {
  /** @returns {Float32Array} */
  create(x = 0, y = 0, z = 0) { return new Float32Array([x, y, z]); },

  set(out, x, y, z) { out[0] = x; out[1] = y; out[2] = z; return out; },

  copy(out, a) { out[0] = a[0]; out[1] = a[1]; out[2] = a[2]; return out; },

  add(out, a, b) { out[0] = a[0] + b[0]; out[1] = a[1] + b[1]; out[2] = a[2] + b[2]; return out; },

  sub(out, a, b) { out[0] = a[0] - b[0]; out[1] = a[1] - b[1]; out[2] = a[2] - b[2]; return out; },

  scale(out, a, s) { out[0] = a[0] * s; out[1] = a[1] * s; out[2] = a[2] * s; return out; },

  scaleAndAdd(out, a, b, s) {
    out[0] = a[0] + b[0] * s; out[1] = a[1] + b[1] * s; out[2] = a[2] + b[2] * s; return out;
  },

  dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; },

  cross(out, a, b) {
    const ax = a[0], ay = a[1], az = a[2], bx = b[0], by = b[1], bz = b[2];
    out[0] = ay * bz - az * by; out[1] = az * bx - ax * bz; out[2] = ax * by - ay * bx;
    return out;
  },

  length(a) { return Math.hypot(a[0], a[1], a[2]); },

  distance(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1], a[2] - b[2]); },

  normalize(out, a) {
    const l = Math.hypot(a[0], a[1], a[2]);
    if (l > 1e-8) { out[0] = a[0] / l; out[1] = a[1] / l; out[2] = a[2] / l; }
    else { out[0] = 0; out[1] = 0; out[2] = 0; }
    return out;
  },

  lerp(out, a, b, t) {
    out[0] = a[0] + (b[0] - a[0]) * t;
    out[1] = a[1] + (b[1] - a[1]) * t;
    out[2] = a[2] + (b[2] - a[2]) * t;
    return out;
  },
};

export const Mat4 = {
  /** @returns {Float32Array} */
  create() {
    const m = new Float32Array(16);
    m[0] = m[5] = m[10] = m[15] = 1;
    return m;
  },

  identity(out) {
    out.fill(0);
    out[0] = out[5] = out[10] = out[15] = 1;
    return out;
  },

  copy(out, a) { out.set(a); return out; },

  /** out = a * b (apply b first, then a) */
  multiply(out, a, b) {
    const r = out === a || out === b ? new Float32Array(16) : out;
    for (let c = 0; c < 4; c++) {
      for (let row = 0; row < 4; row++) {
        r[c * 4 + row] =
          a[row] * b[c * 4] +
          a[4 + row] * b[c * 4 + 1] +
          a[8 + row] * b[c * 4 + 2] +
          a[12 + row] * b[c * 4 + 3];
      }
    }
    if (r !== out) out.set(r);
    return out;
  },

  translation(out, x, y, z) {
    Mat4.identity(out);
    out[12] = x; out[13] = y; out[14] = z;
    return out;
  },

  rotationX(out, rad) {
    Mat4.identity(out);
    const c = Math.cos(rad), s = Math.sin(rad);
    out[5] = c; out[6] = s; out[9] = -s; out[10] = c;
    return out;
  },

  rotationY(out, rad) {
    Mat4.identity(out);
    const c = Math.cos(rad), s = Math.sin(rad);
    out[0] = c; out[2] = -s; out[8] = s; out[10] = c;
    return out;
  },

  /**
   * Roll about +z. Added for the structure pass: a wreck that only spins about
   * y reads as a carousel, and a tumble needs all three axes.
   */
  rotationZ(out, rad) {
    Mat4.identity(out);
    const c = Math.cos(rad), s = Math.sin(rad);
    out[0] = c; out[1] = s; out[4] = -s; out[5] = c;
    return out;
  },

  scaling(out, x, y, z) {
    Mat4.identity(out);
    out[0] = x; out[5] = y; out[10] = z;
    return out;
  },

  perspective(out, fovYRad, aspect, near, far) {
    const f = 1 / Math.tan(fovYRad / 2);
    out.fill(0);
    out[0] = f / aspect;
    out[5] = f;
    out[10] = (far + near) / (near - far);
    out[11] = -1;
    out[14] = (2 * far * near) / (near - far);
    return out;
  },

  /** Orthographic projection for 2D HUD passes. */
  ortho(out, left, right, bottom, top, near, far) {
    out.fill(0);
    out[0] = 2 / (right - left);
    out[5] = 2 / (top - bottom);
    out[10] = -2 / (far - near);
    out[12] = -(right + left) / (right - left);
    out[13] = -(top + bottom) / (top - bottom);
    out[14] = -(far + near) / (far - near);
    out[15] = 1;
    return out;
  },

  /** Look-at view matrix (right-handed), for the exterior chase camera. */
  lookAt(out, eye, target, up) {
    let zx = eye[0] - target[0], zy = eye[1] - target[1], zz = eye[2] - target[2];
    let zl = Math.hypot(zx, zy, zz) || 1; zx /= zl; zy /= zl; zz /= zl;
    let xx = up[1] * zz - up[2] * zy;
    let xy = up[2] * zx - up[0] * zz;
    let xz = up[0] * zy - up[1] * zx;
    let xl = Math.hypot(xx, xy, xz) || 1; xx /= xl; xy /= xl; xz /= xl;
    const yx = zy * xz - zz * xy;
    const yy = zz * xx - zx * xz;
    const yz = zx * xy - zy * xx;
    out[0] = xx; out[1] = yx; out[2] = zx; out[3] = 0;
    out[4] = xy; out[5] = yy; out[6] = zy; out[7] = 0;
    out[8] = xz; out[9] = yz; out[10] = zz; out[11] = 0;
    out[12] = -(xx * eye[0] + xy * eye[1] + xz * eye[2]);
    out[13] = -(yx * eye[0] + yy * eye[1] + yz * eye[2]);
    out[14] = -(zx * eye[0] + zy * eye[1] + zz * eye[2]);
    out[15] = 1;
    return out;
  },

  /**
   * First-person view matrix from eye position + yaw/pitch.
   * view = rotX(-pitch) * rotY(-yaw) * translate(-eye)
   */
  fpsView(out, eye, yaw, pitch, tmpA, tmpB) {
    Mat4.rotationX(tmpA, -pitch);
    Mat4.rotationY(tmpB, -yaw);
    Mat4.multiply(out, tmpA, tmpB);
    Mat4.translation(tmpA, -eye[0], -eye[1], -eye[2]);
    return Mat4.multiply(out, out, tmpA);
  },
};

export const Quat = {
  /** @returns {Float32Array} identity quaternion [x,y,z,w] */
  create() { return new Float32Array([0, 0, 0, 1]); },

  identity(out) { out[0] = 0; out[1] = 0; out[2] = 0; out[3] = 1; return out; },

  copy(out, a) { out.set(a); return out; },

  /**
   * Quaternion that points the ship's nose (local -z) along a horizontal
   * direction. Rotating (0,0,-1) by yaw about +y gives (-sin y, 0, -cos y), so
   * the yaw that lands on `dir` is atan2(-dx, -dz).
   */
  lookYaw(out, dir) {
    const yaw = Math.atan2(-dir[0], -dir[2]);
    out[0] = 0; out[1] = Math.sin(yaw / 2); out[2] = 0; out[3] = Math.cos(yaw / 2);
    return out;
  },

  setAxisAngle(out, axis, rad) {
    const s = Math.sin(rad / 2);
    out[0] = axis[0] * s; out[1] = axis[1] * s; out[2] = axis[2] * s;
    out[3] = Math.cos(rad / 2);
    return out;
  },

  /** out = a * b (apply b's rotation first, then a's) */
  multiply(out, a, b) {
    const ax = a[0], ay = a[1], az = a[2], aw = a[3];
    const bx = b[0], by = b[1], bz = b[2], bw = b[3];
    out[0] = aw * bx + ax * bw + ay * bz - az * by;
    out[1] = aw * by + ay * bw + az * bx - ax * bz;
    out[2] = aw * bz + az * bw + ax * by - ay * bx;
    out[3] = aw * bw - ax * bx - ay * by - az * bz;
    return out;
  },

  conjugate(out, a) {
    out[0] = -a[0]; out[1] = -a[1]; out[2] = -a[2]; out[3] = a[3];
    return out;
  },

  normalize(out, a) {
    const l = Math.hypot(a[0], a[1], a[2], a[3]) || 1;
    out[0] = a[0] / l; out[1] = a[1] / l; out[2] = a[2] / l; out[3] = a[3] / l;
    return out;
  },

  /** Rotate vec3 v by quaternion q. */
  rotateVec3(out, q, v) {
    const qx = q[0], qy = q[1], qz = q[2], qw = q[3];
    const vx = v[0], vy = v[1], vz = v[2];
    // t = 2 * cross(q.xyz, v)
    const tx = 2 * (qy * vz - qz * vy);
    const ty = 2 * (qz * vx - qx * vz);
    const tz = 2 * (qx * vy - qy * vx);
    // v + q.w * t + cross(q.xyz, t)
    out[0] = vx + qw * tx + qy * tz - qz * ty;
    out[1] = vy + qw * ty + qz * tx - qx * tz;
    out[2] = vz + qw * tz + qx * ty - qy * tx;
    return out;
  },
};

/** Column-major rotation matrix from a (unit) quaternion. */
Mat4.fromQuat = function fromQuat(out, q) {
  const x = q[0], y = q[1], z = q[2], w = q[3];
  const x2 = x + x, y2 = y + y, z2 = z + z;
  const xx = x * x2, xy = x * y2, xz = x * z2;
  const yy = y * y2, yz = y * z2, zz = z * z2;
  const wx = w * x2, wy = w * y2, wz = w * z2;
  out[0] = 1 - (yy + zz); out[1] = xy + wz; out[2] = xz - wy; out[3] = 0;
  out[4] = xy - wz; out[5] = 1 - (xx + zz); out[6] = yz + wx; out[7] = 0;
  out[8] = xz + wy; out[9] = yz - wx; out[10] = 1 - (xx + yy); out[11] = 0;
  out[12] = 0; out[13] = 0; out[14] = 0; out[15] = 1;
  return out;
};

export const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const DEG2RAD = Math.PI / 180;

/** Forward unit vector from yaw/pitch (yaw 0 looks toward -Z, matching the view matrix). */
export function forwardFromAngles(out, yaw, pitch) {
  const cp = Math.cos(pitch);
  out[0] = -Math.sin(yaw) * cp;
  out[1] = Math.sin(pitch);
  out[2] = -Math.cos(yaw) * cp;
  return out;
}

/**
 * Ray vs AABB slab test.
 * @returns {number} hit distance, or Infinity on miss
 */
export function rayAabb(ox, oy, oz, dx, dy, dz, min, max) {
  let tmin = 0, tmax = Infinity;
  const o = [ox, oy, oz], d = [dx, dy, dz];
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) {
      if (o[i] < min[i] || o[i] > max[i]) return Infinity;
    } else {
      let t1 = (min[i] - o[i]) / d[i];
      let t2 = (max[i] - o[i]) / d[i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) return Infinity;
    }
  }
  return tmin;
}
