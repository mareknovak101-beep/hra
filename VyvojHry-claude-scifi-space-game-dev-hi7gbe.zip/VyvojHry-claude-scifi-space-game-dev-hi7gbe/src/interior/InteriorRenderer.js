/**
 * InteriorRenderer — draws the ship: one draw call per zone (static batch) plus
 * one per door panel. Each draw gets its zone's light set (max 8, plus
 * neighbour spill), keeping the context/02 §4 uniform contract per-draw.
 */
import { LIGHTING, RENDER } from '../core/Constants.js';
import { Mat4 } from '../utils/MathUtils.js';

export class InteriorRenderer {
  /**
   * @param {import('../core/Renderer.js').Renderer} renderer
   * @param {import('./ShipMap.js').ShipMap} shipMap
   * @param {import('../rendering/LightSystem.js').LightSystem} lights
   * @param {{albedo: WebGLTexture, normal: WebGLTexture}} atlasTextures
   */
  constructor(renderer, shipMap, lights, atlasTextures) {
    this.renderer = renderer;
    this.shipMap = shipMap;
    this.lights = lights;
    this.atlasTexture = atlasTextures.albedo;
    this.normalTexture = atlasTextures.normal;
    this.identity = Mat4.create();
    // runtime-tunable (Settings / scene): ambient level and brightness
    this.ambient = LIGHTING.AMBIENT; // lit ship by default; derelicts lower this
    this.brightness = 1.0;
    /**
     * Diegetic CRT terminals: [firstScreenLayer, lastScreenLayer, enabled].
     * Set by main.js from the atlas layer indices; screens are registered
     * consecutively so the range identifies exactly the console glass.
     */
    this.screenCrt = [0, -1, 0];
    /**
     * Things standing on the deck that are not part of it.
     *
     * `{draw(drawZoneLit, zoneAt)}` — anything that wants to be lit by the
     * compartment it is in gets handed the same per-zone light gather the walls
     * use, and draws itself with its own model matrices. That is the whole
     * contract, and it is deliberately the only way in: an actor lit by
     * anything other than the room it is standing in would sit on top of the
     * scene rather than in it, which at this resolution is the difference
     * between a creature in a corridor and a sprite pasted over one.
     *
     * @type {{draw:(d:Function, zoneAt:Function)=>void}|null}
     */
    this.actors = null;
  }

  /**
   * @param {import('../player/PlayerCamera.js').PlayerCamera} camera
   * @param {import('../player/PlayerLight.js').PlayerLight} playerLight
   * @param {number} time
   */
  render(camera, playerLight, time) {
    const gl = this.renderer.gl;
    const prog = this.renderer.use('interior');
    const u = prog.uniforms;

    gl.uniformMatrix4fv(u.u_viewProjection, false, camera.viewProjection);
    gl.uniform1f(u.u_time, time);
    const a = this.ambient;
    gl.uniform3f(u.u_ambient, a, a, a);
    gl.uniform1f(u.u_brightness, this.brightness);
    gl.uniform3f(u.u_ditherParams,
      RENDER.DITHER_LIGHT_LEVELS, RENDER.DISTANCE_DARKEN_RANGE, RENDER.DISTANCE_DARKEN_FLOOR);
    gl.uniform2f(u.u_reliefParams, RENDER.SPEC_POWER, RENDER.SPEC_STRENGTH);
    gl.uniform3f(u.u_screenCrt, this.screenCrt[0], this.screenCrt[1], this.screenCrt[2]);

    // helmet light
    const H = LIGHTING.HELMET_LIGHT;
    gl.uniform3fv(u.u_playerLightPos, camera.eye);
    gl.uniform3fv(u.u_playerLightDir, camera.forward);
    gl.uniform3fv(u.u_playerLightColor, H.color);
    gl.uniform4f(u.u_playerLightParams,
      H.intensity, H.range,
      Math.cos((H.innerAngleDeg * Math.PI) / 180),
      Math.cos((H.outerAngleDeg * Math.PI) / 180));
    gl.uniform1f(u.u_playerLightOn, playerLight.on ? 1 : 0);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, this.atlasTexture);
    gl.uniform1i(u.u_atlas, 0);
    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D_ARRAY, this.normalTexture);
    gl.uniform1i(u.u_normalAtlas, 1);

    const drawWithZoneLights = (zoneId, neighbours, mesh, model) => {
      const count = this.lights.gatherForZone(zoneId, neighbours);
      gl.uniform1i(u.u_lightCount, count);
      gl.uniform3fv(u.u_lightPositions, this.lights.uPositions);
      gl.uniform3fv(u.u_lightColors, this.lights.uColors);
      gl.uniform1fv(u.u_lightIntensities, this.lights.uIntensities);
      gl.uniform1fv(u.u_lightRadii, this.lights.uRadii);
      gl.uniformMatrix4fv(u.u_model, false, model);
      this.renderer.drawMesh(mesh);
    };

    for (const zone of this.shipMap.zones) {
      drawWithZoneLights(zone.id, zone.neighbours, zone.mesh, this.identity);
    }
    for (const door of this.shipMap.doors) {
      drawWithZoneLights(door.spec.a, [door.spec.b], door.mesh, door.modelMatrix);
    }
    // Last, and inside the same program state: whatever is walking around in
    // here. Drawn after the shell so the depth buffer already holds the walls.
    this.actors?.draw(drawWithZoneLights, (x, z) => this.shipMap.zoneAt(x, z));
  }
}
