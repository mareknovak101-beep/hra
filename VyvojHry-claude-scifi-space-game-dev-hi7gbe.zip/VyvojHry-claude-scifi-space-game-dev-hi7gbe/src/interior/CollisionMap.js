/**
 * CollisionMap — static + dynamic AABB colliders and the player movement
 * resolver (custom, no library — context/02 §8). Every solid prop registers a
 * box here; that's a hard rule in the context/07 quality checklist.
 */

export class CollisionMap {
  constructor() {
    /** @type {Array<{min:number[], max:number[], active:boolean, ref:any}>} */
    this.boxes = [];
  }

  /**
   * @returns {object} the collider record (keep it to toggle `active`, e.g. doors)
   */
  addBox(min, max, ref = null) {
    const box = { min, max, active: true, ref };
    this.boxes.push(box);
    return box;
  }

  /** AABB overlap test against all active boxes. */
  overlaps(min, max) {
    for (const b of this.boxes) {
      if (!b.active) continue;
      if (
        min[0] < b.max[0] && max[0] > b.min[0] &&
        min[1] < b.max[1] && max[1] > b.min[1] &&
        min[2] < b.max[2] && max[2] > b.min[2]
      ) return b;
    }
    return null;
  }

  /**
   * Move an AABB (center + half extents) by delta with axis-separated
   * slide resolution. Mutates and returns `center`. Also reports whether the
   * mover ended up standing on something (for grounding).
   */
  move(center, half, delta, out = { grounded: false, hitY: false }) {
    out.grounded = false;
    out.hitY = false;
    for (const axis of [0, 2, 1]) { // x, z, then y — stable stair-free sliding
      const d = delta[axis];
      if (d === 0) continue;
      center[axis] += d;
      const min = [center[0] - half[0], center[1] - half[1], center[2] - half[2]];
      const max = [center[0] + half[0], center[1] + half[1], center[2] + half[2]];
      for (const b of this.boxes) {
        if (!b.active) continue;
        if (
          min[0] < b.max[0] && max[0] > b.min[0] &&
          min[1] < b.max[1] && max[1] > b.min[1] &&
          min[2] < b.max[2] && max[2] > b.min[2]
        ) {
          if (d > 0) {
            center[axis] = b.min[axis] - half[axis] - 1e-4;
          } else {
            center[axis] = b.max[axis] + half[axis] + 1e-4;
            if (axis === 1) out.grounded = true;
          }
          if (axis === 1) out.hitY = true;
          min[axis] = center[axis] - half[axis];
          max[axis] = center[axis] + half[axis];
        }
      }
    }
    return center;
  }

  /**
   * Push an AABB out of everything it currently overlaps, resolving the deepest
   * intrusion first along its own axis of least penetration. Returns true if it
   * came out clear.
   *
   * `move` cannot do this. It resolves per axis in the DIRECTION OF TRAVEL and
   * skips any axis whose delta is zero, so a body placed inside a wall with no
   * horizontal velocity never gets pushed sideways — and then the downward Y
   * pass finds the wall collider under it, treats it as ground, and snaps the
   * body to the wall's top face at ceiling height. That is exactly how
   * `__debug.teleport` was landing the player at y≈3.3, standing on the roof of
   * a 2.8 m room, which made every interior probe shot look like the hull was
   * leaking space out of its side walls.
   */
  depenetrate(center, half, iters = 8) {
    for (let n = 0; n < iters; n++) {
      let worst = null, worstPen = 0, worstAxis = 0, worstSign = 1;
      for (const b of this.boxes) {
        if (!b.active) continue;
        let deepest = Infinity, axis = 0, sign = 1;
        let inside = true;
        for (let a = 0; a < 3; a++) {
          const outNeg = center[a] + half[a] - b.min[a]; // distance to clear toward -a
          const outPos = b.max[a] - (center[a] - half[a]); // ... toward +a
          if (outNeg <= 0 || outPos <= 0) { inside = false; break; }
          const pen = Math.min(outNeg, outPos);
          if (pen < deepest) { deepest = pen; axis = a; sign = outPos < outNeg ? +1 : -1; }
        }
        // keep the box we are furthest INTO: resolving it first stops the
        // shallow ones from shoving us deeper into the serious one
        if (inside && deepest > worstPen) {
          worstPen = deepest; worst = b; worstAxis = axis; worstSign = sign;
        }
      }
      if (!worst) return true;
      center[worstAxis] += worstSign * (worstPen + 1e-3);
    }
    return false;
  }
}
