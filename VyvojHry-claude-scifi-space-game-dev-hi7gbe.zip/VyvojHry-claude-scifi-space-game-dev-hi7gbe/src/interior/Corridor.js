/**
 * Corridor — the five corridor cross-sections (context/02 §5), built on top of
 * the Room.js wall/floor machinery. The corridor-type sequence along the spine
 * is data in ShipMap.js; this file only knows shapes.
 *
 *  A Barrel Arch — side walls + sloped vault to a flat apex strip
 *  B Low Industrial — flat, pipe-covered ceiling
 *  C Wide Bay — flat + buttress pilasters
 *  D Maintenance — narrow, walls angle in to a slim ceiling (hex feel)
 *  E Junction — octagonal hub (square with 45° corner cuts)
 */
import { buildWall, buildFloorCeiling, wallQuad, addWallRelief } from './Room.js';

const CEIL_AO4 = [0.85, 0.85, 0.85, 0.85];

export function buildCorridorShell(ctx) {
  const shape = ctx.zone.shape;
  if (shape === 'arch') buildArch(ctx);
  else if (shape === 'hex') buildHex(ctx);
  else if (shape === 'octagon') buildOctagon(ctx);
  else if (shape === 'buttress') buildButtress(ctx);
  else buildFlat(ctx);
}

function shellPieces(ctx, wallHeight) {
  const { zone, atlas } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const wall = atlas.layer(zone.tex.wall);
  // end walls always full zone height (openings live there)
  buildWall(ctx, 'z', z0, x0, x1, zone.h, +1, wall, ctx.openings.nz);
  buildWall(ctx, 'z', z1, x0, x1, zone.h, -1, wall, ctx.openings.pz);
  // side walls to the given height
  buildWall(ctx, 'x', x0, z0, z1, wallHeight, +1, wall, ctx.openings.nx);
  buildWall(ctx, 'x', x1, z0, z1, wallHeight, -1, wall, ctx.openings.px);
}

function buildFlat(ctx) {
  const { zone, atlas } = ctx;
  buildFloorCeiling(ctx, atlas.layer(zone.tex.floor), atlas.layer(zone.tex.ceil));
  shellPieces(ctx, zone.h);
  addWallRelief(ctx);
}

function buildButtress(ctx) {
  buildFlat(ctx);
  const { zone, atlas, builder, shipMap } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const wall = atlas.layer(zone.tex.wall);
  const step = 2.4;
  for (let z = z0 + 1.2; z < z1 - 0.6; z += step) {
    for (const side of [x0, x1]) {
      const dir = side === x0 ? 1 : -1;
      const min = [side + (dir > 0 ? 0 : -0.28), 0, z - 0.18];
      const max = [side + (dir > 0 ? 0.28 : 0), zone.h, z + 0.18];
      builder.box(min, max, wall, { uvScale: 0.6, ao: [0.8, 0.8, 0.9, 0.9] });
      shipMap.collision.addBox(min, max, { pilaster: true });
    }
  }
}

function buildArch(ctx) {
  const { zone, atlas, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const wall = atlas.layer(zone.tex.wall);
  const wallH = 2.0;
  const apexHalf = 0.35;
  const cx = (x0 + x1) / 2;
  buildFloorCeiling(ctx, atlas.layer(zone.tex.floor), atlas.layer(zone.tex.ceil), { skipCeiling: true });
  shellPieces(ctx, wallH);
  // sloped vault: wall top -> apex strip edge. Wound so the normal faces
  // inward/down (visible from below) — the reverse winding was back-face culled
  // and read as a missing roof when looked at from an angle.
  builder.quad(
    [cx - apexHalf, zone.h, z0], [cx - apexHalf, zone.h, z1], [x0, wallH, z1], [x0, wallH, z0],
    wall, { ao: CEIL_AO4 },
  );
  builder.quad(
    [cx + apexHalf, zone.h, z1], [cx + apexHalf, zone.h, z0], [x1, wallH, z0], [x1, wallH, z1],
    wall, { ao: CEIL_AO4 },
  );
  // apex strip
  builder.quad(
    [cx - apexHalf, zone.h, z0], [cx + apexHalf, zone.h, z0],
    [cx + apexHalf, zone.h, z1], [cx - apexHalf, zone.h, z1],
    atlas.layer(zone.tex.ceil), { ao: CEIL_AO4 },
  );
  // structural hoops every ~1.2m: wall ribs + an apex cross-piece — the
  // classic barrel-corridor rhythm
  const hoopAo = [0.6, 0.6, 0.85, 0.85];
  const hoops = Math.floor((z1 - z0) / 1.2);
  for (let i = 1; i <= hoops; i++) {
    const zc = z0 + ((z1 - z0) * i) / (hoops + 1);
    for (const [xAt, dir] of [[x0, 1], [x1, -1]]) {
      const far = xAt + dir * 0.07;
      builder.box(
        [Math.min(xAt, far), 0.05, zc - 0.08], [Math.max(xAt, far), wallH, zc + 0.08],
        wall, { uvScale: 1.0, ao: hoopAo },
      );
    }
    builder.box(
      [cx - apexHalf, zone.h - 0.08, zc - 0.08], [cx + apexHalf, zone.h, zc + 0.08],
      wall, { uvScale: 1.0, ao: hoopAo },
    );
  }
}

function buildHex(ctx) {
  const { zone, atlas, builder, shipMap } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const wall = atlas.layer(zone.tex.wall);
  const midH = 1.1;
  const ceilHalf = 0.35;
  const cx = (x0 + x1) / 2;
  buildFloorCeiling(ctx, atlas.layer(zone.tex.floor), atlas.layer(zone.tex.ceil), { skipCeiling: true });
  const { h } = zone;
  buildWall(ctx, 'z', z0, x0, x1, h, +1, wall, ctx.openings.nz);
  buildWall(ctx, 'z', z1, x0, x1, h, -1, wall, ctx.openings.pz);
  // vertical lower walls
  wallQuad(builder, 'x', x0, z0, z1, 0, midH, +1, wall);
  wallQuad(builder, 'x', x1, z0, z1, 0, midH, -1, wall);
  // angled upper walls in to the ceiling strip (wound to face inward/down)
  builder.quad(
    [cx - ceilHalf, h, z0], [cx - ceilHalf, h, z1], [x0, midH, z1], [x0, midH, z0],
    wall, { ao: CEIL_AO4 },
  );
  builder.quad(
    [cx + ceilHalf, h, z1], [cx + ceilHalf, h, z0], [x1, midH, z0], [x1, midH, z1],
    wall, { ao: CEIL_AO4 },
  );
  builder.quad(
    [cx - ceilHalf, h, z0], [cx + ceilHalf, h, z0], [cx + ceilHalf, h, z1], [cx - ceilHalf, h, z1],
    atlas.layer(zone.tex.ceil), { ao: CEIL_AO4 },
  );
  // side colliders
  shipMap.collision.addBox([x0 - 0.2, 0, z0], [x0 + 0.02, h, z1], { wall: true });
  shipMap.collision.addBox([x1 - 0.02, 0, z0], [x1 + 0.2, h, z1], { wall: true });
}

function buildOctagon(ctx) {
  const { zone, atlas, builder, shipMap } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const wall = atlas.layer(zone.tex.wall);
  const h = zone.h;
  const cut = 1.4;
  buildFlat(ctx);
  const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
  // 45° corner walls; guard winding by checking the normal faces the center
  const corner = (ax, az, bx, bz) => {
    let A = [ax, az], B = [bx, bz];
    // normal of segment A->B (rotated -90°): (dz, -dx)
    const nX = B[1] - A[1], nZ = -(B[0] - A[0]);
    const toC = [cx - A[0], cz - A[1]];
    if (nX * toC[0] + nZ * toC[1] < 0) { const t = A; A = B; B = t; }
    builder.quad(
      [A[0], 0, A[1]], [B[0], 0, B[1]], [B[0], h, B[1]], [A[0], h, A[1]],
      wall, { ao: [0.75, 0.75, 0.85, 0.85] },
    );
    // blocky corner collider
    const minX = Math.min(ax, bx), maxX = Math.max(ax, bx);
    const minZ = Math.min(az, bz), maxZ = Math.max(az, bz);
    // cover the outer triangle with a box whose inner corner touches the diagonal
    const boxX = minX === x0 ? [x0, (minX + maxX) / 2] : [(minX + maxX) / 2, x1];
    const boxZ = minZ === z0 ? [z0, (minZ + maxZ) / 2] : [(minZ + maxZ) / 2, z1];
    shipMap.collision.addBox([boxX[0], 0, boxZ[0]], [boxX[1], h, boxZ[1]], { corner: true });
  };
  corner(x0 + cut, z0, x0, z0 + cut);
  corner(x1 - cut, z0, x1, z0 + cut);
  corner(x0 + cut, z1, x0, z1 - cut);
  corner(x1 - cut, z1, x1, z1 - cut);
}
