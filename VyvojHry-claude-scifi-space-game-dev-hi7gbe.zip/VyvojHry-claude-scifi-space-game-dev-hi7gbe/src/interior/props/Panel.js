/**
 * Panel — flush wall-mounted breaker/access panel. Back against a wall,
 * front faces local -z. opts: { w, h, y, tex, interact }
 */
import { PropBase } from './PropBase.js';

export class Panel extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 1.0;
    const h = this.opts.h ?? 1.0;
    const y = this.opts.y ?? 0.7;
    const L = (n) => ctx.atlas.layer(n);
    this.addBox([-w / 2, y, -0.09], [w / 2, y + h, 0], {
      all: L('wall_military'), nz: L(this.opts.tex ?? 'panel_wall'),
    }, { uvScale: 1 / Math.max(w, h) });
    if (this.opts.interact) {
      const it = typeof this.opts.interact === 'string'
        ? { label: 'INSPECT PANEL', fn: (game) => game.notify(this.opts.interact) }
        : this.opts.interact;
      this.addInteract([-w / 2 - 0.15, y - 0.4, -0.8], [w / 2 + 0.15, y + h + 0.3, 0.05], it.label, it.fn);
    }
  }
}
