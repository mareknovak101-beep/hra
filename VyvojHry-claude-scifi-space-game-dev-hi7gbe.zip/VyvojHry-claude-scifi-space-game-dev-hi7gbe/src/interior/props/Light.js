/**
 * LightFixture — the visible housing for a ceiling tube light. Purely visual
 * (the actual illumination is a LightSystem entry); the emissive lens face is
 * what the player sees glowing. Long axis along local x.
 * opts: { len, y (mount height, defaults to ceiling), color: 'warm'|'red',
 *         lens (texture), off: bool }
 */
import { PropBase } from './PropBase.js';

export class LightFixture extends PropBase {
  build(ctx) {
    const len = this.opts.len ?? 1.4;
    const y = this.opts.y ?? ctx.zone.h - 0.14;
    const L = (n) => ctx.atlas.layer(n);
    const housing = L('door_frame');
    const lens = L(this.opts.lens ?? 'light_tube');
    this.addBox([-len / 2, y, -0.11], [len / 2, y + 0.14, 0.11], {
      all: housing, ny: lens,
    }, {
      uvScale: 1 / len,
      emissive: { ny: this.opts.off ? 0 : 1 },
    });
  }
}
