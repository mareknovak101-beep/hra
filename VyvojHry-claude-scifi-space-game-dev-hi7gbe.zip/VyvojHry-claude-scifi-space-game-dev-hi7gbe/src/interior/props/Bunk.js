/**
 * Bunk — crew bed, long axis along local z, headboard at -z (against wall).
 * opts: { double: bool, interact: {label, fn} }
 */
import { PropBase } from './PropBase.js';

export class Bunk extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    const frame = L('wall_steel');
    const mat = L('mattress');
    const len = 2.0, w = 0.9;

    const level = (y) => {
      this.addBox([-w / 2, y, -len / 2], [w / 2, y + 0.18, len / 2], frame, { uvScale: 0.6 });
      this.addBox([-w / 2 + 0.05, y + 0.18, -len / 2 + 0.05],
        [w / 2 - 0.05, y + 0.32, len / 2 - 0.1], mat, { uvScale: 0.7 });
      // pillow — brighter mattress block
      this.addBox([-w / 2 + 0.12, y + 0.32, -len / 2 + 0.1],
        [w / 2 - 0.12, y + 0.4, -len / 2 + 0.45], mat, { uvScale: 1.4, ao: [1.15, 1.15, 1.15, 1.15] });
    };
    level(0.25);
    if (this.opts.double) {
      level(1.25);
      // corner posts
      for (const [px, pz] of [[-w / 2, -len / 2], [w / 2 - 0.06, -len / 2], [-w / 2, len / 2 - 0.06], [w / 2 - 0.06, len / 2 - 0.06]]) {
        this.addBox([px, 0, pz], [px + 0.06, 1.6, pz + 0.06], frame, { uvScale: 1.5 });
      }
    }
    this.addCollider([-w / 2, 0, -len / 2], [w / 2, this.opts.double ? 1.6 : 0.62, len / 2]);
    const it = this.opts.interact;
    if (it) {
      this.addInteract([-w / 2 - 0.3, 0, -len / 2], [w / 2 + 0.3, 1.7, len / 2 + 0.3], it.label, it.fn);
    }
  }
}
