/**
 * HackingTerminal — mainframe access console (Computer Core, later derelicts).
 * The HackingMinigame itself is Phase 7; the prop, screen and lockout fiction
 * are in place now so the room reads correctly.
 */
import { PropBase } from './PropBase.js';
import { LIGHTING } from '../../core/Constants.js';

export class HackingTerminal extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    // wide desk console with double phosphor screens
    this.addBox([-0.9, 0, -0.45], [0.9, 0.8, 0.02], {
      all: L('wall_military'), nz: L('console_base'),
    }, { uvScale: 0.9 });
    for (const [a, b] of [[-0.85, -0.03], [0.03, 0.85]]) {
      this.addBox([a, 0.8, -0.2], [b, 1.5, 0.02], { all: L('door_frame') }, { uvScale: 1.2 });
      this.screenFace([b - 0.05, 0.85, -0.215], [a + 0.05, 0.85, -0.215],
        [a + 0.05, 1.45, -0.215], [b - 0.05, 1.45, -0.215], L('screen_phosphor'));
    }
    this.addCollider([-0.9, 0, -0.47], [0.9, 1.5, 0.02]);

    const pos = this.world(0, 1.2, -0.6);
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.TERMINAL_PHOSPHOR, pos);

    this.addInteract([-1.1, 0, -1.1], [1.1, 1.7, 0.1], 'ACCESS MAINFRAME', (game) => {
      game.audio?.playDenyBuzz();
      game.notify('MAINFRAME LOCKED - INTRUSION COUNTERMEASURES ACTIVE');
    });
  }
}
