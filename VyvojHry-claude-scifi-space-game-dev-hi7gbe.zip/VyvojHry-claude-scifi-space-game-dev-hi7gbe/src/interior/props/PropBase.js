/**
 * PropBase — shared placement machinery for every interior prop.
 *
 * Props are authored in local space: origin on the floor, +y up, the prop's
 * FRONT facing local -z (like the camera at yaw 0). `facing` rotates the prop
 * in quarter turns: 'N' (-z), 'E' (+x), 'S' (+z), 'W' (-x). Quarter turns keep
 * every box axis-aligned, which keeps collision and meshing trivial.
 */

const FACING_TURNS = { N: 0, E: 1, S: 2, W: 3 };
// local face key -> world face key, per quarter turn (nz→px→pz→nx cycle)
const FACE_CYCLE = ['nz', 'px', 'pz', 'nx'];

export class PropBase {
  /**
   * @param {object} ctx room-dressing context (builder, shipMap, atlas, zone)
   * @param {number} x world x of prop origin
   * @param {number} z world z of prop origin
   * @param {'N'|'E'|'S'|'W'} facing
   * @param {object} opts subclass-specific options, available in build()
   */
  constructor(ctx, x, z, facing = 'N', opts = {}) {
    this.ctx = ctx;
    this.x = x;
    this.z = z;
    this.turns = FACING_TURNS[facing] ?? 0;
    this.opts = opts;
    this.build(ctx);
  }

  /** Subclasses override. */
  build(_ctx) {}

  /** Rotate a local (x,z) pair by the prop's quarter turns. */
  rot(lx, lz) {
    let x = lx, z = lz;
    for (let i = 0; i < this.turns; i++) {
      const nx = -z, nz = x;
      x = nx; z = nz;
    }
    return [x, z];
  }

  /** Local point -> world point. */
  world(lx, ly, lz) {
    const [x, z] = this.rot(lx, lz);
    return [this.x + x, ly, this.z + z];
  }

  /** Local AABB -> world AABB {min, max}. */
  worldBox(localMin, localMax) {
    const a = this.world(localMin[0], localMin[1], localMin[2]);
    const b = this.world(localMax[0], localMax[1], localMax[2]);
    return {
      min: [Math.min(a[0], b[0]), Math.min(a[1], b[1]), Math.min(a[2], b[2])],
      max: [Math.max(a[0], b[0]), Math.max(a[1], b[1]), Math.max(a[2], b[2])],
    };
  }

  /** Permute a {face: layer} map through the prop rotation. */
  rotFaces(layers) {
    if (typeof layers === 'number') return layers;
    const out = {};
    for (const [face, v] of Object.entries(layers)) {
      const i = FACE_CYCLE.indexOf(face);
      out[i === -1 ? face : FACE_CYCLE[(i + this.turns) % 4]] = v;
    }
    return out;
  }

  /**
   * Add a textured box to the zone's static mesh.
   * layers/emissive maps use LOCAL face keys and get rotated with the prop.
   */
  addBox(localMin, localMax, layers, opts = {}) {
    const { min, max } = this.worldBox(localMin, localMax);
    const worldOpts = { ...opts };
    if (typeof opts.emissive === 'object') worldOpts.emissive = this.rotFaces(opts.emissive);
    this.ctx.builder.box(min, max, this.rotFaces(layers), worldOpts);
    return { min, max };
  }

  /** Register a solid collider (local AABB). */
  addCollider(localMin, localMax) {
    const { min, max } = this.worldBox(localMin, localMax);
    return this.ctx.shipMap.collision.addBox(min, max, this);
  }

  /**
   * Register an interaction volume (local AABB).
   * @param {string} label shown as "[E] LABEL" on the HUD
   * @param {(game: object) => void} onInteract
   */
  addInteract(localMin, localMax, label, onInteract) {
    const { min, max } = this.worldBox(localMin, localMax);
    return this.ctx.shipMap.addInteractable({ min, max, label, onInteract, prop: this });
  }

  /**
   * Add an arbitrary quad (local-space points, CCW from front).
   * Used for sloped console faces and other non-box details.
   */
  addQuad(p0, p1, p2, p3, layer, opts = {}) {
    const pts = [p0, p1, p2, p3].map((p) => this.world(p[0], p[1], p[2]));
    // quarter turns flip winding never (rotation, det=+1) — order preserved
    this.ctx.builder.quad(pts[0], pts[1], pts[2], pts[3], layer, opts);
  }

  /**
   * Emissive display face with NORMALIZED UVs: the whole texture mapped exactly
   * once across the quad, corner to corner. Corners are given as
   * bottom-left, bottom-right, top-right, top-left AS SEEN FROM THE FRONT
   * (local -z), so for a front-facing display the "left" corners are at +x.
   *
   * Every other interior surface uses a planar world-space UV projection, which
   * is right for tiling plating and wrong for a screen: the tile lands wherever
   * the prop happens to sit in the room, so a baked readout came out offset and
   * wrapped through the middle of its own glyphs. A display is one image on one
   * rectangle and needs its own mapping.
   */
  screenFace(bl, br, tr, tl, layer, emissive = 1) {
    this.addQuad(bl, br, tr, tl, layer, {
      uvs: [[0, 1], [1, 1], [1, 0], [0, 0]],
      emissive,
    });
  }

  /** Solid box + mesh in one call — the common case. */
  solidBox(localMin, localMax, layers, opts = {}) {
    this.addBox(localMin, localMax, layers, opts);
    this.addCollider(localMin, localMax);
  }

  /**
   * Box with its top edges chamfered (bevelled) by `bev` — reads as a softer,
   * less-boxy solid (crates, lockers, cabinets). Collider stays the full AABB.
   */
  chamferTop(localMin, localMax, layer, bev, opts = {}) {
    const [x0, y0, z0] = localMin;
    const [x1, y1, z1] = localMax;
    const yb = y1 - bev;
    this.addBox([x0, y0, z0], [x1, yb, z1], layer, { ...opts, skip: ['py'] });
    const o = { uvScale: opts.uvScale };
    // inset top face + four chamfer trapezoids (wound so normals face out/up)
    this.addQuad([x0 + bev, y1, z0 + bev], [x0 + bev, y1, z1 - bev], [x1 - bev, y1, z1 - bev], [x1 - bev, y1, z0 + bev], layer, o);
    this.addQuad([x0, yb, z0], [x0 + bev, y1, z0 + bev], [x1 - bev, y1, z0 + bev], [x1, yb, z0], layer, o);
    this.addQuad([x1, yb, z1], [x1 - bev, y1, z1 - bev], [x0 + bev, y1, z1 - bev], [x0, yb, z1], layer, o);
    this.addQuad([x0, yb, z1], [x0 + bev, y1, z1 - bev], [x0 + bev, y1, z0 + bev], [x0, yb, z0], layer, o);
    this.addQuad([x1, yb, z0], [x1 - bev, y1, z0 + bev], [x1 - bev, y1, z1 - bev], [x1, yb, z1], layer, o);
    this.addCollider(localMin, localMax);
  }
}

/**
 * GenericBlock — a one-off textured solid box with optional interaction.
 * For simple set dressing that doesn't deserve its own class.
 * opts: { min, max, layers, emissive, interact: {label, fn, pad} }
 */
export class GenericBlock extends PropBase {
  build(_ctx) {
    const o = this.opts;
    this.solidBox(o.min, o.max, o.layers, { emissive: o.emissive, ao: o.ao });
    if (o.interact) {
      const pad = o.interact.pad ?? 0.25;
      this.addInteract(
        [o.min[0] - pad, o.min[1], o.min[2] - pad],
        [o.max[0] + pad, o.max[1] + pad, o.max[2] + pad],
        o.interact.label, o.interact.fn,
      );
    }
  }
}
