/**
 * SaveTerminal — the diegetic save ritual station (context/04 §10).
 * Pedestal console with a phosphor screen. Interacting plays the mechanical
 * "chunk" and prints PROGRESS RECORDED. Full SaveSystem lands in Phase 5;
 * this session the terminal performs the ritual and records a marker.
 */
import { PropBase } from './PropBase.js';
import { LIGHTING } from '../../core/Constants.js';

export class SaveTerminal extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    // pedestal
    this.addBox([-0.35, 0, -0.3], [0.35, 1.05, 0.02], {
      all: L('wall_military'), nz: L('console_base'),
    }, { uvScale: 1.2 });
    // screen head: bezel housing with the phosphor glass set into it
    this.addBox([-0.4, 1.05, -0.34], [0.4, 1.62, 0.02], { all: L('door_frame') }, { uvScale: 1.2 });
    this.screenFace([0.34, 1.11, -0.355], [-0.34, 1.11, -0.355], [-0.34, 1.56, -0.355],
      [0.34, 1.56, -0.355], L('screen_phosphor'));
    this.addCollider([-0.4, 0, -0.36], [0.4, 1.62, 0.02]);

    // its own phosphor pool of light
    const pos = this.world(0, 1.3, -0.5);
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.TERMINAL_PHOSPHOR, pos);

    this.addInteract([-0.6, 0, -1.0], [0.6, 1.8, 0.1], 'RECORD PROGRESS', (game) => {
      game.audio?.playSaveChunk();
      game.notify('PROGRESS RECORDED');
      game.events.emit('save:ritual', { terminal: this, zone: ctx.zone.id });
    });
  }
}
