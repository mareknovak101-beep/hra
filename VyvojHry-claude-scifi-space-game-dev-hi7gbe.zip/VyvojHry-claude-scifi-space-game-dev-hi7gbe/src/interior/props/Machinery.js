/**
 * Machinery — generic industrial equipment block with gauge/cable dressing.
 * opts: { size:[w,h,d], tex, topPipe: bool, interact }
 */
import { PropBase } from './PropBase.js';

export class Machinery extends PropBase {
  build(ctx) {
    const [w, h, d] = this.opts.size ?? [1.2, 1.6, 0.8];
    const L = (n) => ctx.atlas.layer(n);
    const tex = L(this.opts.tex ?? 'machinery');
    this.solidBox([-w / 2, 0, -d], [w / 2, h, 0], { all: L('wall_military'), nz: tex, pz: tex }, {
      uvScale: 1 / Math.max(w, h),
      ao: [0.85, 0.85, 1, 1],
    });
    // Optional bank of small inset displays across the front. A mainframe
    // cabinet is a RACK of readouts — mapping one terminal texture across a
    // 1.4 × 2.3 m face just blew a single screenshot up to wall size.
    const bank = this.opts.screens;
    if (bank) {
      const [cols, rows] = bank.grid ?? [2, 4];
      const layer = L(bank.tex ?? 'screen_phosphor');
      const mx = 0.09, my = 0.13;
      const cw = (w - mx * (cols + 1)) / cols;
      const ch = (h - my * (rows + 1)) / rows;
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const x0 = -w / 2 + mx + c * (cw + mx), y0 = my + r * (ch + my);
          // recessed bezel, then the glass standing in it
          this.addBox([x0 - 0.03, y0 - 0.03, -d - 0.02], [x0 + cw + 0.03, y0 + ch + 0.03, -d],
            L('door_frame'), { uvScale: 1 });
          this.screenFace([x0 + cw, y0, -d - 0.03], [x0, y0, -d - 0.03],
            [x0, y0 + ch, -d - 0.03], [x0 + cw, y0 + ch, -d - 0.03], layer, 0.9);
        }
      }
    }
    if (this.opts.topPipe) {
      this.addBox([-w / 2 + 0.1, h, -d / 2 - 0.08], [w / 2 - 0.1, h + 0.16, -d / 2 + 0.08],
        L('pipe'), { uvScale: 1 / w });
    }
    if (this.opts.interact) {
      const it = typeof this.opts.interact === 'string'
        ? { label: 'INSPECT MACHINERY', fn: (game) => game.notify(this.opts.interact) }
        : this.opts.interact;
      this.addInteract([-w / 2 - 0.2, 0, -d - 0.6], [w / 2 + 0.2, h + 0.2, 0.05], it.label, it.fn);
    }
  }
}
