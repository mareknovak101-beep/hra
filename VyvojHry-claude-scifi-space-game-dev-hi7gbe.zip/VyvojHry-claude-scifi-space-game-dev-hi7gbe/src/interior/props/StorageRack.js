/**
 * StorageRack — shelving unit stocked with boxes, back against a wall.
 * opts: { w, h, interact }
 */
import { PropBase } from './PropBase.js';

export class StorageRack extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 1.6;
    const h = this.opts.h ?? 1.9;
    const L = (n) => ctx.atlas.layer(n);
    this.solidBox([-w / 2, 0, -0.5], [w / 2, h, 0], {
      all: L('wall_military'), nz: L('shelf_storage'),
    }, { uvScale: 1 / Math.max(w, h) });
    if (this.opts.interact) {
      const it = typeof this.opts.interact === 'string'
        ? { label: 'SEARCH SHELVES', fn: (game) => game.notify(this.opts.interact) }
        : this.opts.interact;
      this.addInteract([-w / 2 - 0.15, 0, -1.0], [w / 2 + 0.15, h, 0.05], it.label, it.fn);
    }
  }
}
