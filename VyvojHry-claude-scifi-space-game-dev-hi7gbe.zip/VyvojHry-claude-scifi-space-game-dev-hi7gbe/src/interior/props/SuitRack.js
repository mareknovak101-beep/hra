/**
 * SuitRack — wall-mounted EVA suit on its stowage frame. Front faces -z.
 */
import { PropBase } from './PropBase.js';

export class SuitRack extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    this.addBox([-0.55, 0.1, -0.28], [0.55, 2.1, 0], {
      all: L('wall_military'), nz: L('suit_rack'),
    }, { uvScale: 0.5, ao: [0.85, 0.85, 1, 1] });
    this.addCollider([-0.55, 0, -0.3], [0.55, 2.1, 0]);
    this.addInteract([-0.7, 0, -0.9], [0.7, 2.2, 0.05], 'EVA SUIT', (game) => {
      game.notify(this.opts.text ?? 'EVA SUIT - SEALS NOMINAL. CERTIFICATION EXPIRED 212 DAYS AGO.');
    });
  }
}
