/**
 * Door — vertical-sliding bulkhead panel on a zone boundary. The panel is a
 * dynamic mesh (own model matrix); when open it rises fully behind the lintel
 * wall, so the mechanism stays hidden. Interact toggles; collision follows.
 */
import { DOOR } from '../../core/Constants.js';
import { MeshBuilder } from '../../rendering/MeshBuilder.js';
import { Mat4 } from '../../utils/MathUtils.js';

export class Door {
  /**
   * @param {object} spec {id, a, b, plane:'x'|'z', at, center, w, h, kind}
   * @param {object} shipMap
   * @param {object} atlas TextureAtlas
   * @param {import('../../core/Renderer.js').Renderer} renderer
   * @param {import('../../core/EventBus.js').EventBus} events
   */
  constructor(spec, shipMap, atlas, renderer, events) {
    this.spec = spec;
    this.events = events;
    this.openT = 0; // 0 closed, 1 open
    this.target = 0;
    this.moving = false;

    const w = spec.w ?? DOOR.WIDTH;
    const h = spec.h ?? DOOR.HEIGHT;
    this.w = w;
    this.h = h;

    // Panel mesh in local space, centered on the boundary plane.
    const b = new MeshBuilder();
    const t = DOOR.THICKNESS / 2;
    const layers = {
      all: atlas.layer('door_panel'),
      py: atlas.layer('door_frame'),
      ny: atlas.layer('door_frame'),
    };
    // uv scaled to door height so the panel texture reads once, not tiled
    if (spec.plane === 'z') {
      b.box([-w / 2, 0, -t], [w / 2, h, t], layers, { uvScale: 1 / h });
    } else {
      b.box([-t, 0, -w / 2], [t, h, w / 2], layers, { uvScale: 1 / h });
    }
    const data = b.finish();
    this.mesh = renderer.createInteriorMesh(data.vertexData, data.indexData);
    this.modelMatrix = Mat4.create();

    // World-space collider at the closed position.
    const cx = spec.plane === 'z' ? spec.center : spec.at;
    const cz = spec.plane === 'z' ? spec.at : spec.center;
    this.cx = cx;
    this.cz = cz;
    const half = spec.plane === 'z' ? [w / 2, 0, t] : [t, 0, w / 2];
    this.collider = shipMap.collision.addBox(
      [cx - half[0] - (spec.plane === 'z' ? 0 : 0.05), 0, cz - half[2] - (spec.plane === 'z' ? 0.05 : 0)],
      [cx + half[0] + (spec.plane === 'z' ? 0 : 0.05), h, cz + half[2] + (spec.plane === 'z' ? 0.05 : 0)],
      this,
    );

    // Interaction volume spans both sides of the doorway.
    const pad = 0.7;
    shipMap.addInteractable({
      min: [cx - w / 2 - 0.2 - (spec.plane === 'x' ? pad : 0), 0, cz - w / 2 - 0.2 - (spec.plane === 'z' ? pad : 0)],
      max: [cx + w / 2 + 0.2 + (spec.plane === 'x' ? pad : 0), h, cz + w / 2 + 0.2 + (spec.plane === 'z' ? pad : 0)],
      label: () => (this.target === 0 ? 'OPEN DOOR' : 'CLOSE DOOR'),
      onInteract: () => this.toggle(),
      prop: this,
    });

    this._updateMatrix();
  }

  toggle() {
    this.target = this.target === 0 ? 1 : 0;
    this.moving = true;
    this.events.emit('door:toggle', { door: this, opening: this.target === 1 });
  }

  update(dt) {
    if (!this.moving) return;
    const dir = Math.sign(this.target - this.openT);
    this.openT += (dir * dt) / DOOR.SLIDE_TIME;
    if ((dir > 0 && this.openT >= this.target) || (dir < 0 && this.openT <= this.target)) {
      this.openT = this.target;
      this.moving = false;
      this.events.emit('door:settled', { door: this, open: this.target === 1 });
    }
    // Solid until mostly open.
    this.collider.active = this.openT < 0.65;
    this._updateMatrix();
  }

  _updateMatrix() {
    // ease the slide slightly (quantized enough by pixel rendering)
    const t = this.openT;
    const eased = t * t * (3 - 2 * t);
    const rise = eased * (this.h - 0.06);
    Mat4.translation(this.modelMatrix, this.cx, rise, this.cz);
  }
}
