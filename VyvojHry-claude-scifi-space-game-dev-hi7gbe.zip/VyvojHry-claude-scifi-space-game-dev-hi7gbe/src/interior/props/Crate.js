/**
 * Crate — cargo box. opts: { size:[w,h,d], tex:'crate_tech'|'crate_hazard'|
 * 'crate_cryo', interact:{label,fn} | string (inspect text), stackOn: h }
 */
import { PropBase } from './PropBase.js';

export class Crate extends PropBase {
  build(ctx) {
    const [w, h, d] = this.opts.size ?? [1.2, 1.0, 1.2];
    const y0 = this.opts.stackOn ?? 0;
    const tex = ctx.atlas.layer(this.opts.tex ?? 'crate_tech');
    // chamfered top edges so stacked cargo reads less like plain cubes
    this.chamferTop([-w / 2, y0, -d / 2], [w / 2, y0 + h, d / 2], tex, Math.min(0.12, h * 0.15), {
      uvScale: 1 / Math.max(w, h),
      ao: [0.9, 0.9, 1, 1],
    });
    if (this.opts.interact) {
      const it = typeof this.opts.interact === 'string'
        ? { label: 'INSPECT CRATE', fn: (game) => game.notify(this.opts.interact) }
        : this.opts.interact;
      this.addInteract([-w / 2 - 0.2, y0, -d / 2 - 0.2], [w / 2 + 0.2, y0 + h + 0.2, d / 2 + 0.2],
        it.label, it.fn);
    }
  }
}
