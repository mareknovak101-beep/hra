/**
 * Pipe — a run of piping along a wall or ceiling, long axis local x.
 * opts: { len, y, dia, offset (distance from wall plane, local -z out) }
 */
import { PropBase } from './PropBase.js';

export class Pipe extends PropBase {
  build(ctx) {
    const len = this.opts.len ?? 3.0;
    const dia = this.opts.dia ?? 0.14;
    const y = this.opts.y ?? 2.0;
    const off = this.opts.offset ?? 0.06;
    const tex = ctx.atlas.layer('pipe');
    this.addBox([-len / 2, y, -off - dia], [len / 2, y + dia, -off], tex, { uvScale: 1 / len });
  }
}
