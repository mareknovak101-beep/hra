/**
 * Seat — chair; the cockpit variant is the cracked-leather pilot chair from
 * the concept art. Faces local -z. opts: { pilot: bool, interact }
 */
import { PropBase } from './PropBase.js';

export class Seat extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    const cushion = L('seat_leather');
    const frame = L('wall_steel');
    const w = this.opts.pilot ? 0.75 : 0.55;

    // pedestal + seat pan + backrest (back at +z)
    this.addBox([-0.12, 0, -0.12], [0.12, 0.32, 0.12], frame, { uvScale: 2 });
    this.addBox([-w / 2, 0.32, -w / 2], [w / 2, 0.5, w / 2], cushion, { uvScale: 1.4 });
    this.addBox([-w / 2, 0.5, w / 2 - 0.16], [w / 2, this.opts.pilot ? 1.45 : 1.1, w / 2], cushion, { uvScale: 1.4 });
    if (this.opts.pilot) {
      // armrests
      for (const sx of [-1, 1]) {
        this.addBox([sx * w / 2 + (sx < 0 ? -0.1 : 0), 0.62, -0.3], [sx * w / 2 + (sx < 0 ? 0 : 0.1), 0.72, w / 2], frame, { uvScale: 1.6 });
      }
      // headrest
      this.addBox([-0.2, 1.45, w / 2 - 0.16], [0.2, 1.62, w / 2], cushion, { uvScale: 2 });
    }
    this.addCollider([-w / 2 - 0.05, 0, -w / 2 - 0.05], [w / 2 + 0.05, this.opts.pilot ? 1.45 : 1.0, w / 2 + 0.05]);
    if (this.opts.interact) {
      // volume tops above standing eye height (1.6) so a level gaze still hits
      this.addInteract([-w / 2 - 0.3, 0, -w / 2 - 0.5], [w / 2 + 0.3, 1.9, w / 2 + 0.3],
        this.opts.interact.label, this.opts.interact.fn);
    }
  }
}
