/**
 * Table — mess/desk table. opts: { size:[w,d], h, interact }
 */
import { PropBase } from './PropBase.js';

export class Table extends PropBase {
  build(ctx) {
    const [w, d] = this.opts.size ?? [1.4, 0.8];
    const h = this.opts.h ?? 0.78;
    const L = (n) => ctx.atlas.layer(n);
    this.addBox([-w / 2, h - 0.06, -d / 2], [w / 2, h, d / 2], L('table_top'), { uvScale: 1 / w });
    for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      this.addBox(
        [sx * (w / 2 - 0.08) - 0.04, 0, sz * (d / 2 - 0.08) - 0.04],
        [sx * (w / 2 - 0.08) + 0.04, h - 0.06, sz * (d / 2 - 0.08) + 0.04],
        L('wall_steel'), { uvScale: 2 },
      );
    }
    this.addCollider([-w / 2, 0, -d / 2], [w / 2, h, d / 2]);
    if (this.opts.interact) {
      this.addInteract([-w / 2 - 0.3, 0, -d / 2 - 0.3], [w / 2 + 0.3, h + 0.5, d / 2 + 0.3],
        this.opts.interact.label, this.opts.interact.fn);
    }
  }
}
