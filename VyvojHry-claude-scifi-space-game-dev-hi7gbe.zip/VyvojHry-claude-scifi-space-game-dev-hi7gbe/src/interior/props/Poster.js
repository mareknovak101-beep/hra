/**
 * Poster — the in-fiction printed ship schematic (context/01 §7), pinned flat
 * to a wall. Front faces local -z. Doubles as the diegetic ship map.
 */
import { PropBase } from './PropBase.js';

export class Poster extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 0.85;
    const h = this.opts.h ?? 1.1;
    const y = this.opts.y ?? 0.95;
    // printed sheet with a normalized mapping — a poster is one image on one
    // rectangle, so it must NOT use the tiling world-planar UV the plating uses
    // (that landed the print wherever the prop sat and cut the schematic
    // through the middle of its own labels)
    this.addBox([-w / 2, y, -0.03], [w / 2, y + h, 0],
      { all: ctx.atlas.layer('door_frame') }, { uvScale: 1 });
    this.screenFace([w / 2 - 0.01, y + 0.01, -0.035], [-w / 2 + 0.01, y + 0.01, -0.035],
      [-w / 2 + 0.01, y + h - 0.01, -0.035], [w / 2 - 0.01, y + h - 0.01, -0.035],
      ctx.atlas.layer('poster_schematic'), 0);
    this.addInteract([-w / 2 - 0.2, y - 0.4, -0.8], [w / 2 + 0.2, y + h + 0.2, 0.05],
      'SHIP SCHEMATIC', (game) => {
        game.notify('HSV AETHON - CUTAWAY, PRINT 3 OF 40. SOMEONE CIRCLED THE VENTS IN PEN.');
      });
  }
}
