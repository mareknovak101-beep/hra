/**
 * Console — freestanding control station: cabinet, sloped button deck, screen
 * slab. Front faces local -z. opts: { w, screen ('screen_amber' etc.),
 * interact: {label, fn}, screenEmissive (default 1) }
 */
import { PropBase } from './PropBase.js';

export class Console extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 1.2;
    const L = (n) => ctx.atlas.layer(n);
    const metal = L('wall_military');
    const face = L('console_base');

    // cabinet
    this.addBox([-w / 2, 0, -0.38], [w / 2, 0.72, 0.02], {
      all: metal, nz: face,
    }, { uvScale: 1 });
    // sloped button deck (rises toward the back)
    this.addQuad(
      [-w / 2, 0.72, -0.38], [w / 2, 0.72, -0.38],
      [w / 2, 0.94, -0.1], [-w / 2, 0.94, -0.1],
      face, { uvScale: 0.8 },
    );
    // deck side cheeks (triangles — last vertex repeated)
    this.addQuad([-w / 2, 0.72, -0.38], [-w / 2, 0.72, -0.1], [-w / 2, 0.94, -0.1], [-w / 2, 0.94, -0.1], metal, {});
    this.addQuad([w / 2, 0.72, -0.38], [w / 2, 0.94, -0.1], [w / 2, 0.72, -0.1], [w / 2, 0.72, -0.1], metal, {});
    // screen slab (screenH lets low consoles keep sightlines clear): a metal
    // bezel housing with the glass set into it, so the display reads as inset
    // hardware rather than a decal on the front of a box
    const screenTop = 0.94 + (this.opts.screenH ?? 0.48);
    const screen = L(this.opts.screen ?? 'screen_amber');
    this.addBox([-w / 2 + 0.08, 0.94, -0.14], [w / 2 - 0.08, screenTop, 0.02],
      { all: metal }, { uvScale: 1 });
    const sx = w / 2 - 0.14, s0 = 0.98, s1 = screenTop - 0.04;
    this.screenFace([sx, s0, -0.155], [-sx, s0, -0.155], [-sx, s1, -0.155], [sx, s1, -0.155],
      screen, this.opts.screenEmissive ?? 1);

    this.addCollider([-w / 2, 0, -0.4], [w / 2, screenTop, 0.02]);
    if (this.opts.interact) {
      this.addInteract(
        [-w / 2 - 0.15, 0, -0.9], [w / 2 + 0.15, 1.6, 0.1],
        this.opts.interact.label, this.opts.interact.fn,
      );
    }
  }
}

/**
 * WallScreen — flush wall-mounted display. Back sits against a wall.
 * opts: { w, h, y, screen, emissive, interact }
 */
export class WallScreen extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 0.9;
    const h = this.opts.h ?? 0.6;
    const y = this.opts.y ?? 1.1;
    const L = (n) => ctx.atlas.layer(n);
    this.addBox([-w / 2, y, -0.08], [w / 2, y + h, 0.0], { all: L('door_frame') }, { uvScale: 1 });
    const sx = w / 2 - 0.05;
    this.screenFace([sx, y + 0.04, -0.095], [-sx, y + 0.04, -0.095],
      [-sx, y + h - 0.04, -0.095], [sx, y + h - 0.04, -0.095],
      L(this.opts.screen ?? 'screen_amber'), this.opts.emissive ?? 1);
    if (this.opts.interact) {
      this.addInteract([-w / 2 - 0.2, y - 0.5, -0.8], [w / 2 + 0.2, y + h + 0.3, 0.1],
        this.opts.interact.label, this.opts.interact.fn);
    }
  }
}
