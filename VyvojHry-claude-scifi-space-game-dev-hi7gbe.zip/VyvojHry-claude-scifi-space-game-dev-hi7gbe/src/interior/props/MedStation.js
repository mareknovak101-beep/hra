/**
 * MedStation — medical bed with monitor arm. Long axis local z, head at -z.
 * opts: { interact }
 */
import { PropBase } from './PropBase.js';

export class MedStation extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    // bed platform
    this.addBox([-0.5, 0, -1.05], [0.5, 0.55, 1.05], L('med_panel'), { uvScale: 0.8 });
    this.addBox([-0.42, 0.55, -0.95], [0.42, 0.68, 0.95], L('mattress'), { uvScale: 0.8 });
    // monitor pylon at the head
    this.addBox([-0.12, 0, -1.45], [0.12, 1.5, -1.1], L('wall_steel'), { uvScale: 1 });
    // monitor faces +z (down the bed toward the patient's feet), so its glass
    // corners are mirrored relative to a front-facing display
    this.addBox([-0.3, 1.5, -1.42], [0.3, 1.95, -1.12], { all: L('wall_steel') }, { uvScale: 1.6 });
    this.screenFace([-0.25, 1.55, -1.105], [0.25, 1.55, -1.105], [0.25, 1.9, -1.105],
      [-0.25, 1.9, -1.105], L('screen_amber'));
    this.addCollider([-0.5, 0, -1.45], [0.5, 0.75, 1.05]);
    if (this.opts.interact) {
      this.addInteract([-0.8, 0, -1.5], [0.8, 1.9, 1.3], this.opts.interact.label, this.opts.interact.fn);
    }
  }
}
