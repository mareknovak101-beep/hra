/**
 * FuelPort — hull fuel coupling, flush wall mount, front faces local -z.
 */
import { PropBase } from './PropBase.js';

export class FuelPort extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    this.addBox([-0.4, 0.5, -0.16], [0.4, 1.3, 0], {
      all: L('door_frame'), nz: L('machinery'),
    }, { uvScale: 1.2 });
    // coupling collar
    this.addBox([-0.14, 0.78, -0.3], [0.14, 1.06, -0.16], L('pipe'), { uvScale: 3 });
    this.addInteract([-0.6, 0.2, -0.9], [0.6, 1.6, 0.05], 'FUEL COUPLING', (game) => {
      game.notify('SUBLIGHT FUEL 87% - INTAKE SEALED');
    });
  }
}
