/**
 * SealedHatch — a doorway that has been welded shut and plated over.
 *
 * A hull class that carries fewer compartments than the survey cutter (see
 * `data/ShipClasses.js`) simply has no door where the cutter has one. Left
 * alone that reads as MISSING CONTENT — a junction with a blank wall where the
 * symmetry obviously wants a door — rather than as a smaller ship.
 *
 * So a cut compartment leaves a scar instead of a gap. The frame is still
 * there, because you cannot economically cut a pressure frame out of a
 * bulkhead; what is gone is the door, and in its place is a plate someone
 * welded on during a refit: weld beads down both seams, a grid of rivets, the
 * hazard chevrons that mark any sealed pressure boundary, and a stencilled
 * legend. That is a story — this ship used to be bigger — and it costs about
 * thirty boxes.
 *
 * Local space per PropBase: origin on the floor, front facing local -z. The
 * plate is placed AT the wall plane and faced into whichever compartment
 * survived, so it is only ever seen from the inhabited side.
 */
import { PropBase } from './PropBase.js';
import { DOOR } from '../../core/Constants.js';

export class SealedHatch extends PropBase {
  build(ctx) {
    const L = (n) => ctx.atlas.layer(n);
    const w = this.opts.w ?? DOOR.WIDTH ?? 1.6;
    const h = this.opts.h ?? DOOR.HEIGHT ?? 2.1;
    const hw = w / 2;
    const frame = L('door_frame');
    const wall = L('wall_military');
    // The surviving frame: jambs and a lintel, standing proud the way the live
    // door frames do, so a sealed hatch reads as the SAME opening treated
    // differently rather than as a different piece of architecture.
    this.addBox([-hw - 0.16, 0, -0.16], [-hw, h + 0.16, 0.02], { all: frame });
    this.addBox([hw, 0, -0.16], [hw + 0.16, h + 0.16, 0.02], { all: frame });
    this.addBox([-hw - 0.16, h, -0.16], [hw + 0.16, h + 0.16, 0.02], { all: frame });
    // The plate itself, set slightly into the frame — a patch sits BELOW the
    // surround it is patching, and that half-inch of recess is most of what
    // makes it read as added rather than as original structure.
    this.addBox([-hw + 0.02, 0.02, -0.10], [hw - 0.02, h - 0.02, -0.02],
      { all: wall }, { uvScale: 1 / Math.max(w, h) });
    // Weld beads down both vertical seams: a run of short overlapping blobs,
    // not a continuous strip. A weld is made one pass at a time and it shows.
    for (let i = 0; i < 9; i++) {
      const y = 0.12 + i * ((h - 0.3) / 8);
      this.addBox([-hw + 0.01, y, -0.13], [-hw + 0.10, y + 0.10, -0.09], { all: frame });
      this.addBox([hw - 0.10, y - 0.04, -0.13], [hw - 0.01, y + 0.06, -0.09], { all: frame });
    }
    // ...and across the head and sill, where the plate meets the lintel.
    for (let i = 0; i < 7; i++) {
      const x = -hw + 0.14 + i * ((w - 0.28) / 6);
      this.addBox([x, h - 0.11, -0.13], [x + 0.10, h - 0.02, -0.09], { all: frame });
      this.addBox([x, 0.03, -0.13], [x + 0.10, 0.12, -0.09], { all: frame });
    }
    // Rivet grid across the face. Three columns by five rows is enough to read
    // as "bolted down" without turning the plate into a texture of rivets.
    for (let c = 0; c < 3; c++) {
      for (let r = 0; r < 5; r++) {
        const x = -hw + 0.30 + c * ((w - 0.6) / 2);
        const y = 0.34 + r * ((h - 0.7) / 4);
        this.addBox([x - 0.035, y - 0.035, -0.125], [x + 0.035, y + 0.035, -0.10], { all: frame });
      }
    }
    // Hazard chevrons: the standing mark for a sealed pressure boundary. Two
    // short bands rather than a full border, so the plate does not compete with
    // the live doors, which wear the same stripe over their whole lower half.
    const haz = L('door_lamp');
    for (let i = 0; i < 4; i++) {
      const x = -hw + 0.22 + i * ((w - 0.44) / 3);
      this.addBox([x, h - 0.30, -0.135], [x + 0.16, h - 0.16, -0.12], { all: haz });
      this.addBox([x, 0.16, -0.135], [x + 0.16, 0.30, -0.12], { all: haz });
    }
    // The legend plate: a small blank sign at eye height. The text lives in the
    // interact prompt rather than in geometry — a 6px stencil modelled in boxes
    // would be unreadable at any distance you actually stand at.
    this.addBox([-0.34, 1.42, -0.14], [0.34, 1.66, -0.115], { all: L('screen_off') });
    const label = this.opts.label ?? 'COMPARTMENT';
    this.addInteract([-hw - 0.2, 0, -0.7], [hw + 0.2, h + 0.2, 0.05],
      'READ REFIT PLATE',
      (game) => game.notify(`${label} — REMOVED IN REFIT. BULKHEAD SEALED.`));
    // Solid: a plated doorway is a wall. Without this the player walks through
    // the scar into the void where the compartment used to be.
    this.addCollider([-hw - 0.16, 0, -0.16], [hw + 0.16, h + 0.16, 0.06]);
  }
}
