/**
 * Locker — tall crew locker, back against a wall. Front faces local -z.
 * opts: { w, h, tex (front texture), interact:{label,fn} | string }
 */
import { PropBase } from './PropBase.js';

export class Locker extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 0.7;
    const h = this.opts.h ?? 1.9;
    const front = ctx.atlas.layer(this.opts.tex ?? 'locker');
    const side = ctx.atlas.layer('wall_military');
    this.solidBox([-w / 2, 0, -0.45], [w / 2, h, 0], { all: side, nz: front }, {
      uvScale: 1 / Math.max(w, h * 0.55),
      ao: [0.85, 0.85, 1, 1],
    });
    if (this.opts.interact) {
      const it = typeof this.opts.interact === 'string'
        ? { label: 'OPEN LOCKER', fn: (game) => game.notify(this.opts.interact) }
        : this.opts.interact;
      this.addInteract([-w / 2 - 0.15, 0, -0.95], [w / 2 + 0.15, h, 0.05], it.label, it.fn);
    }
  }
}
