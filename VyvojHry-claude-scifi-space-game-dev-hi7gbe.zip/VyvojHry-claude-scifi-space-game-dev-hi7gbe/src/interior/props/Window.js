/**
 * Window — armored viewport. As of Phase 3 the glass is a genuine opening in
 * the hull wall (zone.windows) with live space rendered behind it: frame +
 * mullions + an invisible glass collider. This is a diegetic view OUT, per
 * the camera rule — never a camera position.
 *
 * opts: { w, h, y, text, interact:false to disable }
 */
import { PropBase } from './PropBase.js';

export class Window extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 2.4;
    const h = this.opts.h ?? 1.2;
    const y = this.opts.y ?? 1.0;
    const L = (n) => ctx.atlas.layer(n);
    const t = 0.08;
    // frame ring
    this.addBox([-w / 2 - t, y - t, -0.1], [w / 2 + t, y, 0], L('door_frame'), { uvScale: 1 });
    this.addBox([-w / 2 - t, y + h, -0.1], [w / 2 + t, y + h + t, 0], L('door_frame'), { uvScale: 1 });
    this.addBox([-w / 2 - t, y, -0.1], [-w / 2, y + h, 0], L('door_frame'), { uvScale: 1 });
    this.addBox([w / 2, y, -0.1], [w / 2 + t, y + h, 0], L('door_frame'), { uvScale: 1 });
    // mullions — split the pane in three, cockpit-style
    for (const mx of [-w / 6, w / 6]) {
      this.addBox([mx - 0.03, y, -0.07], [mx + 0.03, y + h, 0], L('door_frame'), { uvScale: 1.5 });
    }
    // the glass itself: invisible, but very much solid
    this.addCollider([-w / 2, y, -0.08], [w / 2, y + h, 0.02]);
    if (this.opts.interact !== false) {
      this.addInteract([-w / 2 - 0.2, y - 0.3, -0.8], [w / 2 + 0.2, y + h + 0.3, 0.05],
        'VIEWPORT', (game) => game.notify(this.opts.text ?? 'SOL PRIME. QUIET TONIGHT.'));
    }
  }
}
