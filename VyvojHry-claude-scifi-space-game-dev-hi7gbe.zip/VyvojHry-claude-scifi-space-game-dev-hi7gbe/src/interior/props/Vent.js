/**
 * Vent — wall vent grille, flush-mounted, front faces local -z.
 * opts: { w, h, y, interact }
 */
import { PropBase } from './PropBase.js';

export class Vent extends PropBase {
  build(ctx) {
    const w = this.opts.w ?? 0.8;
    const h = this.opts.h ?? 0.5;
    const y = this.opts.y ?? 0.15;
    const L = (n) => ctx.atlas.layer(n);
    this.addBox([-w / 2, y, -0.05], [w / 2, y + h, 0], {
      all: L('wall_military'), nz: L('vent'),
    }, { uvScale: 1 / w });
    if (this.opts.interact) {
      const it = typeof this.opts.interact === 'string'
        ? { label: 'VENT', fn: (game) => game.notify(this.opts.interact) }
        : this.opts.interact;
      this.addInteract([-w / 2 - 0.1, y - 0.2, -0.6], [w / 2 + 0.1, y + h + 0.2, 0.05], it.label, it.fn);
    }
  }
}
