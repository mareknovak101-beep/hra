/**
 * Med Bay (Room 04) — clean-ish, clinical, stocked for six.
 */
import { LIGHTING } from '../../core/Constants.js';
import { MedStation } from '../props/MedStation.js';
import { Locker } from '../props/Locker.js';
import { Console } from '../props/Console.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  new MedStation(ctx, -5.4, 17.5, 'N', {
    interact: {
      label: 'MED BED',
      // Reads you, then treats you out of the dispensary — see
      // gameplay/ShipStations.js for the store it draws down.
      fn: (g) => {
        if (g.stations) g.stations.treat();
        else g.notify('SCAN: MILD FATIGUE, ELEVATED CORTISOL. NO TREATMENT REQUIRED.');
      },
    },
  });
  new Locker(ctx, -3.4, 15.56, 'S', {
    tex: 'locker',
    interact: {
      label: 'SUPPLY CABINET',
      fn: (g) => g.notify('STIM ROW EMPTY. GAUZE AND SEALANT PLENTIFUL.'),
    },
  });
  new Console(ctx, -3.6, 19.05, 'N', {
    w: 1.1, screen: 'screen_amber',
    interact: {
      label: 'DIAGNOSTIC TERMINAL',
      fn: (g) => g.notify('LAST PATIENT ENTRY: 61 DAYS AGO. FILE LOCKED BY KESTREL MEDICAL.'),
    },
  });
  new LightFixture(ctx, -4.5, 17.5, 'N', { len: 1.4 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-4.5, 2.62, 17.5]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.SCREEN_GLOW, [-3.6, 1.4, 18.7]);
}
