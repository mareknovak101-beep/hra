/**
 * Cargo Bay (Room 10) — the big volume: green lattice walls, crane gantry,
 * crate variety, heavy rust. Concept ref: context/01 §6. Feel: claustrophobic
 * warehouse despite the size.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Crate } from '../props/Crate.js';
import { Panel } from '../props/Panel.js';
import { SuitRack } from '../props/SuitRack.js';
import { Vent } from '../props/Vent.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  const { builder, atlas, shipMap } = ctx;
  const L = (n) => atlas.layer(n);

  // -- crates (12) — clusters, some stacked --------------------------------
  new Crate(ctx, -5.2, 36.5, 'N', { size: [1.4, 1.1, 1.4], tex: 'crate_tech' });
  new Crate(ctx, -5.2, 36.5, 'N', {
    size: [1.1, 0.9, 1.1], tex: 'crate_tech', stackOn: 1.1,
    interact: 'MANIFEST TAG - CONTENTS: "AGRICULTURAL." THE SEAL IS KESTREL SECURITY-GRADE.',
  });
  new Crate(ctx, -4.9, 38.4, 'E', { size: [1.3, 1.0, 1.3], tex: 'crate_hazard' });
  new Crate(ctx, -5.4, 44.0, 'N', { size: [1.2, 1.2, 1.2], tex: 'crate_cryo' });
  new Crate(ctx, -5.4, 45.6, 'N', {
    size: [1.2, 1.2, 1.2], tex: 'crate_cryo',
    interact: 'CRYO CRATE - TEMP HOLDING. CONDENSATION HAS FROZEN THE LATCH.',
  });
  new Crate(ctx, -4.2, 50.5, 'S', { size: [1.4, 1.0, 1.2], tex: 'crate_tech' });
  new Crate(ctx, 4.8, 35.6, 'N', { size: [1.5, 1.1, 1.5], tex: 'crate_tech' });
  new Crate(ctx, 5.4, 37.6, 'W', { size: [1.2, 1.0, 1.2], tex: 'crate_hazard' });
  new Crate(ctx, 5.2, 48.4, 'N', { size: [1.4, 1.1, 1.4], tex: 'crate_hazard' });
  new Crate(ctx, 5.2, 48.4, 'N', { size: [1.0, 0.9, 1.0], tex: 'crate_tech', stackOn: 1.1 });
  new Crate(ctx, 1.8, 39.2, 'E', { size: [1.1, 0.9, 1.1], tex: 'crate_tech' });
  new Crate(ctx, -1.6, 49.6, 'W', { size: [1.2, 1.1, 1.2], tex: 'crate_cryo' });

  // -- overhead crane gantry -------------------------------------------------
  const rail = L('crane_metal');
  builder.box([-2.2, 6.8, 34], [-1.9, 7.1, 52], rail, { uvScale: 0.8 });
  builder.box([1.9, 6.8, 34], [2.2, 7.1, 52], rail, { uvScale: 0.8 });
  builder.box([-1.9, 6.6, 40.6], [1.9, 6.95, 41.4], rail, { uvScale: 0.8 }); // trolley
  builder.box([-0.06, 4.7, 40.95], [0.06, 6.6, 41.05], L('pipe'), { uvScale: 2 }); // cable
  builder.box([-0.28, 4.3, 40.8], [0.28, 4.7, 41.2], rail, { uvScale: 2 }); // hook block
  shipMap.collision.addBox([-0.3, 4.3, 40.8], [0.3, 4.7, 41.2], { crane: true });

  // -- wall panels ------------------------------------------------------------
  new Panel(ctx, -6.9, 38.5, 'E', {
    w: 1.1, h: 1.1, y: 0.9,
    interact: { label: 'CRANE CONTROL', fn: (g) => g.notify('GANTRY LOCKED FOR TRANSIT. HOOK LOAD: 0 KG.') },
  });
  new Panel(ctx, -6.9, 47.0, 'E', {
    w: 1.0, h: 1.0, y: 0.9,
    interact: 'BAY POWER BUS - BREAKERS 3 AND 9 HAND-LABELED "TEMPERAMENTAL."',
  });

  // -- EVA suit racks flanking the airlock door -------------------------------
  new SuitRack(ctx, 6.94, 40.2, 'W');
  new SuitRack(ctx, 6.94, 45.3, 'W', {
    text: 'THE SECOND SUIT\'S TAG READS "MERCER." DUST ON THE VISOR.',
  });

  new Vent(ctx, -3.5, 33.06, 'S', { w: 1.4, h: 0.9, y: 0.3, interact: 'DEEP DRAFT. THE DUCT RUNS THE LENGTH OF THE SHIP.' });

  // -- gantry lighting ----------------------------------------------------------
  //
  // The bay was effectively UNLIT: measured mean scene luminance 13-17 against
  // 50-59 for every normal compartment, with a 95th percentile of 24, meaning
  // even its brightest pixels were near-black. Four tubes of radius 8 cannot
  // light a 14x20x8m hold — attenuation is (1 - d/radius)², so from mid-bay the
  // nearest fixture sat 6.9m away and contributed (1 - 6.9/8)² ≈ 0.02. The room
  // ran on ambient alone. A 2.8m compartment gets ~0.59 from its tube at 1.5m.
  //
  // The fix is FEWER, LARGER lights, not more of them: LightSystem.gatherForZone
  // keeps only RENDER.MAX_LIGHTS_PER_DRAW (8) per zone and ranks them by
  // intensity × radius rather than by distance to the camera, so adding fixtures
  // past eight does nothing and can even crowd out a nearer one. Six tubes plus
  // the two floor seams is exactly the budget.
  //
  // Radius 17 puts mid-bay at (1 - 6.5/17)² ≈ 0.38 per tube; intensity drops
  // 0.85 → 0.6 because six overlapping lights of radius 17 otherwise sum past
  // the shader's 1.35 clamp and flatten the near-fixture highlights. Net result
  // is a fairly even 0.7-0.85 across the hold, in line with the rest of the ship.
  const BAY_Z = [36, 42.5, 49];
  for (const z of BAY_Z) {
    new LightFixture(ctx, -3, z, 'N', { len: 2.0, y: 6.4 });
    new LightFixture(ctx, 3, z, 'N', { len: 2.0, y: 6.4, off: false });
  }
  const bayTube = { ...LIGHTING.TYPES.CEILING_TUBE, radius: 17.0, intensity: 0.6 };
  for (const z of BAY_Z) {
    // the far starboard tube still stutters — this hold is meant to feel neglected
    ctx.lights.add(ctx.zone.id, bayTube, [-3, 6.3, z], z === 49 ? 'occasional_cut' : undefined);
    ctx.lights.add(ctx.zone.id, bayTube, [3, 6.3, z]);
  }
  // rust-orange floor seam glow (concept art)
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CARGO_SEAM, [-6.4, 0.25, 42]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CARGO_SEAM, [6.4, 0.25, 51]);
}
