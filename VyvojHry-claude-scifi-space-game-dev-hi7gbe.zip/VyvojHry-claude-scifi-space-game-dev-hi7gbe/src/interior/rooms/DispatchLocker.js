/**
 * DISPATCH LOCKER — the Petrel's refit of the general stores compartment.
 *
 * On a mail hull the hold is the job, so the stores compartment is not where
 * the ship keeps its own supplies; it is where the cargo lives, under seal,
 * with a franking terminal and a manifest board that is the only reason anyone
 * pays for this ship to exist.
 *
 * The read is BUREAUCRACY, not industry: numbered pigeonholes instead of racks,
 * sealed pouches instead of crates, and a stamp machine. It is the one
 * compartment in the game that is tidy, which on a courier is the point — a
 * loose parcel is a lost fee.
 *
 * Occupies the `storage` rect: x 2.5→6.5, z 19.5→23.5, h 2.8.
 */
import { LIGHTING } from '../../core/Constants.js';
import { StorageRack } from '../props/StorageRack.js';
import { Crate } from '../props/Crate.js';
import { Console } from '../props/Console.js';
import { Machinery } from '../props/Machinery.js';
import { Locker } from '../props/Locker.js';
import { Panel } from '../props/Panel.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  // Pigeonholes, both outboard bays, numbered by destination.
  new StorageRack(ctx, 6.44, 20.5, 'W', {
    interact: 'PIGEONHOLES 01-24 - VEGA REACH AND THE INNER ROUTE. NINE ARE SEALED AND NONE ARE YOURS TO OPEN.',
  });
  new StorageRack(ctx, 6.44, 22.5, 'W', {
    interact: 'PIGEONHOLES 25-48 - OUTBOUND SPURS. THE PALE COLUMN HAS NEVER BEEN USED.',
  });

  // Sealed pouches, small and light, because a courier carries value by weight.
  new Crate(ctx, 3.3, 20.4, 'N', {
    size: [0.85, 0.6, 0.7], tex: 'crate_tech',
    interact: 'BONDED POUCHES - WAX SEALS, COMPANY CREST. THE TOP ONE IS ADDRESSED TO A NAME YOU KNOW.',
  });
  new Crate(ctx, 3.3, 20.4, 'N', { size: [0.7, 0.45, 0.6], tex: 'crate_tech', stackOn: 0.6 });
  new Crate(ctx, 3.3, 22.9, 'N', {
    size: [0.8, 0.7, 0.75], tex: 'crate_cryo',
    interact: 'CHILLED CONSIGNMENT - MEDICAL, PRIORITY. THE TIMER ON THE LID IS COUNTING DOWN.',
  });

  // The franking machine and the manifest board: the actual work of the hull.
  new Machinery(ctx, 4.7, 19.56, 'S', {
    size: [1.3, 1.25, 0.5], tex: 'machinery',
    screens: { grid: [2, 2], tex: 'screen_amber' },
    interact: {
      label: 'FRANKING TERMINAL',
      fn: (g) => g.notify('STAMPS, LOGS AND BONDS A PARCEL IN ONE STROKE. THE INK RESERVOIR IS DRY AND IT STAMPS ANYWAY.'),
    },
  });
  new Console(ctx, 2.56, 21.4, 'E', {
    w: 0.95, screen: 'screen_amber',
    interact: {
      label: 'MANIFEST BOARD',
      fn: (g) => g.notify('48 CONSIGNMENTS BOOKED, 9 ABOARD. THE REST WERE NEVER COLLECTED FROM A STATION THAT IS GONE.'),
    },
  });
  new Locker(ctx, 5.9, 23.44, 'N', {
    tex: 'locker',
    interact: {
      label: 'BOND SAFE',
      fn: (g) => g.notify('COMBINATION LOCK, COMPANY ISSUE. THE COURIER BEFORE YOU LEFT THE DIAL ON THE LAST NUMBER.'),
    },
  });
  new Panel(ctx, 2.52, 22.6, 'E', { w: 0.85, h: 0.65, y: 1.45 });

  // Bright and even. Sorting is reading work.
  new LightFixture(ctx, 4.5, 20.6, 'N', { len: 1.0 });
  new LightFixture(ctx, 4.5, 22.6, 'N', { len: 1.0 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [4.5, 2.62, 20.6]);
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.55 }, [4.5, 2.62, 22.6]);
}
