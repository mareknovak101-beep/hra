/**
 * Computer Core (Room 09, NEW) — the mainframe room; the terminal-phosphor
 * palette's showcase (context/01 §2). Holds a save terminal and the ship
 * schematic poster (context/01 §7).
 */
import { LIGHTING } from '../../core/Constants.js';
import { Machinery } from '../props/Machinery.js';
import { HackingTerminal } from '../props/HackingTerminal.js';
import { SaveTerminal } from '../props/SaveTerminal.js';
import { StorageRack } from '../props/StorageRack.js';
import { Poster } from '../props/Poster.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  // mainframe cabinets along the east wall
  new Machinery(ctx, 6.44, 26.7, 'W', {
    size: [1.4, 2.3, 0.75], tex: 'machinery', screens: { grid: [2, 5] },
    interact: { label: 'MAINFRAME BANK A', fn: (g) => g.notify('COOLING FANS AT HALF SPEED. TAPE REELS TURNING.') },
  });
  new Machinery(ctx, 6.44, 28.5, 'W', {
    size: [1.4, 2.3, 0.75], tex: 'machinery',
  });

  new HackingTerminal(ctx, 4.4, 25.98, 'S');
  new SaveTerminal(ctx, 2.56, 29.2, 'E');
  new StorageRack(ctx, 5.4, 29.94, 'N', {
    w: 1.5,
    interact: 'DATA ARCHIVE - TAPE SPOOLS INDEXED BY HAND. NEAT UNTIL 47 DAYS AGO.',
  });
  new Poster(ctx, 2.54, 26.6, 'E');

  new LightFixture(ctx, 4.5, 27.7, 'N', { len: 1.2 });
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.4 }, [4.5, 2.62, 27.7]);
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.TERMINAL_PHOSPHOR, intensity: 0.2, radius: 2.0 }, [5.9, 1.6, 26.7]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.TERMINAL_PHOSPHOR, [4.4, 1.4, 26.4]);
}
