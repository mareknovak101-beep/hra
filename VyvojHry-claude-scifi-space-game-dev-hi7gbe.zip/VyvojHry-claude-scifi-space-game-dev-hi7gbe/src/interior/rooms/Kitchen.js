/**
 * Galley / Mess (Room 05) — where a crew of six used to eat.
 * (File named Kitchen.js per the architecture tree.)
 */
import { LIGHTING } from '../../core/Constants.js';
import { StorageRack } from '../props/StorageRack.js';
import { Machinery } from '../props/Machinery.js';
import { Table } from '../props/Table.js';
import { Seat } from '../props/Seat.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  new StorageRack(ctx, 3.6, 15.56, 'S', {
    w: 1.5,
    interact: {
      label: 'FOOD STORES',
      // Reads the rack; the DISPENSER below is what hands anything out.
      fn: (g) => g.notify(g.stations?.storesLine()
        ?? '212 RATION UNITS. THE GOOD FLAVORS ARE LONG GONE.'),
    },
  });
  new Machinery(ctx, 6.0, 15.56, 'S', {
    size: [1.7, 0.95, 0.7], tex: 'workbench',
    interact: {
      label: 'GALLEY DISPENSER',
      fn: (g) => {
        if (g.stations) g.stations.dispenseMeal();
        else g.notify('PREP SURFACE WIPED DOWN. TOO CLEAN.');
      },
    },
  });
  new Machinery(ctx, 7.44, 17.4, 'W', {
    size: [1.0, 1.5, 0.6], topPipe: true,
    interact: {
      label: 'WATER RECLAIMER',
      fn: (g) => {
        if (g.stations) g.stations.drawWater();
        else g.notify('CYCLING. EFFICIENCY 96%. THE HUM IS ALMOST COMPANY.');
      },
    },
  });
  new Table(ctx, 5.0, 18.0, 'N', {
    size: [1.6, 0.9],
    interact: { label: 'MESS TABLE', fn: (g) => g.notify('SIX CHAIRS ONCE. YOU EAT STANDING UP THESE DAYS.') },
  });
  new Seat(ctx, 4.1, 18.0, 'E');
  new Seat(ctx, 5.9, 18.0, 'W');
  new LightFixture(ctx, 5, 17.5, 'N', { len: 1.4 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [5, 2.62, 17.5]);
}
