/**
 * Bathroom (Room 06) — tiled, rust in the grout, one light that won't settle.
 */
import { LIGHTING } from '../../core/Constants.js';
import { WallScreen } from '../props/Console.js';
import { GenericBlock } from '../props/PropBase.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  const L = (n) => ctx.atlas.layer(n);
  // sink counter on the south wall
  new GenericBlock(ctx, -4.5, 23.0, 'N', {
    min: [-0.8, 0, -0.5], max: [0.8, 0.85, 0],
    layers: { all: L('fixture_white') },
    interact: { label: 'SINK', fn: (g) => g.notify('THE TAP KNOCKS TWICE BEFORE IT RUNS. IT ALWAYS HAS.') },
  });
  // mirror above it — a dead screen makes a decent mirror at this resolution
  new WallScreen(ctx, -4.5, 23.44, 'N', {
    w: 0.9, h: 0.6, y: 1.2, screen: 'screen_off', emissive: 0,
    interact: { label: 'MIRROR', fn: (g) => g.notify('YOU LOOK TIRED.') },
  });
  // shower stall partitions, NW corner
  new GenericBlock(ctx, -5.9, 20.6, 'N', {
    min: [-0.05, 0, -1.05], max: [0.05, 2.0, 1.05],
    layers: L('fixture_white'),
  });
  new GenericBlock(ctx, -5.9, 21.68, 'N', {
    min: [-0.62, 0, -0.05], max: [0.55, 2.0, 0.05],
    layers: L('fixture_white'),
    interact: { label: 'SHOWER', fn: (g) => g.notify('WATER RATION AVAILABLE: 4 MINUTES. IT NEVER FEELS LIKE FOUR.') },
  });
  new LightFixture(ctx, -4.5, 21.5, 'N', { len: 1.0 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-4.5, 2.62, 21.5], 'rapid');
}
