/**
 * DERELICT COMPARTMENTS — the dressing for data/WreckPlan.js.
 *
 * The rule for every room here is that NOTHING WORKS. No lit fixture, no live
 * screen, no powered door. Whatever is in a compartment is either bolted down,
 * burst open, or floating where the last of the air left it. The helmet lamp is
 * the only working light on the deck, which is the first time in the project it
 * has been load-bearing rather than a convenience.
 *
 * THE SALVAGE POINT is the one interactable that matters. It calls back into
 * `Boarding` through a hook — the same `advance()` the panel used to call — so
 * the oxygen model, the hazard rolls and the loot table are untouched. What
 * changed is that reaching it costs you the walk, and the walk back out is the
 * thing you are spending air on the whole time.
 *
 * Each is registered with its own generous interact volume rather than relying
 * on a prop's derived box: a salvage point you cannot find in the dark because
 * the crosshair passes over it is a compartment you cannot loot.
 */
import { Machinery } from '../props/Machinery.js';
import { Crate } from '../props/Crate.js';
import { StorageRack } from '../props/StorageRack.js';
import { Locker } from '../props/Locker.js';
import { Bunk } from '../props/Bunk.js';
import { MedStation } from '../props/MedStation.js';
import { Console } from '../props/Console.js';
import { Seat } from '../props/Seat.js';
import { Table } from '../props/Table.js';
import { Pipe } from '../props/Pipe.js';
import { Panel } from '../props/Panel.js';

/**
 * Register a salvage point: a volume you can hit from anywhere near the fitting
 * it belongs to, wired to the boarding run.
 */
function salvage(ctx, x, z, label) {
  // TIGHT, and beside a fitting rather than in the middle of the floor.
  //
  // The first version was a 3.8 m cube on the compartment's centre, which the
  // player ends up STANDING IN — and `raycastInteract` deliberately rejects a
  // volume you are inside unless you are looking at its centre, so a salvage
  // point you were standing on top of reported nothing. A salvage point is a
  // thing you walk up to and look at, so it is sized like one.
  ctx.shipMap.addInteractable({
    min: [x - 1.1, 0.2, z - 1.1],
    max: [x + 1.1, 2.2, z + 1.1],
    label,
    onInteract: (game) => {
      const fn = ctx.shipMap?.wreckHooks?.salvage;
      if (fn) fn(ctx.zone.id);
      else game.notify('NOTHING HERE ANSWERS.');
    },
  });
}

// -- BREACH: the way in, and the way out ------------------------------------
export const breach = {
  dress(ctx) {
    // The cut edge of the hull, and the line you came across on. This is the
    // only interactable that leaves, and it is deliberately unmissable.
    ctx.shipMap.addInteractable({
      min: [-2.2, 0, -0.4], max: [2.2, 2.6, 1.8],
      label: 'BACK THROUGH THE BREACH',
      onInteract: (game) => {
        const fn = ctx.shipMap?.wreckHooks?.leave;
        if (fn) fn();
        else game.notify('THE LINE IS GONE.');
      },
    });
    for (const s of [-1, 1]) {
      new Pipe(ctx, s * 3.2, 2.0, s > 0 ? 'W' : 'E', { len: 3.4, y: 2.5 });
      new Panel(ctx, s * 3.44, 4.4, s > 0 ? 'W' : 'E', { w: 0.9, h: 0.8, y: 1.2, tex: 'machinery' });
    }
    new Crate(ctx, -2.4, 5.0, 'N', { size: [1.0, 0.8, 0.9], tex: 'crate_hazard', interact: 'SPLIT OPEN. WHATEVER WAS IN IT LEFT WITH THE AIR.' });
    new Crate(ctx, 2.4, 5.2, 'N', { size: [0.9, 0.9, 0.9], tex: 'crate_tech' });
  },
};

// -- CARGO HOLD -------------------------------------------------------------
export const w_hold = {
  dress(ctx) {
    salvage(ctx, -4.6, 15.0, 'STRIP THE HOLD');
    for (const [x, z] of [[-4.2, 12.5], [-4.2, 18.6], [4.2, 13.4], [4.2, 19.8], [0, 20.4]]) {
      new Crate(ctx, x, z, 'N', { size: [1.4, 1.2, 1.4], tex: 'crate_tech' });
      new Crate(ctx, x, z, 'N', { size: [1.1, 0.9, 1.1], tex: 'crate_hazard', stackOn: 1.2 });
    }
    new StorageRack(ctx, -5.44, 15.0, 'E', { interact: 'LASHING POINTS, CUT. THE LOAD WENT SOMEWHERE.' });
    new StorageRack(ctx, 5.44, 17.2, 'W');
    new Pipe(ctx, -5.2, 11, 'E', { len: 10, y: 4.1 });
    new Pipe(ctx, 5.2, 11, 'W', { len: 10, y: 4.1 });
  },
};

// -- CREW SPACES ------------------------------------------------------------
export const w_quarters = {
  dress(ctx) {
    salvage(ctx, 0, 27.4, 'SEARCH THE CREW SPACES');
    for (const [x, z, f] of [[-4.4, 28, 'E'], [-4.4, 32, 'E'], [4.4, 28, 'W'], [4.4, 32, 'W']]) {
      new Bunk(ctx, x, z, f);
    }
    new Locker(ctx, -2.0, 26.56, 'S', { tex: 'locker', interact: 'PERSONAL EFFECTS. SOMEBODY ELSE HAS ALREADY BEEN THROUGH THEM.' });
    new Locker(ctx, 2.0, 26.56, 'S', { tex: 'locker' });
    new Table(ctx, 0, 31.4, 'N', { size: [1.8, 0.9] });
    new Seat(ctx, 0, 32.4, 'N');
  },
};

// -- SICK BAY ---------------------------------------------------------------
export const w_medical = {
  dress(ctx) {
    salvage(ctx, -3.7, 43.2, 'CLEAR THE SICK BAY');
    new MedStation(ctx, -3.4, 41.0, 'E', { interact: { label: 'MED BED', fn: (g) => g.notify('THE STRAPS ARE FASTENED AND THERE IS NOBODY IN THEM.') } });
    new MedStation(ctx, 3.4, 41.0, 'W');
    new Locker(ctx, -4.44, 43.4, 'E', { tex: 'locker', interact: 'DRUG CABINET, FORCED. THE FORCING WAS DONE FROM THIS SIDE.' });
    new Console(ctx, 0, 44.56, 'S', { w: 1.1, screen: 'screen_amber', screenEmissive: 0,
      interact: { label: 'PATIENT BOARD', fn: (g) => g.notify('DEAD SCREEN. THE LAST THING ON IT IS SCRATCHED INTO THE BEZEL.') } });
  },
};

// -- BRIDGE -----------------------------------------------------------------
export const w_bridge = {
  dress(ctx) {
    salvage(ctx, -4.2, 54.0, 'PULL THE BRIDGE CORES');
    for (const [x, z] of [[-2.6, 50.2], [2.6, 50.2]]) {
      new Console(ctx, x, z, 'S', { w: 1.3, screen: 'screen_amber', screenEmissive: 0 });
      new Seat(ctx, x, z + 1.6, 'S', { pilot: true });
    }
    new Machinery(ctx, -4.6, 54.0, 'E', { size: [1.4, 1.8, 0.6], tex: 'machinery',
      interact: 'NAVIGATION RACK. THE CORES ARE STILL SEATED, WHICH IS UNUSUAL.' });
    new Machinery(ctx, 4.6, 54.0, 'W', { size: [1.4, 1.8, 0.6], tex: 'machinery' });
    new Panel(ctx, 0, 55.44, 'N', { w: 2.2, h: 1.0, y: 1.3, tex: 'machinery' });
  },
};

// -- DRIVE SECTION ----------------------------------------------------------
export const w_engine = {
  dress(ctx) {
    salvage(ctx, 0, 66.0, 'CUT THE DRIVE SECTION');
    new Machinery(ctx, 0, 66.4, 'N', { size: [3.0, 2.6, 1.2], tex: 'machinery', topPipe: true,
      interact: 'THE DRIVE. COLD LONG ENOUGH THAT THE COOLANT HAS FROZEN IN THE LINES.' });
    for (const s of [-1, 1]) {
      new Pipe(ctx, s * 4.2, 60.5, s > 0 ? 'W' : 'E', { len: 6.4, y: 3.6 });
      new Machinery(ctx, s * 3.6, 62.0, s > 0 ? 'W' : 'E', { size: [1.2, 1.6, 0.6], tex: 'machinery' });
    }
    new Crate(ctx, -3.0, 65.0, 'N', { size: [1.0, 0.9, 1.0], tex: 'crate_hazard' });
  },
};

// -- GALLEY: off the crew spaces, to port -----------------------------------
//
// The one compartment on a dead ship that is still doing its job. Everything in
// here froze solid the day the heat went and is perfectly edible, which is a
// far bleaker fact than an empty room would have been.
export const w_galley = {
  dress(ctx) {
    salvage(ctx, -9.4, 30.0, 'CLEAR THE GALLEY STORES');
    new Machinery(ctx, -10.9, 28.4, 'E', { size: [1.0, 1.6, 0.7], tex: 'machinery',
      interact: 'COLD STORE. STILL COLD, FOR THE OPPOSITE REASON TO THE ONE INTENDED.' });
    new Machinery(ctx, -10.9, 31.6, 'E', { size: [1.0, 1.2, 0.7], tex: 'machinery' });
    new Table(ctx, -8.0, 30.0, 'N', { size: [2.0, 1.0] });
    new Seat(ctx, -8.0, 31.2, 'N');
    new Seat(ctx, -8.0, 28.8, 'S');
    new StorageRack(ctx, -5.44, 29.0, 'E', { interact: 'DRY STORES, IN ORDER, LABELLED. NOBODY PANICKED IN HERE.' });
    new Locker(ctx, -6.6, 32.44, 'S', { tex: 'locker' });
    new Pipe(ctx, -11.0, 27.4, 'E', { len: 5.2, y: 2.3 });
  },
};

// -- WORKSHOP: off the bridge, to starboard ---------------------------------
export const w_shop = {
  dress(ctx) {
    salvage(ctx, 9.6, 52.6, 'WORK THE BENCH');
    new Machinery(ctx, 11.4, 51.0, 'W', { size: [1.6, 1.0, 0.8], tex: 'workbench',
      interact: 'A JOB HALF DONE, AND THE TOOLS FOR IT LAID OUT IN ORDER BESIDE IT.' });
    new StorageRack(ctx, 11.44, 54.4, 'W');
    new Machinery(ctx, 7.0, 55.4, 'N', { size: [1.0, 1.8, 0.6], tex: 'machinery' });
    new Crate(ctx, 6.6, 50.6, 'N', { size: [1.0, 0.9, 1.0], tex: 'crate_tech' });
    new Panel(ctx, 9.0, 49.94, 'S', { w: 1.4, h: 0.9, y: 1.4, tex: 'machinery' });
    new Pipe(ctx, 6.2, 50.0, 'W', { len: 5.4, y: 2.7 });
  },
};

// -- REACTOR SPACE: aft of the drive, and reading hot ------------------------
export const w_reactor = {
  dress(ctx) {
    salvage(ctx, 0, 76.5, 'PULL THE REACTOR RODS');
    new Machinery(ctx, 0, 78.6, 'N', { size: [3.4, 3.0, 1.4], tex: 'reactor_core', topPipe: true,
      interact: 'THE PILE. COLD, AND THE DOSIMETER DISAGREES ABOUT WHAT THAT MEANS.' });
    for (const s of [-1, 1]) {
      new Machinery(ctx, s * 4.4, 74.0, s > 0 ? 'W' : 'E', { size: [1.4, 2.0, 0.7], tex: 'machinery' });
      new Pipe(ctx, s * 5.4, 72.6, s > 0 ? 'W' : 'E', { len: 7.4, y: 3.8 });
      new Panel(ctx, s * 5.94, 79.0, s > 0 ? 'W' : 'E', { w: 1.2, h: 1.0, y: 1.5, tex: 'machinery' });
    }
    new Crate(ctx, -3.4, 73.4, 'N', { size: [0.9, 0.9, 0.9], tex: 'crate_hazard',
      interact: 'SHIELDING OFFCUTS. SOMEBODY WAS PATCHING THE CRACK BY HAND.' });
  },
};

// -- SEALED COMPARTMENT: dogged from the inside ------------------------------
//
// The deepest thing on the deck, reached on your hands and knees through the
// access crawl, and the only compartment whose door was shut deliberately.
export const w_core = {
  dress(ctx) {
    salvage(ctx, 0, 88.4, 'OPEN WHAT THEY SEALED');
    new Locker(ctx, -3.9, 87.0, 'E', { tex: 'locker',
      interact: 'DOGGED FROM THIS SIDE. WHATEVER THEY WERE KEEPING OUT, IT WAS OUT THERE.' });
    new Locker(ctx, 3.9, 87.0, 'W', { tex: 'locker' });
    new Console(ctx, 0, 91.44, 'N', { w: 1.4, screen: 'screen_phosphor', screenEmissive: 0,
      interact: { label: 'SEALED ARCHIVE', fn: (g) => g.notify('DEAD, AND THE CASING IS WARM. IT SHOULD NOT BE WARM.') } });
    new Bunk(ctx, -3.4, 90.0, 'E');
    new Table(ctx, 1.6, 89.6, 'N', { size: [1.4, 0.8] });
    new Crate(ctx, 2.8, 86.6, 'N', { size: [0.9, 0.8, 0.9], tex: 'crate_cryo' });
  },
};

/** The dresser table `WreckPlan` is built with. */
export const WRECK_DRESSERS = {
  breach, w_hold, w_quarters, w_galley, w_medical, w_bridge, w_shop,
  w_engine, w_reactor, w_core,
};
