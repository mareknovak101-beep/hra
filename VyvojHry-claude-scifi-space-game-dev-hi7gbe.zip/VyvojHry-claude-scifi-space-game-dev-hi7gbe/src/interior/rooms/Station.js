/**
 * STATION COMPARTMENTS — the dressing for every zone in data/StationPlan.js.
 *
 * One module rather than seven files: these rooms are small, they share one
 * vocabulary (a counter, a rack behind it, a board on the wall) and splitting
 * them would mean seven near-identical import blocks.
 *
 * WHAT MAKES A SHOP A SHOP. It is the COUNTER, and specifically the fact that
 * the counter is the interactable rather than a menu key. You walk up to a
 * length of scratched steel with a till on it, press E, and the trade window
 * opens — which is the same window it always was, now with somewhere to be.
 * Every one of these compartments is therefore built around a physical barrier
 * between you and the stock: you can see the racks, you cannot reach them.
 *
 * The counters call out through `ctx.shipMap.stationHooks`, set by main when it
 * builds the deck. Going through a hook rather than importing the UIs keeps the
 * interior layer ignorant of the DOM, which is the one boundary in this project
 * that has never been crossed.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Machinery } from '../props/Machinery.js';
import { Console } from '../props/Console.js';
import { StorageRack } from '../props/StorageRack.js';
import { Crate } from '../props/Crate.js';
import { Table } from '../props/Table.js';
import { Seat } from '../props/Seat.js';
import { Locker } from '../props/Locker.js';
import { Panel } from '../props/Panel.js';
import { Pipe } from '../props/Pipe.js';
import { Poster } from '../props/Poster.js';
import { SaveTerminal } from '../props/SaveTerminal.js';
import { LightFixture } from '../props/Light.js';
import { MedStation } from '../props/MedStation.js';
import { Bunk } from '../props/Bunk.js';

/** Fire a named station hook, or say nothing is answering. */
function hook(ctx, name, fallback) {
  return (game) => {
    const fn = ctx.shipMap?.stationHooks?.[name];
    if (fn) fn();
    else game.notify(fallback);
  };
}

/**
 * A serving counter with a till, a kick rail, and — the part that matters — an
 * interact volume you can actually hit.
 *
 * A counter is 1.12 m of waist-high furniture. `Machinery` derives its interact
 * box from the prop's own height, so the box topped out at 1.32 m while the
 * player's eye sits at 1.6 and the crosshair looks STRAIGHT OVER IT. Every
 * shop on the deck was unreachable and the raycast reported "nothing" from two
 * metres away, facing the till.
 *
 * So the counter registers its own volume: the full footprint, floor to well
 * above head height, standing a metre and a half proud into the room. You walk
 * up to a counter and look at it — you do not aim at its lip.
 */
function counter(ctx, x, z, facing, opts) {
  const w = opts.size?.[0] ?? 3.4;
  new Machinery(ctx, x, z, facing, {
    size: opts.size ?? [3.4, 1.12, 0.8], tex: 'workbench',
    screens: { grid: [3, 1], tex: 'screen_amber' },
  });
  new Panel(ctx, x, z, facing, { w: w - 0.5, h: 0.22, y: 0.16, tex: 'machinery' });
  // Which way the shopkeeper's side is, so the volume reaches into the room
  // rather than into the bulkhead behind them.
  const d = facing === 'S' ? 1 : facing === 'N' ? -1 : 0;
  const e = facing === 'W' ? -1 : facing === 'E' ? 1 : 0;
  const zLo = d >= 0 ? z - 0.9 : z - 1.7, zHi = d >= 0 ? z + 1.7 : z + 0.9;
  const xLo = e >= 0 ? x - w / 2 - 0.3 : x - w / 2 - 1.5;
  const xHi = e >= 0 ? x + w / 2 + 1.5 : x + w / 2 + 0.3;
  ctx.shipMap.addInteractable({
    min: [e ? xLo : x - w / 2 - 0.3, 0, e ? z - w / 2 - 0.3 : zLo],
    max: [e ? xHi : x + w / 2 + 0.3, 2.3, e ? z + w / 2 + 0.3 : zHi],
    label: opts.label,
    onInteract: opts.fn,
  });
}

/**
 * A PERSON AT A POST.
 *
 * Pushes a roster entry the `Crew` entity turns into a body (see
 * entities/Crew.js), plants a collider so you cannot walk through them, and
 * registers the interact volume that opens the conversation. Placement lives
 * here, with every other placement on this deck, rather than in a table in the
 * entity that nobody would keep in sync with the furniture.
 *
 * The prompt names the POST, not the person — you find out who they are by
 * talking to them, which is how it works.
 *
 * @param {string} kind  archetype id in CREW_KINDS (mesh + topic list)
 * @param {string} id    unique post id; the person's name is seeded off it, so
 *                       two officers on one station are two different people
 */
function crew(ctx, kind, id, role, x, z, yaw) {
  const map = ctx.shipMap;
  (map.npcs ??= []).push({ kind, id, role, x, z, yaw, zone: ctx.zone.id });
  // A body is about 0.6 m across the shoulders; the collider is a little
  // tighter so you can squeeze past one in a doorway rather than being wedged.
  map.collision?.addBox([x - 0.26, 0, z - 0.22], [x + 0.26, 1.85, z + 0.22]);
  map.addInteractable({
    min: [x - 1.0, 0, z - 1.0], max: [x + 1.0, 2.1, z + 1.0],
    label: `TALK TO ${role}`,
    onInteract: (game) => {
      if (game.talkTo) game.talkTo(kind, id, role);
      else game.notify(`${role} LOOKS AT YOU AND SAYS NOTHING.`);
    },
  });
}

// -- DOCKING ARM -------------------------------------------------------------
// Where your hull is clamped. The way home is a lit sign and an interactable,
// so leaving is never a menu you have to remember.
export const dock_arm = {
  dress(ctx) {
    new Console(ctx, -3.44, 3.4, 'E', {
      w: 1.2, screen: 'screen_amber',
      interact: { label: 'BERTH CONTROL', fn: hook(ctx, 'undock', 'CLAMPS HOLD. THE BOARD SAYS NOTHING.') },
    });
    new Machinery(ctx, 3.44, 3.4, 'W', {
      size: [1.4, 1.7, 0.6], tex: 'machinery', topPipe: true,
      interact: 'UMBILICAL GANTRY — FUEL, AIR AND POWER, ALL READING NOMINAL.',
    });
    new Crate(ctx, -2.2, 6.4, 'N', { size: [1.1, 0.9, 1.0], tex: 'crate_tech', interact: 'INBOUND FREIGHT, NOT YOURS.' });
    new Crate(ctx, -2.2, 6.4, 'N', { size: [0.9, 0.7, 0.8], tex: 'crate_hazard', stackOn: 0.9 });
    new Crate(ctx, 2.4, 6.4, 'N', { size: [1.2, 1.0, 1.0], tex: 'crate_cryo', interact: 'CHILLED CONSIGNMENT. THE TIMER IS RUNNING.' });
    crew(ctx, 'dockhand', 'dock', 'DOCK CREW', 2.5, 4.5, Math.PI * 0.75);
    new Pipe(ctx, -3.6, 4.5, 'E', { len: 5.0, y: 2.9 });
    new Pipe(ctx, 3.6, 4.5, 'W', { len: 5.0, y: 2.9 });
    new LightFixture(ctx, 0, 2.0, 'N', { len: 1.4 });
    new LightFixture(ctx, 0, 5.4, 'N', { len: 1.4 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [0, 3.2, 2.0]);
    ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.6 }, [0, 3.2, 5.4]);
  },
};

// -- CONCOURSE ---------------------------------------------------------------
// The street. Deliberately the only tall space on the deck: coming out of a
// 2.6-metre access lock into five metres of ceiling is the whole arrival.
export const concourse = {
  dress(ctx) {
    // Planters, benches and a departures board — the furniture of a public
    // space, which is what separates a concourse from a wide corridor.
    for (const z of [15, 22, 29, 34]) {
      new Crate(ctx, -4.6, z, 'E', { size: [1.3, 0.7, 1.3], tex: 'crate_tech' });
      new Crate(ctx, 4.6, z + 3, 'W', { size: [1.3, 0.7, 1.3], tex: 'crate_tech' });
    }
    for (const [x, z, f] of [[-3.2, 19, 'E'], [3.2, 25, 'W'], [-3.2, 32, 'E']]) {
      new Table(ctx, x, z, f, { size: [1.6, 0.7] });
      new Seat(ctx, x, z + 1.1, f);
    }
    new Console(ctx, 0, 12.2, 'N', {
      w: 1.6, screen: 'screen_amber',
      interact: {
        label: 'ARRIVALS BOARD',
        fn: (g) => g.notify('SIX BERTHS, TWO OCCUPIED. THE REST OF THE LIST IS SHIPS THAT STOPPED FILING.'),
      },
    });
    crew(ctx, 'dockhand', 'street', 'IDLE HAND', -2.2, 23.5, Math.PI * 0.5);
    new Poster(ctx, -5.9, 22.5, 'E', { w: 1.4, h: 1.8, y: 1.1 });
    new Poster(ctx, 5.9, 33.0, 'W', { w: 1.4, h: 1.8, y: 1.1 });
    // Overhead service run and a row of lamps down the hall.
    new Pipe(ctx, -5.2, 13, 'E', { len: 22, y: 4.7 });
    new Pipe(ctx, 5.2, 13, 'W', { len: 22, y: 4.7 });
    for (const z of [14, 20, 26, 32, 36]) {
      new LightFixture(ctx, 0, z, 'N', { len: 1.8 });
      ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: z === 26 ? 0.8 : 0.62 }, [0, 5.0, z]);
    }
  },
};

// -- CHANDLER: general goods, the trade counter ------------------------------
export const chandler = {
  dress(ctx) {
    counter(ctx, -9, 15.6, 'S', {
      label: 'CHANDLER — TRADE',
      fn: hook(ctx, 'trade', 'THE COUNTER IS SHUT. NOBODY SAYS WHEN.'),
    });
    crew(ctx, 'chandler', 'chandler', 'THE CHANDLER', -9, 14.4, Math.PI);
    new StorageRack(ctx, -11.44, 17.4, 'E', { interact: 'DRY STORES, FLOOR TO DECKHEAD. PRICED IN GREASE PENCIL.' });
    new StorageRack(ctx, -11.44, 19.2, 'E', { interact: 'WATER, FILTERS, SCRUBBER CARTRIDGES. THE STAPLES.' });
    new Crate(ctx, -7.2, 18.6, 'N', { size: [1.0, 0.9, 1.0], tex: 'crate_tech' });
    new Crate(ctx, -7.2, 18.6, 'N', { size: [0.8, 0.7, 0.8], tex: 'crate_cryo', stackOn: 0.9 });
    new LightFixture(ctx, -9, 17.5, 'N', { len: 1.4 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-9, 2.8, 17.5]);
  },
};

// -- OUTFITTER: parts, ordnance, repairs -------------------------------------
export const outfitter = {
  dress(ctx) {
    counter(ctx, 9, 15.6, 'S', {
      label: 'OUTFITTER — PARTS & ORDNANCE',
      fn: hook(ctx, 'outfit', 'THE SHUTTER IS DOWN OVER THE PARTS WINDOW.'),
    });
    new Machinery(ctx, 11.4, 18.4, 'W', {
      size: [1.6, 1.9, 0.7], tex: 'machinery',
      screens: { grid: [2, 3], tex: 'screen_amber' },
      // The yard lets you use its bench. Same jobs, somebody else's power.
      interact: {
        label: 'BENCH TEST RIG',
        fn: (g) => {
          if (g.openFabricator) g.openFabricator();
          else g.notify('BENCH TEST RIG. SOMEBODY LEFT A COIL ON IT, HALF STRIPPED.');
        },
      },
    });
    crew(ctx, 'armourer', 'armourer', 'THE ARMOURER', 9, 14.4, Math.PI);
    new StorageRack(ctx, 7.2, 19.2, 'W', { interact: 'HARDPOINT SPARES. THE SLUG BINS ARE THE ONLY FULL ONES.' });
    new Locker(ctx, 10.6, 13.56, 'S', { tex: 'locker', interact: 'BONDED ORDNANCE. TWO SIGNATURES TO OPEN AND YOU ARE NEITHER.' });
    new Pipe(ctx, 8.0, 14.2, 'W', { len: 4.6, y: 2.7 });
    new LightFixture(ctx, 9, 17.5, 'N', { len: 1.4 });
    ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.75 }, [9, 2.8, 17.5]);
  },
};

// -- HULL BROKER: the yard's sales office ------------------------------------
export const broker = {
  dress(ctx) {
    counter(ctx, -9, 26.6, 'S', {
      size: [3.0, 1.12, 0.8],
      label: 'HULL BROKER — VIEW REGISTER',
      fn: hook(ctx, 'broker', 'NO BROKER SITS AT THIS SLIP. TRY A YARD.'),
    });
    crew(ctx, 'broker', 'broker', 'THE BROKER', -9, 25.4, Math.PI);
    new Console(ctx, -11.44, 28.6, 'E', {
      w: 1.2, screen: 'screen_amber',
      interact: { label: 'REGISTER TERMINAL', fn: (g) => g.notify('FOUR HULLS ON THE BOOKS. THREE OF THEM HAVE BEEN ON THE BOOKS A WHILE.') },
    });
    new Poster(ctx, -7.06, 25.4, 'W', { w: 1.1, h: 1.4, y: 1.15 });
    new Poster(ctx, -7.06, 29.6, 'W', { w: 1.1, h: 1.4, y: 1.15 });
    new Table(ctx, -9.4, 29.8, 'N', { size: [1.8, 0.9] });
    new Seat(ctx, -9.4, 30.7, 'N');
    new LightFixture(ctx, -9, 27.8, 'N', { len: 1.4 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-9, 2.8, 27.8]);
  },
};

// -- TAPROOM: the one room aboard that is not selling you anything -----------
export const taproom = {
  dress(ctx) {
    counter(ctx, 9, 25.6, 'S', {
      size: [3.6, 1.12, 0.75],
      label: 'BAR',
      fn: hook(ctx, 'bar', 'THE TAP RUNS. NOBODY TAKES YOUR MONEY.'),
    });
    for (const [x, z] of [[7.6, 28.4], [9.4, 29.6], [11.0, 27.9]]) {
      new Table(ctx, x, z, 'N', { size: [1.2, 1.2] });
      new Seat(ctx, x, z + 0.95, 'N');
    }
    crew(ctx, 'dockhand', 'drinker', 'THE DRINKER', 9.4, 30.8, 0);
    new StorageRack(ctx, 11.44, 24.9, 'W', { interact: 'BOTTLES, MOSTLY EMPTY, ARRANGED AS IF THEY ARE NOT.' });
    new Poster(ctx, 6.06, 27.0, 'E', { w: 1.2, h: 1.5, y: 1.2 });
    new LightFixture(ctx, 9, 27.8, 'N', { len: 1.0, lens: 'light_tube_red' });
    ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.34 }, [9, 2.8, 27.8]);
    ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.SCREEN_GLOW, intensity: 0.5 }, [9, 1.5, 25.9]);
  },
};

// -- HARBOUR OFFICE ----------------------------------------------------------
export const harbour_office = {
  dress(ctx) {
    new SaveTerminal(ctx, 0, 47.4, 'N');
    new Console(ctx, -3.2, 42.0, 'S', {
      w: 1.3, screen: 'screen_amber',
      interact: { label: 'HARBOUR LOG', fn: hook(ctx, 'log', 'THE LOG IS SEALED TO THE HARBOURMASTER.') },
    });
    new Machinery(ctx, 3.2, 42.0, 'S', {
      size: [1.5, 1.6, 0.6], tex: 'machinery',
      screens: { grid: [2, 2], tex: 'screen_amber' },
      interact: 'MANIFEST FILER. IT WANTS A SHIP NUMBER AND WILL NOT TAKE YOURS.',
    });
    new Table(ctx, 0, 44.6, 'N', { size: [2.0, 1.0] });
    new Seat(ctx, 0, 45.6, 'N');
    crew(ctx, 'officer', 'harbour', 'THE HARBOURMASTER', -1.8, 43.4, Math.PI * 0.4);
    new Locker(ctx, -4.44, 45.5, 'E', { tex: 'locker', interact: 'HARBOURMASTER\'S COAT. STILL ON THE HOOK.' });
    new LightFixture(ctx, 0, 44.0, 'N', { len: 1.6 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [0, 2.8, 44.0]);
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.SCREEN_GLOW, [-3.2, 1.4, 42.6]);
  },
};

// -- STATION CLINIC ----------------------------------------------------------
//
// The one lit white room on the deck. A station with a bar and no clinic is a
// set; a station with both is a place where people get hurt and come back.
export const clinic = {
  dress(ctx) {
    counter(ctx, -9, 33.2, 'S', {
      label: 'MEDICAL COUNTER',
      fn: hook(ctx, 'medical', 'THE DUTY MEDIC IS ASLEEP BEHIND THE GLASS AND HAS EARNED IT.'),
    });
    crew(ctx, 'medic', 'medic', 'THE DUTY MEDIC', -9, 32.5, Math.PI);
    new MedStation(ctx, -11.0, 35.4, 'W', {
      interact: { label: 'TREATMENT BAY', fn: (g) => g.notify('CLEAN SHEETS, WARM LAMP, AND A BILL AT THE END OF IT.') },
    });
    new MedStation(ctx, -7.4, 35.4, 'W');
    new StorageRack(ctx, -11.44, 33.0, 'W', { interact: 'DRUG STORE, LOCKED, INVENTORIED TWICE A SHIFT.' });
    new Poster(ctx, -6.06, 34.6, 'E', { w: 1.1, h: 1.4, y: 1.3 });
    new LightFixture(ctx, -9, 34.4, 'N', { len: 1.4 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-9, 2.8, 34.4]);
  },
};

// -- TRANSIT BUNKS -----------------------------------------------------------
//
// Where a crew sleeps between hulls. Six racks, no windows, and the only place
// aboard a station where the lights are turned down on purpose.
export const bunkhouse = {
  dress(ctx) {
    for (const [x, z, f] of [[7.0, 33.2, 'W'], [7.0, 35.8, 'W'], [11.0, 33.2, 'E'], [11.0, 35.8, 'E']]) {
      new Bunk(ctx, x, z, f);
    }
    new Locker(ctx, 8.6, 32.06, 'N', { tex: 'locker', interact: 'SOMEBODY ELSE\'S KIT, PADLOCKED, LABELLED WITH A HULL NUMBER.' });
    new Locker(ctx, 9.8, 32.06, 'N', { tex: 'locker' });
    new Table(ctx, 9.0, 34.6, 'N', { size: [1.2, 0.9] });
    new LightFixture(ctx, 9, 34.0, 'N', { len: 0.9, lens: 'light_tube_red' });
    ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.28 }, [9, 2.6, 34.0]);
  },
};

// -- BONDED TRANSFER ---------------------------------------------------------
//
// The cargo actually has to go somewhere, and until now it went nowhere: you
// traded at a counter and the hold changed by magic. This is the floor the
// containers cross, tall enough for a stack and loud enough to feel worked.
export const transfer = {
  dress(ctx) {
    counter(ctx, -9, 42.4, 'S', {
      label: 'TRANSFER DESK',
      fn: hook(ctx, 'trade', 'THE DESK IS SHUT. BONDED GOODS MOVE ON THE DAY SHIFT.'),
    });
    for (const [x, z] of [[-11.2, 45.4], [-7.0, 45.4], [-11.2, 48.4], [-7.0, 48.4]]) {
      new Crate(ctx, x, z, 'N', { size: [1.5, 1.3, 1.5], tex: 'crate_tech' });
      new Crate(ctx, x, z, 'N', { size: [1.2, 1.0, 1.2], tex: 'crate_hazard', stackOn: 1.3 });
    }
    crew(ctx, 'chandler', 'bonded', 'THE BONDED CLERK', -9, 41.4, Math.PI);
    new StorageRack(ctx, -12.44, 44.0, 'W');
    new Machinery(ctx, -5.6, 47.6, 'E', { size: [1.0, 2.0, 0.8], tex: 'machinery',
      screens: { grid: [1, 2], tex: 'screen_nav' },
      interact: 'WEIGHBRIDGE. IT REMEMBERS EVERY CONTAINER THAT HAS CROSSED THIS FLOOR.' });
    new Pipe(ctx, -12.6, 42.0, 'W', { len: 7.4, y: 4.0 });
    new LightFixture(ctx, -9, 46.0, 'N', { len: 1.6 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-9, 4.2, 46.0]);
  },
};

// -- CUSTOMS POST ------------------------------------------------------------
//
// Who is allowed in, and what they are allowed to be carrying. It answers the
// same hook the harbour log does — the point of the room is that the station
// has an opinion about you, which the faction system already tracks.
export const custom = {
  dress(ctx) {
    new Console(ctx, 8.4, 42.0, 'S', {
      w: 1.4, screen: 'screen_nav',
      interact: { label: 'DECLARATION BOARD', fn: hook(ctx, 'log', 'NOTHING TO DECLARE, AND NOBODY TO DECLARE IT TO.') },
    });
    new Machinery(ctx, 11.4, 44.4, 'W', { size: [1.2, 1.8, 0.7], tex: 'machinery',
      screens: { grid: [2, 2], tex: 'screen_amber' },
      interact: 'CARGO SCANNER. IT HAS BEEN LOOKING THROUGH YOUR HOLD SINCE THE CLAMPS TOOK.' });
    new Table(ctx, 8.6, 45.0, 'N', { size: [2.2, 0.9] });
    new Seat(ctx, 8.6, 46.0, 'N');
    crew(ctx, 'officer', 'customs', 'THE INSPECTOR', 10.2, 45.6, Math.PI * 1.35);
    new Locker(ctx, 6.06, 43.4, 'E', { tex: 'locker', interact: 'CONFISCATIONS. THE LABELS ARE MORE INTERESTING THAN THE CONTENTS.' });
    new Poster(ctx, 9.6, 46.94, 'N', { w: 1.3, h: 1.0, y: 1.6 });
    new LightFixture(ctx, 9, 44.0, 'N', { len: 1.2 });
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [9, 2.8, 44.0]);
    ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.SCREEN_GLOW, [8.4, 1.4, 42.6]);
  },
};

/** The dresser table `StationPlan` is built with. */
export const STATION_DRESSERS = {
  dock_arm, concourse, chandler, outfitter, broker, taproom, harbour_office,
  clinic, bunkhouse, transfer, custom,
};
