/**
 * Workshop (Room 11) — fabrication bench, tool storage, and one of the two
 * save terminals (context/03 §2: Workshop + Computer Core, never adjacent).
 */
import { LIGHTING } from '../../core/Constants.js';
import { Machinery } from '../props/Machinery.js';
import { Panel } from '../props/Panel.js';
import { StorageRack } from '../props/StorageRack.js';
import { SaveTerminal } from '../props/SaveTerminal.js';
import { Pipe } from '../props/Pipe.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  new Machinery(ctx, -5.0, 56.56, 'S', {
    size: [2.0, 0.95, 0.75], tex: 'workbench',
    interact: {
      label: 'FABRICATION BENCH',
      fn: (g) => {
        if (g.openFabricator) g.openFabricator();
        else g.notify('CRAFTING SUITE OFFLINE. VICE STILL HOLDS A BRACKET.');
      },
    },
  });
  new Panel(ctx, -5.0, 56.58, 'S', { w: 1.6, h: 0.7, y: 1.35, tex: 'machinery' });
  new StorageRack(ctx, -7.44, 59.5, 'E', {
    interact: 'PARTS STORAGE - LABELED BINS. THE WELD ROD BIN IS NEARLY EMPTY.',
  });
  new SaveTerminal(ctx, -5.0, 62.42, 'N');
  new Pipe(ctx, -3.0, 62.4, 'N', { len: 4.0, y: 2.3 });
  new LightFixture(ctx, -5.0, 59.5, 'N', { len: 1.4 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-5, 2.62, 59.5]);
}
