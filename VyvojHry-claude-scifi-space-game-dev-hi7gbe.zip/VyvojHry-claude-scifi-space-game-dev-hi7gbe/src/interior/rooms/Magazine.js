/**
 * MAGAZINE — the Harrier's refit of the general stores compartment.
 *
 * The class blurb has said "a magazine where the laboratory used to be" since
 * 0.25.0, and behind that door was a shelf of ration cartons. This is the room
 * standing behind the sentence.
 *
 * It reads as ordnance, not as storage, through three things and not through
 * new geometry: everything is CLAMPED rather than stacked (a loose crate in a
 * magazine is a court martial), the lighting is the low red of a space you are
 * not supposed to linger in, and the only console tells you the ship's guns are
 * gone and the racks are not.
 *
 * Occupies the `storage` rect: x 2.5→6.5, z 19.5→23.5, h 2.8.
 */
import { LIGHTING } from '../../core/Constants.js';
import { StorageRack } from '../props/StorageRack.js';
import { Crate } from '../props/Crate.js';
import { Machinery } from '../props/Machinery.js';
import { Console } from '../props/Console.js';
import { Locker } from '../props/Locker.js';
import { Panel } from '../props/Panel.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  // Ready racks down the outboard wall: canisters stood on end in clamps.
  new StorageRack(ctx, 6.44, 20.6, 'W', {
    interact: 'READY RACK A - SIX CANISTER SLOTS, TWO FILLED. THE CLAMPS ARE NUMBERED IN WHITE PAINT.',
  });
  new StorageRack(ctx, 6.44, 22.4, 'W', {
    interact: 'READY RACK B - EMPTY. THE FOAM CRADLES STILL HOLD THE SHAPE OF WHAT SAT IN THEM.',
  });

  // Ordnance itself, strapped low and marked. Hazard crates rather than the
  // general-stores tech crates the compartment used to carry.
  new Crate(ctx, 3.35, 20.2, 'N', {
    size: [1.5, 0.55, 0.85], tex: 'crate_hazard',
    interact: 'SLUG STOCK - ARMOUR-PIERCING, KESTREL LOT 44. SEAL INTACT, DATE EXPIRED.',
  });
  new Crate(ctx, 3.35, 20.2, 'N', { size: [1.2, 0.42, 0.7], tex: 'crate_hazard', stackOn: 0.55 });
  new Crate(ctx, 3.35, 22.6, 'N', {
    size: [1.1, 0.9, 0.9], tex: 'crate_cryo',
    interact: 'COOLANT FOR THE CANISTER CRADLES. THE GAUGE READS LOW AND HAS FOR SOME TIME.',
  });

  // The arming panel. On a hull whose guns were stripped at auction, a live
  // arming board with nothing to arm is the whole story of the class.
  new Machinery(ctx, 4.6, 19.56, 'S', {
    size: [1.6, 1.45, 0.55], tex: 'machinery',
    screens: { grid: [3, 2], tex: 'screen_amber' },
    interact: {
      label: 'ARMING BOARD',
      fn: (g) => g.notify('MAGAZINE INTERLOCK: SAFE. NO TURRET RESPONDS. THE BOARD DOES NOT KNOW THAT.'),
    },
  });
  new Console(ctx, 2.56, 21.6, 'E', {
    w: 0.95, screen: 'screen_amber',
    interact: {
      label: 'ORDNANCE LEDGER',
      fn: (g) => g.notify('LAST DRAW: 14 ROUNDS, SIGNED BY AN OFFICER OF A NAVY THAT NO LONGER OWNS THIS HULL.'),
    },
  });
  new Locker(ctx, 5.9, 23.44, 'N', {
    tex: 'locker',
    interact: {
      label: 'SMALL ARMS LOCKER',
      fn: (g) => g.notify('THREE BRACKETS, ONE WEAPON. THE OTHER TWO WERE SOLD WITH THE SHIP.'),
    },
  });
  new Panel(ctx, 2.52, 22.8, 'E', { w: 0.8, h: 0.6, y: 1.5, tex: 'machinery' });

  // Low red: a magazine is lit to be worked in briefly and left.
  new LightFixture(ctx, 4.5, 21.5, 'N', { len: 1.0, lens: 'light_tube_red' });
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.EMERGENCY, intensity: 0.5 }, [4.5, 2.62, 21.5]);
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.22 }, [4.5, 2.62, 20.0]);
}
