/**
 * Crew Bunks (Room 03) — four bunks, one occupant. Concept ref: green-CRT
 * terminal, tiled rust walls, lockers. This is the player's spawn room; the
 * emptiness should be the first thing that reads.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Bunk } from '../props/Bunk.js';
import { Locker } from '../props/Locker.js';
import { Table } from '../props/Table.js';
import { Seat } from '../props/Seat.js';
import { WallScreen } from '../props/Console.js';
import { Panel } from '../props/Panel.js';
import { Vent } from '../props/Vent.js';
import { GenericBlock } from '../props/PropBase.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  // two double stacks = four bunks (context/03: rated crew six, two in cockpit shifts)
  new Bunk(ctx, 3.6, 9.05, 'N', {
    double: true,
    interact: { label: 'YOUR BUNK', fn: (g) => g.notify('YOUR BUNK. THE OTHER THREE ARE MADE AND COLD.') },
  });
  new Bunk(ctx, 6.3, 9.05, 'N', {
    double: true,
    interact: { label: 'EMPTY BUNKS', fn: (g) => g.notify('SOMEONE LEFT A PAPERBACK UNDER THE PILLOW. PAGE 112, FOLDED.') },
  });

  // lockers along the east wall
  new Locker(ctx, 7.46, 10.8, 'W', { interact: 'EMPTY. A SINGLE GLOVE ON THE SHELF.' });
  new Locker(ctx, 7.46, 11.55, 'W', {
    tex: 'locker',
    interact: {
      label: 'MERCER\'S LOCKER',
      fn: (g) => g.notify('"M. MERCER" TAPED OVER THE STENCIL. IT IS STILL FULL.'),
    },
  });
  new Locker(ctx, 7.46, 12.3, 'W', { interact: 'YOURS. SUIT LINER, SPARE BOOTS, RATION BARS.' });

  // desk with the green CRT terminal (diegetic phosphor — allowed off-HUD)
  new Table(ctx, 4.2, 12.35, 'N', { size: [1.5, 0.75] });
  new Seat(ctx, 4.2, 11.5, 'S');
  new WallScreen(ctx, 4.2, 12.94, 'N', {
    w: 1.0, h: 0.7, y: 1.1, screen: 'screen_phosphor',
    interact: {
      label: 'CREW TERMINAL',
      fn: (g) => g.notify('LOG 44: "...THREE SHIFTS SINCE ANYONE USED THE GYM. QUIET ISN\'T THE WORD."'),
    },
  });
  // knife/tool rack above the desk (concept art detail)
  new Panel(ctx, 5.8, 12.94, 'N', { w: 0.9, h: 0.5, y: 1.25, tex: 'machinery' });

  // sink recessed into the west wall, clear of the south bulkhead
  new GenericBlock(ctx, 2.55, 12.5, 'E', {
    min: [-0.35, 0, -0.45], max: [0.35, 0.85, 0],
    layers: { all: ctx.atlas.layer('fixture_white') },
    interact: { label: 'SINK', fn: (g) => g.notify('WATER RECYCLER FEED - POTABLE. TASTES LIKE THE FILTER.') },
  });

  new Vent(ctx, 5.2, 8.06, 'S', {
    w: 0.9, h: 0.5, y: 0.2,
    interact: 'THE GRILLE RATTLES FAINTLY. AIRFLOW NOMINAL.',
  });

  new LightFixture(ctx, 5, 10.5, 'N', { len: 1.6 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [5, 2.62, 10.5]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.TERMINAL_PHOSPHOR, [4.2, 1.5, 12.3]);
}
