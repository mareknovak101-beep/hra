/**
 * Captain's Quarters (Room 02) — small, private, orderly in a way the rest of
 * the ship isn't. The absent-crew details start here.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Bunk } from '../props/Bunk.js';
import { Locker } from '../props/Locker.js';
import { Table } from '../props/Table.js';
import { Seat } from '../props/Seat.js';
import { WallScreen } from '../props/Console.js';
import { GenericBlock } from '../props/PropBase.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  new Bunk(ctx, -5.03, 9.35, 'N', {
    interact: { label: 'CAPTAIN\'S BUNK', fn: (g) => g.notify('MADE TO REGULATION. NOBODY HAS SLEPT HERE IN A WHILE.') },
  });
  new Locker(ctx, -3.4, 8.04, 'S', {
    interact: 'SEALED. COMMAND CIPHER REQUIRED.',
  });
  new Table(ctx, -4.3, 12.35, 'N', { size: [1.5, 0.75] });
  new Seat(ctx, -4.3, 11.5, 'S');
  new WallScreen(ctx, -4.3, 12.94, 'N', {
    w: 1.0, h: 0.65, y: 1.15, screen: 'screen_amber',
    interact: {
      label: 'PERSONAL TERMINAL',
      fn: (g) => g.notify('14 UNREAD FROM KESTREL OPS. ALL FLAGGED CONTRACT-CRITICAL.'),
    },
  });
  // framed photo on the desk — the crew that isn't aboard
  new GenericBlock(ctx, -4.7, 12.5, 'N', {
    min: [-0.12, 0.75, -0.02], max: [0.12, 0.95, 0.03],
    layers: ctx.atlas.layer('screen_off'),
    interact: {
      label: 'FRAMED PHOTO',
      fn: (g) => g.notify('SIX CREW IN FRONT OF THE AETHON. FOUR OF THE FACES ARE CIRCLED IN PEN.'),
    },
  });
  new LightFixture(ctx, -4, 10.5, 'N', { len: 1.2 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-4, 2.62, 10.5], 'slow_pulse');
}
