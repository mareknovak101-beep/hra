/**
 * Reactor Room (Room 12) — the core column glows through its vent slits;
 * everything else stays in shadow.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Console } from '../props/Console.js';
import { Panel } from '../props/Panel.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  const L = (n) => ctx.atlas.layer(n);

  // the core column — an octagonal shaft (rounded, not a blunt box)
  ctx.builder.prism(6.0, 59.5, 0.92, 0, 3.2, 8, L('reactor_core'), { uvScale: 0.7, emissive: 1 });
  ctx.shipMap.collision.addBox([5.1, 0, 58.6], [6.9, 3.2, 60.4], { core: true });
  ctx.shipMap.addInteractable({
    min: [5.0, 0, 58.5], max: [7.0, 2.0, 60.5],
    label: 'REACTOR CORE',
    onInteract: (g) => g.notify('OUTPUT 71%. COIL TEMP STEADY. THE HUM GETS INTO YOUR TEETH.'),
  });
  // four conduit panels
  new Panel(ctx, 4.2, 56.58, 'S', { w: 1.0, h: 1.1, y: 0.8 });
  new Panel(ctx, 7.8, 56.58, 'S', {
    w: 1.0, h: 1.1, y: 0.8,
    interact: 'POWER CONDUIT 2 - LOAD BALANCED. SCORCH MARK AROUND BREAKER 5.',
  });
  new Panel(ctx, 4.2, 62.42, 'N', { w: 1.0, h: 1.1, y: 0.8 });
  new Panel(ctx, 7.8, 62.42, 'N', { w: 1.0, h: 1.1, y: 0.8 });
  // emergency shutdown
  new Console(ctx, 9.42, 59.5, 'W', {
    w: 0.9, screen: 'screen_amber',
    interact: {
      label: 'EMERGENCY SCRAM',
      fn: (g) => {
        g.audio?.playDenyBuzz();
        g.notify('HANDLE SEALED UNDER GLASS. AUTHORIZATION: CHIEF ENGINEER.');
      },
    },
  });

  new LightFixture(ctx, 4.0, 61.5, 'N', { len: 1.0, lens: 'light_tube_red' });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.REACTOR_GLOW, [6.0, 1.8, 59.5], 'slow_pulse');
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.EMERGENCY, [4.0, 2.9, 61.5], 'slow_pulse');
}
