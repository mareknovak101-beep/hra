/**
 * Airlock (Room 10a) — the ship's most exposed point: the one door that leads
 * to nothing breathable. Concept ref: context/01 §6.
 */
import { LIGHTING } from '../../core/Constants.js';
import { WallScreen } from '../props/Console.js';
import { GenericBlock } from '../props/PropBase.js';
import { LightFixture } from '../props/Light.js';
import { SuitRack } from '../props/SuitRack.js';
import { StorageRack } from '../props/StorageRack.js';

export function dress(ctx) {
  const L = (n) => ctx.atlas.layer(n);

  // outer vault door, set into the east (hull) wall
  new GenericBlock(ctx, 9.93, 42.75, 'W', {
    min: [-1.0, 0.05, -0.16], max: [1.0, 2.25, 0],
    layers: { all: L('door_frame'), nz: L('door_panel') },
    interact: {
      label: 'OUTER DOOR',
      // THE DOOR NOW OPENS. It refused for four sessions on the grounds of
      // "EVA protocol requires certification", which was a placeholder standing
      // in for a mechanic that did not exist; the mechanic exists now. It still
      // refuses while the ship is under way and while it is parked on a deck,
      // because both of those are the door killing you rather than a feature.
      fn: (g) => {
        if (!g.startEva) {
          g.audio?.playDenyBuzz();
          g.notify('OUTER DOOR: CYCLE INTERLOCK ENGAGED.');
          return;
        }
        g.startEva();
      },
    },
  });
  // status console beside the door (teal-lit in concept — phosphor family here)
  new WallScreen(ctx, 9.94, 41.3, 'W', {
    w: 0.7, h: 0.55, y: 1.15, screen: 'screen_phosphor',
    interact: {
      label: 'AIRLOCK STATUS',
      fn: (g) => g.notify('PRESSURE EQUALIZED. CYCLE LOCKED. LAST CYCLE: 213 DAYS AGO.'),
    },
  });
  // first-aid kit on the floor, slightly out of place
  new GenericBlock(ctx, 7.6, 43.9, 'N', {
    min: [-0.25, 0, -0.18], max: [0.25, 0.18, 0.18],
    layers: L('med_panel'),
    interact: {
      label: 'FIELD MEDKIT',
      fn: (g) => g.notify('SEALS INTACT. SOMEONE LEFT IT BY THE DOOR AND NEVER CAME BACK FOR IT.'),
    },
  });

  // Suit stores, against the forward wall. The airlock had nothing searchable in
  // it, which meant the one compartment on the ship whose entire purpose is
  // going outside held none of the gear for going outside.
  //
  // An open rack and a hung hardsuit, NOT two lockers. Two `Locker` props side
  // by side print the same baked MERCER name tape twice, thirty centimetres
  // apart, which reads as a texture repeat rather than as two cabinets — and
  // these are the right props anyway: an airlock stows its suits where they can
  // be reached in a hurry, not behind doors.
  //
  // Facing 'S' puts the fronts on the +z side, so the backs sit flush against
  // the wall at z = 41 and they open into the chamber. The outer door is on the
  // x = 10 wall and the inner door on x = 7 at z = 42.75; both racks clear each.
  new SuitRack(ctx, 7.72, 41.02, 'S', {
    text: 'FOUR HARDSUITS ON THE RAIL. THREE HAVE NAMES ON THEM.',
  });
  // "EVA SUIT STORAGE", and every word of that is load-bearing. main.js decides
  // what is searchable by matching the interactable's LABEL against
  // CONTAINER_RE, which knows STORAGE but not STORES — the first draft of this
  // rack was called EVA STORES and quietly yielded nothing at all. The SUIT/EVA
  // prefix is what steers the roll onto the airlock loot table rather than the
  // generic locker one.
  new StorageRack(ctx, 8.85, 41.02, 'S', {
    w: 1.1, h: 1.9,
    interact: {
      label: 'EVA SUIT STORAGE',
      fn: (g) => g.notify('TETHERS, CARTRIDGES, SPARE VISOR FILM. THE INVENTORY SHEET IS SIX YEARS OLD.'),
    },
  });

  new LightFixture(ctx, 8.5, 42.75, 'N', { len: 0.9, lens: 'light_tube_red' });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.EMERGENCY, [8.5, 2.5, 42.75], 'slow_pulse');
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.TERMINAL_PHOSPHOR, [9.6, 1.4, 41.3]);
}
