/**
 * Cockpit / Bridge (Room 01) — concept ref: context/01 §6. Cracked leather
 * pilot chair as the anchor, amber console banks, forward viewport with
 * starfield. Flight itself is Phase 3; the seat already speaks.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Console, WallScreen } from '../props/Console.js';
import { Seat } from '../props/Seat.js';
import { Window } from '../props/Window.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  // forward viewport — matches the hull opening declared in ShipMap zone.windows
  new Window(ctx, 0, 0.06, 'S', {
    w: 3.2, h: 1.3, y: 1.0,
    text: 'SOL PRIME THROUGH FOUR CENTIMETERS OF GLASS. STILL QUIET OUT THERE.',
  });

  // console bank under the viewport — nav map center (kept low so the seated
  // sightline clears it), systems either side
  new Console(ctx, 0, 1.0, 'S', {
    w: 1.4, screen: 'screen_nav', screenH: 0.3,
    interact: { label: 'NAV CONSOLE', fn: (g) => g.notify('NAV - IN SYSTEM: SOL PRIME. NO PLOTTED ROUTE.') },
  });
  new Console(ctx, -1.6, 1.0, 'S', {
    w: 1.2, screen: 'screen_amber',
    interact: { label: 'SYSTEMS CONSOLE', fn: (g) => g.notify('SYSTEMS - ALL BOARDS GREEN. FOUR CONSOLES DARK BY CONFIG.') },
  });
  new Console(ctx, 1.6, 1.0, 'S', {
    w: 1.2, screen: 'screen_amber',
    interact: { label: 'COMMS STATION', fn: (g) => g.notify('COMMS - CARRIER LOCK: MERIDIAN STATION. NO TRAFFIC ON WATCH.') },
  });

  // the chair — sitting down IS the flight mode (first person throughout,
  // no camera pull-back: context/02 §3)
  new Seat(ctx, 0, 2.7, 'N', {
    pilot: true,
    interact: {
      label: 'PILOT SEAT',
      fn: (g) => g.enterFlight(),
    },
  });

  // side status screens
  new WallScreen(ctx, -2.4, 3.2, 'E', {
    w: 0.9, h: 0.6, y: 1.2, screen: 'screen_amber',
    interact: { label: 'STATUS SCREEN', fn: (g) => g.notify('HULL 91% / FUEL 87% / O2 RESERVE 94%') },
  });
  new WallScreen(ctx, 2.4, 3.2, 'W', {
    w: 0.9, h: 0.6, y: 1.2, screen: 'screen_off',
    interact: { label: 'DEAD SCREEN', fn: (g) => g.notify('THE SCREEN IS DARK. A STICKY NOTE: "PARTS ON ORDER - R."') },
  });

  new LightFixture(ctx, 0, 2.6, 'N', { len: 1.6 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [0, 2.62, 2.6]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.SCREEN_GLOW, [0, 1.5, 1.4]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.SCREEN_GLOW, [-1.6, 1.4, 1.5]);
}
