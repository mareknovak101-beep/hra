/**
 * ASSAY BAY — the Drayman's refit of the med bay compartment.
 *
 * A bulk hauler rated for eight never carried a doctor; it carried an assayer,
 * because the entire economics of the hull turn on knowing what is in the ore
 * before you agree a price for it. The paperwork calls the compartment a med
 * bay because the survey office's form has a box for one. The bench, the
 * sample trays and the dust on everything call it what it is.
 *
 * The one medical fitting left is a wall cabinet, and it is a first-aid box —
 * which is exactly what a working hull has instead of a hospital.
 *
 * Occupies the `med_bay` rect: x -6.5→-2.5, z 15.5→19.5, h 2.8.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Machinery } from '../props/Machinery.js';
import { Table } from '../props/Table.js';
import { StorageRack } from '../props/StorageRack.js';
import { Crate } from '../props/Crate.js';
import { Console } from '../props/Console.js';
import { Locker } from '../props/Locker.js';
import { Pipe } from '../props/Pipe.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  // The assay bench: a crusher, a furnace and a scale, in that order, which is
  // the order the work goes in.
  new Machinery(ctx, -5.2, 15.56, 'S', {
    size: [1.9, 1.15, 0.7], tex: 'workbench', topPipe: true,
    interact: {
      label: 'ASSAY BENCH',
      fn: (g) => {
        if (g.stations) g.stations.assay();
        else g.notify('JAW CRUSHER, CUPEL FURNACE, BALANCE. THE PAN HAS NOT BEEN CLEANED SINCE THE PALE.');
      },
    },
  });
  new Machinery(ctx, -3.3, 15.56, 'S', {
    size: [1.0, 1.55, 0.6], tex: 'machinery',
    screens: { grid: [2, 3], tex: 'screen_amber' },
    interact: {
      label: 'SPECTROGRAPH',
      fn: (g) => g.notify('LAST BURN: NICKEL-IRON WITH A PLATINUM TRACE. SOMEONE UNDERLINED THE TRACE TWICE.'),
    },
  });

  // Sample trays, labelled by hand, on a table in the middle of the floor.
  new Table(ctx, -4.6, 17.8, 'N', {
    size: [1.7, 0.9],
    interact: {
      label: 'SAMPLE TRAYS',
      fn: (g) => g.notify('FORTY NUMBERED CELLS. THE GREASE-PENCIL LABELS RUN OUT AT TWENTY-THREE.'),
    },
  });
  new StorageRack(ctx, -6.44, 18.6, 'E', {
    interact: 'CORE STORAGE - DRILL CORES IN SLEEVES, OLDEST AT THE BOTTOM AND FUSED THERE BY DAMP.',
  });
  new Crate(ctx, -3.3, 18.9, 'N', {
    size: [0.95, 0.85, 0.95], tex: 'crate_tech',
    interact: 'REJECT ORE - TAGGED FOR DUMPING AND STILL ABOARD, WHICH IS THE USUAL OUTCOME.',
  });

  // The last medical fitting on the ship, and the ledger that replaced the rest.
  new Locker(ctx, -6.44, 16.4, 'E', {
    tex: 'locker',
    interact: {
      label: 'FIRST AID CABINET',
      fn: (g) => g.notify('BURN DRESSINGS, EYE WASH, A SPLINT. EVERYTHING A CRUSHER TAKES OFF YOU, NOTHING IT TAKES OUT.'),
    },
  });
  new Console(ctx, -4.0, 19.05, 'N', {
    w: 1.1, screen: 'screen_amber',
    interact: {
      label: 'ASSAY LEDGER',
      fn: (g) => g.notify('GRADE LOG, 900 ENTRIES. THE LAST FOUR ARE BLANK AND THE CURSOR IS STILL ON THE FIRST.'),
    },
  });
  new Pipe(ctx, -2.9, 17.4, 'E', { len: 3.4, y: 2.35 });

  // Worklight over the bench, and nothing over the rest: the room is lit where
  // the work is and dark where it is not.
  new LightFixture(ctx, -4.4, 16.4, 'N', { len: 1.4 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-4.4, 2.62, 16.4]);
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.28 }, [-4.4, 2.62, 18.9]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.SCREEN_GLOW, [-4.0, 1.4, 18.7]);
}
