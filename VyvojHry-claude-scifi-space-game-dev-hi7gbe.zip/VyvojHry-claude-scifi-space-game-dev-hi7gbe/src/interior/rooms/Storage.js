/**
 * Storage (Room 07) — shelved general stores; dim by design.
 */
import { LIGHTING } from '../../core/Constants.js';
import { StorageRack } from '../props/StorageRack.js';
import { Crate } from '../props/Crate.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  new StorageRack(ctx, 6.44, 20.9, 'W', {
    interact: 'GENERAL STORES - RATION CARTONS, FILTER STOCK, SPARE FUSES.',
  });
  new StorageRack(ctx, 6.44, 22.6, 'W', {
    interact: 'AIR FILTERS, BOXED. SOMEONE COUNTED THEM IN GREASE PENCIL: 41.',
  });
  new StorageRack(ctx, 4.0, 19.56, 'S', { w: 1.5 });
  new Crate(ctx, 3.3, 22.6, 'N', {
    size: [1.0, 0.9, 1.0], tex: 'crate_tech',
    interact: 'SHIP STORES OVERFLOW - STRAPPED AND SEALED.',
  });
  new Crate(ctx, 3.3, 22.6, 'N', { size: [0.8, 0.7, 0.8], tex: 'crate_hazard', stackOn: 0.9 });
  new LightFixture(ctx, 4.5, 21.5, 'N', { len: 1.0 });
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.CEILING_TUBE, intensity: 0.45 }, [4.5, 2.62, 21.5]);
}
