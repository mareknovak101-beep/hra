/**
 * Research Lab (Room 08, NEW) — the room that should feel most like *before*:
 * ordinary, unfinished survey work. Concept ref: context/01 §6.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Console } from '../props/Console.js';
import { Locker } from '../props/Locker.js';
import { Machinery } from '../props/Machinery.js';
import { GenericBlock } from '../props/PropBase.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  const L = (n) => ctx.atlas.layer(n);

  new Console(ctx, -5.4, 25.95, 'S', {
    w: 1.3, screen: 'screen_phosphor',
    interact: {
      label: 'SPECIMEN ANALYZER',
      fn: (g) => g.notify('TRAY EMPTY. LAST RUN: 47 DAYS AGO. RESULT FILE 0 BYTES.'),
    },
  });
  new Locker(ctx, -3.4, 25.56, 'S', {
    tex: 'crate_cryo',
    interact: {
      label: 'COLD STORAGE',
      fn: (g) => g.notify('-41 C. THREE SEALED TRAYS, LABELS HANDWRITTEN, NOT LOGGED.'),
    },
  });
  // containment cabinet with the phosphor glow inside
  new GenericBlock(ctx, -6.35, 27.6, 'E', {
    min: [-0.55, 0, -0.65], max: [0.55, 2.0, 0],
    layers: { all: L('machinery'), nz: L('screen_phosphor') },
    emissive: { nz: 1 },
    interact: {
      label: 'CONTAINMENT CABINET',
      fn: (g) => g.notify('EMPTY. SEAL LOG SHOWS ONE ENTRY. THE ENTRY IS REDACTED.'),
    },
  });
  // bookshelf — worn hardbound survey volumes
  new GenericBlock(ctx, -5.4, 29.9, 'N', {
    min: [-0.9, 0, -0.35], max: [0.9, 2.0, 0],
    layers: { all: L('wall_military'), nz: L('bookshelf') },
    interact: {
      label: 'BOOKSHELF',
      fn: (g) => g.notify('FIELD MANUALS, SURVEY ATLASES. VOLUME IX IS MISSING.'),
    },
  });
  // cluttered workbench near the door
  new Machinery(ctx, -2.56, 29.1, 'W', {
    size: [1.6, 0.92, 0.6], tex: 'workbench',
    interact: {
      label: 'WORKBENCH',
      fn: (g) => g.notify('MICROSCOPE, SAMPLE DISHES, PATCH CABLES. MID-TASK, ABANDONED.'),
    },
  });

  new LightFixture(ctx, -4.5, 27.7, 'N', { len: 1.4 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-4.5, 2.62, 27.7]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.TERMINAL_PHOSPHOR, [-6.0, 1.2, 27.6]);
}
