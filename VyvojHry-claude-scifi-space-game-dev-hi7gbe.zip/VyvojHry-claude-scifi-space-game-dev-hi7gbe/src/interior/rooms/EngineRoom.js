/**
 * Engine Room (Room 13) — aft-most: two main drives, thruster feeds, the
 * deepest hum on the ship.
 */
import { LIGHTING } from '../../core/Constants.js';
import { Machinery } from '../props/Machinery.js';
import { Panel } from '../props/Panel.js';
import { FuelPort } from '../props/FuelPort.js';
import { Pipe } from '../props/Pipe.js';
import { WallScreen } from '../props/Console.js';
import { LightFixture } from '../props/Light.js';

export function dress(ctx) {
  new Machinery(ctx, -3.0, 72.44, 'N', {
    size: [2.8, 3.0, 2.4], tex: 'machinery', topPipe: true,
    interact: {
      label: 'MAIN DRIVE A',
      fn: (g) => g.notify('NOMINAL. VIBRATION 0.3 ABOVE BASELINE. LOGGED, IGNORED, LOGGED AGAIN.'),
    },
  });
  new Machinery(ctx, 3.0, 72.44, 'N', {
    size: [2.8, 3.0, 2.4], tex: 'machinery', topPipe: true,
    interact: {
      label: 'MAIN DRIVE B',
      fn: (g) => g.notify('COLD. START SEQUENCE REQUIRES BRIDGE AUTHORIZATION.'),
    },
  });
  new FuelPort(ctx, -5.94, 68.0, 'E');
  new Panel(ctx, 5.94, 68.0, 'W', {
    w: 1.2, h: 1.2, y: 0.8,
    interact: 'THRUSTER STATUS - RCS QUADS 1-4 GREEN. QUAD 3 VALVE REBUILT TWICE.',
  });
  /**
   * THE FIELD BENCH. A folding vice, a spool rack and a hotplate bolted to the
   * engine-room bulkhead, which is where a working hull's second bench always
   * ends up. It exists because the Petrel drops the whole workshop — and a hull
   * with no way at all to turn scrap into plate is a hull you cannot survive a
   * bad week in. Every class has an engine room, so every class can work.
   */
  new Machinery(ctx, 5.4, 70.6, 'W', {
    size: [1.5, 0.92, 0.62], tex: 'workbench',
    interact: {
      label: 'FIELD BENCH',
      fn: (g) => {
        if (g.openFabricator) g.openFabricator();
        else g.notify('FOLDING VICE, SPOOL RACK, HOTPLATE. NOTHING TO PUT IN IT.');
      },
    },
  });
  new WallScreen(ctx, -2.0, 64.6, 'S', {
    w: 1.0, h: 0.6, y: 1.3, screen: 'screen_amber',
    interact: { label: 'DRIVE TELEMETRY', fn: (g) => g.notify('DRIVE A 71% / DRIVE B STANDBY / FEED PRESSURE NOMINAL') },
  });
  new Pipe(ctx, 0, 64.65, 'S', { len: 8.0, y: 3.6, dia: 0.2 });
  new Pipe(ctx, 0, 64.65, 'S', { len: 8.0, y: 3.2, dia: 0.14 });

  new LightFixture(ctx, -2.5, 67.5, 'N', { len: 1.6, y: 4.75 });
  new LightFixture(ctx, 2.5, 70.0, 'N', { len: 1.6, y: 4.75 });
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [-2.5, 4.65, 67.5]);
  ctx.lights.add(ctx.zone.id, LIGHTING.TYPES.CEILING_TUBE, [2.5, 4.65, 70.0], 'occasional_cut');
  ctx.lights.add(ctx.zone.id, { ...LIGHTING.TYPES.REACTOR_GLOW, intensity: 0.4, radius: 4.0 }, [0, 1.5, 71.5]);
}
