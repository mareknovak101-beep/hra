/**
 * Greebles — automatic decorative detailing. After each zone's shell + room
 * dressing is built, this scatters small mechanical props along the free wall
 * runs (the ones not covered by a door, window or major prop): junction
 * boxes, cable conduits, wall pipes, extinguisher canisters, signage plates
 * and small vent grilles. Deterministic per zone (seeded RNG) so the ship is
 * the same every session.
 *
 * These are visual density only — no colliders (the flat wall collider already
 * stops the player short of them). They ride ~5cm proud of the wall plane.
 */
import { RNG } from '../utils/RNG.js';
import { clearRuns } from './Room.js';

/**
 * Local wall-space box: `a` runs along the wall, `d` is depth out from it.
 * `opts` (optional) is merged into the box call — used for per-face emissive on
 * lit greebles. `base` shifts the box's near face off the wall so stacked
 * details sit proud of a backing plate (layered relief = plasticity).
 */
function wallBox(ctx, w, a0, a1, y0, y1, depth, layer, ao, opts = {}, base = 0) {
  const near = w.at + w.dir * base;
  const far = w.at + w.dir * (base + depth);
  const lo = Math.min(near, far);
  const hi = Math.max(near, far);
  const uv = { uvScale: opts.uvScale ?? 1.0, ao: ao ?? [0.7, 0.7, 0.95, 0.95], ...opts };
  if (w.plane === 'z') ctx.builder.box([a0, y0, lo], [a1, y1, hi], layer, uv);
  else ctx.builder.box([lo, y0, a0], [hi, y1, a1], layer, uv);
}

/** A vertical cable run dropping down the wall from the rail to the skirting. */
function cableRun(ctx, w, a, layer) {
  wallBox(ctx, w, a - 0.04, a + 0.04, 0.16, 1.1, 0.04, layer, [0.6, 0.6, 0.8, 0.8]);
}

// [weight, builder(ctx, w, center, L), topReach] — topReach is the highest y
// the kind occupies, so it is only placed where the ceiling clears it.
const GREEBLE_KINDS = [
  [3, function junctionBox(ctx, w, c, L) {
    wallBox(ctx, w, c - 0.16, c + 0.16, 0.9, 1.28, 0.09, L('panel_wall'), [0.85, 0.85, 1, 1]);
    cableRun(ctx, w, c - 0.1, L('pipe'));
    cableRun(ctx, w, c + 0.1, L('pipe'));
  }, 1.28],
  [3, function conduit(ctx, w, c, L) {
    // horizontal pipe hugging the wall at chest height for ~1m
    const half = 0.5;
    if (w.plane === 'z') wallBox(ctx, w, c - half, c + half, 1.35, 1.5, 0.08, L('pipe'), [0.8, 0.8, 1, 1]);
    else wallBox(ctx, w, c - half, c + half, 1.35, 1.5, 0.08, L('pipe'), [0.8, 0.8, 1, 1]);
  }, 1.5],
  [2, function extinguisher(ctx, w, c, L) {
    wallBox(ctx, w, c - 0.09, c + 0.09, 0.55, 0.95, 0.12, L('canister_red'), [0.9, 0.9, 1, 1]);
    // small bracket above
    wallBox(ctx, w, c - 0.1, c + 0.1, 0.95, 1.0, 0.13, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
  }, 1.0],
  [2, function sign(ctx, w, c, L) {
    wallBox(ctx, w, c - 0.22, c + 0.22, 1.55, 1.85, 0.03, L('sign_plate'), [1, 1, 1, 1]);
  }, 1.85],
  [2, function ventlet(ctx, w, c, L) {
    wallBox(ctx, w, c - 0.24, c + 0.24, 0.35, 0.7, 0.03, L('vent'), [0.85, 0.85, 1, 1]);
  }, 0.7],
  [2, function breaker(ctx, w, c, L) {
    wallBox(ctx, w, c - 0.2, c + 0.2, 0.95, 1.4, 0.06, L('machinery'), [0.85, 0.85, 1, 1]);
  }, 1.4],
  // --- richer, layered detail (more plasticity, more sci-fi density) ---
  [2, function gaugeCluster(ctx, w, c, L) {
    // recessed backing plate with three instrument bezels standing proud of it
    wallBox(ctx, w, c - 0.28, c + 0.28, 0.95, 1.42, 0.03, L('panel_wall'), [0.8, 0.8, 1, 1]);
    for (const dx of [-0.17, 0, 0.17]) {
      wallBox(ctx, w, c + dx - 0.07, c + dx + 0.07, 1.06, 1.3, 0.09, L('machinery'), [0.9, 0.9, 1, 1], {}, 0.03);
    }
    wallBox(ctx, w, c - 0.28, c + 0.28, 0.9, 0.95, 0.05, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
  }, 1.42],
  [2, function valveManifold(ctx, w, c, L) {
    // twin horizontal pipes with a valve wheel proud of them
    wallBox(ctx, w, c - 0.42, c + 0.42, 0.72, 0.84, 0.08, L('pipe'), [0.8, 0.8, 1, 1]);
    wallBox(ctx, w, c - 0.42, c + 0.42, 1.02, 1.14, 0.08, L('pipe'), [0.8, 0.8, 1, 1]);
    wallBox(ctx, w, c - 0.11, c + 0.11, 0.83, 1.05, 0.12, L('machinery'), [0.9, 0.9, 1, 1], {}, 0.05);
    cableRun(ctx, w, c + 0.34, L('pipe'));
  }, 1.14],
  [2, function cableTray(ctx, w, c, L) {
    // a shallow tray carrying three parallel cables at staggered depth
    wallBox(ctx, w, c - 0.5, c + 0.5, 1.78, 1.92, 0.05, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    wallBox(ctx, w, c - 0.5, c + 0.5, 1.8, 1.86, 0.1, L('pipe'), [0.85, 0.85, 1, 1], {}, 0.05);
    wallBox(ctx, w, c - 0.5, c + 0.5, 1.86, 1.9, 0.08, L('pipe'), [0.8, 0.8, 1, 1], {}, 0.05);
  }, 1.92],
  [2, function monitor(ctx, w, c, L) {
    // small readout screen in a deep bezel — muted amber, never neon
    wallBox(ctx, w, c - 0.24, c + 0.24, 1.28, 1.74, 0.07, L('door_frame'), [0.8, 0.8, 1, 1]);
    wallBox(ctx, w, c - 0.19, c + 0.19, 1.33, 1.69, 0.03, L('screen_amber'),
      [1, 1, 1, 1], { emissive: 0.9 }, 0.07);
    wallBox(ctx, w, c - 0.24, c + 0.24, 1.2, 1.28, 0.05, L('machinery'), [0.7, 0.7, 0.9, 0.9]);
  }, 1.74],
  [1, function ductBox(ctx, w, c, L) {
    // a chunky ribbed junction with a drop pipe — deep silhouette
    wallBox(ctx, w, c - 0.22, c + 0.22, 1.5, 2.02, 0.12, L('machinery'), [0.85, 0.85, 1, 1]);
    wallBox(ctx, w, c - 0.26, c + 0.26, 1.44, 1.5, 0.06, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    cableRun(ctx, w, c, L('pipe'));
  }, 2.02],

  // --- second wave (session 16v): the ship read as empty because eleven kinds
  // capped at six per wall run left a 20m hold with six objects on it. These are
  // mostly TALL or LONG so they break the horizontal band the old set sat in,
  // and several are pure structure (ladder, rail, pipe cluster) rather than
  // another box on the wall.
  [2, function pipeCluster(ctx, w, c, L) {
    // four vertical pipes of differing gauge, floor to ceiling, with clamps
    const gauges = [0.05, 0.035, 0.06, 0.04];
    let a = c - 0.24;
    for (let i = 0; i < gauges.length; i++) {
      const g = gauges[i];
      wallBox(ctx, w, a, a + g * 2, 0.1, 2.3, g * 1.6, L(i === 2 ? 'machinery' : 'pipe'),
        [0.7, 0.7, 0.95, 0.95]);
      a += g * 2 + 0.035;
    }
    // clamp bands at two heights, standing proud of the pipes
    for (const y of [0.62, 1.74]) {
      wallBox(ctx, w, c - 0.27, c + 0.27, y, y + 0.07, 0.13, L('door_frame'), [0.85, 0.85, 1, 1]);
    }
  }, 2.3],
  [2, function ladder(ctx, w, c, L) {
    // access ladder — two stiles and eight rungs. Reads as a route, not decor,
    // which is what makes a hold feel like a working space.
    wallBox(ctx, w, c - 0.21, c - 0.17, 0.1, 2.25, 0.11, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    wallBox(ctx, w, c + 0.17, c + 0.21, 0.1, 2.25, 0.11, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    for (let i = 0; i < 8; i++) {
      const y = 0.24 + i * 0.26;
      wallBox(ctx, w, c - 0.19, c + 0.19, y, y + 0.04, 0.09, L('pipe'), [0.9, 0.9, 1, 1], {}, 0.02);
    }
  }, 2.25],
  [2, function handrail(ctx, w, c, L) {
    // rail on three stand-off brackets — the brackets are what sell it
    wallBox(ctx, w, c - 0.62, c + 0.62, 0.94, 0.99, 0.13, L('pipe'), [0.9, 0.9, 1, 1], {}, 0.06);
    for (const dx of [-0.55, 0, 0.55]) {
      wallBox(ctx, w, c + dx - 0.03, c + dx + 0.03, 0.9, 1.03, 0.07, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    }
  }, 1.03],
  [2, function grilleBank(ctx, w, c, L) {
    // three louvred returns in a common frame, recessed behind it
    wallBox(ctx, w, c - 0.44, c + 0.44, 1.36, 1.88, 0.04, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    for (const dx of [-0.28, 0, 0.28]) {
      wallBox(ctx, w, c + dx - 0.12, c + dx + 0.12, 1.42, 1.82, 0.02, L('vent'), [0.9, 0.9, 1, 1]);
    }
  }, 1.88],
  [2, function powerPanel(ctx, w, c, L) {
    // breaker cabinet with a throw lever and conduit stubs top and bottom
    wallBox(ctx, w, c - 0.24, c + 0.24, 0.86, 1.46, 0.11, L('machinery'), [0.85, 0.85, 1, 1]);
    wallBox(ctx, w, c - 0.2, c + 0.2, 0.92, 1.4, 0.02, L('panel_wall'), [0.95, 0.95, 1, 1], {}, 0.11);
    wallBox(ctx, w, c + 0.14, c + 0.2, 1.0, 1.16, 0.06, L('canister_red'), [1, 1, 1, 1], {}, 0.13);
    for (const dx of [-0.13, 0.13]) {
      wallBox(ctx, w, c + dx - 0.025, c + dx + 0.025, 1.46, 2.0, 0.05, L('pipe'), [0.7, 0.7, 0.9, 0.9]);
      wallBox(ctx, w, c + dx - 0.025, c + dx + 0.025, 0.18, 0.86, 0.05, L('pipe'), [0.6, 0.6, 0.85, 0.85]);
    }
  }, 2.0],
  [2, function hoseReel(ctx, w, c, L) {
    // drum on a stand-off bracket with a coil of hose and a nozzle clip
    wallBox(ctx, w, c - 0.26, c + 0.26, 0.72, 1.24, 0.06, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    wallBox(ctx, w, c - 0.21, c + 0.21, 0.78, 1.18, 0.17, L('pipe'), [0.85, 0.85, 1, 1], {}, 0.06);
    wallBox(ctx, w, c - 0.1, c + 0.1, 0.88, 1.08, 0.2, L('machinery'), [0.9, 0.9, 1, 1], {}, 0.06);
    wallBox(ctx, w, c + 0.2, c + 0.28, 0.6, 0.74, 0.09, L('canister_red'), [1, 1, 1, 1]);
  }, 1.24],
  [2, function lockerSmall(ctx, w, c, L) {
    // shallow supply cabinet — two doors, hinges, a latch and a placard
    wallBox(ctx, w, c - 0.3, c + 0.3, 0.8, 1.62, 0.16, L('locker'), [0.85, 0.85, 1, 1]);
    wallBox(ctx, w, c - 0.005, c + 0.005, 0.82, 1.6, 0.17, L('door_frame'), [0.6, 0.6, 0.85, 0.85]);
    for (const y of [0.92, 1.5]) {
      wallBox(ctx, w, c - 0.3, c - 0.24, y, y + 0.05, 0.18, L('machinery'), [0.9, 0.9, 1, 1]);
      wallBox(ctx, w, c + 0.24, c + 0.3, y, y + 0.05, 0.18, L('machinery'), [0.9, 0.9, 1, 1]);
    }
    wallBox(ctx, w, c - 0.14, c + 0.14, 1.66, 1.8, 0.03, L('sign_plate'), [1, 1, 1, 1]);
  }, 1.8],
  [1, function sensorPod(ctx, w, c, L) {
    // an angled pod high on the wall with a lens and a stalk
    wallBox(ctx, w, c - 0.03, c + 0.03, 2.0, 2.2, 0.06, L('pipe'), [0.7, 0.7, 0.9, 0.9]);
    wallBox(ctx, w, c - 0.12, c + 0.12, 1.84, 2.02, 0.16, L('machinery'), [0.9, 0.9, 1, 1]);
    wallBox(ctx, w, c - 0.06, c + 0.06, 1.88, 1.98, 0.05, L('screen_amber'),
      [1, 1, 1, 1], { emissive: 0.7 }, 0.16);
  }, 2.2],
  // --- themed fittings (session 16w) ---
  //
  // These are the ones carrying the house style rather than generic machinery.
  // The reference is the lived-in industrial interior in `context/01`: quilted
  // padding, corrugated flexible ducting, caged lamps, fat cable looms on
  // strapping, gasketed hatch surrounds. Each is built in THREE OR FOUR depth
  // tiers — a backing plate, a body, and something proud of the body — because
  // a single box at one depth reads as a sticker however good its texture is.
  // Depth comes from stacked silhouettes, and that is what "plasticity" means
  // here.
  [3, function quiltPadding(ctx, w, c, L) {
    // Padded bulkhead lining: a backing plate, then a grid of proud pads with
    // gutters between them. The signature corridor surface of the reference,
    // and the one thing on this ship that is soft.
    wallBox(ctx, w, c - 0.62, c + 0.62, 0.42, 1.86, 0.03, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    for (let r = 0; r < 4; r++) {
      const y0 = 0.46 + r * 0.35;
      for (let i = 0; i < 4; i++) {
        const a = c - 0.56 + i * 0.3;
        wallBox(ctx, w, a, a + 0.25, y0, y0 + 0.29, 0.07, L('mattress'), [0.9, 0.9, 1, 1], {}, 0.03);
        // button dimple in the middle of each pad — the fourth tier
        wallBox(ctx, w, a + 0.1, a + 0.15, y0 + 0.12, y0 + 0.17, 0.04, L('machinery'),
          [0.6, 0.6, 0.85, 0.85], {}, 0.03);
      }
    }
    wallBox(ctx, w, c - 0.64, c + 0.64, 1.86, 1.94, 0.06, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    wallBox(ctx, w, c - 0.64, c + 0.64, 0.34, 0.42, 0.06, L('door_frame'), [0.65, 0.65, 0.85, 0.85]);
  }, 1.94],
  [2, function flexDuct(ctx, w, c, L) {
    // Corrugated flexible duct climbing the wall into the overhead, built from
    // alternating wide and narrow segments so the corrugation is real geometry
    // and not a painted stripe.
    for (let i = 0; i < 9; i++) {
      const y = 0.5 + i * 0.19;
      const wide = i % 2 === 0;
      const hw = wide ? 0.16 : 0.13;
      const d = wide ? 0.17 : 0.13;
      wallBox(ctx, w, c - hw, c + hw, y, y + 0.19, d, L('pipe'), [0.85, 0.85, 1, 1]);
    }
    // gasketed collars top and bottom where it lands on hard fittings
    wallBox(ctx, w, c - 0.2, c + 0.2, 0.36, 0.52, 0.2, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    wallBox(ctx, w, c - 0.2, c + 0.2, 2.19, 2.34, 0.2, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    wallBox(ctx, w, c - 0.24, c + 0.24, 0.3, 0.38, 0.1, L('machinery'), [0.8, 0.8, 1, 1]);
  }, 2.34],
  [2, function cageLamp(ctx, w, c, L) {
    // Wall lamp behind a guard cage: backing plate, housing, lens, then four
    // bars standing proud of the lens. An unguarded glowing box is a decal; a
    // guarded one is hardware you could bark a knuckle on.
    wallBox(ctx, w, c - 0.19, c + 0.19, 1.72, 2.14, 0.05, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    wallBox(ctx, w, c - 0.15, c + 0.15, 1.76, 2.1, 0.11, L('machinery'), [0.85, 0.85, 1, 1], {}, 0.05);
    wallBox(ctx, w, c - 0.11, c + 0.11, 1.8, 2.06, 0.03, L('light_tube'),
      [1, 1, 1, 1], { emissive: 1 }, 0.16);
    for (const dx of [-0.09, -0.03, 0.03, 0.09]) { // vertical guard bars
      wallBox(ctx, w, c + dx - 0.012, c + dx + 0.012, 1.78, 2.08, 0.03, L('pipe'),
        [0.9, 0.9, 1, 1], {}, 0.19);
    }
    wallBox(ctx, w, c - 0.13, c + 0.13, 1.76, 1.8, 0.05, L('pipe'), [0.8, 0.8, 1, 1], {}, 0.17);
  }, 2.14],
  [2, function cableLoom(ctx, w, c, L) {
    // A fat bundle of lines dropping the full height on strapping brackets —
    // five cables at four different depths, so the loom has a rounded profile
    // instead of being a flat ribbon.
    const lay = [[-0.09, 0.06], [-0.04, 0.1], [0.01, 0.12], [0.06, 0.09], [0.1, 0.05]];
    for (const [dx, d] of lay) {
      wallBox(ctx, w, c + dx - 0.025, c + dx + 0.025, 0.2, 2.2, d, L('pipe'), [0.8, 0.8, 1, 1]);
    }
    for (const y of [0.42, 1.06, 1.72]) { // strapping saddles
      wallBox(ctx, w, c - 0.15, c + 0.15, y, y + 0.08, 0.16, L('door_frame'), [0.85, 0.85, 1, 1]);
      wallBox(ctx, w, c - 0.17, c + 0.17, y - 0.02, y + 0.1, 0.05, L('machinery'), [0.7, 0.7, 0.9, 0.9]);
    }
  }, 2.2],
  [2, function hatchSurround(ctx, w, c, L) {
    // A sealed inspection hatch: gasket frame, dogged door, four dog levers and
    // a centre wheel. Four tiers deep and the most mechanical thing on a wall.
    wallBox(ctx, w, c - 0.36, c + 0.36, 0.62, 1.5, 0.04, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    wallBox(ctx, w, c - 0.31, c + 0.31, 0.67, 1.45, 0.03, L('vent'), [0.6, 0.6, 0.85, 0.85], {}, 0.04);
    wallBox(ctx, w, c - 0.28, c + 0.28, 0.7, 1.42, 0.09, L('locker'), [0.9, 0.9, 1, 1], {}, 0.07);
    for (const [dx, dy] of [[-0.22, 0.76], [0.22, 0.76], [-0.22, 1.3], [0.22, 1.3]]) {
      wallBox(ctx, w, c + dx - 0.035, c + dx + 0.035, dy, dy + 0.09, 0.06,
        L('machinery'), [0.95, 0.95, 1, 1], {}, 0.16);
    }
    wallBox(ctx, w, c - 0.09, c + 0.09, 1.0, 1.12, 0.07, L('pipe'), [0.95, 0.95, 1, 1], {}, 0.16);
    wallBox(ctx, w, c - 0.02, c + 0.02, 0.94, 1.18, 0.05, L('pipe'), [0.9, 0.9, 1, 1], {}, 0.18);
  }, 1.5],
  [1, function cableSpool(ctx, w, c, L) {
    // a drum of spare line on two brackets, low on the wall
    wallBox(ctx, w, c - 0.28, c + 0.28, 0.24, 0.3, 0.2, L('door_frame'), [0.7, 0.7, 0.9, 0.9]);
    wallBox(ctx, w, c - 0.22, c + 0.22, 0.3, 0.66, 0.24, L('pipe'), [0.85, 0.85, 1, 1]);
    wallBox(ctx, w, c - 0.24, c - 0.19, 0.28, 0.68, 0.26, L('machinery'), [0.8, 0.8, 1, 1]);
    wallBox(ctx, w, c + 0.19, c + 0.24, 0.28, 0.68, 0.26, L('machinery'), [0.8, 0.8, 1, 1]);
  }, 0.68],
];

/**
 * MICRO DETAIL — the layer that actually fixes "feels empty".
 *
 * The main greebles are 0.4–1.2m objects on a ~1m pitch, so between any two of
 * them there is a metre of bare wall, and bare wall is what reads as unfinished.
 * These are 4–20cm fittings scattered on a ~0.35m pitch in the gaps: conduit
 * staples, bracket pads, placards, cable clips, corner angles. Individually
 * they are almost invisible; collectively they are the difference between a
 * built surface and a painted one.
 *
 * All are ≤4cm proud so they never intrude on the walkway, and none carries
 * legible text (same rule as the textures — a repeated readable label is worse
 * than no label).
 */
const MICRO_KINDS = [
  function staple(ctx, w, c, L, y) {
    wallBox(ctx, w, c - 0.035, c + 0.035, y, y + 0.05, 0.035, L('door_frame'), [0.8, 0.8, 1, 1]);
  },
  function clipPair(ctx, w, c, L, y) {
    wallBox(ctx, w, c - 0.05, c - 0.01, y, y + 0.07, 0.03, L('machinery'), [0.85, 0.85, 1, 1]);
    wallBox(ctx, w, c + 0.01, c + 0.05, y, y + 0.07, 0.03, L('machinery'), [0.85, 0.85, 1, 1]);
  },
  function placard(ctx, w, c, L, y) {
    wallBox(ctx, w, c - 0.075, c + 0.075, y, y + 0.1, 0.015, L('sign_plate'), [1, 1, 1, 1]);
  },
  function bracketPad(ctx, w, c, L, y) {
    wallBox(ctx, w, c - 0.06, c + 0.06, y, y + 0.12, 0.025, L('door_frame'), [0.75, 0.75, 0.95, 0.95]);
    wallBox(ctx, w, c - 0.02, c + 0.02, y + 0.03, y + 0.09, 0.045, L('pipe'), [0.9, 0.9, 1, 1], {}, 0.025);
  },
  function stubPipe(ctx, w, c, L, y) {
    wallBox(ctx, w, c - 0.025, c + 0.025, y, y + 0.22, 0.04, L('pipe'), [0.8, 0.8, 1, 1]);
  },
  function boltPad(ctx, w, c, L, y) {
    wallBox(ctx, w, c - 0.04, c + 0.04, y, y + 0.04, 0.02, L('machinery'), [0.9, 0.9, 1, 1]);
  },
];

// Wall-hugging kinds (<=0.07 proud) — the only greebles allowed in narrow
// transit spaces (corridors/junctions) so nothing juts into the walkway.
// quiltPadding earns its place despite being 0.07: the padded corridor
// lining is the single most on-theme surface in the reference, and a
// corridor is exactly where it belongs.
const FLAT_KINDS = new Set(['sign', 'ventlet', 'breaker', 'monitor',
  'grilleBank', 'handrail', 'ladder', 'quiltPadding', 'cageLamp']);

/** Weighted pick among kinds whose top reach clears `maxTop`. */
function pickKind(rng, maxTop, flatOnly) {
  const eligible = GREEBLE_KINDS.filter(([, fn, top]) =>
    top <= maxTop && (!flatOnly || FLAT_KINDS.has(fn.name)));
  if (!eligible.length) return null;
  const total = eligible.reduce((s, [wt]) => s + wt, 0);
  let r = rng.range(0, total);
  for (const [wt, fn] of eligible) { if ((r -= wt) < 0) return fn; }
  return eligible[0][1];
}

/**
 * Dress one zone with greebles.
 * @param {object} ctx build context {zone, builder, atlas, openings}
 */
export function dressGreebles(ctx) {
  const { zone, atlas } = ctx;
  if (zone.h < 1.9) return; // maintenance crawl stays claustrophobically bare
  const rng = new RNG(0x9eeb1e ^ hashId(zone.id));
  const L = (n) => atlas.layer(n);
  const { x0, x1, z0, z1 } = zone.rect;

  const walls = [
    { plane: 'z', at: z0, a0: x0, a1: x1, dir: +1, openings: ctx.openings.nz },
    { plane: 'z', at: z1, a0: x0, a1: x1, dir: -1, openings: ctx.openings.pz },
    { plane: 'x', at: x0, a0: z0, a1: z1, dir: +1, openings: ctx.openings.nx },
    { plane: 'x', at: x1, a0: z0, a1: z1, dir: -1, openings: ctx.openings.px },
  ];

  // Corridors and junctions are transit spaces: keep them clean, using only
  // flat wall-hugging greebles (sparser) so nothing juts into the walkway.
  const narrow = zone.kind === 'corridor' || zone.kind === 'junction';
  // Density raised across the board (session 16v). The old numbers left a 20m
  // cargo wall carrying six objects, and corridors — where the player spends
  // most of their time — one every four metres at half odds.
  const density = narrow ? 1.3 : 0.8; // metres of wall run per greeble slot
  const chance = narrow ? 0.72 : 0.92;
  const maxTop = zone.h - 0.12; // keep greebles clear of the ceiling
  for (const w of walls) {
    for (const [r0, r1] of clearRuns(w.a0, w.a1, w.openings, 0.45)) {
      const len = r1 - r0;
      if (len < 0.8) continue;
      // Cap scales with the run instead of a flat 6. The flat cap was the single
      // biggest cause of the ship feeling empty: it applied hardest exactly where
      // it hurt most, in the big holds with the most wall to fill.
      const count = Math.min(22, Math.floor(len / density));
      const used = [];
      for (let i = 0; i < count; i++) {
        if (!rng.chance(chance)) continue;
        // jittered position within an even slot
        const slot = r0 + (len * (i + 0.5)) / count + rng.range(-0.2, 0.2);
        const c = Math.max(r0 + 0.3, Math.min(r1 - 0.3, slot));
        const fn = pickKind(rng, maxTop, narrow);
        if (fn) { fn(ctx, w, c, L); used.push(c); }
      }
      microPass(ctx, w, r0, r1, used, rng, L, maxTop);
    }
  }

  edgeStructure(ctx, rng, L, narrow);
  deckFittings(ctx, rng, L, narrow);
  if (!narrow) ceilingConduits(ctx, rng, L); // no overhead clutter in transit spaces
}

/**
 * Deck fittings — the floor was a flat plane with a texture on it.
 *
 * Walls got three passes of detail and the ceiling now has a rig, but the deck
 * had nothing at all standing on it, and it is a third of what the player sees
 * while walking. These are all LOW (≤7cm) and carry no colliders, so they read
 * as flush fittings you walk over rather than obstacles: tie-down rings on
 * pads, bolted access hatches, a cable ramp crossing the walkway, and kerbs
 * marking the edge of the traffic route.
 *
 * The kerbs matter most. A room with a defined walkway edge reads as laid out;
 * a room where the floor meets the wall in a bare line reads as a box you were
 * dropped into.
 */
function deckFittings(ctx, rng, L, narrow) {
  const { zone, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const ao = [0.55, 0.55, 0.85, 0.85]; // deck detail is shaded from below
  const uv = { uvScale: 1, ao };
  const spanX = x1 - x0, spanZ = z1 - z0;
  const alongZ = spanZ >= spanX;
  const lo = alongZ ? z0 : x0, hi = alongZ ? z1 : x1;
  const c0 = alongZ ? x0 : z0, c1 = alongZ ? x1 : z1;
  /** Axis-agnostic floor box: `a` along the long axis, `c` across it. */
  const R = (a0, a1, cc0, cc1, y0, y1, layer) => {
    if (alongZ) builder.box([cc0, y0, a0], [cc1, y1, a1], layer, uv);
    else builder.box([a0, y0, cc0], [a1, y1, cc1], layer, uv);
  };

  // -- walkway kerbs, inset from the wall so the skirting duct clears them ---
  if (!narrow && Math.min(spanX, spanZ) > 3.2) {
    for (const s of [-1, 1]) {
      const c = (c0 + c1) / 2 + s * (Math.min(spanX, spanZ) / 2 - 0.62);
      R(lo + 0.5, hi - 0.5, c - 0.05, c + 0.05, 0.005, 0.055, L('floor_hazard'));
      // periodic raised blocks along the kerb — a plain strip reads as a decal
      for (let a = lo + 0.8; a < hi - 0.7; a += 1.6) {
        R(a, a + 0.3, c - 0.07, c + 0.07, 0.005, 0.075, L('door_frame'));
      }
    }
  }

  // -- bolted deck access hatches -------------------------------------------
  const hatches = Math.max(1, Math.floor((hi - lo) / 4.4));
  for (let i = 1; i <= hatches; i++) {
    const a = lo + ((hi - lo) * i) / (hatches + 1) + rng.range(-0.4, 0.4);
    const c = (c0 + c1) / 2 + rng.range(-0.5, 0.5);
    R(a - 0.42, a + 0.42, c - 0.42, c + 0.42, 0.004, 0.026, L('floor_grate'));  // liner
    R(a - 0.36, a + 0.36, c - 0.36, c + 0.36, 0.026, 0.05, L('floor_plate'));   // lid
    for (const [da, dc] of [[-0.3, -0.3], [0.3, -0.3], [-0.3, 0.3], [0.3, 0.3]]) {
      R(a + da - 0.05, a + da + 0.05, c + dc - 0.05, c + dc + 0.05, 0.05, 0.072, L('machinery'));
    }
    R(a - 0.07, a + 0.07, c - 0.07, c + 0.07, 0.05, 0.078, L('pipe')); // lift ring
  }

  // -- tie-down rings on pads, scattered near the walls ----------------------
  for (let i = 0; i < (narrow ? 2 : 7); i++) {
    const a = rng.range(lo + 0.6, hi - 0.6);
    const c = rng.chance(0.5) ? rng.range(c0 + 0.4, c0 + 1.1) : rng.range(c1 - 1.1, c1 - 0.4);
    R(a - 0.11, a + 0.11, c - 0.11, c + 0.11, 0.004, 0.024, L('door_frame'));
    R(a - 0.06, a + 0.06, c - 0.035, c + 0.035, 0.024, 0.062, L('pipe'));
  }

  // -- one cable ramp crossing the deck --------------------------------------
  if (!narrow && Math.min(spanX, spanZ) > 2.6) {
    const a = lo + (hi - lo) * rng.range(0.3, 0.7);
    R(a - 0.16, a + 0.16, c0 + 0.35, c1 - 0.35, 0.004, 0.042, L('pipe'));
    R(a - 0.22, a + 0.22, c0 + 0.35, c1 - 0.35, 0.004, 0.02, L('door_frame')); // ramp skirts
  }
}

/**
 * Scatter MICRO_KINDS through the gaps a wall run's main greebles leave.
 *
 * Keeps 0.22m clear of every placed greeble so nothing intersects one, and
 * spreads the y positions across the wall's whole height rather than the
 * 0.9–1.5m band the main kinds cluster in — a wall with detail only at chest
 * height still reads as bare above and below.
 */
function microPass(ctx, w, r0, r1, used, rng, L, maxTop) {
  const step = 0.34;
  for (let a = r0 + 0.25; a < r1 - 0.25; a += step * rng.range(0.7, 1.5)) {
    if (used.some((u) => Math.abs(u - a) < 0.22)) continue;
    if (!rng.chance(0.62)) continue;
    const fn = MICRO_KINDS[rng.int(0, MICRO_KINDS.length - 1)];
    const y = rng.chance(0.45)
      ? rng.range(0.25, 0.8) // low: skirting fittings and cable runs
      : rng.chance(0.55)
        ? rng.range(1.0, 1.7) // mid: the working band
        : rng.range(1.9, Math.max(2.0, maxTop - 0.2)); // high: overhead services
    fn(ctx, w, a, L, Math.min(y, maxTop - 0.25));
  }
}

/**
 * Structural detail on the room's EDGES rather than its faces: vertical corner
 * angles, a continuous cable tray under the cornice, and a skirting duct along
 * the wall base.
 *
 * Edges are where a real compartment carries most of its ironmongery and where
 * this ship carried none — every wall met its neighbour and the floor in a bare
 * mitre. These three runs also tie the room together visually, so the greebles
 * on the faces read as fitted to a structure rather than stuck on at random.
 */
function edgeStructure(ctx, rng, L, narrow) {
  const { zone, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const h = zone.h;
  const ao = [0.7, 0.7, 0.9, 0.9];
  const t = 0.07;
  // corner angles, floor to just under the cornice
  const top = Math.min(h - 0.16, 2.5);
  for (const [cx, cz] of [[x0, z0], [x1, z0], [x0, z1], [x1, z1]]) {
    const sx = cx === x0 ? 1 : -1, sz = cz === z0 ? 1 : -1;
    builder.box([Math.min(cx, cx + sx * 0.16), 0.02, Math.min(cz, cz + sz * t)],
      [Math.max(cx, cx + sx * 0.16), top, Math.max(cz, cz + sz * t)], L('door_frame'), { uvScale: 1, ao });
    builder.box([Math.min(cx, cx + sx * t), 0.02, Math.min(cz, cz + sz * 0.16)],
      [Math.max(cx, cx + sx * t), top, Math.max(cz, cz + sz * 0.16)], L('door_frame'), { uvScale: 1, ao });
  }
  // skirting duct along the two long walls, with periodic access covers
  const dz = z1 - z0 > x1 - x0;
  const duct = (a0, a1, fixed, alongZ) => {
    const y0 = 0.04, y1 = 0.22;
    if (alongZ) builder.box([fixed - 0.09, y0, a0 + 0.2], [fixed + 0.09, y1, a1 - 0.2], L('pipe'), { uvScale: 1, ao });
    else builder.box([a0 + 0.2, y0, fixed - 0.09], [a1 - 0.2, y1, fixed + 0.09], L('pipe'), { uvScale: 1, ao });
    const n = Math.max(1, Math.floor((a1 - a0) / 2.6));
    for (let i = 1; i <= n; i++) {
      const p = a0 + ((a1 - a0) * i) / (n + 1) + rng.range(-0.25, 0.25);
      if (alongZ) builder.box([fixed - 0.11, y0 + 0.02, p - 0.13], [fixed + 0.11, y1 + 0.02, p + 0.13], L('machinery'), { uvScale: 1, ao });
      else builder.box([p - 0.13, y0 + 0.02, fixed - 0.11], [p + 0.13, y1 + 0.02, fixed + 0.11], L('machinery'), { uvScale: 1, ao });
    }
  };
  if (dz) { duct(z0, z1, x0 + 0.12, true); duct(z0, z1, x1 - 0.12, true); }
  else { duct(x0, x1, z0 + 0.12, false); duct(x0, x1, z1 - 0.12, false); }

  // cable tray riding just under the cornice on the two long walls
  if (narrow || h < 2.4) return;
  const ty0 = Math.min(h - 0.34, 2.16), ty1 = ty0 + 0.1;
  const tray = (a0, a1, fixed, alongZ) => {
    if (alongZ) builder.box([fixed - 0.11, ty0, a0 + 0.15], [fixed + 0.11, ty1, a1 - 0.15], L('door_frame'), { uvScale: 1, ao });
    else builder.box([a0 + 0.15, ty0, fixed - 0.11], [a1 - 0.15, ty1, fixed + 0.11], L('door_frame'), { uvScale: 1, ao });
    // two cables sitting in the tray, at slightly different depths
    for (const [off, lay] of [[-0.04, 'pipe'], [0.035, 'ceiling_pipes']]) {
      if (alongZ) builder.box([fixed + off - 0.03, ty1 - 0.02, a0 + 0.15], [fixed + off + 0.03, ty1 + 0.04, a1 - 0.15], L(lay), { uvScale: 1, ao });
      else builder.box([a0 + 0.15, ty1 - 0.02, fixed + off - 0.03], [a1 - 0.15, ty1 + 0.04, fixed + off + 0.03], L(lay), { uvScale: 1, ao });
    }
  };
  if (dz) { tray(z0, z1, x0 + 0.14, true); tray(z0, z1, x1 - 0.14, true); }
  else { tray(x0, x1, z0 + 0.14, false); tray(x0, x1, z1 - 0.14, false); }
}

/**
 * Overhead cable/conduit runs slung just under the ceiling, spanning the room's
 * long axis, plus short cross-ties. Only in rooms tall enough that they clear a
 * jumping head. Decorative (no colliders); adds vertical layering overhead so
 * the ceiling reads as machinery, not a lid.
 */
function ceilingConduits(ctx, rng, L) {
  const { zone, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const h = zone.h;
  if (h < 2.6) return; // low compartments: keep the overhead clear
  const spanZ = z1 - z0, spanX = x1 - x0;
  const alongZ = spanZ >= spanX; // run pipes along the longer axis
  const y1 = h - 0.08, y0 = h - 0.2; // hangs ~12cm below the ceiling
  const ao = [0.7, 0.7, 0.85, 0.85];
  // two parallel runs, offset either side of centre
  const offs = alongZ
    ? [(x0 + x1) / 2 - Math.min(1.4, spanX * 0.28), (x0 + x1) / 2 + Math.min(1.4, spanX * 0.28)]
    : [(z0 + z1) / 2 - Math.min(1.4, spanZ * 0.28), (z0 + z1) / 2 + Math.min(1.4, spanZ * 0.28)];
  for (let k = 0; k < offs.length; k++) {
    const o = offs[k];
    const layer = k === 0 ? L('pipe') : L('ceiling_pipes');
    if (alongZ) builder.box([o - 0.07, y0, z0 + 0.2], [o + 0.07, y1, z1 - 0.2], layer, { uvScale: 1, ao });
    else builder.box([x0 + 0.2, y0, o - 0.07], [x1 - 0.2, y1, o + 0.07], layer, { uvScale: 1, ao });
  }
  // a few cross-ties / drop boxes bridging the runs
  const ties = Math.max(1, Math.floor((alongZ ? spanZ : spanX) / 3.2));
  const lo = alongZ ? z0 : x0, hi = alongZ ? z1 : x1;
  for (let i = 1; i <= ties; i++) {
    const t = lo + ((hi - lo) * i) / (ties + 1) + rng.range(-0.3, 0.3);
    if (alongZ) builder.box([offs[0], y0 - 0.03, t - 0.06], [offs[1], y1, t + 0.06], L('pipe'), { uvScale: 1, ao });
    else builder.box([t - 0.06, y0 - 0.03, offs[0]], [t + 0.06, y1, offs[1]], L('pipe'), { uvScale: 1, ao });
  }
  overheadRig(ctx, rng, L, alongZ);
}

/**
 * The overhead rig — the layer that fixes the emptiest surface on the ship.
 *
 * The ceiling had two parallel conduits and a few cross-ties over a flat plane,
 * which is nothing: it is the surface the player looks straight up into and it
 * carried less detail than any wall. The reference interior in `context/01` is
 * densest overhead — trunking, cable baskets, lamp housings in cages, sprinkler
 * drops, ribbed ducting — because that is where a real ship routes everything it
 * does not want underfoot.
 *
 * Everything hangs from the ceiling plane downward in FOUR tiers (hanger →
 * carrier → contents → fittings proud of the contents), for the same reason the
 * wall fittings do: one box at one depth is a sticker, stacked boxes throw
 * shadows onto each other.
 *
 * @param {boolean} alongZ true if the room's long axis is z (matches the
 *   conduit runs above, so the rig and the conduits agree on direction)
 */
function overheadRig(ctx, rng, L, alongZ) {
  const { zone, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const h = zone.h;
  const ao = [0.62, 0.62, 0.8, 0.8]; // overhead is shaded — light comes from below
  const uv = { uvScale: 1, ao };
  const lo = alongZ ? z0 : x0, hi = alongZ ? z1 : x1;
  const cross0 = alongZ ? x0 : z0, cross1 = alongZ ? x1 : z1;
  const mid = (cross0 + cross1) / 2;
  /** Axis-agnostic box: `a` runs along the room's long axis, `c` across it. */
  const R = (a0, a1, c0, c1, y0, y1, layer) => {
    if (alongZ) builder.box([c0, y0, a0], [c1, y1, a1], layer, uv);
    else builder.box([a0, y0, c0], [a1, y1, c1], layer, uv);
  };

  // -- 1. main trunking duct down the centreline, in segments with collars ----
  // Segmented rather than one extrusion: each collar is a step in the silhouette
  // and a shadow line, so a 20m run reads as assembled ductwork instead of a bar.
  const dy1 = h - 0.1, dy0 = h - 0.46;
  const segs = Math.max(2, Math.round((hi - lo) / 2.3));
  for (let i = 0; i < segs; i++) {
    const a0 = lo + ((hi - lo) * i) / segs + 0.06;
    const a1 = lo + ((hi - lo) * (i + 1)) / segs - 0.06;
    R(a0, a1, mid - 0.26, mid + 0.26, dy0, dy1, L('ceiling_pipes'));
    R(a1 - 0.09, a1 + 0.15, mid - 0.31, mid + 0.31, dy0 - 0.04, dy1, L('door_frame'));
    // hanger straps up to the deckhead either side of the collar
    for (const sc of [mid - 0.28, mid + 0.24]) {
      R(a1 - 0.02, a1 + 0.06, sc, sc + 0.04, dy1 - 0.02, h, L('pipe'));
    }
  }

  // -- 2. cable baskets outboard of the trunking, carrying loose runs --------
  for (const s of [-1, 1]) {
    const c = mid + s * Math.min(1.15, (cross1 - cross0) * 0.24);
    R(lo + 0.25, hi - 0.25, c - 0.16, c + 0.16, h - 0.3, h - 0.26, L('vent')); // basket floor
    for (const e of [-0.16, 0.13]) { // basket side rails
      R(lo + 0.25, hi - 0.25, c + e, c + e + 0.03, h - 0.32, h - 0.2, L('door_frame'));
    }
    for (const [dc, dd] of [[-0.1, 0.05], [-0.02, 0.06], [0.06, 0.045]]) { // the cables in it
      R(lo + 0.25, hi - 0.25, c + dc, c + dc + dd, h - 0.26, h - 0.26 + dd, L('pipe'));
    }
    // drop hangers at intervals
    for (let a = lo + 0.9; a < hi - 0.6; a += 2.1 + rng.range(-0.3, 0.3)) {
      R(a, a + 0.05, c - 0.18, c + 0.18, h - 0.33, h, L('door_frame'));
    }
  }

  // -- 3. caged deckhead lamps slung between the runs ------------------------
  // Same reasoning as the hull floodlamps: the cage is what makes it hardware.
  for (let a = lo + 1.6; a < hi - 1.0; a += 3.4) {
    const c = mid + (rng.chance(0.5) ? 1 : -1) * Math.min(1.9, (cross1 - cross0) * 0.34);
    R(a, a + 0.46, c - 0.15, c + 0.15, h - 0.24, h - 0.16, L('door_frame'));      // yoke
    R(a + 0.03, a + 0.43, c - 0.12, c + 0.12, h - 0.34, h - 0.24, L('machinery')); // housing
    // the lens itself is emissive, so it goes through builder.box directly
    // rather than R(), which has no opts channel
    builder.box(
      alongZ ? [c - 0.09, h - 0.37, a + 0.07] : [a + 0.07, h - 0.37, c - 0.09],
      alongZ ? [c + 0.09, h - 0.34, a + 0.39] : [a + 0.39, h - 0.34, c + 0.09],
      L('light_tube'), { uvScale: 1, ao: [1, 1, 1, 1], emissive: 1 });
    for (const g of [0.11, 0.22, 0.33]) { // guard bars across the lens
      R(a + g, a + g + 0.03, c - 0.11, c + 0.11, h - 0.4, h - 0.37, L('pipe'));
    }
  }

  // -- 4. sprinkler / sensor drops, short stems with a head ------------------
  for (let a = lo + 1.1; a < hi - 0.7; a += 2.7 + rng.range(-0.4, 0.4)) {
    const c = mid + rng.range(-1.5, 1.5);
    if (c < cross0 + 0.4 || c > cross1 - 0.4) continue;
    R(a, a + 0.05, c - 0.025, c + 0.025, h - 0.26, h, L('pipe'));
    R(a - 0.04, a + 0.09, c - 0.06, c + 0.06, h - 0.31, h - 0.26, L('machinery'));
  }
}

function hashId(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (Math.imul(h, 31) + id.charCodeAt(i)) | 0;
  return h;
}
