/**
 * Room — zone shell geometry: floor, ceiling, four walls with door/portal
 * openings cut in, plus matching colliders. Corridor.js reuses these pieces
 * and adds the per-type cross-section shapes.
 *
 * Wall keys: 'nz' wall at z0 (faces +z, into the zone), 'pz' at z1,
 * 'nx' at x0, 'px' at x1. Openings: {center, w, h} along the wall axis.
 */

const WALL_AO_BOTTOM = 0.72;
const WALL_AO_TOP = 0.85;
const CEIL_AO = 0.88;
const WALL_COLLIDER_HALF = 0.12;

/**
 * Vertical rect on plane ('x'|'z') = at, spanning [a0,a1] × [y0,y1], with the
 * normal pointing toward +plane axis when sign > 0.
 */
export function wallQuad(builder, plane, at, a0, a1, y0, y1, sign, layer, opts = {}) {
  const P = (a, y) => (plane === 'z' ? [a, y, at] : [at, y, a]);
  const ao = opts.ao ?? [WALL_AO_BOTTOM, WALL_AO_BOTTOM, WALL_AO_TOP, WALL_AO_TOP];
  const o = { ...opts, ao };
  if ((plane === 'z' && sign > 0) || (plane === 'x' && sign < 0)) {
    builder.quad(P(a0, y0), P(a1, y0), P(a1, y1), P(a0, y1), layer, o);
  } else {
    builder.quad(P(a1, y0), P(a0, y0), P(a0, y1), P(a1, y1), layer, o);
  }
}

/**
 * Wall with rectangular openings. Adds mesh segments + colliders.
 * Openings run from y0 (default 0 — doors) to h; a y0 > 0 makes a window,
 * adding a sill segment below it.
 * @param {object} ctx {builder, shipMap, zone}
 * @param {Array<{center:number,w:number,h:number,y0?:number}>} openings
 */
export function buildWall(ctx, plane, at, a0, a1, h, sign, layer, openings = [], opts = {}) {
  const sorted = [...openings].sort((p, q) => p.center - q.center);
  let cursor = a0;
  const segs = [];
  for (const op of sorted) {
    const lo = op.center - op.w / 2;
    const hi = op.center + op.w / 2;
    const sill = op.y0 ?? 0;
    if (lo > cursor + 1e-4) segs.push([cursor, lo, 0, h]);
    if (sill > 1e-4) segs.push([lo, hi, 0, sill]); // sill under a window
    if (op.h < h - 1e-4) segs.push([lo, hi, op.h, h, true]); // lintel
    cursor = hi;
  }
  if (cursor < a1 - 1e-4) segs.push([cursor, a1, 0, h]);
  if (openings.length === 0) segs.length = 0, segs.push([a0, a1, 0, h]);

  for (const [s0, s1, y0, y1, isLintel] of segs) {
    const ao = isLintel
      ? [WALL_AO_TOP, WALL_AO_TOP, WALL_AO_TOP, WALL_AO_TOP]
      : undefined;
    wallQuad(ctx.builder, plane, at, s0, s1, y0, y1, sign, layer, { ...opts, ao });
    // collider centered on the plane
    const t = WALL_COLLIDER_HALF;
    const min = plane === 'z' ? [s0, y0, at - t] : [at - t, y0, s0];
    const max = plane === 'z' ? [s1, y1, at + t] : [at + t, y1, s1];
    ctx.shipMap.collision.addBox(min, max, { wall: true, zone: ctx.zone.id });
  }
}

/** Floor + ceiling quads and their colliders for a rect zone. */
export function buildFloorCeiling(ctx, floorLayer, ceilLayer, opts = {}) {
  const { x0, x1, z0, z1 } = ctx.zone.rect;
  const h = ctx.zone.h;
  const b = ctx.builder;
  b.quad([x0, 0, z0], [x0, 0, z1], [x1, 0, z1], [x1, 0, z0], floorLayer, { uvScale: opts.floorUvScale ?? 0.5 });
  if (!opts.skipCeiling) {
    b.quad([x0, h, z0], [x1, h, z0], [x1, h, z1], [x0, h, z1], ceilLayer,
      { uvScale: 0.5, ao: [CEIL_AO, CEIL_AO, CEIL_AO, CEIL_AO] });
  }
  ctx.shipMap.collision.addBox([x0 - 0.5, -0.5, z0 - 0.5], [x1 + 0.5, 0, z1 + 0.5], { floor: true });
  ctx.shipMap.collision.addBox([x0, h, z0], [x1, h + 0.5, z1], { ceiling: true });
}

/**
 * Standard rectangular room shell. ctx.openings = {nz:[], pz:[], nx:[], px:[]}.
 */
export function buildRoomShell(ctx) {
  const { zone, atlas } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const h = zone.h;
  const wall = atlas.layer(zone.tex.wall);
  buildFloorCeiling(ctx, atlas.layer(zone.tex.floor), atlas.layer(zone.tex.ceil));
  buildWall(ctx, 'z', z0, x0, x1, h, +1, wall, ctx.openings.nz);
  buildWall(ctx, 'z', z1, x0, x1, h, -1, wall, ctx.openings.pz);
  buildWall(ctx, 'x', x0, z0, z1, h, +1, wall, ctx.openings.nx);
  buildWall(ctx, 'x', x1, z0, z1, h, -1, wall, ctx.openings.px);
  addWallRelief(ctx);
}

/**
 * Geometric wall relief so walls read as built structure, not wallpaper:
 * a raised skirting band at the floor, a mid-height conduit rail, pilaster
 * ribs at regular intervals — on ALL four walls, split around door/window
 * openings — plus transverse ceiling beams. Real silhouette the normal maps
 * can't fake. Decorative (no colliders — the flat wall collider already stops
 * the player short of them).
 * opts: { wallH: cap trim below this height, skipBeams }
 */
export function addWallRelief(ctx, opts = {}) {
  const { zone, atlas } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const h = Math.min(opts.wallH ?? zone.h, zone.h);
  const trim = atlas.layer(zone.tex.wall);

  const walls = [
    { plane: 'z', at: z0, a0: x0, a1: x1, dir: +1, openings: ctx.openings.nz },
    { plane: 'z', at: z1, a0: x0, a1: x1, dir: -1, openings: ctx.openings.pz },
    { plane: 'x', at: x0, a0: z0, a1: z1, dir: +1, openings: ctx.openings.nx },
    { plane: 'x', at: x1, a0: z0, a1: z1, dir: -1, openings: ctx.openings.px },
  ];
  for (const w of walls) reliefOnWall(ctx, trim, w, h);

  if (!opts.skipCornice) addCornice(ctx, trim, h);
  if (!opts.skipBeams) addCeilingBeams(ctx);
}

/**
 * A continuous trim box running the full top of every wall, overlapping the
 * wall↔ceiling seam. Belt-and-suspenders: even a hairline seam or an edge-on
 * lintel can't show void behind this. Runs the whole wall (above door height)
 * so no opening splits are needed.
 */
function addCornice(ctx, trim, h) {
  const { zone, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const y0 = h - 0.14, y1 = h + 0.001;
  const dp = 0.08; // proud of the wall, into the room
  const ao = [0.8, 0.8, 0.7, 0.7];
  // z walls (span x), x walls (span z) — overlap at corners is fine
  builder.box([x0, y0, z0], [x1, y1, z0 + dp], trim, { uvScale: 1, ao });
  builder.box([x0, y0, z1 - dp], [x1, y1, z1], trim, { uvScale: 1, ao });
  builder.box([x0, y0, z0], [x0 + dp, y1, z1], trim, { uvScale: 1, ao });
  builder.box([x1 - dp, y0, z0], [x1, y1, z1], trim, { uvScale: 1, ao });
}

/** Clear horizontal runs of a wall between its openings (with margin). */
export function clearRuns(a0, a1, openings, margin = 0.35) {
  const spans = (openings ?? [])
    .map((o) => [o.center - o.w / 2 - margin, o.center + o.w / 2 + margin])
    .sort((p, q) => p[0] - q[0]);
  const runs = [];
  let cursor = a0 + 0.06;
  for (const [lo, hi] of spans) {
    if (lo > cursor + 0.5) runs.push([cursor, lo]);
    cursor = Math.max(cursor, hi);
  }
  if (a1 - 0.06 > cursor + 0.5) runs.push([cursor, a1 - 0.06]);
  return runs;
}

function reliefOnWall(ctx, trim, w, h) {
  const { builder } = ctx;
  const skirtH = 0.16;
  const railY0 = Math.min(1.12, h * 0.45);
  const railH = 0.1;
  // relief box helper oriented to this wall: da = depth from the wall plane
  const strip = (r0, r1, y0, y1, depth, ao) => {
    const near = w.at, far = w.at + w.dir * depth;
    if (w.plane === 'z') {
      box3(builder, trim, r0, r1, y0, y1, Math.min(near, far), Math.max(near, far), ao);
    } else {
      box3(builder, trim, Math.min(near, far), Math.max(near, far), y0, y1, r0, r1, ao);
    }
  };
  for (const [r0, r1] of clearRuns(w.a0, w.a1, w.openings)) {
    strip(r0, r1, 0, skirtH, 0.07, [0.7, 0.7, 0.95, 0.95]); // skirting
    if (h > 1.7) strip(r0, r1, railY0, railY0 + railH, 0.05, [0.85, 0.85, 1.0, 1.0]); // conduit rail
    // pilaster ribs every ~2.2m within the run
    const len = r1 - r0;
    const ribs = Math.floor(len / 2.2);
    for (let i = 1; i <= ribs; i++) {
      const c = r0 + (len * i) / (ribs + 1);
      strip(c - 0.07, c + 0.07, skirtH, h - 0.06, 0.055, [0.6, 0.6, 0.85, 0.85]);
    }
  }
}

/** Transverse structural beams under the ceiling, every ~2.6m of length. */
function addCeilingBeams(ctx) {
  const { zone, atlas, builder } = ctx;
  const { x0, x1, z0, z1 } = zone.rect;
  const h = zone.h;
  if (h < 2.6) return; // low compartments: beams would graze a jumping head
  const layer = atlas.layer(zone.tex.ceil);
  const span = z1 - z0;
  const beams = Math.floor(span / 2.6);
  const ao = [0.75, 0.75, 0.85, 0.85];
  for (let i = 1; i <= beams; i++) {
    const zc = z0 + (span * i) / (beams + 1);
    box3(builder, layer, x0 + 0.05, x1 - 0.05, h - 0.14, h, zc - 0.09, zc + 0.09, ao);
  }
}

/** Axis-aligned relief box (5 inward faces; the face on the wall is omitted). */
function box3(builder, layer, x0, x1, y0, y1, z0, z1, ao) {
  const o = { uvScale: 1.0, ao };
  // top
  builder.quad([x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], layer, o);
  // bottom
  builder.quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], layer, o);
  // +z / -z ends
  builder.quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], layer, o);
  builder.quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], layer, o);
  // +x / -x faces (the outward one shows; the wall-side one is harmless)
  builder.quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], layer, o);
  builder.quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], layer, o);
}
