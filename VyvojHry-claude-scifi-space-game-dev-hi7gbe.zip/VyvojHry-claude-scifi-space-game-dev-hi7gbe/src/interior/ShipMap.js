/**
 * ShipMap — the HSV Aethon deck plan as data, plus the build orchestrator.
 *
 * Layout follows context/03 §2 exactly: thirteen rooms + airlock, fore→aft
 * along a spine, corridor types per context/02 §5 with type-E junction hubs
 * where side-by-side room pairs meet the spine. Spine sequence:
 * A, E, B, E, C, E, C, D, E, B(3.0 engine-bay variant) — never the same type
 * twice in a row.
 *
 * Coordinates: x = starboard(+)/port(-), z = fore(0)→aft(+), y = up.
 */
import { LIGHTING, DOOR } from '../core/Constants.js';
import { MeshBuilder } from '../rendering/MeshBuilder.js';
import { CollisionMap } from './CollisionMap.js';
import { buildRoomShell } from './Room.js';
import { buildCorridorShell } from './Corridor.js';
import { Door } from './props/Door.js';
import { SealedHatch } from './props/SealedHatch.js';
import { LightFixture } from './props/Light.js';
import { Vent } from './props/Vent.js';
import { Panel } from './props/Panel.js';
import { dressGreebles } from './Greebles.js';
import { shipFit } from '../data/ShipFit.js';
import { rayAabb } from '../utils/MathUtils.js';

import * as Cockpit from './rooms/Cockpit.js';
import * as CaptainQuarters from './rooms/CaptainQuarters.js';
import * as CrewBunks from './rooms/CrewBunks.js';
import * as MedBay from './rooms/MedBay.js';
import * as Kitchen from './rooms/Kitchen.js';
import * as Bathroom from './rooms/Bathroom.js';
import * as Storage from './rooms/Storage.js';
import * as ResearchLab from './rooms/ResearchLab.js';
import * as ComputerCore from './rooms/ComputerCore.js';
import * as CargoBay from './rooms/CargoBay.js';
import * as Airlock from './rooms/Airlock.js';
import * as Workshop from './rooms/Workshop.js';
import * as ReactorRoom from './rooms/ReactorRoom.js';
import * as EngineRoom from './rooms/EngineRoom.js';
import * as Magazine from './rooms/Magazine.js';
import * as AssayBay from './rooms/AssayBay.js';
import * as DispatchLocker from './rooms/DispatchLocker.js';

const ROOM_DRESSERS = {
  cockpit: Cockpit, capt_quarters: CaptainQuarters, crew_bunks: CrewBunks,
  med_bay: MedBay, galley: Kitchen, bathroom: Bathroom, storage: Storage,
  research_lab: ResearchLab, computer_core: ComputerCore, cargo_bay: CargoBay,
  airlock: Airlock, workshop: Workshop, reactor_room: ReactorRoom,
  engine_room: EngineRoom,
};

/**
 * Alternate dressings a hull class may fit in place of a compartment's own.
 *
 * Keyed by the `dress` name in data/ShipFit.js rather than by zone id, because
 * a refit is a THING A ROOM CAN BECOME, not a property of the room it replaces
 * — nothing stops a future class fitting the magazine into the research lab.
 */
const REFIT_DRESSERS = {
  magazine: Magazine, assay: AssayBay, dispatch: DispatchLocker,
};

const TEX_STD = { wall: 'wall_military', floor: 'floor_plate', ceil: 'ceiling_panel' };

/** Player spawn: beside your bunk, crew quarters, facing the door. */
export const SPAWN = { pos: [5.0, 0, 10.5], yaw: Math.PI / 2, pitch: 0 };

export const ZONES = [
  // -- rooms -------------------------------------------------------------------
  {
    id: 'cockpit', kind: 'room', name: 'COCKPIT', rect: { x0: -2.5, x1: 2.5, z0: 0, z1: 4.5 },
    h: 2.8, tex: TEX_STD, surface: 'metal',
    // The canopy: a real hole in the hull; space renders behind it. Was one
    // small square pane — now a WRAP-AROUND multi-pane greenhouse, which is
    // both the survey-ship silhouette and far more to look out of:
    //   · a tall centre pane (the pilot's forward view)
    //   · two shorter flanking panes, stepped down, so the front silhouette is
    //     a canopy profile rather than a plain rectangle
    // Mullions between panes come free: they're the wall left standing between
    // the holes, so the canopy reads as framed glass, not a hole.
    //
    // NOTE: side-wall (nx/px) quarter-lights were tried and left out for now —
    // NOT because anything is broken. The "cockpit leaks space sideways" I
    // chased was a TEST artifact: `__debug.teleport` lands the player on top of
    // the ceiling collider (y≈3.3 vs a 2.8 ceiling), i.e. outside the hull
    // looking in, so of course the sides showed space. A stashed baseline
    // rendered identically, confirming it predates the canopy work.
    // Re-adding side panes needs a probe that can actually stand on the deck
    // (walk in, or fix the teleport to resolve against the floor) — otherwise
    // there's no way to tell a correct pane from a broken one.
    windows: [
      { wall: 'nz', center: 0, w: 2.3, y0: 0.82, y1: 2.55 },
      { wall: 'nz', center: -1.62, w: 0.86, y0: 1.02, y1: 2.24 },
      { wall: 'nz', center: 1.62, w: 0.86, y0: 1.02, y1: 2.24 },
    ],
  },
  { id: 'capt_quarters', kind: 'room', name: 'CAPTAIN\'S QUARTERS', rect: { x0: -5.5, x1: -2.5, z0: 8, z1: 13 }, h: 2.8, tex: TEX_STD, surface: 'metal' },
  { id: 'crew_bunks', kind: 'room', name: 'CREW QUARTERS', rect: { x0: 2.5, x1: 7.5, z0: 8, z1: 13 }, h: 2.8, tex: { wall: 'wall_tile', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'med_bay', kind: 'room', name: 'MED BAY', rect: { x0: -6.5, x1: -2.5, z0: 15.5, z1: 19.5 }, h: 2.8, tex: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'galley', kind: 'room', name: 'GALLEY', rect: { x0: 2.5, x1: 7.5, z0: 15.5, z1: 19.5 }, h: 2.8, tex: { wall: 'wall_tile', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'bathroom', kind: 'room', name: 'WASHROOM', rect: { x0: -6.5, x1: -2.5, z0: 19.5, z1: 23.5 }, h: 2.8, tex: { wall: 'fixture_white', floor: 'floor_grate', ceil: 'ceiling_panel' }, surface: 'grating' },
  { id: 'storage', kind: 'room', name: 'STORAGE', rect: { x0: 2.5, x1: 6.5, z0: 19.5, z1: 23.5 }, h: 2.8, tex: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'research_lab', kind: 'room', name: 'RESEARCH LAB', rect: { x0: -6.5, x1: -2.5, z0: 25.5, z1: 30 }, h: 2.8, tex: { wall: 'wall_tile', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'computer_core', kind: 'room', name: 'COMPUTER CORE', rect: { x0: 2.5, x1: 6.5, z0: 25.5, z1: 30 }, h: 2.8, tex: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'cargo_bay', kind: 'room', name: 'CARGO BAY', rect: { x0: -7, x1: 7, z0: 33, z1: 53 }, h: 8, tex: { wall: 'wall_cargo', floor: 'floor_cargo', ceil: 'ceiling_panel' }, surface: 'grating' },
  { id: 'airlock', kind: 'room', name: 'AIRLOCK', rect: { x0: 7, x1: 10, z0: 41, z1: 44.5 }, h: 2.8, tex: { wall: 'wall_military', floor: 'floor_hazard', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'workshop', kind: 'room', name: 'WORKSHOP', rect: { x0: -7.5, x1: -2.5, z0: 56.5, z1: 62.5 }, h: 2.8, tex: { wall: 'wall_engine', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal' },
  { id: 'reactor_room', kind: 'room', name: 'REACTOR ROOM', rect: { x0: 2.5, x1: 9.5, z0: 56.5, z1: 62.5 }, h: 3.2, tex: { wall: 'wall_reactor', floor: 'floor_grate', ceil: 'ceiling_panel' }, surface: 'grating' },
  { id: 'engine_room', kind: 'room', name: 'ENGINE ROOM', rect: { x0: -6, x1: 6, z0: 64.5, z1: 72.5 }, h: 5, tex: { wall: 'wall_engine', floor: 'floor_grate', ceil: 'ceiling_pipes' }, surface: 'grating' },

  // -- corridors + junctions (context/02 §5) -------------------------------------
  {
    id: 'corr_a', kind: 'corridor', type: 'A', shape: 'arch', name: 'CORRIDOR A',
    rect: { x0: -1, x1: 1, z0: 4.5, z1: 8 }, h: 2.8, tex: TEX_STD, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.6, 6.25], fixture: { len: 0.6 } }],
  },
  {
    id: 'j1', kind: 'junction', type: 'E', shape: 'octagon', name: 'JUNCTION 1',
    rect: { x0: -2.5, x1: 2.5, z0: 8, z1: 13 }, h: 3.5, tex: TEX_STD, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.95, 10.5], fixture: { len: 1.2 } }],
  },
  {
    id: 'corr_b', kind: 'corridor', type: 'B', shape: 'flat', name: 'CORRIDOR B',
    rect: { x0: -1.25, x1: 1.25, z0: 13, z1: 16 }, h: 2.0,
    tex: { wall: 'wall_military', floor: 'floor_grate', ceil: 'ceiling_pipes' }, surface: 'grating',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 1.86, 14.5], flicker: 'occasional_cut', fixture: { len: 0.9 } }],
  },
  {
    id: 'j2', kind: 'junction', type: 'E', shape: 'octagon', name: 'JUNCTION 2',
    rect: { x0: -2.5, x1: 2.5, z0: 16, z1: 21 }, h: 3.5, tex: TEX_STD, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.95, 18.5], fixture: { len: 1.2 } }],
  },
  {
    id: 'corr_c1', kind: 'corridor', type: 'C', shape: 'buttress', name: 'CORRIDOR C',
    rect: { x0: -2, x1: 2, z0: 21, z1: 25 }, h: 3.5,
    tex: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 3.0, 23], fixture: { len: 1.2 } }],
  },
  {
    id: 'j3', kind: 'junction', type: 'E', shape: 'octagon', name: 'JUNCTION 3',
    rect: { x0: -2.5, x1: 2.5, z0: 25, z1: 30 }, h: 3.5, tex: TEX_STD, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.95, 27.5], fixture: { len: 1.2 } }],
  },
  {
    id: 'corr_c2', kind: 'corridor', type: 'C', shape: 'buttress', name: 'CORRIDOR C',
    rect: { x0: -2, x1: 2, z0: 30, z1: 33 }, h: 3.5,
    tex: { wall: 'wall_steel', floor: 'floor_plate', ceil: 'ceiling_panel' }, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 3.0, 31.5], flicker: 'slow_pulse', fixture: { len: 1.2 } }],
  },
  {
    id: 'corr_d', kind: 'corridor', type: 'D', shape: 'hex', name: 'MAINTENANCE WAY',
    rect: { x0: -0.6, x1: 0.6, z0: 53, z1: 56.5 }, h: 1.8,
    tex: { wall: 'wall_engine', floor: 'floor_grate', ceil: 'ceiling_pipes' }, surface: 'grating',
    lights: [{ type: 'EMERGENCY', pos: [0, 1.66, 54.75], flicker: 'slow_pulse', fixture: { len: 0.5, lens: 'light_tube_red' } }],
  },
  {
    id: 'j4', kind: 'junction', type: 'E', shape: 'octagon', name: 'JUNCTION 4',
    rect: { x0: -2.5, x1: 2.5, z0: 56.5, z1: 61.5 }, h: 3.5, tex: TEX_STD, surface: 'metal',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.95, 59], flicker: 'occasional_cut', fixture: { len: 1.2 } }],
  },
  {
    id: 'corr_e', kind: 'corridor', type: 'B', shape: 'flat', name: 'ENGINE BAY ACCESS',
    // deck plan calls for a 3.0W engine-bay connector — type-B geometry, width override
    rect: { x0: -1.5, x1: 1.5, z0: 61.5, z1: 64.5 }, h: 2.2,
    tex: { wall: 'wall_engine', floor: 'floor_grate', ceil: 'ceiling_pipes' }, surface: 'grating',
    lights: [{ type: 'CEILING_TUBE', pos: [0, 2.06, 63], fixture: { len: 0.9 } }],
  },
];

// Doors and open portals between zones. `a` owns the frame geometry.
export const CONNECTIONS = [
  { id: 'd_cockpit', kind: 'door', a: 'cockpit', b: 'corr_a', plane: 'z', at: 4.5, center: 0 },
  { id: 'p_a_j1', kind: 'portal', a: 'corr_a', b: 'j1', plane: 'z', at: 8, center: 0, w: 2.0, h: 2.4 },
  { id: 'd_capt', kind: 'door', a: 'j1', b: 'capt_quarters', plane: 'x', at: -2.5, center: 10.5 },
  { id: 'd_bunks', kind: 'door', a: 'j1', b: 'crew_bunks', plane: 'x', at: 2.5, center: 10.5 },
  { id: 'p_j1_b', kind: 'portal', a: 'j1', b: 'corr_b', plane: 'z', at: 13, center: 0, w: 2.5, h: 2.0 },
  { id: 'p_b_j2', kind: 'portal', a: 'corr_b', b: 'j2', plane: 'z', at: 16, center: 0, w: 2.5, h: 2.0 },
  { id: 'd_med', kind: 'door', a: 'j2', b: 'med_bay', plane: 'x', at: -2.5, center: 17.5 },
  { id: 'd_galley', kind: 'door', a: 'j2', b: 'galley', plane: 'x', at: 2.5, center: 17.5 },
  { id: 'd_bath', kind: 'door', a: 'j2', b: 'bathroom', plane: 'x', at: -2.5, center: 20.2 },
  { id: 'd_storage', kind: 'door', a: 'j2', b: 'storage', plane: 'x', at: 2.5, center: 20.2 },
  { id: 'p_j2_c1', kind: 'portal', a: 'j2', b: 'corr_c1', plane: 'z', at: 21, center: 0, w: 3.2, h: 3.0 },
  { id: 'p_c1_j3', kind: 'portal', a: 'corr_c1', b: 'j3', plane: 'z', at: 25, center: 0, w: 3.2, h: 3.0 },
  { id: 'd_lab', kind: 'door', a: 'j3', b: 'research_lab', plane: 'x', at: -2.5, center: 27.5 },
  { id: 'd_core', kind: 'door', a: 'j3', b: 'computer_core', plane: 'x', at: 2.5, center: 27.5 },
  { id: 'p_j3_c2', kind: 'portal', a: 'j3', b: 'corr_c2', plane: 'z', at: 30, center: 0, w: 3.2, h: 3.0 },
  { id: 'd_cargo_fore', kind: 'door', a: 'corr_c2', b: 'cargo_bay', plane: 'z', at: 33, center: 0, w: 2.4, h: 2.6 },
  { id: 'd_airlock', kind: 'door', a: 'cargo_bay', b: 'airlock', plane: 'x', at: 7, center: 42.75 },
  { id: 'd_cargo_aft', kind: 'door', a: 'cargo_bay', b: 'corr_d', plane: 'z', at: 53, center: 0, w: 1.0, h: 1.7 },
  { id: 'p_d_j4', kind: 'portal', a: 'corr_d', b: 'j4', plane: 'z', at: 56.5, center: 0, w: 1.0, h: 1.7 },
  { id: 'd_workshop', kind: 'door', a: 'j4', b: 'workshop', plane: 'x', at: -2.5, center: 58.5 },
  { id: 'd_reactor', kind: 'door', a: 'j4', b: 'reactor_room', plane: 'x', at: 2.5, center: 58.5 },
  { id: 'p_j4_e', kind: 'portal', a: 'j4', b: 'corr_e', plane: 'z', at: 61.5, center: 0, w: 2.4, h: 2.1 },
  { id: 'd_engine', kind: 'door', a: 'corr_e', b: 'engine_room', plane: 'z', at: 64.5, center: 0, w: 1.4 },
];

/**
 * Compartments a hull class may omit, and the proof that omitting them is safe.
 *
 * Every id here is a LEAF on the deck graph: it hangs off a junction by exactly
 * one door and nothing routes through it. Drop the zone and its door and the
 * spine — cockpit, corridors A-E, the four junctions, cargo bay, airlock,
 * engine room — is bit-for-bit what it was. That is why a class may cut rooms
 * but may NOT cut the corridor run: re-stitching the spine means recomputing
 * every `at`/`center` in CONNECTIONS, and the geometry audits of sessions 16f
 * and 16x are a standing record of how that goes.
 */
const LEAF_ZONES = new Set(['capt_quarters', 'med_bay', 'galley',
  'bathroom', 'storage', 'research_lab', 'computer_core', 'workshop',
  'reactor_room']);
// `crew_bunks` is a leaf too and is deliberately NOT in that set: SPAWN sits at
// [5.0, 0, 10.5], which is inside it. A hull that dropped it would start the
// player embedded in the bulkhead.

/**
 * THE SHIP'S OWN DECK, as a plan object.
 *
 * `ShipMap` used to read the module tables above directly, which was fine while
 * there was exactly one deck in the game. There are now two — the Aethon and a
 * station concourse (data/StationPlan.js) — and they want the identical
 * builder: the same room shells, corridor shells, door frames, greeble pass,
 * collision map and interact raycast. Everything that differs between them is
 * DATA, so it lives in a plan and the builder takes one.
 *
 * Nothing about the ship's geometry changed to do this; the tables moved behind
 * a default argument. That mattered: the deck graph is the thing three sessions
 * of geometry audits stabilised and it is the last thing that should be
 * rewritten to add a feature somewhere else.
 */
export const SHIP_PLAN = {
  zones: ZONES,
  connections: CONNECTIONS,
  dressers: ROOM_DRESSERS,
  spawn: SPAWN,
  /**
   * Compartments a hull class may omit.
   *
   * Set HERE, in the literal, and not by a later assignment. The first version
   * wrote `SHIP_PLAN.leaves = LEAF_ZONES` from inside the LEAF_ZONES comment
   * block seventeen lines ABOVE this declaration — a temporal dead zone
   * reference that threw at module evaluation, which meant the module never
   * finished loading and the game never booted at all. `node --check` cannot
   * see it because it is a runtime ordering fault, not a syntax one.
   */
  leaves: LEAF_ZONES,
};

export class ShipMap {
  /**
   * @param {import('../core/EventBus.js').EventBus} events
   * @param {string[]} [drop] compartment ids this hull class does not have
   *   (see data/ShipClasses.js). Non-leaf ids are ignored rather than trusted —
   *   a typo in a class table must not be able to sever the deck.
   * @param {string} [classId]
   * @param {object} [plan] which deck to build; defaults to the ship's own
   */
  constructor(events, drop = [], classId = 'aethon', plan = SHIP_PLAN) {
    this.plan = plan;
    this.events = events;
    this.collision = new CollisionMap();
    /** @type {Array<{min:number[],max:number[],label:string|Function,onInteract:Function}>} */
    this.interactables = [];
    /** @type {Door[]} */
    this.doors = [];
    const cut = new Set((drop ?? []).filter((id) => (this.plan.leaves ?? LEAF_ZONES).has(id)));
    this.cutZones = cut;
    this.fit = shipFit(classId);
    /** Which hull class the deck currently standing is. See `reconfigure`. */
    this.builtAs = classId;
    this.zones = this.plan.zones.filter((z) => !cut.has(z.id)).map((z) => this._fitted(z));
    this.zoneById = new Map(this.zones.map((z) => [z.id, z]));
    this._lastZone = null;
    /**
     * Connections whose far end still exists. A door onto a compartment this
     * hull does not have would otherwise open onto the void — literally, since
     * `_openingsFor` cuts a hole in the bulkhead for every connection on that
     * wall regardless of whether anything is behind it.
     */
    this.connections = this.plan.connections.filter((c) => !cut.has(c.a) && !cut.has(c.b));

    // adjacency from connections
    for (const c of this.connections) {
      this.zoneById.get(c.a).neighbours.push(c.b);
      this.zoneById.get(c.b).neighbours.push(c.a);
    }
  }

  /**
   * Rebuild the deck for a different hull class.
   *
   * The commission screen runs long after the interior is built — the boot
   * order is fixed by the save restore, which needs collision to depenetrate the
   * player before anything is drawn — so the chosen hull cannot be known at
   * construction time. Rather than restructure boot (and risk the geometry the
   * last three sessions were spent auditing), the deck is simply built twice on
   * a fresh commission: once as the default cutter, once as whatever was picked.
   * It happens before `engine.start()`, so nothing has moved yet.
   *
   * Everything the first build allocated is released first: zone meshes through
   * the renderer, lights out of the LightSystem's zone map (and its lazy flat
   * cache, which would otherwise still hold the dead ones), and the collision
   * map, interactables and doors wholesale.
   */
  reconfigure(drop, ctx, classId = 'aethon') {
    for (const z of this.zones) if (z.mesh) ctx.renderer.deleteMesh?.(z.mesh);
    ctx.lights.zoneLights.clear();
    ctx.lights._flat = null;
    this.collision = new CollisionMap();
    this.interactables = [];
    this.doors = [];
    const cut = new Set((drop ?? []).filter((id) => (this.plan.leaves ?? LEAF_ZONES).has(id)));
    this.cutZones = cut;
    this.fit = shipFit(classId);
    this.builtAs = classId;
    this.zones = this.plan.zones.filter((z) => !cut.has(z.id)).map((z) => this._fitted(z));
    this.zoneById = new Map(this.zones.map((z) => [z.id, z]));
    this.connections = this.plan.connections.filter((c) => !cut.has(c.a) && !cut.has(c.b));
    for (const c of this.connections) {
      this.zoneById.get(c.a).neighbours.push(c.b);
      this.zoneById.get(c.b).neighbours.push(c.a);
    }
    this._lastZone = null;
    this.build(ctx);
  }

  /**
   * A zone with this hull's fit applied: finish, name and refit dresser.
   *
   * Returns a COPY every time — `ZONES` is a module-level table shared by every
   * ShipMap that will ever exist, and a fit written into it would follow the
   * player from a Harrier into an Aethon on the next commission. The bug this
   * prevents has no symptom until you reconfigure, which is exactly the kind
   * that gets shipped.
   */
  _fitted(z) {
    const fin = this.fit?.finish;
    const tex = fin?.[z.id] ?? (z.kind === 'room' ? null : fin?.default) ?? z.tex;
    const refit = this.fit?.refit?.[z.id];
    return {
      ...z,
      tex,
      name: refit?.name ?? z.name,
      refit: refit?.dress ?? null,
      mesh: null,
      neighbours: [],
    };
  }

  addInteractable(rec) {
    this.interactables.push(rec);
    return rec;
  }

  /** Openings on one zone wall, derived from CONNECTIONS. */
  _openingsFor(zone, wall) {
    const { x0, x1, z0, z1 } = zone.rect;
    const plane = wall === 'nz' || wall === 'pz' ? 'z' : 'x';
    const at = wall === 'nz' ? z0 : wall === 'pz' ? z1 : wall === 'nx' ? x0 : x1;
    const span = plane === 'z' ? [x0, x1] : [z0, z1];
    const out = [];
    for (const c of this.connections) {
      if (c.plane !== plane || Math.abs(c.at - at) > 1e-3) continue;
      if ((c.a !== zone.id && c.b !== zone.id)) continue;
      if (c.center < span[0] || c.center > span[1]) continue;
      out.push({
        center: c.center,
        w: c.w ?? DOOR.WIDTH,
        h: c.h ?? DOOR.HEIGHT,
        spec: c,
        owner: c.a === zone.id,
      });
    }
    // hull windows declared on the zone itself (frames come from Window props)
    for (const win of zone.windows ?? []) {
      if (win.wall !== wall) continue;
      out.push({ center: win.center, w: win.w, h: win.y1, y0: win.y0, window: true });
    }
    return out;
  }

  /**
   * Build all geometry, colliders, props, lights and doors.
   * @param {object} deps {atlas, lights, renderer, game}
   */
  build(deps) {
    const { atlas, lights, renderer } = deps;

    for (const zone of this.zones) {
      const builder = new MeshBuilder();
      const ctx = {
        zone, builder, atlas, lights, shipMap: this,
        openings: {
          nz: this._openingsFor(zone, 'nz'),
          pz: this._openingsFor(zone, 'pz'),
          nx: this._openingsFor(zone, 'nx'),
          px: this._openingsFor(zone, 'px'),
        },
      };

      if (zone.kind === 'room') buildRoomShell(ctx);
      else buildCorridorShell(ctx);

      // door/portal frames — built once, by the owning zone. The filler above
      // the opening rises to the taller of the two adjoining ceilings so there
      // is never a see-through gap between doorway and roof.
      for (const wall of ['nz', 'pz', 'nx', 'px']) {
        for (const op of ctx.openings[wall]) {
          if (!op.owner) continue;
          const other = op.spec && (op.spec.a === zone.id ? op.spec.b : op.spec.a);
          const otherH = other ? (this.zoneById.get(other)?.h ?? zone.h) : zone.h;
          this._buildFrame(builder, atlas, op, Math.max(zone.h, otherH));
        }
      }

      // dressing — a class refit replaces the compartment's own dresser rather
      // than adding to it, because a magazine and a stores room want the same
      // floor space and stacking both would put ordnance through the shelving.
      const dresser = (zone.refit && REFIT_DRESSERS[zone.refit]) || this.plan.dressers[zone.id];
      if (dresser) dresser.dress(ctx);
      this._dressCorridor(ctx);
      // Refit scars BEFORE the greebles, so the greeble pass sees the plated
      // doorway as occupied wall and does not stack a junction box on top of it.
      this._sealCutDoorways(ctx);
      dressGreebles(ctx); // decorative density on the free wall runs

      const data = builder.finish();
      zone.mesh = renderer.createInteriorMesh(data.vertexData, data.indexData);
    }

    // doors + their status lamps. `this.connections`, not CONNECTIONS: a door
    // onto a compartment this hull does not have would be a working door in a
    // solid bulkhead.
    for (const c of this.connections) {
      if (c.kind !== 'door') continue;
      this.doors.push(new Door(c, this, atlas, renderer, this.events));
    }
  }

  /**
   * Plate over every doorway whose compartment this hull does not carry.
   *
   * Without this a smaller hull is a junction with a blank wall exactly where
   * the symmetry says a door belongs, which reads as missing content rather
   * than as a ship that was cut down. See props/SealedHatch.
   *
   * Only DOORS are sealed, never portals: portals are the corridor spine and
   * `LEAF_ZONES` cannot contain either end of one, so a cut portal is by
   * construction impossible and finding one would be a bug worth crashing on
   * rather than papering over.
   */
  _sealCutDoorways(ctx) {
    if (!this.cutZones?.size) return;
    const live = ctx.zone;
    for (const c of this.plan.connections) {
      if (c.kind !== 'door') continue;
      const aGone = this.cutZones.has(c.a);
      const bGone = this.cutZones.has(c.b);
      if (aGone === bGone) continue;   // both kept, or both gone: nothing to face
      if ((aGone ? c.b : c.a) !== live.id) continue; // not this zone's wall
      const { x0, x1, z0, z1 } = live.rect;
      // Face the plate INTO the surviving compartment: the scar is only ever
      // seen from the inhabited side, so it points at whichever side of the
      // wall plane that compartment's centre is on.
      let x, z, facing;
      if (c.plane === 'x') {
        x = c.at; z = c.center;
        facing = (x0 + x1) / 2 < c.at ? 'W' : 'E';
      } else {
        x = c.center; z = c.at;
        facing = (z0 + z1) / 2 < c.at ? 'N' : 'S';
      }
      const label = this.plan.zones.find((zz) => zz.id === (aGone ? c.a : c.b))?.name ?? 'COMPARTMENT';
      new SealedHatch(ctx, x, z, facing, { w: DOOR.WIDTH, h: DOOR.HEIGHT, label });
    }
  }

  /** Corridor/junction chrome: light fixtures + declared lights, small greebles. */
  _dressCorridor(ctx) {
    const { zone, lights } = ctx;
    if (!zone.lights) return;
    for (const spec of zone.lights) {
      const def = LIGHTING.TYPES[spec.type];
      lights.add(zone.id, def, spec.pos, spec.flicker ?? 'none');
      // fixture housing sits at the ceiling; the light point may hang lower
      if (spec.fixture) {
        new LightFixture(ctx, spec.pos[0], spec.pos[2], 'N', spec.fixture);
      }
    }
    if (zone.kind === 'junction') {
      const { x1, z0, z1 } = zone.rect;
      const cz = (z0 + z1) / 2;
      new Vent(ctx, x1 - 1.9, z0 + 0.06, 'S', { w: 0.7, h: 0.45, y: 0.18 });
      if (zone.id === 'j2' || zone.id === 'j4') {
        new Panel(ctx, x1 - 0.06, cz + 1.6, 'W', { w: 0.9, h: 0.9, y: 0.85 });
      }
    }
  }

  _buildFrame(builder, atlas, op, fillTop) {
    const { spec } = op;
    const layer = atlas.layer('door_frame');
    const wallLayer = atlas.layer('wall_military');
    const lampLayer = atlas.layer('door_lamp');
    const t = 0.12; // frame post width
    const d = 0.12; // depth each side of the plane (real thickness — never edge-on)
    const lo = op.center - op.w / 2;
    const hi = op.center + op.w / 2;
    const h = op.h;
    const top = fillTop ?? (h + 0.6); // seal all the way to the taller ceiling
    const lw = 0.34, lh = 0.08, ly = h + 0.015; // status lamp
    if (spec.plane === 'z') {
      builder.box([lo - t, 0, spec.at - d], [lo, top, spec.at + d], layer, { uvScale: 1 });
      builder.box([hi, 0, spec.at - d], [hi + t, top, spec.at + d], layer, { uvScale: 1 });
      // SOLID lintel filler above the opening (was a thin plane that vanished
      // edge-on and showed the void) — real depth d, up to the ceiling
      builder.box([lo, h, spec.at - d], [hi, top, spec.at + d],
        { all: wallLayer, ny: layer, pz: layer, nz: layer }, { uvScale: 1 });
      builder.box([op.center - lw / 2, ly, spec.at - d - 0.01], [op.center + lw / 2, ly + lh, spec.at + d + 0.01],
        { all: layer, pz: lampLayer, nz: lampLayer }, { uvScale: 1 / lw, emissive: { pz: 1, nz: 1 } });
    } else {
      builder.box([spec.at - d, 0, lo - t], [spec.at + d, top, lo], layer, { uvScale: 1 });
      builder.box([spec.at - d, 0, hi], [spec.at + d, top, hi + t], layer, { uvScale: 1 });
      builder.box([spec.at - d, h, lo], [spec.at + d, top, hi],
        { all: wallLayer, ny: layer, px: layer, nx: layer }, { uvScale: 1 });
      builder.box([spec.at - d - 0.01, ly, op.center - lw / 2], [spec.at + d + 0.01, ly + lh, op.center + lw / 2],
        { all: layer, px: lampLayer, nx: lampLayer }, { uvScale: 1 / lw, emissive: { px: 1, nx: 1 } });
    }
  }

  update(dt) {
    for (const door of this.doors) door.update(dt);
  }

  /** Zone containing a world point (cached for the common same-zone case). */
  zoneAt(x, z) {
    const last = this._lastZone;
    if (last && x >= last.rect.x0 && x <= last.rect.x1 && z >= last.rect.z0 && z <= last.rect.z1) {
      return last;
    }
    for (const zone of this.zones) {
      const r = zone.rect;
      if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) {
        this._lastZone = zone;
        return zone;
      }
    }
    return null;
  }

  /**
   * Nearest interactable hit by a ray. Volumes the player is standing INSIDE
   * (doorways especially) only count when the view direction actually points
   * at their center — otherwise the doorway would swallow every E press made
   * near it.
   * @returns {{rec: object, dist: number}|null}
   */
  raycastInteract(origin, dir, maxDist) {
    let best = null;
    let bestDist = maxDist;
    for (const rec of this.interactables) {
      let d = rayAabb(origin[0], origin[1], origin[2], dir[0], dir[1], dir[2], rec.min, rec.max);
      if (d === Infinity) continue;
      if (d <= 1e-6) {
        const tx = (rec.min[0] + rec.max[0]) / 2 - origin[0];
        const ty = (rec.min[1] + rec.max[1]) / 2 - origin[1];
        const tz = (rec.min[2] + rec.max[2]) / 2 - origin[2];
        const len = Math.hypot(tx, ty, tz) || 1;
        const facing = (dir[0] * tx + dir[1] * ty + dir[2] * tz) / len;
        if (facing < 0.35) continue;
        d = len;
      }
      if (d < bestDist) {
        bestDist = d;
        best = rec;
      }
    }
    return best ? { rec: best, dist: bestDist } : null;
  }
}
