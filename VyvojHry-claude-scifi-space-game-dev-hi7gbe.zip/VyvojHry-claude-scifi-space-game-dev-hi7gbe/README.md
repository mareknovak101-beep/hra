# STARRIFT

A first-person, retro pixel-art (16-bit), sci-fi survival-exploration game.
You are the only crew member left aboard the **HSV Aethon**, a Kestrel
Extraction & Salvage Co. heavy survey vessel rated for six.

*Alien* (1979) mood, rebuilt as hard-edged pixel art: worn analog machinery,
oppressive shadow, a ship that feels used and a little too empty.

Built with **vanilla JavaScript + WebGL2, zero libraries, zero asset files** —
every texture, sound and letterform is generated procedurally at startup.

## Run it

The game is pure static files, but ES modules need an HTTP origin:

```bash
# from the repository root — any static server works
python3 -m http.server 8000
# then open http://localhost:8000
```

No build step. No dependencies. Refresh to play the latest code.

**Play the latest build online:** once GitHub Pages is enabled (Settings →
Pages → Source: *GitHub Actions*), every push to `main` auto-publishes to a
stable URL — `https://<owner>.github.io/VyvojHry/`. That URL always serves the
newest build with the correct offline service worker, so it's the recommended
way to test on a phone (no ephemeral preview URLs, no stale caches).

A small `BUILD x.y.z` stamp in the bottom-right corner shows exactly which
build you're running — if it looks out of date, hard-refresh once.

## Controls

| Input | On foot | In the pilot seat |
|---|---|---|
| Mouse | Look (pointer lock — click to board) | Steer the ship (pitch/yaw) |
| `W` / `S` | Move | Main thrust / retro |
| `A` / `D` | Strafe | Roll |
| `Shift` | Sprint | Boost |
| `Space` | Jump | Flight-assist brake |
| `C` / `Ctrl` | Crouch (hold) | — |
| `E` | Interact (doors, terminals, the pilot seat) | Stand up |
| `F` | Helmet lamp | Helmet lamp |
| `V` | — | Toggle cockpit / external hull cam |
| Right mouse (hold) | — | Orbit the hull cam instead of steering |
| `T` | — | Cycle the target lock (it auto-acquires on its own) |
| `C` | Crouch | Cycle weapon hardpoint |
| `H` | — | Weld a hull plate onto the worst-damaged section |
| `J` / `I` / `L` | — / Hold / Journal | Warp chart / Hold / Journal |
| `Esc` / `P` | Settings | Settings |
| `` ` `` | Debug overlay (FPS, draw calls, zone) | same |

Flight is Newtonian: cut thrust and you coast; brake or fly the retro burn.
On foot the camera never leaves your head. In the pilot seat the default view
is first-person through the windshield; press `V` (or the touch VIEW button)
to pull out to an external chase camera that shows the whole ship, and again
to return. **Steering works the same in both views** — hold right mouse (or the
touch ORBIT button) if you want to swing the hull cam around the ship instead.
Open **Settings** (from MENU, the pause screen, or Esc/P) to tune look and flight
sensitivity, brightness, volume, FOV and invert-Y.

The upper-right instrument is a **tactical radar**: nose-up, bearings relative to
the hull, radius is range. A contact above your plane draws as an up-chevron,
below as a down-chevron, level as a solid block; the locked target gets a bracket
and the four nearest worlds plot dim so an empty system still tells you where you
are.

**Controls adapt to the device automatically.** Desktop gets keyboard + mouse
(pointer lock); the first touch anywhere switches to on-screen controls — no
setting, no reload.

Touch layout: left half = move stick, right half = look stick. Piloting adds a
fixed **TURN stick** in the right gutter (a rate control — hold it over and the
ship holds a steady turn, in either view), with REPAIR and FIRE below it, throttle
in the left gutter, and a tap row along the bottom for WARP · SCAN · LOCK · WPN.
Mode toggles (A/S, VIEW, ORBIT, STAND) run down from the top-right corner under
MENU; BAG/LOG is one chip in the top-left that cycles hold → journal → closed.

## Current state — Session 2

Phases 1–3 of the [roadmap](context/07-ROADMAP-AND-WORKFLOW.md) are in.

New in Session 2 (Phase 3 — First-Person Flight):

- The cockpit windshield is a real hole in the hull with live space behind it:
  1400-star sky, dithered nebulae, a granulated G-type sun, and two planets
  (oceanic Aethon, rocky Cinder) with Bayer-quantized terminators
- Sit in the pilot seat (`E`) and the same first-person camera lerps into the
  seated eye — no pull-back, ever. Mouse steers the ship; the universe moves
  around the fixed interior. Newtonian flight with boost and assist braking
- Flight HUD: glass reticle + SPD/THR strip; engine rumble follows thrust;
  velocity dust streams past the glass; a Kestrel freighter works the lane
- Mobile touch controls (dual floating joysticks + button strip)

From Session 1 (Phases 1–2):

- 480×270 WebGL2 pixel pipeline (nearest-neighbor upscale, no antialiasing)
- ~42 procedural textures — 4×4 Bayer ordered dithering, per-material dither
  language, downward rust streaks, Kestrel stencils
- Two runtime-generated bitmap fonts (AMBER-9 HUD face, TERM-MONO-7 terminals)
- The full 13-room + airlock deck plan, all five corridor types (barrel arch,
  low industrial, wide bay, maintenance hex, octagonal junctions), sliding
  bulkhead doors, ~78 interactable props
- Dither-quantized dynamic lighting with flicker patterns, helmet spotlight
- First-person controller: AABB collision, crouch/sprint/jump, head bob
- Amber helmet HUD (compass, vitals, interact prompts) + helmet-glass overlay
- Procedural ambience: reactor hum, HVAC, distant clanks, surface-aware
  footsteps, door hiss, the save-terminal "chunk"

Flight (Phase 3) is next: the pilot seat is installed, the windshield shows
Sol Prime, and the camera will stay first-person in the seat — see the camera
rule in [CLAUDE.md](CLAUDE.md).

## Documentation map

Design truth lives in `context/`:

| Doc | Covers |
|---|---|
| [`context/01-ART-DIRECTION.md`](context/01-ART-DIRECTION.md) | palette, dithering, materials, typography |
| [`context/02-TECHNICAL-ARCHITECTURE.md`](context/02-TECHNICAL-ARCHITECTURE.md) | engine, shaders, camera rule, file layout |
| [`context/03-WORLD-SHIP-AND-LORE.md`](context/03-WORLD-SHIP-AND-LORE.md) | the Aethon, star systems, factions, the Hollow |
| [`context/04-GAMEPLAY-SYSTEMS.md`](context/04-GAMEPLAY-SYSTEMS.md) | survival stats, scanner, hiding, hacking, saves |
| [`context/05-UI-HUD-AND-MENUS.md`](context/05-UI-HUD-AND-MENUS.md) | HUD layout, menus, terminal chrome |
| [`context/06-AUDIO-DESIGN.md`](context/06-AUDIO-DESIGN.md) | synthesis recipes, mixing philosophy |
| [`context/07-ROADMAP-AND-WORKFLOW.md`](context/07-ROADMAP-AND-WORKFLOW.md) | phase roadmap, quality checklist |
| [`context/SESSION_LOG.md`](context/SESSION_LOG.md) | per-session record of what shipped |

Read `CLAUDE.md` first — it carries the four pillars and the absolute bans.
