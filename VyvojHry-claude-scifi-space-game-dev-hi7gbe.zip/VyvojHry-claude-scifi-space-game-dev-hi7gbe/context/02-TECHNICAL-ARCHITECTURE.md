# 02 — Technical Architecture

## 1. Rendering engine

WebGL2, true 3D polygon geometry. No raycaster, no canvas 2D fallback.

```
Base resolution:      480 × 270 (16:9)
Upscale method:        CSS image-rendering: pixelated + nearest-neighbor
Target framerate:      60fps desktop / 30fps mobile
WebGL version:         WebGL2 (GLSL ES 3.0)
Pixel format:          RGBA8 (no HDR)
Shadow maps:           512×512 per dynamic light (max 4 dynamic), 256×256 on mobile
Max draw calls/frame:  200 interior / 100 space
```

## 2. Technology stack

```
Language:       Vanilla JavaScript ES2022 (ES modules)
Rendering:      WebGL2 + custom GLSL ES 3.0 shaders
Physics:        Custom AABB + sphere collision (no library)
Audio:          Web Audio API (procedural synthesis, no audio files)
Persistence:    localStorage (save/load) — revisit IndexedDB if save size grows past ~5MB
Entry point:    index.html (no build tools, runs directly)
Module loading: <script type="module"> imports
External libs:  NONE — fully self-contained
```

## 3. Camera system — read this before touching `PlayerCamera.js` or anything in `ship/`

This version merges what the v2 prompt called `FlightCamera.js` into `PlayerCamera.js`. There is one camera system, and it never leaves the player character's head:

- **Walking:** standard first-person camera, eye height 1.6 units, subtle head bob (amplitude 0.04, frequency 1.8Hz while walking).
- **Piloting:** walk to the Cockpit, interact with the pilot seat. The camera does **not** pull back or reveal the ship — it lerps smoothly (~0.5s) into the seated eye position, and gameplay continues in first person looking out the windshield / at the console. HUD swaps to flight instrumentation (rendered as the ship's own console screens plus a minimal reticle on the glass, not the walking-mode helmet HUD wholesale).
- **Anything that shows the ship from outside** — other ships passing the window, a docking approach, the warp sequence, a schematic viewer on a Computer Core screen, the main menu backdrop — is either something the player is legitimately looking *at* through glass/a window, or a non-interactive scripted moment. It is never a camera the player freely orbits around their own ship mid-play.

```js
// Seat transition — stays first person throughout
function enterPilotSeat(player, seat) {
  player.controller.lockMovement();
  camera.lerpTo(seat.eyePosition, seat.eyeRotation, 0.5 /* seconds */);
  hud.transitionTo('flight');
  // no camera pull-back, no exterior ship reveal — contrast with the v2 prompt's
  // "camera pulls back over 1.5s until entire ship visible," which this version removes
}
```

`ShipExterior.js` still exists and still needs a full pixel-art hull model — it's just rendered for *other* ships, station approaches, and cinematics, never for the player's own ship during live control.

## 4. Shader uniform contract

All shaders in GLSL ES 3.0. Key uniforms passed per-draw:

- `u_viewProjection` : mat4 — combined view+projection matrix
- `u_model` : mat4 — object-to-world transform
- `u_time` : float — elapsed seconds (animation)
- `u_lightPositions[8]` / `u_lightColors[8]` / `u_lightIntensities[8]` — up to 8 point lights per draw
- `u_pixelSize` : float — logical pixel size for dithering math
- `u_playerLightPos` / `u_playerLightDir` : vec3 — helmet flashlight

Surface sampling uses a 4-channel convention — reuse this for every interior material:

```glsl
// Channel 0 (RGB): base material texture
// Channel 1 (RGB): wear/rust/grime overlay
// Channel 2 (RGB): detail decals (serials, labels)
// Channel 3 (A):   damage mask (blends the wear channel in)
vec3 base   = texture(u_baseTexture, uv * u_tile).rgb;
vec3 wear   = texture(u_wearTexture, uv * u_tile).rgb;
vec3 detail = texture(u_detailTexture, uv).rgb;
float dmask = texture(u_damageMask, uv).a;
vec3 surface = mix(base, wear, dmask) * detail;
```

Diegetic CRT screens (Computer Core, consoles) get their own small shader pass distinct from `PostProcess.js`: scanline dither, boot-in flicker, and the terminal-phosphor-green clamp from `context/01` §2 — this keeps "screen glow" visually and technically separate from the full-frame CRT post effect used on the player's own view.

## 5. Corridor types — never the same type twice in a row

| Type | Shape | Width | Height | Usage |
|---|---|---|---|---|
| A — Barrel Arch | Vaulted arch ceiling | 2.0 | 2.8 apex | Main crew corridors |
| B — Low Industrial | Flat ceiling, pipe-covered | 2.5 | 2.0 | Engine/maintenance access |
| C — Wide Bay | Flat ceiling, buttressed walls | 4.0 | 3.5 | Cargo access routes |
| D — Maintenance | Hexagonal cross-section | 1.2 | 1.8 | Tight access passages |
| E — Junction | Octagonal hub | 5.0⌀ | 3.5 | Room connection nodes |

Full room-by-room connection diagram is in `context/03`.

## 6. Lighting system

```js
// CEILING_TUBE — fluorescent fixture
{ type: 'tube', color: [0.9, 0.75, 0.45], intensity: 0.7, radius: 4.0,
  flickerType: 'none'|'slow_pulse'|'rapid'|'occasional_cut', flickerRate: 0.3 }

// EMERGENCY — backup light
{ type: 'point', color: [0.6, 0.1, 0.1], intensity: 0.3, radius: 2.0, flickerType: 'slow_pulse' }

// SCREEN_GLOW — from active terminals (amber consoles)
{ type: 'point', color: [0.4, 0.5, 0.7], intensity: 0.15, radius: 1.5 }

// TERMINAL_PHOSPHOR — NEW, from Computer Core / mainframe screens
{ type: 'point', color: [0.29, 0.48, 0.34], intensity: 0.12, radius: 1.2 } // matches #4a7a52 family

// HELMET_LIGHT — player flashlight (spot)
{ type: 'spot', color: [0.95, 0.9, 0.8], intensity: 1.2, innerAngle: 18, outerAngle: 32,
  range: 12.0, toggleable: true }

// SCANNER_PULSE — NEW, brief radial light-pulse when the proximity scanner pings
{ type: 'point', color: [0.29, 0.48, 0.34], intensity: 0.4, radius: 3.0, decay: 0.3 /* seconds */ }
```

Ambient base: `intensity: 0.08` — dark corners stay genuinely dark. Every room should require the player's own light to read clearly; that's the whole ambient-lighting philosophy in one sentence.

Flicker implementation (`slow_pulse`, `rapid`, `occasional_cut`) — same pattern for all flickering lights:

```js
switch (light.flickerType) {
  case 'slow_pulse':
    light.currentIntensity = light.intensity * (0.85 + 0.15 * Math.sin(time * 1.2 + light.phase));
    break;
  case 'rapid':
    light.currentIntensity = light.intensity * (Math.random() > 0.1 ? 1.0 : 0.3);
    break;
  case 'occasional_cut':
    if (time - light.lastCut > light.cutInterval) {
      light.isCut = true; light.cutEnd = time + 0.2; light.lastCut = time;
      light.cutInterval = 4 + Math.random() * 4;
    }
    if (light.isCut && time > light.cutEnd) light.isCut = false;
    light.currentIntensity = light.isCut ? 0 : light.intensity;
    break;
}
```

## 7. Complete file & folder structure

Changes from the v2 prompt this replaces: `FlightCamera.js` removed (merged into `PlayerCamera.js`, §3); added `ProximityScanner.js`, `HollowEntity.js`, `HackingMinigame.js`, `TensionDirector.js`, `SaveTerminal.js`, `HackingTerminal.js`, `CRTTerminalRenderer.js`, `TerminalUI.js`, `ResearchLab.js`, `ComputerCore.js`. Everything else below is a direct carry-forward.

```
STARRIFT/
├── index.html                    ← Entry point, canvas, module loader, loading screen
├── manifest.json                 ← PWA manifest (offline capable)
├── sw.js                         ← Service worker (cache assets)
├── src/
│   ├── main.js                   ← Bootstrap: init engine, start game loop
│   ├── core/
│   │   ├── Engine.js              ← Main game loop (rAF, delta, fixed update)
│   │   ├── Renderer.js            ← WebGL2 context, pipeline, framebuffers
│   │   ├── InputManager.js        ← Keyboard, pointer lock, touch, gamepad
│   │   ├── AudioEngine.js         ← Web Audio API, sound synthesis, music
│   │   ├── AssetManager.js        ← Texture cache, shader compile, asset load
│   │   ├── StateManager.js        ← Global FSM (MENU, PLAYING, INVENTORY, MAP...)
│   │   ├── EventBus.js            ← Decoupled pub/sub
│   │   └── Constants.js           ← ALL magic numbers, config, palette colors
│   ├── rendering/
│   │   ├── PixelRenderer.js       ← Pixel-perfect utilities, dithering
│   │   ├── TextureFactory.js      ← Procedural texture generation (everything)
│   │   ├── TextureAtlas.js        ← Packs generated textures into atlases
│   │   ├── LightSystem.js         ← Lights, flicker, shadow maps (§6)
│   │   ├── AmbientOcclusion.js    ← Baked per-vertex AO for interiors
│   │   ├── ParticleSystem.js      ← Thruster fire, sparks, dust, smoke
│   │   ├── SpaceRenderer.js       ← Star field, nebulae, skybox
│   │   ├── PlanetRenderer.js      ← Pixel sphere planets, atmosphere, rings
│   │   ├── WarpEffect.js          ← Black-hole-style warp transition
│   │   ├── PostProcess.js         ← CRT scanlines, vignette, grain (full-frame)
│   │   ├── CRTTerminalRenderer.js ← NEW — diegetic screen shader pass (§4)
│   │   ├── PixelFont.js           ← Bitmap font renderer (AMBER-9, TERM-MONO-7)
│   │   └── shaders/               ← interior/space/planet/particle/warp/postprocess/hud .vert/.frag
│   ├── world/
│   │   ├── Universe.js, StarSystem.js, CelestialBody.js, Star.js, Planet.js, Moon.js
│   │   ├── AsteroidField.js, SpaceStation.js, Derelict.js, Minefield.js, Artifact.js
│   │   └── generation/  ← SystemGenerator.js, PlanetGenerator.js, ContentPopulator.js, NoiseLib.js
│   ├── interior/
│   │   ├── ShipMap.js, InteriorRenderer.js, CollisionMap.js, Room.js, Corridor.js
│   │   ├── rooms/  ← Cockpit.js, Bridge.js, CaptainQuarters.js, CrewBunks.js, MedBay.js,
│   │   │            Kitchen.js, Bathroom.js, Storage.js, CargoBay.js, Airlock.js,
│   │   │            Workshop.js, ResearchLab.js*, ComputerCore.js*, ReactorRoom.js, EngineRoom.js
│   │   └── props/  ← PropBase.js, Crate.js, Console.js, Panel.js, Locker.js, Bunk.js, Light.js,
│   │                Door.js, Pipe.js, Vent.js, MedStation.js, FuelPort.js, StorageRack.js,
│   │                Machinery.js, SaveTerminal.js*, HackingTerminal.js*
│   ├── player/
│   │   ├── Player.js, PlayerController.js, PlayerCamera.js (§3), PlayerLight.js
│   │   ├── Survival.js, Inventory.js, CharacterSheet.js
│   │   └── ProximityScanner.js*
│   ├── ship/
│   │   ├── Spaceship.js, ShipExterior.js, FlightController.js
│   │   ├── ShipSystems.js, ShipDamage.js, ShipWeapons.js, WarpDrive.js, ThrusterFX.js, LandingSystem.js
│   │   └── (no FlightCamera.js — merged into player/PlayerCamera.js, §3)
│   ├── entities/
│   │   ├── EntityManager.js, AlienShip.js, AlienFaction.js, Wildlife.js
│   │   ├── Projectile.js, Explosion.js, NPC.js
│   │   └── HollowEntity.js*
│   ├── combat/  ← CombatSystem.js, WeaponFactory.js, DamageCalculator.js, TargetingSystem.js, PersonalCombat.js
│   ├── gameplay/
│   │   ├── CraftingSystem.js, TradingSystem.js, MiningSystem.js, ScanSystem.js
│   │   ├── QuestSystem.js, SaveSystem.js, TimeSystem.js
│   │   └── HackingMinigame.js*, TensionDirector.js*
│   ├── ui/
│   │   ├── HUD.js, Crosshair.js, Compass.js, InventoryScreen.js, GalaxyMap.js
│   │   ├── ShipStatusUI.js, TradingUI.js, CraftingUI.js, ScanResultUI.js, DialogueUI.js
│   │   ├── JournalUI.js (holds audio/text logs), PauseMenu.js, MainMenu.js, CharacterCreation.js
│   │   ├── LoadingScreen.js, NotificationSystem.js, TouchControls.js, SettingsMenu.js
│   │   └── TerminalUI.js*  ← shared CRT terminal screen chrome
│   ├── data/
│   │   ├── items/  ← ItemRegistry.js, resources.js, components.js, consumables.js, weapons.js,
│   │   │            shipParts.js, alienItems.js, artifacts.js, tradeGoods.js
│   │   ├── StarSystemsData.js, ShipTypes.js, AlienRaces.js, CraftingRecipes.js
│   │   ├── BiomeData.js, DialogueData.js
│   │   └── LoreEntries.js  ← now specifically houses audio-log / text-log content
│   └── utils/  ← MathUtils.js, NoiseUtils.js, ColorUtils.js, ObjectPool.js, Serializer.js, RNG.js, Debug.js
└── assets/
    ├── textures/  ← interior/, exterior/, space/, ui/  (pre-generated + cached, not hand-authored)
    └── data/      ← savegame.json, settings.json
```
`*` = new in this version.

## 8. Collision & physics

Custom AABB + sphere collision, no library. Every prop with solid geometry gets a registered AABB collider — this is a hard rule in the quality checklist (`context/07`).

## 9. Save system

`SaveSystem.js` serializes full game state to `localStorage`. Two triggers:
- **Autosave** — periodic + on major transitions (room change, docking, sleep), silent, safety net.
- **Manual save** — at a `SaveTerminal` prop, with sound + short animation (`context/04`, `context/06`). This is the ritual the player actually relies on; the autosave exists so a crash doesn't erase real progress, not to replace the terminal.

Watch save size as content grows (portrait data, discovered-log flags, procedurally-named items). `localStorage` is capped around 5–10MB depending on browser; if we approach that, migrate to IndexedDB — noted as an open question in `CLAUDE.md`.

## 10. Mobile implementation

```js
const isMobile = /Android|iPhone|iPad/i.test(navigator.userAgent) || navigator.maxTouchPoints > 2;

if (isMobile) {
  screen.orientation.lock?.('landscape');
  ParticleSystem.MAX_PARTICLES = 500;      // vs 2000 desktop
  LightSystem.SHADOW_RES = 256;            // vs 512 desktop
  TouchControls.show();
  Engine.TARGET_FPS = 30;
}

document.addEventListener('touchmove', e => e.preventDefault(), {passive: false});
document.addEventListener('contextmenu', e => e.preventDefault());
```

Touch layout (left joystick = move, right joystick = look, bottom strip = interact/jump/sprint/crouch/inventory/map, flight-mode additions = fire/boost/roll/warp/weapon-select) is specified in full in `context/05`.

## 11. Performance budget

| Metric | Desktop | Mobile |
|---|---|---|
| Framerate | 60fps | 30fps |
| Draw calls (interior) | < 200 | < 200 |
| Draw calls (space) | < 100 | < 100 |
| Shadow map resolution | 512×512 | 256×256 |
| Max particles | 2000 | 500 |
| Frame budget | < 16ms | < 33ms |
