# 07 — Roadmap & Workflow

Check items off as they land. Update `SESSION_LOG.md` at the end of every session — see the protocol at the bottom of `CLAUDE.md`.

## Phase 1 — Engine Foundation
- [x] `index.html` with canvas, module loading, loading screen
- [x] `Engine.js` game loop (rAF, delta timing, fixed update at 60Hz)
- [x] `Renderer.js` WebGL2 context, framebuffer, pixel-upscale pipeline
- [x] `InputManager.js` keyboard + pointer lock + touch basics
- [x] `Constants.js` full palette (`context/01` §2), config values
- [x] Basic Cockpit room (placeholder geometry, one light)
- [x] Player movement + collision (simple AABB)

## Phase 2 — Full Interior
- [x] All 13 rooms + airlock fully built with geometry, including Research Lab and Computer Core
- [x] All 5 corridor types implemented, never repeating adjacently (`context/02` §5)
- [x] `TextureFactory.js` — generate all wall/floor/ceiling/prop textures per `context/01`
- [x] `LightSystem.js` — all light types + flicker, including `TERMINAL_PHOSPHOR` and `SCANNER_PULSE`
- [x] Door open/close animation
- [x] All props placed, collision enabled on all
- [x] Room-to-room navigation working

## Phase 3 — First-Person Flight
- [x] `SpaceRenderer.js` — star field + nebulae
- [x] Ship exterior model (pixel art, textured) — for other-ship/cinematic use only
- [x] `FlightController.js` — Newtonian physics
- [x] Seated first-person cockpit transition, **no camera pull-back** (`context/02` §3 — verify explicitly)
- [x] Sol Prime star + 2 planets, basic
- [x] `ThrusterFX.js` — engine particles

## Phase 4 — Full Star Systems
- [x] All 5 star systems built out (`context/03` §4) — generated from real-astronomy rules (`CelestialGen.js`), lore compositions forced per system
- [x] **Five more off-route spurs** (session 16n): Odessa Chain (F), Amber Well (red giant), Cold Harbour (brown dwarf), Thresher (O supergiant), The Drum (neutron star) — ten systems total, grouped in the warp chart
- [x] Interior materials at 128² on a 64² design grid (session 16o) — `Painter` writes TX output texels per design texel and samples noise/wear at the output rate; `NEAREST_MIPMAP_NEAREST` chain kills minification shimmer without blending
- [x] Thirteen body surface kinds — `toxic`, `carbon`, `metal`, `tundra`, `sulfur` added to `moon`/`comet`/`rocky`/`ice`/`lava`/`gas`/`oceanic`/`jungle`, all built on demand via `ensureBodyTex`
- [x] `PlanetRenderer.js` — pixel sphere planets ✓ + atmosphere ✓ + **ring systems** ✓ (all live in `SpaceRenderer.js`; rings are split far/near ellipse billboards, see `planetRingTexture`)
- [x] Warp sequence — 4-stage singularity cinematic (infall → black hole + accretion disk → consume → streaks) in `SpaceRenderer.js` + `main.js`; target chart in `WarpPanel.js`
- [x] Asteroid fields — per-system belts (11–17 planetoids at ~2.5× HZ radius; `beltN`/`beltAt`/`beltSpread` overrides, three materials incl. nickel-iron)
- [x] Basic stations (dock trigger, refuel) — 9 stations + 8 derelicts across the chart; DOCK refuels sublight + warp tanks
- [x] Scale system + travel timers — real km/AU compressed-proportional scale; warp charge/streak timers; warp fuel economy (22%/jump)

## Phase 5 — Gameplay Core
- [x] Survival stats — all 7 tracked in `ShipSystems.js` (health/oxygen/hunger/thirst/fatigue/radiation/temperature) with critical-threshold health drains; full `Survival.js` split can come with Phase 6 death
- [x] `Inventory.js` — 120 volume-slots, weight, stacking, categories
- [x] `HUD.js` — full helmet display: all 7 vitals (FOOD/H2O/RST added), NOISE meter + HIDDEN tag in SENSORS, flashing critical-alert strip under the compass
- [x] Item pickup/inspect/use interactions — containers roll seeded loot on first search (`Loot.js`); USE routes effects through `ShipSystems.applyItem`
- [x] `SaveSystem.js` — autosave (60 s) + `SaveTerminal` ritual ("PROGRESS RECORDED"), versioned localStorage snapshot, restore on boot (system, ship pose, vitals, inventory, searched containers)
- [x] 200 items in registry — exactly 200 in `ItemRegistry.js` (adds alloys, electronics, exotic gases, Keth/Vrenn/Drift faction salvage, minerals, galley stock, field equipment); Phase 7 expands to 1000+
- [x] `ProximityScanner.js` and hiding/noise system (`context/04` §5–6) — TAB-raised handheld with phosphor CRT sweep, movement blips (doors; the Hollow later), battery + console recharge, slowed walk while raised; `NoiseSystem.js` tracks step/door noise with a HUD meter and a general `hidden` state for Phase 6 AI

## Phase 6 — Combat & Threat
- [x] Personal combat (3 weapons) — `combat/PersonalCombat.js`: the sidearm, carbine and arc cutter are drawable (B cycles/holsters), firable (Mouse0/X), reloadable (R) on foot. Hitscan against the collision map and the interactable boxes, ammunition drawn from the hold as `ammo_slug`/`ammo_cell` items, per-weapon recoil as a single clamped pitch impulse, procedural first-person viewmodels with muzzle flash, spent cases and world-projected impact sparks, and a shot pinning the noise meter at 1.0. Rounds that land on ship systems damage that hull section; the Hollow still cannot be shot (0.23.0)
- [x] Ship laser cannon + projectiles — click / X / FIRE, capacitor-limited, amber bolts (`SpaceCombat.js`)
- [x] 2 alien ship types — Keth fighter (Vega Reach) + Drift drone (Twin Suns, the Pale) with patrol/aggro/jink/fire AI; Vrenn stay neutral until reputation lands
- [x] Explosion effects + camera shake — spark bursts, hit knocks, seat rattle
- [x] Shield system — absorbs bolts, regens between hits; overflow eats hull
- [x] Death + respawn — hull loss or vitals collapse -> death screen -> recover last record (save restore, floors on wake)
- [x] `HollowEntity.js` + `TensionDirector.js` (one module, `gameplay/TensionDirector.js`) — evasion-only lair encounter in the aft wing while riding Twin Suns/the Pale: cues escalate (lights sag, clanks, scanner static), hide/evade/noisemaker, resolves by leaving; **no combat-win path exists** — the entity has no health, no hitbox, no defeat state

- [x] **On-foot hostiles you can actually fight** — `entities/Boarders.js` (0.50.0): three species aboard a boarded hull (CARRION scavengers, KETH BOARDERS with a bullpup, DRIFT DRONES that only proximity wakes), deterministic per hull id, five part meshes each drawn through the interior renderer's `actors` hook so they are lit by the compartment they stand in. Dormant/rousing/hunting/winding/dead, melee windups you can back out of, ranged fire that can miss, corpses you strip with `[E]`, kills persisted so a cleared hull stays cleared. They ping the proximity scanner — the first thing besides a door that has ever moved aboard. Deliberately the opposite pole from the Hollow, which still cannot be shot

## Phase 7 — Content
- [ ] All items (expand to 1000+) — registry now **483** (0.56.0), each with a unique generated icon (30 forms, one per subcategory, seeded per id — `ui/ItemIcons.js`); earlier **313** (0.47.0): wearable FITTINGS (the first items that change the ship rather than being spent), deep-range charts and sealed manifests, five more artifacts, bulk trade goods; earlier — eight variant-hull faction salvage pickups, ten EVA/suit consumables, twelve named ship spares, three specialty ammunition loads plus weapon-service kit/sight/brace, eight nav-and-records data items, eight restricted goods, eight xeno samples, eight more hand tools and ten more personal effects. Families still ready to extend
- [x] `TradingSystem.js` + `TradingUI.js` — per-station seeded price bias, buy/sell spread, credits account; opens on docking, buy/sell tabs; persists in save (0.8.3)
- [x] Planet landing transition — flown atmospheric entry with a real position (0.38.0), then the ionisation envelope that hides the world swap so there is no hitch and no jump cut either way (0.42.0), and finally **whole spherical worlds** (0.45.0): the height is a function of a direction on the body, the mesh is a curved cap that slides with you, and the old 3200-metre wall is gone. **The envelope now peels back** (0.52.0): it was pinned solid for the whole entry, which made the descent a loading screen with a plasma texture on it — it is opaque only until there is a world underneath it, then clears across the first stretch of the descent so you fly the rest of it looking at the landscape. And the ventral jets got their own figure (`DESCENT_ACCEL`), because at RCS thrust the net climb authority over a 1 g world was twelve u/s² and over a heavy one was two: landing was not hard, it was arithmetically impossible
- [x] Alien AI behaviors + faction system — Keth/Drift AI (Phase 6) + faction reputation: four powers (Kestrel/Vrenn/Keth/Drift) with −100..+100 standing moved by combat/trade/quests, standing tiers, Vrenn-counter price flex, STANDINGS journal tab, persisted (`gameplay/FactionSystem.js`, 0.8.5). **Standing now drives AI aggro** (0.8.9): friendly/neutral patrols are tolerant and never fire first (one-time no-lock hail), hostile factions hunt from 1.4× further out, and firing first provokes the whole squadron for −25 standing
- [x] `QuestSystem.js` (10 quests minimum) — 10 data-driven work orders (collect/dock/visit/kill/sell/save/slots) tracked off the event bus with credit + materiel payouts; WORK ORDERS tab (0.8.3)
- [x] **Boarding from the suit, and decks worth walking** (0.51.0–0.53.0) — a derelict is entered by crossing to it on the pack (`[E] CUT INTO <hull>`), not by a cockpit button; station-keeping runs while you are outside, without which the wreck sails away at its host's orbital speed. The wreck deck went 6 → **10** compartments (galley, workshop, reactor space, sealed compartment behind an access crawl) and the station 7 → **11** rooms (clinic that sells health and radiation clearance, transit bunks, bonded transfer bay, customs post). `Boarding`'s compartment list is keyed to the zone ids now, so the flavour text and loot pool finally belong to the room you are standing in
- [x] **Enemy hulls you disable and board** (0.54.0) — a measured killing blow leaves a hostile dark and adrift instead of destroyed (overkill under a third of its own hull); the crippled ship keeps drifting, drops its running lights and its plume, becomes an EVA boarding target with its own faction's crew still aboard at danger 0.95, and costs standing to cut into. Station-keeping learned to hold a hull that was never on the chart
- [x] **Fabrication, and fittings that do work** (0.57.0) — the workshop bench has said `CRAFTING SUITE OFFLINE` since Phase 2 and now runs 21 recipes across SHIP/SUIT/ORDNANCE/MEDICAL/STOCK, none of which make a better version of a thing you can buy: every one converts what you have too much of into what you ran out of, where there is no shop. Spoil chance eats the inputs and ENGINEERING halves it; STRIP is the lossy other direction, with a `recycleYield` guard and a verified-zero closed-loop economy. Alongside it, four fittings aboard your own hull stopped printing flavour and started drawing on finite stores — galley dispenser (212 ration units, counted), water reclaimer (a loop tank on a twelve-minute refill), med bed (+34 HP / −22 RAD out of eight doses), assay bench (a sample crushed for a survey fee). The Petrel has no workshop, so every hull's engine room carries a FIELD BENCH
- [x] **The hold manifest, deep enough for 483 items** (0.57.0) — search across name and description, six sort orders, a subcategory sub-rail under the open category, rarity pips on the tiles, a live capacity bar, a two-tap jettison, and a readout that gives value/mass/bulk per unit *and* per stack plus exactly which stat USE moves. Narrow viewports stack the three columns into three rows instead of hiding two of them
- [x] **NPC dialogue** (0.58.0) — ten people on a station deck (`entities/Crew.js`, built on the boarder part-mesh machinery so they are lit by the compartment they stand in), each with a topic list rather than a branching tree (`gameplay/Dialogue.js`). Every line is generated from LIVE state — the officer names bodies in the system you are actually in, the chandler quotes the price bias your standing has actually earned, the armourer reads the hull stat that is actually lowest, the medic reads your actual injuries. Once-only topics are spent per station, so a favour asked is a favour gone and the next station is worth walking around. Names are seeded off station id and post, so the harbourmaster at Meridian is a specific person who is still there when you come back
- [x] `HackingMinigame.js` + `HackingTerminal.js` — ICE-break glyph-sequence intrusion vs a countermeasure clock; secured terminals route through it for a data chip + credits (`ui/HackingMinigame.js`, 0.8.3)
- [x] Audio/text logs populated in `LoreEntries.js`, readable via `JournalUI.js` — 14 crew/station logs, zone/dock/visit-gated, RECOVERED LOGS tab + LOG chip / L key (0.8.3)

## Phase 8 — Polish
- [x] `PostProcess.js` — CRT scanlines, vignette, film grain (full-frame) — offscreen FBO → CRT resolve shader: aperture-grille scanlines, RGB phosphor triad mask, tube-curve vignette + bezel, chromatic aberration, rolling grain, mains flicker; Settings VIDEO → CRT SCREEN toggle (0.8.4)
- [x] `CRTTerminalRenderer.js` — diegetic screen pass, separate from the above — implemented inside `interior.frag` rather than as a separate module (the screens are already batched into the zone draw; a second pass would have cost a draw call per console for no gain). Console glass gets UV-space scanlines, a rolling refresh bar, mains flicker, random dropouts, tube vignette and a phosphor drive, targeted by atlas layer range so emissive lamps stay clean. Shares the CRT SCREEN setting (0.9.0)
- [x] `AudioEngine.js` — **all sounds** (0.59.0). The four `context/06` §3 cues that were specced and never written: `playScannerPing` (drops an octave and gathers static near the Hollow — the scanner's unreliability finally exists in the channel the player is listening to, not just on the screen), `playTapeLogCrackle` (a telephone-band bed with a slow wow, running under a log while you read it), `playHullGroan` (on a timer whose rate and gain scale with plating damage, so the hull number is audible without looking at it) and `playHeartbeatSting` (Hollow only, triple-gated to stay a signal). Plus **`playAirlock`, which `startEva` has been calling since 0.51.0 into a method that did not exist** — the optional chaining swallowed it and the most dramatic thing you can do on foot happened in silence. Plus fifteen more for systems that had no voice at all: dock clamps, warp charge and jump, soft vs hard touchdown, the bench crafting and spoiling, pickup (rare gets a second note), the till, a proficiency going up, a klaxon, deflector hit vs deflector collapse, dry fire, eat/drink/dose, and the suit's cold-gas jet as a held hiss. Wired off the event bus in the engine's own constructor, the same way `Progression` reads it, so no other module had to learn audio exists and nothing can play twice
- [x] `TouchControls.js` — full mobile overlay — 13 keys in two gutters (down from 20), sizes measured against the 44px floor, the turn gesture folded into the silent right-half look region rather than a painted stick, and `_stackClusters()` resolving each gutter bottom-up in measured pixels so the columns cannot overlap at any viewport height (verified zero overlaps at 844x390 / 1024x600 / 740x360 / 1280x720, both modes, 0.22.0)
- [ ] Mobile performance optimization
- [x] `CharacterCreation.js` — pilot setup screen (`context/05` §5) — commission screen on a fresh save: name the sole survivor + pick one of four service backgrounds (Company Lifer / Void Salvager / Vrenn Factor / Deck Officer), each seeding starting credits, kit and faction standing; blocks boarding until BEGIN; pilot name shows on the gate; persisted, skipped when a save exists (`ui/CharacterCreation.js`, 0.8.6)
- [x] **Full settings menu** (0.60.0) — seven options became fourteen, in four contiguous sections. New levers, each with real engine support behind it rather than a stored value nobody reads: **CRT STRENGTH** (a `u_crt` mix in the post shader and the same figure on the diegetic screens, so the tube dials from off to full instead of being a switch between "no period feel" and "scanlines over the 6px glyphs"), **SHIP AMBIENCE / EFFECTS** as two buses under the master (the bed is what makes the ship feel inhabited, the one-shots are information, and one slider could express neither), **HEAD BOB** off as an accessibility option (pillar 1 means there is no third-person view to escape a 1.8 Hz oscillation into), **AUTOSAVE** interval including OFF (a survival game where a bad decision costs you cannot have a background writer committing the consequences every minute; the terminal ritual still works), and **THE HOLLOW** frequency — never / two systems / four / every one, which is `CLAUDE.md`'s oldest open question answered as a player choice rather than a number somebody has to be right about. Two menu bugs fixed on the way: `note` was only rendered inside the `select` branch so four written notes were silently dropped, and `_syncAll` painted each readout *before* writing the new value into its slider, so after RESET every thumb moved and every number beside it still showed the old figure

## Quality checklist — run before every commit

Last run against the live game in session 17b (0.21.0). The measured items are
driven by a Playwright probe rather than checked by eye — that is what caught the
40px-tall touch keys and what proved two of the "failures" below were probe bugs.

**Visual**
- [x] No flat single-color surfaces in any texture — every generator paints ≥3 colours plus wear
- [x] No neon/bright green anywhere in the HUD — grep for `#00ff00|#00cc00|#0f0|#00e000` returns only the comment naming the ban
- [x] Terminal phosphor green never appears on the player's own HUD — `HUD.js` has no `PHOSPHOR` reference at all
- [x] All HUD text uses the amber palette (`#b08040`–`#d0a060` range)
- [x] All color transitions via dithering, not smooth gradient
- [x] Pixel alignment: all UI elements snap to integer coordinates at 480×270 (`RENDER.UI_*`; the scene buffer scales, the chrome grid does not)
- [x] Crosshair visible, amber, max 5×5 pixels

**Perspective**
- [x] No third-person camera during WALKING — `view.third` is reachable only from the pilot seat. The hull cam itself is an owner-approved piloting view mode (session 5); see the camera rule in `CLAUDE.md`.
- [x] Cockpit entry stays first-person throughout (`context/02` §3)

**Technical**
- [ ] 60fps desktop, 30fps mobile mid-range — cannot be measured in the harness; SwiftShader fps says nothing about real GPU cost. Draw calls are the proxy that IS measurable.
- [x] No WebGL errors in console — zero across every probe this session
- [x] Draw calls: < 200 interior, < 100 space — **41** interior, **73** cruising, **79** in a five-hostile fight, **79** peak during a warp
- [x] All solid-geometry objects have registered AABB colliders — 341 boxes
- [x] No leaked WebGL buffers — 106 buffers / 56 VAOs before a warp, identical after

**Gameplay**
- [x] Touch targets minimum 44×44px on mobile — the small keys were 48×**40**; fixed to 48×44, big ones 68×52
- [x] All 5 corridor types appear, never duplicated adjacently — A·E·B·E·C·E·C·D·E·B, zero adjacent duplicates (type E is the junction hub, which is why a corridors-only filter appears to fail this)
- [x] Every room has at minimum 2 interactive objects — 78 across 14 rooms, minimum 4 (med bay, bathroom, storage, airlock, workshop, reactor)
- [x] Save/load round-trips without data loss — hull, per-section integrity, fuel and stack counts all exact
- [x] Warp effect completes without framerate drop — peak 79 of the 100 draw-call budget, no buffer growth
- [x] The Hollow has no combat-win path — `TensionDirector` only ever returns `'kill'`; nothing in it accepts damage

**Code**
- [ ] No magic numbers outside `Constants.js` — the palette families are honoured, but the DOM UI files still carry inline hex (Chrome.js 66, CharacterCreation 27, JournalUI 21). Real debt.
- [x] JSDoc on all class constructors and public methods
- [ ] Object pool in use for particles and projectiles — `utils/ObjectPool.js` exists and is imported **nowhere**; sparks/bolts/smoke use plain array push+splice. Not currently a problem (no leaks, budget headroom) but the checklist item is unmet.
- [x] No global variables except the debug refs — only `window.__debug` and `window.DEBUG`
