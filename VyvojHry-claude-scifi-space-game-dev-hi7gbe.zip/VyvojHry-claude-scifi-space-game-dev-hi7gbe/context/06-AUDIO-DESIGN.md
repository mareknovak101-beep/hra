# 06 — Audio Design

No audio files, anywhere. Everything below is synthesized at runtime through the Web Audio API in `AudioEngine.js`.

## 1. Philosophy

Silence is an instrument. Most of this ship should be quiet enough that a single distant clank means something. Don't default to constant music — layered, sparse ambience is the baseline, and real near-silence is reserved deliberately for the moments that need it (the Hollow's lairs especially, `context/04` §8). If a room feels like it needs music to not be boring, the texture and lighting probably need another pass before the audio does.

## 2. Core functions (carried forward)

```js
playReactorHum() {
  // Oscillator: sine, 48Hz base + slight modulation at 0.3Hz — deep ambient drone
}

playFootstep(surface) {
  // Noise burst (50ms), filtered by surface:
  // 'metal': bandpass 800–2000Hz, sharp attack
  // 'grating': bandpass 400–1200Hz, slight reverb
  // Randomize pitch ±15%
}

playLaserFire() {
  // Sine wave, 800Hz → 200Hz over 80ms, overdrive distortion
}

playExplosion(size) {
  // White noise burst, duration: size * 0.4s, low-pass 400Hz Q=0.8, exponential decay
}

playWarpCharge() {
  // Sine sweep 40Hz → 800Hz over 5s, volume rises exponentially, 3× harmonic at 50% volume
}

playAmbientInterior() {
  // 3 layers: reactor hum (constant) + HVAC whoosh (0.5Hz LFO on volume) +
  // random distant clank (impulse noise, random interval 8–30s)
}
```

## 3. New functions for this version

```js
playScannerPing() {
  // Short sine blip, 1200Hz, 40ms, soft attack/decay — the proximity scanner's own sound
  // Near the Hollow: pitch-shift down + add light noise/static instead of a clean ping
}

playTerminalKeystroke() {
  // Very short filtered click, 30ms, randomized ±10% pitch per keypress
}

playTapeLogCrackle() {
  // Bandpass filter (300–3400Hz, telephone-ish) + low-level pink noise bed under any
  // audio-log playback — simulates a degraded recording without needing an audio file
}

playHullGroan() {
  // Low sawtooth, 30–60Hz, slow pitch drift, used sparingly during hull stress / cold flexing
}

playHeartbeatSting() {
  // Two-pulse low sine (60Hz), used ONLY during active Hollow proximity — this should be
  // rare enough that it's a genuine signal, not ambient wallpaper
}

playSaveChunk() {
  // Short percussive noise burst + low thunk (mechanical relay sound) — the save-terminal ritual
}
```

## 4. Mixing notes

- Frequency-carve critical cues so they cut through ambience: the scanner ping and any alert klaxon should sit in a band the reactor hum and HVAC layers aren't occupying — check this by ear with ambience playing, not in isolation.
- Dynamic range stays wide. Loud moments (explosions, alarms) should feel loud specifically because the baseline is quiet — compressing everything toward the same loudness kills the effect this whole game is built around.
- `playHeartbeatSting()` and the Hollow-degraded `playScannerPing()` variant are the two sounds most likely to get overused in testing. If either one is playing more than a handful of times per session, `TensionDirector.js` (`context/04` §8) needs tuning, not the sound itself.
