# Session Log

Append an entry here at the end of every session (see `CLAUDE.md` → Session protocol). Keep entries short — what shipped, what broke, what's next. This file is a record, not a doc; the real specs live in the rest of `context/`.

---

## Session 15 — Owner Batch: 3D Stars, Effects Package, Plastic Chrome, Menu Overhaul (build 0.8.1)

**Date:** 2026-07-18

Owner's four tasks before the next phase:

1. **3D spectral stars.** The star is no longer a turning billboard: `starSurfaceTexture(class)` generates a real equirect photosphere per stellar classification (O hot/smooth/blue → M convective/granulated/spotted, plus RG/WD/KD/KM), drawn as a slowly rotating emissive sphere with the old billboard demoted to a corona halo behind it, and **CME prominences** — warm particles rising and falling off the limb on independent clocks. Verified: Sol Prime's G-type fills the windshield with granulation and a starspot.
2. **Effects package.** Staged pixel explosions (white-hot flash core → expanding ring → embers), **deflector shimmer** ring on shield hits, metal sparks + dark debris chips on hull hits, muzzle flash, **engine plumes** for the player (throttle-keyed, boost-brightened) and both enemy types (Keth red, Drift white-blue) — all colour/size-carrying particles now. **Cloud shells**: oceanic/jungle/gas worlds wear a second sphere of real-alpha clouds spinning ~1.7× the surface rate, so the atmosphere visibly slides over the ground as the body turns (the repeating animation asked for). Bodies keep their axial rotation; the star surface now turns too.
3. **Plastic chrome.** New `ui/Chrome.js` — shared bevelled cassette-futurist styling (rivet corners, top catch-light, deep lower shadow, pixel-rendered). WARP/BAG/SCAN shrank to small chips; touch joysticks 52→38 px radius; touch strip buttons compact (34×26 visual) with the same moulded look. NOTE: visual size now under the 44 px checklist minimum at the owner's explicit request — hit areas padded by layout gaps.
4. **Menu overhaul.** The gate is a boot screen now: riveted panel, corner brackets, glowing title, company/vessel lines, divider, full key legend (scanner/hold/warp/fire included), survey-route footer over a CSS starfield. Pause matches (status lines + plastic SETTINGS button). Warp chart + hold manifest re-skinned with the shared plastic panel (scanline weave, inset glow).

**Verified:** star close-up, cloud shells, firefight effects (16 live particles), gate — all screenshotted; flight draw calls 64; zero console errors.

**Known follow-ups:** settings tabs (fields exist, sectioning cosmetic), inventory category filter chips, star classes only generated for the five route classes (add the rest when systems use them).
### 15b addendum — owner redo of the visual batch + two new tasks (build 0.8.2)

Owner: the 15a slice was too thin — star ugly, engine "dots", menus untouched, no in-game menu; plus two new tasks (hull-cam free look/zoom, auto screen fit). Redone properly:

- **Stars, actually stellar now.** Photosphere redrawn: pole-safe granulation (no more pinwheel), supergranulation lane shadows, umbra+penumbra starspots, faculae; the sphere is drawn **lit from the viewer**, giving real **limb darkening** (bright centre → warm dim limb) plus a chromosphere rim. The old giant blotchy halo is replaced by a **tight, rayed, class-tinted corona** per spectral class. **All 11 classes generate** (O B A F G K M + RG WD KD KM). **Prominence arcs**: four magnetic loops that grow, hang and collapse off the limb as animated line arcs — visible at star scale (the CME animation).
- **Engine effects are flames now, not dots**: 3-frame pixel-art flame billboards (white throat → amber body → red fringe, ragged animated tail) burn off both nozzles, throttle-keyed and boost-brightened; **RCS side-thruster puffs** fire at the wingtips when rolling and at the nose when steering; enemies wear the same burning plumes along their velocity.
- **In-game menu** (MENU chip / fourth in the left column): RESUME · RECORD PROGRESS (save) · RECOVER LAST RECORD (load) · SETTINGS · ABANDON SURVEY (double-press wipe + restart), on the moulded plate, sim paused while open.
- **Settings menu** re-plated (moulded plastic + scanlines) with **VIDEO / CONTROLS / AUDIO section headers**; **hold manifest gains category tab chips** (ALL + per-category filters).
- **Hull-cam free look + zoom** (new task): in third person the look input orbits the camera around the ship (pitch clamped), the wheel dollies 0.45×–3.2×; resets on view toggle. Steering stays on roll/thrust keys while orbiting.
- **Automatic screen fit** (new task): integer scale only when it covers ≥88% of the screen, half-integer next, fractional best-fit otherwise — phones now fill the display (900×420 test: canvas 720px wide vs 480px before); re-fits on resize/rotation/visual-viewport changes.

**Verified:** star close-up (limb darkening + corona + two arcs), chase shot (cloud-shell colony + flame trail at THR 100%), in-game menu with save/load live, auto-fit measured; zero console errors.

**Honest gaps:** RCS puffs use the flame sprite (a dedicated cold-gas puff sprite would read cleaner); prominence arcs are line-drawn (1px) — thick sprite arcs would carry more weight at small screens; menus share one plate style rather than per-menu bespoke art.


---

## Session 16 — Owner Redo #3: Multi-Layer FX + Pixel-Art Menu Plates + PHASE 7 Content (build 0.8.3)

**Date:** 2026-07-23

Owner rejected 0.8.2's effects as still too thin ("engine looks like dots, redo engine/warp/damage/getting-hit/side-thrusters/shield with complex, multi-layered, heavily-pixelated effects; menus need real pixel-art textures, 3D parts, decoration; then next phase").

1. **Effects, rebuilt at the right scale.** The root cause of "dots" was size: plumes were ~6–14 world units against a ~90px hull on the 480×270 buffer, so nearest-neighbour sampling dissolved them. Recalibrated to **plume scale** and layered:
   - **Engine thrust** — per nozzle: white-hot throat glow + amber nozzle bloom + a **42-unit bell-profile plume** (Mach core, shock diamonds, ragged tail) + a hotter inner tongue. Boost stretches it to ~110 units. Flames now draw as a **crossed quad pair** (volume from every angle) with a round exhaust bloom when viewed dead-astern.
   - **Shield** — a hull-hugging **ellipsoid, two faceted shells** breathing at different rates (interference shimmer) + a cold rim bloom, all keyed to `shieldT`; facets chunked up so they read at bubble scale.
   - **Getting hit** — layered impact flashes (expanding coloured halo + white-hot core), lingering **battle smoke** puffs that swell and thin.
   - **Hull damage** — below 65% integrity the ship trails ragged smoke and guttering ember glow from two wound points, worse as integrity falls (fed by `space.damage = 1 - hull/100`).
   - **Side thrusters** — RCS cold-gas jets (pale crossed puffs + throat glow) at the wingtips on roll, at the nose on steer.
   - **Warp singularity** — a real 6-layer portrait: wide bloom → two counter-rotating **accretion swirls** (new `swirlTexture`, doppler-boosted) → **relativistic polar jets** → a blazing **photon ring** (new `ringTexture`) → the void last. New effect textures: `swirlTexture`, `ringTexture`, `glowWhite`.
   - Fixed a latent bug: `_drawFlame` cycled `% 3` against 4 flame frames; also re-anchored prominence arcs to the photosphere shell so they hug the disc up close instead of smearing across the sky. All exterior effect layers now depth-test-but-don't-write and are double-sided (no layer self-punches or back-face culls).
2. **Menus are generated pixel art now, not CSS gradients.** `ui/Chrome.js` rewritten: `platePNG()` **paints each panel/button into a canvas** — Bayer-dithered brushed-charcoal ramp, hard 2px bevel (lit top-left, shadowed bottom-right), corner + mid rivets, paint pits, pale scuffs, hazard ticks, vent slots, stencil tallies — exported as a data URI, stretched with `image-rendering:pixelated`. New `hazardBar()` themed accent strip and `applyBootChrome()` to reskin the static gate/pause overlays on boot. Applied to the gate (main menu), in-game menu, settings menu, and hold manifest.
3. **PHASE 7 — Content.** `TradingSystem` (per-station seeded price bias, buy/sell spread, credits) + `TradingUI` (buy/sell tabs, opens on docking). `QuestSystem` (10 data-driven work orders: collect/dock/visit/kill/sell/save/slots, live progress off the event bus, credit + materiel payouts) + the WORK ORDERS tab. `LoreEntries` (14 crew/station logs, trigger-gated by zone/dock/visit) + RECOVERED LOGS tab in the new `JournalUI` (LOG chip / L key). `HackingMinigame` — ICE-break intrusion grid: lock a scrambled glyph sequence before the countermeasure clock fills; secured terminals (MAINFRAME/VAULT/ARCHIVE…) route through it for a data chip + credits. Trading/quests/lore all persist in the save file.

**Verified (Playwright, 960×540, zero console errors):** thrust dead-astern + side profile (real layered plume), boost (~110u trail), RCS puffs, shield bubble, hull-hit flashes + smoke + damage trail, warp singularity portrait; all four menus on pixel-art plates; Phase 7 — 10 open quests, arrival completes q_vega + unlocks lore, collecting 3 rations completes q_provisions, 18-item station stock, sell adds credits, hacking grid live.

**Honest gaps:** hacking/trading modals release pointer lock and freeze the sim while open (re-lock on close) rather than an in-canvas overlay; quest set is exactly 10 (roadmap says "10 minimum"); item registry still 200, not the 1000+ Phase 7 target; NPC dialogue + planet-landing transition not yet built.

### 16b — Phase 8 start: full-frame CRT post-process (build 0.8.4)

Kept advancing the roadmap after the owner batch — pulled the biggest unpulled mood lever (the game's core pillar is *Alien/Isolation* analog-monitor dread, and nothing yet gave the picture that CRT). New `rendering/PostProcess.js`: the whole 480×270 scene now renders into an **offscreen framebuffer** (RGBA8 colour + depth renderbuffer), then a single attributeless fullscreen triangle blits it to the backbuffer through a **CRT resolve shader** — aperture-grille scanlines (alternate rows −20%), an **RGB phosphor triad mask** (per-column tint), a **tube-curve barrel** with a black corner bezel, **chromatic aberration** growing toward the edges, **rolling film grain** quantized to 4 levels (dithers, never blurs), and a faint **mains-flicker** brightness wobble, with a +10% lift so the layers don't crush the picture. Everything is quantized to stay pixel-honest.

Wired through `Settings` (new `crt` default-on, **VIDEO → CRT SCREEN** toggle); `post.setEnabled()` reacts live. When off, `begin()/end()` bind the backbuffer directly for **zero cost**. One extra 480×270 draw when on (flight 88 draw calls, still far under budget). Broken-FBO guard falls back to no-op.

**Verified (Playwright, zero console errors):** CRT-on interior (scanlines + phosphor + vignette + aberration on the door prompt), CRT-on star flight, CRT-off comparison (clean/flat), live toggle on→off, full boot→walk→flight→save/load smoke at 88 draw calls.

**Next on Phase 8:** `CRTTerminalRenderer.js` (diegetic screen pass, separate from this full-frame one), full `AudioEngine`, `CharacterCreation.js`, mobile perf. On Phase 7: 1000+ items, planet landing, faction reputation, NPC dialogue.

### 16c — faction reputation system (build 0.8.5)

Closed the "Alien AI behaviors + **faction system**" Phase 7 line. New `gameplay/FactionSystem.js`: the four powers of the lanes — **Kestrel** (employer), **Vrenn** (traders), **Keth** (war-clans), **Drift** (machines) — each hold a −100..+100 standing, moved off the existing event bus. Splashing a Keth fighter drops Keth −8 while Kestrel/Vrenn tick up (you cleared their lane); the Drift the same; trading warms the merchants; work orders please the company. Standings cross five tiers (HOSTILE → WARY → NEUTRAL → FRIENDLY → ALLIED) and announce the crossing.

Consequences wired in: **Vrenn counters now price by your standing** (`TradingSystem.priceMod` reads `factions.priceModifier` — buyers pay less and sellers earn more the friendlier you are, ±15% across the range), and a new **STANDINGS tab** in the journal draws each faction on a centre-ticked ± pixel meter tinted by tier, with a one-line blurb. Persisted in the save.

The three feeder systems visibly interlock: in the verify run, 3 Keth kills auto-completed the `q_keth` work order (which paid out a dense fuel cell) *and* pushed Kestrel from FRIENDLY-ward while Keth fell to WARY, all from the one action.

**Verified (Playwright, zero console errors):** start standings → after 3 Keth kills + a quest (Kestrel 20→41, Keth −30→−54, Vrenn 0→5), Vrenn vs Kestrel price modifiers diverge (0.96 vs 0.85), STANDINGS tab renders 4 meters, save/load round-trip preserves reputation; full boot→walk→flight→save smoke at 88 draw calls.

**Honest gaps:** faction shifts are notification-only (no diplomacy screen); Keth/Drift stay always-hostile in combat regardless of standing (rep gates prices + flavour, not aggro yet); station faction ownership is inferred by name (`VRENN`/`REDFALL`) rather than tagged in the system data.

### 16d — pilot commission screen (build 0.8.6)

Phase 8 `CharacterCreation.js`: the game finally has a front door. On a **fresh save** a SURVEY COMMISSION screen (pixel-art plate) opens over the gate — name the sole survivor of a crew of six and pick one of four **service backgrounds**, each seeding the opening differently: **Company Lifer** (Kestrel +15, 150 CR, medkit), **Void Salvager** (260 CR, fuel ×2 + cutter, Drift −10), **Vrenn Factor** (Vrenn +25, sundries), **Deck Officer** (120 CR, sidearm + meds). A base standard-issue kit is granted to everyone on top. BEGIN applies the grant to `Inventory` / `TradingSystem` / `FactionSystem`, the pilot's name lands on the gate (`PILOT <NAME> — HSV AETHON — CREW 1 OF 6`), and boarding is blocked until a commission is taken. Persisted in the save; skipped entirely when a save exists.

**Verified (Playwright, zero console errors):** fresh boot shows the commission and a gate click is refused (stays GATE); picking Void Salvager as "REYES" applied +260 CR (250→510), Drift −40→−50, the cutter, and 5.5 slots of kit, then boarding reached PLAYING; a reload with a save present **skipped** the commission and restored the pilot (TESTPILOT/officer), booting straight to a usable gate.

**Honest gaps:** backgrounds only seed the opening (no ongoing trait/perk); the pilot name is cosmetic (gate + save, not yet on the HUD or in dialogue); no portrait art (context/05 §5 mentions portrait data — deferred).

### 16e — flight controls overhaul + flight HUD + font glyphs (build 0.8.7)

Owner: improve controls (mainly ship maneuvering) and enhance the HUD/visuals.

**Maneuvering — real 6-DOF.** The flight model only did nose-thrust (W/S) + roll (A/D) + mouse pitch/yaw, so lining up on a target or docking meant pointing and coasting. Added **translational RCS**: `Q/E` sidestep, `R/F` climb/dive (`STRAFE_ACCEL`), fed through the ship's quat into world velocity. Added a **fly-by-wire flight-assist** toggle (`Z`, default on): with no thruster input it gently bleeds residual drift (`ASSIST_DAMP`) so the ship settles to a hover instead of coasting forever — precise docking without manual counter-burns; `Space` stays a hard brake. Rebindings to make room: lamp `F→G`, and stand-up moved from `E` to `crouch` (C/Ctrl) so `E` is free for strafe-right. `Spaceship` gains `flightAssist` + `strafe[]`.

**Flight HUD.** New **flight-path markers** projected into the seated view — a ringed **prograde** velocity vector + a hollow **retrograde** cross (essential once you can strafe: shows the drift the nose hides), an **RCS translation grid** lighting the active thruster, and a **flight-assist status** token in the SPD/THR strip (`A/S` amber vs `MAN` alert). The exterior chase view fires **strafe thruster jets** (opposite the push) so translation reads visually.

**Font glyphs (game-wide HUD polish).** AMBER-9 / TERM-7 lacked `—`, `·` and `×`, so every notification/label using them rendered `?` (e.g. "Water Pouch ?2", "SLOTS ? kg"). Added the three glyphs to the atlas — fixes dashes and multiply signs **everywhere at once** (inventory, trading, journal, notifications, commission).

**Verified (Playwright, zero console errors):** strafe-right E moves +x (vel 0→14, strafe=[1,0]); flight assist bleeds 40→10.4 u/s when on, holds 40 when toggled off with Z; stand-up (C) FLIGHT→PLAYING; flight HUD shows prograde marker offset to the velocity heading + `A/S` token; third-person strafe jets fire; inventory renders `×6`/`×4` and the em-dash cleanly; boot clean (no atlas overflow).

**Honest gaps:** strafe is keyboard-only (touch move-stick still maps to roll/thrust, no translation); assist state isn't persisted (session default on); no throttle-lock/cruise-hold (thrust is held-key).

### 16f — celestial visual overhaul: boiling stars, real CMEs, living atmospheres (build 0.8.8)

Owner: more realistic visuals, deeper textures, more effects; enhance the star surface with real colours and a chaotic animated surface; improve the CME effect; add repeating atmosphere animation for planets and gas giants.

**Animated star photospheres.** `starSurfaceTexture` now takes `(class, frame, frames)` and generates **4 frames per spectral class** (44 textures, all 11 classes). Each frame walks a step around a **circle in noise space**, so the granulation boils chaotically and the last frame joins the first — endless churn with no visible snap. Measured **54% of the star's pixels changing** between consecutive frames.
- **Real colours.** Base tints now match the blackbody values in `STAR_TYPES` (the Sun's photosphere is near-*white*, not egg-yolk yellow). The warmth comes from physics instead of saturation: new `warmShade()` in ColorUtils darkens *and* reddens, so intergranular lanes and starspot umbrae cool toward orange the way real plasma does. A per-class `con` scales that spread so a white star still reads as boiling gold-white.
- **Real cell scale.** The old `gran` frequencies (0.5–3.4) produced a handful of huge smooth blobs — the disc looked flat and washed. Raised to 1.5–13 and added a **micro-granulation octave** that nudges each patch up/down the ramp, so the surface is a dense boiling carpet that still holds detail when the star fills the windshield.

**CMEs, rebuilt.** The old prominences were 1px `gl.LINES` (a gap flagged in 15b). Now there's a `plasmaTexture` — a ragged, *filamentary* plasma blob (white core → amber → ember skirts, 2 crawling frames) — and the star draws **5 magnetic loop arcs as chains of these sprites**, fattest at the crown, flickering on their own phases. Added true **eruptions**: every 9–20s a loop goes unstable and throws a cloud of 8 blobs that climbs several radii, fans out, expands and fades, with a white **flare footprint** blazing on the limb as it launches.
- **Batched, so it's free.** Per-sprite billboards pushed a star close-up to **119 draw calls** (over the <100 space budget). Added a dynamic sprite **batcher** (`_buildSpriteBatch`/`_spritePush`/`_spriteFlush`) that packs all plasma into one buffer and **one draw call** — back to **88**, while allowing *more* sprites than before. Plus distance LOD: filament count drops, then skips entirely, as the star shrinks to a dot.

**Living atmospheres.** `cloudTexture` also takes `(kind, frame, frames)` and generates 4 seamless-loop frames per kind, cycled *on top of* the existing differential rotation — so the deck now **churns and billows** rather than just sliding. Gas giants get turbulent **storm eddies** (bright ammonia upwellings, dark belt troughs) and a **second counter-sheared high-haze shell** for banded depth. Gas-giant band tones were all mid-browns (one muddy sphere); rekeyed to real Jovian contrast — bright cream zones against rust-brown belts. The **hull cam** now draws atmospheres too (it was showing bare spheres while the cockpit view had weather since 0.8.1).

**Verified (Playwright, zero console errors):** star surface churn 54% pixel delta/frame; gas-giant atmosphere 20% and oceanic 32% delta/frame; forced eruption tracked climbing off the limb; boot 2.2s with 99 live textures; **88 draw calls** at a dramatic star close-up (was 119 before batching); full boot→walk→flight→save/load smoke clean at 89.

**Honest gaps:** 4 frames/surface is a compromise between churn smoothness and boot time (frames are generated, not loaded); no jungle world exists in Sol Prime so that cloud kind is only verified by code path; gas-giant readability still depends on the sun angle (dim when viewed near its terminator — physically right, but a close pass can look muted).

### 16g — reputation drives aggro; atmosphere slowed; CME retinted (build 0.8.9)

Owner feedback on 0.8.8 (slow the atmosphere animation, redo the CME so it fits the environment) plus the faction line the reputation system was missing.

**Reputation now decides who shoots.** Standing only moved prices before — Keth and Drift attacked on sight regardless. `SpaceCombat` gained a `standingOf(faction)` probe (injected from `FactionSystem`) and a `disposition()` rule: **FRIENDLY (≥30)** and **NEUTRAL (≥0)** patrols are *tolerant* — they close, sweep past with a one-time "HOLDS FORMATION — NO LOCK" hail, and never fire first; **WARY** engages at the normal radius; **HOSTILE (≤−60)** hunts you from **1.4× further out**. And the other half, so tolerance isn't a free kill: **firing first on a tolerant patrol provokes the whole squadron** (`provoked` flag propagates to every ship of that faction) and costs **−25 standing** with them plus −4 with Kestrel, with an "UNPROVOKED FIRE LOGGED" warning. Provoked ships attack whatever the standing.
- Fixed a temporal-dead-zone bug while wiring this: `combat.standingOf` was assigned next to the `FactionSystem` construction, ~130 lines *above* `const combat` — a guaranteed runtime ReferenceError. Moved to after `combat` exists.

**Atmospheres slowed 6×.** Cloud decks were cycling at 2.6 frames/s, which read as boiling rather than weather. Extracted `CLOUD_FPS = 0.45` (a ~9-second loop over 4 frames) and `STAR_FPS = 3.2` as named constants — photospheres *should* churn fast (convection turns over quickly), atmospheres should drift. Measured: clouds flip **0.35/s**, star **3.18/s**.

**CME rebuilt to fit the star.** The old plasma used a fixed amber→WARNING_RED ramp on every star, so a blue-white giant threw orange-red blobs — it read as a foreign object stuck to the limb, and the hard red skirt plus a pure-white flare bloom fought the muted palette. Now `plasmaTexture(frame, tint)` builds its ramp **from the star's own spectral colour** (shared `TextureFactory.starTint()`, also used by the corona so they can't drift apart), tinted per class at registration (11 classes × 2 frames, 32px — ~90 KB). The eruption is also tighter and calmer: reaches ~1.6 radii instead of 3.6, shrinks as it fades, dimmer outer wisps (alpha 88 vs 120), tighter cut-off, and the white flare footprint is now the star's own plasma at 0.17× instead of a white glow at 0.3×. It reads as the corona surging, not debris thrown across the sky.

**Verified (Playwright, zero console errors):** disposition probe at four standings — hostile −70 → aggro 9800 + attack, wary −30 → 7000 + attack, neutral +10 → tolerant, stays on patrol, friendly +50 → tolerant, stays on patrol; provocation at +50 standing → 25, `provoked` set, state → attack. Frame rates measured as above. Full smoke (boot→walk→flight→save/load) clean at 89 draw calls; faction and flight suites still pass.

**Honest gaps:** tolerant patrols shadow you but never escort or assist in a fight; provocation decays only through the normal standing economy (no cool-off timer); the Vrenn have no ships in space yet, so their standing still only affects prices.

### 16h — diegetic CRT terminals (build 0.9.0)

Phase 8's second CRT item: the *in-world* screen pass, distinct from 0.8.4's full-frame tube. Where that one filters the whole camera, this one makes each console a monitor **in the room**.

**Built into `interior.frag`, not a separate module.** The roadmap named a `CRTTerminalRenderer.js`, but the screens are already batched into their zone's single draw call — a separate pass would have cost a draw per console for no visual gain. Instead the effect lives in the interior fragment shader and everything works in the **screen's own UV space**, so the scanlines and refresh roll are painted *on the glass* and stay put as the player walks past (a screen-space effect would have slid around and read as a filter).

**Targeted by atlas layer range.** Screens and lamps are both `emissive`, so emissive alone couldn't distinguish them — scanlines on a light strip would look wrong. `TextureFactory` registers `screen_amber`/`screen_phosphor`/`screen_nav`/`screen_off` consecutively, so a new `u_screenCrt = [firstLayer, lastLayer, enabled]` uniform identifies exactly the console glass (verified contiguous at runtime: layers 18–21). Shares the one **CRT SCREEN** setting with `PostProcess`, so both tube effects toggle together.

Layers: aperture-grille scanlines (32 lines up the glass), a rolling refresh bar, mains flicker, random frame dropouts, and a tube vignette on the screen's corners.

**Two things measurement caught that eyeballing wouldn't have:**
1. **The animation was invisible.** First pass measured **0.05%** of the frame changing over time. The uniforms resolved and the clock advanced — the terms were simply too weak (±6% flicker, a 6%-tall bar), and my 500 ms sample happened to land almost exactly one 13 rad/s flicker cycle apart. Slowed the flicker to 3.7 rad/s (a fast wobble averages out to a steady glow), widened the bar and raised the dropout rate; re-measured across five phases → **7.7%**.
2. **Screens were getting dimmer.** Scanline × flicker × vignette all multiply *downward* (~0.62×), so the glass ended ~25% darker — backwards for something that emits. Added a **phosphor drive** (×1.55) *before* those terms, so lit rows come out brighter than the flat texture and the dark rows carry the contrast. Mean frame brightness with the effect on is now **32.3 vs 32.1** off — neutral overall, glowing where it counts.

**Verified (Playwright, zero console errors):** shader compiles, both `u_time` and `u_screenCrt` locations resolve, layer range contiguous, effect confined to screen layers, animation 7.7% across phases, brightness neutral, draw calls unchanged (87–89 — it's inside the existing pass). Full smoke + faction + celestial suites all pass.

**Honest gaps:** I couldn't frame a screenshot that shows the effect off well — the consoles are small, dim props in dark rooms and the notification banner sits across the console bank, so the verification here is measurement rather than a hero shot. Screen *content* is still a static texture (no live per-screen data yet), and there's no per-screen power state, so a "dead" console still scans.

---

## Session 14 — Code Audit + PHASE 6 Combat Core (build 0.7.3)

**Date:** 2026-07-18

Owner: "First do a complex check of code, find problems, errors and if we don't forget something. Then proceed with phase 6."

**Audit (all 90 source files):** syntax clean; no banned neon greens; no TODO debt; full-flow probe (boot → walk → loot → scanner → fly → warp → chase → exit → save) error-free at **41 interior / 82 flight draw calls** (both in budget). Three real findings, all fixed: (1) **`sw.js` cache key was stale at v0.5.0** — deployed PWAs could pin ancient builds; now tracks the version. (2) **SENSORS "CONTACTS" was always 0** — never fed from the live system; now counts hulls in scope range plus hostiles. (3) **The scanner stayed raised when sitting into the pilot seat** — now lowered on entry ("both hands on the yoke").

**Phase 6 combat core** (`src/combat/SpaceCombat.js`):
- **Ship laser cannon**: left-click / X / touch FIRE, amber bolts along the nose, capacitor-limited (7%/shot, recharges) — the capacitor bar finally means something.
- **Two alien ship types with AI**: **Keth fighters** patrol Vega Reach (angular black dart mesh, muted-red strike lines), **Drift drones** hold Twin Suns and the Pale (crystalline shard-cluster mesh, near-white fractal veining per the lore palette). Patrol → aggro inside 7 km ("KETH FIGHTER LOCKING ON") → bore in, jink on a timer, lead their shots. Kills stay dead until the system is re-entered; Redfall stays neutral until reputation lands (Phase 7).
- **Damage model**: enemy bolts hit the shield first ("SHIELD IMPACT"), overflow eats hull ("HULL BREACH — INTEGRITY FALLING"); camera-shake seat rattle on every hit; laser zap / boom / hull-knock synth cues in `AudioEngine`.
- **Explosions**: 26-spark bursts on a kill, and destroyed hostiles drop **faction salvage scooped straight into the hold** ("KETH FIGHTER DESTROYED — SCOOPED PLATING SCRAP").
- **Death & respawn**: hull 0 → "THE AETHON BREAKS UP"; vitals collapse → "YOU DIE ABOARD THE AETHON" (health floor removed — the criticals are lethal now). The death screen offers **[ RECOVER LAST RECORD ]**: restores the last save, floors health/hull/O₂ so you wake breathing, and returns you to the deck.

**Verified in-browser:** warp into Vega Reach aggroes three Keth on arrival; a tracked 5-second firefight kills one (salvage in inventory), shields absorb return fire; forced hull-zero shows the death screen and recovery restores to PLAYING with floors applied; zero console errors.

**What broke / known issues:**
- Player bolt hit-sphere is generous (30 u) by design for 480×270 aiming; revisit if kills feel cheap.
- Enemy hulls reuse the shell projection like everything else — at knife range (<300 u) they can feel size-capped; acceptable at current AI distances.
- Personal (on-foot) weapons and **the Hollow + TensionDirector** are the remaining Phase 6 boxes — the Hollow hooks into the scanner-blip and hidden-state systems already built.

**Next session priority:** the Hollow + TensionDirector (evasion-only, scanner static, no combat-win path — the reason this game exists), then personal weapons.

### 14b addendum — THE HOLLOW (build 0.8.0)

Owner: "Continue" → the Phase 6 centrepiece.

- **TensionDirector + HollowEntity** (`gameplay/TensionDirector.js`, one module per the spec's "single owner of pacing"). The lair, until derelict boarding lands: the **Aethon's own aft wing** (engine room / reactor / cargo / workshop / aft corridors) — but only while the ship rides **Twin Suns or the Pale**. Something came aboard with the salvage. Arm → the player walks into the lair → "THE VENTS GO QUIET." and it wakes in the reactor room.
- **The stalk**: a zone-graph entity that drifts the lair on a 5–9 s clock, drawn faster by noise; every move drops a **scanner blip** and a distant clank, and its proximity **sags the lights** (`setDamageLevel`) and **drowns the scanner CRT in static** — "SIGNAL??" flickers where blips should be, so the information dies exactly when it matters (diegetic, per spec).
- **Never a fight**: no health, no hitbox the laser can find, no defeat state — the checklist item "no combat-win path" holds by construction. Exposed in its zone for ~3 s → **"IT FINDS YOU IN THE DARK"** (death → recover last record). **Crouched and silent** → it lingers over you, then drifts on. Leave the lair for 8 s → "THE SHIP BREATHES AGAIN." Once per system visit; re-arms on the next haunted arrival.
- **Noisemaker Charge** (item 201): USE while it hunts throws a clatter aft and it goes to look; unused when nothing is listening ("YOU WEIGH THE CHARGE IN YOUR HAND. NOTHING IS LISTENING. YET."). Drops from storage racks.

**Verified in-browser:** Twin Suns arms; lair entry activates with the Hollow in the reactor; scanner static reads at range; standing exposed in its zone kills in ~4 s with the right death card; recovery resets; a fresh Pale arrival re-arms; the noisemaker relocated it reactor→workshop. Zero console errors.

**Phase 6 status:** every box checked except personal on-foot weapons (the three guns exist as items; firing lands next).

**Next session priority:** personal weapons, then Phase 7 content (trading, quests, hacking, lore logs via JournalUI — the storyline payload).

---

## Session 13 — PHASE 4: Five Systems, Black-Hole Warp, Stations & Docking (build 0.7.0)

**Date:** 2026-07-17

Owner: "move to next development phase" — Phase 4 (Full Star Systems) per the roadmap — plus a detailed spec for the warp visual mid-session (4 sequences: space deformation + in-falling particles → a black sphere appears at the ship's centre and grows with a spinning accretion disk → it consumes the whole ship → jump to warp speed).

- **All five systems built** from the lore (`context/03` §4) via `CelestialGen.generateSystem` with forced compositions (`planetSpec`): **Sol Prime** (G, colony, Meridian Station + Outer Reach Dockyard + the unregistered-shuttle derelict), **Vega Reach** (B-type furnace, 3 lava + storm giant + ice, Vega Extraction Platform, HIGH), **Redfall** (M dwarf, Verdane jungle world + Kerath city-world, Vrenn Trade Hub, MEDIUM), **Twin Suns** (K+M binary class, tidally torn worlds, THE L4 RELIC ancient station + a Drift-gutted freighter, HIGH), **The Pale** (K-subdwarf, four frozen worlds + THE WANDERER rogue body, THE ARCHIVE 50 km megastructure + KSV LONG SILENCE derelict, EXTREME). New star classes KD/KM; `rogue`, `belt:false`, `comets` knobs.

- **Warp travel with the owner-specced black-hole jump.** `J` key or the WARP button (DOM, touch-friendly) opens the **warp chart** — five systems with star class, danger rating, lore blurb, fuel cost, current-system dimmed. The jump itself is a **4-stage cinematic** on the external camera (explicitly allowed by the camera rule for warp): **infall** — the starfield starts lensing around the ship (post-projection swirl in `stars.vert` `u_bend`) while ember particles stream into the spine; **hole** — a black sphere (hard void disc + white-hot photon ring + dithered glow, `blackHoleTexture`) grows out of the ship's centre as two-thirds of the particles wind into a tilted, spinning **accretion disk**; **consume** — the sphere swallows the drawn hull; then a white-out flash cuts back to the windshield for **streaks** (radial hyperspace lines through the glass) while the system swaps behind the flash. Warp fuel −22%/jump; jump blocked when low; seat exit blocked mid-sequence.

- **Stations, docking, refuel, derelicts.** Stations/derelicts ride the `ships` render path (freighter hull at 3–7× scale, stations roll slowly, derelicts tumble adrift) and register in `StarSystem.approach`, so the NAV panel pops with **DOCK / INSPECT**: docking at a refuel station tops off sublight + warp tanks; the relic/Archive answer with tone text instead ("the doors are open anyway"); derelicts log a boarding survey. This also seeds the storyline: every station and derelict carries a lore line, and the route's danger ratings sketch the arc Sol Prime → The Pale.

**Verified in-browser:** warp chart renders all five; full jump Sol Prime → Redfall (warp fuel 64→42) with every stage screenshotted (bend + infall, disk + hole, hull half-consumed, streaks + arrival banner); docked at Vrenn Trade Hub → fuel 100/warp 100; zero console errors.

**What broke / known issues:**
- Planet **rings** (the one unchecked Phase 4 item) still pending.
- The black sphere reads mostly by its photon ring + disk against dark space at 480×270 — good, but a screen-space lens pass (bending the *rendered* image, not just the starfield) would sell stage 1 harder; deferred.
- Station hulls reuse the freighter mesh at scale; bespoke station/relic silhouettes are a next-content item.
- Arrival always at the system's shipStart (near the flagship world); no per-target arrival points yet.

**Next session priority:** Phase 5 gameplay core (survival stats, inventory, save terminal) or deeper Phase 4 content (planet rings, bespoke station meshes, faction ships patrolling their systems, live NAV range) — owner's call; storyline threading continues either way.

### 13b addendum — PHASE 5 core: items, inventory, loot, saves (build 0.7.1)

Owner: "yes continue" → Phase 5 per the roadmap.

- **143-item registry** (`ItemRegistry.js`, context/04 §3 schema): rations/drinks/meds, ship consumables (fuel cells, warp condensate, O₂, shield/hull/power), eight ores in three grades, crystals (up to the Drift Core Shard), salvage, components, tools, placeholder weapons + ammo, ancient artifacts (the Archive Access Sliver "wants to go home"), log chips, trade goods per faction, and twelve personal effects for mood (MERCER's tags; the Key to Nowhere). 143 of the 200 target — honest count; Phase 7 expands anyway.
- **Inventory** (`Inventory.js`): 120 volume-slots, kg tracking, stacking with maxStack, category grouping; **HOLD MANIFEST** UI (`InventoryUI.js`, `I` key or BAG button, touch-first DOM) with per-item USE.
- **Loot**: searching any crate/locker/cabinet/rack rolls a seeded table (`Loot.js`) **once per container** — first press yields "FOUND: …", subsequent presses fall through to the prop's own flavor line. Central hook in `PlayerController` (`game.tryLoot`), so no dressing file needed changes.
- **Item use** routes through `ShipSystems.applyItem` (eat/drink/med/breathe/refuel/ship repairs) with a HUD delta report. **Fatigue** added as the 7th vital; critical thresholds now bite (thirst<20, rad>60, O₂≈0 → health drain, floored at 1 until Phase 6 death).
- **Saving** (`SaveSystem.js`): the diegetic **SaveTerminal ritual** (chunk sound + "PROGRESS RECORDED") and a quiet 60 s autosave write one versioned localStorage snapshot — current system, ship pose, player pose, all vitals/tanks, inventory, and searched-container keys. Restored on boot ("SURVEY LOG RESTORED"); fresh boots get a starter kit instead.

**Verified in-browser:** starter kit granted; locker looted once then correctly inert; water pouch use lifted thirst 74→100 with report; terminal ritual wrote the save; full reload restored thirst/inventory/searched state exactly. HOLD MANIFEST screenshotted. No game errors (one probe-artifact fetch cancel from reloading mid-boot).

**Known gaps:** fatigue not yet on the HUD; no bunk-sleep to restore it; scanner/hiding still open; item pickup is container-search only (no world-floor items yet).

**Next:** HUD fatigue + low-stat alerts, bunk sleep, proximity scanner; or Phase 6 threat (Hollow) — owner's call.

### 13c addendum — PHASE 5 COMPLETE: scanner, noise/hiding, full HUD, bunk sleep, 200 items (build 0.7.2)

Owner: "Finish phase 5."

- **Proximity scanner** (`ProximityScanner.js`, context/04 §5): TAB (or the SCAN touch button) raises a handheld device that fills the lower view — a round **terminal-phosphor CRT** (allowed: diegetic screen, never the HUD) with range rings, a fixed-interval sweep arm, CRT speckle, and fading **blips for anything that moves** (door cycles now; the Hollow will feed the same channel). The attention cost is real: movement drops to 55% while it's up. Battery drains ~0.9%/s raised, dies in your hand at 0, and **any powered console recharges it** ("SCANNER CELL CHARGED").
- **Noise & hiding** (`NoiseSystem.js`, §6): footsteps pulse a noise level by movement state (crouch < walk < sprint) and surface; door hydraulics spike it; it decays fast. The SENSORS panel gained an **NSE meter** that reads **HIDDEN** when crouched with the floor settled — a general stealth state built for every Phase 6 threat, not just the Hollow.
- **Full helmet HUD** (context/05 §1): VITALS now shows **all seven stats** — HP, O2, FOOD, H2O, RST (fatigue), HEAT, RAD — with warn thresholds, plus a **flashing critical-alert strip** under the compass (LOW O2 / DEHYDRATION / STARVATION / EXHAUSTION / RAD SICKNESS).
- **Bunk sleep**: interacting with any bunk while tired restores rest to 100, costs a little food and water, and autosaves — "YOU SLEEP. THE SHIP HUMS ON WITHOUT YOU." Not tired → the prop's own flavor line runs instead.
- **Registry at exactly 200 items**: added refined alloys, electronics salvage, exotic gases (Vega volatiles), **Keth/Vrenn/Drift faction salvage** (the Drift Logic Wafer "the Archive might read"), planetary minerals, extra galley stock, and field equipment (scanner cells, suit patches, chem flares, glow tape).

**Verified in-browser:** scanner raised with a live door blip, battery drain and console recharge confirmed; bunk rest 30→100; DEHYDRATION · RAD SICKNESS strip flashing with the H2O bar in warn state; 7-bar VITALS + NSE meter screenshotted; zero console errors. Phase 5 roadmap: every box checked.

**Next session priority:** Phase 6 — Combat & Threat: the Hollow (evasion-only) + TensionDirector, personal weapons, ship laser, Keth fighters/Drift drones, death & respawn. The scanner static-degradation near the Hollow (context/03 §6) hooks straight into the new blip channel.

---

## Session 12 — Kill the Black-Round Occluder, Bigger Worlds / Smaller Chase Ship, Richer Planets (build 0.6.6)

**Date:** 2026-07-17

Owner: "You didn't fix the black round covering the view on bodies when turning — like a shadow, maybe cockpit parts. Bodies still aren't bigger, not even close — or make the ship look smaller in third person than first. Then complex texture enhancements: more detail, depth, realistic look."

- **Black-round root-caused and fixed.** It wasn't a shadow or a seat — it was the **sky-sphere projection**. Every body is drawn on a sphere of radius `SKY_RADIUS` scaled by `k = SKY/dist`; as the ship nears a body the drawn radius reaches/exceeds `SKY_RADIUS` and the sphere **engulfs the camera**, so its dark side smears across the whole view as a black disc that sweeps when you turn. Two guards: (1) **cap the projected radius** at `SKY_RADIUS*0.72` so the camera is always outside the disc — a close world now fills most of the view as a real lit sphere, never a black mass; (2) **body collision** (`StarSystem.collide`, includes the star) — a spherical hitbox pushes the ship back to the surface and cancels inward velocity, so you can never get closer than one radius (the exact condition that broke the projection) and worlds are solid now. Night-side fill nudged 0.42→0.5 so dark limbs read as dim spheres.

- **Worlds much bigger, chase ship smaller.** Body render scale ~2× (`KM_PER_UNIT` 30→14): colony 256u→**549u**, gas giant 2422u→**5191u**, ice giant→1725u, star 1400u→**2600u**. Spawn pulled in to `radius*1.9+500` so the colony is a **big disc dead ahead at start (~22°)**, not a speck. And the Aethon is drawn at **0.55×** in the chase cam (`SHIP_CHASE_SCALE`) so the worlds it flies past dwarf it — verified: the ship is now a small craft beside a large planet, exactly the requested read. Orbits unchanged (still real-AU spaced); no overlaps.

- **Richer, more realistic planet textures.** Rebuilt `planetTexture` at **256×128** (was 128×64) with layered detail: oceans get depth-shaded seas + beige coastlines + green continents + mountains + a swirling **cloud deck**; gas giants get **domain-warped turbulent bands** + a great storm oval + festoon striation; rocky/desert/moons get a deterministic **crater field** (rimmed impact rings) + maria + ejecta flecks; ice gets fracture veins + frost mottle; lava gets a branching **glowing-fissure network**. Still chunky shade-stepped, seamless in longitude, no smooth gradients.

**Verified:** collision pushes a ship placed at a gas-giant's centre back to its surface; close-range full-rotation spins show a lit sphere, no black round; spawn shows a big colony world; chase shows a small ship beside a big planet; error-free.

**What broke / known issues:**
- The NAV RANGE only refreshes on first entry into a body's approach sphere (stale until you leave/return) — cosmetic, worth a live-update pass.
- Chase ship at 0.55× is a deliberate "looks smaller than it is" cheat (owner-sanctioned); if it now reads *too* toy-like it's a one-line dial.
- Comet tails / eccentric orbits and a star-class-tinted sun still pending; landing is still the NAV pop-up (no surface scene).

**Next session priority:** live NAV range; star-class-tinted sun + comet tails; a real landing/surface scene; then the other four systems + `WarpEffect`.

### 12b addendum — camera-centred shell + eclipse rim (build 0.6.7)

Owner (device screenshot, chase view): "still bugging with blackening, and I don't like the bodies magnifying when moving and turning."

- **Root cause of the warp/"magnify":** bodies were projected onto a sky shell centred on the **ship**, but the chase camera rides up to ~58 u away from the ship — from the camera's actual position every body's direction and angular size were wrong, and turning swept that parallax error across the view (bodies stretched/slid/"magnified"). **Fix: `_shellProject` centres the shell on the camera eye** in both render paths (first-person seat eye included). Angular size and direction are now exact from wherever the camera really is; turning changes nothing; approach growth is physical.
- **Radius cap removed** — with an eye-centred shell the drawn radius is always `SKY/1.06 < SKY` (collision keeps the ship a radius out; `_shellProject` also floors the distance at 1.06 r for the chase eye near small moons), so the engulf/black-round is geometrically impossible and the size freeze/jump the cap caused is gone.
- **The remaining "black round" in the owner's screenshot was an eclipse silhouette** — a night-side moon in front of the sun's corona. Added a **backlit atmosphere rim** to `space.frag`: when a body sits between camera and star, its limb gets a strong forward-scattered glow ring, so it reads as a world eclipsing the sun, never a black hole punched in the view.

**Verified:** chase full-rotation spin at 2.5 radii from the colony — the disc slides across frame with constant curvature, no warp, no blackening; the eclipse scenario (moon dead-centred on the sun from its night side) shows a dim lit sphere with the sun blazing behind it; error-free.

**Owner's next direction:** move to the next development phases — tons of content, features, more mechanics, and a storyline.

---

## Session 11 — Rule-Based Realistic Star System + Deeper Interior Textures (build 0.6.5)

**Date:** 2026-07-17

Owner ask: "resize celestial bodies, create a set of rules for every body type (stars/main sequences, gas giants, moons, planetoids, comets, asteroids…), realistic distances in real units, bodies can't be so close together, write new star-system generation rules… and enhance interior with much more heavily pixelated textures with more detail and depth per part." Plus: "blackening is much better, fix it more."

- **Star systems are now generated from real astronomy rules** (`src/data/CelestialGen.js`). Star classes O–M + red giant + white dwarf (real radii/temps/colours). Body archetypes — lava, desert, rocky, ocean, jungle, super-Earth, ice, ice/gas giant, dwarf, moon, planetoid — each with **real km radii, surface gravity, temperature and atmosphere**, chosen by the star's habitable zone (`sqrt(luminosity)`). Orbits laid out on a **Titius–Bode-like geometric ladder at real AU** so bodies are genuinely far apart, not clustered. Giants get moons; an **asteroid belt** (11–17 planetoids) sits ~2.5× the HZ radius out; **1–2 long-period comets** ride steep outer orbits. `SOL_PRIME` is now `generateSystem({starType:'G', habitableName:'AETHON', colony:true})` — the ocean colony still shares the ship's name.

- **Sizes are diverse and real.** Scale is compressed-but-proportional: `KM_PER_UNIT=30`, `UNITS_PER_AU=12000`, so ratios and NAV labels are real even though the absolute clock is game-tuned (full AU would leave every body an invisible speck). Range runs ~13u planetoids → ~2400u gas giants; stars are cube-root-compressed so a proportional Sun doesn't swallow the inner orbits. **NAV landing panel now shows real units:** RADIUS km, ORBIT AU, GRAVITY g, TEMP °C, RANGE km. Flight speeds raised (thrust 42, boost ×5, soft-max 1400) for the larger interplanetary distances.

- **Blackening improved again.** Raised `PLANET_FILL` 0.34→0.42 and exterior hull fill 0.7→0.8. Verified in the chase cam: the Aethon hull renders clearly lit grey-blue at rest with a body in frame; planets show a clean star-tracked terminator (gas-giant crescent confirmed). Night sides stay legitimately dark (real terminator, not a bug).

- **Deeper interior textures — more detail + depth per part.** New reusable `Painter` primitives: `insetPanel()` (machined recessed sub-panel with beveled lit/shadowed rim + corner bolts), `raisedTrim()` (proud frame/handle), `speckle()` (sparse single-colour micro-wear, no borders → heavy-pixelated grain without the "field of dots"). Applied across walls (military/steel/engine/reactor), ceiling (every tile a recessed panel), floor (bolt-down access plate), doors (recessed viewport + kick-plate) and consoles (recessed instrument bank with proud keys). `NORMAL_STRENGTH` 1.7→2.05 for deeper relief. Verified: junctions/cockpit/engine/cargo read as bolted, sectioned, deep industrial surfaces, error-free.

**Verified:** generated system dumps 33 bodies (incl. moons) with real km/AU across ~4k–610k u; NAV popup shows real units for planet/asteroid/moon; chase-cam hull lit; interior depth clearly visible in probes; all textures build; no console errors.

**What broke / known issues:**
- Comets are dormant icy nuclei with **no tail/coma** yet (tails only near perihelion; StarSystem orbits are circular). Eccentric orbits + tail render are future work.
- Asteroid-belt and dwarf/comet bodies are small specks at distance (realistic) — a sensor/labeling pass would help find them.
- Star colour/temp are carried on the record but the sun billboard isn't tinted by class yet; landing is still a NAV pop-up (no surface scene).

**Next session priority:** star-class-tinted sun + a real landing/surface scene; comet tails + eccentric orbits; then the other four star systems + `WarpEffect` travel.

---

## Session 10 — Detailed Plastic Textures, Planet-Winding Fix, Chamfer + Decor (build 0.6.3)

**Date:** 2026-07-16

Course-correcting Session 9's flatten (owner: "I don't want flat-pixel style") plus a real celestial bug.

- **Celestial bodies going black in the chase cam — root-caused and fixed.** Not a fill problem: the planet **sphere was wound inside-out** (front faces pointing inward), so the back-face cull added for the Session-7 wedge fix was culling the *near* hemisphere. On a body's night side (camera opposite the star) only the atmosphere rim survived → the disc read as black. Reversed the sphere winding so standard back-face culling shows the outer surface: the near hemisphere always renders now, no wedges, from every angle. Night-side fill back to a modest 0.34 (real terminator) with slightly brighter planet ramps so shadowed sides stay readable. Verified: Aethon is a full solid world on its night side in the chase cam and first-person.

- **Textures: detailed + plastic again, NOT flat 3-colour.** Session 9 over-flattened. Kept the win (no Bayer dither grain, no white/black highlight borders) but restored richness: `RAMP_STEPS` 7→14 and `PIXEL_BLOCK` 2→1 (full per-texel detail across many clean single-colour shades → smooth, detailed gradients, not 3-colour blocks); restored 3D plasticity via **diffuse** relief (`NORMAL_STRENGTH` 0.5→1.7 for real bolt/panel/seam depth) plus a **broad, weak specular** (power 16, strength 0.06) that reads as a gentle plastic sheen, never a hard border.

- **Less-squared + more decoration (first slice).** New `PropBase.chamferTop()` bevels box top edges; cargo crates use it so stacked cargo isn't plain cubes. Bumped room greeble density (denser sci-fi wall detailing; corridors stay clean).

**Verified:** planets render solid from all angles (chase + first-person), no wedges; bunks/core walls read detailed and plastic with depth and no grain/borders; crates chamfered; build smoke clean; error-free.

**What broke / known issues:**
- De-square + decoration is a first slice — more props still need rounding (lockers/tables/tanks octagonal, arched doorways) and more decorative elements can be added; ongoing.
- `PIXEL_BLOCK` is 1 now (detailed); if the owner wants *chunkier* pixels that's a one-line bump, but it trades away detail.
- Flickering-light corridors (corr_b) are intentionally dim; texture detail is hard to judge there.

**Next session priority:** continue de-square (octagonal tanks/lockers, arched door frames) + more decoration; then a real landing/surface scene and the other four star systems + `WarpEffect`.

---

## Session 9 — Flat Chunky Textures, Hull-Visible Chase Cam, Smooth Dynamic Body Shadows (build 0.6.2)

**Date:** 2026-07-16

Owner feedback from a device video + close-up screenshot.

- **Texture style reworked to flat chunky pixels (no grain, no borders).** The owner hated the fine Bayer-dot grain and the white/black highlight borders on every surface. `ditherFill`/`ditherOver` now paint **flat `PIXEL_BLOCK`-sized colour blocks** snapped to a **7-shade expanded ramp** — chunky flat pixels with smooth shade steps, no checkerboard. Killed the per-texel **specular** (`SPEC_STRENGTH` 0) and cut **normal-map strength** 2.4→0.5 so bolts/seams no longer get outlined. Interior **lighting is no longer Bayer-dithered** — smooth banding at 22 levels reads as a gradient over the flat texels. Bunks/core/cargo now read as clean flat surfaces with smooth shading. (Still outstanding: per-segment *unique* textures to break tiling repetition — deferred; the flatter look already makes tiling far less obvious.)

- **Piloting black-out (chase cam) actually fixed this time.** The 0.6.1 `CHASE_NEAR` fix stopped the camera entering the hull, but the video showed the real remaining issue: whenever no planet was in frame the hull was a near-black silhouette against black space. Brightened the hull plating (steel ×1.5) and raised the exterior **fill 0.55→0.7**, so the shaded side stays a clear grey while the star still drives a visible light/dark gradient. The ship now reads from every orientation.

- **Smooth dynamic day/night on bodies.** Dropped the Bayer grain from the space shader's lighting and raised levels 5→14: planets show a **clean terminator that tracks the home star**, and because the surface texture spins while the shadow stays star-fixed, features rotate through day/night (the "realistic shadow by rotation + star" the owner asked for).

**Verified:** interior surfaces flat/clean with smooth shading (no dots); chase-cam hull clearly lit at all orientations; planet terminators smooth; all textures build; error-free at **41 interior / 59 space** draw calls.

**What broke / known issues:**
- The reported roof holes still could not be reproduced in-engine; 0.6.1's space-skip should mask them. Need an on-device check on **0.6.2**.
- `PIXEL_BLOCK` is 2 (32² effective texels) — trivially tunable up if the owner wants even chunkier pixels.
- Per-wall-segment texture uniqueness (anti-repetition) not yet done; wants a bigger texture-variant/tint pass.
- Landing is still a pop-up placeholder (no surface scene).

**Next session priority:** per-segment texture variation (kill tiling repetition), a real landing/surface view, then the other four star systems + `WarpEffect` travel.

---

## Session 8 — Third-Person Fix, Interior Space-Leak Robustness, Living Star System + Landing (build 0.6.1)

**Date:** 2026-07-16

- **Third-person view black-out fixed.** `CHASE_NEAR` sat at z=10 but the hull's nozzles reach z≈16.5, so the zoom-out transition *began with the camera inside the ship* — the view filled with the dark hull and read as a black-out when toggling/moving. Moved `CHASE_NEAR` clear of the hull (z=26), pulled `CHASE_FAR` to 54 for space around the ship, and raised the exterior fill 0.42→0.55 so the shaded side never goes pure black.

- **Interior no longer leaks space through stray gaps.** A full audit (every zone, doors open, all grazing angles, space disabled) found the hull **watertight here — 0% leak everywhere** — so the roof holes the owner still sees on device are a GPU-specific thin-quad dropout, made glaring only because the starfield was drawn behind the interior. Fix: render space behind the interior **only where it's visible** — seated flight (windshield) or standing in/next to the cockpit (the one windowed room). Everywhere else the sealed interior already covers the view, so any dropout now shows dark hull instead of stars (and walking drops from 54→41 draw calls). If holes persist for the owner, it's worth a hard-reload — the deployed build must be 0.6.1.

- **Living star system.** `StarSystem` now **orbits every body** around the star (Kepler-ish r^1.5 periods, compressed so inner worlds visibly lead) and **orbits moons** around their planet; spin stays separate. Sol Prime's bodies gained class / atmosphere / gravity / temperature / description metadata and **five moons** (Aethon's Lyra; Brunt I/II/III; Cinder's Ash), all rendered.

- **Approach + landing pop-up.** `StarSystem.approach()` gives every body a hitbox (≈2.6 radii + 400u). New `CelestialInfo` DOM panel: fly into a body's sphere and a diegetic amber NAV readout slides in with its class + data and **LAND / SCAN** and **LEAVE** options. Surface ops are a logged placeholder for now (the pop-up is the deliverable the owner asked for).

**Verified:** third-person transition + all orientations no longer black out; walk interior fully sealed with space skipped; cockpit windshield still shows space; flight bodies + 5 moons render; approach pop-up shows correct per-body data. Error-free at **41 interior / 59 space** draw calls.

**What broke / known issues:**
- The owner's roof holes could not be reproduced in-engine (SwiftShader) even with an exhaustive sweep; the space-skip should mask them regardless. Need an on-device confirmation on 0.6.1, and the exact room if any remain.
- Landing is a placeholder pop-up — no surface scene yet.
- Orbital periods are compressed for play, not physical; bodies drift over minutes.

**Next session priority:** surface/landing scene (even a simple orbital or landed view), the other four star systems + `WarpEffect` travel between them, then rings + asteroid fields + dockable stations.

---

## Session 7 — Retro-Future Repalette, Roof/Celestial Fixes, HUD Instruments, De-square (build 0.6.0)

**Date:** 2026-07-16

Six owner-reported items from mobile screenshots.

- **Celestial bodies broke into shifting geometric wedges in flight — fixed.** The space passes render with no depth test (painter's sort), so a planet sphere's far/dark hemisphere overwrote its near face in index order; the terminator shattered into hard wedges that moved as the ship rolled (the "squared shadow made by the ship"). Enabled **back-face culling** around the planet-sphere draws in both the seated and external-hull passes — convex spheres now show a clean terminator from every angle.

- **Missing roof over arch/hex corridors — fixed.** The sloped vault quads in the arch (corr_a) and hex (corr_d) corridors were wound so their normals faced up/out, so they were **back-face culled from below** and read as a missing roof at a glance (straight-up probes hit the correct apex strip and missed it — which is why Session 5 thought it was sealed). Reversed the winding; corridor A is now a solid grey vault.

- **Interior repalette to retro-future — the industrial green is gone.** `METAL_DARK` (most walls) goes green→cool blue-grey steel, `PANEL_STEEL` brightens to a cleaner blue-grey, `FLOOR_GRIME` goes green-brown→neutral charcoal, and `RUST` desaturates to muted grey-brown staining (aged, not industrial). Added a `PANEL_WHITE` accent. Diegetic CRT screens stay phosphor-green and machine accents stay amber (the allowed decorative colours). Verified across bunks/core/engine/cargo/corridors: walls read grey/blue-grey.

- **Props no longer jut into corridors.** Corridors and junctions now take only flat wall-hugging greebles (signs/vents/breakers/monitors), sparser, with no overhead conduit runs — the horizontal pipes/boxes that stuck into the walkway are gone from transit spaces (rooms keep the full deep detail).

- **HUD enhanced + themed, touch controls resized.** Added viewport **corner brackets** to both modes (helmet visor edge on foot, cockpit glass in the seat). Flight gains a **cockpit instrument cluster**: an **attitude horizon** that banks with roll and slides with pitch (+ pitch ladder and fixed waterline), a **vertical throttle quadrant** with a centre detent, and a small circular **NAV sweep scope** — all composed from pixel rects in the existing 2D pass (no new draw calls). Touch controls: smaller joysticks, compact rounded amber buttons that wrap and cap width so they clear the HUD panels.

- **De-square, first pass.** HUD panels get 2px cut corners (bevel follows the rounded outline); new `MeshBuilder.prism()` builds N-sided vertical prisms and the reactor core is now an **octagonal shaft** instead of a blunt box. More rounding (chamfered furniture, arched doorways, octagonal tanks) is queued for the next pass.

**Verified:** interior build smoke clean; browser walk (bunks/corridors/junctions/reactor), seated + third-person flight, and touch layout — **zero console/WebGL errors, 48 draw calls interior / 54 space**; planets render as clean spheres, corridor roofs sealed, walls grey, attitude horizon tracks a banked ship, reactor core octagonal, touch strip clear of the HUD. No banned neon (screens amber/phosphor).

**What broke / known issues:**
- The reported "flickering textures" couldn't be reproduced in captured frames (it's temporal z-fighting); reducing the overlapping greeble geometry in transit spaces should help — flagged to confirm on device.
- De-square is a first pass — most furniture is still boxy; the prism helper and a chamfer pass will extend it.

**Next session priority:** finish the de-square pass (chamfered furniture, arched door frames, octagonal tanks/canisters), then continue Phase 4 — planetary rings, the other four star systems + warp travel, asteroid fields, dockable stations.

---

## Session 6 — Celestial Fix, Live Ship Systems + Compact HUD, Interior Decoration

**Date:** 2026-07-16

Three owner-requested things, then a decoration pass.

- **Celestial bodies no longer render as black discs (and don't lag).** In third person the planets were showing as solid dark circles the exact size/shape of the body. Root cause: the planet night-side fill floor was `0.05`, so the unlit hemisphere crushed to near-black and read as a filled disc against the starfield. Fixed in `space.frag` + `SpaceRenderer`: a per-body fill uniform (`u_fill`, planets 0.30) lifts the dark side to a legible sphere with a real terminator, and a quantized **atmosphere rim** (`u_atmo`, day-biased Fresnel, per-body colour: oceanic/rocky/ice/lava/jungle) wraps the lit limb so bodies read as lit spheres, in both the seated and external-hull views. Committed `f079672`.

- **Live ship systems drive a rebuilt, compact HUD.** New `ShipSystems.js` — a per-frame survival/ship model (fuel, power, shield, hull, warp fuel, O2, heat °C, radiation, contacts) that responds to thrust/boost/zone (reactor & engine rooms push heat + radiation, boost draws power, fuel burns with thrust, shield trickle-regens). `HUD.js` fully rewritten: shrunk, bezeled **3D panels** (lit top/left, shadowed bottom/right, corner rivets) with recessed segmented bars — a VITALS cluster (HP/O2/HEAT/RAD) bottom-left, a SHIP cluster (FUEL/PWR/SHLD/HULL) bottom-right, and a SENSORS/contacts readout top-left — all wired to the live model (values visibly track in play). Notifications lifted above the new console panels. Committed `0092c67`.

- **Interior props + a big sci-fi decoration pass.** Audited every prop collider against its room shell: one real offender — the crew-quarters **sink poked 0.25 m through the aft bulkhead** and floated 0.4 m off its wall — repositioned flush into the west wall, clear of the door bulkhead. Extended `Greebles.js` with **layered, deeper detail** (gauge clusters with proud instrument bezels, twin-pipe valve manifolds with a wheel, staggered-depth cable trays, muted-amber readout monitors in deep bezels, ribbed duct junctions) plus an **overhead pass** — cable/conduit runs slung under the ceiling of every tall room with cross-ties, so the overhead reads as machinery. Density bumped; each kind carries a top-reach so nothing pokes a low ceiling. Also fixed **mirrored baked text** on `-z`/`+x`-facing screens (a `flipU` in `MeshBuilder.quad`, verified: the Computer Core terminal reads correctly now).

- **Reactor-room "void" was a false alarm — do not chase it.** A magenta/space-through-walls artifact only reproduced when a probe teleported the camera *inside* the emissive reactor-core column or into an unsettled physics state (eye at y≈5.3), where the near-clip plane sliced the shell. From any settled standing spot the reactor is fully enclosed (east wall with RAD stencils, ceiling, floor all present — mesh is 598 shell tris, browser count matches node). Lesson baked into the probe scripts: **teleport, let physics settle ~850 ms, stand clear of props** before judging geometry.

- **Phase 4 started — richer planets + a complete Sol Prime.** `planetTexture` gained four new biomes beyond oceanic/rocky — **ice** (pale blue-white, bright caps, fracture veins), **lava** (dark basalt with glowing molten fissures), **gas** (latitude-banded giant with turbulent storm ovals), **jungle** (green landmass for the later Redfall worlds) — all still 2–3-tone Bayer-dithered, seamless across longitude, no smooth gradients. Wired all six into `space.tex.planets`; added a warm-haze atmosphere rim for `gas`. Sol Prime filled out from 2 → **its full 8 worlds** (EMBER lava · BRUNT gas giant · HALE ice · TESSERA rock · CINDER · AETHON · GELID ice · VIGIL rock), spread across x/y so the field never reads as a line. Verified in flight: each new world renders correctly through the windshield and in the external hull cam, still error-free at 54 draw calls (space budget 100). Rings, the other four systems, warp, asteroid fields, stations and travel timers remain for the next Phase-4 sessions.

**Verified:** interior build smoke (24 zones + 15 door panels, ~14.5k tris, reactor 598→778 tris from greebles, no build errors); prop-collider audit **0 penetrations** after the sink fix; browser runs — walk through bunks/cargo/engine/research, seated flight, third-person toggle both ways — **zero console/WebGL errors, 48 draw calls** interior and flight (decoration folds into the per-zone batch, no new draws). Planet renders as a lit sphere with atmosphere in third person; ceiling conduits visible in cargo/engine; no banned neon (screens use muted amber/phosphor).

**What broke / known issues:**
- Wall greebles are weighted-random within free runs; density is higher now but still tasteful — tune via weights/chance in `Greebles.js`.
- Engine room is intentionally dim, so its overhead conduits are subtle; cargo bay shows them clearly.
- `ShipSystems` heat/radiation/consumption curves are first-pass game-feel numbers, not balanced survival tuning (that's Phase 5).

**Next session priority:** Continue Phase 4 — planetary **rings** (opaque banded annulus, depth-sorted with its planet), the remaining **four systems** (Vega Reach, Redfall, Twin Suns, The Pale) as data + stars, **`WarpEffect` + system travel** so those systems are reachable, then asteroid fields, dockable stations (dock/refuel), scale + travel timers.

---

## Session 5 — Lighting, Settings, Roof-Seal, Third-Person Pilot View

**Date:** 2026-07-15

Four owner-requested changes (build 0.5.0):

- **Turning sensitivity + a Settings menu.** Base look sensitivity raised (0.0021→0.0034 rad/px) and flight steer (0.0011→0.0017). New `Settings.js` (localStorage-persisted) + `SettingsMenu.js` — a DOM overlay of amber slider "bars" and toggle buttons: look sensitivity, flight sensitivity, invert-Y, brightness, master volume, FOV, with RESET/DONE. Opened from the pause screen, a ⚙ gear button (mainly for touch), or Esc/P. Every system reads Settings live (camera sens/invert/FOV, flight sens/invert, interior brightness uniform, audio master gain).

- **Brighter ship; dark reserved for derelicts; damage light-failure.** The Aethon now reads as *lit* — ambient 0.08→0.26, ceiling tubes 0.7→1.15 intensity / 4→6.5m radius, distance-murk floor 0.3→0.6. The old oppressive 0.08 is kept as `LIGHTING.AMBIENT_DERELICT` for later wrecks/enemy hulls. `LightSystem.setDamageLevel(0..1)` deterministically kills/stutters a fraction of the warm ceiling mains as hull damage rises (wired for combat later; emergency/glow lights stay on separate buses). Brightness is also a live Settings slider (`u_brightness`).

- **Sealed roof holes at door frames + corners.** Diagnosed with a magenta-void probe: thin-plane lintels above doorways vanished edge-on and showed space behind. Fixed with **solid box lintels** (real depth, up to the taller of the two adjoining ceilings) and a continuous **wall-top cornice** overlapping every wall↔ceiling seam. Probed straight-up in crew quarters, junctions (incl. corners), cargo bay, reactor, arch/low corridors and height transitions — zero magenta void anywhere.

- **Third-person pilot view + ultra-detailed Aethon exterior** (owner-requested design change; **CLAUDE.md camera pillar amended** — walking stays strictly first-person, piloting gains an optional hull cam). `ShipExterior.buildAethon()` — a cruciform survey vessel (~1.2k hull tris + 540 emissive tris): segmented paneled fuselage, cockpit canopy with lit windows, four cruciform radiator wings, 3 glowing engine nozzles, comms dish, sensor masts/antennas, hull conduits, raised panels, and rows of emissive windows/running lights. New `Mat4.lookAt`, `space.frag` fill-light uniform, `SpaceRenderer.renderExterior()` (world-frame chase render: stars, sun, planets, lit hull + emissive glow). `V` / touch VIEW button toggles a chase camera that lerps out from the hull (zoom-out reveal) and back; the ship keeps flying and the cam follows its bank.

**Verified:** smoke (11554 interior tris, exterior mesh valid, spawn clear); browser walk, iPad-touch boarding, seated flight, settings open/persist/close, and third-person toggle both directions — all zero console/WebGL errors, 48 draw calls interior. Checklist greps clean (no neon green, no phosphor on HUD, PlayerCamera still the only camera *class* — the chase is a piloting view mode, not a walking camera).

**What broke / known issues:**
- Third-person chase is a fixed behind/above follow (no free orbit yet); mouse still steers the ship. Fine for a hull cam; free-orbit is a later nicety.
- Exterior sunlit side can be dim when flying toward the sun; a 0.42 fill keeps the whole hull readable. No exterior collision — third-person is a view only.
- The old `flight-test.mjs` walk-navigation script is timing-flaky (lands in J1 sometimes); direct-entry flight + view verified clean in `thirdperson-test.mjs`.

**Next session priority:** Phase 4 — Full Star Systems (PlanetRenderer rings/atmosphere, warp, asteroid fields, dockable stations, travel timers), now that the exterior model exists for docking/warp cinematics too.

---

## Session 0 — Planning (this bundle)

**Date:** 2026-07-12

**What happened:** Authored the full instruction bundle (`CLAUDE.md` + `context/*` + `.claude/rules/*`) from the STARRIFT v2 master prompt and 17 pieces of concept art. No game code written yet.

**Key decisions locked in:**
- Flight moved from third-person pull-back to first-person seated — see `context/02` §3.
- Two rooms added (Research Lab, Computer Core) — see `context/03` §2.
- New rare threat, "the Hollow," added for evasion-only tension — see `context/03` §6, `context/04` §8.
- New corp identity, "Kestrel Extraction & Salvage Co." — see `context/03` §3.
- Terminal-phosphor-green palette added for diegetic screens only, kept off the player HUD — see `context/01` §2.

**Known open questions (also in `CLAUDE.md`):** Hollow encounter frequency; whether to keep the "STARRIFT" title; localStorage vs. IndexedDB if save size grows.

**Next session priority:** Phase 1 — Engine Foundation (`context/07`).

---

## Session 1 — Engine Foundation + Full Walkable Interior (Phases 1–2)

**Date:** 2026-07-13

**What shipped:**
- Complete engine foundation: `Engine` (fixed 60Hz loop), `Renderer` (WebGL2 at a true 480×270 backbuffer, CSS pixelated upscale), `InputManager` (pointer lock + action map), `StateManager` (LOADING→GATE→PLAYING↔PAUSED), `EventBus`, `Constants` (full context/01 palette + every tunable), custom `MathUtils` (vec3/mat4, no libraries), seeded `RNG`, value-noise lib, `ObjectPool`, `Debug` overlay (backquote).
- `TextureFactory`: 42 procedural 64×64 textures — 4×4 Bayer ordered dithering throughout, material dither language per context/01 §4, downward rust streaks, Kestrel stencils, hand-written-note details, the sepia ship-schematic poster, emissive screens (amber, phosphor, nav, starfield).
- `PixelFont`: AMBER-9 (bold slab) + TERM-MONO-7 (plain mono) generated from one embedded 5×7 glyph set; used for HUD, screen content and texture stencils.
- `LightSystem` with the exact context/02 §6 flicker patterns; per-zone light sets (≤8/draw); dither-quantized lighting + distance darkening in the interior shader; helmet spotlight per spec.
- Full HSV Aethon: all 13 rooms + airlock per the context/03 §2 deck plan, five corridor types (A barrel arch, B low industrial, C buttressed wide bay, D maintenance hex, E octagonal junctions — spine sequence never repeats a type adjacently), 15 sliding bulkhead doors + framed portals, 331 colliders, 78 interactables, 43 zone lights. Save terminals in Workshop + Computer Core (ritual sound + PROGRESS RECORDED; real serialization is Phase 5).
- First-person player: AABB collision (axis-separated slide), crouch w/ headroom check, sprint, jump, head bob 0.04@1.8Hz, eye 1.6, interact raycast, helmet lamp toggle.
- Amber-only helmet HUD per context/05 §1 (compass, shield/ammo/gravity, fuel/temp/rad/O2/hull, health L→R + oxygen R→L bars, ≤5×5 crosshair, dithered helmet-glass vignette + fixed scratches), notifications, zone name readout.
- `AudioEngine`: reactor hum (48Hz + 0.3Hz mod), HVAC LFO layer, random distant clanks (8–30s), surface-aware footsteps, door hiss, save chunk, deny buzz, switch click — all synthesized, no files.
- `index.html` + PWA manifest + service worker (cache-first, skipped on localhost); README with run instructions.

**Verified:** Playwright/Chromium run — boots with zero console/WebGL errors; pointer lock engages; scripted walk from Crew Quarters through J1 → Corridor B → J2 → Corridor C → Cargo Bay including two door interactions; 41 draw calls (budget <200); headless audit: no flat textures, every room ≥2 interactables, no zone over the 8-light budget; checklist greps clean (no neon green anywhere, no phosphor on HUD, exactly one camera class — first-person only).

**What broke / known issues:**
- Shadow maps deferred (spec'd in context/02 but not yet built) — depth currently comes from baked AO + dither quantization; revisit in Phase 8 polish.
- AMBER-9 is a bold double-strike of the shared 5×7 glyph set rather than a fully distinct face; corner-shaving pass still to do. 'G' reads like '6' beside digits at this size.
- Bunk rest, med bed, crafting bench, hacking and pilot seat are inspect-only placeholders until their phases (3/5/7).
- `Bridge.js` from the architecture tree intentionally folded into `Cockpit.js` (deck plan merges Room 01); `AmbientOcclusion.js` folded into `MeshBuilder` (per-vertex bake).

**Next session priority:** Phase 3 — First-Person Flight (`SpaceRenderer` starfield, seated cockpit transition with **no camera pull-back**, `FlightController` Newtonian physics, Sol Prime star + 2 planets, `ThrusterFX`).

---

## Session 2 — First-Person Flight + Touch Controls (Phase 3 complete)

**Date:** 2026-07-14

**What shipped:**
- **The windshield is real now.** Cockpit fore wall carries a genuine opening (wall builder learned sill heights); `Window` prop provides frame, mullions and an invisible glass collider; space renders behind the interior every frame with depth off, so the universe exists exactly where the hull doesn't.
- `SpaceRenderer` + `stars`/`space` shader pairs: 1400-point starfield + dithered nebula patches on a rotation-only sky, procedural G-type sun (granulated disc, ordered-dithered corona — new starlight/sun rows added to the context/01 §2 space palette first, per the closed-system rule), two planets (oceanic AETHON with teal seas/tan continents/ice caps; rocky CINDER) as UV spheres with Bayer-quantized terminators, all projected onto a sky sphere inside the far plane with angular size preserved.
- **Flight, first person throughout (context/02 §3 verified):** pilot-seat interact lerps the camera 0.5s into the seated eye — no pull-back exists anywhere; grep confirms `PlayerCamera` is still the only camera class. `Spaceship` holds system pos/quat/vel; the interior never moves — the universe is transformed by the inverse ship pose. `FlightController`: mouse = pitch/yaw, A/D roll, W/S thrust, Shift boost, Space flight-assist brake; quaternion math added to `MathUtils` (unit-tested: 2s thrust = exactly 44 u/s). Stand up mid-flight and the ship keeps coasting.
- Flight HUD mode: minimal glass reticle + SPD/THR/BRK strip — deliberately not the helmet HUD wholesale. Engine rumble follows thrust (36Hz sawtooth through a lowpass); seat-latch clunk on entry/exit.
- `ShipExterior.buildFreighter()` — procedural Kestrel freighter (other-ship/cinematic use only), one parked on the colony lane, sun-lit. `ThrusterFX` — 130 velocity dust motes streaming past the glass, alpha scaled by speed.
- `StarSystem` + `StarSystemsData` (Sol Prime partial: star, 2 of 8 planets, 1 freighter).
- **TouchControls (pulled forward from Phase 8 by request):** context/05 §7 spec — floating dual virtual joysticks (left MOVE, right LOOK; 65px base, 28px knob, 12% dead zone, amber, 0.35/0.8 opacity), bottom button strip ≥44px that swaps walk (USE/JUMP/RUN/DUCK/LAMP) ↔ flight (THR±/ROLL/BOOST/BRAKE/STAND) sets; InputManager gained analog axis + look injection + virtual buttons; enabled on mobile or `?touch=1`.

**Verified:** Playwright — scripted walk bunks→cockpit, seat transition, thrust to 55 m/s, coast (velocity persists), steer (planets swing across the panes), brake 55→6.5 exactly per the damping constant, stand up with ship coasting; zero console/WebGL errors; 48 draw calls. Touch run: tap-to-board, stick-walk into a closed door (collision holds), look drag, button strip present. Fixed en route: interact volumes you stand inside (doorways) now require facing their center; seat/med-bed volumes raised above standing eye height.

**What broke / known issues:**
- Only the cockpit has a window; other hull views (and seeing your own hull edge through the glass at extreme angles) wait for Phase 4 content.
- Planet spheres pinch slightly at the poles (2D-noise equirect); revisit with the full `PlanetRenderer` (rings, atmosphere) in Phase 4.
- Landing, docking, warp, travel timers, damage — Phase 4+. No collision in space yet; you can fly through Cinder.
- Touch look-stick sensitivity untuned on real hardware; mobile perf pass still pending (Phase 8).

**Next session priority:** Phase 4 — Full Star Systems (all 5 systems, `PlanetRenderer` with rings/atmosphere, `WarpEffect`, asteroid fields, stations with dock/refuel, scale + travel timers).

---

## Session 3 — Adaptive Input + Surface Depth (bug fixes + visual pass)

**Date:** 2026-07-15

**What shipped (both from direct user reports):**

- **Adaptive input — the device decides, not a UA sniff.** The reported bug was being stuck on the main menu on mobile (buttons unresponsive). Root causes fixed: (1) the boarding overlay sat at the same z-index as the touch-control layer and behind it in cases — overlays are now z-30, touch layer z-20, so menu taps always land; (2) `screen.orientation.lock()` throws/rejects on iOS Safari and desktop, which could abort the boarding handler — now fully guarded; (3) touch controls were created once at boot behind a UA check, so a device `isMobile()` missed stayed keyboard-only forever. Now: any genuine `touchstart` anywhere flips the session to touch mode (the boarding tap itself qualifies, since touch fires before its synthesized click), `TouchControls` is created lazily the moment touch is real, and the desktop pointer-lock path has a 700ms fallback that starts a lock-free touch session if the browser refuses the lock — so no input configuration can leave the player stranded at the menu. Added `touch-action:none` + tap-highlight suppression on body and all touch surfaces. Verified with the exact bug repro (touch context, NO `?touch=1`): tap boards into gameplay, stick walks the player, zero errors. Desktop keyboard + pointer lock still verified unchanged.

- **Surfaces have real depth now (no more 2D-texture-on-a-flat-wall).** Two layers of fix: (1) **Normal mapping + specular.** The `Painter` gained an explicit relief channel — bolts/rivets push up, seams/grout/rust/bevels cut down — and every one of the 42 textures now generates a matching tangent-space normal map (painted height + a luminance assist through a wrapping Sobel). `MeshBuilder` emits per-vertex tangents (interior vertex grew 11→14 floats); the interior shader does full tangent-space normal mapping plus a Bayer-quantized Blinn-Phong specular term (worn-metal tight highlight, AO/distance-scaled so it never blooms in a dark corner). Bolts, tread plate, vents, pipe insulation and door hardware now catch the helmet light and read as physical relief. (2) **Geometric wall relief.** `addWallRelief()` adds actual proud geometry to every room's long walls — raised skirting at the floor, a mid-height conduit rail, and pilaster ribs every ~2.6m — so walls have a real silhouette, not just a painted surface. Constants: `NORMAL_STRENGTH`, `SPEC_POWER`, `SPEC_STRENGTH`. TextureAtlas now uploads two parallel `TEXTURE_2D_ARRAY`s (albedo + normal) on shared layer indices; InteriorRenderer binds both.

**Verified:** smoke test (42 albedo + 42 normal maps, 40/42 with real relief, all tangents finite & unit, ship builds to 5110 tris with relief geometry, spawn clear); three browser runs — walk, seated flight (thrust 55.4 m/s, brake 6.8, unchanged), and the adaptive touch repro — all zero console/WebGL errors at 48 draw calls (well under the 200 budget). Checklist greps clean (no neon green, no phosphor on HUD, one camera class, dithering-only shading).

**What broke / known issues:**
- Specular was initially too hot in extreme close-up under the helmet lamp; dialed `SPEC_STRENGTH` 0.5→0.32 and `SPEC_POWER` 26→32 (tighter, drier highlight). Reads as worn metal now, not wet plastic.
- Relief geometry is on room long-walls only; corridors and the big cargo-bay lattice still rely on normal maps alone (fine — they already had strong painted relief). Prop meshes get normal mapping but no added micro-geometry.
- Draw calls unchanged (relief geometry folds into the existing per-zone static batch), but interior tri count is up ~30%; still trivial at this scale.

**Next session priority:** Phase 4 — Full Star Systems (unchanged from Session 2's note).

---

## Session 4 — Stale-Cache Lockout Fix + Intense Plasticity Pass

**Date:** 2026-07-15

**What shipped (both from repeated user reports):**

- **The real cause of "still stuck at the menu on mobile": the service worker.** The original `sw.js` was **cache-first**, so the very first build a device ever loaded got pinned permanently — every later fix (including all of Session 3's touch work) was served stale from cache and never reached the phone, which is exactly why the symptom survived the previous fix. Rewrote `sw.js` **network-first** with an offline fallback: the network is always tried first, install fetches use `cache:'reload'` to bypass the HTTP cache, `skipWaiting()`+`clients.claim()` take over immediately, and a `controllerchange` reload swaps to the fresh build mid-session. Added a **visible BUILD stamp** (bottom-right, from `GAME_VERSION`) so a stale cache is diagnosable at a glance — if it doesn't say the current version, the device is on an old cache. Also hardened boarding further: `touchend` boards directly (some mobile browsers don't synthesize a click from a tap on locked-down pages) and marks the session touch-first before any click can race it; boot faults now show a loud red message instead of a silent hang that reads as a dead menu.

- **Much more intense visual plasticity + detail (the "walls look like flat 2D textures" ask, taken further).** Three layers:
  1. **Deep texture relief.** Pushed explicit height into ~15 more generators — panel/plate seams and tile grout now *cut deep*, tread-plate diamonds and lattice beams and reactor ribs stand *proud*, pipe cross-sections are rounded (crest-to-edge falloff), vent/grating slots are punched holes, console keys and toggle levers are raised, corner reinforcement plates sit on the shell. Bumped `NORMAL_STRENGTH` 1.7→2.4 so the maps read strongly.
  2. **Relief on every wall + overhead structure.** `addWallRelief()` now runs on **all four walls** of every room (was two), splits its skirting/rail/rib runs around door and window openings, and adds **transverse ceiling beams** in tall compartments. Corridors got relief too, and barrel-arch corridors now have **structural hoops** every ~1.2m (wall ribs + apex cross-piece) for the classic ribbed-tunnel rhythm.
  3. **Greeble auto-dresser** (`Greebles.js`) — after each zone is built it scatters decorative mechanical props along the free wall runs (junction boxes with cable drops, horizontal conduits, red extinguisher canisters, deck signage plates, small vent grilles, breaker boxes), deterministic per zone. Plus an **emissive amber status lamp** baked onto every door lintel. Three new textures (`canister_red`, `sign_plate`, `door_lamp`); `TextureAtlas` already carried the parallel normal-map array from Session 3. All greebles/relief are decorative — **no colliders** (the flat wall collider already stops the player short).

**Verified:** smoke (45 albedo + 45 normal maps, 44/45 with relief, ship tri-count 5110→10498 from the added geometry, colliders unchanged at 335 — confirms greebles are decorative, spawn clear); four browser runs (walk, seated flight, adaptive-touch-no-flag repro, forced touch) — all zero console/WebGL errors, still 48 draw calls (greebles fold into the existing per-zone static batch), seated flight unchanged (55.7 m/s thrust, brake to 6.7). Checklist greps clean. Tuned specular 0.32→0.24 (power 32→34) so point-blank helmet lamp never blows out.

**What broke / known issues:**
- Draw calls unchanged but interior tri-count roughly doubled; still trivial at this scale (SwiftShader headless dipped to ~21 fps, but that's the software rasterizer — real GPUs are unaffected).
- Greeble placement is weighted-random within free runs; occasionally a conduit and a sign land close together. Acceptable density; tunable via the weights in `Greebles.js`.
- The maintenance crawl (corridor D) and the tightest low compartments intentionally skip beams/greebles (headroom).
- **Users on a device that already cached an old build must hard-reload once** (or the new network-first worker will self-heal on the next visit). The BUILD stamp confirms which version is live.

**Next session priority:** Phase 4 — Full Star Systems (unchanged).

---

### 16i — owner batch: concept-art stars, flight inertia, control-panel HUD, canopy (0.9.1)

Owner gave five tasks with a concept image. Three landed complete, one partly, one not started.

**1. Celestial visuals (done).** 0.8.8 used real blackbody colour — technically right, visually wrong: a G photosphere is near-white, so the disc rendered washed-out cream with no structure. The concept art is a saturated orange-red sphere with bright yellow granules and rust lanes, so the palette is now pushed hot per class while keeping spectral identity. Contrast comes from an explicit cool hue per class rather than `shade()`-ing the body, so lanes are a genuinely different tone — that colour break is what makes granulation read as blocks. Star *and* planet textures quantize their sample grid to 2×2 texel blocks (hard pixel clusters, not per-texel mush). Corona reworked to the concept's dithered ring: tighter falloff, bright inner collar, 6 hard steps.

**4. Flight inertia (done).** Input is now TORQUE, not direct rotation: the hull carries angular momentum and bleeds it through the RCS. Assist damps hard on release (6.0), lighter while steering (2.4) so it still glides; assist off is 0.25 — you tumble until you counter-steer. Clamped so a flung mouse can't start an unrecoverable spin. Verified: roll spins **up** to 1.48 rad/s, still carries 0.74 after release, assist nulls to ~0, manual holds 1.71 rad/s 900 ms later. RCS thruster visuals now key off actual angular velocity, so jets fire while momentum is being arrested.

**5. HUD + controls (done).** New centre console in the dead gap between VITALS and SHIP: pitch/yaw/roll rate needles (you need to *see* the tumble now that momentum exists) plus a DRIVE block — velocity, throttle, flight mode, weapon capacitor. The right edge is off limits for HUD: the celestial approach popup is a DOM overlay that covers it. Touch flight buttons were one cramped centered row; split into thumb clusters — throttle bottom-left, fire/boost/brake bottom-right, roll inboard, translation d-pad above the right cluster, view/stand/assist top-left. Touch also gained the strafe controls that 0.8.7 gave only to the keyboard.

**3. Cockpit canopy (partial).** The windshield went from one small square pane to a three-pane canopy — a tall centre pane flanked by stepped-down side panes, with the wall left between them reading as mullions. Much bigger and no longer a plain rectangle. **Not done:** the wrap-around side-wall quarter-lights, and the interior texture/prop-placement half of the task.

**A correction, in two stages.** I added nx/px quarter-lights, saw the cockpit open to space when looking sideways, and told the owner I'd blown out the side wall. Re-running with my changes stashed gave a near-identical frame (13.6 vs 13.7 mean RGB), so I corrected that to "pre-existing bug, not mine". Then I went to fix the pre-existing bug — and it isn't one either.

`__debug.teleport` leaves the player at **y ≈ 3.3 against a 2.8 m ceiling**: resting on TOP of the ceiling collider, outside the hull looking in. Every "interior" screenshot I took that way was shot from the roof, which is why the sides showed space. The ship was fine the whole time. Zeroing velocity in the teleport does *not* fix it (verified), so the ejection is inside collision resolution.

Two lessons recorded in code: the teleport hook now carries a KNOWN LIMITATION docstring telling the next person not to trust it for interior shots (walk from spawn, or use `enterFlight()`), and the canopy comment says the side panes are deferred for want of a trustworthy probe — not because anything is broken.

**2. Ship model + effects: not started.**

**Real open item:** `__debug.teleport` can't place the player on a deck. It's a test-harness defect, not a rendering bug, but it blocks interior verification (and blocked the wrap-around canopy), so it's worth fixing in collision resolution before the next interior pass.

---

### 16j — the Aethon rebuilt, and two invisible bugs that were hiding the work (0.9.3)

Finishing the owner's five-task batch: task 2 (ship model + effects) and the interior half of task 3. Both turned out to be gated behind rendering bugs rather than missing content.

**2. Ship model + effects (done).**

The hull was seven stacked boxes with four flat wings. It's now lofted: chamfered cross-sections through a three-mass silhouette (swollen sensor head, pinched waist, heavy engineering block), with frame bands at every section joint, a dorsal walkway with stanchions and rails, a lofted survey pallet carrying two concave dishes, a magnetometer boom off the nose, a raked three-pane canopy with flank quarter-lights and chin ports, four finned radiator wings on stepped pylons, a three-bell gimballed drive with concave throats and a vernier pair, a forward-facing comms dish, a dorsal docking collar you can see into, an airlock recess, segmented conduit runs, cargo doors, and a deterministic greeble field. 8.6k triangles, still one draw call.

New primitives carry it: `loft` over cross-sections with true per-facet normals, `octaTube` on any axis (tapered, optionally inside-out so bells and dish bowls read concave instead of culling to a hole), and `boxR`/`octaTubeR` to stamp one canonical starboard part through four quarter-turns. Mirroring by hand (`[s*x0 … s*x1]`) silently inverts min/max on the port side, flipping winding and culling the part — every mirrored part goes through an `HX`/`GX` helper now.

**Why the engines looked like "a few loose dots".** The drive plumes were emitting from model z=16.8 — amidships, 14 world units ahead of the actual bells. Every throat core and bloom was being drawn *inside the hull* and depth-tested away; only the far tail of the plume ever escaped. Fixed by exporting `AETHON_FX`: nozzles, verniers, RCS ports, damage vents, beacons and the shield ellipsoid all come from the same table the geometry is built from, so they can't drift again. Six layers per bell across three nozzles now, plus a cluster wash, vernier trickle, and shock-diamond beads. RCS fires the specific port that would produce each torque (main.js passes signed per-axis rates instead of one lumped "steer" magnitude), reverse thrust brakes on the forward-facing pylon clusters, and attitude jets got their own pale cold-gas sprite — they were drawing the hot amber rocket flame, which made every manoeuvre look like a rocket firing out of the ship's flank.

**Why the plating never showed.** `Renderer.createTexture2D` clamped every 2D texture. Exterior hulls derive planar UVs from model space, so a 90-unit ship at uvScale 0.16 addresses u ∈ [-7, 7] — under CLAMP_TO_EDGE every face sampled the same edge column. The Aethon, the freighter and both enemy hulls have been rendering as flat colour since they were written, regardless of what got painted into their textures. Added an opt-in `repeat` flag, set on all four hull textures plus extGlow; spheres and billboards stay clamped. Then gave the player's ship its own `aethonHullTexture` — deliberately low frequency (stepped plate blocks, sunken seam channels, one narrow muted hazard band), because a 64px tile still minifies hard at chase distance and fine speckle just aliases.

**3. Interior half (done).**

First, the blocker from 16i. `CollisionMap.move` resolves per axis in the direction of travel and **skips any axis whose delta is zero**, so a body placed inside a wall with no horizontal velocity is never pushed sideways — and the next downward pass finds the wall collider beneath it, treats it as ground, and snaps it to the wall's top face at ceiling height. That is the y≈3.3 roof landing. New `CollisionMap.depenetrate` pushes an AABB out of everything it overlaps, deepest intrusion first, along that box's own axis of least penetration; `teleport` runs it after placing the player. All 24 zones now land on the deck. 16i's "test-harness defect, needs a real fix in collision resolution" was the right diagnosis.

With a working probe, the interior's actual worst problem was visible immediately: **big pure-black rectangles in the cockpit, med bay, computer core, research lab, engine room and crew quarters.** Every one was a screen. This is a regression I introduced with 16i's diegetic CRT: interior `v_uv` is a planar world-space projection scaled per surface, not a normalized 0..1 rect, so `1.0 - dot(v_uv - 0.5, v_uv - 0.5) * 0.85` went far negative on every off-origin screen and the negative multiply crushed it to zero. The CRT terms now work on `fract(v_uv)`. My 16i brightness check passed because I happened to measure a screen sitting near the UV origin.

The same non-normalized UV was also mis-mapping the *content*: displays and posters showed their texture offset and wrapped through the middle of their own glyphs. Added `PropBase.screenFace` — a normalized mapping for anything that is one image on one rectangle — and moved Console, WallScreen, SaveTerminal, HackingTerminal, MedStation and Poster onto it, each now set into a metal bezel rather than decalled onto the front of a box. The mainframe cabinet in the computer core was one terminal screenshot blown up to 1.4 × 2.3 m; `Machinery` gained a `screens` option and it's a rack of ten individually bezelled readouts.

**Verified.** No console or page errors anywhere. All six attitude/translation axes fire the correct ports. 89 draw calls in first-person flight, 88 worst-case interior (budget 200), 63 worst-case hull cam (budget 100). All 24 zones on deck. Headless build smoke green.

**What I did not do.** The interior *texture set* itself is unchanged — the palette and relief work from sessions 3, 4, 11 and 14 is owner-approved, and the depth gain this session comes from geometry (inset bezels, screen racks, hull relief) rather than repainting it. Say the word if you want the wall/floor materials themselves reworked.

**Next:** planet-landing transition, NPC dialogue, the full `AudioEngine`, mobile perf.

---

### 16k — owner batch: finer celestials, non-repeating plating, one control layout, concept-art screens (0.9.4)

Five asks off a set of in-game screenshots, then four concept arts mid-session for the menu, character creation and inventory.

**Celestial resolution.** Star photospheres went 256×128 → 512×256 sampled one texel to one, dropping the 2×2 block quantization; at the disc sizes a close approach produces, that grid was showing a few dozen enormous squares instead of a photosphere. Planets and clouds went to 384×192, coronas to 192. Paid for by building star surfaces **per class on demand** rather than all eleven at boot — the five systems in the game use five classes, and eleven sets at the new resolution would be several seconds of loading for sets nothing ever shows. `ensureStarTex` fires at boot, on warp arrival and on save load, with a defensive call from `_drawStar`. Net boot cost is *lower* than before at four times the star detail.

**Hull plating.** `space.frag` gained `u_tileVary`: per texture tile, mirror the panel content on a coin flip and step its value. The seam lines stay on the grid — that is what plating looks like — while no two adjacent panels carry the same wear. Aethon `uvScale` 0.16 → 0.095 so a tile spans ~10.5 model units instead of 6.25, and the plating texture got a corner-biased wear gradient so the four mirror variants read as four different panels.

**Controls and HUD.** Walking had a centred bottom strip while piloting had thumb clusters, so the two halves of the game wanted different hand positions — and the strip sat on the canvas HUD's bottom panels. Both modes now use one six-cluster geometry; only the labels change. The flight util cluster moved to the right edge because it used to interleave with the game's own WARP/BAG/SCAN/MENU/LOG chips into a stack of half-covered labels. `HUD.inset` reserves the button gutters inside the 480×270 buffer; side panels narrow to 112px when it's active and the centre console sizes itself to the gap that leaves, because hard-coded x/width put the DRIVE block straight through the SHIP panel. The chip column reflows over its visible members so hiding WARP on foot closes the gap. Verified in a 1000×450 touch viewport: 21 buttons, **zero overlapping pairs**, walk and flight resolving to identical positions.

Also fixed: the bar label column was exactly 24px, the width of a 4-glyph label, so FOOD, HEAT and RAD rendered as "FOOl", "HEAl".

**Front-of-house screens, to the concept art.** `Chrome.js` gained four generators — `spacePNG` (dithered void, ragged nebulae whose radius is sine-warped *before* quantization, because stepping a plain radial falloff just draws concentric rings, three-brightness star field), `bulkheadFrame` (bevelled edge rails, cut corner plates, amber trim, indicator ticks, title plate), `pilotPNG` (48×56 EVA bust) and `itemIconPNG` (24×24 isometric solid, hard outline, category glyph).

- Main menu: was one centred slab with the controls list crammed under the title. Now three columns inside the frame over the star field, side panels dropping out below 720px.
- Boot screen: same surround, segmented riveted progress gauge. Applied at the *start* of boot — `applyBootChrome` runs after generation, by which point the loading screen is already hidden.
- Commission screen: framed personnel-file portrait whose shoulder patch takes the chosen record's colour, service record on the right, action on a footer bar.
- Inventory: rebuilt from a scrolling text list into a **slot grid** — category rail left, 6×5 icon grid centre with quantity badges and selection highlight, SELECTED readout right with a large icon, description, mass and USE. Every one of the 200+ items gets a distinguishable sprite from its category shape plus a hash-picked base colour, with no asset files.

Item tinting took two passes: a single base with per-channel jitter was either too narrow (every item the same tan) or too wide (pinks and lilacs, which the palette bans). Each category now carries a set of four muted on-palette bases and the item hashes into one.

**Verified.** No console or page errors, 89 draw calls in flight, 88 worst-case interior, all 24 zones on deck, build smoke green, zero overlapping on-screen buttons.

**Finishing the batch (0.9.5).** Two parts of the five asks were still open after the first pass, so this closes them.

*The rest of the celestial textures.* The star, planets and clouds went up in the first pass, but the nebula was still 128px stretched across a sky-sized billboard (a handful of enormous blocks), rings were 96, and the sun fallback and warp singularity were 128. Nebula → 320, the other three → 256, with the nebula's noise frequency scaled by `128/size` so the cloud keeps its on-screen shape and simply resolves finer. The singularity's photon ring was specified in absolute pixels, so doubling the texture would have halved its relative thickness until it vanished — it's now `size/58`. Whole set costs 55 ms.

*The screens I hadn't touched.* The first pass did the boot screen, main menu, commission screen and inventory; the journal, trade counter, intrusion clock, warp chart, settings sheet, pause veil, in-game menu and death screen were all still on the old plain-plate look. Rather than rewrite eight layouts, `Chrome.js` gained two decorators that work IN PLACE:

- `framePanel(el)` — swaps in a larger generated plate, adds hard corner brackets and a hazard strip along the top edge. For the centred modals, which each build their own layout and hold references into it.
- `frameBackdrop(root)` — slides the bulkhead surround and star field in *behind* a full-screen overlay's existing children. For the settings sheet and the death screen.

Plus `showScrim()`, a reference-counted dimmed star-field veil behind any open modal, so a popup reads as a panel inside the ship instead of a box on a black page. Every screen in the game now shares one visual language.

**Not done:** the concept's equipped-item hotbar along the bottom of the inventory. The slots exist in the fiction but nothing equips yet, so it would be a row of dead boxes — worth doing when equipment lands.

### 16m — Machined buttons, framed approach panel, small-body surfaces, longer star loop (0.9.6)

**Buttons.** Every DOM control in the game comes out of one function, `Chrome.plasticButton`, so restyling it restyles the whole front of house at once. The old version was a rounded rectangle with a soft glow — closer to a phone app than to a switch panel. It now has chamfered corners cut with `clip-path` (the 45° corner cut is the single strongest read of "machined plate" at this scale, and it costs nothing), an inset amber bezel drawn with `outline` + negative `outline-offset` so it sits *inside* the plate edge instead of growing the element, and an inner top shadow so the face reads as recessed under a lip. `addLamp(el, on)` adds a small status LED for controls that have a state.

One trap worth recording: `plasticButton` used to include `position:relative`, which silently beat the `position:fixed` its callers set — the five left-edge chips lost their positioning entirely and dropped out of the layout probe (21 buttons → 16). `plasticButton` no longer sets `position` at all, and `addLamp` only sets it when the computed position is already `static`.

**The approach panel.** `CelestialInfo` was the last plain box in the game. It now uses `framePanel`, `plasticButton` for LAND/LEAVE, and a generated 40×40 shaded disc of the body you're approaching as a thumbnail header, so the panel says *which* world without reading the name.

Placement took three tries and the two failures are the interesting part: the right edge is now the flight button column, so the panel covered A/S, VIEW, STAND and FIRE; dead centre (`top:16%`) covered the body being approached, which is the one thing the player is looking at. It sits at `left:8.5%; top:31%` — inside the left gutter's dead zone, below SENSORS, above VITALS.

**Moons, planetoids, comets.** These three kinds were all falling through to the generic rocky branch, so a moon looked like a small planet. `planetTexture` gained two real branches:

- `moon` — a maria/highlands split at low frequency, then crater *rings* rather than crater discs (bright sunward rim, dark floor: a filled circle reads as a dot, a ring reads as a hole), a second finer crater field on top, and an ejecta ray system radiating from the largest ones. Cool grey ramp, no hue.
- `comet` — near-black carbon crust with sublimation vents blown out to near-white ice, plus deep fissures. The widest value range of any body in the game (38..186 on a 0..255 scale), which is what a dirty snowball actually looks like.

Measured means confirm they read as distinct materials rather than recolours: moon 86.7, comet 60.8, against rocky 150.0 and ice 193.2.

**Star animation.** The surface loop was 4 frames at 3.2 fps — 1.25 s, short enough that the eye locks onto the repeat and the star reads as a flickering texture rather than a churning plasma. Now 6 frames at 2.5 fps (2.4 s), with churn amplitude ×1.45 so consecutive frames actually differ, and the whole shell's slow drift raised 0.012 → 0.03 rad/s so the loop point never lands in the same place twice. Frame-to-frame deltas measured 28.3/29.4/28.5/28.6/29.2/30.2 — even, and the wrap (30.2) matches the interior steps, so the loop closes without a visible jump. Six 512×256 frames per class generate in 418 ms, and generation is still lazy per star class, so boot cost is unchanged.

**Verified.** Build smoke green, full smoke 89 draw calls with no errors, all 24 zones on deck, worst interior 88 (budget 200), 21 buttons / 0 overlapping pairs, every screen renders clean.

### 16n — The chart doubles: ten systems, five new body kinds, planetary rings (0.9.7)

The ask was "expand the game with more content — new star systems, celestial bodies." Five systems became ten, and the body roster grew by five surface types plus a ring system.

**Five off-route spurs.** The existing five are the *commissioned survey route*; the new five hang off it — same lane network, nobody's contract, none required to finish the story. Each one is built around body types the route has no reason to contain, so a jump changes what's out the window and not just the star's colour:

- **ODESSA CHAIN** (F) — Kestrel's other lane. A greenhouse world, two stripped cores mined open, a ringed gas giant, a tundra world breathable through a mask, and the richest belt on the chart (22 rocks). Station, derelict, MEDIUM.
- **AMBER WELL** (red giant) — a star that already ate its inner worlds. The shredded inner system is a 26-rock belt at **0.9 AU** — far closer in than a belt belongs, which is the tell. A tundra world that has only had a habitable zone for ninety thousand years, and a meltwater ocean where something is dividing.
- **COLD HARBOUR** (brown dwarf) — a star that never lit. **No belt at all**, because a failed star's disc never had the mass to leave one, and the emptiness is the point: everything out here was *put* here. A ringed ice giant with a volcanic sulphur moon in its tidal grip, and a Drift breaking yard with hulls parked in rows.
- **THRESHER** (O supergiant) — Keth forward yard. No belt, no comets; nothing icy survives. Two carbon worlds, a mirror-bright stripped core, and a ringed giant whose rings are being blown into a visible tail.
- **THE DRUM** (neutron star) — 11.4 turns a second. A structure locked to the beam, and a fifth hull design that is not human, Keth, Vrenn or Drift.

Two spurs (Odessa Chain, Amber Well) are deliberately **not** patrolled. A spur that shoots at you on arrival is a spur nobody visits twice, and the game needs somewhere off-route to trade from. The Hollow is armed on two of the five, not all — `context/04` calls for it to stay rare, and arming it everywhere would turn the one thing that cannot be fought into ordinary weather.

Along with them: 6 new quests, 5 new visit-triggered lore entries, 3 new hostile tables, and two new star classes — **BD** (brown dwarf: no fusion, so what you see is weather, banded methane cloud over a dull maroon glow — reads closer to a gas giant than a sun) and **NS** (neutron star: frankly a stylisation, with hard magnetic banding and two blazing polar caps where the beams leave). Both take deliberately inflated radii; a Jupiter-sized primary would render smaller than the worlds orbiting it.

**Five new surfaces.** `moon` and `comet` got real branches last session; these five were still falling through to `rocky`:

- **toxic** — Venus-analog. Near-total cloud coverage (0.98) with hard shear, because a greenhouse world *is* a featureless ochre ball from orbit and that opacity is the read. The ground below is deliberately low-contrast so the deck doesn't look like haze over detail.
- **carbon** — graphite crust, carbide plains, diamond-seam fractures, hydrocarbon tar seas. The only truly achromatic body in the game, which is what makes it read as wrong next to the warm rock and blue ice.
- **metal** — a planet's stripped core: smooth basins, wrinkle ridges where it froze, and bright rayed scars exposing fresh nickel.
- **tundra** — ice sheets pushing to the fortieth parallel with a ragged noise-driven edge, olive steppe between, pack ice on the seas.
- **sulfur** — Io-analog, volcanic moons only. Deposit *rings* around dark paterae, for the same reason craters use rings: a filled circle reads as a dot.

Measured means confirm they're materials and not recolours: toxic 72.6, carbon 44.1, metal 83.3, sulfur 122.7, tundra 181.5, against rocky 124.6 and ice 206.8. Sulfur needed a second pass — the first version started its plain steps at the *second*-darkest allotrope and averaged into one flat gold ball at the ~90px a moon actually draws; four steps from the darkest fixed it.

**Planetary rings.** New, and worth recording *why* they are billboards rather than an annulus mesh:

1. Orbits here are near-coplanar and the ship flies in that plane, so a physically-oriented ring would be edge-on — a 1px line — almost always. Baking a fixed 0.335 minor/major ratio guarantees it always reads as a ring. Same compression licence the star radii already take.
2. The space pass runs with **no depth test**, so a real annulus interpenetrating the planet sphere could not be sorted per-fragment. Splitting the ellipse into a `far` half (drawn *before* the sphere, so the planet occludes it) and a `near` half (drawn *after*, so it crosses the disc) buys the signature Saturn read for two draw calls and zero depth buffer.

The billboard's up vector is the **ecliptic pole mapped into the render frame**, not the camera's up — otherwise the ring would roll with the ship instead of staying fixed against the ecliptic. Four ringed bodies across the chart.

**Lazy body textures.** `ensureBodyTex(kind)` mirrors `ensureStarTex`: a surface (and its cloud deck, if the kind has weather) is built the first time anything asks to draw it, and `primeSystemTex(def)` pre-builds a whole system's set during its loading beat — at boot, on warp arrival, and on save load. Half the roster only appears on the spurs, and charging every player for worlds they may never visit is exactly the cost this avoids. Boot is unchanged with thirteen kinds available instead of eight.

**Two perf guards, because the content growth exposed a real hole.** Cold Harbour arrived at **103 draw calls**, over the <100 space budget. Diagnosis, not guesswork: 25 of its 28 bodies were on screen at once, because a failed star's habitable zone is measured in hundredths of an AU, so the *whole system* is in view and nothing is far enough away to be small.

- `_subPixel` — skip any body whose angular radius is under 0.0011 rad (under half a pixel at 480×270). Handles spread-out systems; Amber Well draws 38 bodies as 55 calls.
- `BODY_DRAW_CAP = 22` — a hard ceiling applied to the near end of the far→near sort, for the compact case the sub-pixel test can't catch. This is the guardrail that keeps the budget true no matter what a future system definition asks for.

Cold Harbour also lost its belt, for the lore reason above. Worst case across all ten systems is now **88 first-person / 49 hull cam**, and the worst interior dropped 88 → 69.

**Also fixed.** The approach panel's `top` moved 31% → 25% with a `max-height`: a body carrying every stat field (a long atmosphere string wraps the ATMOS row) grew the plate down over the VITALS header. Verified clear at 960×540 and 1000×450 with the worst-case content. And `Chrome.BODY_TONES` gained entries for every kind the generator can produce — a moon or carbon world falling back to `rocky` showed the player a tan marble for a body that is grey or black in the window right beside it.

**Verified.** Build smoke green, full smoke 70 draw calls with no errors, all 24 zones on deck, 21 buttons / 0 overlaps, every screen clean, all ten systems arrive with the right star class and a populated sky, 15 quests registered, ring geometry confirmed in both views.

### 16o — Interior materials at 128², with a mip chain (0.9.8)

The last open item from the owner's batch: *"enhance all textures with more heavily pixelated visuals."* Celestial and hull were done in 16j–16m; the interior material set was still the only thing left at its original resolution, so this closes it.

**Two grids, not one.** The naive move — raise `TEXTURE_SIZE` and let the generators run — would have been wrong in an obvious way: every one of the ~46 interior generators writes absolute coordinates (`for (let y = 15; y < S; y += 16)`, `insetPanel(4, 18, 22, 24)`, stencils at `(41, 5)`). Doubling `S` would leave every feature in the top-left quadrant and halve every seam pitch relative to the tile. Retuning forty hand-authored generators is not a texture-resolution change, it is a redesign.

So `RENDER` now carries **two** numbers. `TEXTURE_DESIGN` (64) is the grid the generators are written against and it has not moved. `TEXTURE_SIZE` (128) is what reaches the GPU. `Painter` bridges them, and the split runs through the whole class:

- **Structural** methods (`px`, `addH`, `get`, `rect`, `outline`, `insetPanel`, `raisedTrim`, `bolt`, `text`) take design coordinates and write a TX×TX block, so every seam, bolt and panel keeps the exact physical size it had on the wall.
- **Fine** methods (`fpx`, `faddH`, `fget`, and the wear built on them — `speckle`, `scratch`, `rustStreak`, `darkenEdges`) work in output texels. This is where the resolution actually shows up: hairline scratches one texel wide, corrosion that trails in flecks instead of a three-texel smear, and grain rather than blocks.
- `ditherFill`/`ditherOver` bridge: rect args stay in design coordinates (so no call site changed) but they iterate output texels and hand `fn` **fractional** design coordinates. `fbm2` and `valueNoise2` are continuous, so sampling them at TX× density over the same region resolves genuinely more structure — it is not an upscale of the coarse version. Exactly the move the star surfaces made at 512×256 with `CH = 1`.

Not one generator body needed editing. Measured: `wall_military` went from 95 to **143 distinct colours** at the same feature layout; boot cost +0.5 s (2.5 s → 3.0 s), memory 1.5 MB → ~8 MB across both texture arrays including mips.

**A mip chain, which the resolution bump made mandatory.** Interior texels are already finer than a screen pixel on any wall more than a few metres off; at 128² that undersampling would have read as crawling static whenever the player walked. The arrays now carry a full chain sampled `NEAREST_MIPMAP_NEAREST`.

That is not a softening of pillar 3. The filter picks exactly one texel from exactly one level — nothing is ever blended, between texels or between levels — so magnification up close is byte-identical to before and every surface stays hard-edged. It is the standard retro-3D answer to minification, and it improves the *old* 64² shimmer too.

**Verified the change did not quietly flatten anything.** The risk with a finer grid is the sobel: a 1-texel difference over a TX× denser grid could halve the derived relief. It does not, because `addH` block-fills a design texel, so a structural edge still steps its full height between two adjacent samples — same steepness, thinner band. Only the *luminance assist* genuinely weakens (finer albedo steps are smaller per-sample differences), and that term alone takes the TX correction rather than inflating the whole gain, which would have over-steepened every bolt by 2×.

Measured on identical camera positions in three places (corridor wall at arm's length, corridor down its length, cargo bay): **mean brightness +1.2 at most on a 0–255 scale, standard deviation unchanged within 0.4.** Same light, same contrast, same structure, finer grain.

**Three clipped strings fixed while in there.** Dumping the text-bearing textures to check the font's new integer block scaling showed three diegetic strings running off the 64-design-grid edge — pre-existing, identical at both resolutions, but plainly visible once magnified: the status screen read "SYS NOMINA", the core terminal "AETHON/COR", and the ship-schematic poster's "HSV AETHO" was cut on the right *and* along the bottom (a glyph is 7 rows, so y must be ≤ 57). The grid fits `floor((64 - x) / 6)` glyphs; that constraint is now written down at the call site.

**Verified.** Build smoke green, full smoke 70 draw calls with no errors, all 24 zones on deck, worst interior 69 draws (budget 200), 21 buttons / 0 overlaps, every screen clean, terminals and stencils legible in world.

### 16p — Planet surfaces rebuilt on a physical model (0.10.0)

The owner asked for the celestial work redone "complex and realistic". The honest
answer was that the previous version could not get there by tuning, because it
had no model to tune: `planetTexture` was a chain of if-blocks, one hand-written
noise recipe per body kind. Every feature in it was decorative. Mountains sat
wherever the noise peaked, deserts wherever it dipped, ice wherever a latitude
band said so, and none of those facts knew about each other. Adding a body type
meant inventing another recipe.

**`src/data/Planetology.js`** replaces all of it with one simulation that every
body runs, and a per-kind table that only sets physical parameters — water
budget, mean temperature, axial tilt, atmospheric pressure, tectonic vigour,
volcanism, impact preservation, crust composition. The pipeline, in causal order:

1. **Plates** seeded by golden-angle spiral, each continental (buoyant, high) or
   oceanic (dense, low), each with a drift vector tangent to the sphere.
2. **Boundaries** classified by projecting relative drift onto the boundary
   normal — convergent, divergent or transform — then a multi-source BFS spreads
   distance-from-boundary so uplift can decay inland. That decay is what makes a
   mountain *range* instead of a one-cell ridge. Continental collision builds
   broad and high; subduction digs a trench and raises a narrow arc beside it;
   divergence gives a mid-ocean ridge or a rift valley depending on the crust.
3. **Elevation** from crust type + that uplift + mantle hotspots + impact basins
   (bowl, raised rim, ejecta apron) + fractal roughness sampled on the 3D
   direction so it wraps with no seam.
4. **Hypsometric remap** — rank every cell and reassign its height from a target
   curve. This turned out to be the most important correction in the model and it
   took a measurement to find. The raw field was roughly Gaussian, which put the
   average land cell 3 km up, froze temperate worlds solid under the lapse rate,
   and reported 16–31 km of relief. Real hypsometry is bimodal: broad abyssal
   plain, narrow shelf, land overwhelmingly low with a thin mountain tail. A
   monotone function of rank imposes that distribution without moving a single
   peak off its plate boundary, and it makes the water budget exact.
5. **Temperature** from a second-Legendre insolation profile (the annual-mean
   approximation; plain cos(latitude) is the noon-equinox value and is far too
   steep — it put 45° six degrees cold and turned every continent to tundra),
   distributed around the spec's global mean so the mean is preserved exactly,
   flattened by pressure, damped by obliquity, minus a 6.5 °C/km lapse rate.
6. **Winds** — three-cell circulation, trade easterlies / westerlies / polar
   easterlies.
7. **Precipitation** — moisture evaporates over water, is advected downwind, and
   condenses on rising ground. This is the reason the model exists: it puts
   deserts *behind mountains*. Measured on an ocean world, rising ground gets
   0.180 mean rainfall against 0.032 on falling ground — a 5.6× rain shadow.
8. **Hydrology** — steepest-descent flow accumulation over land sorted high to
   low; the top 2.5% of drainage is river, closed basins are lakes.
9. **Biomes** — Whittaker on (temperature, precipitation), with the precipitation
   axis normalised to the world's *own* 20th/80th percentile, plus crust-specific
   tables for molten, sulphur, carbon, metal, ice and regolith surfaces.

`planetTexture` now only looks the answer up and paints it, with three layers on
top: a domain warp so a 144-cell grid does not show as blocky biome edges,
within-biome variation, and relief shading from the bilinear elevation slope.
Craters are drawn at texture resolution from the model's own impact list, so the
ring structure resolves finely while sitting exactly on the basin the elevation
field dug.

**Gas giants get their own generator**, because they have no crust and there is
nothing for the model to simulate. `_gasGiantTexture` builds from zonal jets:
alternating prograde/retrograde bands, narrower toward the poles because the
Coriolis parameter rises with latitude, bright ammonia zones against rust belts,
festoon curls where the shear is highest, and long-lived vortices placed *on* jet
boundaries — which is where the Great Red Spot actually sits.

**Calibration was iterative and each step was measured, not eyeballed.** Four
defects found and fixed this way: the rain-shadow check itself was wrong (it
assumed westerlies at every latitude and so sampled the downwind neighbour in the
tropics, making the effect look inverted); the biome census over-weighted the
poles because an equirectangular grid gives a polar row as many cells as the
equator, which reported 23% sea ice on a temperate world; flat coastal land got
0.09 of rainfall with only an orographic term and the classifier called an entire
ocean world desert; and the slope gain pinned its own clamp on every crater rim,
double-counting with the ring shading and turning regolith into black holes.

Colour depth went up with it: each biome ramp is expanded to seven shades at load,
because three authored entries meant a three-biome world had exactly nine colours
in it. Ocean worlds now carry 71 distinct colours, stripped cores 112.

**Verified.** All thirteen kinds generate in 35–105 ms. Build smoke green, full
smoke 70 draw calls with no errors, all 24 zones on deck, worst interior 69,
all ten systems still inside budget at 88 first-person / 49 hull cam.

### 16q — Keplerian orbits, resonance-derived rings, limb-darkened stars (0.11.0)

Three deep passes, in the order the owner asked for.

**1. Orbits are Keplerian.** Bodies used to run on circles: a radius, an angle,
and `K/r^1.5`. The exponent was right so inner worlds led outer ones, but every
orbit was perfectly round and exactly on the ecliptic, so a system read as
concentric rings on a flat plane, and a comet on a 150 AU orbit tracked at the
same steady rate as a planet at 1 AU.

`src/data/Orbits.js` implements the six classical elements — a, e, i, Ω, ω, M₀ —
and solves Kepler's equation M = E − e·sin E by Newton–Raphson for the eccentric
anomaly. Two robustness details worth recording: the seed is E₀ = M + e·sin M
rather than M, which keeps the iteration count flat as e climbs into the comet
range; and the derivative 1 − e·cos E is floored, because it tends to zero at the
periapsis of a very eccentric orbit and would otherwise throw the Newton step to
infinity.

Verified against theory, not by eye: residuals ≤ 1e-10 at every eccentricity from
0 to 0.95; T²/a³ constant to 1e-9 across five decades of semi-major axis; sampled
apsides matching the closed form to the unit; the vis-viva speed ratio on an
e = 0.6 orbit measuring 4.00× against a predicted 4.00×; and the position after
exactly one period returning to its start with zero drift. 240 bodies cost 176 µs
a frame.

Element distributions come from the Solar System: planets e = 0.005–0.09 and
i ≤ 3.4°, dwarf planets 0.06–0.34 and 4–28° (Pluto is 0.25 and 17°), comets
0.45–0.88 and 5–42°. Sol Prime now runs its planets at e = 0.013–0.083 and
i ≤ 2.9° with its two outer dwarfs at 15°, and its comets swing between 366,000
and 1.6 million units while their speed varies 4.4× over one period.

`StarSystem` keeps ONE clock and solves every position from it, rather than
integrating each body's angle. Per-body accumulation drifts with rounding over a
long session and makes position depend on how many frames were drawn instead of
on elapsed time; solving from `t` keeps the system reproducible and lets a save
restore it exactly by storing one number.

*Two latent bugs this exposed.* Comet designations were two random draws from a
six-name list, so a collision was about one in six and Sol Prime shipped with two
objects both called COMET ZETA-4. And stations were positioned relative to their
host at epoch and then never moved — "Meridian Station, colony orbit" was
abandoned in empty space the moment the colony went round the star. Anything
parked over a world now rides with it, with the station-keeping vector slowly
rotating so it also circles the planet. Measured: stations hold their range
exactly over an hour of game time, derelicts drift as intended.

**2. Ring gaps are mean-motion resonances.** The old ring was one number and one
hardcoded division two-thirds of the way out, identical on every giant.

`buildRings` now solves the structure from the host's own moons. The inner edge
is the **Roche limit**, d = R·(2ρ₁/ρ₂)^⅓ — inside it tidal shear beats a
moonlet's self-gravity, which is precisely why rings exist there and moons do
not. The outer edge is set by the innermost shepherd. The gaps are **resonances**:
a particle whose period is a simple ratio of a moon's takes the same kick every
orbit, the kicks accumulate instead of averaging out, and it is swept away. The
Cassini Division is the 2:1 with Mimas, not a decorative stripe. Resonance radii
follow from the third law as a_res = a_moon·(q/p)^⅔, and gap width and depth
scale with the resonance's order.

This immediately showed that every giant had identical gaps — because the
innermost moon was hardcoded at exactly 3.2 R, so the 2:1 always landed in the
same place. Jittered to 2.55–4.4 R, the six ring systems on the chart now carry
3 to 5 gaps each at different radii, and the disc tilt drives how open the ellipse
is rendered. Sheets are built per body and cached by id.

**3. Stars are limb-darkened.** A star is not a Lambertian ball: at the centre of
the disc you look straight down into hot deep gas, at the limb your line of sight
grazes cooler upper layers. The standard quadratic law
I(μ)/I(1) = 1 − u₁(1−μ) − u₂(1−μ)² is now in `space.frag`, and since the star is
lit from the eye, the Lambert term is already exactly μ. Coefficients are per
class and real — the Sun is (0.93, −0.23); hot radiative atmospheres barely
darken, which is why an M dwarf reads as a fat glowing cushion and an O star as a
flat brilliant disc.

Active regions gained real structure: a dark **umbra** where the vertical field
chokes convection outright, a filamentary **penumbra** where the inclined field
only partly suppresses it, and bright **faculae** around both, where the flux
tubes are small enough that you see the walls of the depression rather than the
floor. All three come from thresholds on one field, which is what makes them
concentric. Plus a **magnetic network** on the supergranule boundaries, derived
from the same lane field that draws the cell shadows — the bright network and the
dark lane are the same structure at different field strengths.

**Differential rotation was tried in the texture first and it does not work
there.** The animation depends on walking a closed circle in noise space so the
last frame rejoins the first; scaling the phase by latitude means only the bands
at full scale complete the circle and everywhere else the loop snaps on repeat. A
2.4-second loop cannot carry a multi-day phenomenon. It moved to the shader as a
latitude-dependent shift of the sampling longitude — no loop to close, and no
seam because an equirectangular sheet is periodic in longitude. That does require
star surfaces to be uploaded with `repeat: true`; clamped, the shear would smear
the seam column across the disc.

**Verified.** Build smoke green, full smoke 65 draw calls with no errors, all 24
zones on deck, worst interior 64, 21 buttons / 0 overlaps, all ten systems inside
budget, every screen clean, shaders compile.

### 16r — Celestial and FX textures at 2x, and what the resolution ceiling actually is (0.12.0)

First tranche of the owner's "more pixels everywhere" batch. Doubled: planet and
cloud sheets 384x192 -> 768x384, star photospheres 512x256 -> 768x384, coronas
192 -> 384, nebulae 320 -> 640, rings 256 -> 512, the singularity and swirl
256/128 -> 512/256, and every FX sprite (flame, cold jet, glow, smoke, shield,
plasma). The planetology simulation grid went 144x72 -> 208x104 so the geography
behind the finer sheet is finer too.

**Two things the measurements settled, and they matter for the rest of the batch.**

*The interior cannot use the extra resolution.* Bumping `TEXTURE_SIZE` 128 -> 256
was tried and reverted. At a 480x270 render target an interior texel is already
smaller than a screen pixel on any wall more than a couple of metres off — the
mip chain averages the extra detail straight back out. It cost 4x the generation
time and 4x the memory for no measurable change in what reaches the screen.
Interior materials stay at 128.

*The binding constraint on apparent pixel size is the RENDER RESOLUTION, not the
textures.* At 480x270 upscaled to a 1080p display, one rendered pixel is a 4x4
screen block, and that block size is what reads as chunky. No texture resolution
can make it smaller. The lever is `RENDER.WIDTH/HEIGHT` — which is pillar 3 in
`CLAUDE.md` and therefore an owner decision, not one to take quietly. Flagged for
the owner; not changed.

**Boot cost went 3.0 s -> 7.2 s** and that is the honest price of this tranche.
Two mitigations landed with it: star photospheres went to 768x384 rather than
1024x512 (6 frames at 1024 cost 3 s per spectral class, which lands as a hitch on
every warp arrival), and the eager planet/cloud texture block in `main.js` was
deleted outright — it duplicated what `primeSystemTex` already builds for the
starting system, and once the sheets were 768x384 it was spending a second and a
half of the loading screen on worlds the player may never visit. Everything is
built on demand now.

**Verified.** Build smoke green, full smoke 65 draw calls with no errors, worst
interior 64 draws. Interior frame rate in the software rasteriser fell 18 -> 12,
which is a texture-bandwidth effect that a real GPU should absorb, but it is
untested on hardware and is the thing to watch.

**Not started in this tranche:** the weapon system, the HUD rework and
repositioning, window scrolling, and the animation-smoothness pass.

### 16s — Nine hardpoints: ammo, guidance, warheads and point defence (0.13.0)

The ship had exactly one gun — a pulse laser on a fixed cooldown, drawing the
capacitor, doing one damage number to whatever it touched. Every fight was the
same fight.

`src/combat/Weapons.js` is a registry of nine full weapon specifications, and
`SpaceCombat` drives all of them through one projectile loop. The differences
that matter in play come out of the data, not out of branches:

- **PULSE** — the original energy lance, unchanged in feel. Infinite shots,
  weakest hit, and it competes with the shields for capacitor. The fallback.
- **RAIL-L / RAIL-H** — light and heavy railguns. Flat, fast, kinetic; the heavy
  is the only slug that threatens a hull in one hit.
- **SCATTER** — six sub-calibre slugs in a cone. Hopeless at range, brutal close.
- **ROCKET / TORPEDO** — guided, proximity-fused, splash. Turn rates are
  deliberately finite so a hard break can still beat them.
- **WARHEAD** — fission. 340-unit blast, four in the locker, and the splash check
  runs against the Aethon too, so firing one inside its own radius will take your
  own hull off.
- **EMP** — almost no damage and still the strongest thing aboard against a
  swarm, because a drone whose systems are down cannot manoeuvre, shoot or run.
  Detonates on a timer; never has to hit anything.
- **PDC** — point defence. Does not target ships at all: it hunts incoming
  hostile PROJECTILES, which makes its value the shots you did not take.

Mechanically new: `Loadout` holds magazines and the selected hardpoint; guidance
steers the velocity vector at a finite rate rather than snapping to the target;
proximity fuses let a near miss count; splash damage falls off linearly from the
centre; and `disable` seconds knock an enemy out of the AI loop entirely. Running
a magazine dry auto-swaps to the next loaded weapon rather than leaving the
trigger dead, falling back to the laser at worst.

Each weapon carries its own hit signature — flash scale, spark count and colour,
smoke, expanding shock rings, screen shake — so a PDC tick, a railgun slug and a
fission warhead land as three different events out of one `_hitFx` path.

Controls: `C` or the new WPN button (directly above FIRE, so a thumb already on
the trigger can reach it) cycles hardpoints. The HUD gained a WPN block above
DRIVE showing the selected weapon and its rounds, red under a fifth of a
magazine, reading CAP for the energy weapon. Docking now replenishes ordnance as
well as fuel and air — magazines are the reason to come back to a station.

**Verified.** All nine fire and consume ammunition correctly, spread weapons
spawn their full salvo (scatter 6, PDC 2), projectiles detonate and produce
sparks and smoke, no errors. Full smoke 65 draw calls, 22 buttons / 0 overlaps,
worst interior 64 draws.

**Still open from the owner's batch:** the HUD rework and repositioning, window
scrolling, the animation-smoothness pass, and the render-resolution decision
flagged in 16r (which is the actual lever on apparent pixel size).

### 16t — Themed scrollbars and machined HUD chrome (0.13.1)

**Scrolling.** Most windows already carried `overflow-y:auto`, so long content
technically scrolled — with the browser's default rounded grey pill, which reads
as a web page bolted onto a 16-bit console, and with no visible affordance at all
on touch. A player with a long journal or a ten-row warp chart had no way to know
there was more below the fold.

`Chrome.installScrollChrome()` injects one stylesheet: a hard-edged amber slider
with chamfered corners and grip notches in a recessed channel, `scrollbar-color`
for Firefox (which has no WebKit pseudo-elements), `overscroll-behavior: contain`
so a flick inside a panel does not scroll the page behind it, and `touch-action:
pan-y` so the drag actually works on a device where the canvas otherwise swallows
gestures. Applied via `scrollable(el)` to the journal, trade counter, warp chart,
settings sheet and approach panel.

**HUD chrome.** `_panel` was a rounded box with a one-pixel outline. It is now
five layers, each a real thing on an instrument bezel: chamfered corners (the
strongest "milled plate" signal available at four pixels), a lit top-left and
shadowed bottom-right edge, an INNER shadow one pixel under the lip — which is
the layer that actually creates depth rather than just an outline — corner
brackets inset like a screwed-down instrument face, and mid-span rivets on any
plate wide enough to need the extra fixing.

Side panels narrowed 128 → 114 (100 with the touch gutters) on the owner's "a
little smaller" note. The floor is set by the DRIVE block's widest string,
MODE / ASSIST, which needs 96px of plate before the label and value columns
collide.

**Verified.** Full smoke 65 draw calls no errors, 22 buttons / 0 overlaps, every
screen clean, all nine weapons still firing.

**One thing I could not confirm:** the new WPN block renders its label and value
butted together as "WPNPDC". The fix (moving the value from x+22 to x+26, since
three 6px glyphs from x+4 end exactly at x+22) is in the source, but two
re-renders still showed them touching and I ran out of room to find out why —
most likely the harness is serving a cached module. Worth a look next session; it
is cosmetic and four pixels wide.

**Still open from the owner's batch:** the animation-smoothness pass, and the
render-resolution decision from 16r, which remains the actual lever on apparent
pixel size.

---

## Session 16u — Render resolution becomes a setting; the tile grid dies

Two owner asks, both of which turned out to be about the same thing: the game
looked like a pattern rather than a place.

### The render resolution (finally)

Sessions 16q–16t all tried to answer "finer pixels" with texture density, and
16r established why that could never work: at 480×270 upscaled to 1080p, one
rendered pixel is a 4×4 block of screen pixels, and every texture is sampled
*down* into those blocks. Raising interior textures 128→256 at that buffer size
cost twice the boot time for nothing visible. The lever was `RENDER.WIDTH/HEIGHT`,
which is pillar 3, so it was flagged rather than changed. Asked a fourth time, so
it changed.

`RENDER.WIDTH/HEIGHT` are now the **scene** buffer, from a preset: 480×270
CLASSIC, **960×540 FINE (default)**, 1920×1080 SHARP. New `RENDER.UI_WIDTH/
UI_HEIGHT` stay pinned at 480×270 for all 2D chrome.

The split is the whole design. The HUD is hand-placed pixel rects and 6px bitmap
glyphs; scaling that grid shrinks the chrome, it does not detail it. The 3D scene
has no such ceiling. The hud shader's `u_resolution` carries the UI size, so one
UI pixel maps onto `RENDER.SCALE` scene pixels and integer snapping stays exact.
The CRT post-process pattern pitch is pinned the same way — tie it to the real
buffer and 540 scanlines on a 1080-line buffer are invisible, so the effect the
player toggles would silently vanish at the high presets.

**No 1440×810.** It upscales to 1080p at 1.33×, and a fractional
nearest-neighbour upscale drops pixels unevenly and staggers straight lines. A
resolution option whose purpose is cleaner pixels must not add shimmer.

`TEXTURE_SIZE` now follows the preset (128 / 256). A 2m wall three metres out
spans ~150 buffer px at 480 wide, where 128 texels is already 1:1; at 960 it
spans ~300, so 256 is what restores it.

Two things the change exposed rather than caused:

- **Screen furniture was anchored to the viewport, not the canvas.** `fitCanvas`
  letterboxes at some scales and fills at others, and the finer presets fill far
  more often — so the BAG/SCAN/MENU/LOG column, until now hidden in the letterbox
  border, landed on top of the SENSORS panel. Chips and the touch layer now
  anchor to the canvas rect, and the HUD gutter is *measured* off the column and
  converted to UI pixels instead of a fixed 44 that only applied in touch mode.
- **The sub-pixel body cull was hardcoded against 270 lines.** Now derived from
  the live buffer height. `BODY_DRAW_CAP` still holds the budget: 43 draws at
  FINE, 46 at SHARP, ceiling 100.

Also closed 16t's loose end: the WPN block really did render "WPNPULSE". Two
fixed offsets failed because AMBER9 is a 7px-advance face, so `x+26` was a 2px gap
on glass, not 4. It now right-aligns through `_readout` like every other
label/value pair — cannot collide by construction.

### The squared grid

Owner mid-session: *"I don't want any patterns or this visible squared grid."*
Fair. Three interior textures were literal grids, and the finer buffer made them
sharper and therefore more obvious.

**Dumping each texture as a 3×3 repeat is what made this tractable** — a tile can
look completely fine on its own and still form a lattice. Two rules came out of
it, each after a failed first attempt:

1. **Varying the cell sizes does nothing.** The first ceiling fix gave the 16px
   lattice uneven row and column pitches and came out *worse*: every cell is
   still an outlined inset box, and outlined boxes tiled two ways are a lattice
   however jittered the spacing. It is now **linear** — ribs of varying width,
   conduit runs, one flush access strip, no cross seams at all. A 1D pattern
   cannot read as a squared grid, and cable trays are the better reference than
   suspended tiles anyway; the transverse rhythm already comes from the real
   ceiling-beam geometry.
2. **A tile must carry no memorable feature.** The first `wallTile` rewrite fixed
   the layout properly — four irregular courses in running bond, so vertical
   joints never stack into columns — and *still* read as a pattern, because it had
   four rust streaks and four bright scratches. Anything localised and
   high-contrast is a landmark, and the eye then counts it five times across one
   wall. Wear is now diffuse, with one short rust bleed and one faint scratch.

Supporting fixes: joint colours come off the *middle* of the ramp, not the darkest
entry (`shade(ramp[0], 0.55)` plus normal-map depth reads as a black outline
around every plate, which is what draws the lattice); rivets down to one per plate
on alternate courses; `wallMilitary` down to a single shade-change panel with no
lit lip; per-plate value steps narrowed from 19% to 8%. The stencilled 'K-7' is
gone — legible text on stock that repeats every 2m announces the tiling louder
than any seam, and that serial appeared three times across one cockpit wall.

`interior.frag` supplies the variation that *cannot* repeat, because it is keyed
to world position rather than to the tile: a per-tile brightness step from a hash
of the integer UV cell, and two octaves of world-space staining at ~5m and ~1.6m
that cross tile boundaries. Both fold into `light` before the level quantizer, so
they emerge as discrete bands, not banned smooth gradients. (First attempt
centred the grime on 0.95 and dimmed every wall in the ship.)

### Animation smoothness (16t's other loose end)

The loop ran a fixed 60Hz accumulator and rendered with no interpolation, so on
any display that is not exactly 60Hz some frames advanced the sim twice and some
not at all. A first-person camera stutters visibly from that even at a locked
60fps, and on a 120Hz panel half the frames drew the identical view.

- `Engine` gains a `frame(frameDt)` phase between the fixed steps and render, and
  passes `alpha` through. Its docstring now states which of the three phases a
  piece of work belongs in, since that choice is what decides whether it looks
  smooth.
- `PlayerCamera` and `Spaceship` snapshot their previous simulated state and
  resolve the drawn one against `alpha` — eye position, and hull attitude (which
  swings the whole view through the glass). **`Spaceship.beginStep` rewinds `quat`
  to the last simulated value first**: `FlightController` integrates from whatever
  it finds there, so without the rewind the sim compounds its own display
  smoothing. `snapHistory()` drops the history on warp arrival, save load and
  debug teleports — those are cuts, not motion.
- Mouse look moved from the fixed step into `frame()`. Inside the accumulator,
  aiming was quantised to whichever frames carried a step: none meant the delta
  was held over (latency, then a jump), two meant it all landed in the first.
- The HUD clock was `+= 1/60` per render call, so every sweep and blink ran at
  double speed on 120Hz and half at 30fps. Now the real frame delta, capped so a
  stall doesn't fast-forward a cycle.
- **A 5-step ceiling on catch-up.** The accumulator alone is a death spiral: a
  long frame queues extra steps, which lengthen the next frame, and the game
  slides into slow motion it can't climb out of. Past the ceiling the backlog is
  dropped — the sim clock falling behind real time is invisible; a spiral isn't.

### Notifications

Third position was the charm. y=168 growing upward put lines two and three
through the interact prompt and the crosshair; under the compass crossed the
SENSORS panel (a long message is ~385px of a 480px grid). Now 162–184, the only
full-width empty band on screen — 22px, so `MAX_VISIBLE` drops 3→2.

### Verified

All three presets in Chromium: buffer and UI sizes correct, zero console errors,
all ten systems reachable, interior 42 draws (<200), worst space 43/46 (<100),
chips inside the canvas box with the gutter covering them. Boot 6.4–8.7s.

### Caveat worth repeating

**The fps numbers from this harness mean nothing about real performance.** It
runs SwiftShader, which shades every pixel on the CPU, so measurements scale with
pixel count exactly as you'd expect and say nothing about a GPU. 960×540 is a
trivial render target for any real hardware, but it is unmeasured on any, and
CLASSIC is one setting away if it bites.

### The de-tiling pass, completed (0.14.2)

The first tranche only fixed the five surfaces that were visibly worst. Built a
**contact sheet of all sixteen tiling surfaces at 2×2** (props excluded — they use
uvScale 1.0, so one texture is one object and an internal grid never repeats) and
eleven still failed. Both rules from above applied mechanically:

*No outlined inset box tiled two ways:* `wall_steel`'s inspection hatch,
`wall_engine`'s recessed junction box with its amber and steel gauges,
`wall_reactor`'s even 24px vent pitch and shielded panel, `floor_plate`'s access
plate (which `floor_cargo` and `floor_hazard` both inherit), `fixture_white`'s
8px double grid, and both hull textures' 4×4 / 16×21 crossing grids — all now
running bond, shade changes or uneven linear runs.

`wall_cargo` was the worst: one square bay per tile, framed all four sides with a
full X, i.e. a perfect grid of identical braced squares. The concept art does
want an exposed truss and a truss is inherently repetitive, but a real one has
unequal bays braced only where the load needs it — so two bays of 27/37, a single
diagonal in the narrow one, a horizontal tie across the wide one. Its backing
also went from near-black to grime: the frame was a bright graphic floating on
void, and there is pressure hull behind a cargo truss, not space.

*No legible text on tiling stock:* 'RAD-3' left `wall_reactor` (four copies
across one wall), 'KSV-114' and 'AETHON' left the hulls — the ship's own name
marched down its flank a dozen times, and reading the registry twice in one
silhouette destroys the illusion that it is a hull. Every surviving `_stencil`
call is on a prop, where text is one-off and wanted.

**Note on the exterior mirroring.** 16t leaned on `u_tileVary` to break the hull
repeat. Mirroring only changes *which copy* you see; it cannot help when the cell
itself is an outlined square, because a mirrored square is the same square. The
layout had to change.

**Twice I broke rule 2 immediately after writing it down**, and the contact sheet
caught both:

- `fixture_white` cracked every eleventh tile. `r` is deterministic in `x0` and
  course, so the *same* tiles cracked in every copy — a row of identical
  stair-step marks marching along the wall. Its glaze spread was also 27%, which
  made every unit a distinct block and turned the washroom into breeze block; now
  ~5%, with dirt carrying the character. Grout lightened and its relief cut from
  −0.34 to −0.18, because `NORMAL_STRENGTH` is 2.05 and the deeper step rendered
  every joint as a masonry bevel.
- `aethon_hull`'s corner-anchored wear gradient existed to exploit the mirroring.
  Against the new plating it dumps as a bright diagonal wedge per tile, and four
  mirrored wedges meet in a huge X across the hull. Also the closest thing left
  to a banned smooth gradient. Gone.

### Cargo bay lighting (found while verifying, fixed because unusable)

The bay measured **mean scene luminance 13–17 against 50–59 for every normal
compartment, p95 of 24** — even its brightest pixels were near-black. Not the
texture work: four tubes of radius 8 cannot light a 14×20×8m hold. Attenuation is
`(1 − d/radius)²`, so from mid-bay the nearest fixture sat 6.9m away and gave
`(1 − 6.9/8)² ≈ 0.02`. The room ran on ambient alone; a 2.8m compartment gets
~0.59 from its tube at 1.5m.

**The fix is fewer, LARGER lights, not more.** `LightSystem.gatherForZone` keeps
only `MAX_LIGHTS_PER_DRAW` (8) per zone and ranks by `intensity × radius`, *not*
by distance to the camera — past eight fixtures nothing is gained and a nearer
one can be crowded out. Six tubes plus the two floor seams is exactly the budget.
Radius 17 puts mid-bay at ≈0.38 per tube; intensity 0.85 → 0.6 because six
overlapping lights of that radius otherwise sum past the shader's 1.35 clamp and
flatten the near-fixture highlights.

After: mean 17.4 → 26.5, p95 45 → 75, and the deck plating, racking, crates and
far door all read. It stays below a small room's mean and should —
`DISTANCE_DARKEN_FLOOR` caps distant surfaces at 0.6 and most of a 20m room is
distant, so mean luminance is not comparable across room sizes.

### Next

- Owner tasks 84–87 (button styling, approach window, star-surface animation,
  more content) are still open from before this batch.
- **`gatherForZone` ranks lights by `intensity × radius`, not by distance to the
  camera.** Wrong in principle for any large room, and the cargo bay only works
  now because its fixtures were sized around the limitation. Re-ranking by
  distance would silently re-light every compartment on the ship, so it wants its
  own session with before/after shots of all fourteen rooms — not a drive-by.
- Corridor hoops and prop textures still unaudited for grids. Props are low risk
  (uvScale 1.0 means no repeat), but corridor walls tile at uvScale 0.6.
- The washroom units read as ~25cm large-format tile rather than small ceramic.
  That is the 2m/64-texel design grid, not a bug, but if it should be finer the
  lever is `uvScale` on that room's walls, not the texture.


---

## Session 16v — Detail back in, without the pattern back in

Owner, after 16u: *"textures are wrong… redo visuals/textures, there are many
repeating patterns and whole interior and ship is missing details, its now feels
so empty, keep the tiny pixels but add complex details, depth as it was before.
And enhance weapons effects… make it multi layered."*

Fair, and the two halves are not in tension once the rule is stated properly:

> **Detail does not cause a visible repeat. FEW, LARGE, HIGH-CONTRAST details
> cause a visible repeat.**

16u solved the pattern by *deleting* detail. A tile carrying one bright outlined
hatch, one stencil and one bold scratch turns a wall into wallpaper, because the
eye finds those three marks and counts them across the room. The same tile
carrying two hundred rivets, weld spatter, chipped paint and hairline scoring
reads as **material** — no single mark is findable, so there is nothing to count.
The answer was to go the *other* way: dense, small, low-contrast.

### The detail toolkit (0.15.0)

`TEXTURE_SIZE` is 256 over a 2m tile, so one output texel is ~8mm — small enough
that hundreds of marks read as surface. Ten new Painter primitives, all writing
the height field, because depth is what the normal-mapped lighting turns into
real shading:

`microGrain` (anisotropic — a directionless mottle reads as noise, a grain
direction reads as metal), `weldBead` (wobbling, pulsing width, heat scorch
either side), `microRivet`/`rivetRun`, `paintChips`, `hairlines`, `dents`,
`scoreLine`, `stainRun`.

**`edgeWear` is the one that does most of the work.** It derives wear from the
HEIGHT FIELD rather than a hand-placed list, so it follows whatever structure the
generator painted and no two surfaces wear alike: bright on raised edges (paint
rubbed to bare metal), dark in recesses (dirt packed in). Every plate lip, weld
crest and rivet head reads as three-dimensional for free.

`_finish()` composes seven of them in a fixed order. **edgeWear must run after
all structure and dents** (it reads the height field and has nothing to follow
otherwise) **and before the grime** (dirt settles on top of worn metal).

Wear is tuned per material, not uniform: decks get heavy scuffing and no gravity
runs (nothing drips onto a floor), the hull gets heavy pitting and almost no rust
(no moisture in vacuum), ceramic gets limescale and little denting, the cargo
truss gets the most rust aboard.

Measured: `wall_military` ~500 → 1723 distinct colours. **Boot 6.2s → 9.0s** — the
per-output-texel passes are genuinely expensive, and this is the obvious thing to
optimise if boot ever becomes a complaint.

### The ship still felt empty — that was geometry (0.15.1)

Three causes, all in `Greebles.js`:

- **A flat cap of six greebles per wall run**, which applied hardest exactly
  where it hurt most: a 20m cargo wall got the same six objects as a 3m cabin
  wall. Now scales with run length (to 22), density 1.05 → 0.8 m/slot in rooms
  and 2.0 → 1.3 in corridors — corridors were the worst and are where the player
  spends most of their time.
- **Eleven kinds, all in the same 0.9–1.5m band.** Nine more, weighted to TALL
  and LONG: pipe cluster, access ladder, handrail, grille bank, breaker cabinet,
  hose reel, supply locker, sensor pod, cable spool. Several are *structure*
  rather than another box on a wall, which is what makes a hold read as a
  working space.
- **Nothing between them.** A new micro layer scatters 4–20cm fittings on a
  ~0.35m pitch through the gaps, spread across the wall's whole height (a wall
  with detail only at chest height still reads as bare above and below).
  Individually almost invisible; collectively the difference between a built
  surface and a painted one.

Plus `edgeStructure`: corner angles, a skirting duct with access covers, and a
cornice cable tray. Edges are where a real compartment carries most of its
ironmongery and where this ship carried none — every wall met its neighbour in a
bare mitre.

**Draw calls unchanged at 42** — it all batches into the existing interior
buffer, so the cost is vertices, not binds.

### Weapons, multi-layered (0.15.2)

The old system had one particle type: fixed colour, fixed size, straight line,
constant speed, then gone. That reads as a sprite being switched off.

- `_ejecta()` gives every particle a hot colour, a cool colour, a start and end
  size, and drag. Particles now cool, shrink and slow. **Drag matters more than
  it sounds** — without it everything flies off perfectly straight at constant
  speed, which is what made the old bursts read as a starburst decal.
- `_debris()` adds solid fragments: slower, longer-lived, barely luminous. Sparks
  alone make every impact a firework; debris is what says something SOLID broke.
- **Impacts in four layers** — incandescent core (gone in <0.1s, which is what
  makes a hit read as instantaneous), cooling spark shower, fragments (skipped
  for the EMP, which should look like a discharge), and long-lived embers so the
  site stays alive instead of snapping back to empty space.
- **Muzzles in three** — a flash cone thrown FORWARD along the bore (the old one
  threw symmetrically, so emitters looked like they were leaking), propellant
  washing back, and an ejected case on slug weapons.
- **Tracers.** Every bolt records its path at a fixed 12ms rate (fixed, not
  per-frame, so a tracer is the same physical length at any frame rate) and
  draws as a fading streak. A round crossing 900–2600 units/s covers more than
  its own length between frames — as a single point it is a dot that teleports.
  Biggest readability win in a firefight.
- Point budget 220 → 900. The old cap silently dropped whatever came last, which
  was always the sparks, because bolts are written first.

### Process note

An early patch script asserted mid-batch and only wrote the file at the end,
silently discarding three good edits that had already applied. Scripts now
validate every match before applying any. This cost a full verification cycle to
find, because the code *looked* right in the diff I had in mind and wasn't on
disk.

### Next

- Boot is 9.6s at FINE. If that becomes a complaint, `microGrain` is two noise
  evaluations across 65k texels for each of eleven surfaces and is the first
  thing to cut.
- Tracer streaks are verified functional (every bolt carries history, renders as
  a fading tail) but hard to judge from a static screenshot at 900 units — they
  want a look in motion.
- `gatherForZone` still ranks lights by `intensity × radius` rather than by
  distance (see 16u). Unchanged, still wants its own session.
- Owner tasks 84–87 remain open.


---

## Session 16w — Plasticity: stacked silhouettes, inside and out

Owner: *"add more plasticity and themed decorative elements and parts to the
interior and exterior. Make it more complex, multi layered, with depth."*

One principle drove everything:

> **Depth comes from stacked silhouettes.** A single box at one depth reads as a
> sticker however good its texture is. Two boxes at different depths give a step
> line and a shadow of their own before the outline even starts.

So every part added here is built in three or four tiers, and that is the whole
technique.

### The enemy ships were the real exterior gap

They had never been touched in sixteen sessions. **The Keth fighter was six boxes
and the Drift drone was six boxes**, and both are on screen in every fight while
the Aethon already had 8876 triangles.

- **Keth** 144 → 1512 verts. Fuselage in three stacked plate layers of
  *decreasing width*, so two step lines run its whole length. Nose in three
  stages to a probe needle; wings gain root fairings, fences standing proud of
  the blade, tip pods with their own spikes, underwing rails with pylons and
  stores; nacelles get intake lips proud of the body and separate exhaust rings.
  Seeded greeble field so a Keth always looks the same but never bands.
- **Drift** 144 → 1200 verts. They are a machine race that *grew*, so the core is
  a crystal habit: three nested masses, never on the same centre. **Every shard
  now carries a sub-shard on one face plus a filament strut back to the core** —
  two-tier relief on every limb is what makes it read as grown crystal instead of
  a handful of loose boxes. Eight shards, twenty-two micro-facets.
- **Aethon** 8876 → 11144 hull tris, all of it *ship furniture* — the parts a
  crew touches, which it had almost none of. Paired ribbed stringers with gusset
  feet (**the pairing is the point**: two ribs with a gutter catch two light
  bands and a shadow; one rib catches one edge and reads flat), caged floodlamps
  with four guard bars in front of the lens (an unguarded glowing box is a decal;
  a guarded one is hardware), segmented grab rails on stand-off stanchions, whip
  antennae in deliberately asymmetric clusters.

### Five themed interior fittings

Carrying the house style rather than generic machinery, each three or four tiers:
`quiltPadding` (backing plate → 4×4 proud pads → button dimple in each; the
signature corridor lining of the reference and the only soft thing aboard, and
allowed in corridors where it belongs), `flexDuct` (alternating wide/narrow
segments so the corrugation is *geometry*, not a painted stripe), `cageLamp`,
`cableLoom` (five lines at four depths so the bundle has a rounded profile
instead of being a flat ribbon), `hatchSurround` (gasket frame → liner → dogged
door → four dog levers and a centre wheel).

### Verified

Interior 42 draws — **unchanged**, because all of it batches into the existing
buffer, so the cost is vertices not binds. Flight 73, worst space 43 of 100, boot
8.2s, zero console errors, room tour clean across all six compartments plus the
chase cam. The stringer bands read on the hull at chase distance, which was the
test that mattered for the exterior work.

### Next

- Enemy ships were verified by build (vertex counts, clean winding via the
  sorted-extent helpers) and no console errors, but **not photographed in
  combat** — they want a look with a Keth close to camera.
- Boot is 8.2s at FINE; `microGrain` remains the first thing to cut if that
  becomes a complaint.
- `gatherForZone` still ranks lights by `intensity × radius` rather than
  distance (16u). Unchanged.
- Owner tasks 84–87 remain open.


### 16w continued (0.16.1) — the two surfaces that still had nothing

**The ceiling was the emptiest surface on the ship.** Two conduits and a few
cross-ties over a flat plane — less detail than any wall, on the surface the
player looks straight *up* into. The reference interior is densest overhead,
because that is where a ship routes everything it does not want underfoot.
`overheadRig()` hangs four tiers: a centreline trunking duct in **segments with
collars and hanger straps** (each collar is a step and a shadow line, so a 20m
run reads as assembled ductwork instead of a bar), cable baskets with rails and
three loose runs lying in them, caged deckhead lamps, sprinkler/sensor drops.

**The deck had nothing standing on it** — a flat plane with a texture, and it is
a third of what you see while walking. `deckFittings()` adds tie-down rings,
bolted access hatches (liner → lid → four dogs → lift ring), a cable ramp, and
walkway kerbs. **The kerbs matter most**: a room with a defined walkway edge
reads as laid out; a room whose floor meets the wall in a bare line reads as a
box you were dropped into. They are broken into periodic raised blocks, because
a plain continuous strip reads as a painted line rather than a fitting. All ≤7cm
and collider-free, so they read as flush fittings you walk over.

**Freighter 120 → 2172 tris.** The spine is now an open **truss** — four chords
with ring members and diagonal webbing — not a solid bar. Giving the silhouette
holes to see through is worth more than any amount of surface detail on a box,
and an exposed spine with the load hung off it is the entire point of a pod
hauler. Pods went from one box each to body + hoop ribs + end caps + cradle keel
+ clamp arms + dorsal walkway.

### Verified / not verified

Interior 42 draws (unchanged — it batches), flight 73, worst space 43 of 100,
boot 6.7s, zero errors, room tour clean. Overhead trunking visible in the med bay
shot.

**Still not photographed: the rebuilt Keth and Drift close to camera.** Two
attempts this session both failed on harness framing — the chase cam centres on
the Aethon so a 22-unit offset puts the target *inside* the hull, and
first-person at 46 units renders it a few pixels across. The geometry builds with
correct vertex counts and clean winding and throws no errors, but I have not
looked at one. Next attempt wants the target ~200 units out and offset laterally,
with the approach popup suppressed.


---

## Session 16x — The damage model was broken; the panels were never wired

Owner batch of eight items. Two done properly this session, six still open (listed
at the end). The two done were the ones that were *broken* rather than thin.

### The damage bug (0.17.0)

Owner: *"when getting hit it not hitting hull indicator not changing, its always
hit shield because they got minimal 1%"* — diagnosed exactly right, and it was one
line with a large blast radius. `ShipSystems.update` ran

    this.shield = clamp(this.shield + 1.5 * dt, 0, 100);

**unconditionally, every frame, with no hold-off after a hit.** So the frame after
a round emptied the shield it was already back to 0.025% — above zero — and
`if (systems.shield > 0)` absorbed the next round too. The shield could never
*stay* down, so every hit for the entire game went to the deflector and the hull
bar never moved once.

Fixes: a 4s regen hold-off after any hit; an emptied shield enters a **collapsed**
state that reboots from nothing (7s, then 4.5%/s until it clears 25%) instead of
trickling out of zero; regen draws reactor power; and **damage overflows** — a
40-point hit on an 8% shield takes the shield out AND puts 32 into the hull.

`hull` is now the mean of six sections. `_sectionOf()` classifies by transforming
the impact into ship-local space and taking the dominant axis, **with z scaled by
0.42 first** — the Aethon is long and thin, so a raw test called almost every hit
fore or aft. Hits leave persistent breaches stored in ship-local space and
converted back to world every frame, so the plume stays welded to the hole as the
ship manoeuvres. `_impactFx` branches on what the model actually did, so
deflected / collapsed / hull / destroyed look like four events instead of one.

`destroyShip()` is shared by enemies and the Aethon — six overlapping stages,
because catastrophic failure is a *sequence*: containment flash, three shock
shells at different speeds (one ring reads as a decal, three read as a front),
fuel deflagration that lingers, structural debris, smoke, delayed secondaries.

Verified four ways including the one that matters: **a hit empties the shield and
it is still 0.00 after two seconds of live sim.** Before, it was back above zero
within a single frame.

### The panels were never wired (0.17.1)

Two findings, the first on me. **Session 16t's commit claims `scrollable()` was
applied to five panels. The imports landed; the calls did not.** It was imported
five times and invoked zero times. I verified the stylesheet existed rather than
that anything used it — a lesson about what "verified" has to mean.

And it could not have worked anyway: TouchControls' document-level `touchmove`
handler calls preventDefault unconditionally while the touch layer is visible,
cancelling the gesture before the browser can scroll. Now it bails on
`e.target.closest('.sr-scroll')`.

New `panelChrome()` gives every window a themed ✕, Escape, and a scroll region.
Before, three windows (journal, warp chart, approach panel) had no exit but the
key that opened them — unusable on touch. Escape uses ONE document listener with
a stack so only the innermost visible panel responds.

**`offsetParent` is null for `position:fixed` elements** — the naive visibility
test reported every panel closed and Escape did nothing. Same trap as the HUD chip
layout in 16u. Now prefers each panel's own `visible` flag.

### Target lock (0.17.2)

Homing weapons used to grab whatever `_nearestEnemy` returned at the moment of
firing — the pilot had no say and no readout. A lock is the missing feedback loop.

**Two cones, deliberately far apart.** ACQUIRE is ~21° (you must point at it);
RETAIN is ~70° (an established lock survives a hard break). One cone for both
makes locking either trivial or impossible-while-manoeuvring; the interaction
lives in the gap. Acquisition takes 1.1s of steady tracking, with 1.4s of grace
before a lost target drops. `cycleLock()` (T / the LOCK touch button beside FIRE
and WPN) steps to the next candidate by range rather than re-locking the same
hull.

HUD reticle has three states because a lock is a *process*: brackets marching
inward from 16px to 6px (the motion IS the progress bar), closed brackets plus
range and integrity once locked (numbers only after locking — showing them during
acquisition implies data you haven't earned), and an edge chevron when the target
is off-screen, which is exactly when you most need to know where it is.

**Harness lesson worth keeping.** Two of the eight checks first read as failures.
They weren't: the probe waited on WALL time while the sim runs on the fixed-step
clock, and under software rendering (~8fps in flight) Engine's own 5-step
catch-up cap drops backlog — so **simulated time advances at ~0.67× wall time**,
leaving both checks just short of the 1.1s lock. Added `__debug.engineTime()`;
anything timing-dependent must wait on simulated seconds. I nearly "fixed" a
non-bug.

Also: **the rebuilt Keth is finally photographed** (carried debt from 16w). Two
earlier attempts failed on framing — the chase cam centres on the Aethon, so a
forward offset puts the target inside the hull. A *lateral* offset works, because
the hull is ~70 long but only ~10 wide.

### Keth corvette (0.18.0)

A capital hull, and the first hostile that cannot be handled like a fighter.
1752 tris at ~34u: five keel slabs, four turret barbettes with twin barrels,
missile cell blocks, a PD stub battery down both flanks, four drive bells. Stationed
only at Thresher, spawned through a new `escort` field so it arrives alongside the
fighter patrol rather than replacing it.

It carries **its own deflector** (220), and both player damage paths route through
`_hurtEnemy()`, so it cannot be chipped down by a PDC the way a fighter can. It
fires a **salvo** — four rounds walking out of separate barbettes at 0.11s spacing,
3.4–5.0s reload — because one bolt from a hull that size reads as a fighter with
more hit points, and the spacing is what gives you room to break between rounds.

`_makeHostile()` exists so escorts and patrols cannot drift apart in fields; the
old inline object literal was duplicated and the escort path silently omitted
`hpMax`.

### The singularity is a 3D body now (0.19.0)

The jump effect was a stack of camera-facing sprites. It is now real geometry:

- the **event horizon is a sphere**, so its silhouette is round from every angle
  and it *occludes*;
- the **accretion disk is a warped annulus mesh** in the hole's own tilted plane,
  drawn depth-tested — its far half disappears behind the horizon and its near half
  sweeps in front of it. That is the one cue a billboard can never fake.
- four disk layers at different radii, tilts and spin rates interfere;
- particles 240 → 900, split into three roles (radial in-fall with frame dragging,
  capture into the disk plane on Keplerian orbits, polar jet ejecta), re-tinted
  every frame by proximity so matter *heats as it falls*;
- jets run along the real spin axis and are depth-tested, so the horizon cuts the
  far beam.

The pass clears the depth buffer first so the singularity self-sorts while still
painting over the hull it is swallowing. **depthMask must be on for that clear to
land** — the soft-sprite pass before it leaves the mask off.

### Percentile ramps, or: the same bug twice (0.19.0)

The CME was rebuilt as a three-shell magnetic flux rope — crescent bow shock,
hollow cavity, dense trailing core knots anchored to the limb by two legs. 34
sprites against 8, up to three concurrent, staggered launch so the shells visibly
separate, and the rope twists as it climbs. `cmeTexture` snaps every sample to a
3-texel block, so a 48px sheet carries 16×16 art and the cloud stays heavily
pixelated at any on-screen size.

**Two shapes had to be thrown away first.** Radial distance bands give an ANNULUS,
and an annulus sprite reads as a soap bubble — the first eruption came out as a
stream of O-shapes. The shock is a crescent now (gated by the outward axis) and the
cavity's hollowness lives in the spatial layout, not in a hole punched through each
sprite.

**And the ramp thresholds could not be hand-picked.** Three formulas with different
natural ranges cannot share fixed cut points: one guess put the core entirely on the
brightest step (a flat pale mass), the next put it entirely on the dimmest
(invisible). Both `cmeTexture` and `plasmaTexture` now derive their thresholds from
the density field's own **percentiles**, which is range-independent by construction.

That second fix also explained a long-standing complaint I had misattributed: the
grey-tan smudges sitting on the star's disc were the **prominences**, not the CME.
Fed the pale *corona* tint and mixed three-quarters to white, they read as smoke.
Saturated away from the halo colour, they read as the star's own plasma.

### Deflector hits are local events (0.19.0)

The whole bubble used to flash on any hit, which told you nothing about where you
had been struck. Each absorbed round now leaves a ripple welded to its spot on the
field — stored as a **ship-local direction**, so it stays put while the ship
manoeuvres under it — with an expanding hex wavefront, a second wave behind it, a
white-hot strike point and four discharge arcs lashing along the surface. Three
shells instead of two, at unrelated rates so the interference crawls. A collapse
seeds the strike plus five sympathetic discharges.

Weapons got the same treatment: every round carries a **bloom sprite** behind its
tracer points (batched by colour — Keth red, Drift cold blue, player amber), so a
firefight has overlapping halos with depth instead of chains of hard dots. Enemy
guns finally have a muzzle signature, so you can tell which of five hulls is
shooting at you.

## Session 17a — the fight, the controls, the layout (0.20.0)

### Turning did not work in third person, and this is why

`main.js` consumed the look delta to orbit the hull cam **whenever the chase camera
was out**, then called `flightCtl.update()`, which found an empty delta. The ship
simply could not be turned in the hull cam. Not a tuning problem — a stolen input.

Orbiting is now a **held** gesture (right mouse / the ORBIT touch button) and
steering is the default use of that input in both views. Measured: 24.6°/s in first
person, 23.8°/s in third, where third person previously read ~0.

### A turn stick, because look could not serve both jobs

New `TurnStick` — fixed position, always drawn, right gutter. Not a
`VirtualJoystick`: those float to wherever you first touched inside a half-screen
zone, which is right for move and look and wrong for attitude, where you want to
find the control without looking and *hold* it.

It is a **rate command, not an impulse**: deflection names a target angular velocity
and the RCS chases it, so holding the stick over holds a *steady* turn instead of
winding the hull up faster the longer you hold. Applied AFTER the RCS damping, not
before — damped afterwards, the achieved rate settles at gain/(gain+damp) of what
was asked for and the flight assist quietly fights the turn it was just told to
hold. Verified steady: 14.6° over 0.6s, 30.9° over 1.2s.

Mouse steering slowed across the board (TORQUE_GAIN 26 → 15, MAX_ANG_VEL 2.2 →
1.35, damping-while-steering 2.4 → 3.4). A flick used to bank the hull most of the
way through a barrel roll before the RCS caught it.

### The ship was weak because it had no armour term

Not because the numbers were dramatic: a 100% section fell to six rounds at 16
damage each, and five hostiles put six rounds in the air in under two seconds. New
`HULL_ARMOR` (2.7) divides hull damage — the section percentages still mean what
they say, they just take about a third of the raw figure. 17 rounds to breach a
fresh section now, against 6.

Enemy speeds cut ~35% (fighters 320–360 → 205–235, corvette 130 → 95), jinks
halved in magnitude and doubled in period, stand-off pushed 900 → 1400, fire cadence
2.0–3.4s. **The point is out-turnability**: a fighter at knife-fight range sweeps
0.126 rad/s across the sky against the hull's commanded 0.62 — five to one. At the
old speeds nothing you did shook a tail, so the fight had no answer in it.

Measured under fire from four fighters *and* the corvette, taking no evasive action
for 30 simulated seconds: shield down, hull 79.5%, worst section 64%, 0.68% hull
per second. Losable, not lethal-on-contact.

### Locking was invisible

`_updateLock` returned early unless `lock.target` was already set, so the whole
mechanism did nothing until you pressed LOCK — and in a fight the one thing you do
not have is a spare hand. Pointing at a hostile now **auto-acquires**, choosing the
candidate closest to the CROSSHAIR rather than merely nearest (nearest-first kept
snapping away from whatever you were aiming at). Envelope widened and quickened:
cone 21° → 31°, range 4200 → 5200, acquire 1.1s → 0.7s, grace 1.4s → 2.6s.

### Field repair, and a repair bug that had always been there

`applyItem` bumped `hull` directly — but `hull` is the *mean* of `sections`, so the
next `applyHit` recomputed it and silently undid the repair. A hull item now patches
the worst section, which is what welding a plate on actually means. New
`repairSection()` plus `fieldRepair()` on H / the REPAIR button: costs a plate,
2.2s cooldown, and clears that section's breach so a patched flank stops venting.

### A functional radar

The old "scope" was decoration — a ring, a cross, a sweep line, and a `contacts`
*count* that was passed in and never drawn. It told you a number, not a direction.

The new dial plots real bearings, nose-up, in ship-local space. Radius is range with
a square-root compression so the near half of the envelope gets most of the dial.
**Elevation is carried by the glyph** — up-chevron above the plane, down-chevron
below, solid block within it — because dropping the third dimension is what makes
most radars useless in a 6-DOF game. Locked target gets a bracket; the four nearest
celestial bodies plot dim, so an empty system still tells you where you are.

### Layout, to the owner's markup

The right gutter carried three stacked columns and they collided at phone heights.
The fix was fewer columns, not tighter packing: throttle left, the tap row
(WARP·SCAN·LOCK·WPN) moved down off the gutters entirely, turn stick / REPAIR / FIRE
down the right, mode toggles top-right. BAG and LOG merged into one chip that cycles
hold → journal → closed. MENU took the top-right corner and **the floating settings
gear is gone** — it duplicated MENU › SETTINGS and fought the touch toggles for the
same corner. Targets are now ≥48×40 (big ones 68×50) with 10px gaps; `plasticButton`
carries a 44px floor, a deeper bevel and a rim glow.

Verified: 20 leaf buttons, **zero overlaps**, none under 44×38, and no DOM chip
sitting on a touch button. WARP/SCAN suppress their DOM chips while the touch layer
is up, because the tap row already carries them.

### Roadmap tail (0.21.0) — comets, shards, flares, the last raw button

**Comets have tails now.** A comet is the one body whose appearance is dominated by
something a lit sphere cannot show: the nucleus is a few km of dirty ice and
everything you see is what comes off it. Coma plus TWO tails, because a real comet
has two pointing different ways — the ion tail is gas swept by the solar wind and
points dead away from the star, the dust tail is heavier grains that keep their
orbital momentum, so it lags along the track and curves. Both scale with proximity:
23 sprites at 1 AU, 15 at 3, and zero past 4.2, which is the whole drama of a comet.

**Belt shards are irregular.** They were perfect spheres, so a 300km rock read as a
tiny planet — same silhouette as Redfall, just smaller. Axis ratios come from a hash
of the body id (a given shard is always the same lumpy shape) and they tumble about
two axes, because a rubble pile has no reason to be spin-stabilised.

**Star flares.** The disc already churned, rotated differentially, and threw
prominences and eruptions — but all on a timescale of many seconds. A flare is the
fast event: two ribbons brightening either side of a neutral line, fast rise and slow
decay, over in half a second. That contrast in *timescale* is what reads as an active
star rather than a looping animation.

**Three bugs found on the way, all of them mine:**

1. I gated the shard shape on `body.spin` — but *every* body spins, so the first run
   turned all 17 planets into lumpy tumbling ellipsoids. And I gated the comet FX on
   `kind === 'comet'`, which is exactly backwards: a real comet's `kind` is `'ice'`
   (that is the surface it should be textured with) while a belt *dwarf's* kind is
   literally `'comet'`. Both now key off explicit generator flags, `shard` and
   `comet`, because neither property is inferable from the ones that already exist.
2. The comet FX built, uploaded and drew 23 sprites that were then discarded by the
   rasteriser: the body pass runs with **back-face culling on** and a camera-facing
   quad is single-sided. The star's plasma escapes this only because `_drawStar` runs
   before the cull is enabled.
3. `renderExterior` keeps its own inline copy of the body draw (different frame), so
   the first version showed comet tails through the windshield and not from the hull
   cam. Both loops now carry both features — noted in a comment on each, because that
   duplication will keep biting.

And a probe lesson: **a body's `pos` is re-solved from its Keplerian elements every
tick**, so writing `body.pos` from a probe is undone on the next update. My first
comet test read 0 draws because the comet was legitimately 1.6 million units away.
Move the *ship*, or edit the *orbit*.

**Last raw button.** `#pause-settings` was the only clickable left with hand-rolled
chrome; main.js now restyles it with `plasticButton` at boot (the inline styles are
the pre-module fallback). `plasticButton` itself gained a 44px floor, a deeper bevel
and a rim glow — and every chip that shows itself with `display:block` had to switch
to `'flex'`, because the style now centres its label with flexbox and `block`
silently dropped that in a 44px-tall key. The boarding screen's keybind list grew a
COMBAT row (it never mentioned lock, repair or the orbit modifier).

### The quality checklist, actually run (0.21.1)

`context/07`'s checklist had been carried unchecked for seventeen sessions. Run it
against the live game with a probe instead of by eye and it pays for itself
immediately:

- **Found a real miss.** The small touch keys were 48x**40** — wide enough, two
  pixels short of the 44px floor the checklist itself sets. Now 48x44, big ones
  68x52.
- **Two "failures" were probe bugs.** Corridor type E is the JUNCTION hub, so
  filtering `kind === 'corridor'` both hid type E entirely and, by dropping the
  junctions from between two type-C runs, invented an adjacency violation that does
  not exist on the deck (the real order is A·E·B·E·C·E·C·D·E·B, zero duplicates).
  And "every room has 2 interactables" read 0/14 because I guessed the registry
  lived on the renderer and that records were points — it lives on `ShipMap`, and
  records are AABBs. Actual figure: 78 across 14 rooms, minimum 4.
- **Measured, not asserted:** 41 draw calls interior, 73 cruising, 79 in a
  five-hostile fight, 79 peak mid-warp, all against a 100 budget. 341 colliders.
  106 buffers / 56 VAOs before a warp and identical after — no leak. Save/load
  round-trips hull, per-section integrity, fuel and stack counts exactly.
- **Two items left honestly unchecked.** `utils/ObjectPool.js` exists and is
  imported nowhere — sparks, bolts and smoke all use plain array push+splice. Not
  currently a problem (no leaks, budget headroom) but the item is unmet. And "no
  magic numbers outside Constants" is false for the DOM UI files, which still carry
  inline hex (Chrome.js 66 occurrences, CharacterCreation 27, JournalUI 21).
- The 60fps target stays unchecked because it **cannot** be measured here:
  SwiftShader frame rates say nothing about real GPU cost. Draw calls are the proxy
  that is measurable, and those are recorded above.

### Harness lesson: two probe bugs wearing a game bug's clothes

The lock check read as a failure three runs in a row and it was mine both times.

First, `_makeHostile` jitters `pos[1]` by ±500 — at 4800 units that is ±6° on top
of the 26 the test aimed for, randomly pushing the target outside the 31° cone. The
probe has to overwrite the position, not trust the spawner.

Second, and worse: I placed the target 4800 units **along the nose** and then added
`tan(26°) × 4800` laterally, which is a slant range of **5340** — past the 5200
limit. The lock was right to refuse it. Decompose with `cos`/`sin` and assert the
distance you actually built, not the one you meant to.

Both times the instinct was to go and "fix" the lock. Measure the geometry the probe
constructed before believing what it reports about the code.

### Still open

- `gatherForZone` ranks lights by `intensity × radius` rather than distance to
  camera. Wrong in principle for large rooms; wants its own session with before/after
  shots of all 14 rooms.
- Boot is ~8.6s at FINE. `microGrain` is the first thing to cut.
- The TouchControls scroll guard is confirmed by inspection only — no touch device
  in the harness.

---

## Session 17c — the screenshot was right (0.22.0)

The owner sent a screenshot back with a short verdict: too many touch buttons, they
overlap, several were meant to be gone, BAG/LOG opens the wrong thing, the turn
stick should be invisible, get the keys off the HUD's readouts, widen the FOV, make
the HUD denser and deeper without losing anything, enhance the effects, and delete
the coronal mass ejection entirely and build a real one. Every item was correct.

### FOV 70° → 84°

One constant, `FLIGHT.FOV_DEG`. At 70 the cockpit felt like looking down a tube;
84 puts the windshield frame back in peripheral vision where it belongs.

### The turn stick is gone, and turning is better for it

`TurnStick` — a whole class, a painted ring and knob in the right gutter — deleted.
The right half of the screen was **already** a look region driving a
`VirtualJoystick`; in flight that region now feeds `setVirtualTurn` directly and
paints nothing (`silent` flag). Same rate command, same gain, no furniture. The
stick was never needed: the gesture existed, it was just wired to the wrong verb.

### 20 buttons → 13, and the layout is now arithmetic instead of percentages

Cut the four-key strafe d-pad, ORBIT, SCAN (a walking tool — it does nothing in the
seat) and BOOST (folded into throttle). Every survivor lives in the left or right
gutter, which is exactly what the HUD's `inset` reserves.

Then the harder half. The clusters were anchored in **percentages**, and that is
why they kept overlapping no matter which percentages I picked: a percentage cannot
know how tall the keys it is separating are. At 900×500 the left gutter's tap row
(top 26%, three 44px keys) reached y=280 while the throttle pair (bottom 23%, two
52px keys) started at 272 — THR+ eight pixels inside WPN, BRAKE three inside
REPAIR. New `_stackClusters()` measures the real heights after layout and resolves
each gutter bottom-up in pixels, compressing gaps before it allows any overlap;
when even that will not fit (740×360 wants 307px of keys in 304px of gutter) the
oversized 68×52 keys drop to the 48×44 checklist floor, which fits in 291px.

Verified: **13 buttons, zero overlaps, zero under 44×44, zero off-screen, zero
console errors** at 844×390, 1024×600, 740×360 and 1280×720, in both modes.

### WARP · SCAN were sitting on the VITALS gauges

They were pinned at 88.5% height on the left — straight through the HEAT and RAD
rows, which is why the condition footer read as "CDMPAIRED" in the screenshot.
`inset` cannot help: it reserves the gutters **horizontally** and cannot push a
panel down. Moved to the top strip beside BAG/LOG — x=50..170 at y=8 on the
480×270 grid is the one band no HUD plate claims (SENSORS starts at y=22, the
compass spans x=174..306).

### A bookmark strip, not a cycling button

BAG/LOG cycled two full-screen panels through one chip, so the only way to find the
journal was to tap and see. New `bookmarkBar()` in Chrome.js: HOLD and JOURNAL as
index tabs clipped over the top edge, the open one proud and lit with a thick amber
underline, the other recessed and raised 3px. Centred was wrong twice over — the
HOLD tab covered each panel's own centred HOLD title, and `top:0` clipped the 3px
lift so JOURNAL sat at y=-3. Now `left:40px; top:3px`.

(Chrome.js does **not** import PALETTE — it carries its own AMBER_HI/RIVET so the
plate painters can run before Constants resolves the render scale. Reaching for
`PALETTE.AMBER_HI` in here crashes the boot.)

### HUD: deeper, denser, nothing removed

Bar pitch 10 → 8 (gauges are 5px tall now, not 6), which is where the smaller
footprint comes from and what paid for everything below without dropping a single
readout.

`_panel` gained four layers: a **cast shadow** one pixel down-right (bevels prove
which way the light comes from; a shadow on what is *behind* proves the plate
stands off it), a **two-step face** — two flat levels and a hard machined rule,
2-bit shading, never a gradient — **screw heads** at the corners, and **index
ticks** down the right flank. New primitives: `_screw`, `_hazard` (diagonal warning
chevrons), `_grille` (ribbed vent), `_titlePlate` (an engraved legend with a rule
and an end cap).

New information, all of it live:

- **Hull section plan** — a 28×18 schematic split into the six sections
  `ShipSystems` actually tracks, each cell tinted and scored by its own integrity,
  breached cells flashing. The HULL bar shows the *mean*, and a mean is the wrong
  number in a fight: 60% could be six even sections or five good ones and a hole in
  the bow. Plus MEAN and WORST beside it.
- **TARGET plate** — type, range, and the target's shield and hull as two pips.
  Only drawn while something is tracked.
- **NAV strip** — system name, nearest body and its range.
- **G and DRF** in the top strip, measured off the velocity difference between
  frames (so a collision or a soft-limit clamp registers, not just throttle), plus
  a 13px drift dial in the centre console.
- **HDG / PIT** — you cannot call a bearing off a horizon line.
- **PR / GR** on the SENSORS plate, and a **COND** footer on VITALS.
- Walk mode's compartment name is now a bolted nameplate with mission-elapsed time.

New `ShipSystems.pressure`, driven by the **worst** section rather than the mean:
one hole vents the deck, and averaging six sections lets a breached bow hide behind
five intact ones. Measured 0.52 atm with fore at 18%.

### AMBER9 advances 7px, and I collided with that five times

`PRS`+`0.52` is 49px of ink in a 40px column → "PRS0.5". `COND`+`IMPAIRED` → 
"COMBAIRED". `WPN`+9-character type name → "KETH_C0R0K". `SH` and `HL` stacked 4px
apart with 7px glyphs → "AL". `G`+`0.0` in a 26px block. Every one was the same
mistake: sizing a column by eye instead of by `font.measure`. Fixed with shorter
labels (PR/GR, WST, 4-letter condition codes), a 7-glyph name cap, and pips side by
side on one row. **Measure the string.**

### Breach venting

`AETHON_FX.wounds` was a pair of fixed points on the skin that only knew the ship's
*overall* integrity, so a shattered bow and a shattered tail smoked from the same
two holes amidships. New `AETHON_FX.sectionVents`: six points, one per tracked
section, each with the outward normal its atmosphere follows.

A holed section now blows a hard narrow jet — a white-hot choked-flow root at the
lip, an **oriented** streak chain along the normal (`_spriteStreak`; `_spritePush`
is screen-axis-aligned and physically cannot point a sprite anywhere, which is why
the old wound damage had to be round puffs), and a small cold flare where the gas
has expanded. The flare was a fat blue ball on the first pass, big enough to
out-read the jet it terminated — a soap bubble on the end of every breach. All six
vents batch into **one** draw call; flushing per vent cost six.

The reward is that the exterior, the HUD's damage plan and the REPAIR key now all
describe the same thing.

### The CME, deleted and rebuilt (again)

The three-shell blob version went in 0.19. It was still clouds. `cmeTexture` is
gone; `filamentTexture` replaces it — a single thread with a wandering spine
(fbm-driven), taper, breaks, frayed ends and 2-texel block quantization, in core
and wisp weights.

The data model is a **flux rope**: 26 strands, each a chain of points on an
expanding arch with a helical twist about the rope axis. Two corrections got it
from "a narrow spray" to something that photographs like a coronagraph frame:

1. **`place()` is cylindrical** — a fixed Y offset — so an eruption at 45° of
   latitude travelled dead horizontally as it climbed and only an equatorial one
   looked right. Scaling latitude by `rr` makes the climb genuinely **radial**.
2. **The three-part structure.** Every strand had the same length, which is exactly
   what made it one undifferentiated jet. Now the bright twisted **core** sits low
   and stops (len 0.30–0.54) — that truncation is what leaves the dark evacuated
   **cavity** above it — while the flank threads are **legs** running the full
   height (0.86–1.0), pinched hard at the footpoint into a neck (fan `0.10 + 1.05f`,
   was `0.35 + 0.9f`). Half-width opened from 0.065 to 0.19–0.31 rad, which only
   read as separate wires back when there were fifteen threads instead of 26.
   The leading front is **two** rims offset in radius, clumpy along their length
   and heaviest at the nose — a swept-up shell seen edge-on, not a wire drawn over
   the star.

Result: a tight neck at the limb, a dense bright knot above it, a broad frayed
filament fan. Threads and structure. No clouds, no circles.

### Perf

Peak draw calls: **41 interior, 69 cruise, 36 chase with six breaches venting under
full burn**. Budget is <200 / <100.

### Still open

- `gatherForZone` still ranks lights by `intensity × radius` rather than camera
  distance.
- Boot ~8.6s at FINE; `microGrain` first to cut.
- Touch scroll guard still inspection-only — no touch device in the harness.
- DOM UI files still carry inline hex (Chrome.js worst).
- `utils/ObjectPool.js` is imported nowhere.

---

## Session 17d — the gun (0.23.0)

`context/07` Phase 6 has carried one unchecked line since the phase opened:
"personal combat (3 weapons)". The sidearm, carbine and arc cutter have been in
`ItemRegistry` the whole time as inert loot. New `combat/PersonalCombat.js` lets
you hold one.

### The decisions, and why

**Hitscan, not projectiles.** `SpaceCombat` simulates real bolts because ship
fights happen across kilometres, where flight time IS the tactical problem. A
corridor is nine metres wide. The ray is the honest model at this scale.

**Recoil is an impulse, not a spray.** Firing kicks the camera's pitch and the
kick decays; it is not random cone growth. The second shot of a burst goes high
in a way you can predict and compensate for. Measured over three shots: sidearm
0.156 rad (~9°), carbine 0.057, cutter 0.012 — the ranking the specs intend.

**A gunshot is the loudest thing in the game.** A sprint pins `NoiseSystem` at
0.95; a discharge sets it to 1.0 outright. That is the trade the whole survival
design turns on — the weapon works, and using it tells the ship where you are.
The cutter at 0.45 is the only quiet option, which is what makes carrying a
mining tool a real choice rather than a downgrade.

**The Hollow cannot be shot**, and the implementation is the point. It has no
world transform and no collider anywhere in this codebase, so there is nothing
for a ray to intersect. `TensionDirector.inZone(zoneId)` is a PREDICATE, not a
position: handing out a point to raycast against would be the first step toward
a hitbox, and a hitbox is one commit from a health bar. Firing in its
compartment resolves against the bulkhead behind and reports "THE ROUND GOES
THROUGH IT" on top.

**You can shoot your own ship.** A round that lands on a console, terminal or
panel damages the hull section it is in — the HUD's damage plan shows it and
REPAIR has to patch it with a plate you could have kept. Verified: the crew
terminal at 2.3 m took starboard from 100 to 94.6 and the hull mean to 99.1.

**Ammunition lives in the hold.** A magazine change consumes one `ammo_slug` or
`ammo_cell`, so ammunition competes for the same 120 slots as everything else.
The DECK OFFICER and VOID SALVAGER commissions now ship two magazines with their
weapon — both granted a gun and no ammunition, which was fine while the weapons
were inert and is not fine now.

### Four bugs worth naming

1. **The viewmodel never reached the screen.** `draw()` ran, every rect was
   emitted, `_plate` was called eight times a frame — and nothing appeared.
   `PixelRenderer` only auto-flushes when the bound texture changes or the quad
   buffer fills, and the frame's only explicit `pix.flush()` is at the end of
   `HUD.render`, which runs BEFORE the weapon draws. The whole viewmodel was
   queued and silently discarded every frame. `draw()` now flushes.

2. **Recoil was integrated per frame.** The first version applied the decaying
   `recoil` envelope to the camera every frame while it decayed, which made the
   total climb depend on frame rate. Split into two things: `recoil` (decaying,
   drives the viewmodel kick and the aim cone) and `kick` (a one-shot impulse
   `consumeKick()` hands to the camera exactly once). It also goes through a new
   `PlayerCamera.kickPitch(rad)` rather than `applyMouse`, because `applyMouse`
   scales by the player's look-sensitivity setting — routing a kick through it
   would make a heavy pistol jump twice as far for someone who likes a fast
   mouse.

3. **Drawing a weapon started a full reload.** `_autoLoad` called `reload()`, so
   a freshly drawn weapon spent 1.6–2.3 s unusable on top of the draw cooldown
   and read as broken. You holstered it loaded; it comes out loaded. The timed
   reload is for magazines you change under fire.

4. **The viewmodel was authored at final size and was far too small.** A 35×51
   pistol on a 480×270 grid is 7% of the frame — it read as a toy floating
   mid-screen. The three silhouettes are now authored on a small integer grid
   and blown up 2.3× at draw time through a `_brush()` helper, so retuning the
   scale is one constant instead of rewriting sixty rects. Anchored at x=0.62W,
   not 0.70W: at 0.70 the weapon sat on the HUD's SHIP plate and buried the FUEL
   and HULL gauges.

### Also

- Finger separations across the glove — without them the hand was a featureless
  dark slab and the weapon read as floating above a rectangle.
- The cutter's emitter fork sank into its own casing at the first contrast and
  the whole thing read as a plain brown box; the tines are now bright steel with
  a hard dark gap between them.
- `ShipSystems` and the interactable records have no type tag, so fragile props
  are matched by label regex — the same way main.js already decides what
  recharges the scanner cell, rather than threading a taxonomy through every
  prop class.

### Harness lesson

Three "bugs" this session were the probe, not the game. Freezing `flash` with
`Object.defineProperty` to hold the muzzle flash open for a screenshot threw on
every `update()` (ES modules are strict). Aiming at a console 10 m away through
a bunk and a bulkhead and concluding the damage path was broken — the hitscan
was correctly reporting the bunk. Reading `rounds` 700 ms after a draw that had
started a 1.6 s reload. **Check what the probe actually constructed before
believing what it reports about the code.**

### Still open

- Nothing on foot to shoot AT. The Hollow is unkillable by design and there are
  no boarders; the weapons currently point at geometry and at your own ship.
  Hostile boarding parties are the obvious next content beat.
- `gatherForZone` still ranks lights by `intensity × radius` rather than camera
  distance.
- Boot ~7-9 s at FINE; `microGrain` first to cut.
- `utils/ObjectPool.js` is imported nowhere.

---

## Session 17e — the command bar (0.24.0)

Owner's note: too many HUD elements and too many control buttons; fold WARP,
BAG/LOG, REPAIR, weapon-select and SCAN into the HUD itself and **not** as
touch-only controls; remove the throttle keys; put FIRE somewhere better.

### The same five actions were on screen twice

That was the actual crowding. WARP and SCAN existed as DOM chips floating over
the canvas **and** as keys in the touch tap row. BAG/LOG was a third chip. Three
visual languages — DOM plastic, touch plastic, HUD chrome — for one set of
commands, and a suppression flag (`dupHidden`) whose whole job was to hide one
copy when the other appeared.

New `HUD._commandBar`: one row of keys along the bottom of the glass, drawn in
the HUD's own machined-plate chrome on the 480×270 grid, present in both input
modes. Flight carries WARP · SCAN · LOCK · WPN · RPR · HOLD · LOG; on foot it is
SCAN · LAMP · ARM · HOLD · LOG. The three DOM chips are gone; MENU is the only
one left on the canvas.

**Every key prints its keybind.** That is what stops this being a touch overlay
wearing HUD paint: on a keyboard the bar is a legend you can read at a glance,
and on a phone it is the button. Lit keys (scanner raised, hold open, weapon
drawn, lock held) carry a status pip and a brighter face; a pressed key sinks —
the bevel inverts and the label drops a pixel.

Dispatch routes through `input.virtualPress` wherever the action already has a
binding, so a tap on the bar and a press of the key take **exactly** the same
path through the update loop. Two code paths for one action is how they drift.

### The throttle keys became the throttle

THR+ and THR− were two of the largest keys on screen for a single scalar — and
the HUD has drawn a throttle quadrant at the left of the glass since 0.9.
Dragging that gauge now latches a throttle setting (centre is zero, a 12% dead
band so idle is findable by feel), republished into the virtual move axis every
tick so the drive holds it after you let go. The instrument became the control.

### FIRE has the corner to itself

It used to share `primaryR` with BRAKE — a 52px key stacked directly on the one
your thumb rests on, the two most-pressed controls in a fight with 9px between
them. BRAKE moved to its own cluster.

Touch keys: **13 → 7** in flight, 6 → 4 on foot. Verified zero overlaps, none
under 44×44, none off-screen, at 844×390 / 1024×600 / 740×360 / 1280×720 in both
modes.

### Three things the layout maths caught

1. **The bar cannot be one size.** 15 rows of a 270-row buffer is 22 CSS px on an
   844×390 phone — half the checklist floor — and there is no height that is both
   compact on a monitor and 44px on a phone. The bar picks: 15 with a mouse, 26
   under a thumb, plus a 5px hit pad on the rect only, so the key stays visually
   compact while the target clears the floor.
2. **Every bottom-anchored block had to move with it**, and by a different amount
   in each mode. All of them now derive from one `BAR`/`BOT` pair at the top of
   `render()` instead of hard-coded offsets — the first pass shifted them by a
   constant 19 and the taller touch bar drew straight through the panels.
3. **The notification stack was at y=162**, which the raised VITALS plate then
   occupied. Moved to y=62, under the compass and the critical-alert strip: the
   one band nothing claims in either mode, since SENSORS is hard left and the NAV
   and TARGET plates are hard right.

### Also

`AMBER9` has no tab glyph, so SCAN's legend rendered as `?`. `KeyN` now aliases
`Tab` for the scanner purely so the bar has a key it can print. Tab still works.

### Still open

- On a desktop the bar is a legend rather than a button while the pointer is
  locked — there is no cursor to hit-test against. Unlocking makes the keys
  clickable. This is why the keybinds are printed, but it is worth knowing.
- The celestial approach popup still lands on the left third of the glass and
  covers the top of the VITALS plate while a body is in range.

---

## Session 17f — four hulls (0.25.0)

Owner's note: more player ship types to choose at the start, with their own
models and interiors, and a bigger commission screen.

### `data/ShipClasses.js`

One record per hull, holding everything that describes a vessel: flight
multipliers, endurance figures, exterior silhouette, and the compartments it
carries. Four classes:

| | ACCEL | AGILITY | HULL | SHIELD | HOLD | COMPARTMENTS |
|---|---|---|---|---|---|---|
| SURVEY CUTTER (HSV Aethon) | 1.00× | 1.00× | 100 | 100 | 120 | 13 |
| FAST COURIER (KSV Petrel) | 2.34× | 1.60× | 62 | 70 | 64 | 8 |
| BULK HAULER (KSV Drayman) | 0.38× | 0.55× | 165 | 120 | 210 | 10 |
| ARMED PINNACE (KSV Harrier) | 1.35× | 1.25× | 108 | 155 | 88 | 11 |

Acceleration is `thrust / mass`, so it falls out of Newton rather than a
difficulty knob — the Drayman is slow because it is heavy and under-engined, not
because a number says "slow".

Endurance stays on the 0..100 scale the HUD already reads and the CLASS changes
the rates instead: a 165-hull hauler divides incoming damage by 1.65, a 78-fuel
pinnace burns its tank 1.28× faster. Rescaling the gauges themselves would have
meant touching every bar in the HUD to no benefit.

### The interiors, and the honest limit on them

Every side compartment on the deck plan is a **leaf**: it hangs off a junction by
one door and nothing routes through it. So a class can drop compartments without
touching the spine — the corridor run from cockpit to engine room is identical on
every hull, and what changes is which doors off it open onto anything. Dropping a
leaf is safe. Re-cutting the spine means recomputing every `at`/`center` in
CONNECTIONS, and sessions 16f and 16x are a standing record of how that goes, so
this deliberately does not try. **The hulls differ in which rooms they have and
how many, not in deck topology.**

`crew_bunks` is a leaf and is deliberately NOT droppable: SPAWN is inside it, and
a hull that cut it would start the player embedded in a bulkhead.

`ShipMap.reconfigure` rebuilds the deck for the chosen class. The commission runs
long after the interior is built — the boot order is fixed by the save restore,
which needs collision before anything draws — so rather than restructure boot,
the deck is simply built twice on a fresh commission, before `engine.start()`.
It releases zone meshes, clears the LightSystem's zone map **and its lazy flat
cache**, and replaces the collision map, interactables and doors.

That last part had a consequence: `PersonalCombat` was caching the CollisionMap
object, so after a reconfigure every shot would have hit the previous ship's
geometry. It now reads through the map.

### The exteriors, and the honest limit on those

`buildAethon` is a hand-authored mesh with every greeble, frame band, canopy pane
and RCS blister at an absolute model coordinate. Stretching the section table
would slide four hundred authored details off the surfaces they belong to — the
frame bands would stop landing on section joints and the RCS blisters would stop
matching where the puffs actually fire from.

So the profile varies the three things that can change a silhouette from a
kilometre out without touching any of that: **arms** (4 / 2 / 0 quarter-turns,
picked as opposed pairs so two arms cannot grow one wing and a keel), **span**
(outboard x only — the root pylon keeps its width so the wing still meets the
fuselage where the fuselage is), and **nozzles** (lit centre-out, because a
single off-axis bell would thrust the ship in a circle). `AETHON_FX.nozzles` is
rewritten to match, or a one-bell courier would burn two plumes out of solid
plating.

Verified in the chase cam: four wings, two, none, four short. They do not read as
the same ship.

### The commission screen

Gained a **CALLSIGN** field (yours; PILOT NAME stays the company's record and the
gate/HUD use the callsign when you set one), an **ASSIGNED HULL** row of four
plates, and a live dossier under it — the class blurb plus six comparison bars
normalised against the widest value any class reaches, so the bars compare the
four hulls against each other rather than against an invented ceiling.

The hull, the callsign and the class id all persist in the save, and a restored
save re-applies its class through the same function the commission uses, so the
two paths cannot drift. Saves from before this session have no `shipClass` and
load as Aethons.

### Still open

- The hulls share one authored detail set. Genuinely distinct models would mean
  three more `buildX` functions of the same weight as `buildAethon`, which is a
  session each.
- Interiors differ by room set, not by deck plan. A real generator — modules laid
  out along a computed spine — is the way to get shorter or wider ships, and it
  is a large, risky piece of work that wants its own session.
- The class `scale` field is in the table and not yet used: `SHIP_CHASE_SCALE` is
  a module constant in SpaceRenderer read from a dozen places.

### 0.25.1 — the cut compartments needed a scar, not a gap

Shipping the hull classes and then looking at one was the point. On a Petrel,
standing in junction j3 — where the survey cutter has the laboratory to port and
the computer core to starboard — you face two blank walls. The geometry was
sound (no holes, `_openingsFor` correctly declines to cut an opening for a
connection that no longer exists), but a junction with a plain wall exactly where
the symmetry says a door belongs reads as MISSING CONTENT, not as a smaller ship.

New `props/SealedHatch.js`: the frame survives, because you cannot economically
cut a pressure frame out of a bulkhead, and in place of the door is a plate
somebody welded on during a refit — weld beads down both seams as a run of short
overlapping blobs rather than a continuous strip (a weld is made one pass at a
time and it shows), a 3×5 rivet grid, hazard chevrons at head and sill, a blank
legend plate, and a collider, because a plated doorway is a wall.

`ShipMap._sealCutDoorways` runs per zone inside the dressing loop — NOT after
it. The first version ran after the door pass, by which point every zone mesh had
already been finished and uploaded, so the plates were built into a dead builder
and never reached the screen. It also runs before `dressGreebles`, so the greeble
pass sees the plated doorway as occupied wall instead of stacking a junction box
on it.

Only doors are sealed, never portals: portals are the corridor spine and
`LEAF_ZONES` cannot contain either end of one, so a cut portal is impossible by
construction and finding one would be a bug worth crashing on.

Verified across all four hulls: 24/19/21/22 zones, 15/10/12/13 doors, 0/5/3/2
sealed compartments, zero console errors.

---

## Session 17g — three ships, not one ship with fewer wings (0.26.0)

0.25.0 gave the hull classes different silhouettes by varying the Aethon's arm
count, wing span and bell count. The owner's answer was the right one: they are
supposed to be different SHIPS. New `ship/HullModels.js` authors each from
scratch, and the three read differently because they are built from different
*ideas*, not different parameters:

**PETREL — a needle.** One continuous lofted taper from a bubble canopy at the
tip to a single bell, swept canards well forward, one tall raked dorsal fin. No
cruciform, no radiator panels, no engineering block. The design argument is that
every gram is airframe, so the things that make the Aethon read as a working
vessel are exactly what it does not carry. The canopy is set INTO the spine at
the nose rather than raised on a tower — on a hull this slim the pilot sits in
the point.

**DRAYMAN — a spine.** There is no fuselage. Four longerons in a square, ring
frames every 4.3 units with alternating diagonal braces, and six cargo bays
clamped along it — one of which is **empty**, clamps only, which does more for
"working hauler" than any amount of surface detail. Boxy tug head with a slab
windscreen at the front, four bells in a square cluster at the back, and the
reactor and radiators mounted externally because there is no hull to hide them
in.

**HARRIER — a wedge.** The same lofting machinery as the Aethon and the Petrel,
fed wide shallow sections: eleven units across and two and a half tall at its
widest. Twin tail booms carrying the tail between them, bells slung in the gap,
a chin sensor blister, and four missile pylons under the wing that the survey
office did not order. Bolt-on armour slabs laid ON the wing rather than modelled
into it, which is what an auction hull that was never repainted looks like.

### FX anchors travel with the mesh

Each builder returns its anchor table alongside its geometry, and
`buildPlayerHull(classId)` swaps both **in the same call**. An anchor table that
can be out of step with the geometry it belongs to is how the drive plumes once
ended up burning out of the middle of the hull, so the two are never separable.

`AETHON_FX` stays a module singleton — there is one player ship at a time and
`SpaceRenderer` imports it directly — and is rewritten in place rather than
threaded through the twenty-odd places the renderer reads it. `AETHON_FX_BASE`
is a pristine copy so switching back to the cutter restores it.

RCS ports and breach vents for the three new hulls are DERIVED from each hull's
own extents (`rcsFor`, `ventsFor`) rather than hand-placed: the Aethon's table is
hand-placed because it has blisters at specific coordinates, and these do not.
Same group names, same meanings, so the renderer needs no per-hull branch.

`HullModels.js` is loaded with a dynamic import, so a player who flies the
default cutter never pays for the other three meshes.

### Verified

All four commission cleanly — 24/19/21/22 zones, 15/10/12/13 doors, zero console
errors — and the four silhouettes are unmistakable from each other in the chase
camera: cruciform tower, slim arrow, freight stack, flat wedge.

### Honest note

The Drayman's truss reads as a solid column at normal chase distance; the gaps
between its longerons only resolve up close or against a bright background. If
that matters it wants either fewer, fatter members or a wider keel.

---

## Session 17h — the guns solve their own problem (0.27.0)

### Gunnery assist

The rule, stated once and enforced in one place: **a shot is corrected onto a
target only if that target is in front of the hull and within 9 degrees of the
boresight.** Outside the cone the guns fire exactly where they point, as they
always have.

That gate is what keeps this an assist rather than an aimbot. You still have to
fly the nose onto the target; what the assist removes is the part that is pure
arithmetic — how far to lead a crossing target at this range and this muzzle
velocity — which a gunnery computer in this fiction would obviously do and a
pilot cannot do in their head.

9 degrees is deliberately much tighter than the 31-degree lock cone. A lock is a
declaration of intent that survives manoeuvring; a firing solution has to be
something you can lose by drifting off, or it is not aiming.

The aim point is the **intercept**, not the target's current position: a bolt
takes real time to arrive and a crossing target is somewhere else when it does.
Two iterations of "how long to reach where I currently think it will be" — the
fixed point converges fast because muzzle velocity is an order of magnitude
above closing speed, and two passes are indistinguishable from twenty here.
Relative velocity, not ground speed, because a bolt inherits the ship's motion.

A locked target wins if it qualifies at all; otherwise the candidate closest to
the boresight does. Homing and intercept weapons are excluded — they steer
themselves, and pre-leading a missile only makes it turn the wrong way first.

The correction lands BEFORE the per-shot spread loop, not inside it: every
pellet of a multi-shot weapon has to come off the same solution or the pattern
walks off the target.

**HUD**: four brackets that sit wide open with no solution and snap closed on
the crosshair when one exists, plus the intercept point drawn as a floating pip.
An assist whose state you cannot see is indistinguishable from bad aim.

Measured: solutions at 0/4/8 degrees off boresight, refused from 8.9 outward
(the cone is measured from the muzzle, 18 units ahead of the hull, so the
probe's ship-relative angles read ~0.7 degrees low); range gate holds at 4.2 km;
lead offset 0 units on a stationary target, 214 at 120 u/s crossing, 784 at 400.

### Hull liveries

Eight of them, from Kestrel factory grey through oxide, void black, glacier
white, hazard ochre, field olive, oxblood and deep slate.

New `u_tint` in `space.frag`, multiplied into the albedo **before** lighting, so
a repaint reads as paint ON the metal: every panel edge, weld line, streak of
wear and value-stepped tile survives and comes through in the new colour. A tint
applied after lighting would have washed all of that flat and read as a coloured
lamp shining on a grey ship.

The uniform is defaulted to white at the top of every space pass. An unset vec3
uniform reads as (0,0,0), so without that default the entire pass — planets,
stations, hostiles — would have rendered black the moment the uniform existed.
It is set for the player hull only and restored immediately after, since every
other mesh shares the program.

Swatches on the commission screen are painted with the ACTUAL tint over a
mid-grey, which is roughly what the plating averages to, so a multiply preview
is honest rather than decorative.

Livery persists in the save alongside the hull and the callsign, and the restore
path re-applies it through the same function the commission uses.

### Still open

- "More content" landed as the eight liveries and nothing else this pass. The
  three older roadmap items (DOM button styling, the landing window's frame,
  more star systems and body variety) are all still untouched.
- The Drayman's truss still reads as a solid column at chase distance.

---

## Session 17i — a different galaxy every commission (0.28.0)

`CelestialGen.generateSystem` has always been rule-driven — give it a seed, a
star type and a planet count and it derives real-km radii, AU-spaced orbits,
moons, belts and comets from astronomy. What did not exist was anything ABOVE
it: the ten systems were a hand-written list, so every save visited the same ten
places in the same order.

New `data/GalaxyGen.js` is that layer. One seed per save lays out a whole chart:
28 systems in a ~46 ly disc, procedural names from a worn/industrial/nautical
register, star types weighted by real stellar frequency (M dwarfs dominate),
danger rising with distance from the centre, and a one-line survey report
assembled from a trait table.

**The ten authored systems survive, as anchors.** Sol Prime, the four route
systems and the five spurs carry the lore — the Hollow's haunts, the named
colony, the derelicts quests point at, the stations trading depends on.
Procedural generation that discarded those would be trading a written world for
a random one. So they keep their ids and content, are placed first (Sol Prime
pinned at the centre, because a start on the rim makes half the chart a one-way
trip), and eighteen generated systems fill in around them. Every game gets the
same story in a different galaxy.

Positions are reject-sampled with a 6 ly minimum separation, on a disc with
sqrt-distributed radius so the layout is uniform by area rather than a
centre-heavy blob, and a thin y spread — a galactic plane, not a ball.

### Warp is local now

`neighbours(id)` returns only what is within **13.5 ly**, which is what turns
the warp panel from a menu of every destination into a chart you have to cross.
A distant system is a sequence of hops through the ones between, and fuel is
spent on each. Measured from Sol Prime on two different seeds: 3 lanes and 5
lanes in range respectively.

A system with NO neighbours would be somewhere you could arrive and never leave,
which reject sampling can produce at the rim, so the nearest system is always
included regardless of range — the drive can always get you back out of wherever
it got you into, even if it has to strain.

The gate is additive: with no galaxy passed, every system stays selectable,
which is exactly the pre-0.28 behaviour. The panel can never end up empty.

### The chart

A plan view of the galactic plane at the top of the warp panel — the jump
envelope as a circle, lanes drawn to everything in range, systems coloured by
danger so the rim reads as hostile before you spend fuel on it, and the current
system ringed. Out-of-range systems are still drawn, dimmed: with gating the
list below only ever shows a handful, so without the chart you would have no
idea what lies two hops away or which direction you are working across.

The thin y spread is ignored for drawing — a chart that showed it would need a
projection the player has to learn — while the range test underneath still uses
the real 3D distance.

### Verified

Two fresh galaxies from two runs: 28 systems each (10 authored + 18 generated),
different names, different neighbours, zero console errors.

### NOT in this pass, and worth saying plainly

The batch asked for five things. This is two of them (procedural systems, and
the map plus local warp, which the first is a prerequisite for). **New items,
new enemy types and better enemy AI did not land.** The AI complaint —
"they just circle around and shoot" — is a real one about existing content and
is the obvious next session on its own: state machine with approach/attack/
extend/regroup, mutual awareness so a squadron does not all commit at once, and
weapon variety per hull.

---

## Session 17j — the enemies stop circling (0.29.0)

"They just circle around and shoots." Correct, and the reason is that the AI was
ONE state: bore in, jink, hold 1400 units, fire. A single behaviour has no
phases, so a hostile was never visibly setting up, committing or breaking off —
nothing it did could be read a second before it happened, and a fight with
nothing to read is a fight with nothing to do but hold the trigger.

### Five states, each of which looks different from outside

**APPROACH** — close from long range on an OFFSET vector, aiming past your
shoulder so the run starts from a flank rather than down the throat. Does not
fire. This is the phase you get to react to, and it did not exist before.

**RUN** — the firing pass. Nose on, shooting, closing hard through minimum
range, with a shallow weave so it is not a rail. Short and committed.

**EXTEND** — after the pass: run OUT, tail toward you, full power, no steering
back. This is the single biggest change. A ship that disengages and returns is
an attack run; a ship that never leaves is a carousel.

**REGROUP** — hold at 2600 units, turning back, waiting for a firing slot.

**EVADE** — hurt and shieldless: hard jinking away from the guns.

Every state is a DESIRED VELOCITY the hull accelerates toward, not a force added
to whatever it was already doing. That is what makes a break-off actually break
off instead of curving lazily back into the same orbit.

### Squadron discipline

`_slots` caps how many hostiles may be in RUN at once at **two**. Everyone else
waits in REGROUP or keeps closing without pressing. That is what stops five
hostiles converging into one undifferentiated cloud, and it is why a fight now
has a rhythm — pressure, gap, pressure — rather than constant uniform noise.

Slots are held by object identity, not by a counter, so a ship that dies
mid-run cannot leak its slot and starve the squadron.

### Firing is gated on state

Only a ship in RUN (or a corvette in STANDOFF) shoots. Shooting from every state
is most of what made the old AI read as "circle and shoot".

### A corvette does not dogfight

It holds STANDOFF at 2200 units and fires salvos. Giving a capital hull the same
attack cycle as a fighter is what made it read as a fighter with more hit points.

### Measured

Five aggroed fighters, 26 seconds: all four fighter states in use (approach 586
frame-samples, run 378, extend 412, regroup 279), **maximum two simultaneous
runs**, and range cycling between 900 and 3151 units — the attack-run rhythm.
The old AI parked at ~1400 and stayed there. Zero console errors.

### Still not done from the batch

New items and new enemy TYPES. The AI rework was the part of that batch that was
about existing content being wrong rather than missing, so it went first.

---

## Session 17k — 0.30.0: enemy types, items, hull-cam zoom, texture plasticity

Four owner asks, all delivered: finish the new enemy types, add more items, put
small zoom buttons on the third-person hull cam, and give every texture more
plasticity, depth and decorative work.

### Three new hostile types, and one table that describes all six

`SpaceCombat` had a five-state attack-run AI (0.29.0) but only one kind of ship
flying it, plus a corvette special-cased with `if (capital)` branches. Adding a
fourth type would have meant a fourth branch. It is now a `PROFILES` table —
standoff range, run duration, whether it respects the squadron slot queue, hull
agility, the damage fraction at which it breaks off, burst size, burst spacing
and reload — and both `_fly` and the firing path read it. Adding an enemy is a
row here plus a row in `HOSTILES`.

**KETH LANCER** (Amber Well) — interceptor. Standoff 3200, agility 1.9, ignores
the slot queue, two-round bursts on a 1.5–2.3s reload. Punishes you for
treating the squadron rhythm as a guarantee.

**DRIFT PICKET** (Redfall) — gun platform. Never closes: it has no run window at
all, holds 3400 and shoots three-round bursts at extended range. Cannot be
ignored and cannot be dogfought; you have to go and get it.

**DRIFT LANCE** (Odessa Chain) — heavy drone that commits. Standoff 1600, five-
to-seven-second passes, never evades. The only fighter-sized thing that will
follow you through a hard turn.

`reload` had to become a profile field rather than a constant. A lancer's
firing WINDOW is its 1.4s pass, so on the shared 2.6–4.0s timer it flew past
without shooting on most passes — measured at four rounds in twenty-two seconds.

Measured over 22s with three of each, player stationary: lancer cycles
approach/run/extend/regroup at 1597–4253 range; picket sits in `standoff` 100%
of samples between 2400 and 3300; lance closes to 43 units and spends more
frames in `run` than any other type. Zero console errors.

**Two real bugs found while wiring them up.** `FactionSystem` matched kill and
provocation events with `type === 'keth'`, so every variant hull scored zero —
you could break a corvette in half for no diplomatic reaction at all. It now
resolves the FAMILY via an exported `factionOf()`, weighted by hull. And
`SpaceCombat.disposition` asked for standing by hull type, so `keth_corvette`
returned 0, which reads as neutral, which made warships hold fire. Same fix.

Variants share their parent's mesh and texture (a lancer *is* a small fast Keth
fighter), so they are separated by scale plus a per-type albedo tint. Setting
that tint also fixed a leak: `u_tint` is a per-draw uniform the player hull
writes, and `renderCombat` never reset it — every hostile in the system was
being painted in whatever livery the player chose at commission.

### 279 items

Was ~200. Added: variant-hull faction salvage (thrust vanes, gunsight optics,
barbette rings, emitter nodes, chorus relays — the parts that explain why that
hull behaved the way it did); ten EVA/suit consumables; twelve named ship
spares (distinct from generic `comp_*` feedstock — each names a fitting on the
deck plan, so a repair reads as a repair to *something*); nav and records; eight
restricted goods; xeno samples; more tools and personal effects.

**Specialty ammunition is real, not flavour.** `PersonalCombat` now has a
`LOADS` table: AP does 1.42× damage and 2.1× damage to your own ship systems
when a round goes through a console; frangible does 0.86× and **0.22×**, which
is the entire argument for carrying it inside a pressure hull; overcharged arc
cells do 1.65× on a 45% magazine. Reload takes the best load in the hold, the
counter names it (`AP 20/12`), and the chambered load is dropped when you switch
weapons so a cutter cannot fire penetrator slugs.

The airlock had nothing searchable in it — the one compartment whose entire
purpose is going outside held none of the gear for going outside. It now has a
hung hardsuit and an EVA stores rack on a dedicated loot table. Named
`EVA SUIT STORAGE` deliberately: `main.js` decides searchability by matching
`CONTAINER_RE`, which knows STORAGE but not STORES, and the first draft quietly
yielded nothing.

### Hull-cam zoom

Small `+`/`−` keys in the right instrument column, drawn only while the external
camera is out, with the magnification beside them and each key greying at its
stop. Held rather than tapped — a zoom you press eleven times is not a zoom —
and rate-limited by dt so the 0.45..3.2 travel takes about four seconds at any
frame rate. Also on `=`/`-` (and the numpad pair), and still on the wheel.

**This exposed a general bug.** `barPointer` was bound to the canvas, and the
touch layer lays two full-width look/steer panes over the top 215 rows — a
listener on the canvas never sees a press that lands on one, because the canvas
is not in that event's path. The command bar worked only because it sits BELOW
the panes. It is now bound on window with capture and gated to the canvas and
`#touch-ui`, so HUD buttons get first refusal wherever they are drawn and DOM
panels still win over anything they cover.

### Texture plasticity

Two new sculpting layers on `Painter`, run last in `_finish` (and in a new
`_sculpt` for props) so they read the finished height field:

**`cavity(strength, radius)`** — Laplacian of the height field: darken concave
texels, brighten convex ones. View- and light-independent by construction, so it
cannot fight the dynamic light the way a baked directional term would.

**`contactShadow(strength, steps)`** — march a short ray toward a fixed up-left
key and darken where something along it stands higher. This is what gives a
rivet a shadow on the plate beside it. The key direction is constant across
every texture in the ship, so a wall and the crate against it agree.

Both are baked into the albedo, which matters because the normal map only
responds to the one nearest dynamic light: a face turned away from every fixture
used to go flat and lose all its structure. Most of this ship is turned away
from every fixture.

Plus decorative hardware that is deliberately ROUND, because the interior is
otherwise built almost entirely from straight lines: `roundBoss` (a real
hemisphere in the height field), `screwHead` (slot/cross/hex, countersunk),
`ribbedBand` (cosine cross-section corrugation), `knurl` (crossing diagonal
ridge families), `castPitting` (clustered blind holes with a windward lip) and
`patina` (oxidation blooms with a raised crust, unlike the flat colour wash).

Applied across the board and tuned per material: vacuum hull plating gets heavy
pitting and no oxidation, ceramic gets almost no pitting but a deeper cavity
term, a deck gets its crust walked off, a mattress and a leather seat get
swelling instead of pits.

The flattest four surfaces in the ship measured **10, 11, 38 and 117 colours**
before this — `floor_grate`, `ceiling_pipes`, `door_frame`, `door_panel`, which
between them are most of what the player looks at. They are now 2436, 828, 2466
and 1891, with real sections: bearing bars that crown, pipes that shade as
tubes, a pressure-door frame with a flange, a seal channel and a land, and a
door with locking dogs and a knurled handwheel.

Interior still renders at 41 draw calls (budget 200) with zero console errors.

### Next

Roadmap #84 (DOM button styling), #85 (landing/celestial-approach window onto
the framed style), #87 (more star systems and body variety).

---

## Session 17l/17m — 0.31.0 / 0.32.0: the system is inhabited, and you can go outside

Two commits against one owner batch: fill space with things worth flying to, and
let the player leave the ship.

### 0.31.0 — structures, traffic, minefields, boarding

**Every non-player object was one mesh.** `SpaceRenderer.freighter`, drawn at
different scales — so a trade post, a shipyard, a derelict and a passing hauler
were the same object four times, and twenty-two of the twenty-eight charted
systems held nothing but rocks.

`world/Structures.js` is fourteen meshes, each authored from its own idea the
way `HullModels.js` treats the player hulls: the trade post is a WHEEL, the
shipyard a CAGE you can see through, the refinery a TANK FARM that burns, the
wreck a BREAK with the frames bare at the tear, the monolith the subtraction of
everything that says "fabricated". 22k vertices for the library.

**The glow mesh is the load-bearing part.** Every builder returns a second,
fully emissive mesh — window bands, approach strobes, the refinery flare, a
cutter arc. At the range where you first pick something out of the dark the
plating is two pixels and the lights are the whole silhouette. A wreck and a
monolith return `glow: null` on purpose: that absence is how you tell a dead
thing from a live one before anything else resolves.

Structures also render in the CHASE view, which they did not at all — switching
to the hull cam beside a trade post made the station vanish.

**Population is danger-driven.** Calm systems get the counter and the building
slip; bad ones get the wreck fields, the minefields and the thing nobody built.
Across the ten authored systems: 52 mines, 39 wrecks, 9 trade posts, 6 relays,
4 monoliths, 3 shipyards, 2 smelters. The first roll produced ZERO shipyards —
a feature that exists nowhere is not rare, it is broken — so the gate moved.

**Traffic.** Ore tenders between the belt and the smelter, bulk haulers between
stations, couriers crossing. Two-point routes that bounce, so a lane is legible
rather than a random walk. They hail, and the tenders and haulers run a counter
off the manifest. 41 civilian hulls where there were none.

**Minefields.** `armedMine` is deliberately separate from `approach`: approach
is an invitation and this is a consequence, and one function for both would put
a DOCK prompt on unexploded ordnance. Damage goes through `applyHit` so the
shield, the armour term and the section plan all see it.

**Boarding.** A wreck is worked from inside your own suit, compartment by
compartment. Each costs oxygen twice — once to be in it, once to walk back out
past it — so the tank falls while the return margin climbs and the two figures
converge on screen while you decide. Leaving early keeps the hull live; reaching
the end strips it permanently, and that rides in the save. Measured: nine
compartments took 96% oxygen down to 34% against a 30% margin, for nine items.

**Two bugs found on the way.** `FactionSystem` matched kills with
`type === 'keth'`, so variant hulls scored nothing at all. And `u_tint` is a
per-draw uniform the player hull writes that `renderCombat` never reset — every
hostile in the system wore the player's commission livery.

### 0.32.0 — the space walk

The airlock's outer door has refused to open for four sessions on the grounds
that "EVA protocol requires certification", which was a placeholder standing in
for a mechanic that did not exist.

**Still first person.** Pillar 1 is untouched: the eye is the helmet. The hull
cam remains a piloting mode.

**Three budgets, and the one that strands people is not oxygen.** Oxygen is the
clock. The COLD GAS pack is the trap: burn it getting somewhere and stopping
costs exactly what starting cost, and the brake is a separate control that
spends the same gas precisely so a player cannot fail to notice. The TETHER is
44 m of braid — inside it you are recoverable and the reel will winch you home;
outside it you are on the jet and your own judgement, and the game says so
rather than stopping you.

**Motion is in the SHIP'S frame.** The Aethon is doing hundreds of units a
second and the suit has no drive worth the name, so what you fly is the
difference. That is also what makes the tether a fixed length instead of a rope
being paid out at orbital speed.

**Rendering reuses the chase path**, which is why this was affordable at all:
that renderer already draws the sky, the worlds, the player's own hull, every
structure and all of combat in exactly the frame an EVA needs. The only
difference is where the eye is, and that is two matrices.

**The bug worth recording.** Entering EVA transitioned the state, drew the suit
HUD and even drained oxygen — and the jet did nothing. Two causes, both quiet:
`running` (the flag the whole physics block sits behind) listed PLAYING and
FLIGHT only; and `startEva` requested pointer lock, whose grant handler
transitions to `resumeState`, which was still PLAYING. The state snapped back
one frame after stepping outside. Set the resume state BEFORE asking for the
lock.

Verified: 44 m at the tether stop on 13% of the pack, cycle back in at the
hatch, 41 draw calls, zero console errors.

### Next

Celestial surfaces and atmosphere entry; the shipyard hull broker; more
exterior and interior variety across the player classes.

---

## Session 17n — 0.33.0: worlds you can land on

The approach panel has had a LAND button since Phase 4. It printed
`SURFACE OPS PENDING` every single time, for six sessions. This is the surface
ops.

### Generated surfaces — `data/SurfaceGen.js`

Nothing here is invented independently of what the chart already says. The
terrain follows from the composition, the sky from the atmosphere, the hazards
from the temperature and the pressure. Thirteen archetypes keyed off the `kind`
`CelestialGen` already assigns: cratered regolith, dune sea, archipelago shelf,
canopy floor, glacial plain, frozen steppe, active basalt, sulphur plain,
pressure floor, graphite crust, exposed core, airless regolith, dirty ice. Gas
giants and stars correctly return **null** — there is nothing to put a ship on,
and the panel now says so instead of logging a site.

**Two products, deliberately separate.** `surfaceProfile(body)` is the cheap
deterministic descriptor, needed the moment a body is scanned. `buildTerrain`
is the mesh — a 4.6k-triangle heightfield with fractal relief, stamped craters
(a raised rim and a sunk floor, which no amount of fractal noise produces) and
a levelled pad blended out over its own radius so a ship can be put down and
walked off. Built only if you actually commit.

**A flat patch, on purpose.** Standing on a world the horizon is a couple of
kilometres out and the curvature over that is less than the terrain relief.
What sells a planet is the horizon line and the sky above it, and those are the
renderer's job — a correctly curved patch costs a hundred times the triangles
to look identical.

### Entry is flown, not watched — `gameplay/Landing.js`

Every other transition in this game is a lerp you watch. An atmosphere is the
one place where the ship's own numbers decide the outcome. Skin heating goes as
density × v², so speed costs plating; a retro burn sheds speed and costs fuel;
aerobraking helps for free and helps more the thicker the air. Burn fuel or burn
hull, decided in about twenty seconds. Fuel is checked for the ROUND TRIP at the
top of the atmosphere, because landing with enough to get down and not enough to
get up is not a challenge, it is a save file that has quietly ended.

Touchdown over 85 u/s costs the ventral section.

**The bug worth recording.** The first version read the descent speed off
`ship.speed`, which looked right and was not: flight assist nulls the hull's
velocity within a second of the commit, so every entry arrived at zero, the heat
term vanished and the descent was free whatever you did. The entry now owns its
own descent velocity, seeded from the world's gravity.

**And a second one.** `body.gravity` and `body.temp` are DISPLAY STRINGS —
`"0.85 g"`, `"+16 °C"` — authored for the NAV panel. Reading them as numbers
gave a NaN landing-fuel cost that propagated into the entry-heat term and made
every descent free. Parse, don't assume.

### On the ground

A new `SURFACE` state: first person, walking, with the heightfield itself as the
floor — there is no CollisionMap out here and there does not need to be, because
a heightfield IS the collision, sampled directly. Walking speed scales inversely
with gravity.

`LandingUI` is the surface board: the world's environment figures, the survey
sites with bearing and range and what each costs in suit oxygen, and the one
number that ends the visit — FUEL TO LEAVE against the tank. Breathable air
quarters the oxygen cost of every site, which makes it the single most valuable
thing a world can have. A planet does not run out, so a worked site yields less
each time rather than becoming empty, and the limiting resource is always the
suit.

Measured: entry heat climbed 0.01 → 0.98 as density rose and gravity built the
speed; three sites on a lava world cost 31% oxygen and returned four new item
stacks; lift-off returned to FLIGHT with the terrain released. 81 draw calls on
the surface, 41 in the ship. Zero console errors.

### Next

The shipyard hull broker (the yards dock but still open the general counter),
and more exterior/interior variety across the four player classes.

---

## Session 17o — 0.34.0: the sky slows down, and the wall becomes a door

Three fixes reported from play plus the broker the last session deferred.

### Orbits ran at six times the wrong speed — `data/Orbits.js`, `world/StarSystem.js`

Watching a moon lap its planet while you line up an approach is the fastest way
to make a solar system read as a desk toy. The honest place to slow it is the
gravitational parameter, not the per-body angular rates: Kepler's third law is
`T = 2π√(a³/μ)`, so period goes as `1/√μ`, and dividing μ by 36 multiplies every
period by exactly 6 — inner worlds and outer worlds keep their correct ratio,
which hand-tuning each rate would have destroyed. `GRAV_MU` and `MOON_MU` both
took the divisor.

Spin, station-keeping phase and derelict yaw have no third law behind them, so
they take a flat `SPIN_SCALE = 1/6` in StarSystem rather than a second guess.

Measured in Sol Prime: 5.2 / 10.6 / 22.9 / 25.7 minutes per orbit, from roughly
one minute each.

### Flying into a world bounced off it — `main.js`

The report was "the transition to the planet surface is not working, the ship
bounces off the celestial bodies", and the cause was that both behaviours were
present and the wrong one won. `system.collide` is a hull hitbox that pushes the
ship back out and kills the inward velocity — correct for the star, correct for
a gas giant you cannot land on, and exactly wrong for the rocky world you were
aiming at. Nothing else consumed the contact, so a deliberate descent read as a
wall.

Contact with a landable body now BEGINS the entry:

```js
if (!landing.active) {
  const hit = system.collide(shipState.pos, shipState.vel);
  if (hit && !hit.isStar && landing.survey(hit)) landing.begin(hit);
}
```

and collision is skipped entirely while an entry or an ascent is running,
because a descent that is being pushed back out is the same bug wearing a
different hat. Flying a lava world at 260 u/s now reaches `phase=entry` in one
frame with range/R holding at 1.06 — no rebound.

**Lift-off had the mirror problem.** Returning to flight at the surface put the
hull inside the collision margin, so the first frame of space threw it back out.
Ascent now parks the ship at `radius * 2.2 + 600` on the sunward flank with zero
velocity and a snapped camera history — you leave a world from orbit, looking at
it, which is also the better shot. Verified at range/R 8.05.

### The yards sell hulls — `ui/ShipyardUI.js`

A shipyard that opens the general trade counter is a prop. It now opens a broker:
four classes with list prices, six signed stat deltas against what you are
flying, livery swatches, and a trade-in valued at `list × 0.62 × condition` with
condition floored at 0.4, so a wreck of an Aethon is still worth something.

**The bug worth recording**, because it is the same shape as a hundred others:
the net was written `Math.max(0, price - value)`. Every upgrade priced correctly
and every downgrade reported "+0 CR BACK" and paid nothing. A refund is a
negative net and subtracting a negative is the whole of it; the clamp that
looked like defensive arithmetic was the entire defect. Verified: a 68%-condition
Aethon valued at 6408 CR, swapped for a Petrel, refunded 1008 CR — 9000 → 10008.

### Next

More exterior and interior variety across the four player classes.

---

## Session 17p — 0.35.0: four ships, not one ship four times

The last item from the owner's content batch: *"improve new player spaceships
with more diverse and different look and parts (interior and exterior)"*.

Both halves had the same shape of problem. The three hulls added in 0.26.0 were
authored in one session against the Aethon's three, and their SILHOUETTES were
distinct while everything at arm's length was bare. Their interiors were worse
than bare: identical to the Aethon's, minus rooms.

### A parts bin, not four hundred more boxes — `ship/HullDetail.js`

The temptation was to hand-place greebles on each hull the way the Aethon got
them. The reason not to is that a greeble written inline exists on exactly one
ship. Written once as a part — `gear`, `dockRing`, `mast`, `flood`, `pod`,
`rail`, `ladder`, `hatch`, `plate`, `dispenser`, `pipes`, `pod3`, `wear` — the
Petrel's nose collar and the Drayman's belly hardpoint are visibly the same
fitting from the same yard. Parts commonality is what makes a fleet read as a
fleet, and it is cheaper than the alternative rather than more expensive.

`kit(hv, hi, gv, gi, rnd)` binds the writers once and returns the bin plus the
raw `H`/`G`/`T` writers, so a builder mixes fitted parts and hand-authored
geometry in one pass.

**Landing gear, on all four.** 0.33.0 let you put a hull down on a planet and
not one ship had feet. Legs are deployed permanently — retracting them wants a
per-frame transform the exterior pass does not have, and a survey hull that
lives on the ground plausibly leaves them out.

Measured, hull triangles before → after: Aethon 11144 → 12064, Petrel **716 →
3240**, Drayman 4080 → 7568, Harrier **904 → 3132**. The two that quadrupled are
exactly the two that read as blockouts.

The import is CIRCULAR — HullDetail builds parts out of ShipExterior's `box`
and `octaTube`, and `buildAethon` bolts those parts on. Safe because both
directions cross only at call time and every name is a hoisted function
declaration. Stated in the file header, because a top-level call reaching across
the cycle would break it silently.

### The interiors stop being the Aethon minus rooms — `data/ShipFit.js`

Three levers, in increasing order of how much they change the read:

**FINISH** — per-zone texture families plus a `default` that repaints the whole
corridor spine. The Petrel is bare steel over open grating, the Drayman is cargo
plate and hazard decking, the Harrier is naval grey. You know which ship you are
on from the first corridor, before opening a door.

**REFIT** — a kept compartment renamed and re-dressed as something else. Three
new rooms: the Harrier's **MAGAZINE** (the class blurb has promised "a magazine
where the laboratory used to be" since 0.25.0, and the room behind that door was
ration cartons), the Drayman's **ASSAY BAY** (a hauler never carried a doctor;
it carried an assayer, and the paperwork calls it a med bay because the survey
office's form has a box for one), and the Petrel's **DISPATCH LOCKER** (on a
mail hull the hold is the job).

The refit dressers are keyed by what a room BECOMES, not by which room it
replaces — nothing stops a future class fitting the magazine into the lab.

**What this deliberately does not touch:** the spine, and every `at`/`center` in
CONNECTIONS. Re-cutting the deck graph is what the geometry audits of 16f and
16x were; finish and dressing buy most of the difference for none of that risk.
Verified: `spine-missing [none]` on all four hulls across seven refits.

**The bug worth recording.** The rebuild was gated `if (c.id !== 'aethon')`,
which is right until you sell a Harrier back for a cutter — then the deck stays
the Harrier's and you are standing in a magazine aboard a survey vessel. Gating
on `shipMap.builtAs !== c.id` is the fix, and the general lesson is that "is it
the default" is never the same question as "is it what is already built".

`_fitted()` returns a COPY of each zone, because `ZONES` is a module table
shared by every ShipMap that will ever exist and a fit written into it would
follow the player between commissions.

Both purchase screens now print the fit note, because the stat deltas say how a
hull flies and nothing said what living in it is like.

Measured: 19 / 21 / 22 / 24 zones, all four spines intact, refits present and
correct across seven back-to-back commissions. 29–41 draw calls in the ship,
76–80 in space. Zero console errors.

### Next

DOM button styling, the landing/approach window onto the framed style, and more
star systems and body variety.

---

## Session 17q — 0.36.0 / 0.37.0 / 0.38.0: the ground, the scale, and the descent

Owner batch: physical docking and walkable stations; boarding and free EVA
flight; realistic space movement; upscale everything; No Man's Sky-style
landing; and 3D surfaces of every type instead of a flat plane.

Three of those shipped this session and are below. Two — walkable stations and
walkable boarded hulls — are not started; they are the next session's work and
are tracked, not quietly dropped.

### 0.36.0 — the surface was flat for two reasons

**The first was a far plane.** The ground was drawn through `camera.viewProjection`,
which carries `RENDER.FAR = 120` because that is the length of a ship and a
corridor never needs more. The terrain patch is 3200 units across. So all but a
120-unit disc around the player's boots was clipped away every frame: there was
never a horizon, the skyline WAS the far plane, and the horizon wash — built at
a radius of 600, outside that plane — had never rendered at all in six sessions.
The ground now has `SURFACE_FAR = 7000` and its own projection.

**The second was the height field.** Products of sines, four octaves, at a
vertical scale that came to about NINE UNITS of relief. Across the visible disc
that is a seven percent slope. A product of sines is also periodic on a regular
lattice, so every hill was the same hill on a grid.

`data/TerrainNoise.js` and `data/Landforms.js` replace it: hash value noise,
fractal sums, ridged multifractal (crests — fbm gives lumps, and no amount of
amplitude turns a lump into a ridge), billow (piled forms), Worley (cell
boundaries — nothing built from fbm makes one), and domain warp, which is one
extra lookup and does more than the other three together.

Thirteen archetypes now each get their own landform. Relief is authored in
WORLD UNITS, so 620 means the ridge is six hundred units above the valley.
Measured: **131 to 499 units**, from about nine.

A thermal erosion pass gives talus slopes, flat valley floors and cliff bases —
consequences of a process, which no noise function produces. Craters gained
central peaks. A detail octave runs AFTER erosion, because erosion is also what
sands off everything at grid scale and a beautiful skyline over a billiard table
is still a billiard table.

Colour is an eight-band ramp indexed by height and slope, replacing a single
flat tint over the HULL PLATING texture — which is why a whole planet came out
one colour with panel lines on it. Cliffs are exposed rock, hollows collect
dark, tops carry frost or scoured ash depending on the world's own temperature.
Boulders, slabs, spires and trunks scatter into the same mesh: a landscape with
nothing of known size in it has no scale.

**Two tuning bugs worth recording.** Band-by-height alone paints a levelled pad
one flat colour, because a pad is all at one height — a mottle term fixes it.
And the fill light was 0.9, set when the ground was effectively unlit, which
meant a lit face and a shadowed face differed by a tenth: five hundred units of
mountain rendered as a silhouette. Fill is 0.40 and the sun rakes at seventeen
degrees, because a landscape lit from overhead has no form in it.

### 0.37.0 — a world was fifteen ship-lengths across

The complaint was "everything is tiny" and the arithmetic says why: a planet was
455 units in radius against a 62-unit ship, and at cruise you crossed one in
under a second.

Two factors, doing different jobs. **Body radius takes 6.4×** — that is what
makes worlds big; Earth is now a hundred ship-lengths across. **Orbital distance
takes 3.33×** — that is what keeps them apart, since radii alone would have put
a 2900-unit world inside a 4800-unit orbit. Distances grow deliberately LESS
than radii: the ratio of orbit to body is what decides how big a world looks
when you are near it, and halving it is the whole trick. Stations take 4×, less
again, because a station the size of a continent stops reading as built.

Orbital periods are held exactly where the last session put them: the third law
would have multiplied every period by six when the axes grew, so μ takes the
CUBE of the distance factor. That is the exact compensation, because a³/μ is all
a period depends on.

The structure multiplier is applied in one pass over the finished list rather
than at the fourteen places a structure record is authored. A factor that must
be remembered at every call site will be forgotten at one of them.

### 0.38.0 — the landing is flown

Entry ran a timer to 1.0 and then declared you landed, at the centre of the
patch, whatever you had been doing. The heat-versus-fuel trade it modelled was
good and survives untouched — but it ended in a CUT, and a cut is what makes a
world feel like a menu option.

The timer now only covers the ionised part of the descent, where there is
genuinely nothing to see and nothing to steer. At 520 units you break cloud with
the terrain built, full attitude and throttle authority, and gravity underneath.
The flight controller runs untouched and owns everything it owns in orbit — this
adds only what a planet adds: weight, ground, and an edge to the surveyed patch.
Nothing here re-implements flying; it decides what flying into a hill means.

Touchdown is judged on the two numbers a real one is: how fast you were going
down and how fast along. Over either and it costs plating — a crash is an
expensive landing, not a fail state. **You walk out where you put the ship**,
not at the middle of the map, which is the entire reason for flying it.
Lift-off comes off the pad with the controls live; the ascent only takes over
above the ceiling.

The cockpit gets its own view matrix inside an atmosphere, because the space
renderer puts the ship at the frame origin and moves the universe — exactly
wrong for a terrain patch that is a real mesh at real coordinates. Still first
person, still from the seat. The two passes use different far planes, so their
depth values are not comparable and one clear between them stops near terrain
z-fighting the console.

Measured: entry → breakout at 512 units → flown cruise across the patch →
touchdown at (197, −99) with no hull loss, handing over to SURFACE at that
coordinate. 88 draw calls in flight, 41 in the ship, zero console errors.

### Next

Walkable stations — dock, disembark, and buy at a counter instead of a menu —
and walkable boarded hulls with free EVA flight around them.

---

## Session 17r — 0.39.0: the projection had a ceiling and the upscale hit it

Owner report: the space walk is broken, station and shipyard models and textures
are broken, docking does not work, the surface is not there when you land,
everything is still too small, and the orbits are still too fast.

Testing these properly is the lesson of the session. The previous pass verified
the flown landing with a probe that called `landing.begin` directly and drove
the descent by hand — which is exactly why it missed every one of these. This
time each report was reproduced through the path a player actually takes: the
approach panel's own DOCK and LAND buttons, `game.startEva`, a real keypress.

### The station models were not broken — the projection was

Everything outside the hull is drawn by moving it onto a sphere of `SKY_RADIUS`
around the eye and scaling it to preserve angular size. That only works while
the drawn object is SMALL compared to the shell. Quadrupling station size put a
trade post's drawn radius past the ninety units between it and the camera, so
half its geometry was behind the eye and it rendered as a field of torn
fragments. The mesh was fine; the renderer was being asked something it cannot
do.

Drawn scale is now capped so a structure's radius never exceeds 0.75 of the
shell. It costs nothing real — a station can still fill seventy-three degrees of
the view, which is as close as a shell renderer can honestly show anything — and
the same fix explains the torn orange object in the EVA screenshot.

**Docking and the space walk were never broken.** Both were verified end to end:
the DOCK button refuels and opens the counter, and the Aethon renders correctly
from thirty-nine metres out on the tether, landing gear and all. What was broken
in both frames was a structure nearby, tearing.

### The surface really was missing when you landed

Two causes, both in the new flown descent.

You broke cloud with the hull LEVEL, so the entire windshield was sky — you
arrived over a landscape you could not see. The descent now starts nose down at
thirty-five degrees, looking at the thing you are descending to, and the
breakout altitude dropped from 520 to 330.

And the horizon wash was drawn at a gain set when it was a thin strip along the
skyline of which half never rendered. It is now a full dome, drawn additively,
and at that gain a hazy world saturated the whole view to flat colour. Cut to
1.35.

### Bigger, and slower

Bodies take 11× (from 6.4), structures 7× (from 4), the star clamp rises to
34 000, and orbital distance takes 4.2× (from 3.33). Orbital periods take a
further 3× on top of the last two slowdowns — an inner world's year is now over
an hour, a moon's month over five. Because μ carries `SPACE_SCALE³`, the
distance change contributes nothing to the periods on its own; the slowdown is
the divisor and nothing else, which is the property that makes this tunable.

### Station-keeping (owner request)

Everything out here moves: a world runs its orbit, a station rides with its
host, a hauler runs its lane. So a ship left at rest is a ship being left
behind, and lining up on something meant chasing it. **HOLD (`O`)** locks the
hull to whatever it is nearest and carries it along by that object's own
per-frame step — position only, so the velocity stays the pilot's and you can
still manoeuvre inside the lock. It drops on going out of range or starting a
descent.

Measured: standoff held at 790 units over six seconds where it had drifted 788
to 596 unheld.

**The bug worth recording:** `holdPrev` is a const scratch and the first press
REASSIGNED it, throwing on every engage. Mutate, never rebind.

### Next

Walkable stations and walkable boarded hulls — still the two items from the
owner's batch that have not been started.

---

## Session 17s — walkable stations: the deck exists, the route to it does not

Groundwork for the owner's "physically dock and walk into the station" ask. What
landed is real and inert; what did not land is named here rather than papered
over, because a half-wired feature that hangs the game is worse than no feature.

### The builder now takes a plan — `interior/ShipMap.js`

`ShipMap` read the module tables directly, which was correct while there was one
deck in the game. There are now two, and they want the identical machinery: room
shells, corridor shells, door frames, the greeble pass, the collision map and
the interact raycast. Everything that differs between a ship and a station is
DATA, so it moved behind a `plan` argument that defaults to `SHIP_PLAN`.

Nothing about the Aethon's geometry changed to do it. That mattered: the deck
graph is what three sessions of audits stabilised and it is the last thing that
should be rewritten to add a feature somewhere else.

### The concourse — `data/StationPlan.js`, `interior/rooms/Station.js`

Nine zones: a docking arm with the only glass on the deck (looking back at your
own hull), an access lock, a five-metre concourse, and four shopfronts off it —
chandler, outfitter, hull broker, taproom — plus a harbour office with a save
terminal at the aft end.

The shops are built around a physical barrier: you can see the racks and you
cannot reach them, so the COUNTER is the interactable. The trade window is the
same trade window; it now has somewhere to be. Counters call out through
`stationHooks`, set per visit, which is how a shipyard differs from a trade post
without needing a second deck: it is which counters answer, not where the walls
are.

### The hang was mine, and it was one line

**Everything below this heading was written before the cause was found, and the
cause makes most of it wrong. It is kept because the mistake is the lesson.**

`SHIP_PLAN.leaves = LEAF_ZONES` was written from inside the LEAF_ZONES comment
block — seventeen lines ABOVE `const SHIP_PLAN`. A temporal dead zone reference,
thrown at module evaluation, so `interior/ShipMap.js` never finished loading,
so `main.js` never ran, so the page never booted.

Which means the "station deck build hangs" was never about the station. Every
probe run after that refactor sat waiting for `window.__debug` on a game that
could not start — including the two that had passed minutes earlier. I read a
dead game as a slow one, then as a hung deck build, and wrote two paragraphs of
hypotheses about concourse geometry for a bug that was in a line of my own
plumbing.

`node --check` cannot see it: it is a runtime ordering fault, not a syntax one.
The tell was there and I misread it — a probe timing out at the
`waitForFunction(() => !!window.__debug)` gate means THE GAME IS DEAD, not that
the thing you were testing is slow. That gate is the boot check, and it should
be the first thing read when anything times out.

`leaves` is now set in the object literal, where LEAF_ZONES is already in scope.
Verified after: 24 zones, 14 rooms, 15 doors, 80 interactables — the
pre-refactor figures exactly — and zero console errors.

### With the game booting again, the station works

`goAboard` builds and swaps the deck in **573 ms**: nine zones, the seven rooms
by name, thirty interactables, five doors, and a map object that is genuinely
not the ship's. Zero console errors. There was never a hang in it.

**One real bug the test found.** Every shop counter was unreachable. `Machinery`
derives its interact box from the prop's own height, so a 1.12 m counter's box
topped out at 1.32 m — and the player's eye is at 1.6, so the crosshair looks
straight over it. The raycast reported "nothing" from two metres away, facing
the till. Counters now register their own volume: full footprint, floor to
2.3 m, standing a metre and a half proud into the room. You walk up to a counter
and look at it; you do not aim at its lip.

### What was written while the cause was unknown

`goAboard` / `leaveStation` are written and the deck swap moves every holder of
a map reference at once. But **building the station deck hangs** — the browser
never returns from `ShipMap.build` on this plan, and I could not isolate it
before running out of room to work safely.

Ruled out: door height against every zone ceiling (2.1 into a 2.6 minimum);
TDZ on the new plan constant; a zero or negative step in the greeble micro pass;
missing dressers on the two corridors; window openings, which skip the frame
builder before it touches a spec they do not have.

**And ruled out after the fact: room size.** The first write-up of this named
the concourse as the suspect on the grounds that it is bigger than anything the
shell builder had been given. It is not. The concourse is 312 m² of floor at
5.2 m; the cargo bay is 280 m² at 8 m, so the cargo bay is the larger volume by
a third and has built correctly for fifteen sessions. Anyone starting from
"the room is too big" will lose a session to it.

What is genuinely untested: the deck-swap path (`useDeck`) and the pointer-lock
request inside `goAboard`, neither of which the ship's own build ever exercises,
and both of which sit between the build call and the first frame. Instrument
`ShipMap.build` per zone first and find out whether it is even reaching the end
— everything above assumes the hang is in the build, and that assumption has not
been established either.

So docking still opens the counter, exactly as it did — verified working end to
end. The station route is commented at the call site with a pointer here.

### Next

Find the deck-build hang, then point docking at `goAboard`. After that,
walkable boarded hulls and free EVA flight are the last of the owner's batch.


---

## Session 17t — the last two: derelicts you walk, and a tether you can drop

### Boarding is a place now — `data/WreckPlan.js`, `interior/rooms/Wreck.js`

Boarding was a panel with a compartment name, an oxygen figure and an ADVANCE
button. The mechanic under it is good — every step deeper costs air twice, once
going in and once walking back — but the player was reading it rather than doing
it.

Same plan machinery as the station, so this cost a data file and a dresser
rather than a system: eleven zones, six compartments on a single spine from the
breach to the drive section. `Boarding` itself is untouched; the salvage point
in each compartment calls the same `advance()` the button used to.

**It is a straight line on purpose.** A wreck is not somewhere you explore, it
is somewhere you go into and have to come back out of, and the whole tension is
the length of the way back. Branching would make the return ambiguous; one spine
means the exit is always behind you and always exactly as far as you have come.
It also maps onto the existing compartment sequence exactly, so the oxygen model
did not have to change at all.

**Every zone is unlit.** No light is declared anywhere on the deck; the emergency
fittings are dead and the helmet lamp is the only working source aboard. That
lamp has existed since Phase 1 and this is the first time it has been necessary
rather than convenient. Ambient drops to 0.047 on entry and is restored on the
way out.

All portals, no doors: a dead ship has no power to open one with, and a deck full
of doors you cannot open is a deck you cannot walk.

**The bug worth recording.** The salvage points were 3.8 m cubes on each
compartment's centre — which is where the player STANDS. `raycastInteract`
deliberately rejects a volume you are inside unless you are looking at its
centre, so a salvage point you were standing on top of reported nothing at all.
They are 2.2 m boxes beside a fitting now. A thing you walk up to has to be sized
like a thing you walk up to.

### The tether comes off — `player/SpaceWalk.js`

Forty-four metres of braid is enough to inspect a hull plate and not enough to
fly around anything: the Aethon is sixty units long, so the line runs out before
you have cleared the nose. `O` unclips.

Off the line there is no line — the jet and the suit are the whole budget, and
the reel cannot save you, so the number that matters becomes how much gas is
left to get BACK. That is a better constraint than a rope because it is one you
spend rather than one you hit. Refused below a 45% jet reserve, because
unclipping with a quarter tank is not a decision.

Same key as station-keeping in the seat, and deliberately: both are "stop being
held to the thing you left".

### Measured

Station deck: builds and swaps in **611 ms** — nine zones, seven rooms by name,
thirty interactables, five doors, a map that is genuinely not the ship's, and
the chandler counter answering `CHANDLER — TRADE` when you walk up to it.

Wreck deck: **1527 ms** — eleven zones, six compartments by name, ambient
0.047, the salvage point answering `STRIP THE HOLD`, and working it charged
**5% oxygen** with the boarding run still live. Zero console errors on either.

### The owner's batch is closed

Physical docking with shops, walkable boarded hulls, free EVA flight, realistic
space movement, upscaled bodies and stations, No Man's Sky-style flown landing,
and 3D generated surfaces — all shipped across 17q–17t.

### Next

The three roadmap items that predate the batch: DOM button styling, the
landing/approach window onto the framed style, and more star systems and body
variety.


---

## Session 17u — 0.41.0: the landing thrusters, and a view to land from

Owner: "landing always crashes, because it has no thrusters at the bottom which
would slow the ship down and land. Add better controllability when landing, and
add third person view for landing."

Correct on all three counts, and the diagnosis was exact.

### The vertical thrusters fired the wrong way

`strafeUp` / `strafeDown` push along the HULL's up axis. In space that is right
and there is no other answer. Over a planet it is catastrophic, because the
descent deliberately breaks cloud at thirty-five degrees nose-down so you can
see the ground — so the thruster you reach for to arrest the fall is pointing
thirty-five degrees off vertical, most of your lift goes sideways, and you hit
anyway. **That is the whole of "landing always crashes."**

A landing thruster is a gimballed ventral jet whose entire job is to hold the
hull off the ground, so it fires DOWN regardless of attitude. `ship.groundMode`
switches the vertical axis to world up for the duration of the atmosphere, and
is cleared on touchdown and on climbing out.

### And there was no hover at all

The second half: the moment you stopped thrusting, thirty-four units per second
per second of weight took over. A ship with flight assist engaged should sit
where you put it — that is what the assist IS — and descending should be
something you ASK for.

With assist on and no vertical command the ventral jets now null the descent.
Press DROP and you get your weight back plus the jets pushing you down; assist
off is the honest version, weight all the time, fly it yourself.

Measured: hands off for five seconds at altitude 317, the hull held at 315 with
a vertical speed of 0.0. Then a full descent on the key, flaring near the
ground, reached the surface with **no hull damage at all** — where before every
approach ended in a crash.

### Nothing on touch could arrest a fall

There were no vertical-thrust buttons in the flight cluster at all, so a mobile
player could commit to an atmosphere with no way to slow down. The landing was
not hard, it was unwinnable. `LIFT` and `DROP` now sit beside `BRAKE`, held
rather than tapped, because those three are what a descent is flown with.

### Third person, for the last twenty units

From the seat, the ground in the final stage of a descent is behind the console
bank — exactly the stage that decides whether the gear takes it. `V` in the
atmosphere now puts the camera behind and above, drawing the hull at FULL SIZE
through the surface projection rather than the shell one, because on a surface
the ship genuinely shares units with the landscape and shrinking it would make
it a toy sitting on a world.

**The tuning bug:** the chase started at 34 units on a 62-unit hull, which put
the camera inside the forward fuselage — the nose filled the top half of the
frame and the landing site was behind it. The entire job of this view is the gap
between the gear and the rock, so the hull has to be small enough that you can
see the gap. 132 units back and 44 up.

## Session 17v — 0.42.0: the cut between a star system and a landscape

Owner report: *"Make the transition between star system fly scene and landing
with ship smooth and without lags or visible teleportation."*

Two separate faults were wearing one costume.

### The lag: a hundred and twenty-eight milliseconds on the commit frame

`buildTerrain` ran synchronously the instant the descent was committed —
measured at **128.5 ms** under the test renderer, which is six dropped frames in
front of a player who has just pressed a button and is watching for a response.

It is now a generator. `terrainJob(profile)` hands the same build out in slices
and `Landing.tickVeil` pumps it six milliseconds a frame while the ionisation
envelope closes. Same work, same output, same determinism — spread across the
second nothing can be seen through. Measured after: **6.1 ms** on the commit
frame, build complete well before the envelope is opaque.

The upload moved with it: `Landing` fires `landing:terrain` when the last slice
lands and main.js does `space.setTerrain` there, so even the GPU transfer
happens behind plasma.

### The teleportation: an eighteen-second timer with no position in it

Entry was positionless. A clock ran while the ship sat wherever it had been in
system space, and at the end of it the hull was **placed** at the middle of the
patch at 330 units — a coordinate it had never flown to. That is the jump cut.

The entry now happens in the terrain's own frame from the moment you commit.
The hull starts at `ENTRY_TOP` (2600 units over the pad) and altitude falls
continuously to touchdown; progress is derived from altitude instead of a clock,
so the number the heat model reads and the number the camera sees are one
number. Lateral stick is integrated all the way down, so the patch you break
cloud over is one you aimed at. `_breakout` now moves **nothing** — it hands the
controls over and halves the vertical rate, and that is all it does.

### What actually hides the swap

A slower swap is just a longer cut. What was needed was something opaque in
front of it — and an atmospheric entry already has one, because a real shock
layer ionises and the ship flies inside a lit envelope seeing nothing.

`ui/EntryVeil.js` draws it: chunky blocks on the fixed 480×270 UI grid, a
quantised eight-step plasma ramp out of the WARNING_RED → AMBER_MACHINE
families topped with a dirty cream, a stepped shock front with 4×4 Bayer stipple
at every band boundary, 54 seeded streaks dragged past the glass and 64 embers
of ablated plating. No smooth gradient anywhere.

`Landing.showGround` is what the renderer reads, and it flips **only while the
envelope is solid** — so the star system becomes a heightfield, and on the way
out a heightfield becomes a star system, on a frame of orange. The nose-down
descent attitude moved onto that same covered frame: snapping it in the open,
on the frame the LAND button was pressed, was a hand grabbing the stick out of
yours.

Measured: envelope closed at 2.0 s, world swapped under it, entry flown from
2589 down to 358 units, breakout at `fly` with the veil at 0.95 and clearing to
zero over the next two seconds. No console errors.

### And the ascent had the same cut, unnoticed

Climbing out ran a bare countdown with the hull parked at whatever altitude
triggered it, then teleported to orbit when the timer expired. It flies out now
— the ground genuinely falls away — and the orbital reposition happens at the
moment the envelope takes the ground away, not when the timer ends. That path
also had no `setTerrain(null)` at all, so a climb-out from atmospheric flight
left stale terrain resident and the hull inside the world's collision sphere.

### Two smaller things the position rewrite exposed

- `tele.alt` was a fraction of the progress bar rescaled to look like a number.
  The radalt and the ship disagreed about where the ship was for the whole
  descent. It reads real altitude now.
- The entry's breakout floor was pad height. Steer over a ridge on the way down
  and you would break out inside it. It is the ground under the hull now.

## Session 17w — 0.43.0: the ground stops being wallpaper

Owner report: *"Enhance much more celestial bodies and their surfaces. Add more
plasticity and more diverse elements."*

The relief was never the problem — 17q already put 130 to 620 units of it under
the ship. Five other things were, and each of them was flattening the result in
a different way.

### 1. One field, corner to corner

Every world ran a single landform across the whole patch, so every direction
you turned gave you statistically the same view. A landscape whose entire
content is visible from the first frame is wallpaper however much vertical
range it has.

Worlds now carry a **primary and a secondary landform**, and a province field
decides per sample which one you are standing in. The transition is *sharpened*,
not lerped: real provinces meet along a boundary — a scarp, a shoreline, the
edge of a flow — and a slow cross-fade gives you neither landscape but a mush
of both.

Eight new fields to give the secondary somewhere distinct to come from:
`badlands`, `karst`, `volcano`, `fjords`, `basin`, `foldbelt`, `pinnacles`,
`rift`. Twenty-two in total. Two of them (`volcano`, `basin`) are the first
fields in the set with a **centre** — a landmark you can navigate by, which
nothing statistically-uniform can give you.

**The bug that caught:** a centred field puts its centre at the origin and the
origin is the landing pad, which is levelled flat as the last step of the build.
The first version carefully constructed a volcano and then bulldozed its summit
— measured relief on a lava world came out at 172 units with a `rel2` of 3.4.
Centred fields now sit off-axis at a seeded bearing. 356 after.

### 2. No occlusion, so no volume

One directional sun and a flat fill means a hollow and a shoulder at the same
slope come out the same value, and the ground reads as a corrugated sheet.

The build now computes **cavity** — a separable box blur of the heightfield,
then `h - blur`, which is positive on crests and negative in gullies — and bakes
it into the vertex `v` coordinate. The terrain ramp's row axis stops being
decorative grain and becomes a **shade axis**. No shader change, no extra
texture, no second draw call, and it is the single biggest reason the ground now
looks like it is made of something.

### 3. A cliff was one flat colour

The one place you can see a world's insides was showing no information at all.
Exposed faces are **bedded** now, alternating between three rock bands keyed to
*absolute* height — so the beds line up across a valley from one wall to the
other, which is the read that says these layers were laid down before this
valley was cut. The steepest faces of all take a fourth band: fresh fracture.

### 4. Eight bands could not say anything

Eight was hollow / ground / two mixes / accent / one face / ridge / cap. There
was no band left for a stained region, for scree, for a vein. **Sixteen** now:
two hollows, five steps of ground, a second regional material in five more
(which is also what the strata alternate between), fresh fracture, and the ridge
and cap. A large-scale province noise moves a whole region onto the second
material, so two plateaus at the same height are made of different rock.

### 5. Everything varied at the wrong scale

The mottle was a 260-unit patch and the province a 1200-unit region. **The
walker is 1.6 units tall.** From standing height the entire near field falls
inside one patch of every one of them and comes out a single flat colour. A
120-unit break (six grid cells, the shortest this grid carries cleanly) and a
per-vertex grain now break up the ground you are actually standing on.

Three more things were sweeping the near field bare:

- The **pad** levelled 72 units of radius blending out over 187. From eye height
  that disc is most of the frame. 50 blending over 110 now — the ship is 62
  units long and sits on it comfortably.
- The **scatter exclusion** was 137 units, eighty-five body-lengths of nothing
  with the closest object on the horizon. Big props still stay out; small ones
  come in to 36.
- The **sun** was raked to −0.30, which put every horizontal surface at ndl 0.30
  — *below* the 0.40 fill. All flat ground clamped to fill and received no
  lighting information whatsoever. −0.44 is still a 26° sun and flat ground
  responds again.

### 6. One silhouette, a hundred and forty times, uniformly at random

Uniform random is the placement that looks least like nature; real ground is
mostly empty with things gathered in fields. Scatter is now a weighted **mix**
per archetype over **twelve silhouettes** — boulder, cobble, slab, spire,
needle, trunk, hoodoo, shard, stack, vent, plus three built by hand: `arch` (the
one thing in the set you can see *through*), `rib` (half-buried, deliberately
ambiguous, could be bone) and `plate` (manufactured, and this game's fiction is
full of ships that did not make it). Placement is clustered into fields with a
size gradient, half of them near the pad, plus loners so the fields do not read
as a grid of clumps.

### Measured, all thirteen archetypes

Relief 151–593 units · 57.6k–65.3k triangles · 145–394 props · 15 of 16 bands in
use on every world · no NaNs · no neon · build 60–154 ms, sliced. In-browser:
41 draw calls walking, 87 in flight, 45 in atmosphere, 5 on the surface, foot
placement error 0.10 units after a walk, full landing-to-orbit round trip with
no console errors.

## Session 17w (cont.) — 0.44.0: weather, and the end of the smooth marble

The same request's other half — *"enhance much more celestial bodies"* — meant
the view from orbit, not just the ground under the boots.

`Planetology` already simulates plates, climate, hydrology and biomes for every
body, and `planetTexture` renders all of it. Two things were still wrong with
the result.

### A world with ninety bars of atmosphere was showing you its bedrock

Every pixel of a toxic world's sheet was CRUST — geology in perfect detail,
which at that pressure is exactly what you would not see. The absence also cost
the sky-worlds their only source of large-scale contrast, which is why one read
as a smooth tan marble from close orbit.

There is a cloud deck now, on anything over 0.25 bar, and it is organised into
**latitude belts** rather than sprayed on: rising air at the equator, clear
sinking subtropics, mid-latitude storm tracks, sheared along longitude by the
zonal wind. Cover is quantised to three steps and Bayer-thresholded, so it
arrives as dithered stipple and never as a soft alpha wash. The deck takes the
world's own colour — a sulphuric one is yellow-grey, an ammonia one is bone.

### The biome ramps are four colours, so a region was a solid field of one

At 768×384 on a body filling half the windshield, one ramp index covers hundreds
of screen pixels of perfectly flat colour — a rendered ball, not pixel art. A
4×4 ordered threshold against a per-texel hash now steps every texel up or down
one value, and the whole disc breaks into stipple.

**A hash, not another octave of fbm.** This runs on every texel of every body in
the system — the first version used two more noise octaves there and cost a
measurable second of load time. Hashed on 2×2 blocks so the grain is chunky
rather than television static.

Verified: walk 41 draws, flight 87, atmosphere 45, surface 5, full landing round
trip, no console errors, boot unchanged.

## Session 17x — 0.45.0: the square becomes a planet

Owner report: *"create whole celestial bodies surfaces, not just a square area."*

A surface was a 3200-metre square with a wall round it. However good the field
inside it got — and 0.43.0 got it good — the world was a square, and walking far
enough in any direction stopped you.

### A landform is a function of a DIRECTION now, not of a plane

`data/TerrainNoise.js` gained the third dimension: `noise3`, `fbm3`, `ridged3`,
`billow3`, `worley3`, `warp3`, `seedDir`. Every one of the twenty-two landforms
in `data/Landforms.js` was rewritten to sample the field ON THE BODY'S SPHERE
rather than on a plane, because a 2D field cannot be wrapped onto a globe
without tearing at a seam, pinching at the poles, or repeating. A 3D field
sampled on a sphere has none of those: no seam because there is no edge, no pole
because every direction is the same kind of direction, and no repeat because the
surface never revisits a point in noise space.

The rewrite made several fields **better**, not just spherical:

- **Dunes** now know which way the wind blows. Ranks run along the parallels,
  because a planet's low-latitude circulation is zonal.
- **Fold belts** and **rifts** run along GREAT CIRCLES, so an orogenic belt or a
  spreading centre girdles the whole world and closes on itself.
- **Volcanoes** and **impact basins** became plural. The flat version put one
  cone at one seeded place, which is fine in a square and useless on a globe —
  you would never find it. They are scattered on a lattice now, one per cell,
  each with its own hashed height, caldera and flank gullies, so "volcanic
  province" means a landscape you fly across finding cone after cone.
- **Craters** left the build loop entirely and became a global field
  (`impacts`), on three lattices — eighteen kilometres, seven, and two and a
  half — because "craters inside craters inside craters" is the actual feature
  line for an airless world and one scale cannot produce it.

### The mesh is a cap, and it follows you

`buildTerrain(profile, frame, extent, grid)` builds a cap of the sphere around a
FRAME: a point on the body plus two tangents. Vertices sit at `(R + h)` along
their own direction, so the curvature is real — a couple of metres on an
Earth-sized world, and on a 60-km comet the horizon is 438 metres away and you
can see it bend.

`Landing.trackFrame` watches whatever the anchor is — the hull in flight, the
boots on foot — and when you cross forty percent of the cap it starts building
the next one IN THE BACKGROUND while the old one is still on screen. The cap
also resizes with altitude: 1600 metres on the ground, up to 11 km from the top
of the atmosphere, because from three kilometres up a cap the size of the one
under your boots would end in mid-air.

**Why nothing jumps when it slides.** The height is a pure function of direction,
so the new cap holds exactly the same ground. The new frame is the old one
rigidly rotated — parallel transport, no twist — so a heading expressed in frame
components is unchanged and needs no correction. The anchor lands on (0,0) by
construction and everything else shifts by the same offset onto the identical
physical point.

Everything that used to vary with the cap's local coordinates had to move onto
the direction too, or it would swim on the swap: the detail octave, the mottle,
the near-field break, the colour provinces, both grain terms, the landing pad,
and the scatter. The props are the sharpest case — they come off a jittered 3D
lattice in the body's own noise space now, so a boulder belongs to a PLACE ON
THE WORLD and is the same boulder every time any cap covers it.

### Measured

- All thirteen archetypes: relief 227–444 m, 58–69k triangles, 179–543 props,
  15 of 16 bands, no NaNs, no neon, 137–263 ms sliced.
- **Continuity across a 900-metre frame slide: 0.06, 0.12 and 0.16 metres** at
  three sampled points, and **201 of 201 props carried across.** That number is
  the whole thing — it is what makes it one planet rather than two patches.
- In-browser: walked **9 kilometres** in one direction across thirteen cap
  slides. The old wall was at 1504. Worst ground step attributable to a slide
  was 16.25 m, *below* the worst ordinary step over the same distance (33.8 m
  across a cliff), so the slides are invisible against the terrain itself.
- Landing still lands, launch still launches, entry veil unchanged: commit costs
  2.2 ms, envelope closes at 1.76 s, no console errors anywhere.

### The one thing that is not a pure function of direction

Thermal erosion. It looks at neighbours in the cap's own grid, so a rebuilt cap
can differ by a metre or two from where the same ground sat in the previous one.
That is the 0.12 m in the continuity numbers above, it is well under the detail
octave's own amplitude, and it is documented at the erosion call rather than
quietly tolerated.

## Session 17y — 0.46.0: the last two screens, and the rows inside them

Roadmap #85 and #84, both left over from the 0.8.x UI pass.

### #85 — the landing and approach windows

Two screens never came onto the bulkhead style. The **surface operations board**
was a floating rounded plate over a dimmed game: a web modal sitting beside a
hold manifest and a commission screen that both read as parts of the ship. It is
full-screen framed now — rails, cut corner plates, amber trim, dead indicator
ticks, star field — with the world's figures down the left, the survey sites and
the log down the right, and the two decisions on a footer bar. The sim was
already frozen while it is up, so taking the whole viewport costs nothing and is
the honest presentation: you are reading a survey, not glancing at a pop-up.

The **approach readout** could not do the same, because its entire job is to be
read *while you look at the body it is describing* — the placement comment in
that file is three paragraphs long for exactly that reason. So there is a third
treatment now, between `framePanel` (a plate with corner brackets) and
`bulkheadFrame` (the whole screen): **`windowFrame`**, the same bulkhead
materials at panel gauge, applied in place so a caller that already built its
layout does not have to be rewritten to gain rails. The approach panel wears it
with `NAV · APPROACH` cast into the top rail.

`closeButton` now tags itself and `windowFrame` watches for one, because
`panelChrome` is usually called after the frame and the key would otherwise land
on top of a corner plate.

### #84 — the DOM buttons were fine; the ROWS were not

Every actual button in the game has been a moulded chamfered plate since 0.8.3.
What had never been touched were the **list rows** — a survey site, a hull on the
broker's board, a recovered log — each of them `border:1px solid #2a2a36;
border-radius:5px`, which is a web list item, sitting inside screens that had
grown rails around them. That contrast is what "the buttons still look like a web
page" actually comes down to.

`plasticRow` is the same language at row proportions: the moulded plate, a
chamfer on the LEADING corners only (a full chamfer on a wide row reads as a
ticket stub), a recessed inner ring, and a lit left edge when the row is
selected — which is how a rack-mounted selector shows you which channel is live.
Applied to the survey sites, the hull board, the livery swatches, the recovered
logs and the work orders — every selectable row in the game.

Verified: all four screens shot in-browser, full landing round trip unchanged,
41/87/45/5 draw calls, no console errors.

## Session 17z — 0.47.0: the pilot starts changing too

Owner: *"add looting mechanics and other rpg elements/mechanics… more items,
lootable items, more depth and more complexity."*

### The thing that was missing

Everything in this game was the same on hour twenty as on minute one. The ship
changes — you buy hulls, you fit them — the inventory changes, the standings
change, but YOU did not. A landing you had flown fifty times was exactly as hard
as the first one, and there was nothing on the other side of doing something
well except having done it.

`gameplay/Progression.js` is five proficiencies that level from doing:
**PILOTING**, **SALVAGE**, **XENOLOGY**, **ENGINEERING**, **MARKSMANSHIP**. Ten
levels each on a front-loaded curve — level 2 arrives inside the first hour so
the system announces itself, level 10 is a commission's work at one activity and
is deliberately not required for anything.

**It is not a skill tree.** Nothing to spend, nothing to pick wrong. You get
better at what you actually do, the way a working pilot does. That is the part
of an RPG that models a job rather than a hero, and this is a job.

**It reads the event bus and nothing else.** Every event it listens to already
existed for the lore unlocks or the quest tracker, so no other module had to
learn progression exists, and an activity cannot be paid twice because exactly
one place decides what an event is worth. Three new events were added where
there was genuinely nothing to listen to: `loot:searched`, `ship:repaired`,
`hack:solved`.

**All bonuses are read, never pushed.** Consumers call `bonus('entryHeat')` when
they need it — named for the effect, not the skill — so a save loaded at a
different level is instantly consistent and there is no accumulated multiplier
to drift out of step. Wired at nine call sites: entry heating and gear tolerance
and landing fuel in Landing, site oxygen and hazard odds and sample yield in
`workSite`, repair size in `fieldRepair`, the intrusion clock in the hacking
minigame, scanner range on the radar, and damage plus ammunition economy at the
one place in SpaceCombat where damage actually lands.

At level 10: entry heat ×0.60, gear tolerance ×1.30, repair ×1.70, damage ×1.40.
Nothing doubles. A progression system that made the late game easy would be
removing the game.

### Looting, which was one flat table

`data/LootTables.js` replaces the old per-pattern lists. Three things changed
and all three are about making the eleventh locker worth opening:

- **A rare shelf per container.** One gate for the whole box rather than a
  chance per rare row — either this one had something at the bottom of it or it
  did not, which is how a search reads.
- **Container class.** The same word means different things in different places:
  `ship` 1.00, `station` 1.12, `surface` 1.20, `derelict` 1.38, `alien` 1.65.
  Scales the odds and gates the shelf.
- **The pilot.** SALVAGE multiplies the tier rather than adding to each row —
  an absolute bonus makes a 0.08 row and a 0.6 row equally likely at high skill,
  which flattens every table into "you get one of everything".

Thirteen tables now, including alien, armoury, science, engineering, bridge and
surface-wreckage sets that did not exist. Measured: a crew locker yields 2.17
items and 8% rare aboard, 3.72 and 14% in an alien structure, 3.91 and 54% at
maxed salvage.

### Something to walk to

Surface looting was the gap: you could land on a whole planet and there was
nothing on it to open. A **second, sparser lattice** scatters manufactured
debris — hull panels, half-buried ribs, crushed canisters — about one every four
hundred metres, on its own lattice rather than out of the archetype's rock mix.
That separation matters: a lava world scatters slabs and vents, a comet scatters
needles, and neither would ever have produced wreckage.

Walk within six metres and the HUD offers `[E]` — the same verb, the same key
and the same prompt as a locker aboard, because it is the same act. The key is
the LATTICE CELL, so a cache you emptied stays emptied across cap slides, save
loads, and coming back to the world a month later.

Measured: 25 caches on one cap, walked to the nearest, pressed E, two items into
the hold and the salvage XP credited.

### Items: 279 → 313, and the first ones that change the ship

Four new families, and every id is reachable from a loot table, a surface find
list or a shop:

- **Fittings** — the first items in this game that are WORN rather than
  consumed, sold or read. Carry a long barrel and your shots go where you meant;
  carry entry ablator panels and the plasma costs you less plating. No slots, no
  paper doll, no menu: it is in the hold, so it works.
- **Data** — deep-range charts, an encrypted ledger, a sealed crew manifest, a
  xenological index with nine entries crossed out.
- **Artifacts** — five more, including a vessel of still water whose contents
  have not moved through eleven gravities of manoeuvring.
- **Bulk trade** — rare earths, reactor salts, refractory ceramics: the goods a
  hold is actually for.

### Verified

XP credited from bus events with nothing calling progression directly · levels
cap at 10 and every bonus moves · save round-trips exactly · loot tiers and skill
scaling measured across 400 rolls each · a cache walked to and searched in-game ·
full landing round trip unchanged at 41/87/45/5 draw calls · no console errors.

## Session 18a — 0.48.0: sixteen systems, and four worlds the chart could not describe

Roadmap #87, the last item on the board.

### Six more systems, and why sixteen is a different number from ten

The route is five and the first spur ring made ten, which was enough to make
warp a *decision*. Sixteen makes it a **career**: there is now more chart than
one commission can survey, so where you go stops being a sequence and becomes a
choice with an opportunity cost on it.

- **KILN** (K) — a quiet orange star with a violent past. A tide-locked world
  whose survey team works the terminator or does not work, and two ash worlds.
- **SALT MERIDIAN** (F) — two worlds that used to have oceans. The tide lines
  are still there. A ringed giant whose rings assay as salt.
- **RUSTBELT** (M) — iron, all of it. Five worlds of banded ore, a shipyard that
  builds hulls out of what it digs, and a loaded hauler nobody came back for.
- **THE ORCHARD** (A) — crystal grows here, and nobody has established whether
  that is a figure of speech. The shards have growth rings. A Kestrel cutter sits
  intact, powered down, hull unbreached, airlock sealed **from outside**.
- **THE FORGE** (RG) — a red giant eating its inner system. Two worlds already
  gone, a third a matter of decades, and one station built to outlast it.
- **NURSERY** (F) — a young system where the planets are not finished and the
  disc is still full of the material they were made from.

### Four new surface archetypes

Each exists because there was a silhouette the route could not produce:

- **ASH PLAIN** — an ash world reads nothing like a lava world, because the
  eruption is *over*. Ash to the ankle, cinder cones in a row all the same age,
  and footprints from an hour ago already softening.
- **DRIED SEABED** — the only flat in the game that is flat *for a reason*. Salt
  polygons a metre across, evaporite terraces, a tide line eighty metres up a
  cliff with nothing under it.
- **BANDED IRON** — the only world whose strata are the whole landscape rather
  than a detail on a cliff. The compass swings and keeps swinging.
- **CRYSTAL FIELD** — the only place where the things standing up are not rock.
  A forest of shards taller than the ship, all leaning one way.

Each carries a full `TERRAIN` entry (landform pair, talus, scatter mix, palette,
feature lines, find table) and a matching `PLANET_SPEC` crust in Planetology, so
they are simulated worlds from orbit as well as walked ones on the ground.

### Six new body types on the chart

`ashWorld`, `saltWorld`, `ironWorld`, `crystalWorld`, plus **`tidalLocked`**
(one face has never seen night, the other has never seen anything else) and
**`oceanIce`** (a cracked shell with a liquid ocean under it, venting at the
south pole). `planetTypeFor` was rewritten to give them real orbital homes —
tide-locking right against the star, desiccated worlds on the hot edge of the
zone, banded iron and crystal out past it — and moons can roll `oceanIce` now,
which makes a gas giant's moon system worth a survey pass in its own right.

### Measured

**16 systems · 346 bodies · 16 distinct surface kinds**, all sixteen listed on
the warp chart. All four new archetypes build clean: relief 123–510 m, 60–66k
triangles, 222–484 props, no NaNs, no neon. Warped to THE ORCHARD, landed on a
crystal world (505 m of relief, 34 searchable caches) and walked it. Full
landing round trip unchanged. No console errors anywhere.

---

## Session 18 — the boarding chain, and two landings that were lying to you

`0.49.0` → `0.53.0`. One owner message, seven parts, all of them shipped.

### The space walk was not "stuck" — it was embedded, and then invisible

Two faults, and the second only appeared once the first was fixed.

The airlock hatch was at `x = 9` on a hull whose half-width is **13.8**. You did
not step outside; you stepped *into the plating*, with the hull filling the
whole frame at a reported range of three metres and nothing you pressed moving
you off it. The hatch now sits on the skin, and leaving is a real exit: the
outer door gives you 2.6 u/s and holds your controls for 1.8 s while you drift
clear, so the first two seconds are the hull going past at arm's length.

Then the ship vanished at about a hundred metres. The suit was borrowing the
walking camera's frustum, whose far plane is 120 units — shorter than the Aethon
is long — while the hull drew at the 0.55 chase scale. Push off to look at your
own vessel and it clipped out of existence into an empty starfield. The suit has
its own frustum now (`EVA_NEAR`/`EVA_FAR`) and the hull draws full size, because
from a suit a ship is the size the ship is.

And there is something to hold: **24 handholds** on the port and starboard
rails, the spine and the keel. `[E]` takes hold and kills your drift for free —
the only brake in the game that costs no gas — `[E]` again pushes off along the
helmet's forward, and any jet input lets go for you.

### Boarding is a crossing now, not a button

It used to be INSPECT on the approach panel: you pressed a key in the cockpit
and arrived inside. Other hulls now appear in the suit's own frame with a live
range, and reaching one means unclipping (44 m of braid reaches nothing),
spending gas you will need to get home, and pressing `[E]` against the plating
with your own ship a hundred metres behind you.

**Station-keeping now runs while you are outside, and that was the whole
feature.** The hold lived inline in the flight branch, so it only ran while you
sat in the seat — invisible while you walk your own hull, fatal the moment you
leave it. A derelict rides its host world's orbit at tens of units a second, so
a ship stopped dead beside one is already falling behind before the outer door
finishes cycling. The first crossing test measured it exactly: **147 m out, and
3.2 km away after ninety seconds of flawless pursuit, with the pack empty.**
Cycling the lock now takes the hold for you if you have not.

### Something is still aboard, and it can be killed

Three species, off the faction notes in `context/03` §5:

- **CARRION** (ours) — the scavenger organism that gets into a hull once nobody
  is maintaining it. Fast, weak, arrives in threes. The "something moved" enemy.
- **KETH BOARDER** — the Armada's own salvage party in angular black-red plate,
  and the only kind that shoots back.
- **DRIFT DRONE** — `#2a2a30` chassis, white fractal marking. Does not hurry,
  does not stop, and **cannot be roused by noise at all**: proximity is the only
  thing it answers to, so it is the one you creep past and then regret.

They are deliberately the opposite pole from the Hollow. `context/04` is
explicit that the entity has no health, no hitbox and no defeat state, and
`PersonalCombat` enforces that by construction — if the only thing in the dark
were unkillable then a gun would be scenery. Boarders are ordinary and mortal so
the weapon means something, and the dread stays with the one thing that does not
die.

Five part meshes each, joints at the mesh origin, drawn through the interior
renderer's new `actors` hook so a thing walking at you is lit by the compartment
it stands in and by your helmet lamp, exactly like the walls.

**The carrion took three builds.** The first two were a low quadruped nearly two
metres long and under a metre tall, and a body with twice as much depth as
height shows a standing player its *back* — which under an 84° lens spills down
the screen as deck plating. It was a creature in the data and a plank on the
screen. It now stands: 1.17 deep against 1.45 tall, hunched, on hind legs.

They also ping the proximity scanner, which has detected exactly one thing since
Phase 5 (doors opening) because nothing else aboard moved. And the arms locker
now holds arms — it held ammunition and nothing to fire it with, which was
survivable only while nothing could be shot.

### The plasma peels back

"Surfaces need to smoothly appear without lags and loadings." They did not
appear at all — they were *revealed at the bottom*. The ionisation envelope was
pinned solid for the whole entry, so from the frame you pressed LAND to the
frame control came back the screen was opaque orange: technically an entry
effect, in practice a loading screen with a plasma texture on it.

It is now opaque only until there is a world underneath it — still the frame the
star system becomes a heightfield on, still hidden — and then it peels off
across the first stretch of the descent. Measured: solid, swap, then
`0.96 → 0.87 → 0.74 → 0.57 → 0.38 → 0.18 → 0` with a third of the descent still
to run.

### The descent was arithmetically impossible

The ventral jets were the manoeuvring RCS at 46 u/s². Gravity at one g is 34, so
net climb authority was **twelve**: arresting the seventy units a second you
break cloud with took six seconds and two hundred metres out of the three
hundred and thirty you are given. Over 1.3 g the net was **two** — thirty-five
seconds and twelve hundred metres. No amount of piloting was going to fix that.

Ground mode has its own figure now, `DESCENT_ACCEL = 118`, which out-lifts two g
with margin left to fly on. The view and the controls are otherwise exactly what
they are in space, which is what was asked for.

### Bigger decks, and compartments that match their rooms

The wreck went from six compartments to **ten**: a galley off the crew spaces, a
workshop off the bridge, and a reactor space and sealed compartment at the far
end — the last two reached through an access crawl you meet whatever is in there
on your hands and knees. The station went from seven rooms to **eleven**: a
clinic that sells health and radiation clearance for credits, transit bunks, a
bonded transfer bay where the cargo actually crosses a floor, and a customs post.

And the boarding sequence was re-keyed to the deck. `COMPARTMENTS` was indexed
positionally against `WRECK_DEPTH`, so the flavour text and the loot pool were
misaligned with the room you were standing in — the sick bay handed you galley
stores. The ids are the zone ids now. The random depth roll no longer truncates
the sequence either (walking into a real, dressed, modelled workshop and being
told the hull had ended); it sets how far in the salvage runs out, and past that
mark a compartment costs the same air, rolls the same hazards, and tells you
somebody worked this far in before you.

### Measured

EVA hull visible at 47 m and 127 m with engine glow. Crossing to a wreck parked
50 m off the skin: range **holds** instead of running, costs 33% of the pack and
ten seconds, hull in reach at 6 m. Three hostiles aboard, one-shot carrion kill
at 34 dmg vs 28 hp, body stripped for two items, 29 draw calls with three actors
on the deck. Wreck deck: 17 zones, 10 salvage points, every compartment
reachable and resolving to its own zone. Station deck: 13 zones, 45
interactables, all eleven rooms reachable; clinic took 44 hp / 21 rad to 100 / 0
for 200 cr. Landing flown end to end: breakout at 328 m doing 62 down, on the
deck-approach at 7 down, hull untouched. No console errors in any run.

### Addendum — the enemy ship you board is one you shot down

The owner's ask said "whole enemy ship model and whole enemy ship interior with
loot, enemy aliens which player needs to kill", and what shipped first was
*derelicts* — hulls that were already dead when the system loaded. A live
hostile still only ever exploded. `0.54.0` closes that.

**A hull taken to zero does not always come apart.** If the blow that finished
it did not massively overshoot — under a third of its own hull again — the ship
goes dark and adrift instead: no drive, no guns, no running lights, tumbling on
the velocity it had when the reactor went out, with its crew still inside.

Overkill is the whole mechanic, and deliberately a skill rather than a dice
roll. Finish a fighter with a measured burst and there is something to board;
put a torpedo into it and there is a debris field. That makes the weapon you
pick for the *last* shot a real decision and gives the PDC a use it never had.
Capital hulls are excluded — a corvette drifting intact beside you would be a
boarding action against forty people, which is a different game.

Boarding one is not salvage. The species is forced to the hull's own faction
(you have been shooting at them, there is no question who is aboard), the deck
runs at danger 0.95 rather than a found wreck's 0.5, and the faction ledger
takes −14 with a −3 from Kestrel, who object on liability grounds.

**Station-keeping had to learn about it.** `system.approach` only knows the
chart, and a hull you crippled yourself is not on it — the first crossing
measured 453 m at the airlock and 3.3 km by the time it was over, because a
Keth fighter keeps its two hundred units a second when the drive dies. The hold
now considers crippled hulls too.

Measured: a 70 hp fighter chipped down 20 at a time cripples; the same fighter
hit for 900 destroys. Crippled hull holds at 209 m instead of running, crossing
costs 49% of the pack, `[E]` at 7 m puts you in the breach with **five Keth
aboard**, and Keth standing goes 38 → 52 against you for doing it.

### Addendum — making the firefight legible

Two faults I introduced with the boarders, both found by looking at the thing
rather than at the numbers.

**A Keth bolt is a hitscan with no tracer.** It works — the damage lands, the
sound plays — but on an unlit deck what the player experiences is a number
going down for no visible reason, which is indistinguishable from a bug. There
is now a dashed warm track from the muzzle to where the round actually went.

Two things had to be true before it drew anything at all. A bolt aimed at the
camera projects to a *single point at the crosshair*, so the first version
rendered one every 1.9 seconds and none could be seen; rounds now end at a
shoulder, offset across the line of fire, and always carry on past. And a miss
that carries past you has its far end BEHIND the camera — the segment was being
discarded rather than clipped, which threw away exactly the shot most worth
seeing. It clips to the near plane now.

**A directional damage mark on the visor.** A survival game may absolutely kill
you from off screen; it may not do so without telling you which way to turn.
An arc at the edge of the glass, at the bearing of whatever hit you, folded per
direction so sustained fire reads as one source rather than a stack of wedges.

Worth recording how the first version of that shipped pointing backwards: the
bearing used `atan2(x, z)` where the camera's convention is `atan2(−x, −z)`, so
every mark was off by exactly π — and the probe only asserted that the arc swung
by π when the player span by π, which a constant-π error passes perfectly. The
horizontal was mirrored on top of that, and only came out when the test was
rewritten to check ABSOLUTE placement in all four directions. Two convention
bugs in one session that self-consistent tests waved through.

---

## Session 18j — 0.57.0 — The bench works, and so does the galley

Owner ask, four parts: continue the leftovers, **add more interactive content —
"parts which actually do something"**, enhance the inventory with more
complexity, and add hundreds of items with unique icons. The last part shipped
in 0.56.0 (483 items, 483 distinct icons). This is the other three.

### The workshop bench

`src/gameplay/Fabrication.js`, `src/ui/FabricatorUI.js`.

The fabrication bench has said `CRAFTING SUITE OFFLINE PENDING PARTS AUDIT`
since Phase 2. It was the largest prop in the game that did nothing, and with
four hundred and eighty three items in the registry the only thing a hold full
of scrap was good for was selling it to somebody else.

**21 recipes** across SHIP / SUIT / ORDNANCE / MEDICAL / STOCK. The design rule
is that *nothing here makes a better version of a thing you can buy* — that is a
progression treadmill and this game does not have one. Every recipe converts
something you have too much of into something you ran out of, in a place with no
shop: scrap and steel into hull patch, ore into stock, lithium into cells,
Verdane sap into burn gel, fabric into dressings. Each carries a spoil chance
that eats the inputs, halved at ENGINEERING 10.

The panel shows recipes you *cannot* afford, greyed, with the shortfall in red —
because "what do I need to look for out there" is the question a crafting screen
is actually being asked.

**Two economy bugs, both found by reading the STRIP tab rather than the code.**
Plating scrap broke down into plating scrap, and with the SALVAGE bonus rounding
1 up to 2 that was an infinite-resource exploit sitting in plain sight. A slug
magazine returned more refined copper than loading it consumed. `recycleYield`
now refuses any mapping whose output is its own input; ore, minerals and trade
cargo are off the recycle table entirely (rock goes in the smelter, and a bale
of fabric is worth more as fabric); and a scan of all 21 recipes against all 483
items at maximum salvage skill reports zero closed loops.

### Fittings that do work

`src/gameplay/ShipStations.js`. Four props aboard your own hull, each drawing on
a store that runs down, because a dispenser that hands out infinite rations
deletes hunger from the game:

| Fitting | What it does | The store |
|---|---|---|
| GALLEY DISPENSER | serves a meal | 212 ration units, and the good flavours really do go first |
| WATER RECLAIMER | bottles a pouch or a canister | a loop tank that refills in twelve minutes at full power |
| MED BED | +34 HP / −22 RAD, refuses when nothing is wrong | 8 dispensary doses, 40s cycle |
| ASSAY BENCH | crushes the best sample for a survey fee + skill credit | the sample |

The rack has claimed 212 ration units since Phase 2. It now *means* 212.

The Petrel drops the whole workshop, so the engine room gains a **FIELD BENCH** —
every hull has an engine room, so every hull can work. The shipyard outfitter's
test rig opens the same card.

### The hold manifest, deeper

Nine top-level categories and a raw grid stopped being a manifest at 483 items
and started being a haystack. Added: **search** (matches name *and* description,
because "the one with the lithium in it" is how anybody actually remembers an
item), **six sort orders** on one cycling chip, a **subcategory sub-rail** that
opens under the chosen category, **rarity pips** on the tiles, and a real
**record** in the readout — value/mass/bulk per unit *and* per stack, stack
limit, exactly which stat USE moves and by how much, and where the thing turns
up. Plus a live capacity bar that goes rust at three quarters and warning red as
the hold closes out, and a two-tap JETTISON.

**Narrow viewports now stack instead of dropping.** The old rule hid both side
columns below 620px, which was survivable when the readout was a name and a mass
and is not now that it is the only place USE and JETTISON live. On a phone the
three columns become three rows: rail scrolling sideways, a three-row grid with
a pager, readout underneath.

Two layout faults worth recording, both invisible in code review and obvious in
a screenshot: a flex item defaults to `min-height:auto` and therefore refuses to
shrink, so the sub-rail ran off the bottom of the screen instead of scrolling
inside its column; and `justify-content:center` on an *overflowing* flex column
pushes the start of the column out past the scroll origin where it cannot be
scrolled back to — the category rail ended up behind the title plate and read as
simply missing.

### Verified

Bench opens from the prop; craft consumes and delivers; a forced spoil eats the
stock; a short hold refuses; recycle returns scrap and refuses food. All four
fittings run their stores down and refuse when empty or unpowered; the stores
round-trip through save. Search, all six sorts, the sub-rail, two-tap jettison
and USE all exercised against a 61-stack hold; layout measured at 1280×720,
820×480, 520×760 and 400×700 with no overflow off screen. Zero console errors
throughout.

### Next

NPC dialogue, the full AudioEngine sound set, mobile performance, the full
settings menu. `ObjectPool` is still unused and the DOM UI files still carry
inline hex instead of palette constants.

---

## Session 18k — 0.58.0 — There are people on the station now

Continuing the roadmap leftovers after the bench. NPC dialogue was the oldest
unchecked line in Phase 7 and the most conspicuous absence on a station deck:
eleven compartments, four counters, a taproom and a clinic, and nobody in any
of it. A station with nobody in it is a set.

### The bodies

`src/entities/Crew.js`. Six archetypes — chandler, armourer, broker, dockhand,
medic, officer — built on the **same part-mesh machinery as the boarders**, and
drawn through the same `interior.actors` hook, so a factor behind a counter is
lit by the compartment they are standing in and by your lamp exactly like the
bulkhead behind them. There is no NPC shader and no billboard sprite. The
textures are existing atlas layers: `suit_rack` is literally worn suit fabric
and `seat_leather` is worn leather, which is what dock crews and factors are
dressed in. No new texture was needed and none was added.

**They do not walk, on purpose.** A concourse is a room, not a corridor, and
pedestrians crossing an open room need avoidance, queueing and somewhere to be
going — three systems' work to produce motion the player reads as "background
people milling". A figure standing at a post that breathes, shifts its weight
and turns to look at you inside six metres reads as a person at a fraction of
the cost and never walks through a crate.

Ten of them, placed by the room dressers that place everything else on that
deck: dock crew on the arm, somebody loitering on the concourse, the chandler,
the armourer, the broker, a drinker in the taproom, the harbourmaster, the duty
medic, the bonded clerk and a customs inspector.

### The conversations

`src/gameplay/Dialogue.js`, `src/ui/DialogueUI.js`. Not a branching tree — a
tree is a writing project and a save-format problem. A flat topic list per
archetype, and **every line is generated from live state**:

- the harbour officer names bodies in the system you are *actually* in
- the chandler quotes the price bias your standing has *actually* earned, and
  will pick the best and worst thing in your *actual* hold
- the armourer reads whichever hull stat is *actually* lowest and counts your
  *actual* magazines
- the medic reads your *actual* injuries, radiation and fatigue
- the dockhand names an *actually* unfinished work order with its real progress

A topic that reads the world is worth ten that read a script, because it stays
true after the world moves.

Some topics do something: the writ moves Kestrel standing, the chandler and the
medic hand over supplies, the medic sells a dispensary refill that restocks the
ship's med bed, the armourer lends you the bench. Those are marked ONCE and
spent **per station**, so a favour asked is a favour gone and the next station
is worth walking around rather than farming this one.

Names are seeded off station id *and* post, so the harbourmaster at Meridian is
a specific person who is still there when you come back, is not the customs
inspector down the passage, and is not the harbourmaster at Halvane.

### Verified

Ten actors placed, all six meshes built at five parts each, nobody off the
floor, nobody outside their own zone, nobody standing inside furniture, ten
`TALK TO` prompts on the deck. All 22 topic slots across all six archetypes
return prose with no throw. Once-only topics fire once and then leave the list.
The writ moves standing 45 → 49. Names are stable across calls and differ
across stations and across posts. Leaving the station clears the roster and the
actor slot. 74 draw calls on the station deck with ten people on it, against a
200 budget. Zero console errors.

One boot fault worth recording: the dialogue block was first placed above
`factions` and `quests`, and reads both at construction — a `const` in the
temporal dead zone, so the whole game failed to boot with `Cannot access
'factions' before initialization`. Moved below its dependencies.

### Next

The full AudioEngine sound set, mobile performance, the full settings menu.
`ObjectPool` is still unused and the DOM UI files still carry inline hex.

---

## Session 18l — 0.59.0 — The ship has a voice for everything now

`AudioEngine.js — all sounds` has been an unchecked roadmap line since Phase 1.
Twelve sessions of features shipped past it, so a large amount of the game was
happening in silence.

### The bug at the bottom of it

**`playAirlock` did not exist.** `startEva` has been calling
`audio.playAirlock?.()` since 0.51.0 and the optional chaining swallowed it
without a word — so the single most dramatic thing you can do on foot, cycling
the outer door and stepping into vacuum, happened without a sound. It is now a
pump-down, a hiss whose band climbs as the compartment empties, and three bolts
arriving into the silence afterwards. The thinning is the sound: it is the only
moment in the game where the air is taken away from you.

That is what optional chaining costs. A `?.` on a method that was never written
is indistinguishable from a method that chose to be quiet.

### The four sounds `context/06` §3 specified and nobody wrote

| | |
|---|---|
| `playScannerPing` | 1200 Hz blip on the sweep arm crossing the top. Near the Hollow it drops an octave and gathers static — the scanner's unreliability was a visual-only lie until now, and the audible version lands before the screen does |
| `playTapeLogCrackle` | Telephone-band noise (300–3400 Hz) with a 0.7 Hz wow on the carrier. Runs *under a log while you read it* and stops when you close it — the point is that you are listening to something, not that a button made a noise |
| `playHullGroan` | 30–60 Hz sawtooth on a slow drift, doubled an octave up at a fifth of the gain because 30 Hz on a laptop speaker is silence. On a timer whose rate *and* gain scale with plating damage, so the hull figure is audible without looking at it. A boarded derelict is pinned near the top |
| `playHeartbeatSting` | Two low pulses, Hollow only, triple-gated: same or adjacent compartment, above half intensity, never inside eleven seconds. In the far case it never plays, which is what makes it mean something when it does |

### Fifteen more for systems that had none

Dock clamps · warp charge and jump · soft vs hard touchdown (the progression
system pays four times as much for the soft one, so the sound has to tell you
which you just did) · the bench crafting and spoiling · pickup, with a second
note a fifth up for a rare find · the till · a proficiency going up · a klaxon
that is deliberately *not* urgent-sounding, because an alarm that panics does
the panicking for you · **deflector hit vs deflector collapse**, which were the
same metallic knock until now — the one transition in a fight that has to be
unmistakable was audibly identical to the moment before it · dry fire ·
eat/drink/dose · and the suit's cold-gas jet as a *held* hiss, because outside
there is no hull to carry a low frequency into your feet.

### How they are wired

Almost all of it hangs off the event bus **in the engine's own constructor**,
the same way `Progression._listen` does. Every one of those events already
existed and was already being emitted for something else, so no other module
had to learn that audio exists, and a sound cannot play twice because there is
exactly one place that decides what an event sounds like. Only five needed a
direct call, because they read state rather than an edge: the scanner ping (the
sweep phase), the Hollow sting (proximity and intensity), the hull groan
(plating), the suit jet (held throttle) and the tape bed (a panel's lifetime).

### Verified

All 27 new calls exist and schedule audio nodes; `playAirlock` is a function
and schedules six. The tape bed starts two nodes and returns a working stop
function, and opening a log arms it while closing the journal clears it. The
scanner fires exactly three pings across five seconds at 1.6 s per revolution —
locked to the arm you are watching, not to a free-running timer, because a ping
out of phase with the sweep reads as a second broken device. The sting's gate
rejects far/cold/recent and passes only near+hot+due. Hull strain arms the
groan timer. Eleven events dispatched produced fourteen sounds — the three
extra were real cascades (docking completed a work order, the landing levelled
a skill), which is the wiring working rather than double-firing. Zero console
errors.

### Next

Mobile performance, the full settings menu, and the registry's march to 1000
items. `ObjectPool` is still imported nowhere and the DOM UI files still carry
inline hex instead of palette constants — both real debt, both still unpaid.

---

## Session 18m — 0.60.0 — Settings that reach the whole engine

`Full settings menu` was the next unchecked roadmap line. Seven options became
fourteen, in four contiguous sections — and the point of the pass is that every
new one has real engine support behind it rather than being a stored value
nobody reads.

| New option | What had to be built |
|---|---|
| **CRT STRENGTH** | A `u_crt` mix in the post shader, applied as ONE blend at the end rather than by scaling each term (they are tuned against each other, and dialling them independently would let a middle setting land somewhere none of them were designed for). The diegetic terminals carry the same figure, so turning the tube down does not leave the screens scanlined inside a clean frame. |
| **SHIP AMBIENCE / EFFECTS** | Two buses under the master. The bed — reactor hum, HVAC, hull groans, the drive, the suit jet — is continuous and is most of what makes the ship feel inhabited; the one-shots are information. One slider could express neither "atmosphere loud, clatter quiet" nor the reverse, and turning the master down far enough to live with the hum also hides the alarm. |
| **HEAD BOB** | An accessibility option, not a nicety. A 1.8 Hz vertical oscillation is one of the two reliable causes of motion sickness in a first-person game, and pillar 1 means there is no third-person view to escape into. |
| **AUTOSAVE** | 30 s / 60 s / 3 min / **OFF**. This is a survival game, and a player who wants a bad decision to actually cost them cannot have that while a background writer commits the consequences every minute. OFF leaves the diegetic terminal ritual, which makes saving *a thing you do* rather than removing it. |
| **THE HOLLOW** | Never / two systems / four / every one. `CLAUDE.md` has carried *"how often should the Hollow actually appear"* as an open question since session 0; the honest answer is that it depends on what the player came for, so it is a choice rather than a number somebody has to be right about. Nothing else changes — it still cannot be fought, still has no health, still resolves by leaving. Frequency is the only dial. |

The fields were also reordered so each section is contiguous. The old list ran
VIDEO / CONTROLS / VIDEO / AUDIO / VIDEO and emitted a fresh header every time
it changed, which with four more fields would have produced seven headers for
four sections.

### Two menu bugs the pass surfaced

**Notes were only rendered inside the `select` branch.** The `note` element was
built there, so the notes written for CRT STRENGTH, HEAD BOB, SHIP AMBIENCE and
EFFECTS were stored on the field, evaluated, and dropped on the floor. Hoisted
to all three field types.

**`_syncAll` painted before it synced.** It called every row's `paint()` — which
read `input.value` — and only *then* wrote the new value into the input. So
after RESET, or after anything else changed a setting from outside the panel,
every slider's thumb moved and every number beside it still showed the previous
figure. Caught by looking at a screenshot where CRT STRENGTH sat at the far left
reading 100%. Fixed at the root: `paint()` now reads the store and writes the
widget, so the readout and the control cannot disagree.

One GLSL trap worth recording: a backtick inside a comment in the fragment
shader's template literal terminates the literal. The file parsed as a
`SyntaxError` pointing at the shader text, twelve lines from the actual comment.

### Verified

14 fields, 4 sections, exactly 4 headers. Both buses exist and track their
sliders (0.20 / 0.90); the groan and the clank connect to ambience while the
door hiss and the till connect to effects. Head bob returns 0.040 on and 0.000
off. 45 s of ticks writes once at 30 s, none at 60 s, none at OFF. The Hollow
gate: OFF arms nothing, RARE arms only the two scripted systems, NORMAL arms
the authored four, OFTEN arms Vega Reach too. CRT strength reaches both the
post pass and the interior screens at 1 / 0.4 / 0, and the frame still renders
at each. All eight sliders agree with their readouts after an external change
and after RESET. All four range/toggle notes present. Zero console errors.

### Next

Mobile performance and the registry's march to 1000 items. `ObjectPool` is
still imported nowhere; the DOM UI files still carry inline hex.
