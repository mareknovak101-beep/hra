# 05 — UI, HUD & Menus

Palette and font rules are set in `context/01` §2 and §5 — this doc is layout and screen-by-screen behavior. Strict reminder up front: **the player HUD is amber-only.** Diegetic terminal screens (main menu, hacking, ship consoles) may use the muted terminal-green — but never mix the two on the same screen.

## 1. Helmet HUD layout (480×270 base)

```
Y=0  ┌───────────────────────────────────────────────────────────┐
     │              [COMPASS STRIP — top center]                  │
Y=20 │ ╔════════╗                    ╔══════════════╗             │
     │ ║SHIELD  ║                    ║ FUEL     87% ║             │
     │ ║ ██▓░░░ ║ 78%                ║ SPD 4.2 AU/h ║             │
Y=60 │ ╠════════╣                    ╠══════════════╣             │
     │ ║AMMO    ║                    ║ TEMP     98° ║             │
     │ ║ 24/60  ║                    ║ RAD      LOW ║             │
     │ ╠════════╣                    ╠══════════════╣             │
Y=100│ ║GRAVITY ║                    ║ O2 TANK  94% ║             │
     │ ║ 0.0g   ║                    ║ HULL INT 91% ║             │
     │ ╚════════╝                    ╚══════════════╝             │
     │                                                              │
     │                    [+] crosshair                            │
     │                                                              │
     │      [scanner ping indicator, bottom-left when active]      │
     │                                                              │
Y=230│ ╔══════════════════╗          ╔══════════════════╗          │
     │ ║ ████████████░░░░ ║          ║ ░░░░░░███████████║          │
     │ ║ HEALTH  89%       ║          ║ OXYGEN  76%      ║         │
Y=270└╚══════════════════╝════════════╚══════════════════╝════════┘
```

- Borders: 1px pixel lines, amber.
- Text: AMBER-9, uppercase.
- Bar fills: health left-to-right, oxygen right-to-left (deliberate visual distinction).
- Panel background: `#0f0f14` at ~75% opacity.
- Zero rounded corners, anywhere.
- Helmet glass effect: ~10% edge vignette, 3–4 faint static diagonal scratch lines (fixed random seed, not animated), very faint (5% opacity) horizontal scanline pass.

## 2. Alert states

| Condition | Visual response |
|---|---|
| Health < 25% | Health bar pulses, red tint flash on health panel every 2s |
| Oxygen < 20% | O2 bar pulses blue, "LOW O2" appears center-screen |
| Fuel < 10% | Fuel indicator text flashes on/off every 1s |
| Hull < 30% | "HULL CRITICAL" text, amber border flashes |
| Radiation high | Red tint overlay scales with radiation level |
| Helmet breach | Cracked-glass overlay added to helmet edges |
| Enemy lock-on | Red bracket around crosshair |
| **Scanner near the Hollow** *(new)* | Scanner display degrades to static; no explicit "ENEMY DETECTED" text — the ambiguity is the point (`context/03` §6, `context/04` §5) |

## 3. Diegetic terminal chrome (shared, `TerminalUI.js`)

Used by the main menu, the hacking minigame, and any in-fiction console screen: scanline dither overlay, cursor blink, boot-in flicker (screen "warms up" over ~0.3s rather than appearing instantly), TERM-MONO-7 font. This is a single shared component — build it once, reuse everywhere a screen appears, rather than re-implementing scanlines per screen.

## 4. Main menu

Reference: the uploaded "window-framed galaxy" concept art. Reusable idea is the **framing device** — the menu is composed as a view *through* the ship's own window or a console screen, not a flat background image with buttons on top. Title card sits inside that frame. Buttons use the diegetic terminal chrome (§3), not the player HUD style — this is the ship's system talking to you, not your own helmet display. Ignore the source image's literal title text and saturated palette; recompose the same "seen through glass" idea using this project's actual palette (`context/01` §2) and the ship's actual name.

## 5. Character / pilot creation

Reference: the uploaded pilot-creation layout (portrait left, fields right, bottom nav). Keep the *layout* — portrait pane, grouped attribute fields, bottom nav bar — and rebuild the portrait rendering entirely: a procedurally-composited pixel portrait from layered part sprites (base head shape + hair + features + limited palette swatches), lit flat and harsh like a company ID badge photo, not the glossy semi-realistic render in the source. This is also a legitimately simpler build than a fully painted portrait system, so it's a win on both style and scope.

## 6. Inventory screen

Reference: the uploaded painterly inventory grid. Keep the *composition* — large central item grid, side info panel, bottom hotbar — and discard the palette entirely: recolor to the amber-monochrome HUD system (§1), frame the whole screen as if displayed on a ship console rather than a glossy game-UI panel, and simplify icon rendering to the isometric single-object convention in `context/01` §8. The source image's saturated multi-hue icons and gloss are the opposite of pillar 3 (`CLAUDE.md`) — don't let them anchor the target.

## 7. Touch controls

```
LEFT HALF: [MOVE] joystick        RIGHT HALF: [LOOK] joystick
Bottom strip: [INTERACT:E] [JUMP] [SPRINT] [CROUCH] [INVENTORY:I] [MAP:M]
Flight-mode additions (right side): [FIRE] [BOOST] [ROLL-L] [ROLL-R] [WARP] [WEAPON-SELECT]
```

```js
class VirtualJoystick {
  constructor(side) {
    this.baseRadius = 65;      // px — touch area
    this.knobRadius = 28;      // px — inner knob
    this.deadZone = 0.12;      // 12% dead zone
    this.color = '#b08040';    // amber
    this.opacity_idle = 0.35;
    this.opacity_active = 0.80;
  }
  getInput() { /* returns normalized [-1..1, -1..1] */ }
}
```

Touch targets minimum 44×44px, always (quality checklist, `context/07`).
