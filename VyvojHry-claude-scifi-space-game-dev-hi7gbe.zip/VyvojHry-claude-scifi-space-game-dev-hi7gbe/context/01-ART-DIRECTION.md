# 01 — Art Direction

This is the longest document in the bundle because it's the one thing the whole project actually hinges on. Everything else — the rooms, the systems, the HUD — is in service of one feeling: a ship that was built cheap, has been worked hard for years, and is currently a little too quiet. If a texture, prop, or screen doesn't contribute to that, redesign it.

## 1. The reference, precisely

"Inspired by *Alien* (1979) and *Alien: Isolation*" doesn't mean copying either — it means building original material from the same design instincts:

- **Used future, not clean future.** Nothing here was designed to look good in a showroom. It was designed to be cheap, serviceable, and is now worn from a decade of hands touching the same six switches. Ron Cobb's Nostromo is a space *tugboat*, not a space *yacht* — industrial, greasy, function over form.
- **Cassette-futurism.** Physical toggle switches, chunky buttons in grid arrays, CRT monitors with visible scanlines, dot-matrix printouts, analog dials with needles, not one flat touchscreen anywhere. Technology reads as 1970s-panel-hardware wearing a sci-fi coat, not as a smartphone.
- **Light is scarce and directional.** Rooms are dim by default; the player's own light source (helmet lamp, terminal glow, a single flickering tube) is what reveals detail. Ambient light stays low enough that corners are genuinely dark — see `context/02` LightSystem spec.
- **Everything has a maker's mark.** Stenciled corporate branding, hand-written labels over the stencils, hazard stripes, serial numbers, a repair patch that doesn't quite match. The ship has a paper trail.
- **Dread is a texture choice, not just a game-design choice.** A rust streak that runs toward a door handle, a scorch mark near a vent, a locker that's slightly ajar — these do narrative work before the player reads a single log entry.

We do **not** reproduce any proprietary names, logos, or creature silhouettes from either property. `context/03` has the original names (ship, company, factions, the rare threat) — use those, always.

## 2. Palette — closed system, extend only here

Every texture draws from these families. If a new one is genuinely needed, add it to this table first — don't invent a hex value inline in a shader and move on.

### Interior / industrial surfaces
```
Dark military metal:  #252d25  #2e3a2e  #3a4a3a
Rust and wear:         #7a3a10  #a04e1a  #c86020
Amber machinery:       #8a5a10  #b07020  #d09030
Panel steel:           #303040  #404055  #505068
Floor grime:           #1a1a14  #252518  #303025
Warning red:           #8a1515  #aa2020  #cc3030
Shadow black:          #0a0a0f  #050508  #000003
```

### Terminal phosphor green — NEW, diegetic screens only
```
Screen background:    #0d1a12  #16241a
Mid glow:             #2d4a35  #3a5c42
Bright text:          #4a7a52  #5a9060  ← brightness ceiling; never brighter, never fully saturated
```
This is the MU-TH-UR-adjacent mainframe-green mood, deliberately desaturated so it reads as an old phosphor tube, not a neon sign. It appears **only** on physical screens inside the fiction (Computer Core, some ship consoles) — never on the player's own HUD, which stays amber. Mixing the two anywhere is the single easiest way to break the palette discipline; watch for it in review.

### HUD — vintage only, zero exceptions
```
Primary amber text:   #b08040  #c09050  #d0a060
Secondary info:       #8a6030  #704a20
Alert red:            #993020  #bb4030
Panel background:     #0f0f14  #14141a
HUD borders:          #403020  #503828
Oxygen bar fill:      #205080 → #4080c0  (desaturated blue, right-to-left fill)
Health bar fill:      #7a1515 → #aa2525  (dark red, left-to-right fill)
```
**Banned from HUD, absolutely:** bright/neon green (`#00ff00` and neighbors), neon cyan, neon anything. If it would look at home on a rave flyer, it's wrong here — including the terminal phosphor green above, which stays off the player's HUD.

### Bio-unknown accent — the Hollow only
```
Wet-shadow black:     #0a0508
Sickly violet-grey:   #3a2f3a  #4f3f4a
```
Used exclusively for organic residue, damage, and environmental storytelling tied to the Hollow (`context/03`, `context/04`). Never used for anything mechanical — this keeps it legible as "wrong" the instant the player sees it.

### Space / exterior
```
Deep space:            #000008  #010110
Starlight (points):    #e8e8f0  #9696a5  #d0b48c   ← white/cool/warm star points + sun-core white; #e8e8f0 shared with the Drift's fractal detailing (context/03 §5)
Sun surface:           #d09030 → core #e8e8f0, rim #7a2a10 (amber-machinery + lava families, no new hues)
Nebula tones:          #200a30  #0a1530  #30200a
Planet (rocky):        #5a4530  #6a5540  #4a3a28
Planet (ice):          #3a4a5a  #4a5a6a  #5a6a7a
Planet (lava):         #5a1a08  #7a2a10  #9a3a18
Planet (jungle):       #1a3a1a  #2a4a2a  #1a2a18
```

### Corporate stencil (Kestrel Extraction & Salvage Co.)
Reuses **amber machinery** + **shadow black** — don't add a new hue family for branding. Stencils are always slightly imprecise (hand-masked spray paint, not vector-perfect), partially worn, sometimes half-covered by a later hand-written note.

## 3. Pixel art rules (non-negotiable)

1. No flat single-color surfaces, anywhere. Minimum 3–4 color variation per surface.
2. Pixel block size: 4×4 to 8×8 logical pixels for texture detail, measured on the **480×270 design grid**, not on the scene buffer.

   The scene buffer is a preset (`RENDER_SCALES` in `src/core/Constants.js`): 480×270, 960×540 (default) or 1920×1080. Changed at the owner's explicit direction in session 16u, after four requests for finer pixels. The reasoning, so it does not get re-litigated:

   - **Texture resolution was never the lever.** At 480×270 upscaled to a 1080p display, one rendered pixel is a 4×4 block of screen pixels, and that block is what reads as chunky. Every texture in the game is sampled *down* into those blocks, so no amount of texel density can make the block smaller — raising interior textures 128→256 at 480×270 was measured to cost 2× the boot time for zero visible gain.
   - **`RENDER.TEXTURE_SIZE` therefore follows the preset.** 128 at CLASSIC, 256 above it. A 2m wall three metres out spans ~150 buffer px at 480 wide (128 texels ≈ 1:1) and ~300 px at 960 (so 256 is what restores 1:1).
   - **Only whole multiples.** 1440×810 is deliberately absent from the preset list: it upscales to 1080p at 1.33×, and a fractional nearest-neighbour upscale drops pixels unevenly, staggering straight lines. A resolution option whose entire purpose is cleaner pixels must not introduce shimmer.
   - **The 2D chrome does not scale.** HUD, crosshair, notifications and the scanner are authored as literal pixel rects and 6px bitmap glyphs on `RENDER.UI_WIDTH/UI_HEIGHT` (fixed 480×270). The hud shader's `u_resolution` carries the UI size, so one UI pixel maps to `RENDER.SCALE` scene pixels and the chrome keeps its apparent size. The CRT post-process pattern pitch is pinned the same way — tied to the real buffer instead, 540 scanlines on a 1080-line buffer would be invisible and the whole effect would silently vanish at the high presets.
   - **What genuinely gains:** all 3D geometry and texture detail, the helmet-glass scratches (generated at scene resolution, so they thin to a true hairline), and the sub-pixel body cull in `SpaceRenderer` (derived from the live buffer height, so finer presets resolve smaller worlds).
3. Shading: 2-bit and 4-bit **ordered dithering** only. No smooth gradients, ever. Reference 4×4 Bayer matrix (standard, reuse this exact pattern for threshold ordering):
   ```
    0  8  2 10
   12  4 14  6
    3 11  1  9
   15  7 13  5
   ```
4. Depth via darker edges / lighter centers / darkened corners (baked pseudo-AO) — never a real gradient.
5. Every prop texture needs 2–3 of: cables, serial numbers, warning labels, wear marks, bolt heads, weld seams, **rust that runs downward from its source** (gravity matters — rust below a bolt, not around it symmetrically), moisture stains, burn marks.
6. Nearest-neighbor upscale only. Antialiasing disabled everywhere, always.

## 4. Material dithering language

Give each material family a distinct *pattern* of dithering, not just a different color — this is what makes metal read as metal and cloth read as cloth at pixel scale.

| Material | Dither pattern | Notes |
|---|---|---|
| Brushed/painted metal | Horizontal banding, 2px grain | Add occasional 1px diagonal scratch, lighter than base |
| Rusted metal | Irregular blotch (not banded), warm-to-dark radial | Streaks trail *downward* from the source |
| Rubber / cable insulation | Smooth, low-contrast dither | Single 1px highlight line along the top edge |
| Glass / CRT screen | Checkerboard scanline dither | No blur/bloom — brighter core pixels only, sharp-edged |
| Cloth (suits, seat) | Cross-hatch dither | 1px darker rows at seams |
| Organic / Hollow residue | Irregular, high-contrast mottling | Single-pixel wet-highlight dots, never symmetric |

## 5. Typography

Two bitmap font families — do not blend them:

- **AMBER-9** — player HUD and suit displays. Blocky slab, uppercase only, ~5×7 to 6×8 grid, corners softened by shaving 1–2 corner pixels. Mood reference: Eurostile Bold Extended / Microgramma-family geometric slabs (naming these as a type-mood reference only, not asset reuse).
- **TERM-MONO-7** — diegetic ship terminals (Computer Core, consoles, hacking UI). Strict monospace, hard corners, dot-matrix feel. Mood reference: OCR-B and early dot-matrix printer output. Supports a "damaged" variant: occasional single-character jitter/flicker for broken terminals.

## 6. Room-by-room concept art reference

These are read directly from the uploaded concept art. Use them as the anchor for procedural texture generation in each room — match the *density* of detail and the *lighting mood*, not a literal pixel-for-pixel copy.

**Cargo Bay** — industrial green cross-braced metal lattice framework; rust-orange glow at floor seams and wall joints; crate variety (plain gray tech crates with small LCD status panels, brown radiation-warning crates with hazard striping, cryo-blue crates with larger temperature readouts); overhead crane/gantry track with hook hardware; heavily rusted floor plates; warm amber tube lighting recessed into the gantry structure. Feel: claustrophobic warehouse, well-used, slightly chaotic.

**Cockpit** — deeply cracked worn brown leather pilot chair as the visual anchor; side consoles with amber/orange button grids, toggle switches, small CRTs; forward window shows starfield with CRT-overlay telemetry text; a secondary screen shows a galaxy/nebula map in warm orange; overhead rows of physical toggle switches and indicator lights; left-side joystick and radar screen. Warm overhead fluorescent + screen glow + indicator LEDs.

**Crew Quarters / Bunks** — bunk beds with worn olive mattresses; tall metal lockers, some dented; a green-CRT terminal with physical keyboard on a desk; a sink area; tools/knives mounted on a wall rack above the desk; heavily tiled walls with rust bleeding through the grout lines. Warm, cramped, personal — this is where found objects (a photo, a half-written note) do the most narrative work.

**Airlock / EVA** — two suits hung on wall mounts flanking a large circular vault-style inner door stenciled "EXTERNAL VACUUM"; hazard-striped floor; visible overhead pipe and cable runs; a diegetic teal-lit status console beside the door; a first-aid kit on the floor, slightly out of place. This room should feel like the ship's most exposed point — the one door that leads to nothing breathable.

**Research Lab** *(new room)* — a wall of CRT diagnostic monitors and analog gauge equipment; a fume-hood-style containment cabinet with a teal glow inside; a bookshelf with worn hardbound volumes; a glowing furnace/reactor viewport; a cluttered workbench (microscope, sample dishes, patch cables); rust bleeding through tiled walls. This is the room that should feel most like *before* — evidence of ordinary, unfinished work.

**Computer Core** *(new room)* — the dedicated mainframe room; this is where the terminal-phosphor-green palette gets its best showcase. Large boxy terminal housings, visible cooling vents, a bank of smaller data-readout screens, physical patch panels, cable bundles hanging loose. This is also where the ship's own schematic (see §7) makes sense as an in-room prop — a printed cutaway diagram taped or pinned near the main console.

## 7. The ship-schematic poster (from the cruciform blueprint concept art)

One of the reference images is a sepia, vignette-toned technical cutaway of the ship in a cruciform layout, labeled in blocky stenciled text — a "poster in a technical manual" aesthetic. Recreate this *device*, not its literal layout: an in-fiction printed schematic of the **HSV Aethon's actual room layout** (per `context/03`), rendered in the same aged-paper, hand-labeled style, and place a copy of it as a physical prop somewhere sensible (Computer Core or Captain's Quarters). It's a nice piece of environmental storytelling and doubles as a diegetic way to show the player the ship map without a modern minimap UI.

## 8. Item icon convention

Two reference icons anchor the convention for all ~1000 planned items: isometric 3/4 view, hard near-black outline, exactly one lit face and one shadow face (not full ambient lighting), flat neutral gray background per icon, material read through the dither pattern from §4 rather than through color alone (a raw ore chunk uses blotch-dither rock texture under a metallic-yellow tint; a sealed canister uses the glass/CRT checkerboard-dither pattern on its window with a matte-metal cross-hatch on its end caps). Every item icon in the game should read clearly as a *physical object sitting on a table*, not a flat glyph.

## 9. Planet and star rendering reference

Four planetary bodies and one star were provided as direct references for `PlanetRenderer.js` / `Star.js`:

- **Rocky/oceanic world** — visible patchy dither texture at the terminator, continents rendered as blotchy tan-on-teal masses (not clean vector coastlines), consistent single light-source direction, soft rim glow at the limb.
- **Ringed gas giant (×2 references)** — horizontal banding dither on the body, ring system rendered as a flat annulus with density variation (denser bands read darker, gaps read as thin dark lines), ring shadow cast across the planet where the ring occludes the light source.
- **G-type star** — granulated, mottled surface dither (not a flat disc), soft multi-layer corona falloff into the surrounding starfield, warm yellow-orange-white core fading to red at the rim.
- **Cratered moon** — hard-edged circular crater stamps at varying sizes with a consistent light/shadow split per crater, sharp terminator line, warm sepia-toned lighting overall.

Match the *dither density and directional lighting consistency* shown across these — that consistency is what sells "pixel sphere," more than any individual crater or continent shape.

## 10. Concept art index — full mapping

| # | What it shows | Use it for |
|---|---|---|
| 1 | Oceanic/rocky world, teal ocean + tan continents, dark navy space | `PlanetRenderer.js` biome dither reference (§9) |
| 2 | Warm tan ringed gas giant, 3/4 angle | Ring-shadow + banding reference (§9) |
| 3 | G-type star, granulated orange-yellow plasma surface | `Star.js` corona/surface reference — this is Sol Prime's star (§9) |
| 4 | Cratered moon, sepia lighting, hard terminator | `Moon.js` crater-stamp reference (§9) |
| 5 | Cruciform ship deck blueprint, sepia vintage poster | In-fiction schematic poster device (§7); source of the Research Lab / Computer Core room additions |
| 6 | Airlock, suits on wall, hazard floor stripes, teal console | `Airlock.js` primary reference (§6) |
| 7 | Crew bunk room, green CRT terminal, tiled rust walls | `CrewBunks.js` primary reference (§6) |
| 8 | Cargo bay, green lattice, crane, varied crates | `CargoBay.js` primary reference (§6) |
| 9 | Research lab, CRT banks, furnace viewport, bookshelf | `ResearchLab.js` primary reference (§6) |
| 10 | Cockpit, cracked leather seat, green console, nebula screen | `Cockpit.js` primary reference (§6) |
| 11 | Small ship sprite near a glowing ringed body, wide shot | **Cinematic-only** exterior reference — warp sequence / main-menu backdrop use only, never the live gameplay camera (see camera rule, `CLAUDE.md`) |
| 12 | Painterly inventory grid UI | Layout/composition reference **only** — recolor entirely to strict amber-monochrome per `context/05`; the gloss and multi-hue icons in the source don't belong in this game |
| 13 | "Star Dust Voyager" main menu, window-framed galaxy view | Main-menu backdrop composition reference — the "seen-through-glass" framing device is the reusable idea, not the title text or palette |
| 14 | Character-creation portrait screen | Pilot-creation layout reference — restyle the portrait itself to a limited-palette, flat-lit "ID badge" pixel style, not the glossy semi-realistic render shown |
| 15 | Reddish ringed gas giant on starfield | Secondary planet/ring reference, alternate palette (§9) |
| 16 | Raw gold ore, isometric icon | Item-icon convention anchor — mineral/ore category (§8) |
| 17 | Green-glass canister/fuel-cell, isometric icon | Item-icon convention anchor — sealed consumable/canister category (§8) |

Images 12–14 are the ones most worth deviating from stylistically: they're useful for *composition* (where things sit on screen) but their actual rendering — painterly shading, saturated multi-hue palettes, soft gradients — is the opposite of pillar 3. Don't let their polish anchor the visual target; the pixel-truth rules in §3 win every time.
