# 04 — Gameplay Systems

## 1. Player vital stats

| Stat | Max | Depletion | Critical threshold | Replenish |
|---|---|---|---|---|
| Health | 100 | Combat/environmental damage | <25: HUD alert | Medical items, med bed |
| Oxygen | 100 | 1/min vacuum, 0.2/min with breach | <20: urgent alert | O2 station, tank items |
| Hunger | 100 | 2/hour game time | <25: performance penalty | Food items |
| Thirst | 100 | 4/hour game time | <20: health drain | Water/drink items |
| Fatigue | 100 | 5/hour activity | <20: impaired input | Bunk sleep (time-skip) |
| Radiation | 0→100 | Environmental accumulation | >60: health damage | Med items, decon station |
| Temperature | 36.6°C | Drops in cold, EVA | <32°C: damage | Heated areas, suit heating |

## 2. Ship vital systems

| System | Range | Effect when low | Repair/restore |
|---|---|---|---|
| Hull Integrity | 0–100% | <30%: breach risk, atmosphere leak | Metal plates + welder |
| Shield | 0–100% | Regens after 8s undamaged | Shield cell items |
| Fuel (sublight) | 0–1000 | Ship stops, drifts | Fuel stations, fuel cells |
| Warp Fuel | 0–100 | No warp travel | Warp fuel (rare, bought/mined) |
| Power | 0–200% | Overload: shutdowns | Manage allocation panel |
| Life Support | 0–100% | Atmosphere drains shipwide | Repair from Workshop |
| Weapons Charge | 0–100% | Lasers drain, regen | Power cells, capacitor items |

## 3. Item schema

```js
{
  id: 'fuel_cell_standard',
  name: 'Standard Fuel Cell',
  category: 'consumable',
  subCategory: 'fuel',
  weight: 2.4,          // kg
  volume: 0.8,           // inventory slots (1.0 = 1 slot)
  value: 85,              // credits (base trade value)
  stackable: true,
  maxStack: 20,
  description: 'Standard deuterium fuel cell. Powers sub-light drive systems.',
  onUse: 'refuel_ship',
  effect: { fuel: +50 },
  texture: 'item_fuel_cell',
  rarity: 'common',       // common, uncommon, rare, unique
  found: ['stations', 'cargo', 'trade', 'derelict'],
}
```

Inventory: 120 slots, categorized, stacking, weight-limited (`Inventory.js`).

## 4. Crafting

Recipes are station-gated (Workshop bench, and a small subset at Research Lab for bio/chemical items). Recipe lookup → ingredient check → consume ingredients → produce output item. Nothing here needs to be more complex than that for v1 — resist the urge to add a mini-game to ordinary crafting; save the mini-game budget for hacking (§7), where it actually earns its keep.

## 5. The proximity scanner

The closest thing this game has to a "motion tracker," built as an original handheld device (`ProximityScanner.js`):

- Pings on a fixed interval (not continuous), showing blips on a small radial CRT display in terminal-phosphor-green (`context/01` §2).
- Precision trade-off is the whole point: holding it up to read blip position/distance means looking down at the device, not at the corridor ahead. This has to cost something — don't let the player check it "for free" with a HUD icon that requires no attention shift.
- Near the Hollow specifically, the display degrades to static instead of showing a clean position (`context/03` §6) — a diegetic reason for the player to lose information exactly when it matters, rather than a difficulty-slider fudge.
- Battery-limited, rechargeable at any powered console.

## 6. Hiding & noise

- Footsteps generate noise scaled by surface (`context/06`) and movement state (crouch < walk < sprint).
- Lockers, vents, and a crouch-in-shadow state are all valid hiding responses. Hiding should meaningfully break line-of-sight and muffle noise, not just be a cosmetic animation.
- This system matters everywhere low-level tension is wanted (avoiding a Keth patrol, avoiding a Drift drone), not just for Hollow encounters — build it as a general system, not a one-off bolted onto a single enemy type.

## 7. Terminal hacking

A simple, honestly-buildable-in-vanilla-JS minigame (`HackingMinigame.js`), used at `HackingTerminal.js` props (mainly Computer Core, occasionally a locked derelict door): a timed sequence-matching or signal-routing puzzle rendered in the TERM-MONO-7 font on a CRT-scanline background. Keep the mechanic itself simple — the atmosphere is doing the work, not puzzle complexity. Failure states should have a cost (alert noise, lockout timer) but not be punishing enough to make players avoid terminals entirely, since terminals are also where logs live (§9).

## 8. The Hollow — encounter design

Full fiction in `context/03` §6. The mechanical rule that matters most: **this is never a fight.** `HollowEntity.js` should not expose a health bar or a "defeat" state through combat. The loop is:

1. Player enters a lair (a specific, hand-placed derelict/wing — not a random spawn table).
2. Ambient and scanner cues escalate (`context/06`).
3. Detection is possible but survivable — evade, hide (§6), or use a one-time distraction item (a noisemaker consumable is enough; don't over-engineer a toolkit for this).
4. The encounter resolves by the player leaving the lair (with or without whatever they came for), not by killing anything.

`TensionDirector.js` owns pacing for this: it should be the single place that decides when the Hollow is "active" in a given lair, rather than scattering that logic across `EntityManager.js` and individual room scripts. Keep it modular enough that intensity is a tunable knob, not a rewrite — the open question in `CLAUDE.md` about how often this should trigger is exactly what this file should make easy to answer later.

## 9. Logs, journal, and environmental storytelling

`LoreEntries.js` holds both audio-log and text-log content; `JournalUI.js` is where the player reviews anything they've found. Logs are the primary tool for backstory (the Company's contract terms, what happened to the rest of the crew, what earlier logs say about the Hollow before the player has met it) — write them short, in-voice, and inconsistent with each other where that inconsistency is realistic (people don't agree on what they saw).

## 10. Saving

Diegetic manual save at a `SaveTerminal` prop (Workshop, Computer Core — `context/03` §2): interact → short animation → mechanical "chunk" sound (`context/06`) → "PROGRESS RECORDED" in TERM-MONO-7. A quiet background autosave runs independently as a safety net (`context/02` §9) — keep both; the ritual is for mood, the autosave is for not losing an hour of play to a browser crash.
