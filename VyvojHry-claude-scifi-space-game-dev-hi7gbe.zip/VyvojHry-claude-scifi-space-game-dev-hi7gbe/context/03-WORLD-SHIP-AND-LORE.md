# 03 — World, Ship & Lore

## 1. The ship

**HSV Aethon** — Heavy Survey Vessel, 85m length, 22m beam. Rated crew: 6. Currently aboard: the player, alone.

That gap is deliberate. Four unused bunks, a locker with someone else's name still taped to it, a second toothbrush in a rack built for six — this is cheaper and more effective atmosphere than any scripted scare, and it costs nothing to build. Don't "fix" it by adding NPC crew without checking in — see the open question in `CLAUDE.md`.

## 2. Deck plan

Thirteen rooms plus the airlock sub-room, arranged fore-to-aft along a spine with branches — same corridor-typing discipline as the v2 prompt (`context/02` §5), with two new rooms (Research Lab, Computer Core) added because a *survey* vessel plausibly has both, and because the uploaded cruciform ship-schematic concept art showed exactly this pairing.

```
FORE ─────────────────────────────────────────────────────── AFT

 ┌─────────────────────────┐
 │  COCKPIT / BRIDGE        │  Room 01   5.0W × 4.5D × 2.8H
 └──────────┬───────────────┘
            │ CORRIDOR A (barrel arch, 2.0W)
 ┌──────────┴───────────────┐
 │ CAPT ┊ CREW BUNKS         │  Rooms 02, 03
 │ QTRS ┊ (4 bunks)          │  3.0W+5.0W × 5.0D
 └─────────┬─────────────────┘
           │ CORRIDOR B (low industrial, 2.5W)
 ┌─────────┴─────────────────┐
 │ MED BAY ┊ GALLEY/MESS      │  Rooms 04, 05
 ├─────────┼──────────────────┤
 │ BATHRM  ┊ STORAGE           │  Rooms 06, 07
 └─────────┴──────┬────────────┘
                   │ CORRIDOR C (wide bay, 4.0W)
      ┌────────────┴─────────────┐
      │ RESEARCH LAB ┊ COMPUTER  │  Rooms 08, 09   NEW
      │              ┊ CORE      │  4.0W+4.0W × 4.5D
      └────────────┬──────────────┘
                    │ CORRIDOR C continues (wide, vented, 4.0W)
      ┌─────────────┴─────────────────────┐
      │ CARGO BAY                          │  Room 10 (+10a Airlock)
      │ [crane] [shelves] [crates]         │  14.0W × 20.0D × 8.0H
      └─────────────┬───────────────────────┘
                     │ CORRIDOR D (maintenance, 1.2W — tight)
      ┌──────────────┴──────────────────┐
      │ WORKSHOP ┊ REACTOR ROOM          │  Rooms 11, 12
      │ [bench]  ┊ [core column]         │  5.0W+7.0W × 6.0D
      └───────────────┬───────────────────┘
                       │ CORRIDOR E (engine bay, 3.0W)
      ┌────────────────┴──────────────────┐
      │ ENGINE ROOM                        │  Room 13
      │ [2× main drives] [4 thrusters]     │  12.0W × 8.0D × 5.0H
      └─────────────────────────────────────┘
```

### Interactive objects per room (minimum)

| Room | Minimum interactive objects |
|---|---|
| Cockpit | Pilot seat (flight trigger), nav console, comms station, 2× status screens |
| Captain's Quarters / Crew Bunks | 4 bunks (rest trigger), personal lockers, at least one *absent-crew* detail object |
| Med Bay | Medical bed (heal trigger), supply cabinet, diagnostic terminal |
| Galley/Mess | Food storage cabinet, meal prep station, water recycler, table (sit trigger) |
| Bathroom / Storage | Functional fixtures; shelved general storage |
| **Research Lab** *(new)* | Specimen analyzer console, sample fridge/cold-storage, bio-scanner station, bookshelf (log source) |
| **Computer Core** *(new)* | Mainframe hacking terminal, data archive shelf, security-feed console, ship schematic poster (`context/01` §7) |
| Cargo Bay (+ Airlock) | 12 cargo crates (varied), overhead crane (operable), 2 wall panels, airlock door, 2 EVA suit racks |
| Workshop | Crafting bench (crafting UI trigger), tool rack, parts storage |
| Reactor Room | Reactor core (inspect/manage), 4 power conduit panels, emergency shutdown |
| Engine Room | 2 engine inspect points, fuel port connection, thruster status panels |

Save Terminals (`context/04`) live in Workshop and Computer Core — two locations, deliberately not adjacent, so a save is never zero-effort from anywhere on the ship.

## 3. The Company

**Kestrel Extraction & Salvage Co.** — "the Company" in crew shorthand. A cold, contract-driven operator that leases survey vessels like the Aethon out for deep-space extraction work and treats the ship, its cargo, and technically its crew as line items. Every stencil, crate label, uniform patch, and terminal boot screen on the ship carries its mark: a plain sans-serif wordmark, always slightly worn, sometimes half-covered by a hand-written note that says something more honest than the branding does. This is original IP — do not substitute a real-world or franchise corporate identity.

## 4. The star systems

Two tiers. **The commissioned survey route** (systems 1–5) is what Kestrel is paying for; it's reused from the v2 prompt, tone deepened slightly toward dread where it costs nothing narratively. **The off-route spurs** (systems 6–10) were added in session 16n so the chart reads as a region rather than a corridor — same lane network, nobody's contract. Each spur is built around body types the route never shows, and no spur is required to finish the story.

### The commissioned survey route

**System 1 — Sol Prime** *(starting system)*. G-type yellow dwarf, 8 planets. Habitable: Planet 3 "Aethon" — human colony, ~2M population (the ship shares its name — not a coincidence worth explaining to the player). Stations: Meridian Station, Outer Reach Dockyard. Tutorial zone, mostly safe — but one small derelict shuttle wreck near Meridian is worth placing early, purely for tone: nothing dangerous happens there, it's just the player's first "someone was here and now isn't." Threats: occasional pirates, minor gangs, low-level alien scouts. Resources: common ores, basic organics, abundant fuel.

**System 2 — Vega Reach**. Home ground of the Keth Armada (§5). B-type hot blue star, 5 planets (3 scorched/lava, 1 electrical-storm gas giant, 1 outer ice world). No habitable worlds — suits required everywhere. Station: Vega Extraction Platform. First serious danger zone; requires upgrades from Sol Prime before it's survivable. Resources: rare heavy metals, exotic crystals, volatile gases.

**System 3 — Redfall**. Home of the Vrenn (§5). M-type red dwarf, 7 planets (2 habitable: "Verdane," a lush alien jungle world, and "Kerath," a Vrenn city-world). Station: Vrenn Trade Hub at Kerath, if reputation is neutral or better. First-contact zone — diplomacy or conflict branch. Resources: rare organics, bio-materials, alien trade goods.

**System 4 — Twin Suns**. Binary star (K orange + M red, close pair), 6 planets in complex L-shaped orbits. No habitable worlds — all tidally stressed or irradiated. An abandoned ancient station sits at the L4 point; ruins on the innermost moon are a major lore-discovery zone. Threats: the Drift (§5), and — rarely — the Hollow (§6). Resources: ancient artifact fragments, uncommon ores, ancient tech salvage.

**System 5 — The Pale** *(end-game)*. Very dim K-subdwarf, barely visible. 4 frozen worlds + 1 rogue ice body. No habitable worlds, extreme cold, no atmosphere. THE ARCHIVE — a 50km ancient alien megastructure — is the narrative climax. Threats: the Drift at their most dangerous, and the Hollow's most deliberate encounters. Resources: the rarest materials in the game, ancient weapons, final tech.

### The off-route spurs

Charted, reachable, and nobody's contract. These exist to give the chart breadth and to show off body types the route has no reason to contain — a greenhouse world, a stripped planetary core, a carbon planet, a ring system, a dead star. Two of them (Odessa Chain, Amber Well) are deliberately NOT patrolled: a spur that shoots at you on arrival is a spur nobody visits twice.

**System 6 — Odessa Chain**. F-type, MEDIUM. Kestrel's other lane: metal-rich, badly regulated, full of people who left Sol Prime for a reason. A toxic greenhouse world (Odessa I), two stripped cores worked open by mining rigs (The Anvil, Lower Anvil), a salt-flat desert under independent claim (Brine), the chain's landmark ringed gas giant (Odessa Major), and a tundra world breathable through a mask (Harrow). The richest asteroid belt on the chart — 22 rocks, including nickel-iron. Station: Odessa Transfer (cheap fuel, optimistic paperwork). Derelict: a loaded ore hauler nobody will board twice.

**System 7 — Amber Well**. Red giant, HIGH. A star that already ate its inner worlds. The shredded inner system is a 26-rock belt at 0.9 AU — far closer in than a belt has any business being, which is the tell. Bodies: the bare core of a swallowed world (The Remnant), a lava world resurfaced by the expansion, a tundra world that has only had a habitable zone for ninety thousand years (Late Spring), a meltwater ocean where something is dividing (Thaw), and a ringed ice giant wearing new debris. Station: Well Watch, a company observation post on a skeleton rotation.

**System 8 — Cold Harbour**. Brown dwarf, HIGH. A star that never lit — everything here is under a dull maroon glow, and it has **no belt**, because a failed star's disc never had the mass to leave one. That emptiness is the point: everything you see out here was *put* here. Bodies: nitrogen-ice worlds, a ringed ice giant (The Lantern) with a volcanic sulphur moon (Kettle) inside its tidal grip, and a carbon world with an albedo near zero (Soot). A Drift **breaking yard** — hulls parked in rows, by size, with fresh sweep marks. Six slow drones; the Hollow is armed here.

**System 9 — Thresher**. O-type blue supergiant, EXTREME. A star burning through its own lifetime, and a Keth forward yard. Nothing icy survives: no belt, no comets. Two carbon worlds (graphite, diamond, tar seas gone hard), a stripped core mirror-bright on the sunward face (Shear), a lava world that has never been allowed to cool, and a ringed giant whose rings are being stripped into a visible tail (The Mill). Four Keth hulls, the hardest in the game. Derelict: KSV Bright Arrears, paint burned to bare metal.

**System 10 — The Drum**. Neutron star, EXTREME. Spinning 11.4 times a second; every instrument aboard hears it. A stripped core that should not still be in orbit, a carbon world with the beam pattern burned into its glassed face, and a fragment on an orbit nothing natural would take. THE METRONOME — a structure locked to the pulsar's rotation, one face always to the beam, keeping time since before the star collapsed. Also here: a fifth hull design, not human, not Keth, not Vrenn, not Drift. The Hollow is armed.

## 5. Factions

**The Keth Armada** (Vega Reach) — always hostile. Fighters (fast/aggressive), Gunships (heavy/slow), rare Carriers. Attacks on sight, swarm tactics, calls reinforcements. Angular black/red ships, sharp protrusions, no curves. Loot: Keth weapons, energy cells, scrap metal. Lore: expansionist military empire, destroyed 3 colonies in the past 20 years.

**The Vrenn** (Redfall) — neutral, upgradeable to friendly or hostile via reputation. Scouts (curious), Traders, Warships (only if hostile rep). Hails the player on approach. Organic-looking curved ships, brown-green with bioluminescent veins. Loot: Vrenn bio-tech, exotic organics, unique trade goods. Lore: ancient philosophical species, cautious with humans, rich culture.

**The Drift** (Twin Suns / The Pale) — always hostile, very dangerous. Drones (numerous, weak), Hunters (medium), rare Dreadnoughts (boss). Silent approach, swarm, board-and-infect, targets ship systems specifically. Geometric crystalline ships, dark gray with white fractal patterns. Loot: ancient tech components, Drift core (rare, key crafting). Lore: ancient machine race, unknown origin, slowly consuming systems. Palette note: chassis `#2a2a30` / `#3a3a42`, fractal detailing in near-white `#e8e8f0` — cold and mechanical, deliberately the opposite register from the Hollow below.

**Human Pirates / Raiders** (all systems) — hostile unless outgunned, then flee. Jury-rigged fighters, salvaged freighters, stolen military ships. Opportunistic, demand tribute before attacking isolated targets. Loot: stolen cargo, common weapons, credits. Lore: desperate outcasts, organized crime, some are former colonists.

## 6. The Hollow — new, mechanical + biological threat

This is the addition that gives "Alien: Isolation atmosphere" an actual mechanic, not just a palette. Full gameplay spec is in `context/04`; this section is the fiction.

**What the player is told, in-universe:** Company classification `CONTACT CLASS: INDETERMINATE (BIOLOGICAL)`. Crew slang: **the Hollow.** No two logs describe it quite the same way — that inconsistency is intentional, not a writing gap to fix.

**What it actually is, for our own design purposes (never state this outright in-game):** an extremely rare, mobile, unkillable-with-standard-equipment presence that occupies specific derelicts. It doesn't patrol a whole level; it occupies a *lair* — one wreck, one ancient-station wing — and the encounter is entirely about the player choosing to go in, noticing they're not alone, and getting back out. It interferes with the proximity scanner at close range (the blip goes to static rather than a clean position — a fair, diegetic reason for the player to lose precise information exactly when they need it most).

**Where it appears:** almost exclusively inside `Derelict.js` content in Twin Suns and The Pale. One or two *false-alarm* environmental beats (claw marks, a torn suit, a log that cuts off mid-sentence, no actual encounter) can appear as early as Sol Prime, purely to seed dread before the player has any mechanical stake in it.

**What it is not:** a reskin of any specific existing franchise creature. Keep physical description sensory and incomplete — sound, residue, a glimpse in poor light — rather than a fully modeled, clearly-silhouetted monster. That's both a copyright-safety rule and, more importantly, the actual design reason Isolation's creature stayed scary as long as it did.

## 7. Item fiction

Reuse the v2 prompt's item schema as-is (full example in `context/04`) — the changes here are additive, not structural: item `found` arrays should include `'derelict'` as a source tag where the Hollow's lairs make sense as loot locations (ancient tech, ambiguous biological samples), and any item description referencing the Company should use "Kestrel Extraction & Salvage Co." branding language (§3), not generic "the manufacturer."
