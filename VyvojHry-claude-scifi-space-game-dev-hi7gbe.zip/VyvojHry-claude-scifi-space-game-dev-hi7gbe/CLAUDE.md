# CLAUDE.md — STARRIFT

Read this file at the start of every session. It is short on purpose — the depth lives in `context/`, loaded only when a task touches it. Don't skip the pointers below; they're doing the same job as this instruction itself.

## What STARRIFT is

A first-person, retro pixel-art (16-bit), sci-fi survival-exploration game. You walk the corridors of a lived-in survey ship, fly it (still first-person, from the seat), and explore ten star systems — a five-system commissioned survey route plus five off-route spurs. Vanilla JavaScript + WebGL2, zero external libraries, everything — textures, audio, geometry — generated procedurally at runtime. Built solo, currently player-only crew of a ship rated for six.

The whole point of this project is **mood over spectacle**: this is *Alien* (1979) and *Alien: Isolation*'s design language — worn analog machinery, oppressive shadow, a ship that feels used and a little too empty — rebuilt as hard-edged 16-bit pixel art. Not a bright space opera. If a choice could read as "clean sci-fi" or "cheerful," it's the wrong choice.

## The four pillars (non-negotiable)

1. **Always first person.** No free third-person camera exists anywhere in live gameplay — not walking, not piloting. See "Camera rule" below; it's the one rule that gets its own section because it's the most likely thing to get quietly reintroduced.
2. **Used future, not clean future.** Every surface is worn, dithered, imperfect. Reference is *Alien* (1979) industrial design and *Alien: Isolation*'s Sevastopol — cassette-futurism, analog switches, CRT phosphor, not sleek touchscreens.
3. **Pixel truth.** Nearest-neighbour upscale, no antialiasing, no smooth gradients — dithering only. The base render is a **player-chosen preset** (session 16u, owner-directed): 480×270 CLASSIC, **960×540 FINE (default)**, or 1920×1080 SHARP. Only whole multiples of 480×270 are offered, so the upscale stays integer and no pixel ever gets dropped unevenly. The 2D chrome — HUD, crosshair, notifications, scanner — stays authored on the fixed 480×270 `RENDER.UI_WIDTH/UI_HEIGHT` grid at every preset; it is hand-placed pixel rects and 6px glyphs, and scaling that grid would shrink it, not detail it. Full rules in `context/01-ART-DIRECTION.md`.
4. **Procedural and self-contained.** No asset files, no npm packages, no build step. `index.html` opens and runs. Textures and audio are generated in JS at startup.

## Camera rule (read this twice)

**Walking is always first person** — the viewpoint never detaches from the player's own eyes or helmet glass on foot, ever. That half of the rule is unchanged and non-negotiable.

**Piloting has an optional third-person hull cam** (owner-requested design change, Session 5). The default pilot view is still first-person seated — sitting down and looking through the windshield. But while seated, the player may toggle (`V`, or the touch VIEW button) to an external chase camera that pulls out to show the whole Aethon against space, then toggle back. This is a deliberate, player-driven *piloting* view mode, not a free third-person walking camera, and it exists only in the pilot seat. Outside of piloting, the ship is still only ever seen from outside through a window, on a diegetic screen, or in a non-interactive cinematic (warp/docking/menu/death). Full rationale in `context/02-TECHNICAL-ARCHITECTURE.md`.

## Read before you touch a system

| Working on... | Read first |
|---|---|
| any texture, prop, material, palette, planet/star rendering | `context/01-ART-DIRECTION.md` |
| engine, renderer, shaders, file layout, camera, physics, save format | `context/02-TECHNICAL-ARCHITECTURE.md` |
| ship rooms, corridors, star systems, factions, lore, item fiction | `context/03-WORLD-SHIP-AND-LORE.md` |
| survival stats, inventory, crafting, the Hollow, hacking, hiding, scanner | `context/04-GAMEPLAY-SYSTEMS.md` |
| HUD, menus, fonts, terminal screens | `context/05-UI-HUD-AND-MENUS.md` |
| any sound | `context/06-AUDIO-DESIGN.md` |
| what to build next, definition of done | `context/07-ROADMAP-AND-WORKFLOW.md` |

`.claude/rules/*.md` mirror this table as path-scoped rules — they load automatically when you open matching files, each with a condensed excerpt plus a pointer to the full doc. You still need to read the full doc for real work; the rule is a guardrail, not a substitute.

## Absolute bans

- Neon anything, especially neon green (`#00ff00` family), anywhere, ever — this is the single most-violated rule in v1, check it explicitly.
- Smooth color gradients. Ordered dithering only (4×4 Bayer, spec in `context/01`).
- A third-person exterior camera during live gameplay (see above).
- Flat single-color surfaces — every texture needs 3–4 colors minimum plus wear detail.
- External asset files, CDN imports, npm dependencies. If you're tempted to `npm install` something, generate it instead.
- Verbatim reuse of any real film/game's proprietary names, logos, or creature designs. We build *original* IP that shares a mood with *Alien* — not a reskin of it. Use the invented names in `context/03` (ship, corporation, factions, the Hollow).

## Quick reference

- **Resolution / perf:** scene 960×540 default (480×270 / 1920×1080 selectable), UI grid fixed 480×270, nearest-neighbor upscale · 60fps desktop / 30fps mobile · <200 draw calls interior, <100 space.
- **Stack:** Vanilla JS ES2022 modules, WebGL2 + GLSL ES 3.0, Web Audio API (procedural), custom AABB/sphere physics, `localStorage` saves. No libraries.
- **Signature colors** (full families in `context/01`): dark military metal `#2e3a2e`, rust `#a04e1a`, HUD amber `#c09050`, warning red `#aa2020`, terminal phosphor green `#4a7a52` (diegetic screens only, muted — never the HUD).
- **Top-level layout:**
  ```
  STARRIFT/
  ├── index.html, manifest.json, sw.js
  ├── src/{core,rendering,world,interior,player,ship,entities,combat,gameplay,ui,data,utils}/
  └── assets/{textures,data}/
  ```
  Full module-by-module tree in `context/02-TECHNICAL-ARCHITECTURE.md`.

## What changed from the STARRIFT v2 prompt this is built on

Carried forward: the ship (HSV Aethon), the five route star systems (five more spurs added in session 16n), the four alien factions, the survival stats, the tech stack, the corridor-type system, the palette philosophy.

Changed: flight is now first-person-seated, not third-person pull-back (pillar 1). Two rooms added — Research Lab and Computer Core — since a *survey* vessel plausibly has one, and the new concept art's ship-schematic poster showed both. Added a rare, evasion-only threat ("the Hollow," `context/03` and `context/04`) so "adventure and exploration" actually earns the *Isolation* comparison mechanically, not just visually. Added a diegetic save-terminal ritual, a proximity scanner, and a terminal-hacking minigame for the same reason.

## Open questions for you

- How often should the Hollow actually appear — a once-per-system set-piece, or a recurring pressure across every derelict? `context/04` defaults to "rare and scripted"; easy to dial up.
- Keep "STARRIFT" as the title, or is there a name you prefer? Everything here is a find-and-replace away from a rename.
- `localStorage` is fine for now; if the save format outgrows ~5MB (portrait data, discovered logs, procedurally-named items) we should move to IndexedDB — flagged, not yet a problem.

## Session protocol

Update `context/SESSION_LOG.md` at the end of every session (what shipped, what broke, what's next). Check off completed items in `context/07-ROADMAP-AND-WORKFLOW.md` as you go. If you make the same correction twice in a session, it belongs in this file or a rule — not just in your head.
