/**
 * Service worker — NETWORK-FIRST with offline fallback.
 *
 * The original cache-first strategy could pin a player's very first build
 * forever (every later fix served stale from cache — the "stuck at the menu"
 * bug on devices that had visited once). Now the network is always tried
 * first and the cache only answers when offline. Install fetches bypass both
 * HTTP cache and any old worker (SW-context fetches skip interception), and
 * the new worker takes over immediately.
 */
const CACHE = 'starrift-v0.18.0'; // keep in step with GAME_VERSION so stale caches purge

const FILES = [
  './',
  './index.html',
  './manifest.json',
  './src/main.js',
  './src/core/Engine.js', './src/core/Renderer.js', './src/core/InputManager.js',
  './src/core/AudioEngine.js', './src/core/AssetManager.js', './src/core/StateManager.js',
  './src/core/EventBus.js', './src/core/Constants.js', './src/core/Settings.js',
  './src/utils/MathUtils.js', './src/utils/NoiseUtils.js', './src/utils/ColorUtils.js',
  './src/utils/ObjectPool.js', './src/utils/RNG.js', './src/utils/Debug.js',
  './src/rendering/PixelRenderer.js', './src/rendering/TextureFactory.js',
  './src/rendering/TextureAtlas.js', './src/rendering/LightSystem.js',
  './src/rendering/MeshBuilder.js', './src/rendering/PixelFont.js',
  './src/rendering/SpaceRenderer.js',
  './src/rendering/shaders/interior.vert', './src/rendering/shaders/interior.frag',
  './src/rendering/shaders/hud.vert', './src/rendering/shaders/hud.frag',
  './src/rendering/shaders/space.vert', './src/rendering/shaders/space.frag',
  './src/rendering/shaders/stars.vert', './src/rendering/shaders/stars.frag',
  './src/interior/ShipMap.js', './src/interior/InteriorRenderer.js',
  './src/interior/CollisionMap.js', './src/interior/Room.js', './src/interior/Corridor.js',
  './src/interior/Greebles.js',
  './src/interior/rooms/Cockpit.js', './src/interior/rooms/CaptainQuarters.js',
  './src/interior/rooms/CrewBunks.js', './src/interior/rooms/MedBay.js',
  './src/interior/rooms/Kitchen.js', './src/interior/rooms/Bathroom.js',
  './src/interior/rooms/Storage.js', './src/interior/rooms/CargoBay.js',
  './src/interior/rooms/Airlock.js', './src/interior/rooms/Workshop.js',
  './src/interior/rooms/ResearchLab.js', './src/interior/rooms/ComputerCore.js',
  './src/interior/rooms/ReactorRoom.js', './src/interior/rooms/EngineRoom.js',
  './src/interior/props/PropBase.js', './src/interior/props/Crate.js',
  './src/interior/props/Console.js', './src/interior/props/Panel.js',
  './src/interior/props/Locker.js', './src/interior/props/Bunk.js',
  './src/interior/props/Light.js', './src/interior/props/Door.js',
  './src/interior/props/Pipe.js', './src/interior/props/Vent.js',
  './src/interior/props/MedStation.js', './src/interior/props/FuelPort.js',
  './src/interior/props/StorageRack.js', './src/interior/props/Machinery.js',
  './src/interior/props/SaveTerminal.js', './src/interior/props/HackingTerminal.js',
  './src/interior/props/Seat.js', './src/interior/props/Table.js',
  './src/interior/props/Poster.js', './src/interior/props/SuitRack.js',
  './src/interior/props/Window.js',
  './src/player/Player.js', './src/player/PlayerController.js',
  './src/player/PlayerCamera.js', './src/player/PlayerLight.js',
  './src/ship/Spaceship.js', './src/ship/FlightController.js',
  './src/ship/ShipExterior.js', './src/ship/ThrusterFX.js',
  './src/world/StarSystem.js', './src/data/StarSystemsData.js',
  './src/data/Planetology.js', './src/data/Orbits.js', './src/combat/Weapons.js',
  './src/ui/HUD.js', './src/ui/Crosshair.js', './src/ui/NotificationSystem.js',
  './src/ui/TouchControls.js', './src/ui/SettingsMenu.js',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) =>
      // cache:'reload' bypasses the HTTP cache; SW-context fetches also bypass
      // any previously-controlling worker, so this snapshot is always fresh
      c.addAll(FILES.map((u) => new Request(u, { cache: 'reload' }))),
    ).then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))),
    ).then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request)
      .then((res) => {
        if (res && res.ok) {
          const clone = res.clone();
          caches.open(CACHE).then((c) => c.put(e.request, clone)).catch(() => {});
        }
        return res;
      })
      .catch(() => caches.match(e.request)),
  );
});
